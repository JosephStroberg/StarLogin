function TableBk(longueur)
{
	var alea = Math.round(Math.random()*longueur+0.50000001); 
	document.write("<table style='width:100%;background-image: url(img/bk/"+alea+".jpg);background-attachment:fixed;' border='0' cellpadding='0' cellspacing='0'>");
}
