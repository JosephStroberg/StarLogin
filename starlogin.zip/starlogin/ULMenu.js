// Merci  pompage.net pour ce javascript, juste ce qui me manquait : http://pompage.net/pompe/deroulants/
sfHover = function()
{  // c'est equivalent de function sfHover()
	var sfEls = document.getElementById("ul_MainMenu").getElementsByTagName("LI");
	
	for (var i=0; i<sfEls.length; i++)
	{
		sfEls[i].onmouseover=function()
		{
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function()
		{
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);


// Code HTML qui affiche le menu
function Display_MenuFR()
{
	var i= 0, j = 0;

	// Debut du layer qui contient le menu
	document.write('<DIV id="div_Menu">');
	document.write('<UL id="ul_MainMenu">'); // Debut bloc UL niveau 1
	
	// Debut affichage du menu (bloc LI) de niveau 1
	for (i = 0; i < iNbMenu; i++)
	{
		if (aMenuFR[i].length == 1)
		{
			document.write('<LI ' + wMenu2[i] + '><A href="'); 
			document.write(SplitOptionSsMenu(aMenuFR[i][0], 'URL')); 
			document.write('"><img src="');
			document.write(SplitOptionSsMenu(aMenuFR[i][0], 'IMG')); 
			//document.write('">&nbsp;&deg;&nbsp;'); 
			document.write('">');
			document.write(SplitOptionSsMenu(aMenuFR[i][0], 'TXT')); 
			document.write('</A></LI>');
		}
		else
		{
			document.write('<LI ' + wMenu2[i] + '><A href=' + SplitOptionSsMenu(aMenuFR[i][0], 'URL') + '><img src="' + SplitOptionSsMenu(aMenuFR[i][0], 'IMG') + '">' + SplitOptionSsMenu(aMenuFR[i][0], 'TXT') + '</A><UL>'); // Le texte niveau 1 pour afficher
		
			for (j = 1; j < aMenuFR[i].length; j++)
			{
				// Debut affichage du menu de niveau 2
				if (j == 1)
				{
					document.write('<LI ' + wMenu3[i] + '><A href="');  // Debut affichage du menu (bloc LI) de niveau 2
				}
				else
				{
					document.write('<LI ' + wMenu[i] + '><A href="');  // Debut affichage du menu (bloc LI) de niveau 2
				}
				document.write(SplitOptionSsMenu(aMenuFR[i][j], 'URL')); // Ici le lien vers la page pour afficher
				document.write('"><img src="');
				// Placer une image. Si pas TOUJOURS placer une invisible.
				document.write(SplitOptionSsMenu(aMenuFR[i][j], 'IMG')); 
				//document.write('">&nbsp;&deg;&nbsp;');
				document.write('">');
				document.write(SplitOptionSsMenu(aMenuFR[i][j], 'TXT')); // Le texte niveau 2 pour afficher
				document.write('</A></LI>');  // Fin affichage du menu (bloc LI) de niveau 2
			}
			document.write('</UL>'); // Fin bloc UL niveau 2
			// Fin affichage du menu de niveau 2
			document.write('</LI>');// Fin affichage du menu (bloc LI) de niveau 1
		}
	}

	document.write('</UL>'); // Fin bloc UL niveau 1
	document.write('</DIV>');
	// Fin du layer qui contient le menu
}

//Code HTML qui affiche le menu
function Display_MenuUS()
{
	var i= 0, j = 0;

	// Debut du layer qui contient le menu
	document.write('<DIV id="div_Menu">');
	document.write('<UL id="ul_MainMenu">'); // Debut bloc UL niveau 1
	
	// Debut affichage du menu (bloc LI) de niveau 1
	for (i = 0; i < iNbMenu; i++)
	{
		if (aMenuUS[i].length == 1)
		{
			document.write('<LI ' + wMenu2[i] + '><A href="'); 
			document.write(SplitOptionSsMenu(aMenuUS[i][0], 'URL')); 
			document.write('"><img src="');
			document.write(SplitOptionSsMenu(aMenuUS[i][0], 'IMG')); 
			//document.write('">&nbsp;&deg;&nbsp;'); 
			document.write('">');
			document.write(SplitOptionSsMenu(aMenuUS[i][0], 'TXT')); 
			document.write('</A></LI>');
		}
		else
		{
			//document.write('<LI><A href="#">' + aMenuUS[i][0] + '<img src="img/fw/empty.gif"></A><UL>'); // Le texte niveau 1 pour afficher
			document.write('<LI ' + wMenu2[i] + '><A href=' + SplitOptionSsMenu(aMenuUS[i][0], 'URL') + '><img src="' + SplitOptionSsMenu(aMenuUS[i][0], 'IMG') + '">' + SplitOptionSsMenu(aMenuUS[i][0], 'TXT') + '</A><UL>'); // Le texte niveau 1 pour afficher
			
			for (j = 1; j < aMenuUS[i].length; j++)
			{
				// Debut affichage du menu de niveau 2
				if (j == 1)
				{
					document.write('<LI ' + wMenu3[i] + '><A href="');  // Debut affichage du menu (bloc LI) de niveau 2
				}
				else
				{
					document.write('<LI ' + wMenu[i] + '><A href="');  // Debut affichage du menu (bloc LI) de niveau 2
				}
				document.write(SplitOptionSsMenu(aMenuUS[i][j], 'URL')); // Ici le lien vers la page pour afficher
				document.write('"><img src="');
				// Placer une image. Si pas TOUJOURS placer une invisible.
				document.write(SplitOptionSsMenu(aMenuUS[i][j], 'IMG')); 
				//document.write('">&nbsp;&deg;&nbsp;');
				document.write('">');
				document.write(SplitOptionSsMenu(aMenuUS[i][j], 'TXT')); // Le texte niveau 2 pour afficher
				document.write('</A></LI>');  // Fin affichage du menu (bloc LI) de niveau 2
			}
			document.write('</UL>'); // Fin bloc UL niveau 2
			// Fin affichage du menu de niveau 2
			document.write('</LI>');// Fin affichage du menu (bloc LI) de niveau 1
		}
	}

	document.write('</UL>'); // Fin bloc UL niveau 1
	document.write('</DIV>');
	// Fin du layer qui contient le menu
}


