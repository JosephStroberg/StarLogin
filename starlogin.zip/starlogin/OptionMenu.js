var SEPARATOR_IMG = '~1';
var SEPARATOR_URL = '~2';
var iNbMenu;

	iNbMenu = 5;
	wMenu = new Array(iNbMenu);
	wMenu[0] = 'style="width:125px;padding-top:10px;padding-left:0px;"';
	wMenu[1] = 'style="width:240px;padding-top:0px;padding-left:0px;"';
	wMenu[2] = 'style="width:200px;padding-top:0px;padding-left:0px;"';
	wMenu[3] = 'style="width:160px;padding-top:0px;padding-left:0px;"';
	wMenu[4] = 'style="width:100px;padding-top:0px;padding-left:0px;"';
	wMenu2 = new Array(iNbMenu);
	wMenu2[0] = 'style="width:125px;padding-top:10px;padding-left:15px;"';
	wMenu2[1] = 'style="width:125px;padding-top:10px;padding-left:0px;"';
	wMenu2[2] = 'style="width:125px;padding-top:10px;padding-left:0px;"';
	wMenu2[3] = 'style="width:125px;padding-top:10px;padding-left:0px;"';
	wMenu2[4] = 'style="width:125px;padding-top:10px;padding-left:0px;"';
	wMenu3 = new Array(iNbMenu);
	wMenu3[0] = 'style="width:125px;padding-top:12px;padding-left:0px;"';
	wMenu3[1] = 'style="width:240px;padding-top:12px;padding-left:0px;"';
	wMenu3[2] = 'style="width:200px;padding-top:12px;padding-left:0px;"';
	wMenu3[3] = 'style="width:160px;padding-top:12px;padding-left:0px;"';
	wMenu3[4] = 'style="width:100px;padding-top:12px;padding-left:0px;"';
	
	aMenuUS = new Array(iNbMenu);
	
	aMenuUS[0] = new Array(2);
	aMenuUS[0][0] = '  Presentation' + SEPARATOR_URL + 'presentation.html' + SEPARATOR_IMG + '../img/fw/presentation.png';
	aMenuUS[0][1] = '  Installation' + SEPARATOR_URL + 'installation.html' + SEPARATOR_IMG + '../img/fw/installation.png';
	
	aMenuUS[1] = new Array(7);
	aMenuUS[1][0] = '  Use' + SEPARATOR_URL + 'use.html' + SEPARATOR_IMG + '../img/fw/use.png';
	aMenuUS[1][1] = '  Astrological events' + SEPARATOR_URL + 'events.html' + SEPARATOR_IMG + '../img/fw/events.png';
	aMenuUS[1][2] = '  Charts' + SEPARATOR_URL + 'charts.html' + SEPARATOR_IMG + '../img/fw/charts.png';
	aMenuUS[1][3] = '  Various calculations' + SEPARATOR_URL + 'calculations.html' + SEPARATOR_IMG + '../img/fw/calculations.png';
	aMenuUS[1][4] = '  Tools' + SEPARATOR_URL + 'tools.html' + SEPARATOR_IMG + '../img/fw/tools.png';
	aMenuUS[1][5] = '  Statistics and reports' + SEPARATOR_URL + 'stats.html' + SEPARATOR_IMG + '../img/fw/stats.png';
	aMenuUS[1][6] = '  Organizer' + SEPARATOR_URL + 'organizer.html' + SEPARATOR_IMG + '../img/fw/organizer.png';

	aMenuUS[2] = new Array(11);
	aMenuUS[2][0] = '  Astrology' + SEPARATOR_URL + 'astrology.html' + SEPARATOR_IMG + '../img/fw/astrology.png';
	aMenuUS[2][1] = '  Signs' + SEPARATOR_URL + 'signs.html' + SEPARATOR_IMG + '../img/fw/signs.png';
	aMenuUS[2][2] = '  Planets' + SEPARATOR_URL + 'planets.html' + SEPARATOR_IMG + '../img/fw/planets.png';
	aMenuUS[2][3] = '  Houses' + SEPARATOR_URL + 'houses.html' + SEPARATOR_IMG + '../img/fw/houses.png';
	aMenuUS[2][4] = '  Aspects' + SEPARATOR_URL + 'aspects.html' + SEPARATOR_IMG + '../img/fw/aspects.png';
	aMenuUS[2][5] = '  Configurations' + SEPARATOR_URL + 'configs.html' + SEPARATOR_IMG + '../img/fw/configs.png';
	aMenuUS[2][6] = '  Planets in sign' + SEPARATOR_URL + 'planets_sign.html' + SEPARATOR_IMG + '../img/fw/planets_sign.png';
	aMenuUS[2][7] = '  Planets in house' + SEPARATOR_URL + 'planets_house.html' + SEPARATOR_IMG + '../img/fw/planets_house.png';
	aMenuUS[2][8] = '  Houses in sign' + SEPARATOR_URL + 'houses_sign.html' + SEPARATOR_IMG + '../img/fw/houses_sign.png';
	aMenuUS[2][9] = '  Hourly astrology' + SEPARATOR_URL + 'hastro.html' + SEPARATOR_IMG + '../img/fw/hastro.png';
	aMenuUS[2][10] = '  Soul seed' + SEPARATOR_URL + 'soul_seed.html' + SEPARATOR_IMG + '../img/fw/soul_seed.png';

	aMenuUS[3] = new Array(4);
	aMenuUS[3][0] = '  Data' + SEPARATOR_URL + 'data.html' + SEPARATOR_IMG + '../img/fw/data.png';
	aMenuUS[3][1] = '  Astronomy' + SEPARATOR_URL + 'astronomy.html' + SEPARATOR_IMG + '../img/fw/astronomy.png';
	aMenuUS[3][2] = '  Glossary' + SEPARATOR_URL + 'glossary.html' + SEPARATOR_IMG + '../img/fw/glossary.png';
	aMenuUS[3][3] = '  Database' + SEPARATOR_URL + 'database.html' + SEPARATOR_IMG + '../img/fw/database.png';

	aMenuUS[4] = new Array(1);
	aMenuUS[4][0] = '  Contact' + SEPARATOR_URL + 'contact.html' + SEPARATOR_IMG + '../img/fw/contact.png';

	aMenuFR = new Array(iNbMenu);

	aMenuFR[0] = new Array(1);
	aMenuFR[0][0] = '  Pr&eacute;sentation' + SEPARATOR_URL + 'presentation.html' + SEPARATOR_IMG + '../img/fw/presentation.png';
	aMenuFR[0][1] = '  Installation' + SEPARATOR_URL + 'installation.html' + SEPARATOR_IMG + '../img/fw/installation.png';
	
	aMenuFR[1] = new Array(7);
	aMenuFR[1][0] = '  Utilisation' + SEPARATOR_URL + 'use.html' + SEPARATOR_IMG + '../img/fw/use.png';
	aMenuFR[1][1] = '  &Eacute;v&eacute;nements astrologiques' + SEPARATOR_URL + 'events.html' + SEPARATOR_IMG + '../img/fw/events.png';
	aMenuFR[1][2] = '  Cartes' + SEPARATOR_URL + 'charts.html' + SEPARATOR_IMG + '../img/fw/charts.png';
	aMenuFR[1][3] = '  Calculs divers' + SEPARATOR_URL + 'calculations.html' + SEPARATOR_IMG + '../img/fw/calculations.png';
	aMenuFR[1][4] = '  Outils' + SEPARATOR_URL + 'tools.html' + SEPARATOR_IMG + '../img/fw/tools.png';
	aMenuFR[1][5] = '  Statistiques et rapports' + SEPARATOR_URL + 'stats.html' + SEPARATOR_IMG + '../img/fw/stats.png';
	aMenuFR[1][6] = '  Agenda' + SEPARATOR_URL + 'organizer.html' + SEPARATOR_IMG + '../img/fw/organizer.png';

	aMenuFR[2] = new Array(11);
	aMenuFR[2][0] = '  Astrologie' + SEPARATOR_URL + 'astrology.html' + SEPARATOR_IMG + '../img/fw/astrology.png';
	aMenuFR[2][1] = '  Signes' + SEPARATOR_URL + 'signs.html' + SEPARATOR_IMG + '../img/fw/signs.png';
	aMenuFR[2][2] = '  Astres' + SEPARATOR_URL + 'planets.html' + SEPARATOR_IMG + '../img/fw/planets.png';
	aMenuFR[2][3] = '  Maisons' + SEPARATOR_URL + 'houses.html' + SEPARATOR_IMG + '../img/fw/houses.png';
	aMenuFR[2][4] = '  Aspects' + SEPARATOR_URL + 'aspects.html' + SEPARATOR_IMG + '../img/fw/aspects.png';
	aMenuFR[2][5] = '  Configurations' + SEPARATOR_URL + 'configs.html' + SEPARATOR_IMG + '../img/fw/configs.png';
	aMenuFR[2][6] = '  Astres en signe' + SEPARATOR_URL + 'planets_sign.html' + SEPARATOR_IMG + '../img/fw/planets_sign.png';
	aMenuFR[2][7] = '  Astres en maison' + SEPARATOR_URL + 'planets_house.html' + SEPARATOR_IMG + '../img/fw/planets_house.png';
	aMenuFR[2][8] = '  Maisons en signe' + SEPARATOR_URL + 'houses_sign.html' + SEPARATOR_IMG + '../img/fw/houses_sign.png';
	aMenuFR[2][9] = '  Astrologie horaire' + SEPARATOR_URL + 'hastro.html' + SEPARATOR_IMG + '../img/fw/hastro.png';
	aMenuFR[2][10] = '  Th&egrave;me semence' + SEPARATOR_URL + 'soul_seed.html' + SEPARATOR_IMG + '../img/fw/soul_seed.png';

	aMenuFR[3] = new Array(4);
	aMenuFR[3][0] = '  Donn&eacute;es' + SEPARATOR_URL + 'data.html' + SEPARATOR_IMG + '../img/fw/data.png';
	aMenuFR[3][1] = '  Astronomie' + SEPARATOR_URL + 'astronomy.html' + SEPARATOR_IMG + '../img/fw/astronomy.png';
	aMenuFR[3][2] = '  Glossaire' + SEPARATOR_URL + 'glossary.html' + SEPARATOR_IMG + '../img/fw/glossary.png';
	aMenuFR[3][3] = '  Base de donn&eacute;es' + SEPARATOR_URL + 'database.html' + SEPARATOR_IMG + '../img/fw/database.png';

	aMenuFR[4] = new Array(1);
	aMenuFR[4][0] = '  Contact' + SEPARATOR_URL + 'contact.html' + SEPARATOR_IMG + '../img/fw/contact.png';
	

	function SplitOptionSsMenu(sOption, sType)
	{
		var iPos1 = 0, iPos2 = 0;
		var sRetValue = '';

		switch (sType)
		{
			case 'TXT':
				sRetValue = sOption.substr(0,sOption.indexOf(SEPARATOR_URL));
				break;
			case 'URL':
				iPos1 = sOption.indexOf(SEPARATOR_URL) + 2, sOption.length;
				iPos2 = sOption.indexOf(SEPARATOR_IMG), sOption.length;
				sRetValue = sOption.substring(iPos1, iPos2);
				break;
			case 'IMG':
				sRetValue = sOption.substr(sOption.indexOf(SEPARATOR_IMG) + 2,sOption.length);
				break;
		}
		return sRetValue;
	}
