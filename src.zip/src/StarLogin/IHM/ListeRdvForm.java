package StarLogin.IHM;


import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.KTDate;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecords;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author Francois DESCHAMPS
 */
public class ListeRdvForm extends JFrame
{
    private final StarLoginManager starLoginManager = MainClass.starLoginManager;
    private String classname = this.getClass().getName();
    private Record rdv;
    private Records rdvs;
    private Records vRdvs;//champs visibles seulement
    private DataGrid dgrRdvs;
    private final String sFRQ = ",RDVRECURID,CLIENTID";
    private final String sFRQv = ",RDVRECURID,CLIENTID";
    String listeChampsVisibles;
    String listeTousChamps;
    private boolean bFilter = false;
    private ImageIcon picture;
    private String sQuery;
    private String sQueryV;
    private String filter;
    private String minmaxfilter;
    private final int HAUTEUR_CHAMP = 22;
    private final int LARGEUR_CHAMP = 200;

    /**
     *
     */
    public String currentDirectory = null;
    private DefaultComboBoxModel cmLookFor; //liste des champs
    private JCheckBox chkRecur;
    private final JLabel lblStatus = new JLabel();
    private int rdvRow = 0;
    private int nbOfRdvRows = 0;
    private int saveRdvRow = 0;
    //private boolean bolRdvAdding = false;
    //private boolean bolRdvEditing = false;
    private String datemin;
    private String datemax;
    private final java.util.ResourceBundle bundle;
    private javax.swing.JLabel lblChamp[];
    private javax.swing.JTextField txtChamp[];
    private javax.swing.JPanel pnlChamp[];
    private String value[];
    private boolean isrecur;
    private String rdvid;
    private String recurid;
    ArrayList champs;
    ArrayList sizes;
    ArrayList alias;
    ArrayList vchamps;
    ArrayList vsizes;
    ArrayList valias;

    /**
     *
     */
    public boolean bolClickFromGrid = false;
    private String orderby = " ORDER BY DATE_,NOM_CLIENT";
    private int kc; //key code
    private int cp; //caret position
    private boolean bdelete = false;

    /**
     *
     * @return
     */
    public String getCurrentRdvID()
    {
        return rdvs.getIDFromRow(rdvRow);
    }
    
    /**
     *
     */
    public void saveColOrder()
    {
        if (dgrRdvs == null)
            return;
        JTable tbl = dgrRdvs.getTable();
        String listeChamps = "";
        for (int i=1; i<tbl.getColumnCount()-2; i++)
        {
            String colName = tbl.getColumnName(i);
            for (int j=1; j<vchamps.size(); j++)
            {
                if (String.valueOf(valias.get(j)).equals(colName))
                {
                    colName = String.valueOf(vchamps.get(j));
                }
            }
            if (!colName.equals("ID"))
                listeChamps = listeChamps.concat(colName).concat(",");
        }
        listeChamps = listeChamps.substring(0, listeChamps.length() - 1);
        
        listeChamps = listeChamps.replace(DataBaseRecords.HDFORMAT, "HEURE_DEBUT");
        listeChamps = listeChamps.replace(DataBaseRecords.HFFORMAT, "HEURE_FIN");
        listeChampsVisibles = listeChamps;
        starLoginManager.updateDataBase("UPDATE ordrechamps SET LISTECHAMPSVISIBLES='" + listeChamps + "' WHERE NOMTABLE='RDV'");
        //refreshRecord();
        //showRdv(rdvid);
    }

    /**
     *
     * @param grdRow
     */
    public void removeFromGrid(int grdRow)
    {
        String id = rdvs.getIDFromRow(grdRow);
        starLoginManager.removeRecord(id, "rdv");
        JTable tbl = dgrRdvs.getTable();
        rdvid = null2String(tbl.getValueAt(grdRow, 0));
        recurid = null2String(tbl.getValueAt(grdRow, champs.size() - 2));
        MainClass.removeRdv(recurid, rdvid);
        bdelete = true;
    }
    
    /**
     *
     * @return
     */
    public ListeRdvForm getForm()
    {
        return this;
    }

    /**
     *
     * @return
     */
    public ImageIcon getPicture()
    {
        return picture;
    }

    /**
     *
     * @param data
     */
    public void setPicture(ImageIcon data)
    {
        picture = data;
    }

    private void reloadPicture()
    {
        pnlPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, pnlPhoto.getPreferredSize());
        imageSurface.setToolTipText(null);
        pnlPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(picture);
        imageSurface.setMenuEnabled(false);//bolRdvEditing);
    }

    /** Creates new form MainForm
     * @param datmin
     * @param datmax
     * @param recordid
     * @param bNew */
    public ListeRdvForm(String datmin, String datmax, String recordid, boolean bNew)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));

        bundle = MainClass.bundle;
        datemin = MainClass.getFormatedDate(datmin);
        datemax = MainClass.getFormatedDate(datmax);
        initComponents();
        //btnLookFor1.setVisible(false);
        txtDateMin.setText(datemin);
        txtDateMax.setText(datemax);

        int pos = classname.lastIndexOf(".");
        if (pos>0)
            classname = classname.substring(pos+1);
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0],params[1],params[2],params[3]);
        this.setExtendedState(params[4]);
        
        String svaleur = Options.getDivider(classname, "jSplitPane1").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        int d = Integer.valueOf(svaleur).intValue();
        jSplitPane1.setDividerLocation(d);
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/gestiontemps.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        //initialize data
        refreshRecord();
        if (recordid == null || recordid.equals("") || recordid.equals("-1"))
        {
            if (bNew)
                showRdv(0);//bolRdvAdding = true;
            else
                showRdv(1);
        }
        else
        {
            showRdv(recordid);
        }
        
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    /**
     *
     * @param order
     */
    public void setOrder(String order)
    {
        orderby = order;
        refreshRecord();
        showRdv(rdvid);
    }

    /**
     *
     */
    public final void refreshRecord()
    {
        listeChampsVisibles = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPSVISIBLES", " WHERE NOMTABLE='RDV'");
        listeTousChamps = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPS", " WHERE NOMTABLE='RDV'");
        sQueryV = "SELECT ID,".concat(listeChampsVisibles).concat(sFRQv).concat(" FROM rdv");
        sQuery = "SELECT ID,".concat(listeTousChamps).concat(sFRQ).concat(" FROM rdv");

        if (MainClass.timeType == MainClass.TIME12)
        {
            sQueryV = sQueryV.replace("HEURE_DEBUT", DataBaseRecords.HDFORMAT);
            sQueryV = sQueryV.replace("HEURE_FIN", DataBaseRecords.HFFORMAT);
            sQuery = sQuery.replace("HEURE_DEBUT", DataBaseRecords.HDFORMAT);
            sQuery = sQuery.replace("HEURE_FIN", DataBaseRecords.HFFORMAT);
        }

        if (filter == null || filter.equals(""))
        {
            filter = "1=1";
        }

        //show the rdv record data
        String minfilter = "";
        if (datemin != null && !datemin.equals(""))
            minfilter = " DATE_>='" + FDate.fr2us(datemin) + "' AND ";
        String maxfilter = "";
        if (datemax != null && !datemax.equals(""))
            maxfilter = " DATE_<='" + FDate.fr2us(datemax) + "' AND ";
        minmaxfilter = minfilter.concat(maxfilter);
        rdvs = starLoginManager.getRecords(sQuery.concat(" WHERE " + minmaxfilter + filter + orderby), "rdv");
        vRdvs = starLoginManager.getRecords(sQueryV.concat(" WHERE " + minmaxfilter + filter + orderby), "rdv");
        String nbclients = starLoginManager.getStringFieldValue("rdv", "count(clientid)", " WHERE " + minmaxfilter + filter);
        lblNBRDVs.setText(nbclients);

        champs = rdvs.getFields();
        sizes = rdvs.getSizes();
        alias = rdvs.getHeaders();
        vchamps = vRdvs.getFields();
        vsizes = vRdvs.getSizes();
        valias = vRdvs.getHeaders();
        value = new String[sizes.size()];
        pnlChamp = new JPanel[champs.size() + 1];
        lblChamp = new JLabel[champs.size()];
        txtChamp = new JTextField[champs.size()];
        pnlChamps.removeAll();

        chkRecur = new JCheckBox();
        lblStatus.setOpaque(true);
        scrChamps.getVerticalScrollBar().setUnitIncrement(HAUTEUR_CHAMP);
        scrChamps.getVerticalScrollBar().setBlockIncrement(scrChamps.getHeight() / 5);

        for (int i = 1; i < champs.size() - 2; i++)
        {
            pnlChamp[i] = new JPanel();
            lblChamp[i] = new JLabel();
            txtChamp[i] = new JTextField();

            pnlChamp[i].setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
            pnlChamp[i].setPreferredSize(new java.awt.Dimension(scrChamps.getWidth() - 19, HAUTEUR_CHAMP));

            lblChamp[i].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            lblChamp[i].setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
            lblChamp[i].setOpaque(true);
            lblChamp[i].setPreferredSize(new java.awt.Dimension(LARGEUR_CHAMP, HAUTEUR_CHAMP));
            pnlChamp[i].add(lblChamp[i]);

            final String nomChamp = champs.get(i).toString();
            if (nomChamp.equals("STATUS_"))
            {
                lblStatus.setPreferredSize(new java.awt.Dimension(scrChamps.getWidth() - 219, HAUTEUR_CHAMP));
                pnlChamp[i].add(lblStatus);
            }
            else
            {
                txtChamp[i].setPreferredSize(new java.awt.Dimension(scrChamps.getWidth() - 219, HAUTEUR_CHAMP));
                txtChamp[i].setEditable(false);
                pnlChamp[i].add(txtChamp[i]);
            }
            pnlChamps.add(pnlChamp[i]);
        }

        int n = champs.size() - 2;
        pnlChamp[n] = new JPanel();
        pnlChamp[n].setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        pnlChamp[n].setPreferredSize(new java.awt.Dimension(scrChamps.getWidth() - 19, HAUTEUR_CHAMP));
        lblChamp[n] = new JLabel();
        lblChamp[n].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblChamp[n].setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblChamp[n].setOpaque(true);
        lblChamp[n].setPreferredSize(new java.awt.Dimension(LARGEUR_CHAMP, HAUTEUR_CHAMP));
        pnlChamp[n].add(lblChamp[n]);
        chkRecur.setBorder(null);
        chkRecur.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);//.CENTER);
        chkRecur.setPreferredSize(new java.awt.Dimension(scrChamps.getWidth() - 219, HAUTEUR_CHAMP));
        chkRecur.setEnabled(false);
        chkRecur.setOpaque(true);
        chkRecur.setBackground(lblChamp[n].getBackground());
        pnlChamp[n].add(chkRecur);
        pnlChamps.add(pnlChamp[n]);

        pnlChamps.setPreferredSize(new Dimension(scrChamps.getWidth(), (HAUTEUR_CHAMP - 1) * (champs.size() - 2)));
        dgrRdvs = new DataGrid(vRdvs.getRecords(), valias, vchamps, vsizes, pnlGrid, false, true, false, false, this, true, 0);
        dgrRdvs.getTable().setToolTipText(bundle.getString("DoubleClic2Modify"));
        //if (bolRdvAdding)
        //    saveRdvRow += 1;
        
        DefaultComboBoxModel comboModel2 = new DefaultComboBoxModel();
        cmLookFor = new DefaultComboBoxModel();
        for (int i=1; i<alias.size()-2; i++)
        {
            comboModel2.addElement(alias.get(i));
            cmLookFor.addElement(champs.get(i));
        }
        comboModel2.addElement("");
        cboLookFor.setModel(comboModel2);
        cboLookFor.setSelectedIndex(-1);
        //showRdv(saveRdvRow);
        resetLangue();
        if (bdelete)
            pnlGrid.paintAll(pnlGrid.getGraphics());
        bdelete = false;
    }
    
    /**
     *
     */
    public void setRow()
    {
        refreshRecord();
        saveRdvRow = MainClass.getCurrentRow(rdvs, saveRdvRow);
        showRdv(saveRdvRow);
    }
    
    /**
     *
     * @param rdvid
     */
    public void setRdv(String rdvid)
    {
        this.rdvid = rdvid;
        refreshRecord();
        showRdv(rdvid);
    }
    
    private void removeRec()
    {
        //if ((bolRdvAdding == false) && (bolRdvEditing == false))
        //{
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                JTable tbl = dgrRdvs.getTable();
                int row[] = tbl.getSelectedRows();
                for (int i = 0; i < tbl.getSelectedRowCount(); i++)
                {
                    rdvid = null2String(tbl.getValueAt(row[i], 0));
                    recurid = null2String(tbl.getValueAt(row[i], champs.size() - 2));
                    MainClass.removeRdv(recurid, rdvid);
                }
                bdelete = true;
                setRow();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        //}
    }

    /*public boolean isRdvEditing()
    {
        return bolRdvEditing;
    }

    public void setRdvEditing(boolean data)
    {
        bolRdvEditing = data;
    }*/

    /**
     *
     * @param row
     */
    

    public final void showRdv(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        rdvid = rdvs.getIDFromRow(row);
        showRdv(rdvid);
        rdvRow = row;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    /**
     *
     * @param strID
     */
    public final void showRdv(String strID)
    {
        rdvid = strID;
        if (rdvid == null || rdvid.equals(""))
            rdvid = "-1";
        if (filter == null)
            filter = "";
        String sql = "SELECT ID,".concat(listeTousChamps).concat(sFRQ).concat(" FROM rdv");
        rdv = starLoginManager.getRecord(sql + " WHERE " + minmaxfilter + filter + " AND ID=" + rdvid + orderby, "rdv", " WHERE " + minmaxfilter + filter);
        
        rdvRow = rdv.getRow();
        saveRdvRow = rdvRow;
        
        if (bolClickFromGrid == false)
            dgrRdvs.setSelectedRow(saveRdvRow);
        else
            bolClickFromGrid = false;
        
        nbOfRdvRows = rdv.getRowNB();
        for (int i = 1; i < champs.size() - 2; i++)
        {
            value[i] = rdv.getData(i);
        }
        String clientid = rdv.getData(champs.size() - 1);
        if (clientid.equals(""))
            clientid = "-1";
        Record photoclient = starLoginManager.getRecord("SELECT ID,PICTURE FROM clients WHERE ID=" + clientid, "clients", "");
        picture = photoclient.getPicture();
        recurid = rdv.getData(champs.size() - 2);
        rdvid = rdv.getData(0);//champs.size() - 6
        reloadPicture();
        setDataToText();
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("RendezVous"));
        btnLookFor.setText(bundle.getString("LookFor"));
        btnLookFor1.setText(bundle.getString("TraitementDonnees"));
        for (int i=1; i< champs.size()-2; i++)
        {
            lblChamp[i].setText(String.valueOf(alias.get(i)));
        }
        lblChamp[champs.size()-2].setText(bundle.getString("Recurrence"));
        btnAddRdv.setText(bundle.getString("Add"));
        btnRemoveRdv.setText(bundle.getString("Remove"));
        btnModify.setText(bundle.getString("Modifier"));
        btnSelectFields.setText(bundle.getString("SelectFields"));
        btnFilter.setText(bundle.getString("Filter"));
        lblDateMin.setText(bundle.getString("Du"));
        lblDateMax.setText(bundle.getString("au"));
        lblNbRdvs.setText(bundle.getString("NbRdvs"));
    }

    private void setDataToText()
    {
    isrecur = (recurid!= null && !recurid.equals("") && !recurid.equals("0") && !recurid.equals("-1"));
        chkRecur.setSelected(isrecur);
        
        if (rdvRow > nbOfRdvRows)
        {
            rdvRow = nbOfRdvRows;
        }

        for (int i=1; i<champs.size() - 2; i++)
        {
            String nomChamp = champs.get(i).toString();
            if (nomChamp.contains("HEURE_DEBUT")||nomChamp.contains("HEURE_FIN"))
            {
                value[i] = FTime.formatAMPM(value[i]);
                txtChamp[i].setText(value[i]);
            }
            else if (nomChamp.equals("STATUS_"))
            {
                String text = null2String(value[i]);
                lblStatus.setText(text);
                Record statutrdv = MainClass.starLoginManager.getRecord("SELECT ID, COULEUR FROM statutrdv WHERE NOM='" + text + "'", "statutrdv", "");
                String scouleur = statutrdv.getData(1);
                Color couleur;
                if (scouleur == null||scouleur.equals("")||scouleur.equals("null"))
                    scouleur = "-1";
                if (scouleur.equals("-1"))
                    couleur = Color.WHITE;
                else
                    couleur = new Color(Integer.valueOf(scouleur));
                lblStatus.setForeground(couleur);
                int icol = couleur.getRGB();
                int w = 16;
                int h = 16;
                BufferedImage nouvelleImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
                int[] rgbs = new int[w*h];
                for (int j = 0; j< w*h; j++)
                {
                    rgbs[j] = icol;
                }
                nouvelleImage.setRGB(0,0,w,h,rgbs,0,w);
                ImageIcon imgicon = new ImageIcon(nouvelleImage);
                lblStatus.setIcon(imgicon);
            }
            else
            {
                txtChamp[i].setText(null2String(value[i]));
            }
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBoutons = new javax.swing.JPanel();
        btnAddRdv = new javax.swing.JButton();
        btnRemoveRdv = new javax.swing.JButton();
        btnModify = new javax.swing.JButton();
        btnLookFor1 = new javax.swing.JButton();
        btnSelectFields = new javax.swing.JButton();
        pnlLookFor = new javax.swing.JPanel();
        cboLookFor = new javax.swing.JComboBox();
        txtLookFor = new javax.swing.JTextField();
        btnLookFor = new javax.swing.JButton();
        btnFilter = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        pnlInfos = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        lblDateMin = new javax.swing.JLabel();
        txtDateMin = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        lblDateMax = new javax.swing.JLabel();
        txtDateMax = new javax.swing.JTextField();
        pnlPhoto = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        lblNbRdvs = new javax.swing.JLabel();
        lblNBRDVs = new javax.swing.JLabel();
        scrChamps = new javax.swing.JScrollPane();
        pnlChamps = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        pnlGridContacts = new javax.swing.JPanel();
        pnlGrid = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setExtendedState(4);
        setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        setMinimumSize(new java.awt.Dimension(1010, 680));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        pnlBoutons.setPreferredSize(new java.awt.Dimension(1000, 72));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        btnAddRdv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddRdv.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddRdv.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAddRdv.setMaximumSize(new java.awt.Dimension(31, 31));
        btnAddRdv.setMinimumSize(new java.awt.Dimension(29, 29));
        btnAddRdv.setPreferredSize(new java.awt.Dimension(150, 32));
        btnAddRdv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddRdvActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddRdv);

        btnRemoveRdv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveRdv.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemoveRdv.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemoveRdv.setMaximumSize(new java.awt.Dimension(31, 31));
        btnRemoveRdv.setMinimumSize(new java.awt.Dimension(29, 29));
        btnRemoveRdv.setPreferredSize(new java.awt.Dimension(150, 32));
        btnRemoveRdv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveRdvActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveRdv);

        btnModify.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png"))); // NOI18N
        btnModify.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnModify.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnModify.setMaximumSize(new java.awt.Dimension(31, 31));
        btnModify.setMinimumSize(new java.awt.Dimension(29, 29));
        btnModify.setPreferredSize(new java.awt.Dimension(150, 32));
        btnModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModifyActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnModify);

        btnLookFor1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
        btnLookFor1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor1.setPreferredSize(new java.awt.Dimension(220, 32));
        btnLookFor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookFor1ActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnLookFor1);

        btnSelectFields.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/selected.png"))); // NOI18N
        btnSelectFields.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSelectFields.setPreferredSize(new java.awt.Dimension(220, 32));
        btnSelectFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectFieldsActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnSelectFields);

        pnlLookFor.setPreferredSize(new java.awt.Dimension(560, 32));
        pnlLookFor.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        cboLookFor.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlLookFor.add(cboLookFor);

        txtLookFor.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtLookFor.setPreferredSize(new java.awt.Dimension(140, 30));
        pnlLookFor.add(txtLookFor);

        btnLookFor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/lookfor.png"))); // NOI18N
        btnLookFor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor.setPreferredSize(new java.awt.Dimension(200, 32));
        btnLookFor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookForActionPerformed(evt);
            }
        });
        pnlLookFor.add(btnLookFor);

        pnlBoutons.add(pnlLookFor);

        btnFilter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/filtrer.png"))); // NOI18N
        btnFilter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFilter.setPreferredSize(new java.awt.Dimension(150, 32));
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnFilter);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        jSplitPane1.setBorder(null);
        jSplitPane1.setDividerLocation(300);
        jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        pnlInfos.setMinimumSize(new java.awt.Dimension(945, 220));
        pnlInfos.setPreferredSize(new java.awt.Dimension(945, 256));
        pnlInfos.setLayout(new java.awt.BorderLayout());

        jPanel9.setLayout(new java.awt.BorderLayout());

        jPanel10.setPreferredSize(new java.awt.Dimension(100, 5));
        jPanel9.add(jPanel10, java.awt.BorderLayout.SOUTH);

        jPanel11.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel9.add(jPanel11, java.awt.BorderLayout.WEST);

        jPanel8.setPreferredSize(new java.awt.Dimension(100, 30));

        jPanel14.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jPanel14.add(lblDateMin);

        txtDateMin.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtDateMin.setName(""); // NOI18N
        txtDateMin.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateMinMousePressed(evt);
            }
        });
        txtDateMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateMinKeyTyped(evt);
            }
        });
        jPanel14.add(txtDateMin);

        jPanel8.add(jPanel14);

        jPanel15.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jPanel15.add(lblDateMax);

        txtDateMax.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtDateMax.setName(""); // NOI18N
        txtDateMax.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateMax.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateMaxMousePressed(evt);
            }
        });
        txtDateMax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateMaxKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateMaxKeyTyped(evt);
            }
        });
        jPanel15.add(txtDateMax);

        jPanel8.add(jPanel15);

        jPanel9.add(jPanel8, java.awt.BorderLayout.PAGE_START);

        pnlPhoto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlPhoto.setPreferredSize(new java.awt.Dimension(324, 246));
        pnlPhoto.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        jPanel9.add(pnlPhoto, java.awt.BorderLayout.CENTER);

        jPanel12.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel9.add(jPanel12, java.awt.BorderLayout.EAST);

        pnlInfos.add(jPanel9, java.awt.BorderLayout.WEST);

        jPanel13.setLayout(new java.awt.BorderLayout());

        jPanel4.setLayout(new java.awt.BorderLayout());

        jPanel7.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        jPanel7.add(lblNbRdvs);

        lblNBRDVs.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblNBRDVs.setPreferredSize(new java.awt.Dimension(90, 22));
        jPanel7.add(lblNBRDVs);

        jPanel4.add(jPanel7, java.awt.BorderLayout.NORTH);

        scrChamps.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        scrChamps.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrChamps.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrChamps.setPreferredSize(new java.awt.Dimension(418, 246));

        pnlChamps.setOpaque(false);
        pnlChamps.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, -1));
        scrChamps.setViewportView(pnlChamps);

        jPanel4.add(scrChamps, java.awt.BorderLayout.CENTER);

        jPanel13.add(jPanel4, java.awt.BorderLayout.CENTER);

        jPanel1.setPreferredSize(new java.awt.Dimension(100, 5));
        jPanel13.add(jPanel1, java.awt.BorderLayout.SOUTH);

        jPanel2.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel13.add(jPanel2, java.awt.BorderLayout.EAST);

        pnlInfos.add(jPanel13, java.awt.BorderLayout.CENTER);

        jSplitPane1.setRightComponent(pnlInfos);

        pnlGridContacts.setLayout(new java.awt.BorderLayout());

        pnlGrid.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlGrid.setLayout(new java.awt.BorderLayout());
        pnlGridContacts.add(pnlGrid, java.awt.BorderLayout.CENTER);

        jPanel3.setPreferredSize(new java.awt.Dimension(5, 100));
        pnlGridContacts.add(jPanel3, java.awt.BorderLayout.EAST);

        jPanel5.setPreferredSize(new java.awt.Dimension(5, 100));
        pnlGridContacts.add(jPanel5, java.awt.BorderLayout.WEST);

        jSplitPane1.setLeftComponent(pnlGridContacts);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = this.getExtendedState();
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        int div = jSplitPane1.getDividerLocation();
        MainClass.options.setDivider(classname, "jSplitPane1", div);
        
        Window windows[] = java.awt.Frame.getWindows();
        for (Window window : windows)
        {
            if (window instanceof GestionTempsForm)
            {
                ((GestionTempsForm) window).setDeleted(bdelete);
                ((GestionTempsForm) window).refreshRdvs(true, rdvid);
            }
        }
    }//GEN-LAST:event_formWindowClosing

    private void btnRemoveRdvActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveRdvActionPerformed
    {//GEN-HEADEREND:event_btnRemoveRdvActionPerformed
        removeRec();
    }//GEN-LAST:event_btnRemoveRdvActionPerformed

    private void btnLookForActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookForActionPerformed
    {//GEN-HEADEREND:event_btnLookForActionPerformed
        Object ofield = cmLookFor.getElementAt(cboLookFor.getSelectedIndex());
        if (ofield == null)
            return;
        if (txtLookFor.getText().equals(""))
            return;
        String sText = txtLookFor.getText().replace("'", "''").toUpperCase();
        String sfield = String.valueOf(ofield);
        sfield = "UCASE(".concat(sfield).concat(")");
        String search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
        String search2 = sfield.concat(" Like '").concat(sText).concat("%'");
        String search3 = sfield.concat(" Like '%").concat(sText).concat("'");
        String search4 = sfield.concat(" ='").concat(sText).concat("'");
        if (rdvid.equals(""))
            rdvid = "-1";
        String id = starLoginManager.getStringFieldValue("rdv", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID>" + rdvid + " AND " + minmaxfilter + filter));
        if (id.equals("-1"))
            id = starLoginManager.getStringFieldValue("rdv", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID<" + rdvid + " AND " + minmaxfilter + filter));
        showRdv(id);
        int row = rdvs.getRowFromID(id);
        dgrRdvs.setSelectedRow(row);
    }//GEN-LAST:event_btnLookForActionPerformed

    private void btnLookFor1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookFor1ActionPerformed
    {//GEN-HEADEREND:event_btnLookFor1ActionPerformed
        DialogQueryTool gf = new DialogQueryTool(4, this, true);
    }//GEN-LAST:event_btnLookFor1ActionPerformed

    private void btnSelectFieldsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSelectFieldsActionPerformed
    {//GEN-HEADEREND:event_btnSelectFieldsActionPerformed
        DlgSelectRdvFields.ShowDialog();
        refreshRecord();
        showRdv(rdvid);
        //pnlChamps.paintAll(pnlChamps.getGraphics());
        //pnlGrid.paintImmediately(pnlGrid.getBounds());
        //Rectangle rec = this.getBounds();
        //this.setBounds(rec.x, rec.y, rec.width, rec.height-1);
        //this.setBounds(rec.x, rec.y, rec.width, rec.height+1);
    }//GEN-LAST:event_btnSelectFieldsActionPerformed

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFilterActionPerformed
    {//GEN-HEADEREND:event_btnFilterActionPerformed
        bFilter = !bFilter;
        if (!bFilter)
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            filter = "";
            cboLookFor.setSelectedIndex(-1);
            txtLookFor.setText("");
            refreshRecord();
            setDataToText();
        }
        else
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
            Object ofield = cmLookFor.getElementAt(cboLookFor.getSelectedIndex());
            if (ofield == null)
            {
                filter = "";
                refreshRecord();
                return;
            }
            if (txtLookFor.getText().equals(""))
            {
                filter = "";
                refreshRecord();
                return;
            }
            String sText = txtLookFor.getText().replace("'", "''").toUpperCase();
            String sfield = String.valueOf(ofield);
            sfield = "UCASE(".concat(sfield).concat(")");
            String search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
            String search2 = sfield.concat(" Like '").concat(sText).concat("%'");
            String search3 = sfield.concat(" Like '%").concat(sText).concat("'");
            String search4 = sfield.concat(" ='").concat(sText).concat("'");
            filter = " (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") ");
            refreshRecord();
        }
        showRdv(rdvid);
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnAddRdvActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddRdvActionPerformed
    {//GEN-HEADEREND:event_btnAddRdvActionPerformed
        DialogRdv dlgRdv = new DialogRdv(this, true, datemin, MainClass.STIME_120000, "-1", false);
        //refreshRecord();
        //showRdv(rdvid);
    }//GEN-LAST:event_btnAddRdvActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowOpened
    {//GEN-HEADEREND:event_formWindowOpened
        String svaleur = Options.getDivider("ListeRdvForm", "jSplitPane1").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        int d = Integer.valueOf(svaleur).intValue();
        jSplitPane1.setDividerLocation(d);
    }//GEN-LAST:event_formWindowOpened

    private void txtDateMinMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMinMousePressed
    {//GEN-HEADEREND:event_txtDateMinMousePressed
        if (evt.getButton() == 1)
        {
            datemin = DlgCalendar.ShowCalendar(datemin);
            datemin = MainClass.getFormatedDate(datemin);
            txtDateMin.setText(datemin);
            refreshRecord();
            showRdv(rdvid);
        }
    }//GEN-LAST:event_txtDateMinMousePressed

    private void txtDateMinKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyTyped
    {//GEN-HEADEREND:event_txtDateMinKeyTyped
        KTDate d = new KTDate(evt, txtDateMin, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMin.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMinKeyTyped

    private void txtDateMaxMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMaxMousePressed
    {//GEN-HEADEREND:event_txtDateMaxMousePressed
        if (evt.getButton() == 1)
        {
            datemax = DlgCalendar.ShowCalendar(datemax);
            datemax = MainClass.getFormatedDate(datemax);
            txtDateMax.setText(datemax);
            refreshRecord();
            showRdv(rdvid);
        }
    }//GEN-LAST:event_txtDateMaxMousePressed

    private void txtDateMaxKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMaxKeyTyped
    {//GEN-HEADEREND:event_txtDateMaxKeyTyped
        KTDate d = new KTDate(evt, txtDateMax, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMax.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMaxKeyTyped

    private void btnModifyActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnModifyActionPerformed
    {//GEN-HEADEREND:event_btnModifyActionPerformed
        DialogRdv dlgrdv = new DialogRdv(this, true, "", "", rdvid, false);
        //refreshRecord();
        //showRdv(rdvid);
    }//GEN-LAST:event_btnModifyActionPerformed

    private void txtDateMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyPressed
    {//GEN-HEADEREND:event_txtDateMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMin.getCaretPosition();
        }
        KTDate td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDate(evt, txtDateMin, kc);
    }//GEN-LAST:event_txtDateMinKeyPressed

    private void txtDateMaxKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMaxKeyPressed
    {//GEN-HEADEREND:event_txtDateMaxKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMax.getCaretPosition();
        }
        KTDate td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDate(evt, txtDateMax, kc);
    }//GEN-LAST:event_txtDateMaxKeyPressed

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        int w = this.getBounds().width;
        if (w < 1600)
        {
            pnlBoutons.setPreferredSize(new Dimension(10,72));
            pnlBoutons.setSize(new Dimension(w,72));
        }
        else
        {
            pnlBoutons.setPreferredSize(new Dimension(10,36));
            pnlBoutons.setSize(new Dimension(w,36));
        }
        pnlBoutons.paintImmediately(pnlBoutons.getBounds());
        jSplitPane1.paintImmediately(jSplitPane1.getBounds());
        //this.paintAll(this.getGraphics());
    }//GEN-LAST:event_formComponentResized

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddRdv;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnLookFor;
    private javax.swing.JButton btnLookFor1;
    private javax.swing.JButton btnModify;
    private javax.swing.JButton btnRemoveRdv;
    private javax.swing.JButton btnSelectFields;
    private javax.swing.JComboBox cboLookFor;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblDateMax;
    private javax.swing.JLabel lblDateMin;
    private javax.swing.JLabel lblNBRDVs;
    private javax.swing.JLabel lblNbRdvs;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlChamps;
    private javax.swing.JPanel pnlGrid;
    private javax.swing.JPanel pnlGridContacts;
    private javax.swing.JPanel pnlInfos;
    private javax.swing.JPanel pnlLookFor;
    private javax.swing.JPanel pnlPhoto;
    private javax.swing.JScrollPane scrChamps;
    private javax.swing.JTextField txtDateMax;
    private javax.swing.JTextField txtDateMin;
    private javax.swing.JTextField txtLookFor;
    // End of variables declaration//GEN-END:variables
}
