package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTUnsignedInteger;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.ChartInterpretation;
import StarLogin.Systeme.ChartResults;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D.Double;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javax.swing.*;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DrawChart extends ChartSurface
{
    private StarLoginManager starLoginManager;
    private ResourceBundle bundle = MainClass.bundle;

    //stars and constellations data
    private Stars stars;
    private ConstellBound constellBound;
    private ConstellationBoundaries constellationBoundaries;
    private ShowConstel showConstel;

    //chart elements
    private SkyChart skyChart;
    private double zoom = 1.0;
    private ChartElements chartElements;
    private double zooms[] =
    {
        20.0, 10.0, 5.0, 4.0, 3.0, 2.5, 2.0, 1.5, 1.25, 1.0, 0.75, 0.5
    };
    private boolean bSetting = true;
    private double deltaAngle = 0.0;
    private int chartKind;
    private int sum_harmo = 1;
    private static final String FT_ARIAL = "arial";
    private static final String FT_STARLOGIN = "StarLogin";
    private static final int topMargin = 15;
    private static final int leftMargin = 5;
    private boolean bMouseMoving = false;           //indication of mouse motion to move the chart

    private Timer timer;                            //Timer to enable animation of the chart

    private int largeRadius = 0;                    //large radius of an astrological chart
    private int smallRadius = 0;                    //small  "
    private int centerX = 0;                        //horizontal position of the center of the chart
    private int centerY = 0;                        //vertical position of the center of the chart
    private int chartW = 0;                         //width of the visible part for the chart drawing
    private int chartH = 0;                         //height   "
    private int hcy = 0;                            //horizontal size for local chart
    private int zcy = 0;                            //vertical      "
    private int hRadius = 0;                        //radius in case of view toward horizon in local chart
    private int zRadius = 0;                        //radius in case of view toward zenith in local chart
    private int characterSize = 8;                  //character size
    private int starsCharacterSize = 8;             //character size for stars name
    private int planetSize = 12;                    //planet character size
    private String aspectKinds[][] = new String[Planets.MC + 1][Planets.MC + 1];         //aspects kinds
    private double aspectValues[][] = new double[Planets.MC + 1][Planets.MC + 1];        //Value of aspects
    private String relativeAspects[][] = new String[Planets.MC + 1][Planets.MC + 1];     //relative aspects values
    private short spire[][] = new short[Planets.MC + 1][Planets.MC + 1];                 //spiral number in relative aspects values
    private ArrayList events = new ArrayList();                                     //events for both inner and outer charts
    private ArrayList positions = new ArrayList();                                  //positions for both inner and outer charts
    private ChartEvent chartEvent;                                                  //event information
    private AllCoord pos1 = new AllCoord();                                         //positions of planets in inner chart
    private AllCoord pos2 = new AllCoord();                                         //positions of planets in outer chart
    private AllCoord posX = new AllCoord();                                         //positions to permute charts
    private String header = "";                                                     //header with harmonic value and new date if animation
    private int tableau_flag = Astrology.POS_1;                                     //Chart(s) taken into account for aspects
    private static final double TSL12 = 12.032854893;
    private static final byte EXTERIEUR = 0;
    private static final byte INTERIEUR = 1;
    private boolean bIncrease = true;                       //indication of modification of the chart adding time to the initial date
    private boolean bMousePressed = false;                  //indication of mouse being pressed

    //about stars
    private ArrayList nom_etoile = new ArrayList();         //star name
    private ArrayList magnitude = new ArrayList();          //star magniture
    private ArrayList azimut = new ArrayList();             //star azimuth
    private ArrayList hauteur = new ArrayList();            //star altitude
    private ArrayList long_star = new ArrayList();          //star first coordinate
    private ArrayList couleur = new ArrayList();            //star color

    private double angle_bary;                              //angle of the barycenter
    private double rayon_bary;                              //rayon of the barycenter

    private MVector VIni;                                   //initial position of the mouse when it's moved while down
    private double dblAngle = 0.0;                          //total angle modification of the chart from the initial moment of a minor or a major modification of the chart
    private String planetaryConfigurations = "";            //planetary configurations

    private int kc;//key code

    ActionListener taskPerformer = new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent evt)
        {
            if (btnAnimate.isSelected())
            {
                if (bIncrease)
                {
                    modifChart(getStep());
                }
                else
                {
                    modifChart(-getStep());
                }
            }
        }
    };

    public DrawChart(ChartElements chartElements, SkyChart skyChart, StarLoginManager starLoginManager)
    {
        this.starLoginManager = starLoginManager;
        events = chartElements.getChartEvents();
        positions = chartElements.getChartCoords();
        if (positions == null || skyChart == null || events.isEmpty())
        {
            return;
        }
        stars = starLoginManager.getStars();
        showConstel = starLoginManager.getShowConstel();
        constellationBoundaries = starLoginManager.getConstellationBoundaries();
        constellBound = starLoginManager.getConstellBound();
        this.chartElements = chartElements;
        this.skyChart = skyChart;
        planetaryConfigurations = chartElements.getPlanetaryConfigurations();
        chartKind = chartElements.getChartKind();
        chartEvent = (ChartEvent) events.get(0);
        header = chartEvent.getHeader();
        pos1 = (AllCoord) positions.get(0);
        if (positions.size() > 1)
        {
            pos2 = (AllCoord) positions.get(1);
        }

        initComponents();
        if (chartKind == ChartKind.local)
        {
            btnInterpret.setVisible(false);
        }

        //jPnlToolbar.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        header = modifHeader(chartEvent.getHeader());

        //make invisible some controls for some chart kinds
        if ((chartKind == ChartKind.composite) || (chartKind == ChartKind.free) || (chartKind == ChartKind.noChart) || (chartKind == ChartKind.synastry))
        {
            btnIncrease.setVisible(false);
            btnDecrease.setVisible(false);
            lblNewDate.setVisible(false);
            cboSteps.setVisible(false);
            btnAnimate.setVisible(false);
            jSeparator2.setVisible(false);
        }

        if (btnAnimate.isVisible())
        {
            timer = new Timer(100, taskPerformer);
        }

        cboZoom.addItem("2000 %");
        cboZoom.addItem("1000 %");
        cboZoom.addItem("500 %");
        cboZoom.addItem("400 %");
        cboZoom.addItem("300 %");
        cboZoom.addItem("250 %");
        cboZoom.addItem("200 %");
        cboZoom.addItem("150 %");
        cboZoom.addItem("125 %");
        cboZoom.addItem("100 %");
        cboZoom.addItem("75 %");
        cboZoom.addItem("50 %");
        cboRulersKind.addItem(Rulers.getRulerKind(Rulers.Orthodox));
        cboRulersKind.addItem(Rulers.getRulerKind(Rulers.Modern));
        cboRulersKind.addItem(Rulers.getRulerKind(Rulers.Esoteric));
        cboRulersKind.addItem(Rulers.getRulerKind(Rulers.Hierarchical));
        cboRulersKind.addItem(Rulers.getRulerKind(Rulers.All));
        cboRulersRef.addItem(Rulers.getRulerRef(Rulers.InSign));
        cboRulersRef.addItem(Rulers.getRulerRef(Rulers.InHouse));
        cboRulersRef.addItem(Rulers.getRulerRef(Rulers.Both));
        cboSteps.addItem(bundle.getString("1minute"));
        cboSteps.addItem(bundle.getString("5minutes"));
        cboSteps.addItem(bundle.getString("15minutes"));
        cboSteps.addItem(bundle.getString("1hour"));
        cboSteps.addItem(bundle.getString("6hours"));
        cboSteps.addItem(bundle.getString("1day"));
        cboSteps.addItem(bundle.getString("1week"));
        cboSteps.addItem(bundle.getString("1month"));
        cboSteps.addItem(bundle.getString("3months"));
        cboSteps.addItem(bundle.getString("6months"));
        cboSteps.addItem(bundle.getString("1year"));
        cboSteps.addItem(bundle.getString("5years"));
        cboSteps.addItem(bundle.getString("10years"));
        cboSteps.addItem(bundle.getString("50years"));
        cboSteps.addItem(bundle.getString("1century"));
        cboSteps.setSelectedIndex(3);
        cboZoom.setSelectedIndex(9);
        if (zoom == 0.0)
        {
            zoom = 1.0;
        }
        if (chartElements.getHorizon() == true)
        {
            mnuHorizon.setSelected(true);
            //mnuHorizon.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
            //mnuZenith.setBackground(new Color(204, 204, 204));
        }
        else
        {
            mnuZenith.setSelected(true);
            //mnuZenith.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
            //mnuHorizon.setBackground(new Color(204, 204, 204));
        }
        bSetting = false;
        if (chartElements.getViewStars() || chartKind == ChartKind.local)
        {
            reCalcStars();
        }
        recalcForDomitudes();
    }

    private void recalcForDomitudes()
    {
        if (chartElements.getCoordSys() == CoordSystem.Domitudes)
        {
            double as = pos1.get(Planets.AS).getTropicGeoLong();
            for (int i = 0; i < Planets.getLast(); i++)
            {
                double lng = pos1.get(i).getTropicGeoLong();
                double delta = AstronomyMaths.modulo(lng - as, 360.0);
                if (delta >= 0.0 && delta < 90.0)
                {
                    lng = -pos1.get(i).getAlt();
                }
                else if (delta >= 90.0 && delta < 270.0)

                {
                    lng = 180 + pos1.get(i).getAlt();
                }
                else
                {
                    lng = 360 - pos1.get(i).getAlt();
                }
                pos1.get(i).setAlt(lng);
            }
            if (positions.size() > 1)
            {
                as = pos2.get(Planets.AS).getTropicGeoLong();
                for (int i = 0; i < Planets.getLast(); i++)
                {
                    double lng = pos2.get(i).getTropicGeoLong();
                    double delta = AstronomyMaths.modulo(lng - as, 360.0);
                    if (delta >= 0.0 && delta < 90.0)
                    {
                        lng = -pos2.get(i).getAlt();
                    }
                    else if (delta >= 90.0 && delta < 270.0)

                    {
                        lng = 180 + pos2.get(i).getAlt();
                    }
                    else
                    {
                        lng = 360 - pos2.get(i).getAlt();
                    }
                    pos2.get(i).setAlt(lng);
                }
            }
        }
    }

    @Override
    public void setZoom(double data)
    {
        zoom = data;
        super.setZoom(data);
    }

    @Override
    public void render(int w, int h, Graphics2D g2, int x, int y)
    {
        //Display the chart
        if (chartKind != ChartKind.noChart)
        {
            int deltaW = (int) ((1.0 - zoom) / 2.0 * (double) w) - x;
            int deltaH = (int) ((1.0 - zoom) / 2.0 * (double) h) - y;
            w = (int) (zoom * (double) w);
            h = (int) (zoom * (double) h);
            chartW = w;
            chartH = h;
            g2.clearRect(0, 0, w, h);
            double refSize;
            if (chartElements != null && chartElements.getHorizon() == true)
            {
                refSize = (double) Math.min(w / 2.0, h) / 2.0;
            }
            else
            {
                refSize = (double) Math.min(w, h) / 2.0;
            }
            largeRadius = (int) (refSize / 2.0);
            smallRadius = (int) ((double) largeRadius / 1.5);
            centerY = h / 2 + deltaH;
            centerX = w / 2 + deltaW;
            if (skyChart == null)
            {
                hcy = h;
            }
            else
            {
                hcy = skyChart.getHeight() - (int) ((double) super.getHorizontalScrollBar().getHeight() * 1.5);
            }
            zcy = centerY;
            zRadius = (int) refSize - super.getHorizontalScrollBar().getHeight();
            hRadius = 2 * zRadius;
            if (chartElements == null)
            {
                largeRadius = (largeRadius * 50) / 100;
                smallRadius = (smallRadius * 50) / 100;
                planetSize = 8;
                characterSize = 8;
                starsCharacterSize = 8;
            }
            else
            {
                largeRadius = (largeRadius * chartElements.getZodiacSize()) / 100;
                smallRadius = (smallRadius * chartElements.getZodiacSize()) / 100;
                planetSize = (int) (chartElements.getPlanetSize() * zoom);
                characterSize = (int) (chartElements.getCharacterSize() * zoom);
                starsCharacterSize = (int) (chartElements.getCharacterSize() * Math.sqrt(zoom));
            }

            if (chartKind != ChartKind.local)
            {
                chartZodiac(g2);
            }
            else
            {
                localChart(g2, 0.0);
            }
        }
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void modifChart(double delta_hour)
    {
        txtHarmonicNB.setText("1");
        sum_harmo = 1;

        if (chartKind == ChartKind.transit)
        {
            //change the transit date
            String sDateTime = chartElements.getTransitsDate();
            String sDate = sDateTime;
            String sTime = MainClass.STIME_000000;
            int pos = sDateTime.indexOf(";");
            if (pos >= 0)
            {
                sTime = sDateTime.substring(pos + 1);
                sDate = sDateTime.substring(0, pos);
            }

            FDate date = new FDate(sDate);
            FTime time = new FTime(sTime);
            double jd = AstronomyMaths.gregorianToJulian(date.getDay(), date.getMonth(), date.getYear());
            double t = time.getDecimalHour();
            jd = jd + (delta_hour + t + chartEvent.getTime()) / 24.0;
            FTime time2 = new FTime(AstronomyMaths.modulo(delta_hour + t, 24.0));
            sTime = time2.getTime();
            FDate newDate = new FDate(AstronomyMaths.julianToGregorian(jd));
            chartElements.setTransitsDate(newDate.getDate() + ";" + sTime);
            FTime time3 = new FTime(AstronomyMaths.modulo(delta_hour + t + chartEvent.getTime(), 24.0));
            sTime = time3.getTime();
            lblNewDate.setText(newDate.getDate() + "   " + sTime);
            //bModifTransitDate = true;
            mnuPermute.setSelected(false);
            header = modifHeader(chartEvent.getHeader());
        }
        else
        {
            mnuPermute.setSelected(false);
            mnuOtherSide.setSelected(false);

            //getting the new date and hour
            if (delta_hour != 0.0)
            {
                chartEvent.addTime2CTimeH(delta_hour);
                lblNewDate.setText(chartEvent.getDateTime());
            }
            if (chartElements.getViewStars() || chartKind == ChartKind.local)
            {
                reCalcStars();
            }
        }
        events.set(0, chartEvent);
        Astrology astrology = new Astrology(chartElements, chartEvent, chartKind, starLoginManager);
        if (chartKind != ChartKind.transit)
        {
            header = modifHeader(chartEvent.getHeader());
        }
        if (!lblNewDate.getText().equals(""))
        {
            header = header.concat("\r\n").concat(lblNewDate.getText());
        }
        positions = chartElements.getChartCoords();
        pos1 = (AllCoord) positions.get(0);
        if (positions.size() > 1)
        {
            pos2 = (AllCoord) positions.get(1);
        }
        displayChart();
    }

    private void harmonicProcessing()
    {
        String svalue = txtHarmonicNB.getText();
        if (svalue.equals("") || svalue.equals("0"))
        {
            return;
        }
        int harmoVal = Integer.parseInt(svalue);

        //calcul des harmoniques des positions initiales
        sum_harmo *= harmoVal;

        pos1 = Astrology.harmonicCalculation(harmoVal, pos1);
        pos2 = Astrology.harmonicCalculation(harmoVal, pos2);

        if (chartElements.getViewBarycenter())
        {
            Astrology.barycenterProcessing(chartElements, pos1);
        }
        header = modifHeader(chartEvent.getHeader());
        if (!lblNewDate.getText().equals(""))
        {
            header = header.concat("\r\n").concat(lblNewDate.getText());
        }
        displayChart();
    }

    private String modifHeader(String header)
    {
        if (sum_harmo > 1)
        {
            if (chartKind == ChartKind.composite)
            {
                header = header + bundle.getString("Harmonic") + " " + sum_harmo;
            }
            else
            {
                header = header + "\r\n" + bundle.getString("Harmonic") + " " + sum_harmo;
            }
        }

        if ((chartKind == ChartKind.transit) && (!lblNewDate.getText().equals("")))
        {
            String strDate = bundle.getString("Date_") + " ";
            int pos = header.indexOf(strDate);
            int pos2b = header.indexOf("\r\n", pos + 1);
            String str;
            if (pos2b < 0)
            {
                str = header.substring(0, pos) + strDate + lblNewDate.getText();
            }
            else
            {
                str = header.substring(0, pos) + strDate + lblNewDate.getText() + header.substring(pos2b);
            }
            header = str;
        }

        if (mnuPermute.isSelected())
        {
            header = header + "\r\n" + bundle.getString("PermutedCharts");
        }

        if (mnuOtherSide.isSelected() && chartKind == ChartKind.local)
        {
            header = header + "\r\n" + bundle.getString("OtherSide");
        }

        if (mnuReverseHouses.isSelected())
        {
            header = header + "\r\n" + bundle.getString("ReverseHouses");
        }

        if ((chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.synastry) || (chartKind == ChartKind.transit))
        {
            switch (tableau_flag)
            {
                case Astrology.POS_1:
                    header = header + "\r\n" + bundle.getString("AspectsInnerChart");
                    break;
                case Astrology.POS_2:
                    header = header + "\r\n" + bundle.getString("AspectsOuterChart");
                    break;
                case Astrology.POS_1_2:
                    header = header + "\r\n" + bundle.getString("AspectsInnerOuter");
                    break;
                case Astrology.POS_2_1:
                    header = header + "\r\n" + bundle.getString("AspectsOuterInner");
                    break;
                default:
                    break;
            }
        }
        if (chartKind == ChartKind.synastry)
        {
            header = header.replaceFirst("\r\n\r\n", "\r\n");
        }
        chartElements.setChartHeader(header);

        return header;
    }

    /*private void interpretation()
     {
     switch (chartKind)
     {
     case ChartKind.seed : break; //displayHelp(autres.HELP_ENUM.HELP_);break;
     case ChartKind.projective : break;  //actionShakti();break;
     default : break; // actionInterp();
     }
     }*/
    private void reverseHouses()
    {
        header = modifHeader(chartEvent.getHeader());
        displayChart();
    }

    private void otherSide()
    {
        dblAngle = 0.0;
        header = modifHeader(chartEvent.getHeader());
        reCalcStars();
    }

    private void reCalcStars()
    {
        StarsCalc starsCalc = new StarsCalc(stars);
        starsCalc.starsPosition(chartKind, chartElements.getLimitMag(), mnuOtherSide.isSelected(), chartElements);
        nom_etoile = starsCalc.getNames();
        magnitude = starsCalc.getMagnitudes();
        azimut = starsCalc.getAzimuts();
        hauteur = starsCalc.getAltitudes();
        long_star = starsCalc.getLongitudes();
        couleur = starsCalc.getColors();
        displayChart();
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) des astres dans la carte du ciel
    //=========================================================================
    private void chartPositions(Graphics2D g2, double angle_phase)
    {
        //indices
        int i;
        int j;
        //auxiliary string
        String strS;
        //indicateur de position planetaire � droite ou � gauche de la carte
        int indice;
        //auxiliary variable
        int x;
        int y;
        int p;
        int x1;
        int y1;
        int x2;
        int y2;
        int b;
        int aux1;
        int aux2;
        //numero de l'astre considere avant tri
        int numero_astre[] = new int[Planets.Chiron + 1];
        //numero de l'astre considere apres tri
        int num_astre[] = new int[Planets.Chiron + 1];
        //position angulaire des astres consideres, non encore tries
        double angle_[] = new double[Planets.Chiron + 1];
        //position angulaire des astres consideres
        double angle_astre[] = new double[Planets.Chiron + 1];
        //position angulaire de l'extremite du trait d'un astre (coordonnee 1)
        double angle_modifie[] = new double[Planets.Chiron + 1];
        //dernier astre pris en compte
        int last_astre;
        //facteurs correctifs
        double fact1;
        double fact2;
        int curX;
        int curY;
        double coord1[] = new double[Planets.getLast()];
        int stringWidth;
        int stringHeight;
        double ax;
        int old_currentX;
        int old_currentY;
        //=========================================================================

        //initializations
        b = (int) ((double) largeRadius + 57.0 * zoom);
        fact1 = 1.1499999999999999;
        fact2 = 0.94999999999999996;
        j = 0;

        for (i = 0; i <= Planets.Chiron; i++)
        {
            angle_[i] = 0;
            angle_astre[i] = 0;
            angle_modifie[i] = 0;
            num_astre[i] = 0;
            numero_astre[i] = 0;
        }

        for (i = 0; i < Planets.getLast(); i++)
        {
            coord1[i] = ((Coord) pos1.get(i)).getCoord1(chartElements.getCoordSys());
        }

        //position angulaire des astres consideres
        //----------------------------------------
        for (i = 0; i <= Planets.Chiron; i++)
        {
            if (i >= Planets.Pluto && chartKind == ChartKind.projective)
            {
                break;
            }
            if (i >= Planets.Ceres && chartElements.getViewAsteroids() == false)
            {
                break;
            }

            //si l'astre est choisi dans l'option correspondante
            if (chartElements.getShownObject(i))
            {
                //angle de l'astre dans la carte
                angle_[j] = AstronomyMaths.mod(angle_phase - coord1[i], 360.0);
                numero_astre[j] = i;
                j += 1;
            }
        }
        last_astre = j - 1;
        if (last_astre < 0)
        {
            return;
        }

        //sort the planets according to their angular position, ascending order
        //---------------------------------------------------------------------
        for (i = 0; i <= last_astre; i++)
        {
            ax = angle_[i];
            p = i;
            for (j = 0; j <= last_astre; j++)
            {
                if (angle_[j] < ax)
                {
                    ax = angle_[j];
                    p = j;
                }
            }
            angle_astre[i] = ax;
            num_astre[i] = numero_astre[p];
            angle_[p] = 360.0;
        }

        //Get the position of the line end
        //--------------------------------
        adjustPlanetsPosition(last_astre, angle_astre, angle_modifie);

        boolean flag_save;

        for (i = 0; i <= last_astre; i++)
        {
            //angle de l'astre dans la carte
            angle_astre[i] *= AstronomyMaths.PI_SUR_CENT80;

            //position of the line end
            if ((angle_modifie[i] >= 90) && (angle_modifie[i] < 270))
            {
                indice = 2;
            }
            else
            {
                indice = 1;
            }
            angle_modifie[i] *= AstronomyMaths.PI_SUR_CENT80;

            //font
            g2.setFont(new Font(FT_STARLOGIN, Font.PLAIN, planetSize));
            g2.setColor(chartElements.getPlanetColor(num_astre[i]));
            g2.setStroke(new BasicStroke((float) zoom));

            //text
            strS = "";
            if (num_astre[i] == Planets.OtherPoint)
            {
                if ((chartElements.getViewHouses() == true) || ((chartElements.getViewHouses() == false) && (chartElements.getOtherPointType() != OtherPt.part)))
                {
                    if (chartElements.getOtherPointType() == OtherPt.star)
                    {
                        strS = Astronomy.getStarName(chartElements.getOtherPointName(), stars.getRecords()) + " ";
                    }
                    else
                    {
                        strS = chartElements.getOtherPointName() + " ";
                    }
                }
            }

            if ((chartElements.getViewCoordinates() == true) && (i != Planets.OtherPoint) || ((i == Planets.OtherPoint) && ((chartElements.getViewHouses() == true) || ((chartElements.getViewHouses() == false) && (chartElements.getOtherPointType() != OtherPt.part)))))
            {
                strS = strS + Astrology.positionInSign(coord1[num_astre[i]], Astrology.NON_CALCUL, chartElements);
            }

            if (((Coord) pos1.get(num_astre[i])).getRetro() != 0)
            {
                strS = strS + " " + ((Coord) pos1.get(num_astre[i])).getRetroString(((Coord) pos1.get(num_astre[i])).getRetro());
            }

            //position du symbole, du texte et du trait repere
            //------------------------------------------------
            //extremite du trait
            old_currentY = centerY + (int) ((double) b * Math.sin(angle_modifie[i]));
            old_currentX = centerX + (int) ((double) b * Math.cos(angle_modifie[i]));

            //South Node
            if (num_astre[i] == Planets.NorthNode)
            {
                y = centerY + (int) (((double) b - 33.0 * zoom) * Math.sin(angle_astre[i]));
                x = centerX + (int) (((double) b - 33.0 * zoom) * Math.cos(angle_astre[i]));
            }
            else
            {
                y = 0;
                x = 0;
            }

            aux1 = (int) ((double) largeRadius * Math.cos(angle_astre[i]));
            aux2 = (int) ((double) largeRadius * Math.sin(angle_astre[i]));

            if ((num_astre[i] != Planets.OtherPoint) || ((num_astre[i] == Planets.OtherPoint) && (chartElements.getViewHouses() == true) || ((chartElements.getViewHouses() == false) && (chartElements.getOtherPointType() != OtherPt.part))))
            {
                x1 = aux1 + centerX;
                y1 = aux2 + centerY;
                x2 = (int) ((double) aux1 * fact1) + centerX;
                y2 = (int) ((double) aux2 * fact1) + centerY;
                g2.drawLine(x1, y1, x2, y2);
                x1 = (int) ((double) aux1 * fact1) + centerX;
                y1 = (int) ((double) aux2 * fact1) + centerY;
                x2 = old_currentX - (int) ((double) b * Math.cos(angle_astre[i]) * 0.050000000000000003);
                y2 = old_currentY - (int) ((double) b * Math.sin(angle_astre[i]) * 0.050000000000000003);
                g2.drawLine(x1, y1, x2, y2);
            }

            //trait du south node
            if (num_astre[i] == Planets.NorthNode)
            {
                x1 = (int) ((double) largeRadius * Math.cos(angle_astre[i] + AstronomyMaths.PI)) + centerX;
                y1 = (int) ((double) largeRadius * Math.sin(angle_astre[i] + AstronomyMaths.PI)) + centerY;
                x2 = centerX + (int) (((double) b - 33.0 * zoom) * Math.cos(angle_astre[i] + AstronomyMaths.PI) * fact2);
                y2 = centerY + (int) (((double) b - 33.0 * zoom) * Math.sin(angle_astre[i] + AstronomyMaths.PI) * fact2);
                g2.drawLine(x1, y1, x2, y2);
            }

            g2.setFont(new Font(FT_ARIAL, Font.PLAIN, characterSize));
            stringWidth = g2.getFontMetrics().stringWidth(strS + "   ");
            stringHeight = g2.getFontMetrics().getHeight();
            curX = old_currentX + (int) ((double) (1 - indice)) * stringWidth;
            curX += (int) ((double) (3 - 2 * indice) * 1.66666675 * characterSize);
            curY = old_currentY - stringHeight / 2;
            g2.drawString(strS, curX, curY);
            g2.setFont(new Font(FT_STARLOGIN, Font.PLAIN, planetSize));
            old_currentX = old_currentX + (int) ((double) (1 - indice) * 1.66666675 * planetSize);
            old_currentY = old_currentY - stringHeight / 2;
            //stringWidth = g2.getFontMetrics().stringWidth("N");
            g2.setColor(chartElements.getPlanetColor(num_astre[i]));
            getObjectSymbol(g2, num_astre[i], old_currentX, old_currentY, x, y);
        }
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) des astres de comparaison
    //(i.e. de transit ou de synastrie, par exemple) dans la carte du ciel
    //=========================================================================
    private void chartPositions2(Graphics2D g2, double angle_phase, int int_ext)
    {
        //indices
        int i;
        int j;
        int ii;
        //auxiliary string
        String strS;
        //position angulaire du premier et du second astre formant un aspect
        double angle;
        //indicateur de position planetaire � droite ou � gauche de la carte
        int indice;
        //auxiliary variable
        int x = 0;
        int y = 0;
        int x1;
        int y1;
        int x2;
        int y2;
        int b;
        //facteurs correctifs
        double fact1;
        double fact2;
        double fact3;
        double fact4;
        double fact5;
        double fact6;
        double fact7;
        int curX;
        int curY;
        double coord1[] = new double[Planets.getLast()];
        double coord2[] = new double[Planets.getLast()];
        int stringWidth;
        int stringHeight;
        int style = Font.PLAIN;
        double bb = 0.0;
        int old_currentX;
        int old_currentY;
        //=========================================================================

        if (int_ext == EXTERIEUR)
        {
            b = largeRadius + (int) (133.0 * zoom);
        }
        else
        {
            b = largeRadius;
        }
        fact1 = 0.84999999999999998;
        fact2 = 0.97499999999999998;
        fact3 = 0.82499999999999996;
        fact4 = (fact3 + fact2) / 2.0;
        fact5 = (1.5 - 1.3999999999999999) / 2.0;
        fact6 = (1.5 - 1.3875) / 2.0;
        fact7 = 1.0305;

        for (i = 0; i < Planets.getLast(); i++)
        {
            if ((chartElements.getShownObject(i) && i < Planets.AS) || i >= Planets.AS)
            {
                coord1[i] = ((Coord) pos1.get(i)).getCoord1(chartElements.getCoordSys());
                coord2[i] = ((Coord) pos2.get(i)).getCoord1(chartElements.getCoordSys());
            }
        }

        if ((int_ext == EXTERIEUR) && (((chartKind != ChartKind.normal) && (chartKind != ChartKind.harmonic) && (chartKind != ChartKind.seed) && (chartKind != ChartKind.composite) && (chartKind != ChartKind.free))) || (int_ext == INTERIEUR))
        {
            //dernier astre considere en cas de cycles symboliques ou non
            if (chartKind == ChartKind.projective)
            {
                j = Planets.Neptune;
            }
            else
            {
                j = Planets.MC;
            }

            //pour chaque astre considere
            for (i = 0; i <= j; i++)
            {
                ii = i;

                if (((ii < Planets.Ceres || ii > Planets.Chiron) && chartElements.getViewAsteroids() == false) || chartElements.getViewAsteroids() == true)
                {
                    //si l'astre est retenu dans les options
                    if ((chartElements.getShownObject(ii)) || (ii >= Planets.AS))
                    {
                        //angle de l'astre dans la carte
                        if (int_ext == EXTERIEUR)
                        {
                            angle = angle_phase - coord2[ii];
                        }
                        else
                        {
                            angle = angle_phase - coord1[ii];
                        }

                        if ((AstronomyMaths.mod(angle, 360.0) >= 90.0) && (AstronomyMaths.mod(angle, 360.0) < 270.0))
                        {
                            indice = 2;
                        }
                        else
                        {
                            indice = 1;
                        }
                        angle *= AstronomyMaths.PI_SUR_CENT80;

                        //font
                        if (int_ext == EXTERIEUR)
                        {
                            style = Font.ITALIC;
                        }
                        g2.setFont(new Font(FT_STARLOGIN, style, planetSize));
                        g2.setColor(chartElements.getPlanetColor(ii));

                        //text
                        strS = "";
                        if (ii == Planets.OtherPoint)
                        {
                            if ((chartElements.getViewHouses() == true) || ((chartElements.getViewHouses() == false) && (chartElements.getOtherPointType() != OtherPt.part)))
                            {
                                if (chartElements.getOtherPointType() != OtherPt.star)
                                {
                                    strS = " " + chartElements.getOtherPointName() + " ";
                                }
                                else
                                {
                                    strS = " " + Astronomy.getStarName(chartElements.getOtherPointName(), stars.getRecords()) + " ";
                                }
                            }
                        }

                        if (((ii != Planets.OtherPoint) || ((ii == Planets.OtherPoint) && ((chartElements.getViewHouses() == true) || ((chartElements.getViewHouses() == false) && (chartElements.getOtherPointType() != OtherPt.part))))) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.cycle))
                        {
                            if ((chartElements.getViewCoordinates() == true))
                            {
                                if (int_ext == INTERIEUR)
                                {
                                    strS = strS + Astrology.positionInSign(coord1[ii], Astrology.NON_CALCUL, chartElements);
                                    if ((ii < Planets.AS) && (((Coord) pos1.get(ii)).getRetro() != 0))
                                    {
                                        strS = strS + " " + ((Coord) pos1.get(ii)).getRetroString(((Coord) pos1.get(ii)).getRetro());
                                    }
                                }
                                else
                                {
                                    strS = strS + Astrology.positionInSign(coord2[ii], Astrology.NON_CALCUL, chartElements);
                                    if ((chartKind == ChartKind.synastry) || (chartKind == ChartKind.transit) || (chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.transit) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir))
                                    {
                                        if ((ii < Planets.AS) && (((Coord) pos2.get(ii)).getRetro() != 0))
                                        {
                                            strS = strS + " " + ((Coord) pos2.get(ii)).getRetroString(((Coord) pos2.get(ii)).getRetro());
                                        }
                                    }
                                }
                            }

                            //position du symbole, du texte et du trait repere
                            //------------------------------------------------
                            //extremite du trait
                            if (int_ext == INTERIEUR)
                            {
                                bb = (double) b + (double) (int) (4.667 * (AstronomyMaths.mod(ii, Planets.Lilith) + 6.0) * zoom);
                                old_currentY = centerY + (int) (bb * Math.sin(angle));
                                old_currentX = centerX + (int) (bb * Math.cos(angle));
                            }
                            else
                            {
                                old_currentY = centerY + (int) ((double) b * Math.sin(angle));
                                old_currentX = centerX + (int) ((double) b * Math.cos(angle));
                            }

                            //pour le South Node
                            if (ii == Planets.NorthNode)
                            {
                                y = old_currentY;
                                x = old_currentX;
                            }

                            if (ii < Planets.AS)
                            {
                                if (int_ext == INTERIEUR)
                                {
                                    x1 = (int) ((double) b * Math.cos(angle)) + centerX;
                                    y1 = (int) ((double) b * Math.sin(angle)) + centerY;
                                    x2 = (int) (bb * Math.cos(angle)) + centerX;
                                    y2 = (int) (bb * Math.sin(angle)) + centerY;
                                }
                                else
                                {
                                    x1 = (int) ((double) b * fact1 * Math.cos(angle)) + centerX;
                                    y1 = (int) ((double) b * fact1 * Math.sin(angle)) + centerY;
                                    x2 = (int) ((double) b * fact2 * Math.cos(angle)) + centerX;
                                    y2 = (int) ((double) b * fact2 * Math.sin(angle)) + centerY;
                                }
                                g2.drawLine(x1, y1, x2, y2);
                            }

                            //trait du south node
                            if (ii == Planets.NorthNode)
                            {
                                if (int_ext == INTERIEUR)
                                {
                                    x1 = (int) (bb * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                    y1 = (int) (bb * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                    x2 = (int) ((bb - 33.0 * zoom) * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                    y2 = (int) ((bb - 33.0 * zoom) * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                }
                                else
                                {
                                    x1 = (int) ((double) b * fact3 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                    y1 = (int) ((double) b * fact3 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                    x2 = (int) ((double) b * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                    y2 = (int) ((double) b * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                }
                                g2.drawLine(x1, y1, x2, y2);
                            }

                            if (((chartKind == ChartKind.synastry) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir)) && (ii >= Planets.AS) && (chartElements.getViewHouses() == true) && (int_ext == EXTERIEUR))
                            {
                                //Ascendant
                                if (ii == Planets.AS)
                                {
                                    x1 = (int) ((double) b * fact3 * Math.cos(angle)) + centerX;
                                    y1 = (int) ((double) b * fact3 * Math.sin(angle)) + centerY;
                                    x2 = (int) ((double) b * Math.cos(angle)) + centerX;
                                    y2 = (int) ((double) b * Math.sin(angle)) + centerY;
                                    g2.drawLine(x1, y1, x2, y2);
                                    x1 = (int) ((double) b * fact4 * Math.cos(angle - 0.035)) + centerX;
                                    y1 = (int) ((double) b * fact4 * Math.sin(angle - 0.035)) + centerY;
                                    x2 = (int) ((double) b * Math.cos(angle)) + centerX;
                                    y2 = (int) ((double) b * Math.sin(angle)) + centerY;
                                    g2.drawLine(x1, y1, x2, y2);
                                    x1 = (int) ((double) b * fact4 * Math.cos(angle + 0.035)) + centerX;
                                    y1 = (int) ((double) b * fact4 * Math.sin(angle + 0.035)) + centerY;
                                    x2 = (int) ((double) b * Math.cos(angle)) + centerX;
                                    y2 = (int) ((double) b * Math.sin(angle)) + centerY;
                                    g2.drawLine(x1, y1, x2, y2);
                                }

                                //Milieu du Ciel
                                if (ii == Planets.MC)
                                {
                                    x1 = (int) ((double) b * fact3 * Math.cos(angle)) + centerX;
                                    y1 = (int) ((double) b * fact3 * Math.sin(angle)) + centerY;
                                    x2 = (int) ((double) b * Math.cos(angle)) + centerX;
                                    y2 = (int) ((double) b * Math.sin(angle)) + centerY;
                                    g2.drawLine(x1, y1, x2, y2);
                                    x1 = (int) ((double) b * fact7 * Math.cos(angle)) + centerX;
                                    y1 = (int) ((double) b * fact7 * Math.sin(angle)) + centerY;
                                    g2.drawOval(x1 - (int) ((double) largeRadius * fact6), y1 - (int) ((double) largeRadius * fact6), (int) ((double) largeRadius * fact6 * 2.0), (int) ((double) largeRadius * fact6 * 2.0));
                                }
                            }

                            if ((ii < Planets.AS) || (((chartKind == ChartKind.synastry) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir)) && (ii >= Planets.AS) && (chartElements.getViewHouses() == true) && (int_ext == EXTERIEUR)))
                            {
                                g2.setFont(new Font(FT_ARIAL, style, characterSize));
                                stringWidth = g2.getFontMetrics().stringWidth(strS + "   ");
                                stringHeight = g2.getFontMetrics().getHeight();
                                curX = old_currentX + (int) ((double) (1 - indice)) * (stringWidth);
                                curX += (int) ((double) (3 - 2 * indice) * 1.66666675) * characterSize;
                                curY = old_currentY - stringHeight / 2;
                                g2.drawString(strS, curX, curY);
                                g2.setFont(new Font(FT_STARLOGIN, style, planetSize));
                                old_currentX = old_currentX + (int) ((double) (1 - indice) * 1.66666675) * planetSize;
                                old_currentY = old_currentY - stringHeight / 2;
                                //stringWidth = g2.getFontMetrics().stringWidth("N");
                                g2.setColor(chartElements.getPlanetColor(ii));
                                getObjectSymbol(g2, ii, old_currentX, old_currentY, x, y);
                            }
                        }
                    }
                }
            }
        }
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) des aspects dans la carte du ciel
    //=========================================================================
    private void chartAspects(Graphics2D g2, double angle_phase)
    {
        //indices
        int i;
        int j;
        //auxiliary string
        String strS;
        //position angulaire du premier et du second astre formant un aspect
        double angle = 0;
        double angle2 = 0;
        //valeur d'aspect entre deux astres
        String aspect;
        //valeur de la couleur d'un aspect
        Color couleur_type_aspect;
        //coordonnees des extremites d'une ligne
        int x1;
        int y1;
        int x2;
        int y2;
        int curX;
        int curY;
        double coord1[] = new double[Planets.getLast()];
        double coord2[] = new double[Planets.getLast()];
        //=========================================================================

        for (i = 0; i < Planets.getLast(); i++)
        {
            coord1[i] = ((Coord) pos1.get(i)).getCoord1(chartElements.getCoordSys());
            coord2[i] = ((Coord) pos2.get(i)).getCoord1(chartElements.getCoordSys());
        }

        AspectsCalc aspectsCalc = new AspectsCalc();
        aspectsCalc.aspectsCalculation(tableau_flag, pos1, pos2, chartElements, chartKind);
        aspectKinds = aspectsCalc.getAspectsKinds();
        aspectValues = aspectsCalc.getAspectsValues();
        relativeAspects = aspectsCalc.getRelativeAspects();
        spire = aspectsCalc.getSpires();
        if ((chartKind != ChartKind.local) && (chartElements.getCoordSys() != CoordSystem.Local))
        {
            //adaptation de la derniere valeur de l'indice i au cas traite
            for (i = 0; i <= Planets.MC; i++)
            {
                //adaptation de la premiere valeur de l'indice j au cas traite
                if (((i < Planets.Ceres || i > Planets.Chiron) && chartElements.getViewAsteroids() == false) || chartElements.getViewAsteroids() == true)
                {
                    for (j = 0; j <= Planets.MC; j++)
                    {
                        if (((j < Planets.Ceres || j > Planets.Chiron) && chartElements.getViewAsteroids() == false) || chartElements.getViewAsteroids() == true)
                        {
                            //transcription de l'aspect en neutre, dynamique ou harmonique
                            aspect = aspectKinds[i][j];
                            couleur_type_aspect = AspectType.aspectKindColor(aspect, chartElements);

                            //symbole de l'aspect
                            if (chartElements.getSymbolAspects())
                            {
                                strS = aspect;
                            }
                            else
                            {
                                strS = "";
                            }

                            //affichage du trait representatif de l'aspect, s'il existe
                            if (!aspectKinds[i][j].equals("")
                                && ((i <= Planets.AS && j < Planets.AS && chartElements.getViewHouses() == false)
                                    || chartElements.getViewHouses() == true))
                            {
                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        angle = -(coord1[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        angle2 = -(coord1[j] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        break;

                                    case Astrology.POS_2:
                                        angle = -(coord2[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        angle2 = -(coord2[j] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        break;

                                    case Astrology.POS_1_2:
                                        angle = -(coord1[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        angle2 = -(coord2[j] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        break;

                                    case Astrology.POS_2_1:
                                        angle = -(coord2[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        angle2 = -(coord1[j] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                                        break;
                                }

                                //line width
                                if (aspect.equals(AspectType.getAspectSymbol(AspectType.Conjunction)))
                                {
                                    g2.setStroke(new BasicStroke(2 * (float) zoom));
                                }
                                else
                                {
                                    g2.setStroke(new BasicStroke(0.5f * (float) zoom));
                                }

                                g2.setColor(couleur_type_aspect);
                                g2.setFont(new Font(FT_STARLOGIN, Font.PLAIN, planetSize));

                                //draw the line
                                x1 = (int) ((double) smallRadius * Math.cos(angle)) + centerX;
                                y1 = (int) ((double) smallRadius * Math.sin(angle)) + centerY;
                                x2 = (int) ((double) smallRadius * Math.cos(angle2)) + centerX;
                                y2 = (int) ((double) smallRadius * Math.sin(angle2)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);

                                if (!strS.equals(""))
                                {
                                    if (aspect.equals(AspectType.getAspectSymbol(AspectType.Opposition)))
                                    {
                                        curX = (int) ((double) smallRadius * (Math.cos(angle) + 2 * Math.cos(angle2)) / 3.0 + centerX);
                                        curY = (int) ((double) smallRadius * (Math.sin(angle) + 2 * Math.sin(angle2)) / 3.0 + centerY);
                                    }
                                    else
                                    {
                                        curX = (int) ((double) smallRadius * (Math.cos(angle) + Math.cos(angle2)) / 2.0 + centerX);
                                        curY = (int) ((double) smallRadius * (Math.sin(angle) + Math.sin(angle2)) / 2.0 + centerY);
                                    }
                                    g2.drawString(strS, curX, curY);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    //=========================================================================
    //impression du resume des aspects non relatifs
    //=========================================================================
    private void aspectsSummary(Graphics2D g2)
    {
        //indices
        int i;
        int j;
        //auxiliary string
        String strS;
        //valeur d'aspect entre deux astres
        String aspect;
        //vertical position of the apsects area
        int deb_area_aspects;
        //height of a line in the area
        int line_height;
        //width of the character having the maximum one
        int max_char_size;
        int curX;
        int curY;
        int marge = (int) (leftMargin * zoom) + centerX - chartW / 2;
        int stringHeight;
        int stringWidth;
        int deb_area_aspects2;

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        double multi = rect.getWidth() / 1024;

        g2.setFont(new Font(FT_STARLOGIN, Font.PLAIN, (int) ((double) 5 * zoom * multi)));
        stringHeight = g2.getFontMetrics().getHeight();
        g2.setStroke(new BasicStroke(0.25f * (float) (zoom * multi)));
        line_height = stringHeight - 2;
        deb_area_aspects = centerY + chartH / 2 - (int) (((double) line_height + 0.5) * (Planets.MC + 3)) - (int) ((double) topMargin * 2.0 * zoom * multi);
        stringWidth = g2.getFontMetrics().stringWidth("Y"); //MC character in StarLogin font
        max_char_size = stringWidth;
        deb_area_aspects2 = deb_area_aspects + (int) (0.80 * (double) stringHeight);

        if ((chartKind != ChartKind.local) && (chartElements.getCoordSys() != CoordSystem.Local))
        {
            for (i = -1; i <= Planets.MC; i++)
            {
                if (i == -1)
                {
                    for (j = 0; j <= Planets.MC; j++)
                    {
                        curX = marge + max_char_size * (j + 1) + (int) (zoom * multi);
                        curY = deb_area_aspects2;
                        g2.setColor(chartElements.getPlanetColor(j));
                        g2.drawString(Planets.getPlanetSymbol(j), curX, curY);

                        //vertical line
                        g2.setColor(Color.BLACK);
                        g2.drawLine(marge + max_char_size * (j + 1), deb_area_aspects, marge + max_char_size * (j + 1), deb_area_aspects + (Planets.MC + 2) * line_height);

                        //horizontal line
                        g2.drawLine(marge, deb_area_aspects + line_height * (j + 1), marge - 2 + max_char_size * (Planets.MC + 2), deb_area_aspects + line_height * (j + 1));
                    }

                }
                else
                {
                    for (j = -1; j < Planets.MC; j++)
                    {
                        if (j == -1)
                        {
                            curX = marge + (int) (zoom * multi);
                            curY = deb_area_aspects2 + line_height * (i + 1);
                            g2.setColor(chartElements.getPlanetColor(i));
                            g2.drawString(Planets.getPlanetSymbol(i), curX, curY);

                        }
                        else
                        {
                            //transcription de l'aspect en neutre, dynamique ou harmonique
                            aspect = aspectKinds[i][j];

                            //symbole de l'aspect
                            strS = aspect;
                            curY = deb_area_aspects2 + line_height * (j + 1);
                            curX = marge + max_char_size * (i + 1) + (int) (zoom * multi);
                            g2.setColor(AspectType.aspectKindColor(aspect, chartElements));
                            g2.drawString(strS, curX, curY);
                        }
                    }
                }
            }
        }
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) des signes dans la carte du ciel
    //=========================================================================
    private void chartSigns(Graphics2D g2, double angle_phase)
    {
        //numero du signe
        int signe;
        //distance par rapport au centre du zodiaque
        int rayon;
        //position angulaire des signes
        double angle;
        int curX;
        int curY;
        int old_currentX;
        int old_currentY;
        int stringHeight;
        int stringWidth;
        //=========================================================================

        if ((chartElements.getCoordSys() != CoordSystem.Equatorial) && (chartKind != ChartKind.local) && (chartElements.getCoordSys() != CoordSystem.Local))
        {
            rayon = (smallRadius + largeRadius) / 2;
            if (chartElements.getCoordSys() == CoordSystem.Domitudes)
            {
                g2.setFont(new Font(FT_ARIAL, Font.BOLD, (int) (chartElements.getSignSize() * zoom)));
            }
            else
            {
                g2.setFont(new Font(FT_STARLOGIN, Font.BOLD, (int) (chartElements.getSignSize() * zoom)));
            }
            g2.setColor(Color.WHITE);

            String strS;
            for (signe = 0; signe < 12; signe++)
            {
                if (chartElements.getCoordSys() == CoordSystem.Domitudes)
                {
                    if (mnuReverseHouses.isSelected())
                    {
                        strS = bundle.getString("h_") + (12 - signe);
                    }
                    else
                    {
                        strS = bundle.getString("h_") + (signe + 1);
                    }
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                }
                else
                {
                    strS = "";
                    stringWidth = g2.getFontMetrics().stringWidth(Signs.getSignSymbol(signe));
                }
                stringHeight = g2.getFontMetrics().getHeight();
                angle = -(15.0 + 30.0 * (double) (signe) - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                old_currentX = centerX + (int) ((double) rayon * Math.cos(angle)) - stringWidth / 2;
                old_currentY = centerY + (int) ((double) rayon * Math.sin(angle)) + stringHeight / 3;

                if ((g2.getFont().getSize() >= 18) && chartElements.getViewShadedLines() == false)
                {
                    //affichage en simili-relief
                    g2.setColor(Color.LIGHT_GRAY);
                    curX = old_currentX;
                    curY = old_currentY;
                    if (chartElements.getCoordSys() == CoordSystem.Domitudes)
                    {
                        g2.drawString(strS, curX, curY);
                    }
                    else
                    {
                        g2.drawString(Signs.getSignSymbol(signe), curX, curY);
                    }

                    g2.setColor(Color.DARK_GRAY);
                    curX = old_currentX + Math.min((int) (2.0 * zoom), 2);
                    curY = old_currentY + Math.min((int) (2.0 * zoom), 2);
                    if (chartElements.getCoordSys() == CoordSystem.Domitudes)
                    {
                        g2.drawString(strS, curX, curY);
                    }
                    else
                    {
                        g2.drawString(Signs.getSignSymbol(signe), curX, curY);
                    }
                }

                if (chartElements.getViewShadedLines() == true)
                {
                    g2.setColor(Color.WHITE);
                }
                else
                {
                    int k = (int) (AstronomyMaths.modulo((double) (signe), 4.0) + 0.00001);
                    if (k == 0)
                    {
                        g2.setColor(chartElements.getFireColor());
                    }
                    else if (k == 1)
                    {
                        g2.setColor(chartElements.getEarthColor());
                    }
                    else if (k == 2)
                    {
                        g2.setColor(chartElements.getAirColor());
                    }
                    else if (k == 3)
                    {
                        g2.setColor(chartElements.getWaterColor());
                    }
                }
                curX = old_currentX + Math.min((int) (zoom), 1);
                curY = old_currentY + Math.min((int) (zoom), 1);
                if (chartElements.getCoordSys() == CoordSystem.Domitudes)
                {
                    g2.drawString(strS, curX, curY);
                }
                else
                {
                    g2.drawString(Signs.getSignSymbol(signe), curX, curY);
                }
            }
        }
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) des cuspides dans la carte du ciel
    //=========================================================================
    private void chartCusps(Graphics2D g2, double angle_phase)
    {
        double coordonnee1m[] = new double[Cusp.Midheaven + 1];
        //indice
        int i;
        //auxiliary string
        String strS = "";
        //position angulaire des cuspides dans le zodiaque
        double angle;
        //coordonnees des deux points d'une ligne
        int x1;
        int y1;
        int x2;
        int y2;
        //facteur correctif
        double fact1;
        double fact2;
        double fact3;
        double fact4;
        double fact5;
        double fact6;
        int curX;
        int curY;
        int old_currentX;
        int old_currentY;
        int stringHeight;
        int stringWidth;
        //=========================================================================

        //initializations
        fact1 = 1.1000000000000001;
        fact2 = 1.3875;
        fact3 = 1.5;
        fact4 = (fact3 + fact2) / 2.0;
        fact5 = 1.03;
        fact6 = (fact3 - fact2) / 2.0;

        if (chartElements.getCoordSys() != CoordSystem.Domitudes)
        {
            for (i = 0; i <= Cusp.House12; i++)
            {
                int ii = i + Planets.MC + 1;
                coordonnee1m[i] = ((Coord) pos1.get(ii)).getCoord1(chartElements.getCoordSys());
            }
            coordonnee1m[Cusp.Ascendant] = ((Coord) pos1.get(Planets.AS)).getCoord1(chartElements.getCoordSys());
            coordonnee1m[Cusp.Midheaven] = ((Coord) pos1.get(Planets.MC)).getCoord1(chartElements.getCoordSys());
        }

        //case of domitudes : the signs (separated by 30 degrees on the ecliptic) become the cusps
        else
        {
            double as = ((Coord) pos1.get(Planets.AS)).getTropicGeoLong();

            for (i = 0; i <= Signs.Sign12; i++)
            {
                //calculate the domitude of each sign
                Coord c = new Coord();
                c.setGeoLat(0.0);
                double lng = 30.0 * (double) i;
                c.setTropicGeoLong(lng);
                double delta = AstronomyMaths.modulo(lng - as, 360.0);
                ArrayList events0 = chartElements.getChartEvents();
                ChartEvent ev = (ChartEvent) events0.get(0);
                double obliquity = ev.getObliquity();
                double ra = c.raFromEcliptic(obliquity);
                c.setRA(ra);
                double decl = c.declFromEcliptic(obliquity);
                c.setDecl(decl);
                coordonnee1m[i] = c.altFromEquatorial(0.0, ev.getLST());
                if (delta >= 0.0 && delta < 90.0)
                {
                    coordonnee1m[i] = -coordonnee1m[i];
                }
                else if (delta >= 90.0 && delta < 270.0)

                {
                    coordonnee1m[i] = 180 + coordonnee1m[i];
                }
                else
                {
                    coordonnee1m[i] = 360 - coordonnee1m[i];
                }
            }
        }

        if ((chartKind != ChartKind.local) && (chartElements.getViewHouses() == true))
        {
            if (chartElements.getCoordSys() == CoordSystem.Domitudes)
            {
                g2.setFont(new Font(FT_STARLOGIN, Font.PLAIN, characterSize));
            }
            else
            {
                g2.setFont(new Font(FT_ARIAL, Font.PLAIN, characterSize));
            }
            g2.setColor(chartElements.getCuspsColor());
            stringHeight = g2.getFontMetrics().getHeight();

            if (chartElements.getCoordSys() == CoordSystem.Domitudes)
            {
                for (i = 0; i <= Signs.Sign12; i++)
                {
                    strS = Signs.getSignSymbol(i) + " " + Astrology.positionInSign(coordonnee1m[i], Astrology.NON_CALCUL, chartElements);
                    angle = -(coordonnee1m[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    old_currentX = centerX + (int) ((double) largeRadius * fact1 * Math.cos(angle)) + ((int) AstronomyMaths.sgn(Math.cos(angle)) - 1) * stringWidth / 2;
                    old_currentY = centerY + (int) ((double) largeRadius * fact1 * Math.sin(angle)) + stringHeight / 2;

                    //Representation schematique des pointes de signes
                    curX = old_currentX;
                    curY = old_currentY;
                    g2.drawString(strS, curX, curY);

                    if ((txtHarmonicNB.getText().equals("1")) || ((chartKind != ChartKind.normal) && (chartKind != ChartKind.harmonic) && (chartKind != ChartKind.seed)))
                    {
                        g2.setStroke(new BasicStroke(2 * (float) zoom));
                        x1 = (int) ((double) largeRadius * Math.cos(angle)) + centerX;
                        y1 = (int) ((double) largeRadius * Math.sin(angle)) + centerY;
                        x2 = (int) ((double) largeRadius * fact5 * Math.cos(angle)) + centerX;
                        y2 = (int) ((double) largeRadius * fact5 * Math.sin(angle)) + centerY;
                        g2.drawLine(x1, y1, x2, y2);
                    }
                }
            }
            else
            {
                for (i = 0; i <= Cusp.Midheaven; i++)
                {
                    //denomination schematique et position des maisons
                    if (i <= Cusp.House12)
                    {
                        //les maisons ordinaires (pas tracees pour le cas de cartes harmoniques
                        if ((txtHarmonicNB.getText().equals("1")) || ((chartKind != ChartKind.normal) && (chartKind != ChartKind.harmonic) && (chartKind != ChartKind.seed)))
                        {
                            if ((i != Cusp.House1 && i != Cusp.House10) || (i == Cusp.House1 && Math.abs(coordonnee1m[i] - coordonnee1m[Cusp.Ascendant]) > AstronomyMaths.PI_SUR_CENT80) || (i == Cusp.House10 && Math.abs(coordonnee1m[i] - coordonnee1m[Cusp.Midheaven]) > AstronomyMaths.PI_SUR_CENT80))
                            {
                                strS = bundle.getString("H") + (i + 1);
                            }
                            else
                            {
                                strS = " ";
                            }
                        }

                    }
                    else
                    {
                        //Ascendant et Milieu du Ciel
                        if (i == Cusp.Ascendant)
                        {
                            strS = "AS ";
                        }
                        else
                        {
                            strS = "MC ";
                        }
                    }

                    if ((chartElements.getHousesCoords() == true) || (i == Cusp.Ascendant || i == Cusp.Midheaven))
                    {
                        if ((i != Cusp.House1 && i != Cusp.House10) || (i == Cusp.House1 && Math.abs(coordonnee1m[i] - coordonnee1m[Cusp.Ascendant]) > AstronomyMaths.PI_SUR_CENT80) || (i == Cusp.House10 && Math.abs(coordonnee1m[i] - coordonnee1m[Cusp.Midheaven]) > AstronomyMaths.PI_SUR_CENT80))
                        {
                            strS = strS + " " + Astrology.positionInSign(coordonnee1m[i], Astrology.NON_CALCUL, chartElements);
                        }
                    }
                    angle = -(coordonnee1m[i] - angle_phase) * AstronomyMaths.PI_SUR_CENT80;
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    old_currentX = centerX + (int) ((double) largeRadius * fact1 * Math.cos(angle)) + ((int) AstronomyMaths.sgn(Math.cos(angle)) - 1) * stringWidth / 2;
                    old_currentY = centerY + (int) ((double) largeRadius * fact1 * Math.sin(angle)) + stringHeight / 2;

                    //Representation schematique des pointes de maisons
                    curX = old_currentX;

                    if ((i == Cusp.Ascendant) && (chartElements.getLeftAsct()))
                    {
                        curY = old_currentY - stringHeight;
                    }
                    else
                    {
                        curY = old_currentY;
                    }
                    g2.drawString(strS, curX, curY);

                    //cas des maisons ordinaires
                    if (i <= Cusp.House12)
                    {
                        if ((txtHarmonicNB.getText().equals("1")) || ((chartKind != ChartKind.normal) && (chartKind != ChartKind.harmonic) && (chartKind != ChartKind.seed)))
                        {
                            g2.setStroke(new BasicStroke(2 * (float) zoom));
                            x1 = (int) ((double) largeRadius * Math.cos(angle)) + centerX;
                            y1 = (int) ((double) largeRadius * Math.sin(angle)) + centerY;
                            x2 = (int) ((double) largeRadius * fact5 * Math.cos(angle)) + centerX;
                            y2 = (int) ((double) largeRadius * fact5 * Math.sin(angle)) + centerY;
                            g2.drawLine(x1, y1, x2, y2);
                        }

                    }
                    //cas des maisons angulaires (AS, FC, DS et FC)
                    else
                    {
                        g2.setStroke(new BasicStroke((float) zoom));
                        if (i != Cusp.Ascendant)
                        {
                            x1 = (int) ((double) largeRadius * Math.cos(angle)) + centerX;
                            y1 = (int) ((double) largeRadius * Math.sin(angle)) + centerY;
                            x2 = (int) ((double) largeRadius * fact2 * Math.cos(angle)) + centerX;
                            y2 = (int) ((double) largeRadius * fact2 * Math.sin(angle)) + centerY;
                            g2.drawLine(x1, y1, x2, y2);
                            x1 = (int) ((double) largeRadius * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                            y1 = (int) ((double) largeRadius * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                            x2 = (int) ((double) largeRadius * fact2 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                            y2 = (int) ((double) largeRadius * fact2 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                            g2.drawLine(x1, y1, x2, y2);
                        }

                        switch (i)
                        {
                            //Schematisation de l'ascendant et du descendant
                            case Cusp.Ascendant:
                                //Ascendant
                                x1 = (int) ((double) largeRadius * Math.cos(angle)) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle)) + centerY;
                                x2 = (int) ((double) largeRadius * fact3 * Math.cos(angle)) + centerX;
                                y2 = (int) ((double) largeRadius * fact3 * Math.sin(angle)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);
                                x1 = (int) ((double) largeRadius * Math.cos(angle - 0.035) * fact2) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle - 0.035) * fact2) + centerY;
                                x2 = (int) ((double) largeRadius * fact3 * Math.cos(angle)) + centerX;
                                y2 = (int) ((double) largeRadius * fact3 * Math.sin(angle)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);
                                x1 = (int) ((double) largeRadius * Math.cos(angle + 0.035) * fact2) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle + 0.035) * fact2) + centerY;
                                x2 = (int) ((double) largeRadius * fact3 * Math.cos(angle)) + centerX;
                                y2 = (int) ((double) largeRadius * fact3 * Math.sin(angle)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);

                                //Descendant
                                x1 = (int) ((double) largeRadius * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                x2 = (int) ((double) largeRadius * fact2 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                y2 = (int) ((double) largeRadius * fact2 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);
                                x1 = (int) ((double) largeRadius * Math.cos(angle + AstronomyMaths.PI - 0.035) * fact3) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle + AstronomyMaths.PI - 0.035) * fact3) + centerY;
                                x2 = (int) ((double) largeRadius * fact2 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                y2 = (int) ((double) largeRadius * fact2 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);
                                x1 = (int) ((double) largeRadius * Math.cos(angle + AstronomyMaths.PI + 0.035) * fact3) + centerX;
                                y1 = (int) ((double) largeRadius * Math.sin(angle + AstronomyMaths.PI + 0.035) * fact3) + centerY;
                                x2 = (int) ((double) largeRadius * fact2 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                y2 = (int) ((double) largeRadius * fact2 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                g2.drawLine(x1, y1, x2, y2);
                                break;

                            case Cusp.Midheaven:
                                //IC
                                x1 = (int) ((double) largeRadius * fact4 * Math.cos(angle + AstronomyMaths.PI)) + centerX;
                                y1 = (int) ((double) largeRadius * fact4 * Math.sin(angle + AstronomyMaths.PI)) + centerY;
                                g2.drawArc((x1 - (int) ((double) largeRadius * fact6)), (y1 - (int) ((double) largeRadius * fact6)), ((int) ((double) largeRadius * fact6 * 2.0)), ((int) ((double) largeRadius * fact6 * 2.0)), 180 - (int) (AstronomyMaths.mod(angle * AstronomyMaths.CENT80_SUR_PI - 90.0, 360.0)), 180);
                                //Midheaven
                                x1 = (int) ((double) largeRadius * fact4 * Math.cos(angle)) + centerX;
                                y1 = (int) ((double) largeRadius * fact4 * Math.sin(angle)) + centerY;
                                g2.drawOval((x1 - (int) ((double) largeRadius * fact6)), (y1 - (int) ((double) largeRadius * fact6)), ((int) ((double) largeRadius * fact6 * 2.0)), ((int) ((double) largeRadius * fact6 * 2.0)));
                                break;

                            default:
                                break;
                        }
                    }
                }
            }
        }
    }

    //=========================================================================
    //qffichage du symbole des astres sur la feuille o� l'on imprime la carte
    //du Ciel of the event astrologique considere
    //input : numero_astre : numero de l'astre � afficher
    //        X            : abscisse du symbole de l'astre
    //        Y            : ordonnee du symbole
    //        XS           : abscisse du symbole de l'astre pour le south node
    //        YS           : ordonnee du symbole pour le south node
    //=========================================================================
    private void getObjectSymbol(Graphics2D g2, int numero_astre, int x, int y, int xs, int ys)
    {
        //String sChar;
        g2.drawString(Planets.getPlanetSymbol(numero_astre), x, y);

        if (numero_astre == Planets.NorthNode)
        {
            //south node
            if ((chartKind != ChartKind.local) && (chartElements.getCoordSys() != CoordSystem.Local))
            {
                int x2 = 2 * centerX - xs;
                int y2 = 2 * centerY - ys;
                g2.drawString(Planets.getPlanetSymbol(Planets.SouthNode), x2, y2);
            }
        }
    }

    private int drawHeader(Graphics2D g2, String header, int curX, int curY)
    {
        int pos = header.indexOf("\r\n");
        String str = header;
        String str2Draw;
        int y = curY;
        int stringHeight = g2.getFontMetrics().getHeight();
        while (pos >= 0)
        {
            str2Draw = str.substring(0, pos);
            str = str.substring(pos + 2);
            pos = str.indexOf("\r\n");
            g2.drawString(str2Draw, curX, y);
            y += stringHeight;
        }
        g2.drawString(str, curX, y);
        y += stringHeight;
        return y;
    }

    //=========================================================================
    //affichage ou impression (suivant l'option) de la carte du ciel
    //=========================================================================
    private void chartZodiac(Graphics2D g2)
    {
        double coord1[] = new double[Planets.getLast()];
        double coord2[] = new double[Planets.getLast()];
        //indices
        int i;
        int j;
        int x;
        int y;
        //angle entre l'ascendant et le point vernal (zero degres Belier)
        double angle_phase;
        //positions angulaires d'astres ou de points dans le zodiaque
        double angle;
        double angle2;
        int curX;
        int curY;

        //arcs in case of projective chart
        double angl1;
        double angl2;
        double ecart;

        int stringWidth;
        //=========================================================================

        //initializations
        if (chartElements == null)
        {
            return;
        }
        if (chartElements.getCoordSys() != CoordSystem.Domitudes)
        {
            mnuReverseHouses.setVisible(false);
        }
        else
        {
            mnuReverseHouses.setVisible(true);
        }

        if (chartElements.getCoordSys() == CoordSystem.HelioSidereal || chartElements.getCoordSys() == CoordSystem.Sidereal)
        {
            chartEvent.setAyanamsa(0);
        }

        for (i = 0; i < Planets.MC; i++)
        {
            coord1[i] = ((Coord) pos1.get(i)).getCoord1(chartElements.getCoordSys());
            coord2[i] = ((Coord) pos2.get(i)).getCoord1(chartElements.getCoordSys());
        }

        //Calculation of the dephasage de la carte par rapport � Belier � gauche
        if (chartElements.getLeftAsct())
        {
            angle_phase = AstronomyMaths.mod(coord1[Planets.AS] + 180.0, 360.0);
        }
        else
        {
            angle_phase = 180.0;
        }
        angle_phase = AstronomyMaths.mod(deltaAngle + angle_phase, 360.0);
        g2.setColor(Color.BLACK);

        //stars
        if (chartElements.getViewStars() == true)
        {
            localChart(g2, angle_phase);
        }

        //arcs in case of projective chart
        if (chartKind == ChartKind.projective)
        {
            for (i = Planets.Sun; i <= Planets.Neptune; i++)
            {
                int r = largeRadius + (int) ((double) (110 + 2 * i) * zoom);
                g2.setColor(chartElements.getPlanetColor(i));
                angl1 = AstronomyMaths.mod(angle_phase - coord1[i], 360.0);
                angl2 = AstronomyMaths.mod(angle_phase - coord2[i], 360.0);
                ecart = AstronomyMaths.mod(angl2 - angl1, 360.0);
                if (i < Planets.Mars && ecart > 180.0)
                {
                    ecart = AstronomyMaths.mod(360.0 - ecart, 360.0);
                }
                g2.setStroke(new BasicStroke((float) zoom));
                g2.drawArc((centerX) - r, (centerY) - r, 2 * r, 2 * r, -(int) Math.floor(angl1), -(int) Math.floor(ecart) - 1);
            }
        }

        //header of the chart
        g2.setColor(Color.BLACK);
        g2.setFont(new Font(FT_ARIAL, Font.PLAIN, (int) (9 * zoom)));
        curY = (int) (topMargin * zoom) + centerY - chartH / 2;
        curX = (int) (leftMargin * zoom) + centerX - chartW / 2;
        curY = drawHeader(g2, header, curX, curY);
        if (planetaryConfigurations != null && !planetaryConfigurations.equals(""))
        {
            g2.drawString(bundle.getString("PlanetaryConfigurations") + " :  " + planetaryConfigurations, curX, curY);
        }

        g2.setFont(new Font(FT_ARIAL, Font.PLAIN, characterSize));
        stringWidth = g2.getFontMetrics().stringWidth("N");

        //shaded colors zodiac
        if (chartElements.getViewShadedLines() == true)
        {
            double a1 = AstronomyMaths.mod(angle_phase - 30, 360.0);
            double a2 = AstronomyMaths.mod(angle_phase - 90, 360.0);
            double a3 = AstronomyMaths.mod(angle_phase - 150, 360.0);
            double a4 = AstronomyMaths.mod(angle_phase - 210, 360.0);
            double a5 = AstronomyMaths.mod(angle_phase - 270, 360.0);
            double a6 = AstronomyMaths.mod(angle_phase - 330, 360.0);
            int radius = largeRadius;
            Double pt1 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a1), centerY + (double) radius * AstronomyMaths.sinD(a1));
            Double pt2 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a2), centerY + (double) radius * AstronomyMaths.sinD(a2));
            Double pt3 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a3), centerY + (double) radius * AstronomyMaths.sinD(a3));
            Double pt4 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a4), centerY + (double) radius * AstronomyMaths.sinD(a4));
            Double pt5 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a5), centerY + (double) radius * AstronomyMaths.sinD(a5));
            Double pt6 = new Double(centerX + (double) radius * AstronomyMaths.cosD(a6), centerY + (double) radius * AstronomyMaths.sinD(a6));
            Color color1 = new Color(255, 0, 0);
            Color color2 = new Color(255, 255, 0);
            Color color3 = new Color(0, 255, 0);
            Color color4 = new Color(0, 255, 255);
            Color color5 = new Color(0, 0, 255);
            Color color6 = new Color(255, 0, 255);
            a1 = AstronomyMaths.mod(180.0 - a1, 360.0);
            a2 = AstronomyMaths.mod(180.0 - a2, 360.0);
            a3 = AstronomyMaths.mod(180.0 - a3, 360.0);
            a4 = AstronomyMaths.mod(180.0 - a4, 360.0);
            a5 = AstronomyMaths.mod(180.0 - a5, 360.0);
            a6 = AstronomyMaths.mod(180.0 - a6, 360.0);
            radius = largeRadius * 2;
            g2.setPaint(new GradientPaint(pt1, color1, pt2, color2));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a4, 60);
            g2.setPaint(new GradientPaint(pt2, color2, pt3, color3));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a5, 60);
            g2.setPaint(new GradientPaint(pt3, color3, pt4, color4));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a6, 60);
            g2.setPaint(new GradientPaint(pt4, color4, pt5, color5));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a1, 60);
            g2.setPaint(new GradientPaint(pt5, color5, pt6, color6));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a2, 60);
            g2.setPaint(new GradientPaint(pt6, color6, pt1, color1));
            g2.fillArc(centerX - largeRadius, centerY - largeRadius, radius, radius, (int) a3, 60);
            g2.setColor(Color.WHITE);
            g2.fillOval(centerX - smallRadius, centerY - smallRadius, 2 * smallRadius, 2 * smallRadius);
        }

        //signs
        chartSigns(g2, angle_phase);

        //cusps of houses
        chartCusps(g2, angle_phase);

        //coordinates of planets
        if (chartElements.getViewStraightLines() == false)
        {
            chartPositions(g2, angle_phase);
        }
        else
        {
            chartPositions2(g2, angle_phase, INTERIEUR);
        }

        //second chart (the biggest one)
        if ((chartKind != ChartKind.normal) && (chartKind != ChartKind.harmonic) && chartKind != ChartKind.free && chartKind != ChartKind.seed && chartKind != ChartKind.composite)
        {
            chartPositions2(g2, angle_phase, EXTERIEUR);
        }

        //aspects
        if (chartElements.getViewAspects() == true)
        {
            chartAspects(g2, angle_phase);
        }

        //barycenter
        if (chartElements.getViewBarycenter() == true)
        {
            rayon_bary = pos1.get(Planets.Barycenter).getRadius() * smallRadius;
            angle_bary = pos1.get(Planets.Barycenter).getTheta();

            //horizontal position
            x = centerX + (int) (rayon_bary * AstronomyMaths.cosD(angle_phase - angle_bary) * zoom);

            //vertical position
            y = centerY + (int) (rayon_bary * AstronomyMaths.sinD(angle_phase - angle_bary) * zoom);

            g2.setColor(new Color(0, 0, 100));
            g2.setStroke(new BasicStroke((float) zoom));
            g2.drawOval(x - (int) (4.0 * zoom), y - (int) (4.0 * zoom), (int) (8.0 * zoom), (int) (8.0 * zoom));
            g2.drawLine(x, y - (int) (7.0 * zoom), x, y + (int) (7.0 * zoom));
            g2.drawLine(x - (int) (7.0 * zoom), y, x + (int) (7.0 * zoom), y);
        }

        //Contellation boundaries
        if (chartElements.getViewConstellations() == true)
        {
            showConstelBoundaries(g2, chartEvent.getCTimeH(), smallRadius, angle_phase);
        }

        //display the small array for aspects
        if (chartElements.getViewAspects() == true)
        {
            aspectsSummary(g2);
        }

        //black lines
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(0.5f * (float) zoom));
        g2.drawOval(centerX - largeRadius, centerY - largeRadius, largeRadius * 2, largeRadius * 2);
        g2.drawOval(centerX - smallRadius, centerY - smallRadius, smallRadius * 2, smallRadius * 2);
        for (i = 0; i < 12; i++)
        {
            angle = -((double) i * 30.0 - angle_phase) * AstronomyMaths.PI_SUR_CENT80;

            double sr = (double) smallRadius + 1.0;
            if (i == 0)
            {
                g2.drawLine((int) (sr * Math.cos(angle)) + centerX, (int) (sr * Math.sin(angle)) + centerY, (int) ((double) largeRadius * 1.07 * Math.cos(angle)) + centerX, (int) ((double) largeRadius * 1.07 * Math.sin(angle)) + centerY);
            }
            else
            {
                g2.drawLine((int) (sr * Math.cos(angle)) + centerX, (int) (sr * Math.sin(angle)) + centerY, (int) ((double) largeRadius * Math.cos(angle)) + centerX, (int) ((double) largeRadius * Math.sin(angle)) + centerY);
            }

            for (j = 1; j <= 2; j++)
            {
                angle2 = angle + AstronomyMaths.PI / 18 * j;
                g2.drawLine((int) (sr * Math.cos(angle2)) + centerX, (int) (sr * Math.sin(angle2)) + centerY, (int) (sr * 1.1 * Math.cos(angle2)) + centerX, (int) (sr * 1.1 * Math.sin(angle2)) + centerY);
            }

            for (j = 1; j <= 3; j++)
            {
                angle2 = angle - AstronomyMaths.PI / 36 + AstronomyMaths.PI / 18.0 * j;
                g2.drawLine((int) (sr * Math.cos(angle2)) + centerX, (int) (sr * Math.sin(angle2)) + centerY, (int) (sr * 1.07 * Math.cos(angle2)) + centerX, (int) (sr * 1.07 * Math.sin(angle2)) + centerY);
            }

            for (j = 1; j <= 30; j++)
            {
                angle2 = angle + AstronomyMaths.PI_SUR_CENT80 * j;
                g2.drawLine((int) (sr * Math.cos(angle2)) + centerX, (int) (sr * Math.sin(angle2)) + centerY, (int) (sr * 1.04 * Math.cos(angle2)) + centerX, (int) (sr * 1.04 * Math.sin(angle2)) + centerY);
            }
        }
    }

    //=========================================================================
    //lngPos de l'extremite du trait de position d'un astre apres rectification
    //par rapport � la position de l'astre et de ses voisins
    //input :  last_astre    : numero du dernier des astres consideres
    //         angle_astre   : tableau de position des astres consideres
    //output : angle_modifie : tableau de position de l'extremite des traits
    //=========================================================================
    private void adjustPlanetsPosition(int last_astre, double angle_astre[], double angle_modifie[])
    {
        //ecart angulaire minimal
        final double ECART_MIN = 10.0;
        //indices
        int i;
        int k;
        //ecart angulaire
        double ecart;
        //indicateur de modification effectuee dans la boucle en cours
        boolean modif;

        //initialization
        for (i = 0; i <= last_astre; i++)
        {
            angle_modifie[i] = angle_astre[i];
        }
        k = 0;
        modif = true;

        while ((k < 16) && (modif == true))
        {
            modif = false;
            k += 1;
            //elimination des ecarts trop faibles pour les angles entre 0� et 360�
            for (i = 0; i <= last_astre; i++)
            {
                ecart = Math.abs(angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)] - angle_modifie[i]);
                ecart = Math.abs(ecart - 360 * (double) (int) (ecart / 180));

                if (ecart < ECART_MIN)
                {
                    modif = true;

                    //modification de l'angle i+1
                    angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)] = AstronomyMaths.mod(angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)] + (ECART_MIN - ecart) / 2.0, 360.0);
                    if ((angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)] >= angle_modifie[AstronomyMaths.mod(i + 2, last_astre + 1)]) && (Math.abs(angle_modifie[AstronomyMaths.mod(i + 2, last_astre + 1)] - angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)]) < ECART_MIN))
                    {
                        angle_modifie[AstronomyMaths.mod(i + 1, last_astre + 1)] = AstronomyMaths.mod(angle_modifie[AstronomyMaths.mod(i + 2, last_astre + 1)] - 0.01, 360.0);
                    }

                    //modification de l'angle i
                    angle_modifie[i] = AstronomyMaths.mod(angle_modifie[i] - (ECART_MIN - ecart) / 2, 360.0);

                    if ((angle_modifie[i] <= angle_modifie[AstronomyMaths.mod(i - 1, last_astre + 1)]) && (Math.abs(angle_modifie[AstronomyMaths.mod(i - 1, last_astre + 1)] - angle_modifie[i]) < ECART_MIN))
                    {
                        angle_modifie[i] = AstronomyMaths.mod(angle_modifie[AstronomyMaths.mod(i - 1, last_astre + 1)] + 0.01, 360.0);
                    }
                }
            }
            if (modif == false)
            {
                break;
            }
        }
    }

    //=====================================================================
    //Affichage du Ciel local au lieu of the event considere
    //=====================================================================
    private void localChart(Graphics2D g2, double angle_phase)
    {
        double c1[] = new double[Planets.getLast()];
        double c2[] = new double[Planets.getLast()];
        int i;
        int rayon_ciel = 0;
        double angle;
        int old_currentX;
        int old_currentY;
        String strS;
        //int aux;
        double rapport_projection;
        //rayon des etoiles dessinees
        int grosseur;
        //numero d 'etoile
        int star;

        //sin�(deltaAngle) et cos�(deltaAngle)
        double SinD_vue;
        double CosD_vue;

        int curX;
        int curY;
        int x;
        int y;
        int w;
        int h;
        int stringHeight;
        int stringWidth;
        //=========================================================================

        if (chartKind == ChartKind.local)
        {
            //Initialisations
            //---------------
            //valeur du zoom
            if (zoom == 0.0)
            {
                zoom = 1.0;
            }

            //angle de vue
            deltaAngle /= zoom;

            //references de la carte du ciel
            g2.setColor(Color.BLACK);
            g2.setFont(new Font(FT_ARIAL, Font.PLAIN, (int) (12 * zoom)));
            curY = (int) (topMargin * zoom) + centerY - chartH / 2;
            curX = (int) (leftMargin * zoom) + centerX - chartW / 2;
            drawHeader(g2, header, curX, curY);
            g2.setFont(new Font(FT_ARIAL, Font.BOLD, (int) (10 * zoom)));

            //rayon et centre selon vue sur l'horizon ou vers le zenith
            if (chartElements.getHorizon() == true)
            {
                rayon_ciel = hRadius;
                centerY = hcy;
            }
            else
            {
                rayon_ciel = zRadius;
                centerY = zcy;
            }

            g2.setStroke(new BasicStroke((float) zoom));

            //affichage du ciel local
            //------------------------
            SinD_vue = AstronomyMaths.sinD(deltaAngle);
            CosD_vue = AstronomyMaths.cosD(deltaAngle);

            //Cercle
            //------
            //si le soleil est leve
            if (((((Coord) pos1.get(Planets.Sun)).getAlt() > 0) && (mnuOtherSide.isSelected() == false)) || ((((Coord) pos1.get(Planets.Sun)).getAlt() <= 0) && (mnuOtherSide.isSelected() == true)))
            {
                g2.setColor(new Color(60, 160, 255));
            }

            //si le soleil est couche
            else
            {
                g2.setColor(new Color(100, 100, 100));
            }

            g2.fillOval(centerX - rayon_ciel, centerY - rayon_ciel, rayon_ciel * 2, rayon_ciel * 2);
            g2.setColor(Color.BLACK);

            //Nom des points cardinaux
            //------------------------
            if (chartElements.getHorizon() == true)
            {
                if (Math.abs(deltaAngle) <= 90)
                {
                    if (mnuOtherSide.isSelected() == false)
                    {
                        strS = bundle.getString("North");
                    }
                    else
                    {
                        strS = bundle.getString("South");
                    }
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    stringHeight = g2.getFontMetrics().getHeight();
                    curY = centerY - stringHeight;
                    curX = centerX - (int) ((double) rayon_ciel * SinD_vue) - stringWidth;
                    g2.drawString(strS, curX, curY);
                }

                if (Math.abs(deltaAngle) >= 90)
                {
                    if (mnuOtherSide.isSelected() == false)
                    {
                        strS = bundle.getString("South");
                    }
                    else
                    {
                        strS = bundle.getString("North");
                    }
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    stringHeight = g2.getFontMetrics().getHeight();
                    curY = centerY - stringHeight;
                    curX = centerX + (int) ((double) rayon_ciel * SinD_vue) - stringWidth;
                    g2.drawString(strS, curX, curY);
                }

                if (deltaAngle >= 0)
                {
                    strS = bundle.getString("East");
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    stringHeight = g2.getFontMetrics().getHeight();
                    curY = centerY - stringHeight;
                    curX = centerX + (int) ((double) rayon_ciel * CosD_vue) - stringWidth;
                    g2.drawString(strS, curX, curY);
                }

                if (deltaAngle <= 0)
                {
                    strS = bundle.getString("West");
                    stringWidth = g2.getFontMetrics().stringWidth(strS);
                    stringHeight = g2.getFontMetrics().getHeight();
                    curX = centerX - (int) ((double) rayon_ciel * CosD_vue) - stringWidth;
                    curY = centerY - stringHeight;
                    g2.drawString(strS, curX, curY);
                }

                //Meridien of the place
                //----------------
                g2.setStroke(new BasicStroke((float) zoom));
                w = 2 * (int) ((double) rayon_ciel * Math.abs(SinD_vue));
                h = 2 * rayon_ciel;
                x = centerX - w / 2;
                y = centerY - rayon_ciel;

                //si le Nord est visible
                if (Math.abs(deltaAngle) <= 90)
                {
                    if (Math.abs(deltaAngle) >= 0.01)
                    {
                        if (deltaAngle > 0)
                        {
                            g2.drawArc(x, y, w, h, -90, -90);
                        }
                        else
                        {
                            g2.drawArc(x, y, w, h, 0, -90);
                        }
                    }
                    else
                    {
                        g2.drawLine(centerX, centerY, centerX, centerY - rayon_ciel);
                    }
                }

                //sinon
                else
                {
                    if (Math.abs(deltaAngle) > 0.01)
                    {
                        if (deltaAngle > 0)
                        {
                            g2.drawArc(x, y, w, h, 0, -90);
                        }
                        else
                        {
                            g2.drawArc(x, y, w, h, -90, -90);
                        }
                    }
                    else
                    {
                        g2.drawLine(centerX, centerY, centerX, centerY - rayon_ciel);
                    }
                }
                g2.drawLine(centerX - rayon_ciel, centerY, centerX + rayon_ciel, centerY);
            }
            else
            {
                stringHeight = g2.getFontMetrics().stringWidth("N");
                curY = centerY + (int) ((double) rayon_ciel * CosD_vue) - stringHeight;
                if (mnuOtherSide.isSelected() == false)
                {
                    strS = bundle.getString("South");
                }
                else
                {
                    strS = bundle.getString("North");
                }
                stringWidth = g2.getFontMetrics().stringWidth(strS);
                stringHeight = g2.getFontMetrics().getHeight();
                curX = centerX - (int) ((double) rayon_ciel * SinD_vue) - stringWidth;
                g2.drawString(strS, curX, curY);
                curY = centerY - (int) ((double) rayon_ciel * SinD_vue) - stringHeight;
                strS = bundle.getString("East");
                stringWidth = g2.getFontMetrics().stringWidth(strS);
                curX = centerX - (int) ((double) rayon_ciel * CosD_vue) - stringWidth;
                g2.drawString(strS, curX, curY);
            }
        }

        //position des etoiles
        //--------------------
        int lngRadius;
        double fact1;
        double fact2;
        double lngH;
        double lngW;
        double longitude;
        double orientation;
        double dl;
        double aux1;
        double aux2;
        int indice;
        int x1;
        int x2;
        int y1;
        int y2;

        if (chartKind == ChartKind.local)
        {
            g2.setFont(new Font(FT_ARIAL, Font.BOLD, starsCharacterSize));

            for (star = 0; star < nom_etoile.size(); star++)
            {
                java.lang.Double az = (java.lang.Double) (azimut.get(star));
                java.lang.Double ha = (java.lang.Double) (hauteur.get(star));
                java.lang.Double longit = (java.lang.Double) (long_star.get(star));
                java.lang.Double magni = (java.lang.Double) (magnitude.get(star));
                String starName = String.valueOf(nom_etoile.get(star));
                Color col = new Color(((java.lang.Integer) (couleur.get(star))));

                //affichage de l'etoile et de son nom (grosseur fonction de la magni.doubleValue()
                if (chartElements.getHorizon() == true)
                {
                    angle = 180 + (az - deltaAngle);
                    old_currentX = centerX - (int) ((double) rayon_ciel * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha));
                    old_currentY = centerY - (int) ((double) rayon_ciel * AstronomyMaths.sinD(ha));
                }
                else
                {
                    angle = (az - deltaAngle);
                    rapport_projection = Math.sqrt(1 - Math.abs(ha) / 90.0);
                    old_currentX = centerX - (int) ((double) rayon_ciel * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha) * rapport_projection);
                    old_currentY = centerY - (int) ((double) rayon_ciel * AstronomyMaths.cosD(angle) * AstronomyMaths.cosD(ha) * rapport_projection);
                }

                if ((ha > 0) && ((chartElements.getHorizon() == false) || (AstronomyMaths.cosD(angle) <= 0)))
                {
                    g2.setStroke(new BasicStroke((float) zoom));
                    grosseur = (int) (((8.0 - magni) + 2.0) / 2.5 * zoom);
                    g2.setColor(col);
                    g2.fillOval((old_currentX - grosseur), (old_currentY - grosseur), (2 * grosseur), (2 * grosseur));
                    if (chartElements.getViewStars() == true)
                    {
                        curX = old_currentX + grosseur;
                        curY = old_currentY + grosseur;

                        if (magni <= chartElements.getLimitMag() * 0.6666667)
                        {
                            starName = Astronomy.firstPartOfStarName(starName);
                            g2.drawString(starName, curX, curY);
                        }
                    }
                }
            }
        }

        else
        {
            g2.setFont(new Font(FT_ARIAL, Font.PLAIN, characterSize));
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke((float) zoom));
            lngRadius = (int) ((double) largeRadius * 1.15);
            fact1 = 1.75;
            fact2 = 1.95;
            for (star = 0; star < nom_etoile.size(); star++)
            {
                java.lang.Double longit = (java.lang.Double) (long_star.get(star));
                java.lang.Double magni = (java.lang.Double) (magnitude.get(star));
                String starName = String.valueOf(nom_etoile.get(star));
                Color col = modifyColor(new Color(((java.lang.Integer) (couleur.get(star)))));

                //display the line
                g2.setColor(col);
                longitude = AstronomyMaths.mod(angle_phase - longit, 360.0);
                aux1 = lngRadius * AstronomyMaths.cosD(longitude);
                aux2 = lngRadius * AstronomyMaths.sinD(longitude);
                x1 = (int) (aux1 * fact1) + centerX;
                y1 = (int) (aux2 * fact1) + centerY;
                x2 = (int) (aux1 * fact2) + centerX;
                y2 = (int) (aux2 * fact2) + centerY;
                g2.drawLine(x1, y1, x2, y2);

                if ((longitude >= 90.0) && (longitude < 270.0))
                {
                    indice = 2;
                }
                else
                {
                    indice = 1;
                }

                //display the name of the star
                starName = Astronomy.firstPartOfStarName(starName);
                strS = starName + " " + new FDegree(AstronomyMaths.mod(longit, 30.0)).getShortDegree();
                stringWidth = g2.getFontMetrics().stringWidth(strS);
                stringHeight = g2.getFontMetrics().getHeight();
                curX = x2 + (1 - indice) * stringWidth;
                curY = y2 - stringHeight / 2;
                g2.drawString(strS, curX, curY);

                //display the star point
                g2.setColor(col);
                grosseur = (int) (((8.0 - magni) + 2.0) / 2.5 * zoom);
                g2.fillOval(x1 - grosseur, y1 - grosseur, 2 * grosseur, 2 * grosseur);
            }
        }

        if (chartKind == ChartKind.local)
        {
            //coordinates of the planets
            //--------------------------
            for (i = 0; i < Planets.getLast(); i++)
            {
                c1[i] = ((Coord) pos1.get(i)).getAz();
                c2[i] = ((Coord) pos1.get(i)).getAlt();
            }

            for (i = 0; i <= Planets.Chiron; i++)
            {
                if (mnuOtherSide.isSelected() == true)
                {
                    c1[i] = AstronomyMaths.mod(-c1[i] + 180, 360.0);
                    if (c1[i] > 360.0)
                    {
                        c1[i] = c1[i] - 360.0;
                        c2[i] = -c2[i];
                    }
                }

                //if the planet is selected to be seen on the chart
                if (chartElements.getShownObject(i) == true && ((i >= Planets.Ceres && chartElements.getViewAsteroids() == true) || (i < Planets.Ceres)))
                {
                    //text
                    strS = "     ";
                    if (i == Planets.OtherPoint)
                    {
                        if (chartElements.getOtherPointType() != OtherPt.star)
                        {
                            strS = strS + chartElements.getOtherPointName() + " ";
                        }
                        else
                        {
                            strS = strS + Astronomy.getStarName(chartElements.getOtherPointName(), stars.getRecords()) + " ";
                        }
                    }
                    strS = strS + " ";

                    if (chartElements.getViewCoordinates() == true)
                    {
                        //pour les astres non stellaires et les points du ciel (Lilith, North Node)
                        if (c2[i] > 0 && (i != Planets.OtherPoint || (i == Planets.OtherPoint && chartElements.getOtherPointType() != OtherPt.star)))
                        {
                            strS = strS + Astrology.positionInSign(c1[i], Astrology.NON_CALCUL, chartElements);
                        }
                    }
                    strS = strS + " " + ((Coord) pos1.get(i)).getRetroString(pos1.get(i).getRetro());

                    //position du symbole et du texte
                    if (chartElements.getHorizon() == true)
                    {
                        angle = 180.0 + (c1[i] - deltaAngle);
                        old_currentX = centerX - (int) ((double) rayon_ciel * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(c2[i]));
                        old_currentY = centerY - (int) ((double) rayon_ciel * AstronomyMaths.sinD(c2[i]));
                    }
                    else
                    {
                        angle = (c1[i] - deltaAngle);
                        rapport_projection = Math.sqrt(1.0 - Math.abs(c2[i]) / 90.0);
                        old_currentX = centerX - (int) ((double) rayon_ciel * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(c2[i]) * rapport_projection);
                        old_currentY = centerY - (int) ((double) rayon_ciel * AstronomyMaths.cosD(angle) * AstronomyMaths.cosD(c2[i]) * rapport_projection);
                    }
                    curX = old_currentX;
                    curY = old_currentY;

                    //font
                    g2.setFont(new Font(FT_ARIAL, Font.BOLD, characterSize));

                    //Planet
                    if ((c2[i] <= 0 && mnuOtherSide.isSelected() == false) || (c2[i] >= 0 && mnuOtherSide.isSelected() == true))
                    {
                        g2.setStroke(new BasicStroke((float) zoom));
                        g2.setColor(Color.WHITE);
                    }
                    else
                    {
                        g2.setStroke(new BasicStroke((float) (characterSize * zoom / 4.0)));
                        g2.setColor(chartElements.getPlanetColor(i));
                    }
                    if ((chartElements.getHorizon() == false) || (AstronomyMaths.cosD(angle) <= 0))
                    {
                        g2.drawString(" " + strS, curX, curY);
                        g2.setFont(new Font(FT_STARLOGIN, Font.BOLD, planetSize));
                        getObjectSymbol(g2, i, old_currentX, old_currentY, old_currentX, old_currentY);
                    }
                    g2.setStroke(new BasicStroke((float) zoom));
                }
            }

            //representation des constellations par des traits reliant certaines de leurs etoiles
            if (chartElements.getViewConstellations() == true)
            {
                ChartEvent chartEvent0 = (ChartEvent) chartElements.getChartEvents().get(0);
                if (mnuOtherSide.isSelected() == false)
                {
                    showConsellations(g2, rayon_ciel, deltaAngle, chartEvent0.getLST(), chartEvent0.getPlaceLat());
                    showConstelBoundariesLS(g2, rayon_ciel, deltaAngle, chartEvent0.getLST(), chartEvent0.getPlaceLat());
                }
                else
                {
                    showConsellations(g2, rayon_ciel, deltaAngle, AstronomyMaths.mod(chartEvent0.getLST() + TSL12, 24.0), -chartEvent0.getPlaceLat());
                    showConstelBoundariesLS(g2, rayon_ciel, deltaAngle, AstronomyMaths.mod(chartEvent0.getLST() + TSL12, 24.0), -chartEvent0.getPlaceLat());
                }
            }

            //Add a rectangle on the invisible part of the sky in case of horizon view
            if (chartKind == ChartKind.local)
            {
                if (chartElements.getHorizon())
                {
                    g2.setColor(skyChart.getBackground());
                    g2.fillRect((centerX - rayon_ciel), centerY + 1, 2 * rayon_ciel, rayon_ciel);
                }
            }
        }
    }

    private Color modifyColor(Color color)
    {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        r = (255 * r) / 75 - 612;
        g = (255 * g) / 75 - 612;
        b = (255 * b) / 75 - 612;
        if (r < 0)
        {
            r = 0;
        }
        if (g < 0)
        {
            g = 0;
        }
        if (b < 0)
        {
            b = 0;
        }
        return new Color(r, g, b);
    }

    //=====================================================================
    //Representation des constallations
    //=====================================================================
    private void showConsellations(Graphics2D g2, int rayon, double deltaAngle, double TSL, double latitude_lieu)
    {
        int stringHeight;
        int stringWidth;
        //constantes
        final int DERNIERE_ETOILE = 50;
        final int DERNIERE_LETTRE = 12;
        final int AUCUN_INDICE = 0;
        final int IND_LETTRE = 1;
        final int IND_NOMBRE = 2;
        final int NOM_CONSTELLATION = 0;
        //auxiliary variables
        double rr;
        double rj;
        double u1;
        double u2;
        double u3;
        //indicateur de debut de fichier
        boolean debut_fichier = true;
        //coordonnees sur la feuille (ecran ou imprimee)
        double angle = 0.0;
        double angle2;
        int old_currentX = 0;
        int old_currentY = 0;
        double rapport_projection;
        //coordonnees pour le point precedent de la constellation
        double angle_precedant = 0.0;
        int old_currentX_precedant = 0;
        int old_currentY_precedant = 0;
        //nom de la constellation consideree
        String constellation;
        //Right ascension des etoiles servant � tracer les constellations
        double ad;
        String ch_ad;
        //declinaison
        double d;
        String ch_d;
        //elements pour tracer les constellations
        String trace;
        //azimut (30 donnees par constellation au maximum;
        double Az[] = new double[DERNIERE_ETOILE + 1];
        //hauteur
        double ha[] = new double[DERNIERE_ETOILE + 1];
        //indices de az et ha issus des lettres extraites en premiere occurence de "trace"
        int ind1[] = new int[DERNIERE_LETTRE + 1];
        //indices de az et ha issus des lettres extraites en seconde occurence
        int ind2[] = new int[DERNIERE_LETTRE + 1];
        //indices de az et ha issus des numeros extraits de "trace"
        int indice_nombre;
        //dernier nombre extrait de "trace" pour une constellation donnee
        int FIN_constellation;
        //indices de ind1 et ind2
        int indice_lettre;
        //dernier non attribue (pour reperer les lettres extraites de trace) dans az et ha
        int dernier_indice_non_attribue;
        //lettre issue de trace
        char lettre;
        //type d'indice entre lettre et nombre
        int type_indice;
        //indice de tableaux
        int i;
        //Julian Day correspondant � l'annee de reference (2000.0)
        double jj_ref;
        //temps seculaire de reference
        double tps_ref;
        //date seculaire par rapport � l'annee de reference
        double date_seculaire;
        //strS auxiliary string
        String strS;
        //position in the string
        int lngPos;
        //indicateur de nouvelle constellation
        boolean nouvelle_constellation;
        //nom de la constellation traitee � la boucle precedente
        String old_constellation;
        //nom de la premiere constellation
        String premiere_constellation = "";
        //
        double aux;
        Coord c;
        int curX;
        int curY;
        //=========================================================================

        //Initialisations
        //type_indice = AUCUN_INDICE;
        FIN_constellation = AUCUN_INDICE;
        indice_nombre = AUCUN_INDICE;
        dernier_indice_non_attribue = DERNIERE_ETOILE;

        for (i = 0; i <= DERNIERE_ETOILE; i++)
        {
            Az[i] = 0;
            ha[i] = 0;
        }

        for (i = 1; i <= DERNIERE_LETTRE; i++)
        {
            ind1[i] = 0;
            ind2[i] = 0;
        }
        //nouvelle_constellation = false;
        old_constellation = "";

        g2.setFont(new Font(FT_ARIAL, Font.PLAIN, starsCharacterSize));
        g2.setStroke(new BasicStroke((float) zoom));
        g2.setColor(new Color(255, 255, 0));

        //calculs prealables
        //------------------
        //annee de reference convertie en Julian Day
        jj_ref = AstronomyMaths.gregorianToJulian(1, 1, 2000);
        //temps seculaire de reference
        tps_ref = (jj_ref - 2415020) / AstronomyMaths.DAY_PER_CENTURY;
        //temps seculaire par rapport � l'annee de reference
        date_seculaire = chartEvent.getCTimeH() - tps_ref;

        //La boucle est effectuee jusqu'au dernier enregistrement
        //-------------------------------------------------------
        ArrayList vSC = showConstel.getShowConstel();
        if (vSC == null || vSC.isEmpty())
        {
            return;
        }
        for (Object vSC1 : vSC)
        {
            ArrayList v = (ArrayList) vSC1;
            ad = java.lang.Double.parseDouble(String.valueOf(v.get(2)));
            d = java.lang.Double.parseDouble(String.valueOf(v.get(3)));
            constellation = String.valueOf(v.get(4));
            trace = String.valueOf(v.get(5));
            if (debut_fichier == true)
            {
                premiere_constellation = constellation;
            }
            //EFFET DE LA PRECESSION
            aux = date_seculaire * AstronomyMaths.PI_SUR_CENT80;
            rr = 0.640457952975 * aux;
            rj = 0.556617038814 * aux;
            u1 = Math.cos(d) * Math.sin(ad + rr);
            aux = Math.cos(d) * Math.cos(ad + rr);
            u2 = Math.cos(rj) * aux - Math.sin(rj) * Math.sin(d);
            u3 = Math.sin(rj) * aux + Math.cos(rj) * Math.sin(d);
            if (Math.abs(u3) > 0.9)
            {
                d = AstronomyMaths.acosD(Math.sqrt(u1 * u1 + u2 * u2)) * AstronomyMaths.sgn(u3);
            }
            else
            {
                d = AstronomyMaths.asinD(u3);
            }
            ad = (rr + Math.atan(u1 / u2)) * AstronomyMaths.CENT80_SUR_PI;
            if (u2 < 0)
            {
                ad = ad + 180.0;
            }
            if (ad < 0)
            {
                ad = ad + 360.0;
            }
            nouvelle_constellation = (!old_constellation.equals(constellation)) && (!constellation.equals(premiere_constellation));
            
            //affichage de la constellation precedente
            //(si l'on n'est pas en debut de fichier)
            //----------------------------------------
            if ((nouvelle_constellation == true) && (!debut_fichier))
            {
                //traits reliant les etoiles reperees par des nombres dans "trace"
                //la premiere etoile est en fait le nom de la constellation
                for (i = 0; i <= DERNIERE_ETOILE; i++)
                {
                    if (i > FIN_constellation)
                    {
                        break;
                    }

                    //sauvegarde des coordonnees d'affichage du point precedant
                    if (i > 1)
                    {
                        old_currentX_precedant = old_currentX;
                        old_currentY_precedant = old_currentY;
                        angle_precedant = angle;
                    }

                    //calcul des coordonnees d'affichage du point actuel
                    if (chartElements.getHorizon() == true)
                    {
                        angle = 180.0 + (Az[i] - deltaAngle);
                        old_currentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha[i]));
                        old_currentY = centerY - (int) ((double) rayon * AstronomyMaths.sinD(ha[i]));
                    }
                    else
                    {
                        angle = Az[i] - deltaAngle;
                        rapport_projection = Math.sqrt(1.0 - Math.abs(ha[i]) / 90.0);
                        old_currentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha[i]) * rapport_projection);
                        old_currentY = centerY - (int) ((double) rayon * AstronomyMaths.cosD(angle) * AstronomyMaths.cosD(ha[i]) * rapport_projection);
                    }

                    //affichage du nom de la constellation
                    if (i == NOM_CONSTELLATION)
                    {
                        if ((ha[i] > 0) && ((chartElements.getHorizon() == false) || (AstronomyMaths.cosD(angle) <= 0)))
                        {
                            stringWidth = g2.getFontMetrics().stringWidth(constellation);
                            curX = old_currentX - stringWidth / 2;
                            curY = old_currentY + 1;

                            if (old_constellation.equals(""))
                            {
                                g2.drawString(premiere_constellation, curX, curY);
                            }
                            else
                            {
                                g2.drawString(old_constellation, curX, curY);
                            }
                        }
                    }

                    //affichage ou impression du trait reliant le point precedant et l'actuel
                    if (i > 1)
                    {
                        showConstelLines(g2, ha[i], angle, ha[i - 1], angle_precedant, old_currentX, old_currentY, old_currentX_precedant, old_currentY_precedant, chartElements.getHorizon());
                    }
                }

                //traits reliant les etoiles reperees par des lettres dans "trace"
                for (i = 1; i <= DERNIERE_LETTRE; i++)
                {
                    if (ind1[i] == AUCUN_INDICE)
                    {
                        break;
                    }

                    //calcul des coordonnees d'affichage du premier point
                    if (chartElements.getHorizon() == true)
                    {
                        angle = 180 + (Az[ind1[i]] - deltaAngle);
                        old_currentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha[ind1[i]]));
                        old_currentY = centerY - (int) ((double) rayon * AstronomyMaths.sinD(ha[ind1[i]]));
                    }
                    else
                    {
                        angle = Az[ind1[i]] - deltaAngle;
                        rapport_projection = Math.sqrt(1 - Math.abs(ha[ind1[i]]) / 90.0);
                        old_currentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha[ind1[i]]) * rapport_projection);
                        old_currentY = centerY - (int) ((double) rayon * AstronomyMaths.cosD(angle) * AstronomyMaths.cosD(ha[ind1[i]]) * rapport_projection);
                    }

                    //calcul des coordonnees d'affichage du second point
                    if (chartElements.getHorizon() == true)
                    {
                        angle2 = 180.0 + (Az[ind2[i]] - deltaAngle);
                        old_currentX_precedant = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle2) * AstronomyMaths.cosD(ha[ind2[i]]));
                        old_currentY_precedant = centerY - (int) ((double) rayon * AstronomyMaths.sinD(ha[ind2[i]]));

                    }
                    else
                    {
                        angle2 = Az[ind2[i]] - deltaAngle;
                        rapport_projection = Math.sqrt(1 - Math.abs(ha[ind2[i]]) / 90.0);
                        old_currentX_precedant = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle2) * AstronomyMaths.cosD(ha[ind2[i]]) * rapport_projection);
                        old_currentY_precedant = centerY - (int) ((double) rayon * AstronomyMaths.cosD(angle2) * AstronomyMaths.cosD(ha[ind2[i]]) * rapport_projection);
                    }

                    //affichage ou impression du trait reliant les deux points
                    showConstelLines(g2, ha[ind1[i]], angle, ha[ind2[i]], angle2, old_currentX, old_currentY, old_currentX_precedant, old_currentY_precedant, chartElements.getHorizon());
                }
            }
            if ((nouvelle_constellation == true) && (!debut_fichier))
            {
                //reinitialisations
                //type_indice = AUCUN_INDICE;
                FIN_constellation = AUCUN_INDICE;
                indice_nombre = AUCUN_INDICE;
                dernier_indice_non_attribue = DERNIERE_ETOILE;

                for (i = 0; i <= DERNIERE_ETOILE; i++)
                {
                    Az[i] = 0;
                    ha[i] = 0;
                }

                for (i = 1; i <= DERNIERE_LETTRE; i++)
                {
                    ind1[i] = 0;
                    ind2[i] = 0;
                }

                if ((!old_constellation.equals(constellation)) && (!constellation.equals(premiere_constellation)))
                {
                    old_constellation = constellation;
                }
            }
            //extraction des informations de "trace"
            //--------------------------------------
            debut_fichier = false;
            lngPos = 1;
            strS = trace;
            while (lngPos >= 0)
            {
                c = new Coord();
                c.setDecl(d);
                c.setRA(ad);

                if (trace.trim().equals(""))
                {
                    break;
                }
                lngPos = strS.indexOf(" ");

                //en cas de nombre
                lettre = strS.charAt(0);
                if (Character.isDigit(lettre))
                {
                    type_indice = IND_NOMBRE;

                    //end of string
                    if (lngPos < 0)
                    {
                        indice_nombre = Integer.parseInt(strS.trim());
                    }
                    else
                    {
                        indice_nombre = Integer.parseInt(strS.substring(0, lngPos));
                    }
                }

                //en cas de lettre
                else
                {
                    type_indice = IND_LETTRE;
                    indice_lettre = Character.getNumericValue(lettre) - Character.getNumericValue('a') + 1;

                    if (ind1[indice_lettre] != 0)
                    {
                        if (!Character.isDigit(trace.substring(0, 1).charAt(0)))
                        {
                            if (trace.equals(strS))
                            {
                                dernier_indice_non_attribue -= 1;
                            }
                            ind2[indice_lettre] = dernier_indice_non_attribue;
                            Az[dernier_indice_non_attribue] = c.azFromEquatorial(latitude_lieu, TSL);
                            if (mnuOtherSide.isSelected() == true)
                            {
                                Az[dernier_indice_non_attribue] = AstronomyMaths.mod(Az[dernier_indice_non_attribue] + 180.0, 360.0);
                            }
                            ha[dernier_indice_non_attribue] = c.altFromEquatorial(latitude_lieu, TSL);
                        }
                        else
                        {
                            type_indice = IND_NOMBRE;
                            ind2[indice_lettre] = indice_nombre;
                        }
                    }
                    else
                    {
                        if (!Character.isDigit(trace.substring(0, 1).charAt(0)))
                        {
                            if (trace.equals(strS))
                            {
                                dernier_indice_non_attribue -= 1;
                            }
                            ind1[indice_lettre] = dernier_indice_non_attribue;
                            Az[dernier_indice_non_attribue] = c.azFromEquatorial(latitude_lieu, TSL);
                            if (mnuOtherSide.isSelected() == true)
                            {
                                Az[dernier_indice_non_attribue] = AstronomyMaths.mod(Az[dernier_indice_non_attribue] + 180.0, 360.0);
                            }
                            ha[dernier_indice_non_attribue] = c.altFromEquatorial(latitude_lieu, TSL);
                        }
                        else
                        {
                            type_indice = IND_NOMBRE;
                            ind1[indice_lettre] = indice_nombre;
                        }
                    }
                }

                if (lngPos >= 0)
                {
                    strS = strS.substring(lngPos + 1);
                }

                //calcul de l'azimut et de la hauteur dans le cas IND_NOMBRE
                if (type_indice == IND_NOMBRE)
                {
                    Az[indice_nombre] = c.azFromEquatorial(latitude_lieu, TSL);
                    if (mnuOtherSide.isSelected() == true)
                    {
                        Az[indice_nombre] = AstronomyMaths.mod(Az[indice_nombre] + 180, 360.0);
                    }
                    ha[indice_nombre] = c.altFromEquatorial(latitude_lieu, TSL);
                }

                FIN_constellation = Math.max(FIN_constellation, indice_nombre);
            }
        }
    }

    private void getEsotericData()
    {
        double as = pos1.get(Planets.AS).getTropicGeoLong();//.getCoord1(chartElements.getCoordSys());
        double sun = pos1.get(Planets.Sun).getTropicGeoLong();//.getCoord1(chartElements.getCoordSys());
        double gaia = AstronomyMaths.modulo(sun - 180.0, 360.0);
        double moon = pos1.get(Planets.Moon).getTropicGeoLong();//.getCoord1(chartElements.getCoordSys());
        double nn = pos1.get(Planets.NorthNode).getTropicGeoLong();//.getCoord1(chartElements.getCoordSys());
        double val_asp = AstronomyMaths.modulo(moon - sun, 360.0);
        double as1;
        double as2;
        double delta1;
        double delta2;
        double delta;
        double x = AstronomyMaths.modulo(as - nn, 360.0);
        double r;
        if (x > 180.0)
        {
            x = 360.0 - x;
        }
        double cosAsNn = AstronomyMaths.cosD(x);

        //esoteric ascendant
        if (sun < 270.0 && sun >= 90.0)     // from summer to winter
        {
            if (val_asp >= 0.0 && val_asp < 180.0) // from new moon to full moon
            {
                delta1 = AstronomyMaths.modulo(sun - as, 360.0);
                if (delta1 > 180.0)
                {
                    delta1 = 360.0 - delta1;
                }
                delta2 = AstronomyMaths.modulo(gaia - moon, 360.0);
                if (delta2 > 180.0)
                {
                    delta2 = 360.0 - delta2;
                }
                delta = delta1 + delta2;
                if (delta > 180.0)
                {
                    delta = 360.0 - delta;
                }
                delta = AstronomyMaths.modulo(delta * cosAsNn, 360.0);
                as1 = AstronomyMaths.modulo(as + delta, 360.0);
                as2 = AstronomyMaths.modulo(as - delta, 360.0);
            }
            else
            {
                delta1 = AstronomyMaths.modulo(sun - as, 360.0);
                if (delta1 > 180.0)
                {
                    delta1 = 360.0 - delta1;
                }
                delta2 = AstronomyMaths.modulo(gaia - moon, 360.0);
                if (delta2 > 180.0)
                {
                    delta2 = 360.0 - delta2;
                }
                delta = AstronomyMaths.modulo((delta1 + delta2 - 180.0) * cosAsNn, 360.0);
                as1 = AstronomyMaths.modulo(as + delta, 360.0);
                as2 = AstronomyMaths.modulo(as - delta, 360.0);
            }
        }

        else
        {
            if (val_asp >= 0.0 && val_asp < 180.0) // from new moon to full moon
            {
                delta1 = AstronomyMaths.modulo(sun - as, 360.0);
                if (delta1 > 180.0)
                {
                    delta1 = 360.0 - delta1;
                }
                delta2 = AstronomyMaths.modulo(sun - moon, 360.0);
                if (delta2 > 180.0)
                {
                    delta2 = 360.0 - delta2;
                }
                delta = AstronomyMaths.modulo((delta1 + delta2 - 180.0) * cosAsNn, 360.0);
                as1 = AstronomyMaths.modulo(as + delta, 360.0);
                as2 = AstronomyMaths.modulo(as - delta, 360.0);
            }
            else
            {
                delta1 = AstronomyMaths.modulo(sun - as, 360.0);
                if (delta1 > 180.0)
                {
                    delta1 = 360.0 - delta1;
                }
                delta2 = AstronomyMaths.modulo(sun - moon, 360.0);
                if (delta2 > 180.0)
                {
                    delta2 = 360.0 - delta2;
                }
                delta = delta1 + delta2;
                if (delta > 180.0)
                {
                    delta = 360.0 - delta;
                }
                delta = AstronomyMaths.modulo(delta * cosAsNn, 360.0);
                as1 = AstronomyMaths.modulo(as + delta, 360.0);
                as2 = AstronomyMaths.modulo(as - delta, 360.0);
            }
        }

        String result = "AS 1 =  " + new FDegree(as1).getShortDegree() + "\r\nAS 2 =  " + new FDegree(as2).getShortDegree();

        //mental, astral and etheric rythmes
        delta1 = AstronomyMaths.modulo(sun - 180.0, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(sun - as, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nE M =  " + AstronomyMaths.getRnd(r, 5);

        delta1 = AstronomyMaths.modulo(moon - 120.0, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(sun - moon, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nE A =  " + AstronomyMaths.getRnd(r, 5);

        delta1 = AstronomyMaths.modulo(gaia - 300.0, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(gaia - moon, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nE E =  " + AstronomyMaths.getRnd(r, 5);

        delta1 = AstronomyMaths.modulo(sun - as, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(sun - 180.0, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nI M =  " + AstronomyMaths.getRnd(r, 5);

        delta1 = AstronomyMaths.modulo(sun - moon, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(moon - 120.0, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nI A =  " + AstronomyMaths.getRnd(r, 5);

        delta1 = AstronomyMaths.modulo(gaia - moon, 360.0);
        if (delta1 > 180.0)
        {
            delta1 = 360.0 - delta1;
        }
        delta1 = Math.abs(delta1 - 180.0);
        delta1 = AstronomyMaths.modulo(delta1, 360.0);
        delta2 = AstronomyMaths.modulo(gaia - 300.0, 360.0);
        if (delta2 > 180.0)
        {
            delta2 = 360.0 - delta1;
        }
        r = delta1 / delta2;
        result = result + "\r\nI E =  " + AstronomyMaths.getRnd(r, 5);
        JOptionPane.showMessageDialog(this, result, "Esoteric", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showConstelBoundariesLS(Graphics2D g2, int rayon, double deltaAngle, double TSL, double latitude_lieu)
    {
        //auxiliary variables
        double rr;
        double rj;
        double u1;
        double u2;
        double u3;
        //coordonnees sur la feuille (ecran ou imprimee)
        double angle = 0.0;
        //double angle2 = 0.0;
        int lngCurrentX = 0;
        int lngCurrentY = 0;
        double rapport_projection;
        //coordonnees pour le point precedent de la constellation
        double lngOldAngle;
        int lngOldCurrentX;
        int lngOldCurrentY;
        //Right ascension
        double ad;
        //declination
        double d;
        //azimut
        double Az;
        //hauteur
        double ha;
        byte move;
        double old_ha = 0.0;
        //Julian Day correspondant � l'annee de reference (2000.0)
        double jj_ref;
        //temps seculaire de reference
        double tps_ref;
        //date seculaire par rapport � l'annee de reference
        double date_seculaire;

        double aux;
        Coord c;
        boolean nouvelle_constellation;
        //=========================================================================

        g2.setColor(new Color(255, 192, 128));
        g2.setStroke(new BasicStroke((float) zoom));

        //calculs prealables
        //------------------
        //annee de reference convertie en Julian Day
        jj_ref = AstronomyMaths.gregorianToJulian(1, 1, 2000);
        //temps seculaire de reference
        tps_ref = (jj_ref - 2415020) / AstronomyMaths.DAY_PER_CENTURY;
        //temps seculaire par rapport � l'annee de reference
        date_seculaire = chartEvent.getCTimeH() - tps_ref;

        ArrayList vSC = constellBound.getConstellBound();
        if (vSC == null || vSC.isEmpty())
        {
            return;
        }
        for (Object vSC1 : vSC)
        {
            ArrayList v = (ArrayList) vSC1;
            move = Byte.parseByte(String.valueOf(v.get(0)));
            ad = java.lang.Double.parseDouble(String.valueOf(v.get(1)));
            d = java.lang.Double.parseDouble(String.valueOf(v.get(2)));
            nouvelle_constellation = move == 0;
            
            //EFFET DE LA PRECESSION
            aux = date_seculaire * AstronomyMaths.PI_SUR_CENT80;
            rr = 0.640457952975 * aux;
            rj = 0.556617038814 * aux;
            u1 = Math.cos(d) * Math.sin(ad + rr);
            aux = Math.cos(d) * Math.cos(ad + rr);
            u2 = Math.cos(rj) * aux - Math.sin(rj) * Math.sin(d);
            u3 = Math.sin(rj) * aux + Math.cos(rj) * Math.sin(d);
            if (Math.abs(u3) > 0.9)
            {
                d = AstronomyMaths.acosD(Math.sqrt(u1 * u1 + u2 * u2)) * AstronomyMaths.sgn(u3);
            }
            else
            {
                d = AstronomyMaths.asinD(u3);
            }
            ad = (rr + Math.atan(u1 / u2)) * AstronomyMaths.CENT80_SUR_PI;
            if (u2 < 0.0)
            {
                ad = ad + 180.0;
            }
            if (ad < 0.0)
            {
                ad = ad + 360.0;
            }
            c = new Coord();
            c.setDecl(d);
            c.setRA(ad);
            Az = c.azFromEquatorial(latitude_lieu, TSL);
            if (mnuOtherSide.isSelected() == true)
            {
                Az = AstronomyMaths.mod(Az + 180, 360.0);
            }
            ha = c.altFromEquatorial(latitude_lieu, TSL);
            //sauvegarde des coordonnees d'affichage du point precedant
            lngOldCurrentX = lngCurrentX;
            lngOldCurrentY = lngCurrentY;
            lngOldAngle = angle;
            //calcul des coordonnees d'affichage du point actuel
            if (chartElements.getHorizon() == true)
            {
                angle = 180 + (Az - deltaAngle);
                lngCurrentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha));
                lngCurrentY = centerY - (int) ((double) rayon * AstronomyMaths.sinD(ha));
            }
            else
            {
                angle = Az - deltaAngle;
                rapport_projection = Math.sqrt(1 - Math.abs(ha) / 90.0);
                lngCurrentX = centerX - (int) ((double) rayon * AstronomyMaths.sinD(angle) * AstronomyMaths.cosD(ha) * rapport_projection);
                lngCurrentY = centerY - (int) ((double) rayon * AstronomyMaths.cosD(angle) * AstronomyMaths.cosD(ha) * rapport_projection);
            }
            //affichage ou impression du trait reliant le point precedant et l'actuel
            if ((nouvelle_constellation == false))
            {
                showConstelLines(g2, ha, angle, old_ha, lngOldAngle, lngCurrentX, lngCurrentY, lngOldCurrentX, lngOldCurrentY, chartElements.getHorizon());
            }
            old_ha = ha;
        }
    }

    private void showConstelBoundaries(Graphics2D g2, double temps_seculaire, double rayon, double angle_phase)
    {
        double longitude;
        double angle[] = new double[ZodConstels.getLast() + 1];
        int j;
        int i;
        double px;
        double a;
        String strg;
        double mult;
        double ayanamsa = 0.0;
        int curX;
        int curY;
        int stringHeight;
        int stringWidth;
        //=========================================================================

        g2.setColor(Color.GRAY);
        g2.setFont(new Font(FT_ARIAL, Font.PLAIN, characterSize));
        g2.setStroke(new BasicStroke((float) zoom));

        if (chartElements.getCoordSys() == CoordSystem.Sidereal || chartElements.getCoordSys() == CoordSystem.HelioSidereal)
        {
            ayanamsa = AstronomyMaths.getAyanamsa(temps_seculaire);
        }

        //show the lines between contellations
        for (i = 0; i <= ZodConstels.getLast(); i++)
        {
            longitude = ZodConstels.getConstelBoundary(i, temps_seculaire);
            if (chartElements.getCoordSys() == CoordSystem.Sidereal || chartElements.getCoordSys() == CoordSystem.HelioSidereal)
            {
                longitude = longitude - ayanamsa;
            }
            angle[i] = AstronomyMaths.mod(angle_phase - longitude, 360.0);
            g2.drawLine((int) ((double) rayon * AstronomyMaths.cosD(angle[i])) + centerX, (int) ((double) rayon * AstronomyMaths.sinD(angle[i])) + centerY, centerX, centerY);
        }

        //show the three first letters of the constellation names
        for (i = 0; i <= ZodConstels.getLast(); i++)
        {
            //angle position of the name
            j = AstronomyMaths.mod(i + 1, 13);
            a = (angle[i] + angle[j]) / 2.0;
            if (Math.abs(a - angle[i]) > 90.0)
            {
                a = a + 180.0;
            }

            //get the name
            strg = ZodConstels.getAbConstelName(i);// MainForm.zodConstelName[i].substring(0, 3);

            //display the name
            if (j == ZodConstels.ZodConstel9)
            {
                mult = 1.25;
            }
            else
            {
                mult = 1.0;
            }

            stringWidth = g2.getFontMetrics().stringWidth(strg);
            stringHeight = g2.getFontMetrics().getHeight();
            curX = (int) ((double) rayon * mult / 1.5 * AstronomyMaths.cosD(a)) + centerX;
            curY = (int) ((double) rayon * mult / 1.5 * AstronomyMaths.sinD(a)) + centerY;
            curX = curX - stringWidth / 2;
            curY = curY + stringHeight / 2;
            g2.drawString(strg, curX, curY);
        }
    }

    //=====================================================================
    //Affichage du trait reliant deux points du schema d'une constellation
    //        ha1              : hauteur du point 1
    //        a1               : a1 du point 1
    //        ha2              : hauteur du point 2
    //        a2               : a1 du point 2
    //        X1               : abscisse du point 1
    //        Y1               : ordonnee du point 1
    //        X2               : abscisse du point 2
    //        Y2               : ordonnee du point 2
    //        rayon            : rayon de la zone d'affichage
    //        centreX          : abscisse du centre de la zone d'affichage
    //        centreY          : ordonnee du centre de la zone d'affichage
    //=====================================================================

    private void showConstelLines(Graphics2D g2, double ha1, double a1, double ha2, double a2, int x1, int y1, int x2, int y2, boolean viewHorizon)
    {
        //si les deux points sont visibles
        if (((ha1 > 0) && ((viewHorizon == false) || (AstronomyMaths.cosD(a1) <= 0))) && ((ha2 > 0) && ((viewHorizon == false) || (AstronomyMaths.cosD(a2) <= 0))))
        {
            g2.drawLine(x1, y1, x2, y2);
        }
    }

    private void initComponents()
    {
        grpAstronView = new ButtonGroup();
        grpAspectsInOut = new ButtonGroup();
        btnOptions = new JButton();
        btnPrint = new JButton();
        btnSave = new JButton();
        cboZoom = new JComboBox();
        btnGrid = new JButton();
        btnValues = new JButton();
        btnInterpret = new JButton();
        btnConfigs = new JButton();
        jSeparator3 = new JSeparator();
        btnDecrease = new JButton();
        cboSteps = new JComboBox();
        btnIncrease = new JButton();
        lblNewDate = new JLabel();
        btnAnimate = new JToggleButton();
        jSeparator2 = new JSeparator();
        jSeparator5 = new JSeparator();
        lblHarmoNB = new JLabel();
        txtHarmonicNB = new JTextField();
        jSeparator1 = new JSeparator();
        lblRulers = new JLabel();
        cboRulersKind = new JComboBox();
        cboRulersRef = new JComboBox();
        btnRulers = new JButton();
        mnuAspect1 = new JRadioButtonMenuItem();
        mnuAspect2 = new JRadioButtonMenuItem();
        mnuAspect12 = new JRadioButtonMenuItem();
        mnuAspect21 = new JRadioButtonMenuItem();
        mnuContext = new JPopupMenu();
        mnuHorizon = new JRadioButtonMenuItem();
        mnuZenith = new JRadioButtonMenuItem();
        jSeparator4 = new JSeparator();
        mnuOtherSide = new JCheckBoxMenuItem();
        mnuReverseHouses = new JCheckBoxMenuItem();
        mnuPermute = new JCheckBoxMenuItem();
        pnlBoutons = new javax.swing.JPanel();
        pnlBoutons1 = new javax.swing.JPanel();
        pnlBoutons2 = new javax.swing.JPanel();

        pnlBoutons.setBackground(new java.awt.Color(255, 255, 255));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 2));

        pnlBoutons1.setOpaque(false);
        pnlBoutons1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 2, 0));
        pnlBoutons2.setOpaque(false);
        pnlBoutons2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 2, 0));

        btnOptions.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/options.png")));
        btnOptions.setBorder(null);
        btnOptions.setPreferredSize(new Dimension(32, 32));
        btnOptions.setToolTipText(bundle.getString("ModifyOptions"));
        btnOptions.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnOptionsActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnOptions);

        btnPrint.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/printer2.png")));
        btnPrint.setBorder(null);
        btnPrint.setPreferredSize(new Dimension(32, 32));
        btnPrint.setToolTipText(bundle.getString("PrintTheViewOfTheChart"));
        btnPrint.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnPrintActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnPrint);

        btnSave.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/save2.png")));
        btnSave.setBorder(null);
        btnSave.setPreferredSize(new Dimension(32, 32));
        btnSave.setToolTipText(bundle.getString("ReadSavedChart"));
        btnSave.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnSaveActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnSave);
        cboZoom.setPreferredSize(new Dimension(100, 24));
        cboZoom.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                cboZoomActionPerformed(evt);
            }
        });

        pnlBoutons1.add(cboZoom);

        btnGrid.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/grid.png")));
        btnGrid.setBorder(null);
        btnGrid.setPreferredSize(new Dimension(32, 32));
        btnGrid.setToolTipText(bundle.getString("GridResult"));
        btnGrid.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnGridActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnGrid);

        btnInterpret.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/einstein.png")));
        btnInterpret.setBorder(null);
        btnInterpret.setPreferredSize(new Dimension(32, 32));
        btnInterpret.setToolTipText(bundle.getString("InterpretationOfChart"));
        btnInterpret.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnInterpretActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnInterpret);

        btnConfigs.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/configs.png")));
        btnConfigs.setBorder(null);
        btnConfigs.setPreferredSize(new Dimension(32, 32));
        btnConfigs.setToolTipText(bundle.getString("PlanetaryConfigurations"));
        btnConfigs.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnConfigsActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnConfigs);

        jSeparator3.setOrientation(SwingConstants.VERTICAL);
        //jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator3.setPreferredSize(new Dimension(2, 24));
        pnlBoutons1.add(jSeparator3);

        btnDecrease.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/decrease.png")));
        btnDecrease.setBorder(null);
        btnDecrease.setPreferredSize(new Dimension(32, 32));
        btnDecrease.setToolTipText(bundle.getString("TowardPast"));
        btnDecrease.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnDecreaseActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnDecrease);

        cboSteps.setPreferredSize(new Dimension(120, 24));

        pnlBoutons1.add(cboSteps);

        btnIncrease.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/increase.png")));
        btnIncrease.setBorder(null);
        btnIncrease.setPreferredSize(new Dimension(32, 32));
        btnIncrease.setToolTipText(bundle.getString("TowardFuture"));
        btnIncrease.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnIncreaseActionPerformed(evt);
            }
        });

        pnlBoutons1.add(btnIncrease);

        //lblNewDate.setBackground(new Color(102, 200, 255));
        lblNewDate.setText("");
        lblNewDate.setFont(new Font("Dialog", 0, 12));
        lblNewDate.setHorizontalAlignment(SwingConstants.CENTER);
        //lblNewDate.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(153, 255, 255), new Color(153, 255, 255), Color.gray, Color.gray));
        lblNewDate.setPreferredSize(new Dimension(150, 20));
        lblNewDate.setHorizontalTextPosition(SwingConstants.LEADING);
        lblNewDate.setOpaque(false);
        pnlBoutons1.add(lblNewDate);

        pnlBoutons.add(pnlBoutons1);

        btnAnimate.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/atomspin.gif")));
        //btnAnimate.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnAnimate.setPreferredSize(new Dimension(34, 34));
        btnAnimate.setPressedIcon(new ImageIcon(getClass().getResource("/StarLogin/images/stopmotion.gif")));
        btnAnimate.setSelectedIcon(new ImageIcon(getClass().getResource("/StarLogin/images/stopmotion.gif")));
        btnAnimate.setToolTipText(bundle.getString("AnimateChartTimeModif"));
        btnAnimate.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnAnimateActionPerformed(evt);
            }
        });

        pnlBoutons2.add(btnAnimate);

        jSeparator2.setOrientation(SwingConstants.VERTICAL);
        jSeparator2.setPreferredSize(new Dimension(2, 24));
        //jSeparator2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlBoutons2.add(jSeparator2);

        //lblHarmoNB.setBackground(new Color(102, 200, 255));
        lblHarmoNB.setFont(new Font("Dialog", 0, 12));
        lblHarmoNB.setHorizontalAlignment(SwingConstants.CENTER);
        lblHarmoNB.setText(bundle.getString("HarmonicNB"));
        //lblHarmoNB.setBorder(new EmptyBorder(new Insets(0, 7, 0, 0)));
        lblHarmoNB.setPreferredSize(new Dimension(160, 18));
        lblHarmoNB.setHorizontalTextPosition(SwingConstants.LEADING);
        lblHarmoNB.setOpaque(true);
        pnlBoutons2.add(lblHarmoNB);

        txtHarmonicNB.setHorizontalAlignment(JTextField.CENTER);
        txtHarmonicNB.setText("1");
        //txtHarmonicNB.setBorder(new BevelBorder(BevelBorder.LOWERED));
        txtHarmonicNB.setPreferredSize(new Dimension(26, 21));
        txtHarmonicNB.addKeyListener(new KeyAdapter()
        {
            @Override
            public void keyTyped(KeyEvent evt)
            {
                txtHarmonicNBKeyTyped(evt);
            }

            @Override
            public void keyReleased(KeyEvent evt)
            {
                txtHarmonicNBKeyReleased(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlBoutons2.add(txtHarmonicNB);

        jSeparator1.setOrientation(SwingConstants.VERTICAL);
        jSeparator1.setPreferredSize(new Dimension(2, 24));
        //jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlBoutons2.add(jSeparator1);

        //lblRulers.setBackground(new Color(102, 200, 255));
        lblRulers.setFont(new Font("Dialog", 0, 12));
        lblRulers.setHorizontalAlignment(SwingConstants.CENTER);
        lblRulers.setText(bundle.getString("Rulers"));
        //lblRulers.setBorder(new EmptyBorder(new Insets(0, 7, 0, 0)));
        lblRulers.setPreferredSize(new Dimension(70, 18));
        lblRulers.setHorizontalTextPosition(SwingConstants.LEADING);
        lblRulers.setOpaque(true);
        pnlBoutons2.add(lblRulers);

        cboRulersKind.setPreferredSize(new Dimension(140, 24));
        pnlBoutons2.add(cboRulersKind);

        cboRulersRef.setPreferredSize(new Dimension(140, 24));
        pnlBoutons2.add(cboRulersRef);

        btnRulers.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/traficlight.png")));
        btnRulers.setBorder(null);
        btnRulers.setPreferredSize(new Dimension(14, 32));
        btnRulers.setToolTipText(bundle.getString("ShowRulerships"));
        btnRulers.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnRulersActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnRulers);

        addMouseListener(new MouseAdapter()
        {
            @Override
            public void mousePressed(MouseEvent evt)
            {
                formMousePressed(evt);
            }

            @Override
            public void mouseReleased(MouseEvent evt)
            {
                formMouseReleased(evt);
            }
        });
        addMouseMotionListener(new MouseMotionAdapter()
        {
            @Override
            public void mouseMoved(MouseEvent evt)
            {
                formMouseMoved(evt);
            }
        });

        pnlBoutons2.add(btnRulers);

        btnValues.setIcon(new ImageIcon(getClass().getResource("/StarLogin/images/eso.gif")));
        btnValues.setPreferredSize(new Dimension(5, 32));
        btnValues.setBorder(null);
        btnValues.setToolTipText(bundle.getString("ValuesFromChart"));
        btnValues.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                btnValuesActionPerformed(evt);
            }
        });

        pnlBoutons2.add(btnValues);
        pnlBoutons.add(pnlBoutons2);
        pnlBoutons1.setPreferredSize(new Dimension(674, 34));
        pnlBoutons2.setPreferredSize(new Dimension(615, 34));

        if (chartKind != ChartKind.local)
        {
            mnuReverseHouses.setText(bundle.getString("ReverseHouses"));
            //mnuReverseHouses.setPreferredSize(new Dimension(220, 20));
            mnuReverseHouses.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    mnuReverseHousesActionPerformed(evt);
                }
            });

            mnuContext.add(mnuReverseHouses);
        }

        if ((chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.synastry) || (chartKind == ChartKind.transit))
        {
            mnuPermute.setText(bundle.getString("PermuteCharts"));
            mnuPermute.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    mnuPermuteActionPerformed(evt);
                }
            });

            mnuContext.add(mnuPermute);
        }

        if (chartKind == ChartKind.local)
        {
            mnuHorizon.setText(bundle.getString("Horizon"));
            grpAstronView.add(mnuHorizon);
            mnuHorizon.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    mnuHorizonActionPerformed(evt);
                }
            });

            mnuContext.add(mnuHorizon);

            mnuZenith.setText(bundle.getString("Zenith"));
            mnuZenith.setSelected(true);
            //mnuZenith.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
            grpAstronView.add(mnuZenith);
            mnuZenith.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    mnuZenithActionPerformed(evt);
                }
            });

            mnuContext.add(mnuZenith);

            //jSeparator4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            mnuContext.add(jSeparator4);

            mnuOtherSide.setText(bundle.getString("OtherSide"));
            //mnuOtherSide.setPreferredSize(new Dimension(220, 20));
            //mnuOtherSide.add(chkOtherSide);
            mnuOtherSide.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    mnuOtherSideActionPerformed(evt);
                }
            });
            mnuContext.add(mnuOtherSide);
        }
        else
        {
            if ((chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.synastry) || (chartKind == ChartKind.transit))
            {
                //jSeparator5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
                mnuContext.add(jSeparator5);

                mnuAspect1.setText(bundle.getString("AspectsInnerChart"));
                mnuAspect1.setSelected(true);
                //mnuAspect1.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
                grpAspectsInOut.add(mnuAspect1);
                mnuAspect1.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent evt)
                    {
                        mnuAspect1ActionPerformed(evt);
                    }
                });
                mnuContext.add(mnuAspect1);

                mnuAspect2.setText(bundle.getString("AspectsOuterChart"));
                grpAspectsInOut.add(mnuAspect2);
                mnuAspect2.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent evt)
                    {
                        mnuAspect2ActionPerformed(evt);
                    }
                });

                mnuContext.add(mnuAspect2);

                mnuAspect12.setText(bundle.getString("AspectsInnerOuter"));
                grpAspectsInOut.add(mnuAspect12);
                mnuAspect12.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent evt)
                    {
                        mnuAspect12ActionPerformed(evt);
                    }
                });

                mnuContext.add(mnuAspect12);

                mnuAspect21.setText(bundle.getString("AspectsOuterInner"));
                grpAspectsInOut.add(mnuAspect21);
                mnuAspect21.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent evt)
                    {
                        mnuAspect21ActionPerformed(evt);
                    }
                });

                mnuContext.add(mnuAspect21);
            }
        }

        addComponentListener(new java.awt.event.ComponentAdapter()
        {
            @Override
            public void componentResized(java.awt.event.ComponentEvent evt)
            {
                int w = skyChart.getBounds().width;
                if (w < 1294)
                {
                    pnlBoutons.setPreferredSize(new Dimension(10, 72));
                    pnlBoutons.setSize(new Dimension(w, 72));
                }
                else
                {
                    pnlBoutons.setPreferredSize(new Dimension(10, 36));
                    pnlBoutons.setSize(new Dimension(w, 36));
                }
                //pnlBoutons.paintImmediately(pnlBoutons.getBounds());
                skyChart.paintAll(skyChart.getGraphics());
            }
        });

        skyChart.getContentPane().add(pnlBoutons, BorderLayout.NORTH);
        skyChart.pack();
    }

    private void txtHarmonicNBKeyTyped(KeyEvent evt)
    {
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtHarmonicNB, 1, kc);
    }

    private void txtHarmonicNBKeyReleased(KeyEvent evt)
    {
        harmonicProcessing();
    }

    private void mnuOtherSideActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        /*if (mnuOtherSide.isSelected())
         {
         mnuOtherSide.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
         }
         else
         {
         mnuOtherSide.setBackground(new Color(204, 204, 204));
         }*/
        otherSide();
    }

    private void mnuReverseHousesActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        /*if (mnuReverseHouses.isSelected())
         {
         mnuReverseHouses.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
         }
         else
         {
         mnuReverseHouses.setBackground(new Color(204, 204, 204));
         }*/
        reverseHouses();
    }

    private void mnuPermuteActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        /*if (mnuPermute.isSelected())
         {
         mnuPermute.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
         }
         else
         {
         mnuPermute.setBackground(new Color(204, 204, 204));
         }*/
        dblAngle = 0.0;
        header = modifHeader(chartEvent.getHeader());

        if (chartElements.getChartEvents().size() > 1)
        {
            //ChartEvent chartEvent1 = (ChartEvent)chartElements.getChartEvents().get(0);
            //ChartEvent chartEvent2 = (ChartEvent)chartElements.getChartEvents().get(1);
            header = modifHeader(chartEvent.getHeader());
            posX = pos1.cloneCoords();
            pos1 = pos2.cloneCoords();
            pos2 = posX.cloneCoords();

            if (chartElements.getViewBarycenter())
            {
                Astrology.barycenterProcessing(chartElements, pos1);
            }
            displayChart();
        }
    }

    private void mnuAspect21ActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        tableau_flag = Astrology.POS_2_1;
        //mnuAspect21.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuAspect12.setBackground(new Color(204, 204, 204));
        //mnuAspect2.setBackground(new Color(204, 204, 204));
        //mnuAspect1.setBackground(new Color(204, 204, 204));
        header = modifHeader(chartEvent.getHeader());
        displayChart();
    }

    private void mnuAspect12ActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        tableau_flag = Astrology.POS_1_2;
        //mnuAspect12.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuAspect21.setBackground(new Color(204, 204, 204));
        //mnuAspect2.setBackground(new Color(204, 204, 204));
        //mnuAspect1.setBackground(new Color(204, 204, 204));
        header = modifHeader(chartEvent.getHeader());
        displayChart();
    }

    private void mnuAspect2ActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        tableau_flag = Astrology.POS_2;
        //mnuAspect2.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuAspect12.setBackground(new Color(204, 204, 204));
        //mnuAspect21.setBackground(new Color(204, 204, 204));
        //mnuAspect1.setBackground(new Color(204, 204, 204));
        header = modifHeader(chartEvent.getHeader());
        displayChart();
    }

    private void mnuAspect1ActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        tableau_flag = Astrology.POS_1;
        //mnuAspect1.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuAspect12.setBackground(new Color(204, 204, 204));
        //mnuAspect2.setBackground(new Color(204, 204, 204));
        //mnuAspect21.setBackground(new Color(204, 204, 204));
        header = modifHeader(chartEvent.getHeader());
        displayChart();
    }

    private void mnuZenithActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        chartElements.setHorizon(false);
        //mnuZenith.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuHorizon.setBackground(new Color(204, 204, 204));
        displayChart();
    }

    private void mnuHorizonActionPerformed(ActionEvent evt)
    {
        if (bSetting == true)
        {
            return;
        }
        chartElements.setHorizon(true);
        //mnuHorizon.setBackground(MainClass.getCurrentOption().getColorButtonsBackground());
        //mnuZenith.setBackground(new Color(204, 204, 204));
        displayChart();
    }

    private void btnSaveActionPerformed(ActionEvent evt)
    {
        /*if (MainClass.getReadOnly())
         {
         JOptionPane.showMessageDialog(this, bundle.getString("CantUseThisFunctionInDemo"), "StarLogin", JOptionPane.WARNING_MESSAGE);
         return;
         }*/
        saveChart(chartElements);
    }

    private void saveChart(ChartElements chartElements)
    {
        //put the results in the database

        //chart data
        Chart chart = new Chart();
        chart.setAdding(true);
        chart.setChartType((byte) chartKind);
        chart.setComments(chartEvent.getEvent().getComments());
        chart.setConfigurations(planetaryConfigurations);
        chart.setCoordinatesSystem((byte) chartElements.getCoordSys());
        chart.setEventID(Integer.parseInt(chartEvent.getEvent().getId()));
        chart.setHeader(chartEvent.getHeader());
        chart.setHousesSystem((byte) chartElements.getHouseSys());
        chart.setOtherPointName(chartElements.getOtherPointName());
        chart.setOtherPointType((byte) chartElements.getOtherPointType());
        chart.setPicture(chartEvent.getEvent().getPicture());
        String title = ChartKind.getChartKindName(chartKind) + " - " + chartEvent.getEvent().getOtherNames() + " " + chartEvent.getEvent().getSurname() + " - " + chartEvent.getEvent().getEventName();
        if (title.length() > 255)
        {
            title = title.substring(0, 254);
        }
        title = JOptionPane.showInputDialog(this, bundle.getString("GiveATitleToTheChart"), title);
        if (title == null)
        {
            return;
        }
        if (title.length() > 255)
        {
            title = title.substring(0, 254);
        }
        chart.setTitle(title);
        starLoginManager.setChart(chart);
        String chartID = chart.getId();

        ArrayList allCoords = chartElements.getChartCoords();
        if (allCoords == null || allCoords.isEmpty())
        {
            return;
        }

        for (int i = 0; i < allCoords.size(); i++)
        {
            AllCoord pos = (AllCoord) allCoords.get(i);
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }
            int j;

            for (j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                Position position = new Position();
                Coord planet = (Coord) coords.get(j);
                position.setAltitude(planet.getAlt());
                position.setAzimuth(planet.getAz());
                position.setChartID(chartID);
                position.setChartNB(Integer.toString(i));
                position.setDeclination(planet.getDecl());
                position.setGeoDistance(planet.getGeoDist());
                position.setGeoLatitude(planet.getGeoLat());
                double aux_coord = planet.getTropicGeoLong();
                position.setGeoLongitude(aux_coord);
                position.setGeoLongitudeSider(planet.getSiderGeoLong());
                position.setHelioDistance(planet.getHelioDist());
                position.setHelioLatitude(planet.getHelioLat());
                position.setHelioLongitude(planet.getTropicHelioLong());
                position.setHelioLongitudeSider(planet.getSiderHelioLong());
                position.setObjName(Planets.getPlanetName(j, chartElements));
                position.setObjectID(Integer.toString(j));
                position.setRightAscension(planet.getRA());
                int sign = (int) (aux_coord / 30.0);
                position.setSign(MainForm.signName[sign]);
                position.setElement(Signs.getElement(sign));
                position.setAngle(Signs.getAngle(sign));
                position.setDecan((byte) (int) (AstronomyMaths.mod(aux_coord, 30.0) / 10.0 + 1));
                ConstelsCalc constelsCalc = new ConstelsCalc();
                position.setConstellation(constelsCalc.findConstell(planet.getRA() * AstronomyMaths.PI_SUR_CENT80, planet.getDecl() * AstronomyMaths.PI_SUR_CENT80, (double) chartEvent.getYear(), constellationBoundaries));

                if (j <= Planets.MC)
                {
                    double x = aspectValues[j][Planets.Moon];
                    double x2 = aspectValues[j][(int) Planets.Moon];
                    double x3 = aspectValues[j][1];
                    position.setAngleWithAscendant(aspectValues[j][Planets.AS]);
                    position.setAngleWithSun(aspectValues[j][Planets.Sun]);
                    position.setAngleWithMoon(aspectValues[j][Planets.Moon]);
                    position.setAngleWithMercury(aspectValues[j][Planets.Mercury]);
                    position.setAngleWithVenus(aspectValues[j][Planets.Venus]);
                    position.setAngleWithMars(aspectValues[j][Planets.Mars]);
                    position.setAngleWithJupiter(aspectValues[j][Planets.Jupiter]);
                    position.setAngleWithSaturn(aspectValues[j][Planets.Saturn]);
                    position.setAngleWithUranus(aspectValues[j][Planets.Uranus]);
                    position.setAngleWithNeptune(aspectValues[j][Planets.Neptune]);
                    position.setAngleWithPluto(aspectValues[j][Planets.Pluto]);
                    position.setAngleWithEarth(aspectValues[j][Planets.Gaia]);
                    position.setAngleWithNorthNode(aspectValues[j][Planets.NorthNode]);
                    position.setAngleWithEast(aspectValues[j][Planets.East]);
                    position.setAngleWithVertex(aspectValues[j][Planets.Vertex]);
                    position.setAngleWithLilith(aspectValues[j][Planets.Lilith]);
                    position.setAngleWithZenith(aspectValues[j][Planets.Zenith]);
                    position.setAngleWithVulcan(aspectValues[j][Planets.Vulcan]);
                    position.setAngleWithOtherPoint(aspectValues[j][Planets.OtherPoint]);
                    position.setAngleWithCeres(aspectValues[j][Planets.Ceres]);
                    position.setAngleWithPallas(aspectValues[j][Planets.Pallas]);
                    position.setAngleWithJuno(aspectValues[j][Planets.Juno]);
                    position.setAngleWithVesta(aspectValues[j][Planets.Vesta]);
                    position.setAngleWithChiron(aspectValues[j][Planets.Chiron]);
                    position.setAngleWithMidheaven(aspectValues[j][Planets.MC]);

                    //Zodiacal constellation
                    double ecart;
                    for (int k = 0; k <= ZodConstels.getLast(); k++)
                    {
                        double cTime = chartEvent.getCTime();
                        ecart = AstronomyMaths.mod(aux_coord - ZodConstels.getConstelBoundary(k, cTime) + 360.0, 360.0);
                        double delta_constel = AstronomyMaths.mod(ZodConstels.getConstelBoundary(AstronomyMaths.mod(k + 1, 13), cTime) - ZodConstels.getConstelBoundary(k, cTime), 360.0);

                        if (ecart < delta_constel)
                        {
                            position.setZodConstel(MainForm.zodConstelName[k]);
                        }
                    }

                    if (j < Planets.AS)
                    {
                        position.setDignity(Rulers.dignityCalculation(j, sign));
                        position.setDirection(planet.getRetroString(planet.getRetro()));

                        //House
                        if (tableau_flag == Astrology.POS_1)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        position.setHouse(MainForm.houseName[k]);
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        position.setHouse(MainForm.houseName[k]);
                                        break;
                                    }
                                }
                            }
                        }
                        else if (tableau_flag == Astrology.POS_1_2)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        position.setHouse(MainForm.houseName[k]);
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        position.setHouse(MainForm.houseName[k]);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                starLoginManager.setPosition(position);
            }
        }
    }

    private void formMouseMoved(MouseEvent evt)
    {
        if (evt.getButton() != 1 || bMousePressed == false)
        {
            return;
        }
        bMousePressed = false;
        bMouseMoving = true;
    }

    private void formMouseReleased(MouseEvent evt)
    {
        if (bMouseMoving == false && evt.getButton() != 1)
        {
            return;
        }

        double x = evt.getX();
        double y = evt.getY();
        MVector VEnd = new MVector((x - centerX) * zoom, (y - centerY) * zoom, 0.0);
        MVector vAux = VIni.ArrayListProduct(VIni, VEnd);

        //Calculate the angle from the ending and the begining mouse position
        deltaAngle = VIni.AngleArrayListsD(VIni, VEnd);
        if (vAux.getZ() < 0.0)
        {
            deltaAngle = -deltaAngle;
        }
        deltaAngle = dblAngle + deltaAngle;
        dblAngle = deltaAngle;
        bMouseMoving = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

        //Display the modified chart
        displayChart();
    }

    private void displayChart()
    {
        super.reFresh();
    }

    private void formMousePressed(MouseEvent evt)
    {
        if (evt.getButton() == 3)
        {
            mnuContext.show(this, evt.getX(), evt.getY());
        }
        else if (evt.getButton() == 1)
        {
            bMousePressed = true;
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            VIni = new MVector((evt.getX() - centerX) * zoom, (evt.getY() - centerY) * zoom, 0.0);
        }
    }

    private void btnGridActionPerformed(ActionEvent evt)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        ChartResultsKinds chartResultsKinds = new ChartResultsKinds();
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        new ChartResultsDialog(new javax.swing.JFrame(), true, chartResultsKinds, chartElements.getChartKind()).setVisible(true);
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        ChartResults chartResults = new ChartResults(chartElements, aspectKinds, aspectValues, relativeAspects, spire, chartResultsKinds, tableau_flag, starLoginManager);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void btnValuesActionPerformed(ActionEvent evt)
    {
        getEsotericData();
    }

    private void btnInterpretActionPerformed(ActionEvent evt)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        ChartInterpretation chartInterpretation = new ChartInterpretation(chartElements, aspectKinds, tableau_flag, starLoginManager);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void btnConfigsActionPerformed(ActionEvent evt)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        planetaryConfigurations = Astrology.getPlanetaryConfigs(aspectKinds);
        displayChart();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private double getStep()
    {
        int i = cboSteps.getSelectedIndex();
        switch (i)
        {
            case 0:
                return 1.0 / 60.0;
            case 1:
                return 1.0 / 12.0;
            case 2:
                return 1.0 / 6.0;
            case 3:
                return 1.0;
            case 4:
                return 6.0;
            case 5:
                return 24.0;
            case 6:
                return 168.0;
            case 7:
                return 720.0;
            case 8:
                return 2191.0;
            case 9:
                return 4383.0;
            case 10:
                return 8766.0;
            case 11:
                return 43830.0;
            case 12:
                return 87660.0;
            case 13:
                return 175320.0;
            case 14:
                return 876600.0;
            default:
                return 0.0;
        }
    }

    public void setChartElements(ChartElements chartElements, boolean bHouseCalc)
    {
        this.chartElements = chartElements;
        if (bHouseCalc == true)
        {
            Astrology.houseCalc(chartElements);
            displayChart();
        }
    }

    private void btnDecreaseActionPerformed(ActionEvent evt)
    {
        bIncrease = false;
        if (!btnAnimate.isSelected())
        {
            modifChart(-getStep());
        }
    }

    private void btnIncreaseActionPerformed(ActionEvent evt)
    {
        bIncrease = true;
        if (!btnAnimate.isSelected())
        {
            modifChart(getStep());
        }
    }

    private void btnAnimateActionPerformed(ActionEvent evt)
    {
        if (btnAnimate.isSelected())
        {
            btnAnimate.paintImmediately(btnAnimate.getBounds());
            timer.start();
        }
        else
        {
            timer.stop();
        }
    }

    private void btnRulersActionPerformed(ActionEvent evt)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Rulers rulers = new Rulers(chartElements, aspectKinds, cboRulersKind.getSelectedIndex(), cboRulersRef.getSelectedIndex(), pos1);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void btnOptionsActionPerformed(ActionEvent evt)
    {
        int oldCoordSys = chartElements.getCoordSys();
        int oldHouseSys = chartElements.getHouseSys();
        boolean oldTrueLilith = chartElements.getTrueLilith();

        new ChartOptions(new JFrame(), true, chartElements, this).setVisible(true);
        recalcForDomitudes();
        if (chartElements.getViewStars() || chartKind == ChartKind.local)
        {
            reCalcStars();
        }

        //if (chartElements.getViewBarycenter() || (!chartElements.getViewStars() && chartKind != ChartKind.local))
        else
        {
            if (oldTrueLilith != chartElements.getTrueLilith())
            {
                Astrology astrology = new Astrology(chartElements, chartEvent, chartKind, starLoginManager);
                header = modifHeader(chartEvent.getHeader());
                positions = chartElements.getChartCoords();
                pos1 = (AllCoord) positions.get(0);
                if (positions.size() > 1)
                {
                    pos2 = (AllCoord) positions.get(1);
                }
                displayChart();
            }
            else
            {
                if (chartElements.getViewBarycenter())
                {
                    Astrology.barycenterProcessing(chartElements, pos1);
                }

                String strSys = CoordSystem.getCoordSystemName(oldCoordSys) + " - " + HouseSystem.getHouseSystemName(oldHouseSys);
                int pos1b = header.indexOf(strSys);
                int pos2b = header.indexOf("\r\n", pos1b + 1);
                String str;
                if (pos2b < 0)
                {
                    str = header.substring(0, pos1b) + CoordSystem.getCoordSystemName(chartElements.getCoordSys()) + " - " + HouseSystem.getHouseSystemName(chartElements.getHouseSys());
                }
                else
                {
                    str = header.substring(0, pos1b) + CoordSystem.getCoordSystemName(chartElements.getCoordSys()) + " - " + HouseSystem.getHouseSystemName(chartElements.getHouseSys()) + header.substring(pos2b);
                }
                //oldCoordSys = chartElements.getCoordSys();
                //oldHouseSys = chartElements.getHouseSys();
                header = str;
                displayChart();
            }
            chartEvent.setHeader(header);
        }
    }

    private void btnPrintActionPerformed(ActionEvent evt)
    {
        try
        {
            PrinterJob printJob = PrinterJob.getPrinterJob();
            PageFormat pageFormat = new PageFormat();
            pageFormat.setOrientation(PageFormat.LANDSCAPE);

            printJob.setPrintable(this, pageFormat);

            boolean pDialogState;
            pDialogState = printJob.printDialog();
            Paper paper = pageFormat.getPaper();
            paper.setImageableArea(0.0, 0.0, paper.getWidth(), paper.getHeight());
            pageFormat.setPaper(paper);
            pageFormat = printJob.validatePage(pageFormat);
            printJob.setPrintable(this, pageFormat);

            if (pDialogState)
            {
                printJob.print();
            }
        }
        catch (AccessControlException ace)
        {
            JOptionPane.showMessageDialog(this, bundle.getString("PrinterAccessErrMessage"), bundle.getString("PrinterAccessError"), JOptionPane.ERROR_MESSAGE);
        }
        catch (IllegalArgumentException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (HeadlessException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (PrinterException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    private void cboZoomActionPerformed(ActionEvent evt)
    {
        if (bSetting == false)
        {
            zoom = zooms[cboZoom.getSelectedIndex()];
            setZoom(zoom);
            super.reFresh();
        }
    }

    // Variables declaration - do !modify
    private JToggleButton btnAnimate;
    private JButton btnDecrease;
    private JButton btnGrid;
    private JButton btnIncrease;
    private JButton btnInterpret;
    private JButton btnConfigs;
    private JButton btnOptions;
    private JButton btnPrint;
    private JButton btnRulers;
    private JButton btnSave;
    private JButton btnValues;
    private JComboBox cboRulersKind;
    private JComboBox cboRulersRef;
    private JComboBox cboSteps;
    private JComboBox cboZoom;
    private JPanel pnlBoutons;
    private JPanel pnlBoutons1;
    private JPanel pnlBoutons2;
    private JSeparator jSeparator1;
    private JSeparator jSeparator2;
    private JSeparator jSeparator3;
    private JSeparator jSeparator4;
    private JSeparator jSeparator5;
    private JLabel lblHarmoNB;
    private JLabel lblRulers;
    private JLabel lblNewDate;
    private JTextField txtHarmonicNB;
    private JPopupMenu mnuContext;
    private JRadioButtonMenuItem mnuHorizon;
    private JCheckBoxMenuItem mnuOtherSide;
    private JCheckBoxMenuItem mnuReverseHouses;
    private JCheckBoxMenuItem mnuPermute;
    private JRadioButtonMenuItem mnuZenith;
    private JRadioButtonMenuItem mnuAspect1;
    private JRadioButtonMenuItem mnuAspect12;
    private JRadioButtonMenuItem mnuAspect2;
    private JRadioButtonMenuItem mnuAspect21;
    private ButtonGroup grpAstronView;
    private ButtonGroup grpAspectsInOut;
    /*private JCheckBox chkHorizon;
     private JCheckBox chkZenith;
     private JCheckBox chkAspect1;
     private JCheckBox chkAspect2;
     private JCheckBox chkAspect12;
     private JCheckBox chkAspect21;*/
    //private JCheckBox chkOtherSide;
}
