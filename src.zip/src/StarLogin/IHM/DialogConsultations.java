/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;
import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.KTDate;
import StarLogin.IHM.components.KeyType.KTTime;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Consultation;
import StarLogin.Systeme.Data.Consultations;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.*;

/**
 *
 * @author Francois
 */
public class DialogConsultations extends JDialog
{
    private int kc; //key code
    private int cp; //caret position
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Consultations consultations;
    private int saveRow;
    private Consultation consultation;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private String consultationID;
    private String consultationClientName;
    private String consultationComments;
    private String consultationDate;
    private String consultationTime;
    private String consultationDue;
    private String consultationFee;
    private String consultationLocation;
    private String consultationServices;
    private boolean consultationPayed;
    private boolean consultationDone;
    private int consultationRow;
    private int consultationNbOfRows;
    private boolean bolSetting = true;
    private boolean bolDeleting = false;
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private DefaultComboBoxModel cmClients;
    private int clientID;
    private String clientid;
    private ImageIcon consultationPhoto;
    private Window parentForm;
    
    /**
     * Creates new form DialogClient
     */
    public DialogConsultations(java.awt.Frame parent, boolean modal, String consultationid)
    {
        super(parent, modal);        
        parentForm = (Window) parent;
        consultationID = consultationid;
        setDlg();
    }
    
    public DialogConsultations(java.awt.Dialog parent, boolean modal, String consultationid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        consultationID = consultationid;
        setDlg();
    }
    
    private void setDlg()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        setConsultationsCombos();
        resetLangue();

        initData();
        cboClientName.setMaximumRowCount(20);
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        this.setVisible(true);
        bolSetting = false;
    }
    
    
    private void resetLangue()
    {
        setTitle(bundle.getString("Consultations"));
        txtConsultationServices.setToolTipText(bundle.getString("DoubleClick4List"));
        btnFirstConsultation.setToolTipText(bundle.getString("FirstRecord"));
        btnPreviousConsultation.setToolTipText(bundle.getString("PreviousRecord"));
        txtCounterConsultation.setText(bundle.getString("NewConsultation"));
        btnNextConsultation.setToolTipText(bundle.getString("NextRecord"));
        btnLastConsultation.setToolTipText(bundle.getString("LastRecord"));
        btnRemoveConsultation.setToolTipText(bundle.getString("RemoveRecord"));
        btnAddConsultation.setToolTipText(bundle.getString("AddRecord"));
        btnOKConsultation.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS"));
        btnCancelConsultation.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS"));
        btnQueries2.setToolTipText(bundle.getString("DataGrids"));
        lblNomClient.setText(bundle.getString("consultationsCLIENTNAME"));
        lblConsultationDate.setText(bundle.getString("consultationsCONSULTATIONDATE"));
        lblConsultationTime.setText(bundle.getString("consultationsCONSULTATIONTIME"));
        lblConsultationLocation.setText(bundle.getString("consultationsLOCATION"));
        lblConsultationService.setText(bundle.getString("consultationsSERVICES"));
        lblConsultationFee.setText(bundle.getString("consultationsFEE"));
        lblConsultationDue.setText(bundle.getString("consultationsDUE"));
        jLabel12.setText(bundle.getString("consultationsCOMMENTS"));
        chkDone.setText(bundle.getString("consultationsDONE"));
        chkPayed.setText(bundle.getString("consultationsPAYED"));
    }

    @SuppressWarnings("unchecked")
    public final void setConsultationsCombos()
    {
        bolSetting = true;
        cmClients = MainClass.starLoginManager.getListe("SELECT ID,CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END FROM clients ORDER BY FIRSTNAME,OTHERNAMES,BIRTHDATE");
        DefaultComboBoxModel comboModel = (DefaultComboBoxModel) starLoginManager.getListe("SELECT CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END,ID FROM clients ORDER BY FIRSTNAME,OTHERNAMES,BIRTHDATE");
        cboClientName.setModel(comboModel);
        cboClientName.addItem(bundle.getString("NewClient"));
        cmClients.addElement("0");
        bolSetting = false;
    }
    
    public void setClient(String clid)
    {
        setConsultationsCombos();
        clientid = clid;
        if (clientid.equals(""))
            clientid = "-1";
        clientID = Integer.valueOf(clid).intValue();
        cboClientName.setSelectedIndex(cmClients.getIndexOf(clientID));
        consultationClientName = null2String(cboClientName.getSelectedItem());
    }
    
    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void initData()
    {
        initConsultationData(consultationID);
    }

    public void showRecord(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        consultationID = consultations.getIDFromRow(row);
        if (consultationID.equals("-1"))
        {
            initConsultationData("-1");
            return;
        }
        showRecord(consultationID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void showRecord(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        consultationID = strID;
        consultation = starLoginManager.getConsultation(consultationID);
        consultationRow = consultation.getRow();
        consultationNbOfRows = consultation.getRowNB();
        if (strID.equals("-1"))
            txtCounterConsultation.setText(bundle.getString("NewConsultation"));
        else
        {
            //consultationNbOfRows += 1;
            saveRow = consultationRow;
            txtCounterConsultation.setText(String.valueOf(consultationRow) + " / " + String.valueOf(consultationNbOfRows));
        }
        clientID = consultation.getClientID();
        consultationClientName = consultation.getClientName();
        consultationComments = consultation.getComments();
        consultationDate = consultation.getConsultationDate();
        consultationDate = MainClass.no2defaultDate(consultationDate, MainClass.DATE_CURRENT);
        consultationTime = consultation.getConsultationTime();
        consultationTime = MainClass.no2defaultTime(consultationTime, MainClass.TIME_CURRENT);
        consultationDue = consultation.getDue();
        consultationFee = consultation.getFee();
        consultationLocation = consultation.getLocation();
        consultationServices = consultation.getServices();
        consultationPhoto = consultation.getPicture();
        consultationDone = consultation.getDone();
        consultationPayed = consultation.getPayed();

        setConsultationDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        consultationClientName = null2String(cboClientName.getSelectedItem());
        if (bolEditing)
        {
            if (!consultationClientName.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Consultation").concat(" ").concat(consultationClientName),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingConsultation"),bundle.getString("Consultation").concat(" ").concat(consultationClientName),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }

    private void initConsultationData(String strID)
    {
        consultations = starLoginManager.getConsultations();
        if (consultations == null||consultations.getRecords().isEmpty())
            strID = "-1";
        if (strID.equals("-1"))
        {
            addRecord();
        }
        else
        {
            showRecord(strID);
        }
    }

    private void refreshConsultationRecord()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            consultations = starLoginManager.getConsultations();

            //show the consultation data
            showRecord(saveRow);
        }
    }

    public void setPicture(ImageIcon data)
    {
        consultationPhoto = data;
        bolEditing = true;
        setEditMode();
    }

    private void addRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveRow = consultationRow;
        showRecord("-1");
        consultationRow += 1;
        bolEditing = false;
        bolAdding = true;
        setEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void removeConsultationRec()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            if (consultationNbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, " tes-vous s�r de vouloir supprimer l'enregistrement en cours?", "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeConsultation(consultation);
                    consultations = starLoginManager.getConsultations();

                    if (consultationRow > 1)
                    {
                        showRecord(consultationRow - 1);
                    }
                    else
                    {
                        showRecord(consultationRow + 1);
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private void reloadConsultationPhoto()
    {
        jPnlConsultationPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, jPnlConsultationPhoto.getSize());
        jPnlConsultationPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(consultationPhoto);
    }

    private boolean save()
    {
        /*if (MainClass.getReadOnly())
        {
            JOptionPane.showMessageDialog(this, bundle.getString("CantUseThisFunctionInDemo"), "StarLogin", JOptionPane.WARNING_MESSAGE);
            return false;
        }*/
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setConsultationTextToData();
            consultation.setAdding(bolAdding);
            consultation.setPicture(consultationPhoto);
            consultation.setComments(consultationComments);
            consultation.setClientID(clientID);
            consultation.setClientName(consultationClientName);
            consultation.setConsultationDate(FDate.fr2us(consultationDate));
            consultation.setConsultationTime(FTime.set24(consultationTime));
            consultation.setDue(consultationDue);
            consultation.setFee(consultationFee);
            consultation.setLocation(consultationLocation);
            consultation.setServices(consultationServices);
            consultation.setDone(consultationDone);
            consultation.setPayed(consultationPayed);
            starLoginManager.setConsultation(consultation);

            if (bolAdding == true)
            {
                saveRow = consultation.getRow();
            }
            bolEditing = false;
            bolAdding = false;
            bolDeleting = false;
            refreshConsultationRecord();
            setConsultationNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }

    private void setConsultationNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }

    private void setConsultationDataToText()
    {
        bolSetting = true;
        txtConsultationComments.setText(consultationComments);
        cboClientName.setSelectedItem(consultationClientName);
        if (bolAdding)
        {
            consultationDate = MainClass.no2defaultDate(consultationDate, MainClass.DATE_CURRENT);
            consultationTime = MainClass.no2defaultTime(consultationTime, MainClass.TIME_CURRENT);
        }
        txtConsultationDate.setText(consultationDate);
        txtConsultationTime.setText(consultationTime);
        txtConsultationDue.setText(consultationDue);
        txtConsultationFee.setText(consultationFee);
        txtConsultationLocation.setText(consultationLocation);
        txtConsultationServices.setText(consultationServices);
        chkPayed.setSelected(consultationPayed);
        chkDone.setSelected(consultationDone);
        int carretPos = txtCounterConsultation.getCaretPosition();
        int len = txtCounterConsultation.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounterConsultation.setCaretPosition(carretPos);
        reloadConsultationPhoto();
        bolSetting = false;
        bolAdding = false;
        bolEditing = false;
        bolDeleting = false;
    }

    private void setConsultationTextToData()
    {
        String cid = null2String(cmClients.getElementAt(cboClientName.getSelectedIndex()));
        if (cid.equals(""))
            cid = "-1";
        clientID = Integer.valueOf(cid).intValue();
        consultationComments = txtConsultationComments.getText();
        consultationClientName = null2String(cboClientName.getSelectedItem());
        consultationDate = txtConsultationDate.getText();
        consultationTime = txtConsultationTime.getText();
        consultationDue = txtConsultationDue.getText();
        consultationFee = txtConsultationFee.getText();
        consultationLocation = txtConsultationLocation.getText();
        consultationServices = txtConsultationServices.getText();
        consultationDone = chkDone.isSelected();
        consultationPayed = chkPayed.isSelected();
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBoutons = new javax.swing.JPanel();
        btnFirstConsultation = new javax.swing.JButton();
        btnPreviousConsultation = new javax.swing.JButton();
        txtCounterConsultation = new javax.swing.JTextField();
        btnNextConsultation = new javax.swing.JButton();
        btnLastConsultation = new javax.swing.JButton();
        btnRemoveConsultation = new javax.swing.JButton();
        btnAddConsultation = new javax.swing.JButton();
        btnOKConsultation = new javax.swing.JButton();
        btnCancelConsultation = new javax.swing.JButton();
        btnQueries2 = new javax.swing.JButton();
        pnlConsultations = new javax.swing.JPanel();
        pnlDetailConsultation = new javax.swing.JPanel();
        pnlDetailConsultation2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPnlConsultationPhoto = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        pnlDetailConsultation1 = new javax.swing.JPanel();
        lblNomClient = new javax.swing.JLabel();
        cboClientName = new javax.swing.JComboBox();
        lblConsultationDate = new javax.swing.JLabel();
        txtConsultationDate = new javax.swing.JTextField();
        lblConsultationTime = new javax.swing.JLabel();
        txtConsultationTime = new javax.swing.JTextField();
        lblConsultationLocation = new javax.swing.JLabel();
        txtConsultationLocation = new javax.swing.JTextField();
        lblConsultationService = new javax.swing.JLabel();
        txtConsultationServices = new javax.swing.JTextField();
        lblConsultationFee = new javax.swing.JLabel();
        txtConsultationFee = new javax.swing.JTextField();
        lblConsultationDue = new javax.swing.JLabel();
        txtConsultationDue = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtConsultationComments = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        chkDone = new javax.swing.JCheckBox();
        chkPayed = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlBoutons.setName(""); // NOI18N
        pnlBoutons.setPreferredSize(new java.awt.Dimension(888, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 1, 5));

        btnFirstConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png"))); // NOI18N
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        btnFirstConsultation.setToolTipText(bundle.getString("FirstRecord")); // NOI18N
        btnFirstConsultation.setBorder(null);
        btnFirstConsultation.setContentAreaFilled(false);
        btnFirstConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFirstConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnFirstConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnFirstConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnFirstConsultation);

        btnPreviousConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
        btnPreviousConsultation.setToolTipText(bundle.getString("PreviousRecord")); // NOI18N
        btnPreviousConsultation.setBorder(null);
        btnPreviousConsultation.setContentAreaFilled(false);
        btnPreviousConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnPreviousConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnPreviousConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnPreviousConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnPreviousConsultation);

        txtCounterConsultation.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCounterConsultation.setMaximumSize(null);
        txtCounterConsultation.setPreferredSize(new java.awt.Dimension(200, 22));
        txtCounterConsultation.setSelectionColor(new java.awt.Color(55, 155, 255));
        txtCounterConsultation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCounterConsultationKeyReleased(evt);
            }
        });
        pnlBoutons.add(txtCounterConsultation);

        btnNextConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
        btnNextConsultation.setToolTipText(bundle.getString("NextRecord")); // NOI18N
        btnNextConsultation.setBorder(null);
        btnNextConsultation.setContentAreaFilled(false);
        btnNextConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnNextConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnNextConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnNextConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnNextConsultation);

        btnLastConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png"))); // NOI18N
        btnLastConsultation.setToolTipText(bundle.getString("LastRecord")); // NOI18N
        btnLastConsultation.setBorder(null);
        btnLastConsultation.setContentAreaFilled(false);
        btnLastConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnLastConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnLastConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnLastConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnLastConsultation);

        btnRemoveConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveConsultation.setToolTipText(bundle.getString("RemoveRecord")); // NOI18N
        btnRemoveConsultation.setBorder(null);
        btnRemoveConsultation.setContentAreaFilled(false);
        btnRemoveConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemoveConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnRemoveConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnRemoveConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveConsultation);

        btnAddConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddConsultation.setToolTipText(bundle.getString("AddRecord")); // NOI18N
        btnAddConsultation.setBorder(null);
        btnAddConsultation.setContentAreaFilled(false);
        btnAddConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAddConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnAddConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnAddConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddConsultation);

        btnOKConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOKConsultation.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS")); // NOI18N
        btnOKConsultation.setBorder(null);
        btnOKConsultation.setContentAreaFilled(false);
        btnOKConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOKConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnOKConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnOKConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOKConsultation);

        btnCancelConsultation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancelConsultation.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS")); // NOI18N
        btnCancelConsultation.setBorder(null);
        btnCancelConsultation.setContentAreaFilled(false);
        btnCancelConsultation.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCancelConsultation.setMaximumSize(new java.awt.Dimension(18, 18));
        btnCancelConsultation.setMinimumSize(new java.awt.Dimension(18, 18));
        btnCancelConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelConsultationActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancelConsultation);

        btnQueries2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
        btnQueries2.setToolTipText(bundle.getString("DataGrids")); // NOI18N
        btnQueries2.setBorder(null);
        btnQueries2.setContentAreaFilled(false);
        btnQueries2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnQueries2.setMaximumSize(new java.awt.Dimension(31, 31));
        btnQueries2.setMinimumSize(new java.awt.Dimension(29, 29));
        btnQueries2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQueries2ActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnQueries2);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        pnlConsultations.setLayout(new java.awt.BorderLayout());

        pnlDetailConsultation.setPreferredSize(new java.awt.Dimension(910, 480));
        pnlDetailConsultation.setLayout(new java.awt.BorderLayout());

        pnlDetailConsultation2.setPreferredSize(new java.awt.Dimension(400, 480));
        pnlDetailConsultation2.setLayout(new java.awt.BorderLayout());

        jPanel3.setPreferredSize(new java.awt.Dimension(100, 5));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        pnlDetailConsultation2.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jPanel21.setPreferredSize(new java.awt.Dimension(5, 100));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 482, Short.MAX_VALUE)
        );

        pnlDetailConsultation2.add(jPanel21, java.awt.BorderLayout.WEST);

        jPnlConsultationPhoto.setPreferredSize(new java.awt.Dimension(400, 480));
        jPnlConsultationPhoto.setRequestFocusEnabled(false);
        jPnlConsultationPhoto.setLayout(new java.awt.BorderLayout());
        pnlDetailConsultation2.add(jPnlConsultationPhoto, java.awt.BorderLayout.CENTER);

        pnlDetailConsultation.add(pnlDetailConsultation2, java.awt.BorderLayout.WEST);

        jPanel2.setPreferredSize(new java.awt.Dimension(5, 100));
        pnlDetailConsultation.add(jPanel2, java.awt.BorderLayout.CENTER);

        pnlDetailConsultation1.setPreferredSize(new java.awt.Dimension(445, 480));
        pnlDetailConsultation1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 1));

        lblNomClient.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNomClient.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblNomClient.setOpaque(true);
        lblNomClient.setPreferredSize(new java.awt.Dimension(140, 22));
        pnlDetailConsultation1.add(lblNomClient);

        cboClientName.setMaximumRowCount(20);
        cboClientName.setAutoscrolls(true);
        cboClientName.setKeySelectionManager(new MultiKeySelectionManager());
        cboClientName.setPreferredSize(new java.awt.Dimension(300, 22));
        cboClientName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboClientNameActionPerformed(evt);
            }
        });
        pnlDetailConsultation1.add(cboClientName);

        lblConsultationDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationDate.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationDate.setOpaque(true);
        lblConsultationDate.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationDate);

        txtConsultationDate.setPreferredSize(new java.awt.Dimension(100, 22));
        txtConsultationDate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtConsultationDateMouseClicked(evt);
            }
        });
        txtConsultationDate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationDateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationDateKeyTyped(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationDate);

        lblConsultationTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationTime.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationTime.setOpaque(true);
        lblConsultationTime.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationTime);

        txtConsultationTime.setPreferredSize(new java.awt.Dimension(100, 22));
        txtConsultationTime.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtConsultationTimeFocusLost(evt);
            }
        });
        txtConsultationTime.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationTimeKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationTimeKeyPressed(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationTime);

        lblConsultationLocation.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationLocation.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationLocation.setOpaque(true);
        lblConsultationLocation.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationLocation);

        txtConsultationLocation.setPreferredSize(new java.awt.Dimension(255, 22));
        txtConsultationLocation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationLocationkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationLocationKeyPressed(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationLocation);

        lblConsultationService.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationService.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationService.setOpaque(true);
        lblConsultationService.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationService);

        txtConsultationServices.setPreferredSize(new java.awt.Dimension(255, 22));
        txtConsultationServices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtConsultationServicesMouseClicked(evt);
            }
        });
        txtConsultationServices.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationServiceskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationServicesKeyPressed(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationServices);

        lblConsultationFee.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationFee.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationFee.setOpaque(true);
        lblConsultationFee.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationFee);

        txtConsultationFee.setPreferredSize(new java.awt.Dimension(100, 22));
        txtConsultationFee.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationFeekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationFeeKeyPressed(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationFee);

        lblConsultationDue.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConsultationDue.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblConsultationDue.setOpaque(true);
        lblConsultationDue.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailConsultation1.add(lblConsultationDue);

        txtConsultationDue.setPreferredSize(new java.awt.Dimension(100, 22));
        txtConsultationDue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationDuekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationDueKeyPressed(evt);
            }
        });
        pnlDetailConsultation1.add(txtConsultationDue);

        jPanel4.setPreferredSize(new java.awt.Dimension(41, 10));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 41, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        pnlDetailConsultation1.add(jPanel4);

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setAlignmentY(1.0F);
        jLabel12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel12.setOpaque(true);
        jLabel12.setPreferredSize(new java.awt.Dimension(110, 22));
        pnlDetailConsultation1.add(jLabel12);

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(440, 246));

        txtConsultationComments.setPreferredSize(new java.awt.Dimension(440, 245));
        txtConsultationComments.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConsultationCommentskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConsultationCommentsKeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(txtConsultationComments);

        pnlDetailConsultation1.add(jScrollPane4);

        jPanel1.setPreferredSize(new java.awt.Dimension(440, 44));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 45, 15));

        chkDone.setAlignmentX(1.0F);
        chkDone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chkDone.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        chkDone.setPreferredSize(new java.awt.Dimension(150, 23));
        chkDone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDoneActionPerformed(evt);
            }
        });
        jPanel1.add(chkDone);

        chkPayed.setAlignmentX(1.0F);
        chkPayed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chkPayed.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        chkPayed.setPreferredSize(new java.awt.Dimension(150, 23));
        chkPayed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPayedActionPerformed(evt);
            }
        });
        jPanel1.add(chkPayed);

        pnlDetailConsultation1.add(jPanel1);

        pnlDetailConsultation.add(pnlDetailConsultation1, java.awt.BorderLayout.EAST);

        pnlConsultations.add(pnlDetailConsultation, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlConsultations, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_formWindowClosing

    private void btnFirstConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstConsultationActionPerformed
    {//GEN-HEADEREND:event_btnFirstConsultationActionPerformed
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(1);
        }
    }//GEN-LAST:event_btnFirstConsultationActionPerformed

    private void btnPreviousConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousConsultationActionPerformed
    {//GEN-HEADEREND:event_btnPreviousConsultationActionPerformed
        if ((consultationRow > 1) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(consultationRow - 1);
        }
    }//GEN-LAST:event_btnPreviousConsultationActionPerformed

    private void txtCounterConsultationKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCounterConsultationKeyReleased
    {//GEN-HEADEREND:event_txtCounterConsultationKeyReleased
        if ((bolSetting == false) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            String value = txtCounterConsultation.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            consultationRow = new Integer(value).intValue();
            if (consultationRow > consultationNbOfRows)
            {
                consultationRow = consultationNbOfRows;
            }
            showRecord(consultationRow);
        }
    }//GEN-LAST:event_txtCounterConsultationKeyReleased

    private void btnNextConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextConsultationActionPerformed
    {//GEN-HEADEREND:event_btnNextConsultationActionPerformed
        if ((consultationRow < consultationNbOfRows) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(consultationRow + 1);
        }
    }//GEN-LAST:event_btnNextConsultationActionPerformed

    private void btnLastConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastConsultationActionPerformed
    {//GEN-HEADEREND:event_btnLastConsultationActionPerformed
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(consultationNbOfRows);
        }
    }//GEN-LAST:event_btnLastConsultationActionPerformed

    private void btnRemoveConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveConsultationActionPerformed
    {//GEN-HEADEREND:event_btnRemoveConsultationActionPerformed
        removeConsultationRec();
    }//GEN-LAST:event_btnRemoveConsultationActionPerformed

    private void btnAddConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddConsultationActionPerformed
    {//GEN-HEADEREND:event_btnAddConsultationActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddConsultationActionPerformed

    private void btnOKConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKConsultationActionPerformed
    {//GEN-HEADEREND:event_btnOKConsultationActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKConsultationActionPerformed

    private void btnCancelConsultationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelConsultationActionPerformed
    {//GEN-HEADEREND:event_btnCancelConsultationActionPerformed
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelConsultationActionPerformed

    private void btnQueries2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnQueries2ActionPerformed
    {//GEN-HEADEREND:event_btnQueries2ActionPerformed
        DialogQueryTool gf = new DialogQueryTool(6, this, true);
    }//GEN-LAST:event_btnQueries2ActionPerformed

    private void cboClientNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboClientNameActionPerformed
    {//GEN-HEADEREND:event_cboClientNameActionPerformed
        if (bolSetting == false)
        {
            String strText = null2String(cboClientName.getSelectedItem());
            if (strText.equals(""))
            {
                return;
            }
            String id = MainClass.starLoginManager.getMainFieldID_S("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END", strText);
            if (!id.equals("-1"))
            {
                int pos = strText.indexOf(" || ");
                if (pos > 0)
                {
                    strText = strText.substring(0, pos);
                }
                consultationClientName = strText;
                clientid = id;
            }
            else
            {
                clientid = "-1";
                DialogClient dlgCl = new DialogClient(this, true, "-1", "", "", "");
            }

            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboClientNameActionPerformed

    private void txtConsultationDateMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtConsultationDateMouseClicked
    {//GEN-HEADEREND:event_txtConsultationDateMouseClicked
        if (evt.getButton() == 1)
        {
            String sdate = txtConsultationDate.getText();
            consultationDate = DlgCalendar.ShowCalendar(sdate);
            consultationDate = MainClass.getFormatedDate(consultationDate);
            txtConsultationDate.setText(consultationDate);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationDateMouseClicked

    private void txtConsultationDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationDateKeyPressed
    {//GEN-HEADEREND:event_txtConsultationDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtConsultationDate.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationDate.setText(consultationDate);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            {
                td = new KTDate(evt, txtConsultationDate, kc);
            }
        }
    }//GEN-LAST:event_txtConsultationDateKeyPressed

    private void txtConsultationDateKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationDateKeyTyped
    {//GEN-HEADEREND:event_txtConsultationDateKeyTyped
        KTDate d = new KTDate(evt, txtConsultationDate, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp > 0)
        {
            txtConsultationDate.setCaretPosition(cp - 1);
        }
    }//GEN-LAST:event_txtConsultationDateKeyTyped

    private void txtConsultationTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtConsultationTimeFocusLost
    {//GEN-HEADEREND:event_txtConsultationTimeFocusLost
        FTime t = new FTime(txtConsultationTime.getText());
        String sText = t.getTime();
        txtConsultationTime.setText(sText);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtConsultationTimeFocusLost

    private void txtConsultationTimeKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationTimeKeyTyped
    {//GEN-HEADEREND:event_txtConsultationTimeKeyTyped
        KTTime ti = new KTTime(evt, txtConsultationTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp > 0)
        {
            txtConsultationTime.setCaretPosition(cp - 1);
        }
    }//GEN-LAST:event_txtConsultationTimeKeyTyped

    private void txtConsultationTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationTimeKeyPressed
    {//GEN-HEADEREND:event_txtConsultationTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtConsultationTime.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationTime.setText(consultationTime);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            {
                t = new KTTime(evt, txtConsultationTime, kc);
            }
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationTimeKeyPressed

    private void txtConsultationLocationkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationLocationkeyTyped
    {//GEN-HEADEREND:event_txtConsultationLocationkeyTyped
        int size = 100;//new Integer(String.valueOf(consultations.getSizes().get(3))).intValue();
        if (txtConsultationLocation.getText().length() >= size)
        {
            txtConsultationLocation.setText(txtConsultationLocation.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtConsultationLocationkeyTyped

    private void txtConsultationLocationKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationLocationKeyPressed
    {//GEN-HEADEREND:event_txtConsultationLocationKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationLocation.setText(consultationLocation);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationLocationKeyPressed

    private void txtConsultationServicesMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtConsultationServicesMouseClicked
    {//GEN-HEADEREND:event_txtConsultationServicesMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtConsultationServices, "services", "SERVICENAME", bundle.getString("servicesSERVICENAME"), false, null, false, null, true);
            txtConsultationServices.setText(strText);
        }
    }//GEN-LAST:event_txtConsultationServicesMouseClicked

    private void txtConsultationServiceskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationServiceskeyTyped
    {//GEN-HEADEREND:event_txtConsultationServiceskeyTyped
        int size = 255;//new Integer(String.valueOf(consultations.getSizes().get(3))).intValue();
        if (txtConsultationServices.getText().length() >= size)
        {
            txtConsultationServices.setText(txtConsultationServices.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtConsultationServiceskeyTyped

    public void setService(String service)
    {
        txtConsultationServices.setText(service);
    }
    
    
    private void txtConsultationServicesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationServicesKeyPressed
    {//GEN-HEADEREND:event_txtConsultationServicesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtConsultationServices, "consultations", "SERVICES", bundle.getString("consultationsSERVICES"), true, bundle.getString("NewService"), false, null, true);
            if (strText.equals(""))
            {
                txtConsultationServices.setText("");
            }
            else if (strText.equals(bundle.getString("NewService")))
            {
                DialogServices ds = new DialogServices(this, true, "-1");
            }
            else
            {
                txtConsultationServices.setText(strText);
            }
        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationServices.setText(consultationServices);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationServicesKeyPressed

    private void txtConsultationFeekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationFeekeyTyped
    {//GEN-HEADEREND:event_txtConsultationFeekeyTyped
        int size = 20;//new Integer(String.valueOf(consultations.getSizes().get(3))).intValue();
        if (txtConsultationFee.getText().length() >= size)
        {
            txtConsultationFee.setText(txtConsultationFee.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtConsultationFeekeyTyped

    private void txtConsultationFeeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationFeeKeyPressed
    {//GEN-HEADEREND:event_txtConsultationFeeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationFee.setText(consultationFee);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationFeeKeyPressed

    private void txtConsultationDuekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationDuekeyTyped
    {//GEN-HEADEREND:event_txtConsultationDuekeyTyped
        int size = 20;//new Integer(String.valueOf(consultations.getSizes().get(3))).intValue();
        if (txtConsultationDue.getText().length() >= size)
        {
            txtConsultationDue.setText(txtConsultationDue.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtConsultationDuekeyTyped

    private void txtConsultationDueKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationDueKeyPressed
    {//GEN-HEADEREND:event_txtConsultationDueKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationDue.setText(consultationDue);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationDueKeyPressed

    private void txtConsultationCommentskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationCommentskeyTyped
    {//GEN-HEADEREND:event_txtConsultationCommentskeyTyped
        int size = 10000;//new Integer(String.valueOf(consultations.getSizes().get(3))).intValue();
        if (txtConsultationComments.getText().length() >= size)
        {
            txtConsultationComments.setText(txtConsultationComments.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtConsultationCommentskeyTyped

    private void txtConsultationCommentsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConsultationCommentsKeyPressed
    {//GEN-HEADEREND:event_txtConsultationCommentsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtConsultationComments.setText(consultationComments);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtConsultationCommentsKeyPressed

    private void chkDoneActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDoneActionPerformed
    {//GEN-HEADEREND:event_chkDoneActionPerformed
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkDoneActionPerformed

    private void chkPayedActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkPayedActionPerformed
    {//GEN-HEADEREND:event_chkPayedActionPerformed
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkPayedActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddConsultation;
    private javax.swing.JButton btnCancelConsultation;
    private javax.swing.JButton btnFirstConsultation;
    private javax.swing.JButton btnLastConsultation;
    private javax.swing.JButton btnNextConsultation;
    private javax.swing.JButton btnOKConsultation;
    private javax.swing.JButton btnPreviousConsultation;
    private javax.swing.JButton btnQueries2;
    private javax.swing.JButton btnRemoveConsultation;
    private javax.swing.JComboBox cboClientName;
    private javax.swing.JCheckBox chkDone;
    private javax.swing.JCheckBox chkPayed;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPnlConsultationPhoto;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblConsultationDate;
    private javax.swing.JLabel lblConsultationDue;
    private javax.swing.JLabel lblConsultationFee;
    private javax.swing.JLabel lblConsultationLocation;
    private javax.swing.JLabel lblConsultationService;
    private javax.swing.JLabel lblConsultationTime;
    private javax.swing.JLabel lblNomClient;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlConsultations;
    private javax.swing.JPanel pnlDetailConsultation;
    private javax.swing.JPanel pnlDetailConsultation1;
    private javax.swing.JPanel pnlDetailConsultation2;
    private javax.swing.JTextPane txtConsultationComments;
    private javax.swing.JTextField txtConsultationDate;
    private javax.swing.JTextField txtConsultationDue;
    private javax.swing.JTextField txtConsultationFee;
    private javax.swing.JTextField txtConsultationLocation;
    private javax.swing.JTextField txtConsultationServices;
    private javax.swing.JTextField txtConsultationTime;
    private javax.swing.JTextField txtCounterConsultation;
    // End of variables declaration//GEN-END:variables
}
