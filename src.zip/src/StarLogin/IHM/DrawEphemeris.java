package StarLogin.IHM;


import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDegree;
import StarLogin.Systeme.Enum.Coordinate;
import StarLogin.Systeme.Enum.Planets;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DrawEphemeris extends JPanel
{
    private final int topMargin = 30;
    private final int leftMargin = 15;
    private final int planetSize = 16;
    private final int characterSize = 12;
    private ArrayList allCoords = null;
    private int curCoord = 0;
    private String sHeader1 = "";
    private String sHeader2 = "";
    private String sHeader3 = "";
    private ArrayList colors = new ArrayList();
    private ArrayList dates = new ArrayList();
    private int xVal = 0;
    private int yVal = 0;
    
    /** Creates a new instance of DrawEphemeris */
    public DrawEphemeris()
    {
    }
    
    public void setCoords(ArrayList allCoords)
    {
        this.allCoords = allCoords;
    }
    
    public void setColors(ArrayList colors)
    {
        this.colors = colors;
    }
    
    public void setCurCoord(int curCoord)
    {
        this.curCoord = curCoord;
    }
    
    public void setHeader1(String sHeader)
    {
        this.sHeader1 = sHeader;
    }
    
    public void setHeader2(String sHeader)
    {
        this.sHeader2 = sHeader;
    }
    
    public void setHeader3(String sHeader)
    {
        this.sHeader3 = sHeader;
    }
    
    public void reFresh(int xVal, int yVal)
    {
        this.xVal = xVal;
        this.yVal = yVal;
        this.repaint();
    }
    
    @Override
    public void paint(Graphics g)
    {
        Dimension d = getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.clearRect(0, 0, d.width, d.height);
        render((int)d.getWidth(), (int)d.getHeight(), g2, xVal, yVal);
        g2.dispose();
    }
    
    public void setDates(ArrayList dates)
    {
        this.dates = dates;
    }
    
    public void render(int w, int h, Graphics2D g2, int x, int y)
    {
        if (allCoords == null) return;
        ArrayList oldCoords = new ArrayList();
        int curY = y;
        int curX;// = x;
        String sDegrees;
        float dot[] = {1f,2f,3f};
        int max = 0;
        boolean bLat = false;
        
        //Header
        g2.setColor(Color.black);
        g2.setFont(new Font("arial", Font.BOLD, characterSize));
        g2.drawString(sHeader1, leftMargin, topMargin);
        //int stringWidth = g2.getFontMetrics().stringWidth("N");
        int stringHeight = g2.getFontMetrics().getHeight();
        g2.drawString(sHeader2, leftMargin, topMargin + stringHeight);
        curY += topMargin + stringHeight * 2;
        g2.drawString(sHeader3, leftMargin, curY);
        curY += topMargin + stringHeight * 4;
        g2.setStroke(new BasicStroke(0.5f));
        
        if (curCoord == Coordinate.GeoLat || curCoord == Coordinate.HelioLat || curCoord == Coordinate.Declination || curCoord == Coordinate.Altitude)
        {
            curX = leftMargin + x;
            g2.drawLine(curX, curY, curX, h);
            sDegrees = "-90�";
            g2.drawString(sDegrees, curX, curY);
            sDegrees = "0�";
            curX = leftMargin + x + 180;
            g2.drawLine(curX, curY, curX, h);
            g2.drawString(sDegrees, curX, curY);
            sDegrees = "90�";
            curX = leftMargin + x + 360;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            g2.setStroke(new BasicStroke(1.0f, 0, 0, 3.0f, dot, 0.0f));
            g2.drawLine(leftMargin + x + 20, curY, leftMargin + x + 20, h);
            g2.drawLine(leftMargin + x + 40, curY, leftMargin + x + 40, h);
            g2.drawLine(leftMargin + x + 60, curY, leftMargin + x + 60, h);
            g2.drawLine(leftMargin + x + 80, curY, leftMargin + x + 80, h);
            g2.drawLine(leftMargin + x + 100, curY, leftMargin + x + 100, h);
            g2.drawLine(leftMargin + x + 120, curY, leftMargin + x + 120, h);
            g2.drawLine(leftMargin + x + 140, curY, leftMargin + x + 140, h);
            g2.drawLine(leftMargin + x + 160, curY, leftMargin + x + 160, h);
            g2.drawLine(leftMargin + x + 200, curY, leftMargin + x + 200, h);
            g2.drawLine(leftMargin + x + 220, curY, leftMargin + x + 220, h);
            g2.drawLine(leftMargin + x + 240, curY, leftMargin + x + 240, h);
            g2.drawLine(leftMargin + x + 260, curY, leftMargin + x + 260, h);
            g2.drawLine(leftMargin + x + 280, curY, leftMargin + x + 280, h);
            g2.drawLine(leftMargin + x + 300, curY, leftMargin + x + 300, h);
            g2.drawLine(leftMargin + x + 320, curY, leftMargin + x + 320, h);
            g2.drawLine(leftMargin + x + 340, curY, leftMargin + x + 340, h);
            max = 360 + x + leftMargin;
            bLat = true;
        }
        else
        {
            sDegrees = "0�";
            curX = leftMargin + x;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            sDegrees = "90�";
            curX = leftMargin + x + 180;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            sDegrees = "180�";
            curX = leftMargin + x + 360;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            sDegrees = "270�";
            curX = leftMargin + x + 540;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            sDegrees = "360�";
            curX = leftMargin + x + 720;
            g2.drawString(sDegrees, curX, curY);
            g2.drawLine(curX, curY, curX, h);
            g2.setStroke(new BasicStroke(0.5f, 0, 0, 3.0f, dot, 0.0f));
            g2.drawLine(leftMargin + x + 20, curY, leftMargin + x + 20, h);
            g2.drawLine(leftMargin + x + 40, curY, leftMargin + x + 40, h);
            g2.drawLine(leftMargin + x + 60, curY, leftMargin + x + 60, h);
            g2.drawLine(leftMargin + x + 80, curY, leftMargin + x + 80, h);
            g2.drawLine(leftMargin + x + 100, curY, leftMargin + x + 100, h);
            g2.drawLine(leftMargin + x + 120, curY, leftMargin + x + 120, h);
            g2.drawLine(leftMargin + x + 140, curY, leftMargin + x + 140, h);
            g2.drawLine(leftMargin + x + 160, curY, leftMargin + x + 160, h);
            g2.drawLine(leftMargin + x + 200, curY, leftMargin + x + 200, h);
            g2.drawLine(leftMargin + x + 220, curY, leftMargin + x + 220, h);
            g2.drawLine(leftMargin + x + 240, curY, leftMargin + x + 240, h);
            g2.drawLine(leftMargin + x + 260, curY, leftMargin + x + 260, h);
            g2.drawLine(leftMargin + x + 280, curY, leftMargin + x + 280, h);
            g2.drawLine(leftMargin + x + 300, curY, leftMargin + x + 300, h);
            g2.drawLine(leftMargin + x + 320, curY, leftMargin + x + 320, h);
            g2.drawLine(leftMargin + x + 340, curY, leftMargin + x + 340, h);
            g2.drawLine(leftMargin + x + 380, curY, leftMargin + x + 380, h);
            g2.drawLine(leftMargin + x + 400, curY, leftMargin + x + 400, h);
            g2.drawLine(leftMargin + x + 420, curY, leftMargin + x + 420, h);
            g2.drawLine(leftMargin + x + 440, curY, leftMargin + x + 440, h);
            g2.drawLine(leftMargin + x + 460, curY, leftMargin + x + 460, h);
            g2.drawLine(leftMargin + x + 480, curY, leftMargin + x + 480, h);
            g2.drawLine(leftMargin + x + 500, curY, leftMargin + x + 500, h);
            g2.drawLine(leftMargin + x + 520, curY, leftMargin + x + 520, h);
            g2.drawLine(leftMargin + x + 560, curY, leftMargin + x + 560, h);
            g2.drawLine(leftMargin + x + 580, curY, leftMargin + x + 580, h);
            g2.drawLine(leftMargin + x + 600, curY, leftMargin + x + 600, h);
            g2.drawLine(leftMargin + x + 620, curY, leftMargin + x + 620, h);
            g2.drawLine(leftMargin + x + 640, curY, leftMargin + x + 640, h);
            g2.drawLine(leftMargin + x + 660, curY, leftMargin + x + 660, h);
            g2.drawLine(leftMargin + x + 680, curY, leftMargin + x + 680, h);
            g2.drawLine(leftMargin + x + 700, curY, leftMargin + x + 700, h);
            max = 720 + x + leftMargin;
        }
        //curX = leftMargin + x + 740;
        //g2.drawString("", curX, curY);
        
        //Values
        g2.setFont(new Font("starlogin", Font.BOLD, planetSize));
        stringHeight = g2.getFontMetrics().getHeight();
        curY += stringHeight;
        for (int i=0; i< allCoords.size(); i++)
        {
            g2.setColor(Color.black);
            curX = leftMargin + x;
            if (AstronomyMaths.modulo(i, 15) == 14)
            {
                g2.setStroke(new BasicStroke(0.5f));
                g2.drawString(dates.get(i).toString(), curX, curY);
                g2.drawLine(curX, curY, 720, curY);
            }
            else
            {
                g2.setStroke(new BasicStroke(0.5f, 0, 0, 3.0f, dot, 0.0f));
                g2.drawLine(curX, curY, 720, curY);
            }
            
            g2.setStroke(new BasicStroke(1f));
            ArrayList coords = (ArrayList)allCoords.get(i);
            for (int j=0; j< coords.size(); j++)
            {
                //get the planet color
                Integer iColor = (Integer)colors.get(j);
                g2.setColor(new Color(iColor.intValue()));
                
                //get the coordinate value
                double value = (new FDegree(coords.get(j).toString()).getDecimalDegree());
                if (bLat) value += 90.0;
                curX = (int)(value * 2.0) + leftMargin + x;
                if (i == 0)
                {
                    //display the planet symbol
                    if (j == Planets.NorthNode)
                    {
                        g2.drawString(Planets.getPlanetSymbol(Planets.Chiron), curX, curY);
                    }
                    else
                    {
                        g2.drawString(Planets.getPlanetSymbol(j), curX, curY);
                    }
                }
                else
                {
                    //get the old value
                    double oldValue = new FDegree(oldCoords.get(j).toString()).getDecimalDegree();
                    if (bLat) oldValue += 90.0;
                    
                    //case of value going trough the zero
                    if (Math.abs(value - oldValue) > 180.0)
                    {
                        //(This appends only with the coordinates between 0 and 360)
                        if (oldValue > 180.0)
                        {
                            oldValue -= 360.0;
                        }
                        else
                        {
                            oldValue += 360.0;
                        }
                    }
                    
                    //draw the curve
                    int oldCurX = (int)(oldValue * 2.0) + leftMargin + x;
                    g2.drawLine(oldCurX, curY - 10, curX, curY);
                }
            }
            curY += 10;
            oldCoords = coords;
        }
    }
}
