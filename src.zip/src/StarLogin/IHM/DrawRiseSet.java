package StarLogin.IHM;

import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.Enum.Planets;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.print.PrinterJob;
import java.security.AccessControlException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DrawRiseSet extends RiseSetSurface
{
    private int planet;
    private ChartEvent event;
    private RiseSetMeridian rsm;
    private static final String FT_ARIAL = "arial";
    private static final String FT_STARLOGIN = "StarLogin";
    private Color planetColor;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    public DrawRiseSet()
    {
    }
    
    public void setColor(Color planetColor)
    {
        this.planetColor = planetColor;
    }
    
    public void setRSM(RiseSetMeridian rsm)
    {
        this.rsm = rsm;
    }
    
    public void setEvent(ChartEvent event)
    {
        this.event = event;
    }
    
    public void setPlanet(int planet)
    {
        this.planet = planet;
    }
    
    @Override
    public void reFresh()
    {
        super.reFresh();
    }
    
    public void print()
    {
        try
        {
            PrinterJob printJob = PrinterJob.getPrinterJob();
            printJob.setPrintable(this);
            boolean pDialogState;
            pDialogState = printJob.printDialog();
            if (pDialogState)
            {
                printJob.print();
            }
        }
        catch (AccessControlException ace)
        {
            JOptionPane.showMessageDialog(this, bundle.getString("PrinterAccessErrMessage"), bundle.getString("PrinterAccessError"), JOptionPane.ERROR_MESSAGE);
        }
        catch (Exception ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    public void render(int w0, int h0, java.awt.Graphics2D g2, int x0, int y0)
    {
        if (event == null || rsm == null) return;
        double heure_m;
        double time_lag;
        int x2;
        int y2;
        int x;
        int y;
        int w;
        int h;
        int i;
        double tan_obl;
        int charSize = 16;
        int curX;
        int curY;
        int width;
        int height;
        int stringWidth;
        int stringHeight;
        double ratio_H;
        double ratio_W;
        boolean flag_r;
        boolean flag_s;
        //=========================================================================
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/world.jpg"));
        if (iconImage == null) return;
        Image icon = iconImage.getImage();
        if (icon == null) return;
        width = icon.getWidth(this);
        height = icon.getHeight(this);
        g2.drawImage(icon, 0, 0, this);
        
        g2.setFont(new Font(FT_ARIAL, Font.PLAIN, 10));
        g2.setColor(Color.black);
        //stringWidth = g2.getFontMetrics().stringWidth("w") / 2;
        stringHeight = g2.getFontMetrics().getHeight();
        time_lag = event.getTimeLag();
        heure_m = new FTime(rsm.getMeridianTime()).getDecimalHour();
        
        //show comments
        String comments = event.getEvent().getPlace() + "  ( " + bundle.getString("Latitude") + " :  " + event.getEvent().getLatitude() + " ;  " + bundle.getString("Longitude") + " :  " + event.getEvent().getLongitude() + " )       " + event.getEvent().getLocalDate() + " - " + event.getEvent().getLocalTime();
        x = 10;
        y = (int)((double)height - (double)stringHeight / 3.0);
        g2.drawString(comments, x, y);
        g2.setFont(new Font(FT_STARLOGIN, Font.BOLD, 16));
        
        //show locations on the world map
        //-------------------------------
        ratio_H = height / 180.0;
        ratio_W = width / 360.0;
        
        //equator, Greenwich meridian and ecliptic
        float dash[] = {2f,3f,5f};
        g2.setStroke(new BasicStroke(1.0f, 0, 0, 7.0f, dash, 0.0f));
        x = (int)(height / 2.0);
        y = (int)(width / 2.0);
        g2.setColor(new Color(128, 255, 0));
        g2.drawLine(0, x, width, x);
        g2.drawLine(y, 0, y, height);
        x2 = 0;
        y2 = 0;
        tan_obl = AstronomyMaths.tanD(event.getObliquity());
        float dot[] = {1f,2f,3f};
        g2.setStroke(new BasicStroke(1.0f, 0, 0, 3.0f, dot, 0.0f));
        
        i = -1;
        while (i <= 360)
        {
            x = x2;
            y = y2;
            x2 = (int)(ratio_W * (double)i);
            y2 = (int)(-AstronomyMaths.atnD(AstronomyMaths.sinD(event.getLST() * 15.0 + (double)i + event.getPlaceLong()) * tan_obl));
            y2 = (int)(ratio_H * (double)(90 - y2));
            
            if ( i == -1 )
            {
                i += 1;
            }
            else
            {
                g2.setColor(new Color(128, 192, 255));
                g2.drawLine(x, y, x2, y2);
            }
            i += 6;
        }
        
        //event place
        g2.setStroke(new BasicStroke(2.0f));
        g2.setColor(new Color(255, 0, 0));
        stringWidth = g2.getFontMetrics().stringWidth("<") / 2;
        stringHeight = g2.getFontMetrics().getHeight();
        curX = (int)(ratio_W * AstronomyMaths.modulo(-event.getPlaceLong() + 180.0, 360.0) - (double)stringWidth / 2.0);
        curY = (int)(ratio_H * (-event.getPlaceLat() + 90.0) + (double)stringHeight / 2.5);
        g2.drawString("\u003C", curX, curY);
        
        //planet location for the hour of the event
        Planet p = new Planet(event, false);
        Coord coord = p.getObjPosition(planet);
        double time = new FTime(event.getTime()).getDecimalHour();
        curX = (int)(ratio_W * (AstronomyMaths.modulo(-event.getPlaceLong() - AstronomyMaths.modulo(time - time_lag - heure_m, 24.0) * 15.0 + 180.0, 360.0)) - (double)stringWidth / 2.0);
        curY = (int)(ratio_H * (90.0 - coord.getDecl()) + (double)stringHeight / 2.5);
        g2.setColor(planetColor);
        g2.drawString(Planets.getPlanetSymbol(planet), curX, curY);
        
        //where the planet is rising or setting
        g2.setStroke(new BasicStroke(1.0f));
        x2 = 0;
        y2 = 0;
        flag_r = false;
        flag_s = false;
        
        for (i = -181; i<=180; i++)
        {
            x = x2;
            y = y2;
            
            if ( coord.getDecl() != 0 )
            {
                double t;
                
                t = AstronomyMaths.UTToLST(time, event.getTSG0(), i) * 15.0;
                x2 = (int)(ratio_W * (double)(-i + 180));
                y2 = (int)(AstronomyMaths.atnD(AstronomyMaths.cosD(t - coord.getRA()) / AstronomyMaths.tanD(coord.getDecl())));
                
                //symbols for rise and set parts
                if ( Math.abs(y2) < 25 )
                {
                    if ( t - coord.getRA() < 0.0 && t - coord.getRA() > -180.0 )
                    {
                        //rise case
                        if ( ! flag_r )
                        {
                            curX = (int)(AstronomyMaths.modulo((double)(x2), (double)(width - charSize)) + charSize / 2.0);
                            curY = (int)(ratio_H * (double)(y2 + 90));
                            g2.drawString("\\", curX, curY);
                            flag_r = true;
                        }
                    }
                    else
                    {
                        //set case
                        if ( ! flag_s )
                        {
                            curX = (int)(AstronomyMaths.modulo((double)(x2), (double)(width - charSize)) + charSize / 2.0);
                            curY = (int)(ratio_H * (double)(y2 + 90));
                            g2.drawString("^", curX, curY);
                            flag_s = true;
                        }
                    }
                }
                
                y2 = (int)(ratio_H * (double)(y2 + 90));
            }
            else
            {
                y2 = 0;
            }
            
            if ( i == -181 )
            {
                i += 1;
            }
            else
            {
                g2.drawLine(x, y, x2, y2);
            }
        }
    }
}
