package StarLogin.IHM;

import java.awt.*;
import java.awt.print.*;
import javax.swing.JPanel;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public abstract class RiseSetSurface extends JPanel implements Printable
{
    public RiseSetSurface()
    {
        setAutoscrolls(false);
        setDoubleBuffered(true);
        setBorder(null);
        setBackground(Color.white);
    }
    
    public Graphics2D createGraphics2D(int width, int height, Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.clearRect(0, 0, width, height);
        return g2;
    }
    
    // classes that extend Surface must implement this routine
    public abstract void render(int w, int h, Graphics2D g2, int x, int y);
    
    public void reFresh()
    {
        this.repaint();
    }
    
    @Override
    public void paint(Graphics g)
    {
        Dimension d = getSize();
        Graphics2D g2 = createGraphics2D(d.width, d.height, g);
        render((int)d.getWidth(), (int)d.getHeight(), g2, 0, 0);
        g2.dispose();
    }
    
    public int print(Graphics g, PageFormat pf, int pi) throws PrinterException
    {
        if (pi >= 1)
        {
            return Printable.NO_SUCH_PAGE;
        }
        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pf.getImageableX(), pf.getImageableY());
        g2d.translate(pf.getImageableWidth() / 2, pf.getImageableHeight() / 2);
        try
        {
            pf.setOrientation(PageFormat.LANDSCAPE);
        }
        catch(IllegalArgumentException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        Dimension d = getSize();
        
        double scale = Math.min(pf.getImageableWidth() / d.width, pf.getImageableHeight() / d.height);
        if (scale < 1.01)
        {
            g2d.scale(scale, scale);
        }
        g2d.translate(-d.width / 2.0, -d.height / 2.0);
        
        Graphics2D g2 = createGraphics2D(d.width, d.height, g2d);
        render((int)d.getWidth(), (int)d.getHeight(), g2, 0, 0);
        g2.dispose();
        
        return Printable.PAGE_EXISTS;
    }
}

