/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM.components;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Divider;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.Enum.OS;
//import com.apple.laf.AquaLookAndFeel;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.IconUIResource;

/**
 *
 * @author Francois
 */
public class Options
{
    private static Divider divider[];
    public static String timescale = "10";
    public static Color photobackground = Color.WHITE;
    public static Color bketiquetteobligatoire = Color.GREEN;
    public static Color fgetiquetteobligatoire = Color.YELLOW;
    public static Color bksaisieobligatoire = Color.YELLOW;
    public static Color fgsaisieobligatoire = Color.GREEN;
    public static Color bklignepaire = Color.LIGHT_GRAY;
    public static Color fglignepaire = Color.BLACK;
    public static Color bkligneimpaire = Color.GRAY;
    public static Color fgligneimpaire = Color.WHITE;
    public static Color bkwarning = Color.YELLOW;
    public static Color fgwarning = Color.RED;
    
    public Options()
    {
        getUIData();
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/contactsr.png"));
        IconUIResource iuir = new IconUIResource(iconImage);
        UIManager.put("Tree.leafIcon", iuir);
        //getUIData();
        iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/contactsfolder.png"));
        iuir = new IconUIResource(iconImage);
        UIManager.put("Tree.closedIcon", iuir);
        UIManager.put("Tree.openIcon", iuir);
    }
    
    /*private void setUIColor(String uiproperty, Color data)
    {
        String valeur = Color2String(data);
        int pos = uiproperty.indexOf(".");
        String composant = uiproperty;
        String propriete = "";
        if (pos>0)
        {
            composant = uiproperty.substring(0, pos);
            propriete = uiproperty.substring(pos + 1);
        }
        ColorUIResource uir = new ColorUIResource(data);
        UIManager.put(uiproperty, uir);
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + valeur + "' WHERE COMPONENT='" + composant + "' AND PROPERTY='" + propriete + "'");
    }*/
    
    public void setColor(String attributref, Color data, boolean bSave)
    {
        String valeur = Color2String(data);
        int pos = attributref.indexOf(".");
        String composant = attributref;
        String propriete = "";
        if (pos>0)
        {
            composant = attributref.substring(0, pos);
            propriete = attributref.substring(pos + 1);
        }
        
        if (composant.equals("Photo"))
        {
            photobackground = data;
        }
        else if (composant.equals("EtiquetteObligatoire"))
        {
            if (propriete.equals("background"))
                bketiquetteobligatoire = data;
            else if (propriete.equals("foreground"))
                fgetiquetteobligatoire = data;
        }
        else if (composant.equals("SaisieObligatoire"))
        {
            if (propriete.equals("background"))
                bksaisieobligatoire = data;
            else if (propriete.equals("foreground"))
                fgsaisieobligatoire = data;
        }
        else if (composant.equals("LignePaire"))
        {
            if (propriete.equals("background"))
                bklignepaire = data;
            else if (propriete.equals("foreground"))
                fglignepaire = data;
        }
        else if (composant.equals("LigneImpaire"))
        {
            if (propriete.equals("background"))
                bkligneimpaire = data;
            else if (propriete.equals("foreground"))
                fgligneimpaire = data;
        }
        else if (composant.equals("Warning"))
        {
            if (propriete.equals("background"))
                bkwarning = data;
            else if (propriete.equals("foreground"))
                fgwarning = data;
        }
        else
        {
            ColorUIResource uir = new ColorUIResource(data);
            UIManager.put(attributref, uir);
        }
        if (bSave)
            MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + valeur + "' WHERE COMPONENT='" + composant + "' AND PROPERTY='" + propriete + "'");
    }
    
    public static Divider getDivider(String window, String component)
    {
        for (int i=0; i< divider.length; i++)
        {
            if (divider[i].getWindow().equals(window) && divider[i].getComponentName().equals(component))
            {
                if (divider[i].getValeur().equals(""))
                    return null;
                else
                    return divider[i];
            }
        }
        return null;
    }
    
    public void setDivider(String window, String component, String val)
    {
        int index = -1;
        for (int i=0; i< divider.length; i++)
        {
            if (divider[i].getWindow().equals(window) && divider[i].getComponentName().equals(component))
            {
                index = i;
                break;
            }
        }
        divider[index].setValeur(val);
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + val + "' WHERE ID=" + divider[index].getID() + "");
    }
    
    public void setDivider(Divider div, String val)
    {
        int index = -1;
        for (int i=0; i< divider.length; i++)
        {
            if (divider[i].equals(div))
            {
                index = i;
                break;
            }
        }
        divider[index].setValeur(val);
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + val + "' WHERE ID=" + divider[index].getID() + "");
    }
    
    public void setDivider(String window, String component, int val)
    {
        int index = -1;
        for (int i=0; i< divider.length; i++)
        {
            if (divider[i].getWindow().equals(window) && divider[i].getComponentName().equals(component))
            {
                index = i;
                break;
            }
        }
        divider[index].setValeur(String.valueOf(val));
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + val + "' WHERE ID=" + divider[index].getID() + "");
    }
    
    public void setDivider(Divider div, int val)
    {
        int index = -1;
        for (int i=0; i< divider.length; i++)
        {
            if (divider[i].equals(div))
            {
                index = i;
                break;
            }
        }
        divider[index].setValeur(String.valueOf(val));
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + val + "' WHERE ID=" + divider[index].getID() + "");
    }
    
    public void setTimeScale(int val)
    {
        timescale = String.valueOf(val);
        MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + val + "' WHERE WINDOW_='GestionTempsForm' AND PROPERTY='timescale'");
    }
    
    public static Color getColor(String attributref)
    {
        Color data;
        int pos = attributref.indexOf(".");
        String composant = attributref;
        String propriete = "";
        if (pos>0)
        {
            composant = attributref.substring(0, pos);
            propriete = attributref.substring(pos + 1);
        }
        if (composant.equals("Photo"))
        {
            data = photobackground;
        }
        else if (composant.equals("EtiquetteObligatoire"))
        {
            data = Color.WHITE;
            if (propriete.equals("background"))
                data = bketiquetteobligatoire;
            else if (propriete.equals("foreground"))
                data = fgetiquetteobligatoire;
        }
        else if (composant.equals("SaisieObligatoire"))
        {
            data = Color.WHITE;
            if (propriete.equals("background"))
                data = bksaisieobligatoire;
            else if (propriete.equals("foreground"))
                data = fgsaisieobligatoire;
        }
        else if (composant.equals("LignePaire"))
        {
            data = Color.WHITE;
            if (propriete.equals("background"))
                data = bklignepaire;
            else if (propriete.equals("foreground"))
                data = fglignepaire;
        }
        else if (composant.equals("LigneImpaire"))
        {
            data = Color.WHITE;
            if (propriete.equals("background"))
                data = bkligneimpaire;
            else if (propriete.equals("foreground"))
                data = fgligneimpaire;
        }
        else if (composant.equals("Warning"))
        {
            data = Color.WHITE;
            if (propriete.equals("background"))
                data = bkwarning;
            else if (propriete.equals("foreground"))
                data = fgwarning;
        }
        else
        {
            Object value = UIManager.get(attributref);
            if (value instanceof ColorUIResource)
                data = (Color)((ColorUIResource)value);
            else
                data = Color.WHITE;
        }
        return data;
    }
    
    public Color getEditColor()
    {
        Color couleur = getColor("Button.background");
        Color tmp = couleur.brighter();
        tmp = tmp.brighter();
        int r1 = couleur.getRed();
        int r2 = tmp.getRed();
        int gr1 = couleur.getGreen();
        int gr2 = tmp.getGreen();
        int b1 = couleur.getBlue();
        int b2 = tmp.getBlue();
        if ((r2 == 255 && gr2 == 255 && b2 == 255)||(r2+gr2+b2-r1-gr1-b1<50))
        {
            tmp = couleur.darker();
            tmp = tmp.darker();
        }
        couleur = tmp;
        return couleur;
    }
    
    public Color getNormalColor()
    {
        return getColor("Button.background");
    }
    
    private void getUIData()
    {
        /*UIManager.LookAndFeelInfo[] lafInfo = UIManager.getInstalledLookAndFeels();
        boolean bFoundLAF = false;
        int index = 0;

        for (int i = 0; i < lafInfo.length; i++)
        {
            String name = lafInfo[i].getName();
            
            if (name.equals("Windows Classic"))
            {
                bFoundLAF = true;
                index = i;
            }
        }
        
        if (bFoundLAF == true)
        {
            try
            {
                UIManager.setLookAndFeel(lafInfo[index].getClassName());
            }
            catch (ClassNotFoundException ex)
            {
                //Logger.getLogger(Options.class.getName()).log(Level.SEVERE, null, ex);
                MainClass.writelog(ex.getMessage());
            }
            catch (InstantiationException ex)
            {
                //Logger.getLogger(Options.class.getName()).log(Level.SEVERE, null, ex);
                MainClass.writelog(ex.getMessage());
            }
            catch (IllegalAccessException ex)
            {
                //Logger.getLogger(Options.class.getName()).log(Level.SEVERE, null, ex);
                MainClass.writelog(ex.getMessage());
            }
            catch (UnsupportedLookAndFeelException ex)
            {
                //Logger.getLogger(Options.class.getName()).log(Level.SEVERE, null, ex);
                MainClass.writelog(ex.getMessage());
            }
        }*/
        
        
        Records cps = MainClass.starLoginManager.getRecords("SELECT COMPONENT, PROPERTY, VALEUR FROM option_ WHERE WINDOW_ is null", "option_");
        ArrayList rows = cps.getRecords();
        
        for (int i=0; i<rows.size(); i++)
        {
            ArrayList row = (ArrayList)rows.get(i);
            String composant = null2String(row.get(0));
            String propriete = null2String(row.get(1));
            String valeur = null2String(row.get(2));
            String attributref = composant.concat(".").concat(propriete);
            Color color0 = String2Color(valeur);
            //if (!valeur.equals(""))
            {
                setColor(attributref, color0, false);
            }
            /*else
            {
                if (composant.equals("Photo")||composant.equals("EtiquetteObligatoire")||composant.equals("SaisieObligatoire")||composant.equals("LignePaire")||composant.equals("LigneImpaire")||composant.equals("Warning"))
                {
                    color0 = getColor(attributref);
                    setColor(attributref, color0, false);
                }
                else
                {
                    Object value = UIManager.get(attributref);
                    if (value instanceof ColorUIResource)
                    {
                        color0 = (Color)((ColorUIResource)value);
                        setUIColor(attributref, color0);
                    }
                }
            }*/
        }
        
        Records dividers = MainClass.starLoginManager.getRecords("SELECT ID, WINDOW_, COMPONENT, VALEUR FROM option_ WHERE WINDOW_ is not null AND PROPERTY='DividerLocation'", "option_");
        rows = dividers.getRecords();
        divider = new Divider[rows.size()];
        for (int i=0; i<rows.size(); i++)
        {
            ArrayList row = (ArrayList)rows.get(i);
            Divider div = new Divider();
            div.setID(null2String(row.get(0)));
            div.setWindow(null2String(row.get(1)));
            div.setComponent(null2String(row.get(2)));
            div.setValeur(null2String(row.get(3)));
            divider[i] = div;
        }
        
        String ts = MainClass.starLoginManager.getStringFieldValue("option_", "VALEUR", " WHERE WINDOW_='GestionTempsForm' AND PROPERTY='timescale'");
        if (ts.equals(""))
            ts = "10";
        timescale = ts;
    }
    
    private Color String2Color(String valeur)
    {
        if (valeur.equals(""))
            valeur = "0";
        int val = Integer.valueOf(valeur).intValue();
        Color color0 = new Color(val);
        return color0;
    }
    
    private String Color2String(Color couleur)
    {
        if (couleur == null)
            return "-1";
        return Integer.toString(couleur.getRGB());
    }
    
    private String null2String(Object obj)
    {
        if (obj == null)
            return "";
        else
            return String.valueOf(obj);
    }
}
