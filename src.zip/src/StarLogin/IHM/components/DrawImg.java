package StarLogin.IHM.components;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Francois DESCHAMPS
 */
public class DrawImg extends JPanel
{

    private String imgFile;
    private String parties;
    private int xVal = 0;
    private int yVal = 0;

    public DrawImg(String img, String parties)
    {
        imgFile = img;
        this.parties = parties;
    }

    public void setParties(String parties)
    {
        this.parties = parties;
    }

    @Override
    public void paint(Graphics g)
    {
        Dimension d = getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.clearRect(0, 0, d.width, d.height);
        render((int) d.getWidth(), (int) d.getHeight(), g2, xVal, yVal);
        g2.dispose();
    }

    public void reFresh(int xVal, int yVal)
    {
        this.xVal = xVal;
        this.yVal = yVal;
        this.repaint();
    }

    public void render(int w0, int h0, java.awt.Graphics2D g2, int x0, int y0)
    {
        //||||||||||||||||||||||||||||||||||||||||||||||||=
        ImageIcon iconImage = new ImageIcon(getClass().getResource(imgFile));
        if (iconImage == null)
        {
            return;
        }
        Image icon = iconImage.getImage();
        if (icon == null)
        {
            return;
        }
        //width = icon.getWidth(this);
        //height = icon.getHeight(this);
        g2.drawImage(icon, 0, 0, this);

        if (parties == null || parties.equals(""))
        {
            return;
        }
        String parts[] = parties.split(",");
        String sX = "0";
        String sY = "0";
        for (int i = 0; i < parts.length; i++)
        {
            int pos = parts[i].indexOf(":");
            if (pos > 0)
            {
                sY = parts[i].substring(pos + 1);
                sX = parts[i].substring(0, pos);
                int x = new Integer(sX).intValue();
                int y = new Integer(sY).intValue();

                g2.setColor(Color.green);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(x - 10, y - 10, 20, 20);
            }
        }
    }
}
