package StarLogin.IHM.components;

import StarLogin.IHM.*;
import StarLogin.Systeme.Enum.OS;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

//import kasper.net.ftp.*;

/**
 *
 * @author Francois DESCHAMPS
 * @version 2.0.0
 */
public class ImageSurface extends JPanel
{
    //private static String currentDirectory = null;
    private String currentDirectory = null;
    private ImageSurface surface;
    private JPopupMenu popupPicture;
    private JMenuItem mnuFile;
    private JMenuItem mnuDeletePicture;
    private Image image;
    private int imageHeight = 0;
    private int imageWidth = 0;
    private int width;
    private int height;
    private ImageIcon picture;
    private boolean bSetting = true;
    private ImageSurface current = this;
    java.util.ResourceBundle bundle;
    private Object object;
    private boolean bEnabled = false;

    public ImageSurface(Object object, Dimension dimension)
    {
        surface = current;
        bundle = MainClass.bundle;
        this.object = object;
        width = (int)dimension.getWidth();
        height = (int)dimension.getHeight();
        setMinimumSize(dimension);
        setPreferredSize(dimension);
        setSize(dimension);
        this.setBackground(new Color(195,225,255));
        setBorder(null);
        final Object obj = object;
        setDoubleBuffered(true);
        setToolTipText(bundle.getString("RightClic2AddOrModifyLeftClic2View"));

        //Popup menu
        popupPicture = new JPopupMenu();
        mnuFile = new javax.swing.JMenuItem();
        mnuFile.setText(bundle.getString("PictureFile"));
        mnuFile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                popupPicture.setVisible(true);
                //show the open file dialog box
                setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));

                java.io.File selectedFile;
                final JFileChooser fc = new JFileChooser();
                fc.setDialogTitle(bundle.getString("SelectingAPictureFile"));
                fc.setAcceptAllFileFilterUsed(false);   //can select only the defined filter
                fc.setMultiSelectionEnabled(false);     //only one file can be selected
                fc.setAccessory(new ImagePreview(fc));  //image previewer
                if (currentDirectory != null && !currentDirectory.equals(""))
                {
                    fc.setCurrentDirectory(new File(currentDirectory));
                }
                fc.addChoosableFileFilter(new ImageFilter());   //gif, png and jpeg filter
                
                //If the file URL already exists, get the picture
                /*if ((picture != null) && (!picture.equals("")))
                {
                    selectedFile = new java.io.File(picture);
                    fc.setSelectedFile(selectedFile);
                }*/

                if (surface != null)
                {
                    int returnVal = fc.showOpenDialog(surface);
                    //click on the OK button --> get the file absolute path
                    if (returnVal == JFileChooser.APPROVE_OPTION)
                    {
                        selectedFile = fc.getSelectedFile();
                        String pictureFile = selectedFile.getAbsolutePath();
                        picture = new ImageIcon(pictureFile);
                        //picture = selectedFile.getAbsolutePath();
                        currentDirectory = selectedFile.getParent();
                        //picture = uploadFile(picture, "ftp.infotech-srv01.com", "optiontravail@infotech-srv01.com", "22option", "img", false);
                        if (obj instanceof ListeEventForm)
                        {
                            ListeEventForm eventForm = (ListeEventForm)obj;
                            eventForm.setPicture(picture);
                        }
                        else if (obj instanceof VariousCalcForm)
                        {
                            VariousCalcForm variousCalcForm = (VariousCalcForm)obj;
                            variousCalcForm.setPicture(picture);
                        }
                        else if (obj instanceof ListeClientForm)
                        {
                            ListeClientForm lcf = (ListeClientForm)obj;
                            lcf.setPicture(picture);
                        }
                        else if (obj instanceof DialogClient)
                        {
                            DialogClient dlc = (DialogClient)obj;
                            dlc.setPicture(picture);
                        }
                        else if (obj instanceof DialogConsultations)
                        {
                            DialogConsultations cf = (DialogConsultations)obj;
                            cf.setPicture(picture);
                        }
                        else if (obj instanceof DialogEvent)
                        {
                            DialogEvent dle = (DialogEvent)obj;
                            dle.setPicture(picture);
                        }
                    }
                    loadPicture(picture);
                }
                setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            }
        });
        popupPicture.add(mnuFile);

        addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent evt)
            {
                if (evt.getButton()==3)
                {
                    popupPicture.show(surface, evt.getX(), evt.getY());
                }
                else
                {
                    if ((picture != null))
                    {
                        
                        Image img = picture.getImage();

                        //BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
                        BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_BGR);
                        Graphics2D g2 = bi.createGraphics();
                        // Draw img into bi so we can write it to file.
                        g2.drawImage(img, 0, 0, null);
                        g2.dispose();
                        //File file = new File("tmp.png");
                        File file = new File("tmp.png");
                        try
                        {
                            // Now bi contains the img.
                            // Note: img may have transparent pixels in it; if so, okay.
                            // If not and you can use TYPE_INT_RGB you will get better
                            // performance with it in the jvm.
                            ImageIO.write(bi, "jpg", file);
                        }
                        catch (IOException ex)
                        {
                            MainClass.setMessage(ex.getMessage());
                        }
                        try
                        {
                            Runtime rt = Runtime.getRuntime();
                            if (OS.getOS() == OS.apple)
                                rt.exec("open /Applications/Preview.app " + file);
                            else if (OS.getOS() == OS.linux)
                                rt.exec("eog -w " + file);
                            else
                                rt.exec("C:\\WINDOWS\\system32\\rundll32.exe c:\\windows\\system32\\shimgvw.dll,ImageView_Fullscreen " + file.getPath());
                        }
                        catch (IOException ie)
                        {
                            MainClass.setMessage(ie.getMessage());
                        }
                    }
                }
            }
        });
    }

    /*private String uploadFile(String picture, String serveur, String user, String pwd, String workingDir, boolean pasv)
    {
        String pictureURL = picture;
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        FTPClient client = new FTPClient();
        try
        {
            // The current FTPServerResponse from the server.
            FTPServerResponse currentResponse = null;
            // Connect to ftp.microsoft.com and print the greeting.
            currentResponse = client.connect(serveur, 21);
            MainClass.writelog(currentResponse.getResponse());

            // See if we need to pass a userID.
            if (currentResponse.getResponseCode() != FTPServerResponse.SERVER_READY)
            {
                //System.exit(1);
            }
            currentResponse = client.user(user);
            MainClass.writelog(currentResponse.getResponse());

            // See if we need to pass a password.
            if (currentResponse.getResponseCode() != FTPServerResponse.PASSWORD_NEEDED)
            {
                //System.exit(1);
            }
            currentResponse = client.pass(pwd);
            MainClass.writelog(currentResponse.getResponse());

            // Now find out the current working directory and print it out.
            currentResponse = client.pwd();
            MainClass.writelog(currentResponse.getResponse());

            // Now change the current working directory to img and print it out.
            currentResponse = client.cwd(workingDir);
            MainClass.writelog(currentResponse.getResponse());

            // We cant forget to change the type to image.
            currentResponse = client.type(FTPClient.IMAGE);
            MainClass.writelog(currentResponse.getResponse());

            // Next, establish a data connection.
            if (pasv == true)
            {
                currentResponse = client.pasv();
            }
            else
            {
                currentResponse = client.port();
            }
            MainClass.writelog(currentResponse.getResponse());

            // Now put the local picture on the remote host.
            String remotePicture = new File(picture).getName();
            pictureURL = remotePicture;
            FTPServerResponse tempResponses[] = client.stor(picture, remotePicture);
            MainClass.writelog(tempResponses[0].getResponse());
            MainClass.writelog(tempResponses[1].getResponse());
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //System.exit(1);
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        return pictureURL;
    }*/

    /*private String downloadFile(String picture, String serveur, String user, String pwd, String workingDir, boolean pasv)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        FTPClient client = new FTPClient();
        try
        {
            // The current FTPServerResponse from the server.
            FTPServerResponse currentResponse = null;
            // Connect to ftp.microsoft.com and print the greeting.
            currentResponse = client.connect(serveur, 21);
            MainClass.writelog(currentResponse.getResponse());

            // See if we need to pass a userID.
            if (currentResponse.getResponseCode() != FTPServerResponse.SERVER_READY)
            {
                //System.exit(1);
            }
            currentResponse = client.user(user);
            MainClass.writelog(currentResponse.getResponse());

            // See if we need to pass a password.
            if (currentResponse.getResponseCode() != FTPServerResponse.PASSWORD_NEEDED)
            {
                //System.exit(1);
            }
            currentResponse = client.pass(pwd);
            MainClass.writelog(currentResponse.getResponse());

            // Now find out the current working directory and print it out.
            currentResponse = client.pwd();
            MainClass.writelog(currentResponse.getResponse());

            // Now change the current working directory to img and print it out.
            currentResponse = client.cwd(workingDir);
            MainClass.writelog(currentResponse.getResponse());

            // We cant forget to change the type to image.
            currentResponse = client.type(FTPClient.IMAGE);
            MainClass.writelog(currentResponse.getResponse());

            // Next, establish a data connection.
            if (pasv == true)
            {
                currentResponse = client.pasv();
            }
            else
            {
                currentResponse = client.port();
            }
            MainClass.writelog(currentResponse.getResponse());

            // Now put the remote picture on the local host.
            String remotePicture = new File(picture).getName();
            if (!picture.substring(0, 2).endsWith(":") && !picture.substring(0, 2).equals("\\\\"))
            {
                JFileChooser fc = new JFileChooser();
                picture = fc.getCurrentDirectory().getPath() + Systeme.Enum.OS.getSeparator() + picture;
            }
            FTPServerResponse tempResponses[] = client.retr(remotePicture, picture);
            MainClass.writelog(tempResponses[0].getResponse());
            MainClass.writelog(tempResponses[1].getResponse());
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //System.exit(1);
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        return picture;
    }*/

    public void loadPicture(ImageIcon picture)
    {
        this.picture = picture;
        bSetting = true;
        //if ((picture != null) && (!picture.equals("")))
        if (picture != null)
        {
            /*if (!picture.substring(0, 2).endsWith(":") && !picture.substring(0, 2).equals("\\\\"))
            {
                picture = downloadFile(picture, "ftp.infotech-srv01.com", "optiontravail@infotech-srv01.com", "22option", "img", false);
            }
            File file = new File(picture);
            if (file != null)
            {*/
                ImageIcon thumbnail = null;
                if (height>0 && width>0)
                {
                    //Get the picture file
                    ImageIcon tmpIcon = picture;//new ImageIcon(file.getPath());
                    if (tmpIcon != null)
                    {
                        int iH = tmpIcon.getIconHeight();
                        int iW = tmpIcon.getIconWidth();

                        //resize the picture, if it's too big
                        if ((iW > width) || (iH > height))
                        {
                            if ((iW > width) && (iH > height))
                            {
                                if (iW/width > iH/height)
                                {
                                    thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(width, -1, Image.SCALE_DEFAULT));
                                }
                                else
                                {
                                    thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(-1, height, Image.SCALE_DEFAULT));
                                }
                            }
                            else if (iW > width)
                            {
                                thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(width, -1, Image.SCALE_DEFAULT));
                            }
                            else
                            {
                                thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(-1, height, Image.SCALE_DEFAULT));
                            }
                        }

                        //no need to miniaturize
                        else
                        {
                            thumbnail = tmpIcon;
                        }
                    }

                    if (thumbnail != null)
                    {
                        image = thumbnail.getImage();
                        imageHeight = thumbnail.getIconHeight();
                        imageWidth = thumbnail.getIconWidth();
                    }
                    else
                    {
                        image = null;
                        imageHeight = 0;
                        imageWidth = 0;
                    }
                }
                else
                {
                    image = null;
                    imageHeight = 0;
                    imageWidth = 0;
                }
            /*}
            else
            {
                image = null;
                imageHeight = 0;
                imageWidth = 0;
            }*/
        }
        else
        {
            image = null;
            imageHeight = 0;
            imageWidth = 0;
        }

        if (image != null && imageHeight>0 && imageWidth>0)
        {
            while (popupPicture.getSubElements().length >1)
            {
                popupPicture.remove(popupPicture.getSubElements().length - 1);
            }
            mnuDeletePicture = new javax.swing.JMenuItem();
            mnuDeletePicture.setText(bundle.getString("DeletePicture"));
            mnuDeletePicture.addActionListener(new java.awt.event.ActionListener()
            {
                protected ImageIcon picture = this.picture;
                protected final Object obj = object;

                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    picture = null;
                    if (obj instanceof ListeEventForm)
                    {
                        ListeEventForm eventForm = (ListeEventForm)obj;
                        eventForm.setPicture(picture);
                    }
                    else if (obj instanceof VariousCalcForm)
                    {
                        VariousCalcForm variousCalcForm = (VariousCalcForm)obj;
                        variousCalcForm.setPicture(picture);
                    }
                    else if (obj instanceof ListeClientForm)
                    {
                        ListeClientForm lcf = (ListeClientForm) obj;
                        lcf.setPicture(picture);
                    }
                    else if (obj instanceof DialogClient)
                    {
                        DialogClient dlc = (DialogClient) obj;
                        dlc.setPicture(picture);
                    }
                    else if (obj instanceof DialogConsultations)
                    {
                        DialogConsultations cf = (DialogConsultations) obj;
                        cf.setPicture(picture);
                    }
                    else if (obj instanceof DialogEvent)
                    {
                        DialogEvent dle = (DialogEvent) obj;
                        dle.setPicture(picture);
                    }
                    loadPicture(picture);
                    setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
                }
            });
            popupPicture.add(mnuDeletePicture);
            mnuDeletePicture.setVisible(bEnabled);
        }

        bSetting = false;
        //repaint();
        //paintAll(this.getGraphics());
        this.paintImmediately(this.getBounds());
    }

    public void setMenuEnabled(boolean enabled)
    {
        bEnabled = enabled;
        mnuFile.setVisible(enabled);
        if (mnuDeletePicture != null)
            mnuDeletePicture.setVisible(enabled);
    }

    @Override
    public void paint(Graphics g)
    {
        if (bSetting == false)
        {
            g.setColor(this.getBackground());
            g.fillRect(0,0,width,height);

            if (image != null)
            {
                g.drawImage(image, (width-imageWidth)/2, (height-imageHeight)/2, imageWidth, imageHeight, Color.white, this);
            }
            g.dispose();
        }
    }
}
