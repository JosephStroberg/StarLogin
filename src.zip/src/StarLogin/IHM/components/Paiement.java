/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM.components;

/**
 *
 * @author Francois
 */
public class Paiement
{
    public static String montantCollecte = "";
    public static String montantRecu = "";
    public static String montantRendu = "";
    public static String montantInterac = "";
    public static String montantVisa = "";
    public static String montantAmex = "";
    public static String montantMC= "";
    public static String montantCC= "";
    public static String montantComptant = "";
    public static String montantAutre = "";
    public static boolean interac = false;
    public static boolean visa = false;
    public static boolean amex = false;
    public static boolean mc = false;
    public static boolean cc = false;
    public static boolean comptant = false;
    public static boolean autre = false;
    public static boolean aborted = true;
    public static boolean compteARecevoir = false;
    public static String piecesid = "";
    
    /*public static String getCollecte()
    {
        return montantCollecte;
    }
    
    public static void setCollecte(String data)
    {
        montantCollecte = data;
    }*/
}
