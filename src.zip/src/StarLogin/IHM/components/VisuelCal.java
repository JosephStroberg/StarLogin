package StarLogin.IHM.components;

/**
 *
 * @author Francois Deschamps - 2011
 */
import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.Enum.Months;
import StarLogin.Systeme.Enum.USWeekDays;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.*;

//the date returned by visuelCal1.getDate() under the corresponding format : dd-mm-yyyy
//(for day-month-year)
public class VisuelCal extends JPanel
{
    private JPanel container = new JPanel();
    private static final int GRID_SIZE = 42;
    public static final int CW = 192;
    public static final int CH = 192;
    private SLabel days[] = new SLabel[GRID_SIZE];
    private Color cdays[] = new Color[GRID_SIZE];
    private boolean seldays[] = new boolean[GRID_SIZE];
    private String seldaynames[] = new String[GRID_SIZE];
    private SButton next;
    private SButton prev;
    private int month = 1;
    private String MIN_YEAR = "1900";
    private String MAX_YEAR = "2100";
    private int year = 2011;
    private SLabel sLabel1;
    private SLabel sLabel2;
    private SLabel sLabel3;
    private SLabel sLabel4;
    private SLabel sLabel5;
    private SLabel sLabel6;
    private SLabel sLabel7;
    private double sizeMultiplier = 1.0;
    private Color bkVColor;
    private Color fgVColor;
    private Color bkDColor;
    private Color fgDColor;
    private Color bkWColor;
    private Color fgWColor;
    private Color bkTColor;
    private Color fgTColor;
    private Color gridColor;
    private Color backColor;
    private boolean bSelected = false;
    private int numSelDay = 0;
    private SCombo cboMonth;
    private SCombo cboYear;
    //private boolean bEnter = false;
    private int day = 1;
    private String date = FDate.curUsFormDate();
    private String time = MainClass.STIME_000000;
    private int nbStableControls = 0;
    private boolean bSettingDate = true;
    private Color selectionColor;
    private int debut;

    //Creates new VisuelCal
    public VisuelCal()
    {
        selectionColor = Options.getColor("TextField.selectionBackground");
        backColor = Options.getColor("Panel.background");
        bkDColor = Options.getColor("TextField.background");
        fgDColor = Options.getColor("TextField.foreground");
        gridColor = Options.getColor("Table.gridColor");
        bkWColor = Options.getColor("Button.background");
        fgWColor = Options.getColor("Button.foreground");
        bkTColor = Options.getColor("Label.background");
        fgTColor = Options.getColor("Label.foreground");
        fgVColor = Options.getColor("EtiquetteObligatoire.foreground");
        bkVColor = Options.getColor("EtiquetteObligatoire.background");
        FDate fd = new FDate(date);
        initCalendar(1, 1, (int)fd.getYear(), container, 1);
        bSettingDate = false;
    }
    
    public VisuelCal(double sizeMultiplier)
    {
        this();
        this.sizeMultiplier = sizeMultiplier;
    }

    public int getDay()
    {
        return day;
    }

    public int getMonth()
    {
        return month;
    }

    public int getYear()
    {
        return year;
    }
    
    public boolean isSelected()
    {
        return bSelected;
    }

    public String getDate()
    {
        return date;
    }

    public String getTime()
    {
        return time;
    }
    
    public void deselectAll(boolean bAll)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (days[i] != null)
            {
                //days[i].setBorder(javax.swing.BorderFactory.createLineBorder(color));
                days[i].setBackground(cdays[i]);
                seldays[i] = false;
                seldaynames[i] = "";
            }
        }
        if (!bAll && days[numSelDay] != null)
        {
            days[numSelDay].setBackground(selectionColor);
            seldays[numSelDay] = true;
            seldaynames[numSelDay] = date;
        }
    }
    
    private int getSelelectedNB()
    {
        int nb = 0;
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (days[i] != null)
            {
                if (seldays[i] == true)
                    nb++;
            }
        }
        return nb;
    }
    
    public String[] getSelectedDays()
    {
        int nb = getSelelectedNB();
        if (nb <= 0)
            return null;
        String selDayNames[] = new String[nb];
        int j = 0;
        
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (days[i] != null)
            {
                if (seldays[i] == true)
                {
                    selDayNames[j] = seldaynames[i];
                    j++;
                }
            }
        }
        return selDayNames;
    }

    //get the multiplier value for the size of the calendar derived from the default one
    public double getMultiplier()
    {
        return sizeMultiplier;
    }

    public void setDate(String newDate)
    {
        FDate fd = new FDate(newDate);
        double jd = AstronomyMaths.gregorianToJulian(fd.getDay(), fd.getMonth(), fd.getYear());
        double ddate = AstronomyMaths.julianToGregorian(jd);
        fd = new FDate(ddate);
        date = getDate(fd);
        setCalendar((int) fd.getDay(), (int) fd.getMonth(), (int) fd.getYear(), container, sizeMultiplier);
    }

    private void setColors()
    {
        setFgVacancyColor(fgVColor);
        setBkVacancyColor(bkVColor);
        setFgTopColor(fgTColor);
        setBkTopColor(bkTColor);
        setFgWeekDaysColor(fgWColor);
        setBkWeekDaysColor(bkWColor);
        setFgDaysColor(fgDColor);
        setBkDaysColor(bkDColor);
        setContainerColor(backColor);
        setGridColor(gridColor);
    }

    private void initCalendar(int day, int month, int year, JPanel container, double sizeMultiplier)
    {
        this.container = container;
        this.sizeMultiplier = sizeMultiplier;
        this.month = month;
        this.year = year;
        this.day = day;

        //set the differents control elements (buttons, labels, combo)
        setControls(container);

        //get the number of controls always visible (all but the buttons for the days)
        nbStableControls = this.getComponents().length;

        //display the grid of days
        afficherGrille(day, month, year);
    }

    //set the calendar with a given date (day, month, year)
    private void setCalendar(int day, int month, int year, JPanel container, double sizeMultiplier)
    {
        this.container = container;
        this.day = day;
        bSettingDate = true;
        setMultiplier(sizeMultiplier);
        setMonth(month);
        setYear(year);
        bSettingDate = false;
        afficherGrille(day, month, year);
    }

    //set the calendar size
    private void setContainerSize(double multiplier)
    {
        setBounds(0, 0, (int) Math.round(CW * multiplier) + 2, (int) Math.round(CH * multiplier) + 1);
        setPreferredSize(new Dimension((int) Math.round(CW * multiplier) + 2, (int) Math.round(CH * multiplier) + 1));
        container.setBounds(0, 0, (int) Math.round(CW * multiplier) + 2, (int) Math.round(CH * multiplier) + 1);
        container.setPreferredSize(new Dimension((int) Math.round(CW * multiplier) + 2, (int) Math.round(CH * multiplier) + 1));
    }

    //set the size of the different elements of the calendar
    public void setMultiplier(double multiplier)
    {
        sizeMultiplier = multiplier;
        setContainerSize(multiplier);
        sLabel1.setBounds((int) Math.round(0 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel2.setBounds((int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel3.setBounds((int) Math.round(48 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel4.setBounds((int) Math.round(72 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel5.setBounds((int) Math.round(96 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel6.setBounds((int) Math.round(120 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel7.setBounds((int) Math.round(144 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier), (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        sLabel1.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel2.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel3.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel4.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel5.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel6.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        sLabel7.setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
        prev.setBounds(0, 0, (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        next.setBounds((int) Math.round(144 * sizeMultiplier), 0, (int) Math.round(24 * sizeMultiplier) + 1, (int) Math.round(24 * sizeMultiplier) + 1);
        cboMonth.setBounds((int) Math.round(24 * sizeMultiplier), (int) Math.round(0 * sizeMultiplier), (int) Math.round(74 * sizeMultiplier + 1), (int) Math.round(24 * sizeMultiplier + 1));
        cboMonth.setPreferredSize(new Dimension((int) Math.round(74 * sizeMultiplier + 1), (int) Math.round(24 * sizeMultiplier + 1)));
        cboYear.setBounds((int) Math.round(98 * sizeMultiplier), (int) Math.round(0 * sizeMultiplier), (int) Math.round(46 * sizeMultiplier + 1), (int) Math.round(24 * sizeMultiplier + 1));
        cboMonth.setFont(new java.awt.Font("Arial", 1, (int) Math.round(9 * sizeMultiplier)));
        cboYear.setFont(new java.awt.Font("Arial", 1, (int) Math.round(9 * sizeMultiplier)));
        afficherGrille(day, month, year);
    }

    public void setMonth(int month)
    {
        cboMonth.setSelectedIndex(AstronomyMaths.modulo(month - 1, 12));
        this.month = month;
        afficherGrille(day, month, year);
    }

    public void setYear(int year)
    {
        cboYear.setSelectedItem("" + year);
        this.year = year;
        afficherGrille(day, month, year);
    }

    private void setControls(JPanel container)
    {
        setOpaque(true);
        setContainerSize(sizeMultiplier);
        setLayout(null);
        container.add(this);

        //button to get the previous month
        prev = new SButton("", 0, 0, 24, 24, this, sizeMultiplier);
        prev.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png")));
        prev.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                if (month == 1)
                {
                    month = 12;
                    year -= 1;
                }
                else
                {
                    month -= 1;
                }
                FDate max = getLastDayOfMonth(month, year);
                day = (int) max.getDay();
                cboYear.setSelectedItem("" + year);
                cboMonth.setSelectedIndex(AstronomyMaths.modulo(month - 1, 12));
                FDate fd = new FDate(day, month, year, "");
                date = getDate(fd);
                dispatchEvent(evt);
            }
        });

        //combo box to select the month
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        for (int i = 0; i < 12; i++)
        {
            comboModel.addElement(Months.getMonthName(i));
        }
        cboMonth = new SCombo(AstronomyMaths.modulo(month - 1, 12), 11, 24, 0, 74, 24, this, sizeMultiplier, comboModel);
        cboMonth.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                if (bSettingDate)
                    return;
                month = cboMonth.getSelectedIndex() + 1;
                FDate max = getLastDayOfMonth(month, year);
                int dj = (int) max.getDay();
                if (day > dj)
                {
                    day = dj;
                }
                afficherGrille(day, month, year);

                java.awt.event.MouseEvent evt2 = new java.awt.event.MouseEvent((Component) next, 0, 1l, 1, 1, 0, 1, false);
                FDate fd = new FDate(day, month, year, "");
                date = getDate(fd);
                Rectangle rect = cboMonth.getBounds();
                cboMonth.setBounds((int) rect.getX(), (int) rect.getY(), (int) rect.getWidth() + 1, (int) rect.getHeight() + 1);
                cboMonth.setBounds(rect);
            }
        });
        cboMonth.addComponentListener(new java.awt.event.ComponentAdapter()
        {
            @Override
            public void componentResized(java.awt.event.ComponentEvent evt)
            {
                dispatchEvent(evt);
            }
        });

        //text box to enter the year
        DefaultComboBoxModel comboModel2 = new DefaultComboBoxModel();
        int min = new Integer(MIN_YEAR).intValue();
        int max = new Integer(MAX_YEAR).intValue();
        for (int i = min; i <= max; i++)
        {
            comboModel2.addElement("" + i);
        }
        cboYear = new SCombo(0, 11, 98, 0, 46, 24, this, sizeMultiplier, comboModel2);//new SText("" + year, 1, 12, 98, 0, 36, 24, this, sizeMultiplier);
        cboYear.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0, 0, 0)));
        cboYear.setBackground(cboMonth.getBackground());
        cboYear.addComponentListener(new java.awt.event.ComponentAdapter()
        {
            @Override
            public void componentResized(java.awt.event.ComponentEvent evt)
            {
                dispatchEvent(evt);
            }
        });
        cboYear.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                if (bSettingDate)
                    return;
                String syear = String.valueOf(cboYear.getSelectedItem());
                if (syear.equals("null"))
                    syear = MIN_YEAR;
                year = new Integer(syear).intValue();
                FDate max = getLastDayOfMonth(month, year);
                int dj = (int) max.getDay();
                if (day > dj)
                {
                    day = dj;
                }
                afficherGrille(day, month, year);
                FDate fd = new FDate(day, month, year, "");
                date = getDate(fd);
                dispatchEvent(evt);
                Rectangle rect = cboYear.getBounds();
                cboYear.setBounds((int) rect.getX(), (int) rect.getY(), (int) rect.getWidth() + 1, (int) rect.getHeight() + 1);
                cboYear.setBounds(rect);
            }
        });
        /*.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    bEnter = true;
                    year = new Integer(txtYear.getText()).intValue();
                    FDate max = getLastDayOfMonth(month, year);
                    int dj = (int) max.getDay();
                    if (day > dj)
                    {
                        day = dj;
                    }
                    afficherGrille(day, month, year);
                    FDate fd = new FDate(day, month, year);
                    date = getDate(fd);
                    dispatchEvent(evt);
                }
            }
        });
        txtYear.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                if (bEnter)
                {
                    bEnter = false;
                    return;
                }
                year = new Integer(txtYear.getText()).intValue();
                FDate max = getLastDayOfMonth(month, year);
                int dj = (int) max.getDay();
                if (day > dj)
                {
                    day = dj;
                }
                afficherGrille(day, month, year);
                FDate fd = new FDate(day, month, year);
                date = getDate(fd);
                dispatchEvent(evt);
            }
        });*/

        //button to select the next month
        next = new SButton("", 144, 0, 24, 24, this, sizeMultiplier);
        next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png")));
        next.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                if (month == 12)
                {
                    month = 1;
                    year += 1;
                }
                else
                {
                    month += 1;
                }
                day = 1;
                cboYear.setSelectedItem("" + year);
                cboMonth.setSelectedIndex(AstronomyMaths.modulo(month - 1, 12));
                FDate fd = new FDate(day, month, year, "");
                date = getDate(fd);
                dispatchEvent(evt);
            }
        });

        //labels for the first letter of the week day names
        sLabel1 = new SLabel(USWeekDays.getInitiale(0), 1, 12, 0, 24, 24, 24, this, sizeMultiplier);
        sLabel2 = new SLabel(USWeekDays.getInitiale(1), 1, 12, 24, 24, 24, 24, this, sizeMultiplier);
        sLabel3 = new SLabel(USWeekDays.getInitiale(2), 1, 12, 48, 24, 24, 24, this, sizeMultiplier);
        sLabel4 = new SLabel(USWeekDays.getInitiale(3), 1, 12, 72, 24, 24, 24, this, sizeMultiplier);
        sLabel5 = new SLabel(USWeekDays.getInitiale(4), 1, 12, 96, 24, 24, 24, this, sizeMultiplier);
        sLabel6 = new SLabel(USWeekDays.getInitiale(5), 1, 12, 120, 24, 24, 24, this, sizeMultiplier);
        sLabel7 = new SLabel(USWeekDays.getInitiale(6), 1, 12, 144, 24, 24, 24, this, sizeMultiplier);
    }
    
    private String getDate(FDate fd)
    {
        String sdate;
        if (MainClass.dateType == MainClass.DATEFR)
            sdate = fd.getFormatedDate().replace(" ", "");
        else
            sdate = fd.getDateUS();
        return sdate;
    }

    public Color getBkVacancyColor()
    {
        return bkVColor;
    }

    public Color getFgVacancyColor()
    {
        return fgVColor;
    }

    public Color getBkDaysColor()
    {
        return bkDColor;
    }

    public Color getFgDaysColor()
    {
        return fgDColor;
    }

    public Color getBkWeekDaysColor()
    {
        return bkWColor;
    }

    public Color getFgWeekDaysColor()
    {
        return fgWColor;
    }

    public Color getBkTopColor()
    {
        return bkTColor;
    }

    public Color getFgTopColor()
    {
        return fgTColor;
    }

    public Color getGridColor()
    {
        return gridColor;
    }

    public Color getContainerColor()
    {
        return backColor;
    }

    public void setBkVacancyColor(Color color)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (AstronomyMaths.modulo(i, 7) == 0)
            {
                if (days[i] != null)
                {
                    cdays[i] = color;
                }
            }
        }
        bkVColor = color;
    }

    public void setFgVacancyColor(Color color)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (AstronomyMaths.modulo(i, 7) == 0)
            {
                if (days[i] != null)
                {
                    days[i].setForeground(color);
                }
            }
        }
        fgVColor = color;
    }

    public void setBkDaysColor(Color color)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (AstronomyMaths.modulo(i, 7) != 0)
            {
                if (days[i] != null)
                {
                    cdays[i] = color;
                }
            }
        }
        bkDColor = color;
    }

    public void setFgDaysColor(Color color)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            if (AstronomyMaths.modulo(i, 7) != 0)
            {
                if (days[i] != null)
                {
                    days[i].setForeground(color);
                }
            }
        }
        fgDColor = color;
    }

    public void setBkWeekDaysColor(Color color)
    {
        sLabel1.setBackground(color);
        sLabel2.setBackground(color);
        sLabel3.setBackground(color);
        sLabel4.setBackground(color);
        sLabel5.setBackground(color);
        sLabel6.setBackground(color);
        sLabel7.setBackground(color);
        bkWColor = color;
    }

    public void setFgWeekDaysColor(Color color)
    {
        sLabel1.setForeground(color);
        sLabel2.setForeground(color);
        sLabel3.setForeground(color);
        sLabel4.setForeground(color);
        sLabel5.setForeground(color);
        sLabel6.setForeground(color);
        sLabel7.setForeground(color);
        fgWColor = color;
    }

    public void setBkTopColor(Color color)
    {
        cboMonth.setBackground(color);
        cboYear.setBackground(color);
        next.setBackground(color);
        prev.setBackground(color);
        bkTColor = color;
    }

    public void setFgTopColor(Color color)
    {
        cboMonth.setForeground(color);
        cboYear.setForeground(color);
        fgTColor = color;
    }

    public void setGridColor(Color color)
    {
        sLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        sLabel7.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        cboMonth.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        cboYear.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        for (int i = 0; i < GRID_SIZE; i++)
        {
            //int debut = getWeekDayOfFirst(month, year);
            if (days[i] != null)
            {
                days[i].setBackground(cdays[i]);
                seldays[i] = false;
                seldaynames[i] = "";
            }
            if (i + 1 - debut == day)
            {
                days[i].setBackground(selectionColor);
                seldays[i] = true;
                seldaynames[i] = date;
            }
        }
        next.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        prev.setBorder(javax.swing.BorderFactory.createLineBorder(color));
        gridColor = color;
    }

    public void setContainerColor(Color color)
    {
        this.setBackground(color);
        backColor = color;
    }

    private FDate getLastDayOfMonth(long month, long year)
    {
        double jd;
        double ddate;

        //last day of the month
        if (month < 12)
        {
            jd = AstronomyMaths.gregorianToJulian(1l, month + 1l, year) - 1; //from january to november
        }
        else
        {
            jd = AstronomyMaths.gregorianToJulian(1l, 1l, year + 1l) - 1;   //december
        }
        ddate = AstronomyMaths.julianToGregorian(jd);
        FDate max = new FDate(ddate);
        return max;
    }

    private int getWeekDayOfFirst(long month, long year)
    {
        //first day of the month
        double jd = AstronomyMaths.gregorianToJulian(1l, month, year);//julian day of the first day of the month
        double ddate = AstronomyMaths.julianToGregorian(jd);
        FDate min = new FDate(ddate);

        //week day number of the first day of the month
        debut = AstronomyMaths.getWeekDay(min.getDate().replace(" ", ""));
        return debut;
    }

    private void afficherGrille(long lday, long month, long year)
    {
        if (bSettingDate)
            return;
        
        //week day number of the first day of the month
        debut = getWeekDayOfFirst(month, year);

        //last day of the month
        FDate max = getLastDayOfMonth(month, year);

        //removing the buttons for the days from the components list
        Component cmps[] = this.getComponents();
        for (int i = nbStableControls; i < cmps.length; i++)
        {
            this.remove(cmps[i]);
        }
        //repaint();

        //adding the buttons for the days to the compenents list
        int ligne;
        for (int i = 0; i < GRID_SIZE; i++)
        {
            final int in = i - debut + 1;       //day number of the month
            final int id = (int) lday;          //day
            final int im = (int) month;         //month
            final int iy = (int) year;          //year
            final int index = i;                //index of the button
            final int deb = debut;              //index of the first visible button (first day of the month)
            //final int fin = (int) max.getDay() + debut;    //index of the last visible button (last day of the month)
            
            int colonne = AstronomyMaths.modulo(i, 7);  //column number of the day in the visual calendar
            ligne = (int) Math.floor(i / 7);               //line number of the day in th visual calendar

            //buttons for the days
            days[i] = new SLabel(new Integer(in).toString(), colonne * 24, (ligne * 24) + 48, 24, 24, this, sizeMultiplier);
            if (i >= debut && i < (int) max.getDay() + debut)
            {
                days[i].setVisible(true);
            }
            else
            {
                days[i].setVisible(false);
            }
            seldays[i] = false;

            //sundays
            if (colonne == 0)
            {
                cdays[i] = bkVColor;
            }
            else
            {
                cdays[i] = bkDColor;
            }

            //selected day
            if (i + 1 - deb == id)
            {
                seldays[i] = true;
                numSelDay = i;
            }

            //detect mouse clics on the buttons for the days
            days[i].addMouseListener(new java.awt.event.MouseAdapter()
            {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt)
                {
                    numSelDay = index;
                    
                    //formatting the date
                    FDate fd = new FDate(in, im, iy, "");
                    date = getDate(fd);

                    //set the day
                    day = in;

                    //selected day by the clic of the mouse on a given button for the days
                    if (days[index].getBackground().getRGB() == selectionColor.getRGB())
                    {
                        days[index].setBackground(cdays[index]);
                        seldays[index] = false;
                        seldaynames[index] = "";
                        bSelected = false;
                    }
                    else
                    {
                        days[index].setBackground(selectionColor);
                        seldays[index] = true;
                        seldaynames[index] = date;
                        bSelected = true;
                    }
                    
                    repaint();

                    //to dispatch the event to the parent container and add code there
                    dispatchEvent(evt);
                }
            });
            add(days[i]);
        }
        setColors();
        repaint();
    }

    private class SLabel extends JLabel
    {
        private SLabel current = this;
        public SLabel(String label, int left, int top, int x, int y, JPanel contentPane, double sizeMultiplier)
        {
            super(label);
            setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
            setBounds((int) Math.round(left * sizeMultiplier), (int) Math.round(top * sizeMultiplier), (int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1));
            setBorder(javax.swing.BorderFactory.createLineBorder(gridColor));
            setOpaque(true);
            setHorizontalAlignment(SwingConstants.CENTER);
            contentPane.add(current);
        }

        public SLabel(String label, int horizontal, int taillePolice, int left, int top, int x, int y, JPanel contentPane, double sizeMultiplier)
        {
            super(label);
            setFont(new java.awt.Font("Arial", 1, (int) Math.round(taillePolice * sizeMultiplier)));
            setBounds((int) Math.round(left * sizeMultiplier), (int) Math.round(top * sizeMultiplier), (int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1));
            if (horizontal == 0)
            {
                setHorizontalAlignment(SwingConstants.LEFT);
            }
            else if (horizontal == 1)
            {
                setHorizontalAlignment(SwingConstants.CENTER);
            }
            else if (horizontal == 2)
            {
                setHorizontalAlignment(SwingConstants.RIGHT);
            }
            setOpaque(true);
            setBorder(javax.swing.BorderFactory.createLineBorder(gridColor));
            contentPane.add(current);
        }
    }

    private class SButton extends JButton
    {
        private SButton current = this;
        public SButton(String label, int left, int top, int x, int y, JPanel contentPane, double sizeMultiplier)
        {
            super(label);
            setFont(new java.awt.Font("Arial", 1, (int) Math.round(12 * sizeMultiplier)));
            setBounds((int) Math.round(left * sizeMultiplier), (int) Math.round(top * sizeMultiplier), (int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1));
            setBorder(javax.swing.BorderFactory.createLineBorder(gridColor));
            setOpaque(true);
            contentPane.add(current);
        }
    }

    private class SText extends JTextField
    {
        private SText current = this;
        public SText(String text, int horizontal, int taillePolice, int left, int top, int x, int y, JPanel contentPane, double sizeMultiplier)
        {
            super(text);
            setFont(new java.awt.Font("Arial", 1, (int) Math.round(taillePolice * sizeMultiplier)));
            setBounds((int) Math.round(left * sizeMultiplier), (int) Math.round(top * sizeMultiplier), (int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1));
            setBorder(javax.swing.BorderFactory.createLineBorder(gridColor));
            if (horizontal == 0)
            {
                setHorizontalAlignment(SwingConstants.LEFT);
            }
            else if (horizontal == 1)
            {
                setHorizontalAlignment(SwingConstants.CENTER);
            }
            else if (horizontal == 2)
            {
                setHorizontalAlignment(SwingConstants.RIGHT);
            }
            contentPane.add(current);
        }
    }

    private class SCombo extends JComboBox
    {
        private SCombo current = this;
        public SCombo(int index, int taillePolice, int left, int top, int x, int y, JPanel contentPane, double sizeMultiplier, DefaultComboBoxModel comboModel)
        {
            super();
            setModel(comboModel);
            setSelectedIndex(index);
            setFont(new java.awt.Font("Arial", 1, (int) Math.round(taillePolice * sizeMultiplier)));
            setBounds((int) Math.round(left * sizeMultiplier), (int) Math.round(top * sizeMultiplier), (int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1));
            setPreferredSize(new Dimension((int) Math.round(x * sizeMultiplier + 1), (int) Math.round(y * sizeMultiplier + 1)));
            setBorder(javax.swing.BorderFactory.createLineBorder(gridColor));
            setMaximumRowCount(12);
            setOpaque(true);
            contentPane.add(current);
        }
    }
}
