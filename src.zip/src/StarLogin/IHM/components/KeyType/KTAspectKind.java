package StarLogin.IHM.components.KeyType;

import java.awt.Color;
import java.awt.event.KeyEvent;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class KTAspectKind
{
    /** Creates new KTAspectKind */
    public KTAspectKind(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int size, Color neutralColor, Color dynamicColor, Color harmonicColor, int kc)
    {
        String sText = textBox.getText();
        if (sText.length() >= size && (kc != KeyEvent.VK_BACK_SPACE) && (kc != KeyEvent.VK_DELETE))
        {
            evt.consume();
            return;
        }
        
        char ch = evt.getKeyChar();
        sText = new Character(ch).toString();
        
        //modify the color
        if ((ch == 'n') ||(ch == 'd') || (ch == 'h') || (ch == 'N') ||(ch == 'D') || (ch == 'H'))
        {
            if ((ch == 'n') ||(ch == 'N')) textBox.setForeground(neutralColor);
            else if ((ch == 'd') ||(ch == 'D')) textBox.setForeground(dynamicColor);
            else if ((ch == 'h') ||(ch == 'H')) textBox.setForeground(harmonicColor);
        }
        
        //process the key
        if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP) && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (ch != 'N') && (ch != 'D') && (ch != 'H') && (ch != 'n') && (ch != 'd') && (ch != 'h'))
        {
            evt.consume();
        }
        else if ((ch == 'n') ||(ch == 'd') || (ch == 'h'))
        {
            sText = sText.toUpperCase();
            textBox.setText(sText);
            evt.consume();
        }
    }
}
