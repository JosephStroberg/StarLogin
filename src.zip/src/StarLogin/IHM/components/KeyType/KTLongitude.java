package StarLogin.IHM.components.KeyType;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */

import StarLogin.IHM.MainClass;
import java.awt.event.KeyEvent;

public class KTLongitude
{
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    /** Creates new KTLongitude */
    public KTLongitude(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int kc)
    {
        //int kc = evt.getKeyCode();
        if ((kc == KeyEvent.VK_RIGHT)||(kc == KeyEvent.VK_LEFT)||(kc == KeyEvent.VK_TAB)||(kc == KeyEvent.VK_ENTER))
            return;
        String sText = textBox.getText();
        String signe = sText.substring(0, 1);
            
        int debut = textBox.getSelectionStart();
        int fin = textBox.getSelectionEnd();
        int newCaret = fin;
        if (Character.isDigit(evt.getKeyChar()) || evt.getKeyChar()=='-' || evt.getKeyChar()==' ' || evt.getKeyChar()=='+')
        {
            if (debut == 4)
                debut = 5;
            else if (debut == 7)
                debut = 8;
        }
        if (fin < debut)
            fin = debut;

        if ((kc == KeyEvent.VK_DELETE)||(kc == KeyEvent.VK_BACK_SPACE))
        {
            if (fin>10)
                fin = 10;
            if (fin==debut && kc == KeyEvent.VK_BACK_SPACE && debut>0)
                debut -= 1;
            evt.consume();
            if (debut==0 && kc == KeyEvent.VK_BACK_SPACE)
                sText = processChars(sText, ' ', debut, fin);
            else
                sText = processChars(sText, '0', debut, fin);
            textBox.setText(sText);
            if (kc == KeyEvent.VK_DELETE)
                newCaret = fin;
            else
                newCaret = debut;
            textBox.setCaretPosition(newCaret);
            return;
        }
        else if (debut >= 0 && debut <= 4)
        {
            String sd = sText.substring(1, 4);
            int d = new Integer(sd).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (d == 0)
                        d = 180;
                    else
                        d -= 1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    if (d == 180)
                        d = 0;
                    else
                        d += 1;
                }
                sd = String.valueOf(d);
                if (d < 10)
                    sd = "00".concat(sd);
                else if (d<100)
                    sd = "0".concat(sd);
                sText = signe.concat(sd).concat(sText.substring(4, 11));
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                if (!Character.isDigit(evt.getKeyChar()) && evt.getKeyChar()!='-' && evt.getKeyChar()!=' ' && evt.getKeyChar()!='+')
                {
                    evt.consume();
                }
                else if (evt.getKeyChar()=='-')
                {
                    sText = "-".concat(sText.substring(1));
                    textBox.setText(sText);
                    newCaret = 1;
                    evt.consume();
                }
                else if (evt.getKeyChar()==' '||evt.getKeyChar()=='+')
                {
                    sText = " ".concat(sText.substring(1));
                    textBox.setText(sText);
                    newCaret = 1;
                    evt.consume();
                }
                else
                {
                    if (debut == 0)
                        debut = 1;
                    sText = processChars(sText, evt.getKeyChar(), debut, fin);
                    textBox.setText(sText);
                    if(textBox.getText().length()>debut)
                        newCaret = debut+1;
                    evt.consume();
                }
            }
        }
        else if (debut >= 5 && debut <= 7)
        {
            String smn = sText.substring(5, 7);
            int mn = new Integer(smn).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (mn == 0)
                        mn = 59;
                    else
                        mn -=1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    if (mn == 59)
                        mn = 0;
                    else
                        mn +=1;
                }
                smn = String.valueOf(mn);
                if (mn < 10)
                    smn = "0".concat(smn);
                sText = sText.substring(0, 5).concat(smn).concat(sText.substring(7));
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                sText = processChars(sText, evt.getKeyChar(), debut, fin);
                textBox.setText(sText);
                if (textBox.getText().length() > debut)
                    newCaret = debut+1;
                evt.consume();
            }
        }
        else if (debut >= 8 && debut <= 10)
        {
            String ss = sText.substring(8, 10);
            int s = new Integer(ss).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (s == 0)
                        s = 59;
                    else
                        s -=1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    if (s == 59)
                        s = 0;
                    else
                        s +=1;
                }
                ss = String.valueOf(s);
                if (s < 10)
                    ss = "0".concat(ss);
                sText = sText.substring(0, 8).concat(ss).concat(sText.substring(10));
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                sText = processChars(sText, evt.getKeyChar(), debut, fin);
                textBox.setText(sText);
                if (textBox.getText().length() > debut)
                    newCaret = debut+1;
                evt.consume();
            }
        }
        else if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_ALT) && (kc != KeyEvent.VK_CONTROL) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP)  && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (!Character.isDigit(evt.getKeyChar()) || ((sText.length() >= 8) && (textBox.getSelectionEnd() == textBox.getSelectionStart()))))
        {
            evt.consume();
        }
        
        String tmp = sText.substring(1, 4);
        int value = Integer.valueOf(tmp).intValue();
        if (value > 180)
        {
            sText = signe.concat("180").concat(sText.substring(4));
            textBox.setText(sText);
            newCaret = 5;
        }
        tmp = sText.substring(5, 7);
        value = Integer.valueOf(tmp).intValue();
        if (value > 59)
        {
            sText = sText.substring(0, 5).concat("59").concat(sText.substring(7));
            textBox.setText(sText);
            newCaret = 8;
        }
        tmp = sText.substring(8, 10);
        value = Integer.valueOf(tmp).intValue();
        if (value > 59)
        {
            sText = sText.substring(0, 8).concat("59").concat(sText.substring(10));
            textBox.setText(sText);
            newCaret = 10;
        }
        textBox.setCaretPosition(newCaret);
    }
    
    private String processChars(String data, char digit, int debut, int fin)
    {
        char caracteres[] = data.toCharArray();
        if (fin == debut)
            fin ++;
        if (fin>caracteres.length)
            fin = caracteres.length;
        for (int i=debut; i<fin; i++)
        {
            if (Character.isDigit(caracteres[i]))
            {
                if (debut!=i)
                    caracteres[i] = '0';
                else if (Character.isDigit(digit))
                    caracteres[i] = digit;
            }
            else if (debut == i && i < caracteres.length - 1 && Character.isDigit(digit))
            {
                i++;
                caracteres[i] = digit;
            }
            else if (debut == 0 &&(digit=='-'||digit==' '))
            {
                caracteres[0] = digit;
                break;
            } 
        }
        return new String(caracteres);
    }
}
