package StarLogin.IHM.components.KeyType;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 */
public class KTDate
{

    /** Creates new KTDate */
    public KTDate(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int kc)
    {
        if (MainClass.dateType == MainClass.DATEFR)
        {
            KTDateFr dfr = new KTDateFr(evt, textBox, kc);
        }
        else
        {
            KTDateUs dus = new KTDateUs(evt, textBox, kc);
        }
    }
}