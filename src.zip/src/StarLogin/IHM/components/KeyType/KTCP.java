package StarLogin.IHM.components.KeyType;

import java.awt.event.KeyEvent;

/**
 *
 * @author Francois DESCHAMPS
 */
public class KTCP
{

    /** Creates new KTDate */
    public KTCP(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int kc)
    {
        String sText = textBox.getText();
        //int kc = evt.getKeyCode();
        int cp = textBox.getCaretPosition();
        int l = sText.length();
        char ch = evt.getKeyChar();

        if ((sText.length() >= 7) && (kc != KeyEvent.VK_BACK_SPACE) && (kc != KeyEvent.VK_DELETE) && (textBox.getSelectionEnd() != sText.length()))
        {
            evt.consume();
        }
        else if (l == 3 && cp == 3 && kc != KeyEvent.VK_BACK_SPACE && kc != KeyEvent.VK_DELETE)
        {
            if (Character.isDigit(ch)||Character.isLetter(ch))
            {
                textBox.setText(sText + " ");
            }
            else if ((l == 0) && (cp == 0))
            {
                if (ch != ' ')
                {
                    evt.consume();
                }
            }
            else
            {
                evt.consume();
            }
        }
        else if (((l == 0 && cp == 0)||(l == 2 && cp == 2)||(l == 5 && cp == 5)) && kc != KeyEvent.VK_BACK_SPACE && kc != KeyEvent.VK_DELETE && !Character.isLetter(ch))
        {
            evt.consume();
        }
        else if (((l == 1 && cp == 1)||(l == 4 && cp == 4)||(l == 6 && cp == 6)) && kc != KeyEvent.VK_BACK_SPACE && kc !=0 && kc != KeyEvent.VK_DELETE && kc != KeyEvent.VK_ENTER && !Character.isDigit(ch))
        {
            evt.consume();
        }
        else if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_ALT) && (kc != KeyEvent.VK_CONTROL) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP) && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (!(Character.isDigit(ch)||Character.isLetter(ch)||kc==0) || ((sText.length() >= 7) && (textBox.getSelectionEnd() == textBox.getSelectionStart()))))
        {
            evt.consume();
        }
    }
}