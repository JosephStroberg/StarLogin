package StarLogin.IHM.components.KeyType;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class KTDateAstro
{
    /** Creates new KTDate */
    public KTDateAstro(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int kc)
    {
        if (MainClass.dateType == MainClass.DATEFR)
        {
            KTDateAstroFr dfr = new KTDateAstroFr(evt, textBox, kc);
        }
        else
        {
            KTDateAstroUs dus = new KTDateAstroUs(evt, textBox, kc);
        }
    }
    
    public KTDateAstro(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, boolean bDontCheck, int kc)
    {
        if (MainClass.dateType == MainClass.DATEFR)
        {
            KTDateAstroFr dfr = new KTDateAstroFr(evt, textBox, bDontCheck, kc);
        }
        else
        {
            KTDateAstroUs dus = new KTDateAstroUs(evt, textBox, bDontCheck, kc);
        }
    }
}