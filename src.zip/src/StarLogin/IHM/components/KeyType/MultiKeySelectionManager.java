/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM.components.KeyType;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.Timer;

/**
 *
 * @author Francois
 */
public class MultiKeySelectionManager implements JComboBox.KeySelectionManager
{

    private final static int RESET_DELAY = 1000;
    private StringBuffer currentSearch = new StringBuffer();
    private Timer resetTimer;
    private boolean btyped = false;
    private long starttime = Long.MAX_VALUE;
    private long curtime = 0l;
    private GregorianCalendar gc;
    
    public boolean isTyping()
    {
        return btyped;
    }

    public MultiKeySelectionManager()
    {
        final TimeZone timeZone = TimeZone.getDefault();
        //int timz = timeZone.getRawOffset() + timeZone.getDSTSavings();
        //double dblTZ = (double) timz / 3600000.0;

        //get the current date on the system
        gc = new GregorianCalendar(timeZone);
        
        resetTimer = new Timer(RESET_DELAY, new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
                currentSearch.setLength(0);
                btyped = false;
            }
        });
        
    }

    @Override
    public int selectionForKey(char aKey, ComboBoxModel aModel)
    {

        // Reset if invalid character
        if (aKey == KeyEvent.CHAR_UNDEFINED)
        {
            currentSearch.setLength(0);
            btyped = false;
            return -1;
        }

        // Since search, don't reset search
        resetTimer.stop();
        
        curtime = gc.getTimeInMillis();
        if (curtime - starttime > RESET_DELAY)
            btyped = false;
        else
            btyped = true;

        // Convert input to uppercase
        char key = Character.toUpperCase(aKey);

        // Build up search string
        currentSearch.append(key);

        // Find selected position within model to starting searching from
        Object selectedElement = aModel.getSelectedItem();
        int selectedIndex = -1;

        if (selectedElement != null)
        {
            for (int i = 0, n = aModel.getSize(); i < n; i++)
            {
                if (aModel.getElementAt(i) == selectedElement)
                {
                    selectedIndex = i;

                    break;
                }
            }
        }

        boolean found = false;
        String search = currentSearch.toString();

        // Search from selected forward, wrap back to beginning if not found
        for (int i = 0, n = aModel.getSize(); i < n; i++)
        {
            if (aModel.getElementAt(selectedIndex) != null)
            {
                String element = aModel.getElementAt(selectedIndex).toString().toUpperCase();

                if (element.startsWith(search))
                {
                    found = true;

                    break;
                }
            }

            selectedIndex++;

            if (selectedIndex == n)
            {
                selectedIndex = 0;    // wrap
            }
        }

        // Restart timer
        resetTimer.start();
        starttime = gc.getTimeInMillis();
        return (found
                ? selectedIndex
                : -1);
    }
}
