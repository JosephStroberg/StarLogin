package StarLogin.IHM.components.KeyType;

import java.awt.event.KeyEvent;
import javax.swing.JTextField;

/**
 *
 * @author Francois DESCHAMPS
 */
public class KTInteger
{    
    public KTInteger(KeyEvent evt, JTextField textBox, int size, int kc)
    {
        char ch = evt.getKeyChar();
        
        if (textBox.getText().length() >= size && (kc != KeyEvent.VK_BACK_SPACE) && (kc != KeyEvent.VK_DELETE))
        {
            if (textBox.getText().length() >= size && textBox.getSelectedText().length() == 0)
                evt.consume();
            else if (!(Character.isDigit(ch) && textBox.getText().length() <= size))
                evt.consume();
        }
        else if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_ALT) && (kc != KeyEvent.VK_CONTROL) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP) && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (!Character.isDigit(ch)) && (ch != '-'))
        {
            evt.consume();
        }
        else if ((textBox.getCaretPosition() > 1) && (ch == '-'))
        {
            evt.consume();
        }
    }
}
