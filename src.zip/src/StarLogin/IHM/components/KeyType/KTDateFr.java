package StarLogin.IHM.components.KeyType;

import java.awt.event.KeyEvent;

/**
 *
 * @author Francois DESCHAMPS
 */
public class KTDateFr
{

    /** Creates new KTDate */
    public KTDateFr(java.awt.event.KeyEvent evt, javax.swing.JTextField textBox, int kc)
    {
        //int kc = evt.getKeyCode();
        if ((kc == KeyEvent.VK_RIGHT)||(kc == KeyEvent.VK_LEFT)||(kc == KeyEvent.VK_TAB)||(kc == KeyEvent.VK_ENTER))
            return;
        String sText = textBox.getText();
        
        int debut = textBox.getSelectionStart();
        int fin = textBox.getSelectionEnd();
        int newCaret = fin;
        if (Character.isDigit(evt.getKeyChar()))
        {
            if (debut == 2)
                debut = 3;
            else if (debut == 5)
                debut = 6;
        }
        if (fin < debut)
            fin = debut;

        if ((kc == KeyEvent.VK_DELETE)||(kc == KeyEvent.VK_BACK_SPACE))
        {
            if (fin>10)
                fin = 10;
            if (fin==debut && kc == KeyEvent.VK_BACK_SPACE && debut>0)
                debut -= 1;
            evt.consume();
            sText = processChars(sText, '0', debut, fin);
            textBox.setText(sText);
            if (kc == KeyEvent.VK_DELETE)
                newCaret = fin;
            else
                newCaret = debut;
            textBox.setCaretPosition(newCaret);
            //return;
        }
        else if (debut >= 0 && debut <= 2)
        {
            String sj = sText.substring(0, 2);
            int j = new Integer(sj).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (j == 0||j == 1)
                        j = 31;
                    else
                        j -= 1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    String mois = sText.substring(3,5);
                    int vm = Integer.valueOf(mois);
                    if ((j == 31 && (vm==1||vm==3||vm==5||vm==7||vm==8||vm==10||vm==12))||(j == 30 && (vm==4||vm==6||vm==9||vm==11))||(j == 29 && vm==2))
                        j = 1;
                    else
                        j += 1;
                }
                sj = String.valueOf(j);
                if (j < 10)
                    sj = "0".concat(sj);
                sText = sj.concat(sText.substring(2));
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                if (!Character.isDigit(evt.getKeyChar()))
                {
                    evt.consume();
                }
                else
                {
                    sText = processChars(sText, evt.getKeyChar(), debut, fin);
                    textBox.setText(sText);
                    if(textBox.getText().length()>debut)
                        newCaret = debut+1;
                    evt.consume();
                }
            }
        }
        else if (debut >= 3 && debut <= 5)
        {
            String smois = sText.substring(3, 5);
            int mois = new Integer(smois).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (mois == 0||mois == 1)
                        mois = 12;
                    else
                        mois -=1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    if (mois == 12)
                        mois = 1;
                    else
                        mois +=1;
                }
                smois = String.valueOf(mois);
                if (mois < 10)
                    smois = "0".concat(smois);
                sText = sText.substring(0, 3).concat(smois).concat(sText.substring(5));
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                sText = processChars(sText, evt.getKeyChar(), debut, fin);
                textBox.setText(sText);
                if (textBox.getText().length() > debut)
                    newCaret = debut+1;
                evt.consume();
            }
        }
        else if (debut >= 6 && debut <= 10)
        {
            String sannee = sText.substring(6, 10);
            int annee = new Integer(sannee).intValue();
            if ((kc == KeyEvent.VK_DOWN)||(kc == KeyEvent.VK_UP))
            {
                if (kc == KeyEvent.VK_DOWN)
                {
                    if (annee == 0)
                        annee = 9999;
                    else
                        annee -= 1;
                }
                else if (kc == KeyEvent.VK_UP)
                {
                    if (annee == 9999)
                        annee = 0;
                    else
                        annee += 1;
                }
                sannee = String.valueOf(annee);
                if (annee < 10)
                    sannee = "000".concat(sannee);
                else if (annee < 100)
                    sannee = "00".concat(sannee);
                else if (annee < 1000)
                    sannee = "0".concat(sannee);
                sText = sText.substring(0, 6).concat(sannee);
                textBox.setText(sText);
                newCaret = debut;
                evt.consume();
            }
            else
            {
                sText = processChars(sText, evt.getKeyChar(), debut, fin);
                textBox.setText(sText);
                if (textBox.getText().length() > debut)
                    newCaret = debut+1;
                evt.consume();
            }
        }
        else if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_ALT) && (kc != KeyEvent.VK_CONTROL) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP)  && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (!Character.isDigit(evt.getKeyChar()) || ((sText.length() >= 8) && (textBox.getSelectionEnd() == textBox.getSelectionStart()))))
        {
            evt.consume();
        }
        
        String tmp = sText.substring(3, 5);
        int value = Integer.valueOf(tmp).intValue();
        if (value > 12||value < 1)
        {
            if (value > 12)
            {
                tmp = "12";
                value = 12;
            }
            else
            {
                tmp = "01";
                value = 1;
            }
            sText = sText.substring(0, 3).concat(tmp).concat(sText.substring(5));
            textBox.setText(sText);
            newCaret = 6;
        }
        int valuemois = value;
        tmp = sText.substring(0, 2);
        value = Integer.valueOf(tmp).intValue();
        if (value > 31 && (valuemois==1||valuemois==3||valuemois==5||valuemois==7||valuemois==8||valuemois==10||valuemois==12))
        {
            sText = "31".concat(sText.substring(2));
            textBox.setText(sText);
            newCaret = 3;
        }
        else if (value > 30 && (valuemois==4||valuemois==6||valuemois==9||valuemois==11))
        {
            sText = "30".concat(sText.substring(2));
            textBox.setText(sText);
            newCaret = 3;
        }
        else if (value > 29 && (valuemois==2))
        {
            sText = "29".concat(sText.substring(2));
            textBox.setText(sText);
            newCaret = 3;
        }
        else if (value < 1)
        {
            sText = "01".concat(sText.substring(2));
            textBox.setText(sText);
            newCaret = 3;
        }
        textBox.setCaretPosition(newCaret);
    }
    
    private String processChars(String data, char digit, int debut, int fin)
    {
        char caracteres[] = data.toCharArray();
        if (fin == debut)
            fin ++;
        if (fin>caracteres.length)
            fin = caracteres.length;
        for (int i=debut; i<fin; i++)
        {
            if (Character.isDigit(caracteres[i]))
            {
                if (debut!=i)
                    caracteres[i] = '0';
                else if (Character.isDigit(digit))
                    caracteres[i] = digit;
            }
            else if (debut == i && i < caracteres.length - 1 && Character.isDigit(digit))
            {
                i++;
                caracteres[i] = digit;
            }
        }
        return new String(caracteres);
    }
}
