/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM.components;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Records;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author Francois
 */
public class ComboStatusRenderer extends JLabel implements ListCellRenderer
{
    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
        setBackground(isSelected ? list.getSelectionBackground() : null);
        //ImageIcon imgicon;
        Records statutrdvs = MainClass.starLoginManager.getRecords("SELECT ID, NOM, COULEUR FROM statutrdv WHERE NOM is not null", "statutrdv");
        if (value == null)
            value = "";
        String text = String.valueOf(value);
        ArrayList statuts = statutrdvs.getRecords();
        
        //String rscpath = MainClass.getFilePathOnServer("img").concat("rsc");
        //java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        setText(text);
        boolean bFound = false;
        for (int i = 0; i < statuts.size(); i++)
        {
            ArrayList row = (ArrayList) statuts.get(i);
            if (text.equals(String.valueOf(row.get(1))))
            {
                String scouleur = String.valueOf(row.get(2));
                if (scouleur == null||scouleur.equals("")||scouleur.equals("null"))
                    scouleur = "0";
                Color couleur = new Color(Integer.valueOf(scouleur));
                setForeground(couleur);
                int icol = couleur.getRGB();
                
                int w = 16;
                int h = 16;
                BufferedImage nouvelleImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
                int[] rgbs = new int[w*h];
                for (int j = 0; j< w*h; j++)
                {
                    rgbs[j] = icol;
                }
                nouvelleImage.setRGB(0,0,w,h,rgbs,0,w);
                ImageIcon imgicon = new ImageIcon(nouvelleImage);
                setIcon(imgicon);
                bFound = true;
                break;
            }
        }
        if (!bFound)
        {
            setForeground(Color.BLACK);
            setIcon(null);
        }
        return this;
    }

    BufferedImage toBufferedImage(Image image)
    {
        /**
         * On test si l'image n'est pas d�ja une instance de BufferedImage
         */
        if (image instanceof BufferedImage)
        {
            return ((BufferedImage) image);
        }
        else
        {
            /**
             * On s'assure que l'image est compl�tement charg�e
             */
            image = new ImageIcon(image).getImage();

            /**
             * On cr�e la nouvelle image
             */
            BufferedImage bufferedImage = new BufferedImage(
                    image.getWidth(null),
                    image.getHeight(null),
                    BufferedImage.TYPE_INT_RGB);

            Graphics g = bufferedImage.createGraphics();
            g.drawImage(image, 0, 0, null);
            g.dispose();

            return (bufferedImage);
        }
    }
    //note : ne pr�serve pas la transparence de l'image de base. 
}
