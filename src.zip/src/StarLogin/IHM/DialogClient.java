/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.KTDate;
import StarLogin.IHM.components.KeyType.KTTime;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.*;
/**
 *
 * @author Francois
 */
public class DialogClient extends JDialog
{
    private StarLoginManager starLoginManager;
    private Record client;
    private Records clients;
    private String sQuery = "SELECT ID,FIRSTNAME,OTHERNAMES,ADDRESS,CITY,ZIPCODE,STATEPROVINCE,COUNTRY,AGE,GENDER,FAMILYSTATUS,OCCUPATIONS,RANK,MAINHOBBIES,RELIGION,BIRTHDATE,BIRTHTIME,BIRTHPLACE,PHONE,TELBUREAU,CELL,COURRIEL,COMPAGNIE,ADRESSECOMP,VILLECOMP,PROVINCECOMP,PAYSCOMP,ZIPCOMP,TELCOMP,FAXCOMP,WEBCOMP,GROUPEID,NOTE,PICTURE FROM clients";
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private java.util.ResourceBundle bundle;
    private DataBaseRecord dbr;
    private DefaultComboBoxModel cmGroupesContacts;
    private String clientID;
    private String name;
    private String othernames;
    private String address;
    private String city;
    private String zipcode;
    private String stateprovince;
    private String country;
    private String age;
    private String gender;
    private String familystatus;
    private String occupations;
    private String rank;
    private String hobbies;
    private String religion;
    private String birthdate;
    private String birthtime;
    private String birthplace;
    private String phone;
    private String telbureau;
    private String cell;
    private String courriel;
    private String compagnie;
    private String adressecomp;
    private String villecomp;
    private String provincecomp;
    private String payscomp;
    private String zipcomp;
    private String telcomp;
    private String faxcomp;
    private String webcomp;
    private String groupeid;
    private String note;
    private ImageIcon picture;
    private int kc; //key code
    private int cp; //caret position
    private boolean bSetting = true;
    private String saveNom = "";
    private String savePrenom = "";
    private String saveTel = "";
    private Window parentForm;

    /**
     * Creates new form DialogClient
     */
    public DialogClient(java.awt.Frame parent, boolean modal, String clientid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        clientID = clientid;
        setDlg();
    }
    
    public DialogClient(java.awt.Dialog parent, boolean modal, String clientid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        clientID = clientid;
        setDlg();
    }
    
    public DialogClient(java.awt.Frame parent, boolean modal, String clientid, String groupeid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        this.groupeid = groupeid;
        clientID = clientid;
        setDlg();
    }
    
    public DialogClient(java.awt.Dialog parent, boolean modal, String clientid, String groupeid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        this.groupeid = groupeid;
        clientID = clientid;
        setDlg();
    }
    
    public DialogClient(java.awt.Frame parent, boolean modal, String clientid, String nom, String prenom, String telclient)
    {
        super(parent, modal);
        saveNom = nom;
        savePrenom = prenom;
        saveTel = telclient;
        parentForm = (Window) parent;
        clientID = clientid;
        setDlg();
    }
    
    public DialogClient(java.awt.Dialog parent, boolean modal, String clientid, String nom, String prenom, String telclient)
    {
        super(parent, modal);
        saveNom = nom;
        savePrenom = prenom;
        saveTel = telclient;
        parentForm = (Window) parent;
        clientID = clientid;
        setDlg();
    }
    
    private void setDlg()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;
        if (clientID.equals("-1"))
            bolAdding = true;

        bundle = MainClass.bundle;
        initComponents();
        
        //String titre = MainClass.starLoginManager.getStringFieldValue("groupes", "GROUPE", "");
        setTitle(bundle.getString("Contacts"));
        
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        
        Color fEO = Options.getColor("EtiquetteObligatoire.background");
        Color pEO = Options.getColor("EtiquetteObligatoire.foreground");
        Color fTO = Options.getColor("SaisieObligatoire.background");
        Color pTO = Options.getColor("SaisieObligatoire.foreground");
        lblNom.setBackground(fEO);
        lblNom.setForeground(pEO);
        txtNom.setBackground(fTO);
        txtNom.setForeground(pTO);
        //lblAutresNoms.setBackground(fEO);
        //lblAutresNoms.setForeground(pEO);
        //lblAutresNoms.setBackground(fTO);
        //lblAutresNoms.setForeground(pTO);
        lblGroupeContacts.setBackground(fEO);
        lblGroupeContacts.setForeground(pEO);
        cboGroupesContacts.setBackground(fTO);
        cboGroupesContacts.setForeground(pTO);

        setCombos();
        if (clientID.equals(""))
            clientID = "-1";
        refreshRecord();
        setDataToText();
        if (clientID.equals("-1"))
        {
            name = saveNom;
            othernames = savePrenom;
            phone = saveTel;
            txtNom.setText(name);
            txtAutresNoms.setText(othernames);
            txtTelephone.setText(phone);
            bolAdding = true;
            bolEditing = true;
            setEditMode();
        }
        else
            setNormalMode();
        resetLangue();
        bSetting = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        this.setVisible(true);
    }
    
    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setTextToData();
            
            //verification champs nom ou prenom remplis
            boolean bPasNom = true;
            boolean bPasPrenom = true;
            
            if (!name.equals(""))
                bPasNom = false;
            if (!othernames.equals(""))
                bPasPrenom = false;
            if (bPasNom && bPasPrenom)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("FournirNomOuPrenom"), JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (groupeid.equals("")|| groupeid.equals("-1"))
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("DataObligatoirePasRemplies").concat("\n").concat(lblGroupeContacts.getText()), JOptionPane.WARNING_MESSAGE);
                return false;
            }
            
            //update data
            client.setAdding(bolAdding);
            client.setData(1, name);
            client.setData(2, othernames);
            client.setData(3, address);
            client.setData(4, city);
            client.setData(5, zipcode);
            client.setData(6, stateprovince);
            client.setData(7, country);
            client.setData(8, age);
            client.setData(9, gender);
            client.setData(10, familystatus);
            client.setData(11, occupations);
            client.setData(12, rank);
            client.setData(13, hobbies);
            client.setData(14, religion);
            client.setData(15, FDate.fr2us(birthdate));
            client.setData(16, FTime.set24(birthtime));
            client.setData(17, birthplace);
            client.setData(18, phone);
            client.setData(19, telbureau);
            client.setData(20, cell);
            client.setData(21, courriel);
            client.setData(22, compagnie);
            client.setData(23, adressecomp);
            client.setData(24, villecomp);
            client.setData(25, provincecomp);
            client.setData(26, payscomp);
            client.setData(27, zipcomp);
            client.setData(28, telcomp);
            client.setData(29, faxcomp);
            client.setData(30, webcomp);
            client.setData(31, groupeid);
            client.setData(32, note);
            client.setPicture(picture);
            starLoginManager.setRecord(client, dbr);
            /*if (bolAdding)
            {
                clientID = starLoginManager.getStringFieldValue("clients", "max(id)", " WHERE NAME='" + name.replace("'", "''") + "'");
            }*/
            clientID = client.getId();
            updateInstances();
            bolEditing = false;
            bolAdding = false;
            setNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    public void setPicture(ImageIcon data)
    {
        picture = data;
        bolEditing = true;
        setEditMode();
    }
    
    private void updateInstances()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof ListeClientForm)
            {
                ((ListeClientForm)windows[i]).setClient(false, clientID);
                //((ListeClientForm)windows[i]).setPicture(picture);
            }
            else if (windows[i] instanceof DialogRdv)
                ((DialogRdv)windows[i]).setClient(clientID);
            //else if (windows[i] instanceof ConsultationsForm)
            //    ((ConsultationsForm)windows[i]).setClient(clientID);
            /*else if (windows[i] instanceof CaisseForm)
                ((CaisseForm)windows[i]).setClient(clientID);
            else if (windows[i] instanceof InventaireForm)
                ((InventaireForm)windows[i]).setFournisseurID(clientID);*/
        }
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }

    /*public void setPicture(String data)
    {
        /*if (data != null && !data.equals(""))
        {
            photo = data;
            if (!bSetting)
            {
                bolEditing = true;
                setEditMode();
            }
        }
        else if (data == null)
        {
            photo = "";
            if (!bSetting)
            {
                bolEditing = true;
                setEditMode();
            }
        }
        reloadPicture();
        picture = data;
    }*/

    private void reloadPicture()
    {
        pnlPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, pnlPhoto.getPreferredSize());
        pnlPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(picture);
        //imageSurface.setMenuEnabled(bolEditing);
    }
    
    @SuppressWarnings("unchecked")
    private void setCombos()
    {
        cboSexe.setModel(new javax.swing.DefaultComboBoxModel(new String[] {bundle.getString("F"), bundle.getString("H")}));
        DefaultComboBoxModel comboModel = starLoginManager.getListe("SELECT DISTINCT GROUPE,ID FROM groupes" + " ORDER BY GROUPE");
        cmGroupesContacts = starLoginManager.getListe("SELECT DISTINCT ID,GROUPE FROM groupes" + " ORDER BY GROUPE");
        cboGroupesContacts.setModel(comboModel);
        cboGroupesContacts.setSelectedIndex(-1);
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        if (bolEditing||bolAdding)
        {
            if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
            {
                if (!name.equals(""))
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Client").concat(" ").concat(name),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingContact"),bundle.getString("Client").concat(" ").concat(name),JOptionPane.YES_NO_OPTION);
                }
                else if (!othernames.equals(""))
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Client").concat(" ").concat(othernames),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingContact"),bundle.getString("Client").concat(" ").concat(othernames),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void refreshRecord()
    {
        if (clientID.equals("-1"))
        {
            bolAdding = true;
            setEditMode();
        }
        client = starLoginManager.getRecord(sQuery + " WHERE ID=" + clientID, "clients", "");
        clients = starLoginManager.getRecords(sQuery + " WHERE ID=" + clientID, "clients");
        dbr = starLoginManager.getDBRecord();
        name = client.getData(1);
        othernames = client.getData(2);
        address = client.getData(3);
        city = client.getData(4);
        zipcode = client.getData(5);
        stateprovince = client.getData(6);
        country = client.getData(7);
        age = client.getData(8);
        gender = client.getData(9);
        familystatus = client.getData(10);
        occupations = client.getData(11);
        rank = client.getData(12);
        hobbies = client.getData(13);
        religion = client.getData(14);
        birthdate = client.getData(15);
        birthdate = MainClass.no2defaultDate(birthdate, MainClass.DATE_1950);
        birthtime = client.getData(16);
        birthtime = MainClass.no2defaultTime(birthtime, MainClass.TIME_120000);
        birthplace = client.getData(17);
        phone = client.getData(18);
        telbureau = client.getData(19);
        cell = client.getData(20);
        courriel = client.getData(21);
        compagnie = client.getData(22);
        adressecomp = client.getData(23);
        villecomp = client.getData(24);
        provincecomp = client.getData(25);
        payscomp = client.getData(26);
        zipcomp = client.getData(27);
        telcomp = client.getData(28);
        faxcomp = client.getData(29);
        webcomp = client.getData(30);
        //groupeid = client.getData(31);
        note = client.getData(32);
        picture = client.getPicture();
        if (groupeid == null||groupeid.equals("-1"))
            groupeid = client.getData(31);
    }

    private void addRecord()
    {
        name = txtNom.getText();
        othernames = txtAutresNoms.getText();
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        picture = null;
        bolAdding = true;
        bolEditing = true;
        clientID = "-1";
        refreshRecord();
        setEditMode();
        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void removeRec()
    {
        if (!clientID.equals("-1"))
        {
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                starLoginManager.updateDataBase("DELETE FROM clients WHERE ID=" + clientID);
                if (parentForm instanceof ListeClientForm)
                {
                    ((ListeClientForm)parentForm).setRow();
                }
                addRecord();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        }
        else
            addRecord();
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void setTextToData()
    {
        name = txtNom.getText();
        othernames = txtAutresNoms.getText();
        birthdate = txtDateNaissance.getText();
        address = txtAdresse.getText();
        city = txtVille.getText();
        zipcode = txtCP.getText();
        stateprovince = txtProvince.getText();
        country = txtPays.getText();
        age = txtAge.getText();
        gender = null2String(cboSexe.getSelectedItem());
        familystatus = txtFamilyStatus.getText();
        occupations = txtOccupation.getText();
        rank = txtRank.getText();
        hobbies = txtHobbies.getText();
        religion = txtReligion.getText();
        birthtime = txtBirthTime.getText();
        birthplace = txtBirthPlace.getText();
        phone = txtTelephone.getText();
        telbureau = txtTelBureau.getText();
        cell = txtCell.getText();
        courriel = txtCourriel.getText();
        compagnie = txtCompagnie.getText();
        adressecomp = txtAdresseComp.getText();
        villecomp = txtVilleComp.getText();
        provincecomp = txtProvinceComp.getText();
        payscomp = txtPaysComp.getText();
        zipcomp = txtCPComp.getText();
        telcomp = txtTelComp.getText();
        faxcomp = txtFaxComp.getText();
        webcomp = txtWebComp.getText();
        groupeid = groupeid = null2String(cmGroupesContacts.getElementAt(cboGroupesContacts.getSelectedIndex()));
        note = txtNote.getText();
    }

    private void resetLangue()
    {
        String titre = MainClass.starLoginManager.getStringFieldValue("groupes", "GROUPE", "");
        setTitle(titre);
        btnAddClient.setText(bundle.getString("Add"));
        btnRemoveClient.setText(bundle.getString("Remove"));
        btnOK.setText(bundle.getString("OK"));
        btnCancel.setText(bundle.getString("Cancel"));
        lblNom.setText(bundle.getString("clientsFIRSTNAME"));
        lblAutresNoms.setText(bundle.getString("clientsOTHERNAMES"));
        lblDateNaissance.setText(bundle.getString("clientsBIRTHDATE"));
        lblAdresse.setText(bundle.getString("clientsADDRESS"));
        lblVille.setText(bundle.getString("clientsCITY"));
        lblCP.setText(bundle.getString("clientsZIPCODE"));
        lblProvince.setText(bundle.getString("clientsSTATEPROVINCE"));
        lblPays.setText(bundle.getString("clientsCOUNTRY"));
        lblAge.setText(bundle.getString("clientsAGE"));
        lblSexe.setText(bundle.getString("clientsGENDER"));
        lblFamilyStatus.setText(bundle.getString("clientsFAMILYSTATUS"));
        lblOccupation.setText(bundle.getString("clientsOCCUPATIONS"));
        lblRank.setText(bundle.getString("clientsRANK"));
        lblHobbies.setText(bundle.getString("clientsMAINHOBBIES"));
        lblReligion.setText(bundle.getString("clientsRELIGION"));
        lblDateNaissance.setText(bundle.getString("clientsBIRTHDATE"));
        lblBirthTime.setText(bundle.getString("clientsBIRTHTIME"));
        lblBirthPlace.setText(bundle.getString("clientsBIRTHPLACE"));
        lblTelephone.setText(bundle.getString("clientsPHONE"));
        lblTelBureau.setText(bundle.getString("clientsTELBUREAU"));
        lblCell.setText(bundle.getString("clientsCELL"));
        lblCourriel.setText(bundle.getString("clientsCOURRIEL"));
        lblCompagnie.setText(bundle.getString("clientsCOMPAGNIE"));
        lblAdresseComp.setText(bundle.getString("clientsADRESSECOMP"));
        lblVilleComp.setText(bundle.getString("clientsVILLECOMP"));
        lblProvinceComp.setText(bundle.getString("clientsPROVINCECOMP"));
        lblPaysComp.setText(bundle.getString("clientsPAYSCOMP"));
        lblCPComp.setText(bundle.getString("clientsZIPCOMP"));
        lblTelComp.setText(bundle.getString("clientsTELCOMP"));
        lblFaxComp.setText(bundle.getString("clientsFAXCOMP"));
        lblWebComp.setText(bundle.getString("clientsWEBCOMP"));
        lblNote.setText(bundle.getString("clientsNOTE"));
        lblPhoto.setText(bundle.getString("clientsPICTURE"));
        lblGroupeContacts.setText(bundle.getString("GroupeContacts"));
    }

    private void setDataToText()
    {
        bSetting = true;
        txtNom.setText(name);
        txtAutresNoms.setText(othernames);
        txtDateNaissance.setText(birthdate);
        txtAdresse.setText(address);
        txtVille.setText(city);
        txtCP.setText(zipcode);
        txtProvince.setText(stateprovince);
        txtPays.setText(country);
        txtAge.setText(age);
        cboSexe.setSelectedItem(gender);
        txtFamilyStatus.setText(familystatus);
        txtOccupation.setText(occupations);
        txtRank.setText(rank);
        txtHobbies.setText(hobbies);
        txtReligion.setText(religion);
        if (bolAdding)
        {
            birthdate = MainClass.no2defaultDate(birthdate, MainClass.DATE_1950);
            birthtime = MainClass.no2defaultTime(birthtime, MainClass.TIME_120000);
        }
        txtDateNaissance.setText(birthdate);
        txtBirthTime.setText(birthtime);
        txtBirthPlace.setText(birthplace);
        txtTelephone.setText(phone);
        txtTelBureau.setText(telbureau);
        txtCell.setText(cell);
        txtCourriel.setText(courriel);
        txtCompagnie.setText(compagnie);
        txtAdresseComp.setText(adressecomp);
        txtVilleComp.setText(villecomp);
        txtProvinceComp.setText(provincecomp);
        txtPaysComp.setText(payscomp);
        txtCPComp.setText(zipcomp);
        txtTelComp.setText(telcomp);
        txtFaxComp.setText(faxcomp);
        txtWebComp.setText(webcomp);
        txtNote.setText(note);
        cboGroupesContacts.setSelectedIndex(cmGroupesContacts.getIndexOf(groupeid));
        if (cboGroupesContacts.getSelectedIndex() == -1)
            cboGroupesContacts.setSelectedIndex(0);
        reloadPicture();
        bSetting = false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBoutons = new javax.swing.JPanel();
        btnAddClient = new javax.swing.JButton();
        btnRemoveClient = new javax.swing.JButton();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlData = new javax.swing.JPanel();
        pnlData1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        lblNom = new javax.swing.JLabel();
        txtNom = new javax.swing.JTextField();
        pnlAutresPrenoms = new javax.swing.JPanel();
        lblAutresNoms = new javax.swing.JLabel();
        txtAutresNoms = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        lblPhoto = new javax.swing.JLabel();
        pnlPhoto = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        lblAdresse = new javax.swing.JLabel();
        txtAdresse = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        lblVille = new javax.swing.JLabel();
        txtVille = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        lblProvince = new javax.swing.JLabel();
        txtProvince = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        lblPays = new javax.swing.JLabel();
        txtPays = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        lblCP = new javax.swing.JLabel();
        txtCP = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lblTelephone = new javax.swing.JLabel();
        txtTelephone = new javax.swing.JTextField();
        jPanel17 = new javax.swing.JPanel();
        lblTelBureau = new javax.swing.JLabel();
        txtTelBureau = new javax.swing.JTextField();
        jPanel18 = new javax.swing.JPanel();
        lblCell = new javax.swing.JLabel();
        txtCell = new javax.swing.JTextField();
        jPanel19 = new javax.swing.JPanel();
        lblCourriel = new javax.swing.JLabel();
        txtCourriel = new javax.swing.JTextField();
        pnlData2 = new javax.swing.JPanel();
        pnlCompagnie = new javax.swing.JPanel();
        lblCompagnie = new javax.swing.JLabel();
        txtCompagnie = new javax.swing.JTextField();
        jPanel21 = new javax.swing.JPanel();
        lblAdresseComp = new javax.swing.JLabel();
        txtAdresseComp = new javax.swing.JTextField();
        jPanel22 = new javax.swing.JPanel();
        lblVilleComp = new javax.swing.JLabel();
        txtVilleComp = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        lblProvinceComp = new javax.swing.JLabel();
        txtProvinceComp = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        lblPaysComp = new javax.swing.JLabel();
        txtPaysComp = new javax.swing.JTextField();
        jPanel25 = new javax.swing.JPanel();
        lblCPComp = new javax.swing.JLabel();
        txtCPComp = new javax.swing.JTextField();
        jPanel26 = new javax.swing.JPanel();
        lblTelComp = new javax.swing.JLabel();
        txtTelComp = new javax.swing.JTextField();
        jPanel27 = new javax.swing.JPanel();
        lblFaxComp = new javax.swing.JLabel();
        txtFaxComp = new javax.swing.JTextField();
        jPanel28 = new javax.swing.JPanel();
        lblWebComp = new javax.swing.JLabel();
        txtWebComp = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel11 = new javax.swing.JPanel();
        lblDateNaissance = new javax.swing.JLabel();
        txtDateNaissance = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        lblSexe = new javax.swing.JLabel();
        cboSexe = new javax.swing.JComboBox();
        jPanel5 = new javax.swing.JPanel();
        lblBirthTime = new javax.swing.JLabel();
        txtBirthTime = new javax.swing.JTextField();
        jPanel31 = new javax.swing.JPanel();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        lblBirthPlace = new javax.swing.JLabel();
        txtBirthPlace = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel8 = new javax.swing.JPanel();
        lblFamilyStatus = new javax.swing.JLabel();
        txtFamilyStatus = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        lblOccupation = new javax.swing.JLabel();
        txtOccupation = new javax.swing.JTextField();
        jPanel24 = new javax.swing.JPanel();
        lblRank = new javax.swing.JLabel();
        txtRank = new javax.swing.JTextField();
        jPanel29 = new javax.swing.JPanel();
        lblHobbies = new javax.swing.JLabel();
        txtHobbies = new javax.swing.JTextField();
        jPanel30 = new javax.swing.JPanel();
        lblReligion = new javax.swing.JLabel();
        txtReligion = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        lblNote = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtNote = new javax.swing.JTextArea();
        jPanel10 = new javax.swing.JPanel();
        lblGroupeContacts = new javax.swing.JLabel();
        cboGroupesContacts = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlBoutons.setPreferredSize(new java.awt.Dimension(980, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnAddClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddClient.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddClient.setPreferredSize(new java.awt.Dimension(200, 32));
        btnAddClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddClientActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddClient);

        btnRemoveClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveClient.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemoveClient.setPreferredSize(new java.awt.Dimension(200, 32));
        btnRemoveClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveClientActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveClient);

        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setPreferredSize(new java.awt.Dimension(200, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(200, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        pnlData.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        pnlData1.setPreferredSize(new java.awt.Dimension(480, 530));
        pnlData1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jPanel4.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblNom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNom.setOpaque(true);
        lblNom.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel4.add(lblNom);

        txtNom.setPreferredSize(new java.awt.Dimension(320, 22));
        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNomKeyPressed(evt);
            }
        });
        jPanel4.add(txtNom);

        pnlData1.add(jPanel4);

        pnlAutresPrenoms.setPreferredSize(new java.awt.Dimension(470, 23));
        pnlAutresPrenoms.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblAutresNoms.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAutresNoms.setOpaque(true);
        lblAutresNoms.setPreferredSize(new java.awt.Dimension(150, 22));
        pnlAutresPrenoms.add(lblAutresNoms);

        txtAutresNoms.setPreferredSize(new java.awt.Dimension(320, 22));
        txtAutresNoms.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAutresNomsKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAutresNomsKeyPressed(evt);
            }
        });
        pnlAutresPrenoms.add(txtAutresNoms);

        pnlData1.add(pnlAutresPrenoms);

        jPanel1.setPreferredSize(new java.awt.Dimension(474, 247));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblPhoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPhoto.setOpaque(true);
        lblPhoto.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel1.add(lblPhoto);

        pnlPhoto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlPhoto.setPreferredSize(new java.awt.Dimension(324, 246));
        pnlPhoto.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        jPanel1.add(pnlPhoto);

        pnlData1.add(jPanel1);

        jPanel12.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel12.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblAdresse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAdresse.setOpaque(true);
        lblAdresse.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel12.add(lblAdresse);

        txtAdresse.setPreferredSize(new java.awt.Dimension(320, 22));
        txtAdresse.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAdresseKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAdresseKeyPressed(evt);
            }
        });
        jPanel12.add(txtAdresse);

        pnlData1.add(jPanel12);

        jPanel13.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel13.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblVille.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblVille.setOpaque(true);
        lblVille.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel13.add(lblVille);

        txtVille.setPreferredSize(new java.awt.Dimension(320, 22));
        txtVille.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtVilleKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtVilleKeyPressed(evt);
            }
        });
        jPanel13.add(txtVille);

        pnlData1.add(jPanel13);

        jPanel9.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblProvince.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProvince.setOpaque(true);
        lblProvince.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel9.add(lblProvince);

        txtProvince.setPreferredSize(new java.awt.Dimension(320, 22));
        txtProvince.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProvinceKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtProvinceKeyPressed(evt);
            }
        });
        jPanel9.add(txtProvince);

        pnlData1.add(jPanel9);

        jPanel15.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel15.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblPays.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPays.setOpaque(true);
        lblPays.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel15.add(lblPays);

        txtPays.setPreferredSize(new java.awt.Dimension(320, 22));
        txtPays.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPaysKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPaysKeyPressed(evt);
            }
        });
        jPanel15.add(txtPays);

        pnlData1.add(jPanel15);

        jPanel16.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel16.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblCP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCP.setOpaque(true);
        lblCP.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel16.add(lblCP);

        txtCP.setPreferredSize(new java.awt.Dimension(80, 22));
        txtCP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCPKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCPKeyPressed(evt);
            }
        });
        jPanel16.add(txtCP);

        pnlData1.add(jPanel16);

        jPanel7.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblTelephone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTelephone.setOpaque(true);
        lblTelephone.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel7.add(lblTelephone);

        txtTelephone.setPreferredSize(new java.awt.Dimension(160, 22));
        txtTelephone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelephoneKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTelephoneKeyPressed(evt);
            }
        });
        jPanel7.add(txtTelephone);

        pnlData1.add(jPanel7);

        jPanel17.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel17.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblTelBureau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTelBureau.setOpaque(true);
        lblTelBureau.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel17.add(lblTelBureau);

        txtTelBureau.setPreferredSize(new java.awt.Dimension(160, 22));
        txtTelBureau.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelBureauKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTelBureauKeyPressed(evt);
            }
        });
        jPanel17.add(txtTelBureau);

        pnlData1.add(jPanel17);

        jPanel18.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel18.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblCell.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCell.setOpaque(true);
        lblCell.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel18.add(lblCell);

        txtCell.setPreferredSize(new java.awt.Dimension(160, 22));
        txtCell.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCellKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCellKeyPressed(evt);
            }
        });
        jPanel18.add(txtCell);

        pnlData1.add(jPanel18);

        jPanel19.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel19.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblCourriel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCourriel.setOpaque(true);
        lblCourriel.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel19.add(lblCourriel);

        txtCourriel.setPreferredSize(new java.awt.Dimension(320, 22));
        txtCourriel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCourrielKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCourrielKeyPressed(evt);
            }
        });
        jPanel19.add(txtCourriel);

        pnlData1.add(jPanel19);

        pnlData.add(pnlData1);

        pnlData2.setPreferredSize(new java.awt.Dimension(480, 530));
        pnlData2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        pnlCompagnie.setPreferredSize(new java.awt.Dimension(470, 23));
        pnlCompagnie.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblCompagnie.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCompagnie.setOpaque(true);
        lblCompagnie.setPreferredSize(new java.awt.Dimension(150, 22));
        pnlCompagnie.add(lblCompagnie);

        txtCompagnie.setPreferredSize(new java.awt.Dimension(320, 22));
        txtCompagnie.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCompagnieKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCompagnieKeyPressed(evt);
            }
        });
        pnlCompagnie.add(txtCompagnie);

        pnlData2.add(pnlCompagnie);

        jPanel21.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel21.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblAdresseComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAdresseComp.setOpaque(true);
        lblAdresseComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel21.add(lblAdresseComp);

        txtAdresseComp.setPreferredSize(new java.awt.Dimension(320, 22));
        txtAdresseComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAdresseCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAdresseCompKeyPressed(evt);
            }
        });
        jPanel21.add(txtAdresseComp);

        pnlData2.add(jPanel21);

        jPanel22.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel22.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblVilleComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblVilleComp.setOpaque(true);
        lblVilleComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel22.add(lblVilleComp);

        txtVilleComp.setPreferredSize(new java.awt.Dimension(320, 22));
        txtVilleComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtVilleCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtVilleCompKeyPressed(evt);
            }
        });
        jPanel22.add(txtVilleComp);

        pnlData2.add(jPanel22);

        jPanel23.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel23.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblProvinceComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProvinceComp.setOpaque(true);
        lblProvinceComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel23.add(lblProvinceComp);

        txtProvinceComp.setPreferredSize(new java.awt.Dimension(320, 22));
        txtProvinceComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProvinceCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtProvinceCompKeyPressed(evt);
            }
        });
        jPanel23.add(txtProvinceComp);

        pnlData2.add(jPanel23);

        jPanel20.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel20.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblPaysComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPaysComp.setOpaque(true);
        lblPaysComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel20.add(lblPaysComp);

        txtPaysComp.setPreferredSize(new java.awt.Dimension(320, 22));
        txtPaysComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPaysCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPaysCompKeyPressed(evt);
            }
        });
        jPanel20.add(txtPaysComp);

        pnlData2.add(jPanel20);

        jPanel25.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel25.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblCPComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCPComp.setOpaque(true);
        lblCPComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel25.add(lblCPComp);

        txtCPComp.setPreferredSize(new java.awt.Dimension(80, 22));
        txtCPComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCPCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCPCompKeyPressed(evt);
            }
        });
        jPanel25.add(txtCPComp);

        pnlData2.add(jPanel25);

        jPanel26.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel26.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblTelComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTelComp.setOpaque(true);
        lblTelComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel26.add(lblTelComp);

        txtTelComp.setPreferredSize(new java.awt.Dimension(160, 22));
        txtTelComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTelCompKeyPressed(evt);
            }
        });
        jPanel26.add(txtTelComp);

        pnlData2.add(jPanel26);

        jPanel27.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel27.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblFaxComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFaxComp.setOpaque(true);
        lblFaxComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel27.add(lblFaxComp);

        txtFaxComp.setPreferredSize(new java.awt.Dimension(160, 22));
        txtFaxComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFaxCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtFaxCompKeyPressed(evt);
            }
        });
        jPanel27.add(txtFaxComp);

        pnlData2.add(jPanel27);

        jPanel28.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel28.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblWebComp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWebComp.setOpaque(true);
        lblWebComp.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel28.add(lblWebComp);

        txtWebComp.setPreferredSize(new java.awt.Dimension(320, 22));
        txtWebComp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtWebCompKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtWebCompKeyPressed(evt);
            }
        });
        jPanel28.add(txtWebComp);

        pnlData2.add(jPanel28);

        jSeparator1.setPreferredSize(new java.awt.Dimension(470, 2));
        pnlData2.add(jSeparator1);

        jPanel11.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel11.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateNaissance.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateNaissance.setOpaque(true);
        lblDateNaissance.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel11.add(lblDateNaissance);

        txtDateNaissance.setPreferredSize(new java.awt.Dimension(100, 22));
        txtDateNaissance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDateNaissanceMouseClicked(evt);
            }
        });
        txtDateNaissance.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDateNaissanceFocusLost(evt);
            }
        });
        txtDateNaissance.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateNaissanceKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateNaissanceKeyTyped(evt);
            }
        });
        jPanel11.add(txtDateNaissance);

        jPanel2.setPreferredSize(new java.awt.Dimension(40, 10));
        jPanel11.add(jPanel2);

        lblSexe.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSexe.setOpaque(true);
        lblSexe.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel11.add(lblSexe);

        cboSexe.setPreferredSize(new java.awt.Dimension(70, 22));
        cboSexe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboSexeActionPerformed(evt);
            }
        });
        jPanel11.add(cboSexe);

        pnlData2.add(jPanel11);

        jPanel5.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblBirthTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBirthTime.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblBirthTime.setMaximumSize(new java.awt.Dimension(185, 19));
        lblBirthTime.setMinimumSize(new java.awt.Dimension(185, 19));
        lblBirthTime.setOpaque(true);
        lblBirthTime.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel5.add(lblBirthTime);

        txtBirthTime.setPreferredSize(new java.awt.Dimension(100, 22));
        txtBirthTime.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBirthTimeFocusLost(evt);
            }
        });
        txtBirthTime.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBirthTimeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBirthTimeKeyTyped(evt);
            }
        });
        jPanel5.add(txtBirthTime);

        jPanel31.setPreferredSize(new java.awt.Dimension(40, 10));
        jPanel5.add(jPanel31);

        lblAge.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAge.setOpaque(true);
        lblAge.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel5.add(lblAge);

        txtAge.setPreferredSize(new java.awt.Dimension(70, 22));
        txtAge.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAgeKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAgeKeyPressed(evt);
            }
        });
        jPanel5.add(txtAge);

        pnlData2.add(jPanel5);

        jPanel6.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblBirthPlace.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBirthPlace.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblBirthPlace.setMaximumSize(new java.awt.Dimension(185, 19));
        lblBirthPlace.setMinimumSize(new java.awt.Dimension(185, 19));
        lblBirthPlace.setOpaque(true);
        lblBirthPlace.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel6.add(lblBirthPlace);

        txtBirthPlace.setPreferredSize(new java.awt.Dimension(320, 22));
        txtBirthPlace.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBirthPlaceKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBirthPlaceKeyPressed(evt);
            }
        });
        jPanel6.add(txtBirthPlace);

        pnlData2.add(jPanel6);

        jSeparator2.setPreferredSize(new java.awt.Dimension(470, 2));
        pnlData2.add(jSeparator2);

        jPanel8.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblFamilyStatus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFamilyStatus.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFamilyStatus.setMaximumSize(new java.awt.Dimension(185, 19));
        lblFamilyStatus.setMinimumSize(new java.awt.Dimension(185, 19));
        lblFamilyStatus.setOpaque(true);
        lblFamilyStatus.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel8.add(lblFamilyStatus);

        txtFamilyStatus.setPreferredSize(new java.awt.Dimension(320, 22));
        txtFamilyStatus.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFamilyStatusKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtFamilyStatusKeyPressed(evt);
            }
        });
        jPanel8.add(txtFamilyStatus);

        pnlData2.add(jPanel8);

        jPanel14.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel14.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblOccupation.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOccupation.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblOccupation.setMaximumSize(new java.awt.Dimension(185, 19));
        lblOccupation.setMinimumSize(new java.awt.Dimension(185, 19));
        lblOccupation.setOpaque(true);
        lblOccupation.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel14.add(lblOccupation);

        txtOccupation.setPreferredSize(new java.awt.Dimension(320, 22));
        txtOccupation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOccupationKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOccupationKeyPressed(evt);
            }
        });
        jPanel14.add(txtOccupation);

        pnlData2.add(jPanel14);

        jPanel24.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel24.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblRank.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRank.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblRank.setMaximumSize(new java.awt.Dimension(185, 19));
        lblRank.setMinimumSize(new java.awt.Dimension(185, 19));
        lblRank.setOpaque(true);
        lblRank.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel24.add(lblRank);

        txtRank.setPreferredSize(new java.awt.Dimension(320, 22));
        txtRank.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRankKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtRankKeyPressed(evt);
            }
        });
        jPanel24.add(txtRank);

        pnlData2.add(jPanel24);

        jPanel29.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel29.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblHobbies.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHobbies.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblHobbies.setMaximumSize(new java.awt.Dimension(185, 19));
        lblHobbies.setMinimumSize(new java.awt.Dimension(185, 19));
        lblHobbies.setOpaque(true);
        lblHobbies.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel29.add(lblHobbies);

        txtHobbies.setPreferredSize(new java.awt.Dimension(320, 22));
        txtHobbies.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHobbiesKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHobbiesKeyPressed(evt);
            }
        });
        jPanel29.add(txtHobbies);

        pnlData2.add(jPanel29);

        jPanel30.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel30.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblReligion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblReligion.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblReligion.setMaximumSize(new java.awt.Dimension(185, 19));
        lblReligion.setMinimumSize(new java.awt.Dimension(185, 19));
        lblReligion.setOpaque(true);
        lblReligion.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel30.add(lblReligion);

        txtReligion.setPreferredSize(new java.awt.Dimension(320, 22));
        txtReligion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtReligionKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtReligionKeyPressed(evt);
            }
        });
        jPanel30.add(txtReligion);

        pnlData2.add(jPanel30);

        jSeparator3.setPreferredSize(new java.awt.Dimension(470, 2));
        pnlData2.add(jSeparator3);

        jPanel3.setPreferredSize(new java.awt.Dimension(470, 101));
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblNote.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNote.setOpaque(true);
        lblNote.setPreferredSize(new java.awt.Dimension(50, 22));
        jPanel3.add(lblNote);

        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(420, 100));

        txtNote.setColumns(20);
        txtNote.setLineWrap(true);
        txtNote.setWrapStyleWord(true);
        txtNote.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txtNote.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNoteKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNoteKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(txtNote);

        jPanel3.add(jScrollPane1);

        pnlData2.add(jPanel3);

        jPanel10.setPreferredSize(new java.awt.Dimension(470, 26));
        jPanel10.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 2));

        lblGroupeContacts.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGroupeContacts.setOpaque(true);
        lblGroupeContacts.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel10.add(lblGroupeContacts);

        cboGroupesContacts.setKeySelectionManager(new MultiKeySelectionManager());
        cboGroupesContacts.setPreferredSize(new java.awt.Dimension(320, 22));
        cboGroupesContacts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboGroupesContactsActionPerformed(evt);
            }
        });
        jPanel10.add(cboGroupesContacts);

        pnlData2.add(jPanel10);

        pnlData.add(pnlData2);

        getContentPane().add(pnlData, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddClientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddClientActionPerformed
    {//GEN-HEADEREND:event_btnAddClientActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddClientActionPerformed

    private void btnRemoveClientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveClientActionPerformed
    {//GEN-HEADEREND:event_btnRemoveClientActionPerformed
        removeRec();
    }//GEN-LAST:event_btnRemoveClientActionPerformed

    private void txtNomKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNomKeyPressed
    {//GEN-HEADEREND:event_txtNomKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtNom.setText(name);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtNomKeyPressed

    private void txtAutresNomsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAutresNomsKeyPressed
    {//GEN-HEADEREND:event_txtAutresNomsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAutresNoms.setText(othernames);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAutresNomsKeyPressed

    private void txtDateNaissanceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateNaissanceKeyPressed
    {//GEN-HEADEREND:event_txtDateNaissanceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateNaissance.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateNaissance.setText(birthdate);
        }
        else
        {
            KTDate t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTDate(evt, txtDateNaissance, kc);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateNaissanceKeyPressed

    private void cboSexeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboSexeActionPerformed
    {//GEN-HEADEREND:event_cboSexeActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboSexeActionPerformed

    private void txtAdresseKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAdresseKeyPressed
    {//GEN-HEADEREND:event_txtAdresseKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAdresse.setText(address);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAdresseKeyPressed

    private void txtVilleKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVilleKeyPressed
    {//GEN-HEADEREND:event_txtVilleKeyPressed
        if (bSetting)
        {
            return;
        }
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtVille.setText(city);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtVilleKeyPressed

    private void txtPaysKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPaysKeyPressed
    {//GEN-HEADEREND:event_txtPaysKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPays.setText(country);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtPaysKeyPressed

    private void txtCPKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCPKeyPressed
    {//GEN-HEADEREND:event_txtCPKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCP.setText(zipcode);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtCPKeyPressed

    private void txtTelephoneKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelephoneKeyPressed
    {//GEN-HEADEREND:event_txtTelephoneKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtTelephone.setText(phone);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtTelephoneKeyPressed

    private void txtTelBureauKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelBureauKeyPressed
    {//GEN-HEADEREND:event_txtTelBureauKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtTelBureau.setText(telbureau);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtTelBureauKeyPressed

    private void txtCellKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCellKeyPressed
    {//GEN-HEADEREND:event_txtCellKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCell.setText(cell);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtCellKeyPressed

    private void txtCourrielKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCourrielKeyPressed
    {//GEN-HEADEREND:event_txtCourrielKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCourriel.setText(courriel);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtCourrielKeyPressed

    private void txtCompagnieKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCompagnieKeyPressed
    {//GEN-HEADEREND:event_txtCompagnieKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCompagnie.setText(compagnie);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtCompagnieKeyPressed

    private void txtAdresseCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAdresseCompKeyPressed
    {//GEN-HEADEREND:event_txtAdresseCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAdresseComp.setText(adressecomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAdresseCompKeyPressed

    private void txtVilleCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVilleCompKeyPressed
    {//GEN-HEADEREND:event_txtVilleCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtVilleComp.setText(villecomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtVilleCompKeyPressed

    private void txtCPCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCPCompKeyPressed
    {//GEN-HEADEREND:event_txtCPCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCPComp.setText(zipcomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtCPCompKeyPressed

    private void txtTelCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelCompKeyPressed
    {//GEN-HEADEREND:event_txtTelCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtTelComp.setText(telcomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtTelCompKeyPressed

    private void txtFaxCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtFaxCompKeyPressed
    {//GEN-HEADEREND:event_txtFaxCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtFaxComp.setText(faxcomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtFaxCompKeyPressed

    private void txtWebCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtWebCompKeyPressed
    {//GEN-HEADEREND:event_txtWebCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtWebComp.setText(webcomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtWebCompKeyPressed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        name = txtNom.getText();
        othernames = txtAutresNoms.getText();
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
        {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        updateInstances();
    }//GEN-LAST:event_formWindowClosing

    private void cboGroupesContactsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboGroupesContactsActionPerformed
    {//GEN-HEADEREND:event_cboGroupesContactsActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboGroupesContactsActionPerformed

    private void txtDateNaissanceMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateNaissanceMouseClicked
    {//GEN-HEADEREND:event_txtDateNaissanceMouseClicked
        if (evt.getButton() == 1)
        {
            String sdate = txtDateNaissance.getText();
            birthdate = DlgCalendar.ShowCalendar(sdate);
            birthdate = MainClass.getFormatedDate(birthdate);
            txtDateNaissance.setText(birthdate);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateNaissanceMouseClicked

    private void txtDateNaissanceKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateNaissanceKeyTyped
    {//GEN-HEADEREND:event_txtDateNaissanceKeyTyped
        KTDate d = new KTDate(evt, txtDateNaissance, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateNaissance.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateNaissanceKeyTyped

    private void txtCPKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCPKeyTyped
    {//GEN-HEADEREND:event_txtCPKeyTyped
        MainClass.ToUpper(evt);
        int size = new Integer(String.valueOf(clients.getSizes().get(5))).intValue();
        if (txtCP.getText().length() >= size)
        {
            txtCP.setText(txtCP.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCPKeyTyped

    private void txtCPCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCPCompKeyTyped
    {//GEN-HEADEREND:event_txtCPCompKeyTyped
        MainClass.ToUpper(evt);
        int size = new Integer(String.valueOf(clients.getSizes().get(27))).intValue();
        if (txtCPComp.getText().length() >= size)
        {
            txtCPComp.setText(txtCPComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCPCompKeyTyped

    private void txtAdresseKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAdresseKeyTyped
    {//GEN-HEADEREND:event_txtAdresseKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(3))).intValue();
        if (txtAdresse.getText().length() >= size)
        {
            txtAdresse.setText(txtAdresse.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAdresseKeyTyped

    private void txtVilleKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVilleKeyTyped
    {//GEN-HEADEREND:event_txtVilleKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(4))).intValue();
        if (txtVille.getText().length() >= size)
        {
            txtVille.setText(txtVille.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtVilleKeyTyped

    private void txtPaysKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPaysKeyTyped
    {//GEN-HEADEREND:event_txtPaysKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(7))).intValue();
        if (txtPays.getText().length() >= size)
        {
            txtPays.setText(txtPays.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtPaysKeyTyped

    private void txtCompagnieKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCompagnieKeyTyped
    {//GEN-HEADEREND:event_txtCompagnieKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(22))).intValue();
        if (txtCompagnie.getText().length() >= size)
        {
            txtCompagnie.setText(txtCompagnie.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCompagnieKeyTyped

    private void txtAdresseCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAdresseCompKeyTyped
    {//GEN-HEADEREND:event_txtAdresseCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(23))).intValue();
        if (txtAdresse.getText().length() >= size)
        {
            txtAdresse.setText(txtAdresse.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAdresseCompKeyTyped

    private void txtVilleCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVilleCompKeyTyped
    {//GEN-HEADEREND:event_txtVilleCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(24))).intValue();
        if (txtVilleComp.getText().length() >= size)
        {
            txtVilleComp.setText(txtVilleComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtVilleCompKeyTyped

    private void txtWebCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtWebCompKeyTyped
    {//GEN-HEADEREND:event_txtWebCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(30))).intValue();
        if (txtWebComp.getText().length() >= size)
        {
            txtWebComp.setText(txtWebComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtWebCompKeyTyped

    private void txtNoteKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNoteKeyTyped
    {//GEN-HEADEREND:event_txtNoteKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(32))).intValue();
        if (txtNote.getText().length() >= size)
        {
            txtNote.setText(txtNote.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtNoteKeyTyped

    private void txtNoteKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNoteKeyPressed
    {//GEN-HEADEREND:event_txtNoteKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtNote.setText(note);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtNoteKeyPressed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        if (parentForm instanceof OrganizerForm)
            ((OrganizerForm)parentForm).setCancel(true);
        updateInstances();
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKActionPerformed

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNomKeyTyped
    {//GEN-HEADEREND:event_txtNomKeyTyped
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            if (txtNom.getCaretPosition() > 0)
                return;
            char ch = evt.getKeyChar();
            String s = String.valueOf(ch);
            s = s.toUpperCase();
            char[] charray = s.toCharArray();
            ch = charray[0];
            evt.setKeyChar(ch);
        }
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtProvinceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtProvinceKeyPressed
    {//GEN-HEADEREND:event_txtProvinceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtProvince.setText(stateprovince);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtProvinceKeyPressed

    private void txtProvinceKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtProvinceKeyTyped
    {//GEN-HEADEREND:event_txtProvinceKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(6))).intValue();
        if (txtProvince.getText().length() >= size)
        {
            txtProvince.setText(txtProvince.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtProvinceKeyTyped

    private void txtPaysCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPaysCompKeyTyped
    {//GEN-HEADEREND:event_txtPaysCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(26))).intValue();
        if (txtPaysComp.getText().length() >= size)
        {
            txtPaysComp.setText(txtPaysComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtPaysCompKeyTyped

    private void txtPaysCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPaysCompKeyPressed
    {//GEN-HEADEREND:event_txtPaysCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPaysComp.setText(payscomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtPaysCompKeyPressed

    private void txtBirthTimeKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBirthTimeKeyTyped
    {//GEN-HEADEREND:event_txtBirthTimeKeyTyped
        KTTime ti = new KTTime(evt, txtBirthTime, kc);
        int pos = txtBirthTime.getCaretPosition();
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtBirthTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtBirthTimeKeyTyped

    private void txtBirthPlaceKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBirthPlaceKeyTyped
    {//GEN-HEADEREND:event_txtBirthPlaceKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(17))).intValue();
        if (txtBirthPlace.getText().length() >= size)
        {
            txtBirthPlace.setText(txtBirthPlace.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtBirthPlaceKeyTyped

    private void txtFamilyStatusKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtFamilyStatusKeyTyped
    {//GEN-HEADEREND:event_txtFamilyStatusKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(10))).intValue();
        if (txtFamilyStatus.getText().length() >= size)
        {
            txtFamilyStatus.setText(txtFamilyStatus.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtFamilyStatusKeyTyped

    private void txtOccupationKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOccupationKeyTyped
    {//GEN-HEADEREND:event_txtOccupationKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(11))).intValue();
        if (txtOccupation.getText().length() >= size)
        {
            txtOccupation.setText(txtOccupation.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtOccupationKeyTyped

    private void txtRankKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRankKeyTyped
    {//GEN-HEADEREND:event_txtRankKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(12))).intValue();
        if (txtRank.getText().length() >= size)
        {
            txtRank.setText(txtRank.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtRankKeyTyped

    private void txtHobbiesKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHobbiesKeyTyped
    {//GEN-HEADEREND:event_txtHobbiesKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(13))).intValue();
        if (txtHobbies.getText().length() >= size)
        {
            txtHobbies.setText(txtHobbies.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtHobbiesKeyTyped

    private void txtReligionKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtReligionKeyTyped
    {//GEN-HEADEREND:event_txtReligionKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(14))).intValue();
        if (txtReligion.getText().length() >= size)
        {
            txtReligion.setText(txtReligion.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtReligionKeyTyped

    private void txtProvinceCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtProvinceCompKeyTyped
    {//GEN-HEADEREND:event_txtProvinceCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(25))).intValue();
        if (txtProvinceComp.getText().length() >= size)
        {
            txtProvinceComp.setText(txtProvinceComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtProvinceCompKeyTyped

    private void txtProvinceCompKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtProvinceCompKeyPressed
    {//GEN-HEADEREND:event_txtProvinceCompKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtProvinceComp.setText(provincecomp);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtProvinceCompKeyPressed

    private void txtAgeKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAgeKeyTyped
    {//GEN-HEADEREND:event_txtAgeKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(8))).intValue();
        if (txtAge.getText().length() >= size)
        {
            txtAge.setText(txtAge.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAgeKeyTyped

    private void txtAutresNomsKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAutresNomsKeyTyped
    {//GEN-HEADEREND:event_txtAutresNomsKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(2))).intValue();
        if (txtAutresNoms.getText().length() >= size)
        {
            txtAutresNoms.setText(txtAutresNoms.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAutresNomsKeyTyped

    private void txtTelephoneKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelephoneKeyTyped
    {//GEN-HEADEREND:event_txtTelephoneKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(18))).intValue();
        if (txtTelephone.getText().length() >= size)
        {
            txtTelephone.setText(txtTelephone.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtTelephoneKeyTyped

    private void txtTelBureauKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelBureauKeyTyped
    {//GEN-HEADEREND:event_txtTelBureauKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(19))).intValue();
        if (txtTelBureau.getText().length() >= size)
        {
            txtTelBureau.setText(txtTelBureau.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtTelBureauKeyTyped

    private void txtCellKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCellKeyTyped
    {//GEN-HEADEREND:event_txtCellKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(20))).intValue();
        if (txtCell.getText().length() >= size)
        {
            txtCell.setText(txtCell.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCellKeyTyped

    private void txtCourrielKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCourrielKeyTyped
    {//GEN-HEADEREND:event_txtCourrielKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(21))).intValue();
        if (txtCourriel.getText().length() >= size)
        {
            txtCourriel.setText(txtCourriel.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCourrielKeyTyped

    private void txtTelCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelCompKeyTyped
    {//GEN-HEADEREND:event_txtTelCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(28))).intValue();
        if (txtTelComp.getText().length() >= size)
        {
            txtTelComp.setText(txtTelComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtTelCompKeyTyped

    private void txtFaxCompKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtFaxCompKeyTyped
    {//GEN-HEADEREND:event_txtFaxCompKeyTyped
        int size = new Integer(String.valueOf(clients.getSizes().get(29))).intValue();
        if (txtFaxComp.getText().length() >= size)
        {
            txtFaxComp.setText(txtFaxComp.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtFaxCompKeyTyped

    private void txtBirthTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBirthTimeKeyPressed
    {//GEN-HEADEREND:event_txtBirthTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtBirthTime.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtBirthTime.setText(birthtime);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtBirthTime, kc);
            setEditMode();
        }
    }//GEN-LAST:event_txtBirthTimeKeyPressed

    private void txtAgeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAgeKeyPressed
    {//GEN-HEADEREND:event_txtAgeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAge.setText(age);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAgeKeyPressed

    private void txtBirthPlaceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBirthPlaceKeyPressed
    {//GEN-HEADEREND:event_txtBirthPlaceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtBirthPlace.setText(birthplace);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtBirthPlaceKeyPressed

    private void txtFamilyStatusKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtFamilyStatusKeyPressed
    {//GEN-HEADEREND:event_txtFamilyStatusKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtFamilyStatus.setText(familystatus);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtFamilyStatusKeyPressed

    private void txtOccupationKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOccupationKeyPressed
    {//GEN-HEADEREND:event_txtOccupationKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtOccupation.setText(occupations);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtOccupationKeyPressed

    private void txtRankKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRankKeyPressed
    {//GEN-HEADEREND:event_txtRankKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtRank.setText(rank);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtRankKeyPressed

    private void txtHobbiesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHobbiesKeyPressed
    {//GEN-HEADEREND:event_txtHobbiesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHobbies.setText(hobbies);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtHobbiesKeyPressed

    private void txtReligionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtReligionKeyPressed
    {//GEN-HEADEREND:event_txtReligionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtReligion.setText(religion);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtReligionKeyPressed

    private void txtDateNaissanceFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateNaissanceFocusLost
    {//GEN-HEADEREND:event_txtDateNaissanceFocusLost
        birthdate = txtDateNaissance.getText();
        if (!birthdate.equals(""))
        {
            String curdate = FDate.curFrFormDate();
            String sdays = MainClass.diffDates(curdate, birthdate);
            if (sdays.equals(""))
                sdays = "0";
            long ldays = Long.valueOf(sdays).longValue();
            double da = ((double)ldays)/365.25;
            if (da < 0)
                da *= -1;
            da = AstronomyMaths.getRnd(da, 0);
            age = String.valueOf((int)da);
            txtAge.setText(age);
        }
    }//GEN-LAST:event_txtDateNaissanceFocusLost

    private void txtBirthTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtBirthTimeFocusLost
    {//GEN-HEADEREND:event_txtBirthTimeFocusLost
        FTime t = new FTime(txtBirthTime.getText());
        String sText = t.getTime();
        txtBirthTime.setText(sText);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtBirthTimeFocusLost

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddClient;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnRemoveClient;
    private javax.swing.JComboBox cboGroupesContacts;
    private javax.swing.JComboBox cboSexe;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lblAdresse;
    private javax.swing.JLabel lblAdresseComp;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblAutresNoms;
    private javax.swing.JLabel lblBirthPlace;
    private javax.swing.JLabel lblBirthTime;
    private javax.swing.JLabel lblCP;
    private javax.swing.JLabel lblCPComp;
    private javax.swing.JLabel lblCell;
    private javax.swing.JLabel lblCompagnie;
    private javax.swing.JLabel lblCourriel;
    private javax.swing.JLabel lblDateNaissance;
    private javax.swing.JLabel lblFamilyStatus;
    private javax.swing.JLabel lblFaxComp;
    private javax.swing.JLabel lblGroupeContacts;
    private javax.swing.JLabel lblHobbies;
    private javax.swing.JLabel lblNom;
    private javax.swing.JLabel lblNote;
    private javax.swing.JLabel lblOccupation;
    private javax.swing.JLabel lblPays;
    private javax.swing.JLabel lblPaysComp;
    private javax.swing.JLabel lblPhoto;
    private javax.swing.JLabel lblProvince;
    private javax.swing.JLabel lblProvinceComp;
    private javax.swing.JLabel lblRank;
    private javax.swing.JLabel lblReligion;
    private javax.swing.JLabel lblSexe;
    private javax.swing.JLabel lblTelBureau;
    private javax.swing.JLabel lblTelComp;
    private javax.swing.JLabel lblTelephone;
    private javax.swing.JLabel lblVille;
    private javax.swing.JLabel lblVilleComp;
    private javax.swing.JLabel lblWebComp;
    private javax.swing.JPanel pnlAutresPrenoms;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlCompagnie;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlData1;
    private javax.swing.JPanel pnlData2;
    private javax.swing.JPanel pnlPhoto;
    private javax.swing.JTextField txtAdresse;
    private javax.swing.JTextField txtAdresseComp;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtAutresNoms;
    private javax.swing.JTextField txtBirthPlace;
    private javax.swing.JTextField txtBirthTime;
    private javax.swing.JTextField txtCP;
    private javax.swing.JTextField txtCPComp;
    private javax.swing.JTextField txtCell;
    private javax.swing.JTextField txtCompagnie;
    private javax.swing.JTextField txtCourriel;
    private javax.swing.JTextField txtDateNaissance;
    private javax.swing.JTextField txtFamilyStatus;
    private javax.swing.JTextField txtFaxComp;
    private javax.swing.JTextField txtHobbies;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextArea txtNote;
    private javax.swing.JTextField txtOccupation;
    private javax.swing.JTextField txtPays;
    private javax.swing.JTextField txtPaysComp;
    private javax.swing.JTextField txtProvince;
    private javax.swing.JTextField txtProvinceComp;
    private javax.swing.JTextField txtRank;
    private javax.swing.JTextField txtReligion;
    private javax.swing.JTextField txtTelBureau;
    private javax.swing.JTextField txtTelComp;
    private javax.swing.JTextField txtTelephone;
    private javax.swing.JTextField txtVille;
    private javax.swing.JTextField txtVilleComp;
    private javax.swing.JTextField txtWebComp;
    // End of variables declaration//GEN-END:variables
}
