/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;


import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Service;
import StarLogin.Systeme.Data.Services;
import java.awt.Cursor;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.KeyEvent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;
/**
 *
 * @author Francois
 */
public class DialogServices extends JDialog
{
    private int kc; //key code
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Services services;
    private int saveRow;
    private Service service;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private String serviceID;
    private String serviceName;
    private String serviceAstrologicalTechniques;
    private String serviceAverageDuration;
    private String serviceComments;
    private String serviceOtherTechniques;
    private String serviceRate;
    private String serviceRepetitiveness;
    private String serviceServiceType;
    private int serviceRow;
    private int nbOfRows;
    private boolean bolSetting = true;
    private boolean bolDeleting = false;
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private Window parentForm;
    

    /**
     * Creates new form DialogClient
     */
    public DialogServices(java.awt.Frame parent, boolean modal, String serviceid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        serviceID = serviceid;
        setDlg();
    }
    
    public DialogServices(java.awt.Dialog parent, boolean modal, String serviceid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        serviceID = serviceid;
        setDlg();
    }
    
    private void setDlg()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        
        resetLangue();

        initData();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        this.setVisible(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bolSetting = false;
    }
    
    
    private void resetLangue()
    {
        setTitle(bundle.getString("Services"));
        btnFirstService.setToolTipText(bundle.getString("FirstRecord"));
        btnPreviousService.setToolTipText(bundle.getString("PreviousRecord"));
        btnNextService.setToolTipText(bundle.getString("NextRecord"));
        btnLastService.setToolTipText(bundle.getString("LastRecord"));
        btnRemoveService.setToolTipText(bundle.getString("RemoveRecord"));
        btnAddService.setToolTipText(bundle.getString("AddRecord"));
        btnOKService.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS"));
        btnCancelService.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS"));
        jLabel113.setText(bundle.getString("ServiceName"));
        jLabel124.setText(bundle.getString("ServiceType"));
        jLabel109.setText(bundle.getString("AstrologicalTechniques"));
        jLabel110.setText(bundle.getString("OtherTechniques"));
        jLabel120.setText(bundle.getString("AverageDuration"));
        jLabel111.setText(bundle.getString("Rate"));
        jLabel112.setText(bundle.getString("Repetitiveness"));
        lblNote.setText(bundle.getString("Note"));
    }
    

    private void initData()
    {
        initServiceData(serviceID);
    }

    public void showRecord(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        serviceID = services.getIDFromRow(row);
        if (serviceID.equals("-1"))
        {
            initServiceData("-1");
            return;
        }
        showRecord(serviceID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void showRecord(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        serviceID = strID;
        service = starLoginManager.getService(serviceID);
        serviceRow = service.getRow();
        nbOfRows = service.getRowNB();
        if (strID.equals("-1"))
            txtCounterService.setText(bundle.getString("NewService"));
        else
        {
            saveRow = serviceRow;
            txtCounterService.setText(String.valueOf(serviceRow) + " / " + String.valueOf(nbOfRows));
        }
        
            //nbOfRows += 1;
        serviceName = service.getServiceName();
        serviceAstrologicalTechniques = service.getAstrologicalTechniques();
        serviceAverageDuration = service.getAverageDuration();
        serviceComments = service.getComments();
        serviceOtherTechniques = service.getOtherTechniques();
        serviceRate = service.getRate();
        serviceRepetitiveness = service.getRepetitiveness();
        serviceServiceType = service.getServiceType();

        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void initServiceData(String strID)
    {
        services = starLoginManager.getServices();
        if (services == null||services.getRecords().isEmpty())
            strID = "-1";
        if (strID.equals("-1"))
        {
            addRecord();
        }
        else
        {
            showRecord(strID);
        }
    }

    private void refreshRecord()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            services = starLoginManager.getServices();

            //show the service data
            showRecord(saveRow);
        }
    }

    private void addRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveRow = serviceRow;
        showRecord("-1");
        serviceRow += 1;
        bolEditing = false;
        bolAdding = true;
        setEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        serviceName = txtServiceName.getText();
        if (bolEditing)
        {
            if (!serviceName.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Service").concat(" ").concat(serviceName),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingService"),bundle.getString("Service").concat(" ").concat(serviceName),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }

    private void removeServiceRec()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            if (nbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, " tes-vous s�r de vouloir supprimer l'enregistrement en cours?", "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeService(service);
                    services = starLoginManager.getServices();

                    if (serviceRow > 1)
                    {
                        showRecord(serviceRow - 1);
                    }
                    else
                    {
                        showRecord(serviceRow + 1);
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setTextToData();
            service.setAdding(bolAdding);
            service.setServiceName(serviceName);
            service.setAstrologicalTechniques(serviceAstrologicalTechniques);
            service.setAverageDuration(serviceAverageDuration);
            service.setComments(serviceComments);
            service.setOtherTechniques(serviceOtherTechniques);
            service.setRate(serviceRate);
            service.setRepetitiveness(serviceRepetitiveness);
            service.setServiceType(serviceServiceType);
            starLoginManager.setService(service);
            if (bolAdding == true)
            {
                saveRow = service.getRow();
            }
            if (parentForm instanceof DialogConsultations)
                ((DialogConsultations)parentForm).setService(serviceName);
            bolEditing = false;
            bolAdding = false;
            bolDeleting = false;
            refreshRecord();
            setNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    

    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }

    private void setDataToText()
    {
        bolSetting = true;
        txtServiceName.setText(serviceName);
        txtAstrologicalTechniques.setText(serviceAstrologicalTechniques);
        txtAverageDuration.setText(serviceAverageDuration);
        txtServiceComments.setText(serviceComments);
        txtOtherTechniques.setText(serviceOtherTechniques);
        txtRate.setText(serviceRate);
        txtRepetitiveness.setText(serviceRepetitiveness);
        txtServiceType.setText(serviceServiceType);
        int carretPos = txtCounterService.getCaretPosition();
        int len = txtCounterService.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounterService.setCaretPosition(carretPos);
        bolSetting = false;
        bolAdding = false;
        bolEditing = false;
        bolDeleting = false;
    }

    private void setTextToData()
    {
        serviceName = txtServiceName.getText();
        serviceAstrologicalTechniques = txtAstrologicalTechniques.getText();
        serviceAverageDuration = txtAverageDuration.getText();
        serviceComments = txtServiceComments.getText();
        serviceOtherTechniques = txtOtherTechniques.getText();
        serviceRate = txtRate.getText();
        serviceRepetitiveness = txtRepetitiveness.getText();
        serviceServiceType = txtServiceType.getText();
        service.setServiceName(serviceName);
        service.setAstrologicalTechniques(serviceAstrologicalTechniques);
        service.setAverageDuration(serviceAverageDuration);
        service.setComments(serviceComments);
        service.setOtherTechniques(serviceOtherTechniques);
        service.setRate(serviceRate);
        service.setRepetitiveness(serviceRepetitiveness);
        service.setServiceType(serviceServiceType);
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBoutons = new javax.swing.JPanel();
        btnFirstService = new javax.swing.JButton();
        btnPreviousService = new javax.swing.JButton();
        txtCounterService = new javax.swing.JTextField();
        btnNextService = new javax.swing.JButton();
        btnLastService = new javax.swing.JButton();
        btnRemoveService = new javax.swing.JButton();
        btnAddService = new javax.swing.JButton();
        btnOKService = new javax.swing.JButton();
        btnCancelService = new javax.swing.JButton();
        pnlDetailService = new javax.swing.JPanel();
        jLabel113 = new javax.swing.JLabel();
        txtServiceName = new javax.swing.JTextField();
        jLabel124 = new javax.swing.JLabel();
        txtServiceType = new javax.swing.JTextField();
        jLabel109 = new javax.swing.JLabel();
        txtAstrologicalTechniques = new javax.swing.JTextField();
        jLabel110 = new javax.swing.JLabel();
        txtOtherTechniques = new javax.swing.JTextField();
        jLabel120 = new javax.swing.JLabel();
        txtAverageDuration = new javax.swing.JTextField();
        jLabel111 = new javax.swing.JLabel();
        txtRate = new javax.swing.JTextField();
        jLabel112 = new javax.swing.JLabel();
        txtRepetitiveness = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        lblNote = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtServiceComments = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlBoutons.setName(""); // NOI18N
        pnlBoutons.setPreferredSize(new java.awt.Dimension(450, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 1, 5));

        btnFirstService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png"))); // NOI18N
        btnFirstService.setBorder(null);
        btnFirstService.setContentAreaFilled(false);
        btnFirstService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnFirstService);

        btnPreviousService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
        btnPreviousService.setBorder(null);
        btnPreviousService.setContentAreaFilled(false);
        btnPreviousService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnPreviousService);

        txtCounterService.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCounterService.setPreferredSize(new java.awt.Dimension(180, 22));
        txtCounterService.setSelectionColor(new java.awt.Color(55, 155, 255));
        txtCounterService.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCounterServiceKeyReleased(evt);
            }
        });
        pnlBoutons.add(txtCounterService);

        btnNextService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
        btnNextService.setBorder(null);
        btnNextService.setContentAreaFilled(false);
        btnNextService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnNextService);

        btnLastService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png"))); // NOI18N
        btnLastService.setBorder(null);
        btnLastService.setContentAreaFilled(false);
        btnLastService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnLastService);

        btnRemoveService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveService.setBorder(null);
        btnRemoveService.setContentAreaFilled(false);
        btnRemoveService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveService);

        btnAddService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddService.setBorder(null);
        btnAddService.setContentAreaFilled(false);
        btnAddService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddService);

        btnOKService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOKService.setBorder(null);
        btnOKService.setContentAreaFilled(false);
        btnOKService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOKService);

        btnCancelService.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancelService.setBorder(null);
        btnCancelService.setContentAreaFilled(false);
        btnCancelService.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelServiceActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancelService);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.PAGE_START);

        pnlDetailService.setPreferredSize(new java.awt.Dimension(452, 473));
        pnlDetailService.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 1));

        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel113.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel113.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel113.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel113.setOpaque(true);
        jLabel113.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel113);

        txtServiceName.setPreferredSize(new java.awt.Dimension(255, 22));
        txtServiceName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtServiceNameKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtServiceNameKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtServiceName);

        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel124.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel124.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel124.setOpaque(true);
        jLabel124.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel124);

        txtServiceType.setPreferredSize(new java.awt.Dimension(255, 22));
        txtServiceType.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtServiceTypekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtServiceTypeKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtServiceType);

        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel109.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel109.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel109.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel109.setOpaque(true);
        jLabel109.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel109);

        txtAstrologicalTechniques.setPreferredSize(new java.awt.Dimension(255, 22));
        txtAstrologicalTechniques.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAstrologicalTechniqueskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAstrologicalTechniquesKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtAstrologicalTechniques);

        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel110.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel110.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel110.setOpaque(true);
        jLabel110.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel110);

        txtOtherTechniques.setPreferredSize(new java.awt.Dimension(255, 22));
        txtOtherTechniques.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOtherTechniqueskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOtherTechniquesKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtOtherTechniques);

        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel120.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel120.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel120.setOpaque(true);
        jLabel120.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel120);

        txtAverageDuration.setPreferredSize(new java.awt.Dimension(255, 22));
        txtAverageDuration.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAverageDurationkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAverageDurationKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtAverageDuration);

        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel111.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel111.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel111.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel111.setOpaque(true);
        jLabel111.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel111);

        txtRate.setPreferredSize(new java.awt.Dimension(255, 22));
        txtRate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRatekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtRateKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtRate);

        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel112.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel112.setMaximumSize(new java.awt.Dimension(185, 19));
        jLabel112.setMinimumSize(new java.awt.Dimension(185, 19));
        jLabel112.setOpaque(true);
        jLabel112.setPreferredSize(new java.awt.Dimension(185, 22));
        pnlDetailService.add(jLabel112);

        txtRepetitiveness.setPreferredSize(new java.awt.Dimension(255, 22));
        txtRepetitiveness.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRepetitivenesskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtRepetitivenessKeyPressed(evt);
            }
        });
        pnlDetailService.add(txtRepetitiveness);

        jPanel1.setPreferredSize(new java.awt.Dimension(450, 310));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        lblNote.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNote.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblNote.setAlignmentY(1.0F);
        lblNote.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblNote.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblNote.setOpaque(true);
        lblNote.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel1.add(lblNote);

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(440, 287));

        txtServiceComments.setPreferredSize(new java.awt.Dimension(440, 309));
        txtServiceComments.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtServiceCommentskeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtServiceCommentsKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(txtServiceComments);

        jPanel1.add(jScrollPane3);

        pnlDetailService.add(jPanel1);

        getContentPane().add(pnlDetailService, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_formWindowClosing

    private void btnFirstServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstServiceActionPerformed
    {//GEN-HEADEREND:event_btnFirstServiceActionPerformed
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(1);
        }
    }//GEN-LAST:event_btnFirstServiceActionPerformed

    private void btnPreviousServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousServiceActionPerformed
    {//GEN-HEADEREND:event_btnPreviousServiceActionPerformed
        if ((serviceRow > 1) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(serviceRow - 1);
        }
    }//GEN-LAST:event_btnPreviousServiceActionPerformed

    private void txtCounterServiceKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCounterServiceKeyReleased
    {//GEN-HEADEREND:event_txtCounterServiceKeyReleased
        if ((bolSetting == false) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            String value = txtCounterService.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            serviceRow = new Integer(value).intValue();
            if (serviceRow > nbOfRows)
            {
                serviceRow = nbOfRows;
            }
            showRecord(serviceRow);
        }
    }//GEN-LAST:event_txtCounterServiceKeyReleased

    private void btnNextServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextServiceActionPerformed
    {//GEN-HEADEREND:event_btnNextServiceActionPerformed
        if ((serviceRow < nbOfRows) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(serviceRow + 1);
        }
    }//GEN-LAST:event_btnNextServiceActionPerformed

    private void btnLastServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastServiceActionPerformed
    {//GEN-HEADEREND:event_btnLastServiceActionPerformed
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            showRecord(nbOfRows);
        }
    }//GEN-LAST:event_btnLastServiceActionPerformed

    private void btnRemoveServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveServiceActionPerformed
    {//GEN-HEADEREND:event_btnRemoveServiceActionPerformed
        removeServiceRec();
    }//GEN-LAST:event_btnRemoveServiceActionPerformed

    private void btnAddServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddServiceActionPerformed
    {//GEN-HEADEREND:event_btnAddServiceActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddServiceActionPerformed

    private void btnOKServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKServiceActionPerformed
    {//GEN-HEADEREND:event_btnOKServiceActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKServiceActionPerformed

    private void btnCancelServiceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelServiceActionPerformed
    {//GEN-HEADEREND:event_btnCancelServiceActionPerformed
        /*if (bolAdding == true)
        {
            serviceRow = saveRow;
        }
        bolEditing = false;
        bolAdding = false;
        bolDeleting = false;
        setNormalMode();
        refreshRecord();*/
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelServiceActionPerformed

    private void txtServiceNameKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceNameKeyTyped
    {//GEN-HEADEREND:event_txtServiceNameKeyTyped
        int size = 100;//new Integer(String.valueOf(services.getSizes().get(1))).intValue();
        if (txtServiceName.getText().length() >= size)
        {
            txtServiceName.setText(txtServiceName.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtServiceNameKeyTyped

    private void txtServiceNameKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceNameKeyPressed
    {//GEN-HEADEREND:event_txtServiceNameKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtServiceName.setText(serviceName);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtServiceNameKeyPressed

    private void txtServiceTypekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceTypekeyTyped
    {//GEN-HEADEREND:event_txtServiceTypekeyTyped
        int size = 100;//new Integer(String.valueOf(services.getSizes().get(2))).intValue();
        if (txtServiceType.getText().length() >= size)
        {
            txtServiceType.setText(txtServiceType.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtServiceTypekeyTyped

    private void txtServiceTypeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceTypeKeyPressed
    {//GEN-HEADEREND:event_txtServiceTypeKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtServiceType.setText(serviceServiceType);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtServiceTypeKeyPressed

    private void txtAstrologicalTechniqueskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAstrologicalTechniqueskeyTyped
    {//GEN-HEADEREND:event_txtAstrologicalTechniqueskeyTyped
        int size = 255;//new Integer(String.valueOf(services.getSizes().get(4))).intValue();
        if (txtAstrologicalTechniques.getText().length() >= size)
        {
            txtAstrologicalTechniques.setText(txtAstrologicalTechniques.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAstrologicalTechniqueskeyTyped

    private void txtAstrologicalTechniquesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAstrologicalTechniquesKeyPressed
    {//GEN-HEADEREND:event_txtAstrologicalTechniquesKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAstrologicalTechniques.setText(serviceAstrologicalTechniques);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAstrologicalTechniquesKeyPressed

    private void txtOtherTechniqueskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherTechniqueskeyTyped
    {//GEN-HEADEREND:event_txtOtherTechniqueskeyTyped
        int size = 255;//new Integer(String.valueOf(services.getSizes().get(5))).intValue();
        if (txtOtherTechniques.getText().length() >= size)
        {
            txtOtherTechniques.setText(txtOtherTechniques.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtOtherTechniqueskeyTyped

    private void txtOtherTechniquesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherTechniquesKeyPressed
    {//GEN-HEADEREND:event_txtOtherTechniquesKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtOtherTechniques.setText(serviceOtherTechniques);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtOtherTechniquesKeyPressed

    private void txtAverageDurationkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAverageDurationkeyTyped
    {//GEN-HEADEREND:event_txtAverageDurationkeyTyped
        int size = 50;//new Integer(String.valueOf(services.getSizes().get(3))).intValue();
        if (txtAverageDuration.getText().length() >= size)
        {
            txtAverageDuration.setText(txtAverageDuration.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtAverageDurationkeyTyped

    private void txtAverageDurationKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAverageDurationKeyPressed
    {//GEN-HEADEREND:event_txtAverageDurationKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAverageDuration.setText(serviceAverageDuration);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAverageDurationKeyPressed

    private void txtRatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRatekeyTyped
    {//GEN-HEADEREND:event_txtRatekeyTyped
        int size = 20;//new Integer(String.valueOf(services.getSizes().get(6))).intValue();
        if (txtRate.getText().length() >= size)
        {
            txtRate.setText(txtRate.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtRatekeyTyped

    private void txtRateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRateKeyPressed
    {//GEN-HEADEREND:event_txtRateKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtRate.setText(serviceRate);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtRateKeyPressed

    private void txtRepetitivenesskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRepetitivenesskeyTyped
    {//GEN-HEADEREND:event_txtRepetitivenesskeyTyped
        int size = 50;//new Integer(String.valueOf(services.getSizes().get(7))).intValue();
        if (txtRepetitiveness.getText().length() >= size)
        {
            txtRepetitiveness.setText(txtRepetitiveness.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtRepetitivenesskeyTyped

    private void txtRepetitivenessKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRepetitivenessKeyPressed
    {//GEN-HEADEREND:event_txtRepetitivenessKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtRepetitiveness.setText(serviceRepetitiveness);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtRepetitivenessKeyPressed

    private void txtServiceCommentskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceCommentskeyTyped
    {//GEN-HEADEREND:event_txtServiceCommentskeyTyped
        int size = 10000;//new Integer(String.valueOf(services.getSizes().get(8))).intValue();
        if (txtServiceComments.getText().length() >= size)
        {
            txtServiceComments.setText(txtServiceComments.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtServiceCommentskeyTyped

    private void txtServiceCommentsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtServiceCommentsKeyPressed
    {//GEN-HEADEREND:event_txtServiceCommentsKeyPressed
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtServiceComments.setText(serviceComments);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtServiceCommentsKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddService;
    private javax.swing.JButton btnCancelService;
    private javax.swing.JButton btnFirstService;
    private javax.swing.JButton btnLastService;
    private javax.swing.JButton btnNextService;
    private javax.swing.JButton btnOKService;
    private javax.swing.JButton btnPreviousService;
    private javax.swing.JButton btnRemoveService;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblNote;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlDetailService;
    private javax.swing.JTextField txtAstrologicalTechniques;
    private javax.swing.JTextField txtAverageDuration;
    private javax.swing.JTextField txtCounterService;
    private javax.swing.JTextField txtOtherTechniques;
    private javax.swing.JTextField txtRate;
    private javax.swing.JTextField txtRepetitiveness;
    private javax.swing.JTextPane txtServiceComments;
    private javax.swing.JTextField txtServiceName;
    private javax.swing.JTextField txtServiceType;
    // End of variables declaration//GEN-END:variables
}
