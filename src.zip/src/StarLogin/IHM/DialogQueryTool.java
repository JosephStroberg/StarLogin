/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.Persistence.DataBaseQueries;
import StarLogin.Persistence.DataBaseRecords;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.QueryDescription;
import StarLogin.Systeme.grids.DataGrid;
import StarLogin.Systeme.iofiles.HTMLStrings;
import java.awt.*;
import java.sql.Types;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
/**
 *
 * @author francoisdeschamps
 */
public class DialogQueryTool extends javax.swing.JDialog
{
    private boolean bSetting = true;
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private DataGrid dgrQuery;
    private DataBaseQueries queries;
    private QueryDescription queryDescription;
    private DefaultListModel listModel;
    private DefaultListModel listModel2;
    private ArrayList savedQueries;
    private ArrayList fields = new ArrayList();
    private ArrayList columnNames = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList rows = new ArrayList();
    private ArrayList sizes = new ArrayList();
    private JPanel[] pnlFieldsSelections;
    private JLabel[] lblFieldsCaptions;
    private JCheckBox[] chkFieldsSelections;
    private JPanel[] pnlFieldsSelections1;
    private JLabel[] lblFieldsGroupCaptions;
    private JLabel[] lblFieldsGroupOperationCaptions;
    private JTextField[] txtFieldValues;
    private JComboBox[] cboGroups;
    private JComboBox[] cboGroupOperations;
    private java.util.ResourceBundle bundle;
    private String mstrFilter = "";
    private int typeFromDataFieldFiltered = 0;
    private String strAscSort;
    private String strDescSort;
    private String strGrouping;
    private String strNumber;
    private String strSum;
    private String strAverage;
    private String strMaximum;
    private String strMinimum;
    private String strFirst;
    private String strLast;
    private String strNone;
    private String strOf;
    private String strAnd;
    //private String strOr;
    private String strEqual;
    private String strDifferent;
    private String strGreater;
    private String strGreaterEqual;
    private String strLesserEqual;
    private String strLesser;
    private String strBegin;
    private String strContain;
    private String strEnd;
    private String strBefore;
    private String strAfter;
    private String strIs;
    private String strNot;
    private String strNull;
    private boolean bolLoading = true;
    private String strGroupDate;
    private String strGroupValue;
    private String strGroupOperation;
    private String strGroupOperator;
    private String strGroupClearValue;
    private String sqlFrom;
    private String sqlString;
    private String sqlOrderBy;
    private String sqlWhere;
    private String STR__WHERE_ = " WHERE ";
    private String STR__ORDER_BY_ = " ORDER BY ";
    private String STR__GROUP_BY_ = " GROUP BY ";
    private String STR__HAVING_ = " HAVING ";
    private boolean bAborted = false;
    //private Window parentForm;
    private String classname = this.getClass().getName();
    private int nbq;
    private String savedQuery = "";

    /**
     * Creates new form DialogQueryTool
     */
    public DialogQueryTool(int nbq, java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        //parentForm = parent;
        setForm(nbq);
    }

    public DialogQueryTool(int nbq, java.awt.Dialog parent, boolean modal)
    {
        super(parent, modal);
        //parentForm = parent;
        setForm(nbq);
    }
    
    private void setForm(int nbq)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.nbq = nbq;
        bundle = MainClass.bundle;
        initComponents();
        resetLangue();
        queries = new DataBaseQueries();
        getQueries();

        cboLeftBracket.addItem("");
        cboLeftBracket.addItem("(");
        cboLeftBracket.addItem("((");
        cboRightBracket.addItem("");
        cboRightBracket.addItem(")");
        cboRightBracket.addItem("))");
        cboAndOr.addItem("");
        cboAndOr.addItem(bundle.getString("et"));
        cboAndOr.addItem(bundle.getString("ou"));
        cboSorting1.addItem("");
        cboSorting1.addItem(strAscSort);
        cboSorting1.addItem(strDescSort);
        cboSorting2.addItem("");
        cboSorting2.addItem(strAscSort);
        cboSorting2.addItem(strDescSort);
        cboSorting3.addItem("");
        cboSorting3.addItem(strAscSort);
        cboSorting3.addItem(strDescSort);
        cboSorting4.addItem("");
        cboSorting4.addItem(strAscSort);
        cboSorting4.addItem(strDescSort);

        int pos = classname.lastIndexOf(".");
        if (pos > 0)
        {
            classname = classname.substring(pos + 1);
        }
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        bolLoading = false;
        resetTab(nbq);
        bSetting = false;
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setVisible(true);
    }
    
    public void resetTab(int nbq)
    {
        getSavedQueries();
        
        MainClass.setRestrict(pnlFields, false, true);
        MainClass.setRestrict(pnlQueries, false, true);
        MainClass.setRestrict(pnlFilter, false, true);
        MainClass.setRestrict(pnlSort, false, true);
        MainClass.setRestrict(pnlGroup, false, true);        
        MainClass.setRestrict(pnlQueries, false, true);
        MainClass.setRestrict(pnlSavedQueries, false, true);
        for (int i=0; i<tabSettings.getTabCount(); i++)
        {
            tabSettings.setEnabledAt(i, false);
        }
        
        if (nbq >= 0)
        {
            lstQueries.setSelectedIndex(nbq);
            tabSettings.setSelectedIndex(2);
            tabSettings.setEnabledAt(2, true);
            MainClass.setRestrict(pnlFields, true, true);
        }
        else
        {
            tabSettings.setEnabledAt(0, true);
            tabSettings.setEnabledAt(1, true);
            MainClass.setRestrict(pnlQueries, true, true);
            MainClass.setRestrict(pnlSavedQueries, true, true);
        }/*
                getSavedQueries();
        for (int i=0; i<tabSettings.getTabCount(); i++)
        {
            tabSettings.setEnabledAt(i, false);
        }
        if (nbq >= 0)
        {
            lstQueries.setSelectedIndex(nbq);
            tabSettings.setSelectedIndex(2);
            tabSettings.setEnabledAt(2, true);
        }
        else
        {
            tabSettings.setEnabledAt(0, true);
            tabSettings.setEnabledAt(1, true);
        }*/
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("QueriesCreationWizard"));
        btnExport.setText(bundle.getString("ExportQueryResult"));
        btnSaveReport.setText(bundle.getString("SauverRapport"));
        btnOKSelect.setText(bundle.getString("Reset"));
        btnSelectAll.setText(bundle.getString("SelectAll"));
        btnUnselectAll.setText(bundle.getString("UnselectAll"));
        btnOKSelection.setText(bundle.getString("ValidateSelection"));
        lblFieldsCaptions1.setText(bundle.getString("AndOr"));
        lblFieldsCaptions2.setText(bundle.getString("LeftBracket"));
        lblFieldsCaptions3.setText(bundle.getString("DataField"));
        lblFieldsCaptions4.setText(bundle.getString("Operation"));
        lblFieldsCaptions5.setText(bundle.getString("Value"));
        lblFieldsCaptions6.setText(bundle.getString("RightBracket"));
        btnAddFilter.setText(bundle.getString("AddToFilter"));
        btnEraseFilter.setText(bundle.getString("EraseFilter"));
        btnOKFilter.setText(bundle.getString("ValidateFilter"));
        lblFieldsCaptions7.setText(bundle.getString("Filter"));
        lblFieldsCaptions8.setText(bundle.getString("DataField"));
        lblFieldsCaptions12.setText(bundle.getString("Sorting"));
        lblFieldsCaptions9.setText(bundle.getString("DataField"));
        lblFieldsCaptions13.setText(bundle.getString("Sorting"));
        lblFieldsCaptions10.setText(bundle.getString("DataField"));
        lblFieldsCaptions14.setText(bundle.getString("Sorting"));
        lblFieldsCaptions11.setText(bundle.getString("DataField"));
        lblFieldsCaptions15.setText(bundle.getString("Sorting"));
        btnOKSorting.setText(bundle.getString("ValidateSorting"));
        btnOKSorting.setActionCommand(bundle.getString("ValidateSorting"));
        btnOKGrouping.setText(bundle.getString("ValidateGrouping"));
        strAscSort = bundle.getString("AscendantSorting");
        strDescSort = bundle.getString("DescendantSorting");
        strGrouping = bundle.getString("Group");
        strNumber = bundle.getString("GNumber");
        strSum = bundle.getString("Sum");
        strAverage = bundle.getString("Average");
        strMaximum = bundle.getString("Maximum");
        strMinimum = bundle.getString("Minimum");
        strFirst = bundle.getString("First");
        strLast = bundle.getString("Last");
        strNone = bundle.getString("None");
        strOf = " " + bundle.getString("Of") + " ";
        strAnd = bundle.getString("et");
        //strOr = bundle.getString("ou");
        strEqual = " " + bundle.getString("EqualTo");
        strDifferent = " " + bundle.getString("DifferentFrom");
        strGreater = " " + bundle.getString("GreaterThan");
        strGreaterEqual = " " + bundle.getString("GreaterThanOrEqualTo");
        strLesserEqual = " " + bundle.getString("LesserThanOrEqualTo");
        strLesser = " " + bundle.getString("LesserThan");
        strBegin = " " + bundle.getString("BeginningWith");
        strContain = " " + bundle.getString("Containing");
        strEnd = " " + bundle.getString("EndingWith");
        strBefore = " " + bundle.getString("Before");
        strAfter = " " + bundle.getString("After");
        strIs = " " + bundle.getString("Is");
        strNot = " " + bundle.getString("Not");
        strNull = " " + bundle.getString("Null");
        
        tabSettings.setTitleAt(0, bundle.getString("RequetesSauvegardees"));
        tabSettings.setTitleAt(1, bundle.getString("DataSource"));
        tabSettings.setTitleAt(2, bundle.getString("DataFields"));
        tabSettings.setTitleAt(3, bundle.getString("Filter"));
        tabSettings.setTitleAt(4, bundle.getString("Sorting"));
        tabSettings.setTitleAt(5, bundle.getString("Grouping"));
        tabSettings.setTitleAt(6, bundle.getString("Destination"));
    }
    
    private void getSavedQuery(int index)
    {
        if (index<0 || index >= listModel.size())
            return;
        //get the query string from the list
        Object object = listModel.get(index);
        if (object != null)
        {
            Records recs;
            ArrayList sq = (ArrayList) savedQueries.get(index);
            sqlString = sq.get(1).toString();

            //get the records
            recs = starLoginManager.getRecords(sqlString, "X");//we don't need here the table name ("X" will indicate that field names include " AS ")

            fields = recs.getFields();
            columnNames = recs.getHeaders();
            rows = recs.getRecords();
            sizes = recs.getSizes();
            types = recs.getTypes();
            int pos = sqlString.indexOf(" FROM ");
            sqlFrom = sqlString.substring(pos);
            refreshGrid();
        }
    }

    public boolean isAborted()
    {
        return bAborted;
    }
    
    private int getType(int dataType)
    {
        switch (dataType)
        {
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
                return DataBaseRecords.typeString;

            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
            case Types.BIGINT:
            case Types.FLOAT:
            case Types.DOUBLE:
            case Types.NUMERIC:
            case Types.REAL:
                return DataBaseRecords.typeNumber;

            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
                return DataBaseRecords.typeDate;

            case Types.BOOLEAN:
            case Types.BIT:
                return DataBaseRecords.typeBool;

            default:
                return DataBaseRecords.typeString;
        }
    }
    
    private void getOperatorAndValue(int type, int group)
    {
        strGroupClearValue = strGroupValue;
        strGroupValue = strGroupValue.replace("'", "''");

        //cas des nombres et dates
        if (type == DataBaseRecords.typeNumber || type == DataBaseRecords.typeDate)
        {
            if (strGroupValue.toLowerCase().equals("null") || strGroupValue.equals(""))
            {
                strGroupValue = " null";
                strGroupClearValue = strNull;
            }
            if (type == DataBaseRecords.typeDate && !strGroupValue.equals(" null"))
            {
                strGroupDate = "#";

                //convert the string to a right date format
                //form yyyy-mm-dd... or dd-mm-yyyy to mm-dd-yyyy
                String strNewFormat;
                if (strGroupValue.length() > 10)
                {
                    strNewFormat = strGroupValue.substring(0, 10);
                }
                else
                {
                    strNewFormat = strGroupValue;
                }
                strNewFormat = strNewFormat.replace("/", "-");
                String strValueSave = strNewFormat;
                int pos = strValueSave.lastIndexOf("-");
                if (pos > 0)
                {
                    strNewFormat = strValueSave.substring(pos + 1);
                    strValueSave = strValueSave.substring(0, pos);
                    pos = strValueSave.indexOf("-");
                    if (pos > 0)
                    {
                        if (pos == 4)
                        {
                            strNewFormat = strValueSave.substring(pos + 1) + "/" + strNewFormat + "/" + strValueSave.substring(0, pos);
                        }
                        else
                        {
                            strNewFormat = strValueSave.substring(pos + 1) + "/" + strValueSave.substring(0, pos) + "/" + strNewFormat;
                        }
                    }
                }
                strGroupValue = strNewFormat;
            }

            if (strGroupValue.equals(" null"))
            {
                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
                else if (strGroupOperation.equals(strGreater))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
                else if (strGroupOperation.equals(strGreaterEqual))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
                else if (strGroupOperation.equals(strLesserEqual))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strLesser))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
            }
            else
            {
                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = "=";
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = "!=";
                }
                else if (strGroupOperation.equals(strGreater))
                {
                    strGroupOperator = ">";
                }
                else if (strGroupOperation.equals(strGreaterEqual))
                {
                    strGroupOperator = ">=";
                }
                else if (strGroupOperation.equals(strLesserEqual))
                {
                    strGroupOperator = "<=";
                }
                else if (strGroupOperation.equals(strLesser))
                {
                    strGroupOperator = "<";
                }
            }
        }
        else if (type == DataBaseRecords.typeString)
        {
            if (strGroupValue.toLowerCase().equals("null") || strGroupValue.equals(""))
            {
                strGroupValue = " null";
                strGroupClearValue = strNull;

                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
                else if (strGroupOperation.equals(strBegin))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strContain))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strEnd))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strBefore))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strAfter))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
            }
            else
            {
                strGroupClearValue = " \"" + strGroupClearValue + "\"";

                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = (group <= 4 ? "=" : "='");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = (group <= 4 ? "!=" : "!='");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
                else if (strGroupOperation.equals(strBegin))
                {
                    strGroupOperator = " Like'";
                    strGroupValue = strGroupValue + "%'";
                }
                else if (strGroupOperation.equals(strContain))
                {
                    strGroupOperator = " Like '" + "%";
                    strGroupValue = strGroupValue + "%'";
                }
                else if (strGroupOperation.equals(strEnd))
                {
                    strGroupOperator = " Like '" + "%";
                    strGroupValue = strGroupValue + "'";
                }
                else if (strGroupOperation.equals(strBefore))
                {
                    strGroupOperator = "<'";
                    strGroupValue = strGroupValue + "'";
                }
                else if (strGroupOperation.equals(strAfter))
                {
                    strGroupOperator = ">'";
                    strGroupValue = strGroupValue + "'";
                }
                else if (strGroupOperation.equals(strGreater))
                {
                    strGroupOperator = (group <= 4 ? ">" : ">'");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
                else if (strGroupOperation.equals(strGreaterEqual))
                {
                    strGroupOperator = (group <= 4 ? ">=" : ">='");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
                else if (strGroupOperation.equals(strLesserEqual))
                {
                    strGroupOperator = (group <= 4 ? "<=" : "<='");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
                else if (strGroupOperation.equals(strLesser))
                {
                    strGroupOperator = (group <= 4 ? "<" : "<'");
                    strGroupValue = strGroupValue + (group <= 4 ? "" : "'");
                }
            }
        }
        else if (type == DataBaseRecords.typeBool)
        {
            if (strGroupValue.equals(" null"))
            {
                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = " is";
                    strGroupOperation = strIs;
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = " is not";
                    strGroupOperation = strIs + strNot;
                }
            }
            else
            {
                if (strGroupOperation.equals(strEqual))
                {
                    strGroupOperator = "=";
                }
                else if (strGroupOperation.equals(strDifferent))
                {
                    strGroupOperator = "!=";
                }
            }
        }
    }

    private void getSavedQueries()
    {
        listModel = new DefaultListModel();
        Records rapports = starLoginManager.getRecords("SELECT NOM, REQUETE FROM rapport ORDER BY NOM", "rapport");
        savedQueries = rapports.getRecords();
        for (int i = 0; i < savedQueries.size(); i++)
        {
            ArrayList sq = (ArrayList) savedQueries.get(i);
            String queryName = sq.get(0).toString();
            listModel.addElement(queryName);
        }
        bSetting = true;
        lstSavedQueries.setModel(listModel);
        bSetting = false;
        if (listModel.isEmpty())
            tabSettings.setSelectedIndex(1);
        else
            tabSettings.setSelectedIndex(0);
    }
    
    private void getQueries()
    {
        listModel2 = new DefaultListModel();
        listModel2.addElement(bundle.getString("Contacts"));
        listModel2.addElement(bundle.getString("Clients"));
        listModel2.addElement(bundle.getString("Fournisseurs"));
        listModel2.addElement(bundle.getString("Events"));
        listModel2.addElement(bundle.getString("RendezVouss"));
        listModel2.addElement(bundle.getString("Asteroids"));
        listModel2.addElement(bundle.getString("Consultations"));
        listModel2.addElement(bundle.getString("Comets"));
        listModel2.addElement(bundle.getString("Stars"));
        listModel2.addElement(bundle.getString("Places"));
        listModel2.addElement(bundle.getString("ArabianParts"));
        listModel2.addElement(bundle.getString("Constellations"));
        lstQueries.setModel(listModel2);
    }

    private void refreshGrid()
    {
        pnlFieldsGroup.removeAll();
        pnlFieldsSelection.removeAll();
        if (sqlString != null && !sqlString.equals(""))
        {
            //Data grid
            dgrQuery = new DataGrid(rows, columnNames, fields, sizes, jPnlTable, false, false, false, false, this, false);

            int intFields = fields.size();

            if (intFields > 0)
            {
                //Build the controls for other tabs
                pnlFieldsSelection.setPreferredSize(new Dimension(900, (intFields * 22 + 34) / 3));
                pnlFieldsSelection.setLayout(new GridLayout(intFields / 3 + 1, 3, 0, 0));
                pnlFieldsSelections = new JPanel[intFields];
                lblFieldsCaptions = new JLabel[intFields];
                chkFieldsSelections = new JCheckBox[intFields];
                pnlFieldsGroup.setPreferredSize(new Dimension(900, (intFields * 30 + 54)));
                pnlFieldsGroup.setLayout(new GridLayout(intFields, 1, 5, 0));
                pnlFieldsSelections1 = new JPanel[intFields];
                lblFieldsGroupCaptions = new JLabel[intFields];
                lblFieldsGroupOperationCaptions = new JLabel[intFields];
                txtFieldValues = new JTextField[intFields];
                cboGroups = new JComboBox[intFields];
                cboGroupOperations = new JComboBox[intFields];
                cboDataField.removeAllItems();
                cboDataField1.removeAllItems();
                cboDataField2.removeAllItems();
                cboDataField3.removeAllItems();
                cboDataField4.removeAllItems();

                for (int i = 0; i < intFields; i++)
                {
                    //Fields selection panel
                    String fieldName = columnNames.get(i).toString();
                    pnlFieldsSelections[i] = new JPanel();
                    pnlFieldsSelections[i].setOpaque(false);
                    lblFieldsCaptions[i] = new JLabel();
                    lblFieldsCaptions[i].setOpaque(true);
                    lblFieldsCaptions[i].setPreferredSize(new Dimension(200, 20));
                    chkFieldsSelections[i] = new JCheckBox();
                    chkFieldsSelections[i].setSelected(true);
                    pnlFieldsSelections[i].setLayout(new FlowLayout(FlowLayout.LEFT, 10, 0));
                    pnlFieldsSelections[i].setPreferredSize(new Dimension(0, 22));
                    lblFieldsCaptions[i].setHorizontalAlignment(SwingConstants.CENTER);
                    lblFieldsCaptions[i].setText(fieldName);
                    if (fieldName.startsWith("_"))
                    {
                        lblFieldsCaptions[i].setVisible(false);
                        chkFieldsSelections[i].setVisible(false);
                        fieldName = "";
                    }
                    else
                    {
                        pnlFieldsSelections[i].add(lblFieldsCaptions[i]);
                        pnlFieldsSelections[i].add(chkFieldsSelections[i]);
                        pnlFieldsSelection.add(pnlFieldsSelections[i]);
                    }

                    //Filter panel
                    cboDataField.addItem(fieldName);

                    //Sorting panel
                    cboDataField1.addItem(fieldName);
                    cboDataField2.addItem(fieldName);
                    cboDataField3.addItem(fieldName);
                    cboDataField4.addItem(fieldName);

                    //Grouping panel
                    int dataType;
                    if (!types.isEmpty())
                    {
                        dataType = new Integer(String.valueOf(types.get(i))).intValue();
                    }
                    else
                    {
                        dataType = DataBaseRecords.typeString;
                    }
                    pnlFieldsSelections1[i] = new JPanel();
                    pnlFieldsSelections1[i].setOpaque(false);
                    lblFieldsGroupCaptions[i] = new JLabel();
                    lblFieldsGroupCaptions[i].setOpaque(true);
                    lblFieldsGroupCaptions[i].setPreferredSize(new Dimension(310, 22));
                    lblFieldsGroupOperationCaptions[i] = new JLabel();
                    lblFieldsGroupOperationCaptions[i].setOpaque(true);
                    lblFieldsGroupOperationCaptions[i].setPreferredSize(new Dimension(180, 22));
                    txtFieldValues[i] = new JTextField();
                    txtFieldValues[i].setPreferredSize(new Dimension(100, 22));
                    txtFieldValues[i].setEnabled(false);
                    cboGroups[i] = new JComboBox();
                    cboGroupOperations[i] = new JComboBox();
                    cboGroupOperations[i].setEnabled(false);
                    pnlFieldsSelections1[i].setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
                    pnlFieldsSelections1[i].setPreferredSize(new Dimension(900, 27));
                    lblFieldsGroupCaptions[i].setHorizontalAlignment(SwingConstants.CENTER);
                    if (fieldName.equals("")|| fieldName.startsWith("_"))
                        fieldName = bundle.getString("Index");
                    lblFieldsGroupCaptions[i].setText(fieldName);
                    lblFieldsGroupOperationCaptions[i].setHorizontalAlignment(SwingConstants.CENTER);
                    lblFieldsGroupOperationCaptions[i].setText(bundle.getString("FilterOnOperation"));
                    pnlFieldsSelections1[i].add(lblFieldsGroupCaptions[i]);
                    cboGroups[i].setPreferredSize(new Dimension(135, 25));

                    switch (dataType)
                    {
                        case DataBaseRecords.typeNumber:
                        case DataBaseRecords.typeDate:
                            cboGroups[i].addItem(strNone);
                            cboGroups[i].addItem(strGrouping);
                            cboGroups[i].addItem(strNumber);
                            cboGroups[i].addItem(strSum);
                            cboGroups[i].addItem(strAverage);
                            cboGroups[i].addItem(strMaximum);
                            cboGroups[i].addItem(strMinimum);
                            cboGroups[i].addItem(strFirst);
                            cboGroups[i].addItem(strLast);
                            break;

                        case DataBaseRecords.typeString:
                            cboGroups[i].addItem(strNone);
                            cboGroups[i].addItem(strGrouping);
                            cboGroups[i].addItem(strNumber);
                            cboGroups[i].addItem(strMaximum);
                            cboGroups[i].addItem(strMinimum);
                            cboGroups[i].addItem(strFirst);
                            cboGroups[i].addItem(strLast);
                            break;

                        case DataBaseRecords.typeBool:
                            cboGroups[i].addItem(strNone);
                            cboGroups[i].addItem(strGrouping);
                            cboGroups[i].addItem(strNumber);
                            cboGroups[i].addItem(strFirst);
                            cboGroups[i].addItem(strLast);
                            break;

                        default:
                    }

                    final JComboBox cboG = cboGroups[i];
                    final JComboBox cboGO = cboGroupOperations[i];
                    final JTextField txtFV = txtFieldValues[i];
                    final JLabel lbl = lblFieldsGroupOperationCaptions[i];
                    final int t = dataType;

                    //add an action listener to the combobox for the grouping operation
                    //in order to enable or disable the filter on the operation
                    cboGroups[i].addActionListener(new java.awt.event.ActionListener()
                    {

                        @Override
                        public void actionPerformed(java.awt.event.ActionEvent evt)
                        {
                            if (cboG.getSelectedItem() != null)
                            {
                                //case of operation not being Grouping or nothing
                                if (cboG.getSelectedIndex() >= 2)
                                {
                                    cboGO.removeAllItems();
                                    cboGO.setEnabled(true);
                                    txtFV.setEnabled(true);
                                    lbl.setEnabled(true);

                                    //fill in the combobox for the filter according to the type
                                    switch (t)
                                    {
                                        case DataBaseRecords.typeNumber:
                                        case DataBaseRecords.typeDate:
                                            cboGO.addItem("");
                                            cboGO.addItem(strEqual);
                                            cboGO.addItem(strDifferent);
                                            cboGO.addItem(strGreater);
                                            cboGO.addItem(strGreaterEqual);
                                            cboGO.addItem(strLesserEqual);
                                            cboGO.addItem(strLesser);
                                            break;

                                        case DataBaseRecords.typeString:
                                            if (cboG.getSelectedIndex() == 2)
                                            {
                                                cboGO.addItem("");
                                                cboGO.addItem(strEqual);
                                                cboGO.addItem(strDifferent);
                                                cboGO.addItem(strGreater);
                                                cboGO.addItem(strGreaterEqual);
                                                cboGO.addItem(strLesserEqual);
                                                cboGO.addItem(strLesser);
                                            }
                                            else
                                            {
                                                cboGO.addItem("");
                                                cboGO.addItem(strEqual);
                                                cboGO.addItem(strDifferent);
                                                cboGO.addItem(strBegin);
                                                cboGO.addItem(strContain);
                                                cboGO.addItem(strEnd);
                                                cboGO.addItem(strBefore);
                                                cboGO.addItem(strAfter);
                                            }
                                            break;

                                        case DataBaseRecords.typeBool:
                                            if (cboG.getSelectedIndex() == 2)
                                            {
                                                cboGO.addItem("");
                                                cboGO.addItem(strEqual);
                                                cboGO.addItem(strDifferent);
                                                cboGO.addItem(strGreater);
                                                cboGO.addItem(strGreaterEqual);
                                                cboGO.addItem(strLesserEqual);
                                                cboGO.addItem(strLesser);
                                            }
                                            else
                                            {
                                                cboGO.addItem("");
                                                cboGO.addItem(strEqual);
                                                cboGO.addItem(strDifferent);
                                            }
                                            break;

                                        default:
                                    }
                                }
                                //other cases
                                else
                                {
                                    cboGO.removeAllItems();
                                    cboGO.setEnabled(false);
                                    txtFV.setEnabled(false);
                                    txtFV.setText(null);
                                    lbl.setEnabled(false);
                                }
                            }
                            else
                            {
                                cboGO.removeAllItems();
                                cboGO.setEnabled(false);
                                txtFV.setEnabled(false);
                                txtFV.setText(null);
                                lbl.setEnabled(false);
                            }
                        }
                    });
                    cboGroupOperations[i].setPreferredSize(new Dimension(200, 25));
                    pnlFieldsSelections1[i].add(cboGroups[i]);
                    pnlFieldsSelections1[i].add(lblFieldsGroupOperationCaptions[i]);
                    pnlFieldsSelections1[i].add(cboGroupOperations[i]);
                    pnlFieldsSelections1[i].add(txtFieldValues[i]);
                    pnlFieldsGroup.add(pnlFieldsSelections1[i]);
                }
            }
        }
        cboDataField.setSelectedIndex(-1);
    }
    
    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT
     * modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPnlTable = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        tabSettings = new javax.swing.JTabbedPane();
        pnlSavedQueries = new javax.swing.JPanel();
        jScrollSavedQueries = new javax.swing.JScrollPane();
        lstSavedQueries = new javax.swing.JList();
        pnlQueries = new javax.swing.JPanel();
        jScrollSource = new javax.swing.JScrollPane();
        lstQueries = new javax.swing.JList();
        pnlFields = new javax.swing.JPanel();
        jScrollFields = new javax.swing.JScrollPane();
        pnlFieldsSelection = new javax.swing.JPanel();
        pnlButtonFields = new javax.swing.JPanel();
        btnSelectAll = new javax.swing.JButton();
        btnUnselectAll = new javax.swing.JButton();
        btnOKSelection = new javax.swing.JButton();
        pnlFilter = new javax.swing.JPanel();
        pnlFilter2 = new javax.swing.JPanel();
        lblFieldsCaptions1 = new javax.swing.JLabel();
        cboAndOr = new javax.swing.JComboBox();
        lblFieldsCaptions2 = new javax.swing.JLabel();
        cboLeftBracket = new javax.swing.JComboBox();
        pnlFilter3 = new javax.swing.JPanel();
        lblFieldsCaptions3 = new javax.swing.JLabel();
        cboDataField = new javax.swing.JComboBox();
        pnlFilter4 = new javax.swing.JPanel();
        lblFieldsCaptions4 = new javax.swing.JLabel();
        cboOperation = new javax.swing.JComboBox();
        pnlFilter5 = new javax.swing.JPanel();
        lblFieldsCaptions5 = new javax.swing.JLabel();
        cboValue = new javax.swing.JComboBox();
        lblFieldsCaptions6 = new javax.swing.JLabel();
        cboRightBracket = new javax.swing.JComboBox();
        pnlFilter6 = new javax.swing.JPanel();
        btnAddFilter = new javax.swing.JButton();
        btnEraseFilter = new javax.swing.JButton();
        btnOKFilter = new javax.swing.JButton();
        pnlFilter7 = new javax.swing.JPanel();
        lblFieldsCaptions7 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtFilter = new javax.swing.JTextArea();
        pnlSort = new javax.swing.JPanel();
        pnlSort2 = new javax.swing.JPanel();
        lblFieldsCaptions8 = new javax.swing.JLabel();
        cboDataField1 = new javax.swing.JComboBox();
        lblFieldsCaptions12 = new javax.swing.JLabel();
        cboSorting1 = new javax.swing.JComboBox();
        pnlSort3 = new javax.swing.JPanel();
        lblFieldsCaptions9 = new javax.swing.JLabel();
        cboDataField2 = new javax.swing.JComboBox();
        lblFieldsCaptions13 = new javax.swing.JLabel();
        cboSorting2 = new javax.swing.JComboBox();
        pnlSort4 = new javax.swing.JPanel();
        lblFieldsCaptions10 = new javax.swing.JLabel();
        cboDataField3 = new javax.swing.JComboBox();
        lblFieldsCaptions14 = new javax.swing.JLabel();
        cboSorting3 = new javax.swing.JComboBox();
        pnlSort5 = new javax.swing.JPanel();
        lblFieldsCaptions11 = new javax.swing.JLabel();
        cboDataField4 = new javax.swing.JComboBox();
        lblFieldsCaptions15 = new javax.swing.JLabel();
        cboSorting4 = new javax.swing.JComboBox();
        pnlSort6 = new javax.swing.JPanel();
        btnOKSorting = new javax.swing.JButton();
        pnlGroup = new javax.swing.JPanel();
        jScrollGroup = new javax.swing.JScrollPane();
        pnlFieldsGroup = new javax.swing.JPanel();
        jPanelGroup = new javax.swing.JPanel();
        btnOKGrouping = new javax.swing.JButton();
        pnlDestination = new javax.swing.JPanel();
        btnExport = new javax.swing.JButton();
        btnSaveReport = new javax.swing.JButton();
        btnOKSelect = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 725));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPnlTable.setPreferredSize(new java.awt.Dimension(1000, 333));
        jPnlTable.setLayout(new java.awt.BorderLayout());
        getContentPane().add(jPnlTable, java.awt.BorderLayout.CENTER);

        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 310));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 25, 5));

        tabSettings.setMinimumSize(new java.awt.Dimension(800, 300));
        tabSettings.setPreferredSize(new java.awt.Dimension(1000, 300));

        pnlSavedQueries.setPreferredSize(new java.awt.Dimension(3, 180));
        pnlSavedQueries.setLayout(new java.awt.BorderLayout());

        jScrollSavedQueries.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollSavedQueries.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollSavedQueries.setPreferredSize(new java.awt.Dimension(919, 300));

        lstSavedQueries.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        lstSavedQueries.setPreferredSize(new java.awt.Dimension(900, 1500));
        lstSavedQueries.setVisibleRowCount(50);
        lstSavedQueries.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstSavedQueriesValueChanged(evt);
            }
        });
        jScrollSavedQueries.setViewportView(lstSavedQueries);

        pnlSavedQueries.add(jScrollSavedQueries, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("", pnlSavedQueries);

        pnlQueries.setPreferredSize(new java.awt.Dimension(3, 180));
        pnlQueries.setLayout(new java.awt.BorderLayout());

        jScrollSource.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollSource.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollSource.setPreferredSize(new java.awt.Dimension(919, 300));

        lstQueries.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        lstQueries.setPreferredSize(new java.awt.Dimension(900, 1500));
        lstQueries.setVisibleRowCount(50);
        lstQueries.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstQueriesValueChanged(evt);
            }
        });
        jScrollSource.setViewportView(lstQueries);

        pnlQueries.add(jScrollSource, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("", pnlQueries);

        pnlFields.setEnabled(false);
        pnlFields.setLayout(new java.awt.BorderLayout());

        jScrollFields.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollFields.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollFields.setPreferredSize(new java.awt.Dimension(919, 300));

        pnlFieldsSelection.setMinimumSize(new java.awt.Dimension(0, 0));
        pnlFieldsSelection.setPreferredSize(new java.awt.Dimension(900, 2000));
        pnlFieldsSelection.setLayout(new java.awt.GridLayout(51, 2, 50, 0));
        jScrollFields.setViewportView(pnlFieldsSelection);

        pnlFields.add(jScrollFields, java.awt.BorderLayout.CENTER);

        pnlButtonFields.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 75, 1));

        btnSelectAll.setPreferredSize(new java.awt.Dimension(200, 26));
        btnSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectAllActionPerformed(evt);
            }
        });
        pnlButtonFields.add(btnSelectAll);

        btnUnselectAll.setPreferredSize(new java.awt.Dimension(200, 26));
        btnUnselectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUnselectAllActionPerformed(evt);
            }
        });
        pnlButtonFields.add(btnUnselectAll);

        btnOKSelection.setPreferredSize(new java.awt.Dimension(200, 26));
        btnOKSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKSelectionActionPerformed(evt);
            }
        });
        pnlButtonFields.add(btnOKSelection);

        pnlFields.add(pnlButtonFields, java.awt.BorderLayout.SOUTH);

        tabSettings.addTab("", pnlFields);

        pnlFilter.setEnabled(false);
        pnlFilter.setPreferredSize(new java.awt.Dimension(1000, 200));

        pnlFilter2.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter2.setPreferredSize(new java.awt.Dimension(970, 29));
        pnlFilter2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        lblFieldsCaptions1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblFieldsCaptions1.setOpaque(true);
        lblFieldsCaptions1.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlFilter2.add(lblFieldsCaptions1);

        cboAndOr.setMaximumRowCount(3);
        cboAndOr.setPreferredSize(new java.awt.Dimension(80, 25));
        pnlFilter2.add(cboAndOr);

        lblFieldsCaptions2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblFieldsCaptions2.setOpaque(true);
        lblFieldsCaptions2.setPreferredSize(new java.awt.Dimension(220, 16));
        pnlFilter2.add(lblFieldsCaptions2);

        cboLeftBracket.setMaximumRowCount(3);
        cboLeftBracket.setPreferredSize(new java.awt.Dimension(80, 25));
        pnlFilter2.add(cboLeftBracket);

        pnlFilter.add(pnlFilter2);

        pnlFilter3.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter3.setOpaque(false);
        pnlFilter3.setPreferredSize(new java.awt.Dimension(970, 29));
        pnlFilter3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        lblFieldsCaptions3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblFieldsCaptions3.setOpaque(true);
        lblFieldsCaptions3.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlFilter3.add(lblFieldsCaptions3);

        cboDataField.setPreferredSize(new java.awt.Dimension(390, 25));
        cboDataField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboDataFieldActionPerformed(evt);
            }
        });
        pnlFilter3.add(cboDataField);

        pnlFilter.add(pnlFilter3);

        pnlFilter4.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter4.setOpaque(false);
        pnlFilter4.setPreferredSize(new java.awt.Dimension(970, 29));
        pnlFilter4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        lblFieldsCaptions4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblFieldsCaptions4.setOpaque(true);
        lblFieldsCaptions4.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlFilter4.add(lblFieldsCaptions4);

        cboOperation.setPreferredSize(new java.awt.Dimension(220, 25));
        pnlFilter4.add(cboOperation);

        pnlFilter.add(pnlFilter4);

        pnlFilter5.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter5.setOpaque(false);
        pnlFilter5.setPreferredSize(new java.awt.Dimension(970, 29));
        pnlFilter5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        lblFieldsCaptions5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblFieldsCaptions5.setOpaque(true);
        lblFieldsCaptions5.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlFilter5.add(lblFieldsCaptions5);

        cboValue.setEditable(true);
        cboValue.setPreferredSize(new java.awt.Dimension(500, 25));
        pnlFilter5.add(cboValue);

        lblFieldsCaptions6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblFieldsCaptions6.setOpaque(true);
        lblFieldsCaptions6.setPreferredSize(new java.awt.Dimension(220, 16));
        pnlFilter5.add(lblFieldsCaptions6);

        cboRightBracket.setMaximumRowCount(3);
        cboRightBracket.setPreferredSize(new java.awt.Dimension(80, 25));
        pnlFilter5.add(cboRightBracket);

        pnlFilter.add(pnlFilter5);

        pnlFilter6.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter6.setOpaque(false);
        pnlFilter6.setPreferredSize(new java.awt.Dimension(970, 37));
        pnlFilter6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 75, 5));

        btnAddFilter.setPreferredSize(new java.awt.Dimension(200, 26));
        btnAddFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddFilterActionPerformed(evt);
            }
        });
        pnlFilter6.add(btnAddFilter);

        btnEraseFilter.setPreferredSize(new java.awt.Dimension(200, 26));
        btnEraseFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEraseFilterActionPerformed(evt);
            }
        });
        pnlFilter6.add(btnEraseFilter);

        btnOKFilter.setPreferredSize(new java.awt.Dimension(200, 26));
        btnOKFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKFilterActionPerformed(evt);
            }
        });
        pnlFilter6.add(btnOKFilter);

        pnlFilter.add(pnlFilter6);

        pnlFilter7.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlFilter7.setOpaque(false);
        pnlFilter7.setPreferredSize(new java.awt.Dimension(970, 65));
        pnlFilter7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        lblFieldsCaptions7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblFieldsCaptions7.setOpaque(true);
        lblFieldsCaptions7.setPreferredSize(new java.awt.Dimension(63, 16));
        pnlFilter7.add(lblFieldsCaptions7);

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane4.setViewportBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jScrollPane4.setPreferredSize(new java.awt.Dimension(895, 63));

        txtFilter.setMargin(new java.awt.Insets(0, 5, 0, 5));
        txtFilter.setPreferredSize(new java.awt.Dimension(0, 200));
        jScrollPane4.setViewportView(txtFilter);

        pnlFilter7.add(jScrollPane4);

        pnlFilter.add(pnlFilter7);

        tabSettings.addTab("", pnlFilter);

        pnlSort.setEnabled(false);
        pnlSort.setLayout(new java.awt.GridLayout(5, 1));

        pnlSort2.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlSort2.setOpaque(false);
        pnlSort2.setPreferredSize(new java.awt.Dimension(116, 25));
        pnlSort2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 7));

        lblFieldsCaptions8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions8.setOpaque(true);
        lblFieldsCaptions8.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort2.add(lblFieldsCaptions8);

        cboDataField1.setPreferredSize(new java.awt.Dimension(360, 25));
        pnlSort2.add(cboDataField1);

        lblFieldsCaptions12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions12.setOpaque(true);
        lblFieldsCaptions12.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort2.add(lblFieldsCaptions12);

        cboSorting1.setPreferredSize(new java.awt.Dimension(200, 25));
        pnlSort2.add(cboSorting1);

        pnlSort.add(pnlSort2);

        pnlSort3.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlSort3.setOpaque(false);
        pnlSort3.setPreferredSize(new java.awt.Dimension(116, 25));
        pnlSort3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 7));

        lblFieldsCaptions9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions9.setOpaque(true);
        lblFieldsCaptions9.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort3.add(lblFieldsCaptions9);

        cboDataField2.setPreferredSize(new java.awt.Dimension(360, 25));
        pnlSort3.add(cboDataField2);

        lblFieldsCaptions13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions13.setOpaque(true);
        lblFieldsCaptions13.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort3.add(lblFieldsCaptions13);

        cboSorting2.setPreferredSize(new java.awt.Dimension(200, 25));
        pnlSort3.add(cboSorting2);

        pnlSort.add(pnlSort3);

        pnlSort4.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlSort4.setOpaque(false);
        pnlSort4.setPreferredSize(new java.awt.Dimension(116, 25));
        pnlSort4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 7));

        lblFieldsCaptions10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions10.setOpaque(true);
        lblFieldsCaptions10.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort4.add(lblFieldsCaptions10);

        cboDataField3.setPreferredSize(new java.awt.Dimension(360, 25));
        pnlSort4.add(cboDataField3);

        lblFieldsCaptions14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions14.setOpaque(true);
        lblFieldsCaptions14.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort4.add(lblFieldsCaptions14);

        cboSorting3.setPreferredSize(new java.awt.Dimension(200, 25));
        pnlSort4.add(cboSorting3);

        pnlSort.add(pnlSort4);

        pnlSort5.setMinimumSize(new java.awt.Dimension(87, 25));
        pnlSort5.setOpaque(false);
        pnlSort5.setPreferredSize(new java.awt.Dimension(116, 25));
        pnlSort5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 7));

        lblFieldsCaptions11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions11.setOpaque(true);
        lblFieldsCaptions11.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort5.add(lblFieldsCaptions11);

        cboDataField4.setPreferredSize(new java.awt.Dimension(360, 25));
        pnlSort5.add(cboDataField4);

        lblFieldsCaptions15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFieldsCaptions15.setOpaque(true);
        lblFieldsCaptions15.setPreferredSize(new java.awt.Dimension(150, 16));
        pnlSort5.add(lblFieldsCaptions15);

        cboSorting4.setPreferredSize(new java.awt.Dimension(200, 25));
        pnlSort5.add(cboSorting4);

        pnlSort.add(pnlSort5);

        pnlSort6.setOpaque(false);

        btnOKSorting.setPreferredSize(new java.awt.Dimension(200, 26));
        btnOKSorting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKSortingActionPerformed(evt);
            }
        });
        pnlSort6.add(btnOKSorting);

        pnlSort.add(pnlSort6);

        tabSettings.addTab("", pnlSort);

        pnlGroup.setEnabled(false);
        pnlGroup.setLayout(new java.awt.BorderLayout());

        jScrollGroup.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollGroup.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollGroup.setPreferredSize(new java.awt.Dimension(900, 2000));

        pnlFieldsGroup.setMinimumSize(new java.awt.Dimension(0, 0));
        pnlFieldsGroup.setPreferredSize(new java.awt.Dimension(900, 2004));
        pnlFieldsGroup.setLayout(new java.awt.GridLayout(51, 1, 100, 0));
        jScrollGroup.setViewportView(pnlFieldsGroup);

        pnlGroup.add(jScrollGroup, java.awt.BorderLayout.CENTER);

        jPanelGroup.setOpaque(false);
        jPanelGroup.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 1));

        btnOKGrouping.setPreferredSize(new java.awt.Dimension(200, 26));
        btnOKGrouping.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKGroupingActionPerformed(evt);
            }
        });
        jPanelGroup.add(btnOKGrouping);

        pnlGroup.add(jPanelGroup, java.awt.BorderLayout.SOUTH);

        tabSettings.addTab("", pnlGroup);

        pnlDestination.setEnabled(false);
        pnlDestination.setPreferredSize(new java.awt.Dimension(10, 100));
        pnlDestination.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 85));

        btnExport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/rapports2.png"))); // NOI18N
        btnExport.setEnabled(false);
        btnExport.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnExport.setPreferredSize(new java.awt.Dimension(275, 42));
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });
        pnlDestination.add(btnExport);

        btnSaveReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/save2.png"))); // NOI18N
        btnSaveReport.setEnabled(false);
        btnSaveReport.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSaveReport.setPreferredSize(new java.awt.Dimension(275, 42));
        btnSaveReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveReportActionPerformed(evt);
            }
        });
        pnlDestination.add(btnSaveReport);

        btnOKSelect.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOKSelect.setEnabled(false);
        btnOKSelect.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOKSelect.setPreferredSize(new java.awt.Dimension(275, 42));
        btnOKSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKSelectActionPerformed(evt);
            }
        });
        pnlDestination.add(btnOKSelect);

        tabSettings.addTab("", pnlDestination);

        jPanel1.add(tabSettings);

        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = 0;
        MainClass.starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
    }//GEN-LAST:event_formWindowClosing

    private void formComponentShown(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentShown
    {//GEN-HEADEREND:event_formComponentShown
        //this.paintAll(this.getGraphics());
        resetTab(nbq);
        bSetting = false;
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_formComponentShown

    private void lstSavedQueriesValueChanged(javax.swing.event.ListSelectionEvent evt)//GEN-FIRST:event_lstSavedQueriesValueChanged
    {//GEN-HEADEREND:event_lstSavedQueriesValueChanged
        /*setCursor(new Cursor(Cursor.WAIT_CURSOR));
        int index = lstSavedQueries.getSelectedIndex();
        bSetting = true;
        getSavedQuery(index);
        bSetting = false;
        MainClass.setRestrict(pnlFields, false, true);
        MainClass.setRestrict(pnlQueries, false, true);
        MainClass.setRestrict(pnlFilter, false, true);
        MainClass.setRestrict(pnlSort, false, true);
        MainClass.setRestrict(pnlGroup, false, true);
        btnExport.setEnabled(true);
        btnSaveReport.setEnabled(false);
        btnOKSelect.setEnabled(false);
        tabSettings.setEnabledAt(0, false);
        tabSettings.setEnabledAt(1, false);
        tabSettings.setEnabledAt(2, true);
        tabSettings.setSelectedIndex(2);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));*/
        if (bSetting)
        {
            return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        int index = lstSavedQueries.getSelectedIndex();
        savedQuery = MainClass.null2String(lstSavedQueries.getSelectedValue());
        bSetting = true;
        getSavedQuery(index);
        bSetting = false;
        MainClass.setRestrict(pnlFields, false, true);
        MainClass.setRestrict(pnlQueries, false, true);
        MainClass.setRestrict(pnlFilter, false, true);
        MainClass.setRestrict(pnlSort, false, true);
        MainClass.setRestrict(pnlGroup, false, true);
        btnExport.setEnabled(true);
        btnSaveReport.setEnabled(false);
        btnOKSelect.setEnabled(true);
        tabSettings.setEnabledAt(0, false);
        tabSettings.setEnabledAt(1, false);
        tabSettings.setEnabledAt(2, false);
        tabSettings.setEnabledAt(3, false);
        tabSettings.setEnabledAt(4, false);
        tabSettings.setEnabledAt(5, false);
        tabSettings.setEnabledAt(6, true);
        tabSettings.setSelectedIndex(6);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_lstSavedQueriesValueChanged

    private void lstQueriesValueChanged(javax.swing.event.ListSelectionEvent evt)//GEN-FIRST:event_lstQueriesValueChanged
    {//GEN-HEADEREND:event_lstQueriesValueChanged
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        int index = lstQueries.getSelectedIndex();
        /*
         * bSetting = true; getQuery(index); bSetting = false;
         */
        bSetting = true;

        Object object = listModel2.get(index);
        if (object != null)
        {
            //String queryName = object.toString();
            queryDescription = queries.getQuery(index);
            fields = queryDescription.getFieldNames();
            columnNames = queryDescription.getHeaders();
            types = queryDescription.getTypes();
            sqlFrom = queryDescription.getFrom();
            sqlWhere = queryDescription.getWhere();
            /*
             * if (nbq == 0) { sqlOrderBy = " ORDER BY NOMCOMPLET"; sqlString =
             * queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, "", sqlOrderBy, ""); }
            else
             */
            sqlString = queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, "", "", "");
            rows = queries.getRows();
            sizes = queries.getSizes();
            if (!sqlString.equals(""))
            {
                mstrFilter = "";
                txtFilter.setText("");
                btnExport.setEnabled(true);
                btnSaveReport.setEnabled(true);
                btnOKSelect.setEnabled(true);
                refreshGrid();
            }
        }
        bSetting = false;

        //next tab enabled, current disabled
        MainClass.setRestrict(pnlFields, true, true);
        MainClass.setRestrict(pnlQueries, false, true);
        MainClass.setRestrict(pnlSavedQueries, false, true);
        tabSettings.setEnabledAt(0, false);
        tabSettings.setEnabledAt(1, false);
        tabSettings.setEnabledAt(2, true);
        tabSettings.setSelectedIndex(2);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_lstQueriesValueChanged

    private void btnSelectAllActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSelectAllActionPerformed
    {//GEN-HEADEREND:event_btnSelectAllActionPerformed
        for (int i = 0; i < chkFieldsSelections.length; i++)
        {
            chkFieldsSelections[i].setSelected(true);
        }
    }//GEN-LAST:event_btnSelectAllActionPerformed

    private void btnUnselectAllActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnUnselectAllActionPerformed
    {//GEN-HEADEREND:event_btnUnselectAllActionPerformed
        for (int i = 0; i < chkFieldsSelections.length; i++)
        {
            String fieldName = columnNames.get(i).toString();
            if (!fieldName.startsWith("_"))
            {
                chkFieldsSelections[i].setSelected(false);
            }
        }
    }//GEN-LAST:event_btnUnselectAllActionPerformed

    @SuppressWarnings("unchecked")
    private void btnOKSelectionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKSelectionActionPerformed
    {//GEN-HEADEREND:event_btnOKSelectionActionPerformed
        ArrayList newFields = new ArrayList();
        ArrayList newAlias = new ArrayList();
        ArrayList newTypes = new ArrayList();
        int intFields = fields.size();
        boolean found = false;
        if (intFields > 0)
        {
            for (int i = 0; i < intFields; i++)
            {
                if (chkFieldsSelections[i].isSelected())
                {
                    newFields.add(fields.get(i));
                    newAlias.add(columnNames.get(i));
                    newTypes.add(types.get(i));
                    found = true;
                }
            }
            if (found)
            {
                fields = newFields;
                columnNames = newAlias;
                types = newTypes;
                sqlString = queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, "", "", "");
                rows = queries.getRows();
                sizes = queries.getSizes();
                refreshGrid();
            }
            //pnlFieldsSelection.paintAll(pnlFieldsSelection.getGraphics());
            pnlFieldsSelection.paintImmediately(pnlFieldsSelection.getBounds());
        }

        //next tab enabled, current disabled
        MainClass.setRestrict(pnlFields, false, true);
        MainClass.setRestrict(pnlFilter, true, true);
        tabSettings.setEnabledAt(2, false);
        tabSettings.setEnabledAt(3, true);
        tabSettings.setSelectedIndex(3);
    }//GEN-LAST:event_btnOKSelectionActionPerformed

    private void cboDataFieldActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboDataFieldActionPerformed
    {//GEN-HEADEREND:event_cboDataFieldActionPerformed
        if (bolLoading == true || bSetting == true)
        {
            return;
        }
        int selectedField = cboDataField.getSelectedIndex();
        if (selectedField < 0)
        {
            return;
        }
        int dataType = new Integer(String.valueOf(types.get(selectedField))).intValue();
        //typeFromDataFieldFiltered = getType(dataType);
        cboOperation.removeAllItems();

        switch (dataType)//typeFromDataFieldFiltered)
        {
            case DataBaseRecords.typeNumber:
            case DataBaseRecords.typeDate:
                cboOperation.addItem(strEqual);
                cboOperation.addItem(strDifferent);
                cboOperation.addItem(strGreater);
                cboOperation.addItem(strGreaterEqual);
                cboOperation.addItem(strLesserEqual);
                cboOperation.addItem(strLesser);
                break;

            case DataBaseRecords.typeString:
                cboOperation.addItem(strEqual);
                cboOperation.addItem(strDifferent);
                cboOperation.addItem(strBegin);
                cboOperation.addItem(strContain);
                cboOperation.addItem(strEnd);
                cboOperation.addItem(strBefore);
                cboOperation.addItem(strAfter);
                break;

            case DataBaseRecords.typeBool:
                cboOperation.addItem(strEqual);
                cboOperation.addItem(strDifferent);
                break;

            default:
        }

        //use a query to find the possible field values
        cboValue.removeAllItems();
        int intField = cboDataField.getSelectedIndex();
        ArrayList vFields = fields;//queryDescription.getFieldNames();
        if (vFields == null)
        {
            return;
        }
        String strQuery = "SELECT DISTINCT " + vFields.get(intField).toString() + queryDescription.getFrom();
        ArrayList values = queries.getList(strQuery);
        if (values != null)
        {
            for (int i = 0; i < values.size(); i++)
            {
                ArrayList v = (ArrayList) values.get(i);
                String value = String.valueOf(v.get(0));
                cboValue.addItem(value);
            }
        }
    }//GEN-LAST:event_cboDataFieldActionPerformed

    private void btnAddFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddFilterActionPerformed
    {//GEN-HEADEREND:event_btnAddFilterActionPerformed
        String strOrAnd = "";
        String strOuEt = "";
        ArrayList vFields = fields;// queryDescription.getFieldNames();
        if (vFields == null)
        {
            return;
        }

        if (!mstrFilter.equals(""))
        {
            strOuEt = cboAndOr.getSelectedItem().toString();
            if (strOuEt.equals(""))
            {
                strOuEt = strAnd;
            }
            if (strOuEt.equals(strAnd))
            {
                strOrAnd = " And ";
            }
            else
            {
                strOrAnd = " Or ";
            }
            strOuEt = "\n" + strOuEt + " ";
        }

        mstrFilter = mstrFilter + strOrAnd + cboLeftBracket.getSelectedItem().toString() + vFields.get(cboDataField.getSelectedIndex()).toString() + " ";
        txtFilter.setText(txtFilter.getText() + strOuEt + cboLeftBracket.getSelectedItem().toString() + "[" + cboDataField.getSelectedItem().toString() + "]" + " ");

        strGroupDate = "";
        strGroupValue = cboValue.getSelectedItem().toString();
        strGroupOperation = cboOperation.getSelectedItem().toString();
        strGroupOperator = "";
        strGroupClearValue = "";
        getOperatorAndValue(typeFromDataFieldFiltered, 99);
        txtFilter.setText(txtFilter.getText() + strGroupOperation + strGroupClearValue + cboRightBracket.getSelectedItem().toString());
        mstrFilter = mstrFilter + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + cboRightBracket.getSelectedItem().toString();
    }//GEN-LAST:event_btnAddFilterActionPerformed

    private void btnEraseFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnEraseFilterActionPerformed
    {//GEN-HEADEREND:event_btnEraseFilterActionPerformed
        mstrFilter = "";
        txtFilter.setText("");
    }//GEN-LAST:event_btnEraseFilterActionPerformed

    private void btnOKFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKFilterActionPerformed
    {//GEN-HEADEREND:event_btnOKFilterActionPerformed
        //modifie la requ�te
        if (!mstrFilter.equals(""))
        {
            if (sqlWhere.equals(""))
            {
                sqlWhere = STR__WHERE_ + mstrFilter;
            }
            else
            {
                sqlWhere = sqlWhere.concat(" AND (").concat(mstrFilter).concat(")");
            }
        }

        sqlString = queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, "", "", "");
        rows = queries.getRows();
        sizes = queries.getSizes();

        //refresh the grid
        if (!sqlString.equals(""))
        {
            dgrQuery = new DataGrid(rows, columnNames, fields, sizes, jPnlTable, false, false, false, false, this, true);
            //this.paintAll(this.getGraphics());
            jPnlTable.paintImmediately(jPnlTable.getBounds());
        }

        //next tab enabled, current disabled
        MainClass.setRestrict(pnlSort, true, true);
        MainClass.setRestrict(pnlFilter, false, true);
        tabSettings.setEnabledAt(3, false);
        tabSettings.setEnabledAt(4, true);
        tabSettings.setSelectedIndex(4);
    }//GEN-LAST:event_btnOKFilterActionPerformed

    private void btnOKSortingActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKSortingActionPerformed
    {//GEN-HEADEREND:event_btnOKSortingActionPerformed
        //modify the query
        String strSort = "";
        ArrayList vFields = fields;
        if (vFields == null)
        {
            return;
        }

        if (cboSorting1.getSelectedIndex() != 0)
        {
            strSort = vFields.get(cboDataField1.getSelectedIndex()).toString();
            if (cboSorting1.getSelectedIndex() == 2)
            {
                strSort = strSort + " DESC";
            }
        }
        if (cboSorting2.getSelectedIndex() != 0)
        {
            if (!strSort.equals(""))
            {
                strSort = strSort + ", " + vFields.get(cboDataField2.getSelectedIndex()).toString();
            }
            else
            {
                strSort = vFields.get(cboDataField2.getSelectedIndex()).toString();
            }
            if (cboSorting2.getSelectedIndex() == 2)
            {
                strSort = strSort + " DESC";
            }
        }

        if (cboSorting3.getSelectedIndex() != 0)
        {
            if (!strSort.equals(""))
            {
                strSort = strSort + ", " + vFields.get(cboDataField3.getSelectedIndex()).toString();
            }
            else
            {
                strSort = vFields.get(cboDataField3.getSelectedIndex()).toString();
            }
            if (cboSorting3.getSelectedIndex() == 2)
            {
                strSort = strSort + " DESC";
            }
        }

        if (cboSorting4.getSelectedIndex() != 0)
        {
            if (!strSort.equals(""))
            {
                strSort = strSort + ", " + vFields.get(cboDataField4.getSelectedIndex()).toString();
            }
            else
            {
                strSort = vFields.get(cboDataField4.getSelectedIndex()).toString();
            }
            if (cboSorting4.getSelectedIndex() == 2)
            {
                strSort = strSort + " DESC";
            }
        }

        if (!strSort.equals(""))
        {
            strSort = STR__ORDER_BY_ + strSort;
        }
        sqlOrderBy = strSort;

        //recreate the query
        sqlString = queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, "", sqlOrderBy, "");
        rows = queries.getRows();
        sizes = queries.getSizes();

        //refresh the grid
        if (!sqlString.equals(""))
        {
            dgrQuery = new DataGrid(rows, columnNames, fields, sizes, jPnlTable, false, false, false, false, this, true);
            //this.paintAll(this.getGraphics());
            jPnlTable.paintImmediately(jPnlTable.getBounds());
        }

        //next tab enabled, current disabled
        MainClass.setRestrict(pnlGroup, true, true);
        MainClass.setRestrict(pnlSort, false, true);
        fields = vFields;
        //columnNames = newAlias;
        //types = newTypes;
        tabSettings.setEnabledAt(4, false);
        tabSettings.setEnabledAt(5, true);
        tabSettings.setSelectedIndex(5);
    }//GEN-LAST:event_btnOKSortingActionPerformed

    @SuppressWarnings("unchecked")
    private void btnOKGroupingActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKGroupingActionPerformed
    {//GEN-HEADEREND:event_btnOKGroupingActionPerformed
        String strHaving = "";
        String strClearHaving = "";
        String strGroup = "";
        int pos = -1;

        //check the grouping function and modify the query according to them
        ArrayList vFields = fields;
        ArrayList vFieldsAlias = columnNames;
        ArrayList newFields = new ArrayList();
        ArrayList newAlias = new ArrayList();
        ArrayList newTypes = new ArrayList();
        int intFields = vFields.size();
        if (intFields > 0)
        {
            //for each field, verify whether it is linked to a grouping function or not
            for (int i = 0; i < intFields; i++)
            {
                String strGroupFunction = cboGroups[i].getSelectedItem().toString();
                String strField = vFields.get(i).toString();
                String strFieldAlias = vFieldsAlias.get(i).toString();
                if (strField.equals(""))
                {
                    strField = "ID";
                }
                if (strField.equals("ID"))
                {
                    strFieldAlias = bundle.getString("Index");
                }

                strGroupDate = "";
                strGroupValue = txtFieldValues[i].getText();
                int group = cboGroupOperations[i].getSelectedIndex();
                if (group != -1)
                {
                    strGroupOperation = cboGroupOperations[i].getSelectedItem().toString();
                }
                else
                {
                    strGroupOperation = "";
                    group = 99;
                }
                strGroupOperator = "";
                strGroupClearValue = "";
                int dataType = new Integer(String.valueOf(types.get(i))).intValue();
                int type = getType(dataType);
                getOperatorAndValue(type, group);


                //(case of no grouping function, will remove the field)

                //case of grouping
                if (strGroupFunction.equals(strGrouping))
                {
                    if (strGroup.equals(""))
                    {
                        strGroup = STR__GROUP_BY_ + strField;
                    }
                    else
                    {
                        strGroup = strGroup + ", " + strField;
                    }
                    newFields.add(vFields.get(i));
                    newAlias.add(vFieldsAlias.get(i));
                    newTypes.add(types.get(i));
                }
                //case of other functions
                else if (strGroupFunction.equals(strNumber))
                {
                    strField = "Count(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strNumber + strOf + strFieldAlias);
                    newTypes.add(DataBaseRecords.typeNumber);
                    sqlOrderBy = sqlOrderBy.replace(strField, "Count(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Count(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strSum))
                {
                    strField = "Sum(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strSum + strOf + strFieldAlias);
                    newTypes.add(DataBaseRecords.typeNumber);
                    sqlOrderBy = sqlOrderBy.replace(strField, "Sum(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Sum(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strAverage))
                {
                    strField = "Avg(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strAverage + strOf + strFieldAlias);
                    newTypes.add(DataBaseRecords.typeNumber);
                    sqlOrderBy = sqlOrderBy.replace(strField, "Avg(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Avg(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strMinimum))
                {
                    strField = "Min(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strMinimum + strOf + strFieldAlias);
                    newTypes.add(types.get(i));
                    sqlOrderBy = sqlOrderBy.replace(strField, "Min(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Min(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strMaximum))
                {
                    strField = "Max(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strMaximum + strOf + strFieldAlias);
                    newTypes.add(types.get(i));
                    sqlOrderBy = sqlOrderBy.replace(strField, "Max(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Max(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strFirst))
                {
                    strField = "First(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strFirst + strOf + strFieldAlias);
                    newTypes.add(types.get(i));
                    sqlOrderBy = sqlOrderBy.replace(strField, "First(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "First(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
                else if (strGroupFunction.equals(strLast))
                {
                    strField = "Last(" + strField + ")";
                    newFields.add(strField);
                    newAlias.add(strLast + strOf + strFieldAlias);
                    newTypes.add(types.get(i));
                    sqlOrderBy = sqlOrderBy.replace(strField, "Last(" + strField + ")");
                    if (cboGroupOperations[i].getSelectedIndex() > 0 && strGroupValue != null && !strGroupValue.equals(""))
                    {
                        if (strClearHaving.equals(""))
                        {
                            strClearHaving = "[" + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        else
                        {
                            strClearHaving = strClearHaving + bundle.getString("_AND_") + strFieldAlias + "]" + strGroupOperation + strGroupClearValue;
                        }
                        strHaving = strHaving + "Last(" + strField + ")" + strGroupOperator + strGroupDate + strGroupValue + strGroupDate + " AND ";
                    }
                }
            }
        }
        if (newFields.size() > 0)
        {
            fields = newFields;
            columnNames = newAlias;
        }
        else
        {
            fields = vFields;
            columnNames = vFieldsAlias;
        }
        types = newTypes;

        if (!strHaving.equals(""))
        {
            strHaving = STR__HAVING_ + strHaving;
        }

        //recreate the query
        if (fields.isEmpty())
        {
            fields.add("ID");
        }
        sqlString = queries.buildQuery(fields, columnNames, sqlFrom, sqlWhere, strGroup, sqlOrderBy, strHaving);
        rows = queries.getRows();
        sizes = queries.getSizes();

        if (!strClearHaving.equals(""))
        {
            if (!txtFilter.getText().equals(""))
            {
                txtFilter.setText(txtFilter.getText() + bundle.getString("AndHaving") + strClearHaving + ")");
            }
            else
            {
                txtFilter.setText(bundle.getString("Having") + strClearHaving + ")");
            }
        }

        //refresh the grid
        if (!sqlString.equals(""))
        {
            dgrQuery = new DataGrid(rows, columnNames, fields, sizes, jPnlTable, false, false, false, false, this, true);
            //this.paintAll(this.getGraphics());
            jPnlTable.paintImmediately(jPnlTable.getBounds());
        }

        //next tab enabled, current disabled
        MainClass.setRestrict(pnlGroup, false, true);
        MainClass.setRestrict(pnlDestination, true, true);
        tabSettings.setEnabledAt(5, false);
        tabSettings.setEnabledAt(6, true);
        tabSettings.setSelectedIndex(6);
    }//GEN-LAST:event_btnOKGroupingActionPerformed

    private void btnExportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnExportActionPerformed
    {//GEN-HEADEREND:event_btnExportActionPerformed
        /*
         * setCursor(new Cursor(Cursor.WAIT_CURSOR));
         *
         * HTMLStrings htmlStrings = new HTMLStrings(); DocForm docForm = new DocForm(); windowNB +=
         * 1; docForm.setTitle(bundle.getString("QueryResult") + " - " + windowNB); HTMLDocument doc
         * = (HTMLDocument) docForm.getDocument();
         *
         * //Header String sHtml = "<p style='background-color: #FFE1C3;' align='center'
         * width='75%'><b><font color='#C300FF' face='arial' size='5'>"; sHtml =
         * sHtml.concat(queryDescription.getName()); sHtml = sHtml.concat("</font></b>");
         *
         * htmlStrings.setCenter(false);
         *
         * if (!txtFilter.getText().equals("")) { //Filter String sFilter =
         * txtFilter.getText().replace("\n", "<br>"); sHtml =
         * sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", bundle.getString("Filter") + "
         * = " + sFilter)); }
         *
         * //Data ArrayList vFields = columnNames; //headers or aliases
         *
         * if (vFields != null) { //Captions String value; sHtml =
         * sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", "<table width='100%'
         * border='1' cellspacing='0' cellpadding='3'><tr>")); for (int j = 0; j < vFields.size();
         * j++) { value = vFields.get(j).toString(); sHtml =
         * sHtml.concat(htmlStrings.getHTMLOther2SB(value, 2)); } sHtml = sHtml.concat("</tr>");
         *
         * //Values for (int i = 0; i < rows.size(); i++) { sHtml = sHtml.concat("<tr>"); ArrayList
         * vr = (ArrayList) rows.get(i); for (int j = 0; j < vFields.size(); j++) { value =
         * String.valueOf(vr.get(j)); value = value.trim(); if (value.equals("null") ||
         * value.equals("")) { sHtml = sHtml.concat("<td>&nbsp;</td>"); } else { sHtml =
         * sHtml.concat(htmlStrings.getHTMLOther2S(value, 2)); } } sHtml = sHtml.concat("</tr>"); }
         * sHtml = sHtml.concat("</table>"); }
         *
         * Element firstElement = doc.getElement(doc.getDefaultRootElement(),
         * StyleConstants.NameAttribute, HTML.Tag.BODY); try { HTMLEditorKit.Parser parser = new
         * javax.swing.text.html.parser.ParserDelegator(); doc.setParser(parser); sHtml =
         * htmlStrings.processCR(sHtml); doc.setInnerHTML(firstElement, sHtml); } catch
         * (BadLocationException ex) { MainClass.setMessage(ex.getMessage()); } catch
         * (java.io.IOException ex) { MainClass.setMessage(ex.getMessage()); }
         *
         * docForm.resetUndo(); docForm.getTextPane().setSelectionStart(0);
         * docForm.getTextPane().setSelectionEnd(0); docForm.setVisible(true);
         * docForm.setExtendedState(MAXIMIZED_BOTH); setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
         *
         * //first tab enabled MainClass.setRestrict(pnlQueries, true, true);
         */
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        HTMLStrings htmlStrings = new HTMLStrings();
        String title = bundle.getString("QueryResult");
        HTMLDocument doc = new HTMLDocument();//(HTMLDocument) docForm.getDocument();

        //Header
        String sHtml = "<p style='background-color: #FFE1C3;' align='center' width='75%'><b><font color='#C300FF' face='arial' size='5'>";
        if (queryDescription == null)
            sHtml = sHtml.concat(savedQuery);
        else
            sHtml = sHtml.concat(queryDescription.getName());
        sHtml = sHtml.concat("</font></b>");

        htmlStrings.setCenter(false);

        if (!txtFilter.getText().equals(""))
        {
            //Filter
            String sFilter = txtFilter.getText().replace("\n", "<br>");
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", bundle.getString("Filter") + " =  " + sFilter));
        }

        //Data
        ArrayList vFields = columnNames;    //headers or aliases

        if (vFields != null)
        {
            //Captions
            String value;
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", "<table width='100%' border='1' cellspacing='0' cellpadding='3'><tr>"));
            for (int j = 0; j < vFields.size(); j++)
            {
                value = vFields.get(j).toString();
                sHtml = sHtml.concat(htmlStrings.getHTMLOther2SB(value, 2));
            }
            sHtml = sHtml.concat("</tr>");

            //Values
            for (int i = 0; i < rows.size(); i++)
            {
                sHtml = sHtml.concat("<tr>");
                ArrayList vr = (ArrayList) rows.get(i);
                for (int j = 0; j < vFields.size(); j++)
                {
                    value = String.valueOf(vr.get(j));
                    value = value.trim();
                    if (value.equals("null") || value.equals(""))
                    {
                        sHtml = sHtml.concat("<td>&nbsp;</td>");
                    }
                    else
                    {
                        sHtml = sHtml.concat(htmlStrings.getHTMLOther2S(value, 2));
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
            sHtml = sHtml.concat("</table>");
        }

        Element firstElement = doc.getElement(doc.getDefaultRootElement(), StyleConstants.NameAttribute, HTML.Tag.BODY);
        try
        {
            HTMLEditorKit.Parser parser = new javax.swing.text.html.parser.ParserDelegator();
            doc.setParser(parser);
            sHtml = htmlStrings.processCR(sHtml);
            doc.setInnerHTML(firstElement, sHtml);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (java.io.IOException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        DialogDoc docForm = new DialogDoc(this, true, doc, title);

        //docForm.setVisible(true);
        //docForm.setExtendedState(MAXIMIZED_BOTH);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

        //first tab enabled
        MainClass.setRestrict(pnlQueries, true, true);
    }//GEN-LAST:event_btnExportActionPerformed

    private void btnSaveReportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveReportActionPerformed
    {//GEN-HEADEREND:event_btnSaveReportActionPerformed
        String result = JOptionPane.showInputDialog(bundle.getString("EnterReportName"));
        if (result == null || result.equals(""))
            return;
        starLoginManager.updateDataBase("INSERT INTO rapport(NOM,REQUETE) VALUES('" + MainClass.replaceQuotes(result) + "','" + MainClass.replaceQuotes(sqlString) + "')");
        //getSavedQueries();
    }//GEN-LAST:event_btnSaveReportActionPerformed

    private void btnOKSelectActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKSelectActionPerformed
    {//GEN-HEADEREND:event_btnOKSelectActionPerformed
        /*tabSettings.setEnabledAt(6, false);
        tabSettings.setEnabledAt(1, true);
        tabSettings.setEnabledAt(0, true);
        tabSettings.setSelectedIndex(0);
        MainClass.setRestrict(pnlDestination, false, true);
        MainClass.setRestrict(pnlQueries, true, true);
        MainClass.setRestrict(pnlSavedQueries, true, true);*/
        tabSettings.setEnabledAt(6, false);
        tabSettings.setEnabledAt(1, true);
        tabSettings.setEnabledAt(0, true);
        //tabSettings.setSelectedIndex(0);
        MainClass.setRestrict(pnlDestination, false, true);
        MainClass.setRestrict(pnlQueries, true, true);
        MainClass.setRestrict(pnlSavedQueries, true, true);
        Records records = starLoginManager.getRecords("SELECT ID FROM events WHERE ID<0", "events");
        dgrQuery = new DataGrid(records.getRecords(), records.getHeaders(), records.getFields(), records.getSizes(), jPnlTable, false, false, false, false, this, false);
        resetTab(-1);
    }//GEN-LAST:event_btnOKSelectActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddFilter;
    private javax.swing.JButton btnEraseFilter;
    private javax.swing.JButton btnExport;
    private javax.swing.JButton btnOKFilter;
    private javax.swing.JButton btnOKGrouping;
    private javax.swing.JButton btnOKSelect;
    private javax.swing.JButton btnOKSelection;
    private javax.swing.JButton btnOKSorting;
    private javax.swing.JButton btnSaveReport;
    private javax.swing.JButton btnSelectAll;
    private javax.swing.JButton btnUnselectAll;
    private javax.swing.JComboBox cboAndOr;
    private javax.swing.JComboBox cboDataField;
    private javax.swing.JComboBox cboDataField1;
    private javax.swing.JComboBox cboDataField2;
    private javax.swing.JComboBox cboDataField3;
    private javax.swing.JComboBox cboDataField4;
    private javax.swing.JComboBox cboLeftBracket;
    private javax.swing.JComboBox cboOperation;
    private javax.swing.JComboBox cboRightBracket;
    private javax.swing.JComboBox cboSorting1;
    private javax.swing.JComboBox cboSorting2;
    private javax.swing.JComboBox cboSorting3;
    private javax.swing.JComboBox cboSorting4;
    private javax.swing.JComboBox cboValue;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelGroup;
    private javax.swing.JPanel jPnlTable;
    private javax.swing.JScrollPane jScrollFields;
    private javax.swing.JScrollPane jScrollGroup;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollSavedQueries;
    private javax.swing.JScrollPane jScrollSource;
    private javax.swing.JLabel lblFieldsCaptions1;
    private javax.swing.JLabel lblFieldsCaptions10;
    private javax.swing.JLabel lblFieldsCaptions11;
    private javax.swing.JLabel lblFieldsCaptions12;
    private javax.swing.JLabel lblFieldsCaptions13;
    private javax.swing.JLabel lblFieldsCaptions14;
    private javax.swing.JLabel lblFieldsCaptions15;
    private javax.swing.JLabel lblFieldsCaptions2;
    private javax.swing.JLabel lblFieldsCaptions3;
    private javax.swing.JLabel lblFieldsCaptions4;
    private javax.swing.JLabel lblFieldsCaptions5;
    private javax.swing.JLabel lblFieldsCaptions6;
    private javax.swing.JLabel lblFieldsCaptions7;
    private javax.swing.JLabel lblFieldsCaptions8;
    private javax.swing.JLabel lblFieldsCaptions9;
    private javax.swing.JList lstQueries;
    private javax.swing.JList lstSavedQueries;
    private javax.swing.JPanel pnlButtonFields;
    private javax.swing.JPanel pnlDestination;
    private javax.swing.JPanel pnlFields;
    private javax.swing.JPanel pnlFieldsGroup;
    private javax.swing.JPanel pnlFieldsSelection;
    private javax.swing.JPanel pnlFilter;
    private javax.swing.JPanel pnlFilter2;
    private javax.swing.JPanel pnlFilter3;
    private javax.swing.JPanel pnlFilter4;
    private javax.swing.JPanel pnlFilter5;
    private javax.swing.JPanel pnlFilter6;
    private javax.swing.JPanel pnlFilter7;
    private javax.swing.JPanel pnlGroup;
    private javax.swing.JPanel pnlQueries;
    private javax.swing.JPanel pnlSavedQueries;
    private javax.swing.JPanel pnlSort;
    private javax.swing.JPanel pnlSort2;
    private javax.swing.JPanel pnlSort3;
    private javax.swing.JPanel pnlSort4;
    private javax.swing.JPanel pnlSort5;
    private javax.swing.JPanel pnlSort6;
    private javax.swing.JTabbedPane tabSettings;
    private javax.swing.JTextArea txtFilter;
    // End of variables declaration//GEN-END:variables
}
