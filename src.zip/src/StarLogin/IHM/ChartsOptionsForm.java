package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTAspectKind;
import StarLogin.IHM.components.KeyType.KTUnsignedDecimal;
import StarLogin.IHM.components.KeyType.KTUnsignedInteger;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javax.swing.*;

/**
 *
 * @author Francois DESCHAMPS
 * @version 7.0.0
 */
public class ChartsOptionsForm extends javax.swing.JFrame
{
    private Color color;
    private int kc; //key code
    private byte currentSelectedChart = ChartKind.all;
    private Color bgEdit = MainClass.options.getEditColor();
    private Color bgNormal = MainClass.options.getNormalColor();
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Places places;
    private Options options;
    private Option option;
    private String optionID;
    private Parts parts;
    private Stars stars;
    private Events events;
    private int optionRow;
    private int nbOfRows;
    private int saveOptionRow;
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private boolean bolSetting = true;
    private boolean bolDeleting = false;
    private String chartReturnPlaceID;
    private String chartCyclePlaceID;
    private String defaultEvent;
    private String defaultPlace;
    private byte coordSys;
    private byte houseSys;
    private byte otherPointType;
    private String chartReturnPlanet;
    private String chartCyclePlanet1;
    private String chartCyclePlanet2;
    private String chartCompositeNB;
    private String chartHarmonicNB;
    private String chartDir1SpaceKind;
    private String chartDir2SpaceKind;
    private String chartDirSSpaceKind;
    private String otherPointName;
    private String configurationName;
    private int zodiacSize;
    private int signSize;
    private int planetSize;
    private int characterSize;
    private String typeAspect0;
    private String typeAspect1;
    private String typeAspect2;
    private String typeAspect3;
    private String typeAspect4;
    private String typeAspect5;
    private String typeAspect6;
    private String typeAspect7;
    private String typeAspect8;
    private String typeAspect9;
    private String typeAspect10;
    private String typeAspect11;
    private String typeAspect12;
    private String typeAspect13;
    private String typeAspect14;
    private String typeAspect15;
    private String typeAspect16;
    private String typeAspect17;
    private String otherAspectName;
    private String chartKinds;
    private Color sunColor;
    private Color moonColor;
    private Color mercuryColor;
    private Color venusColor;
    private Color marsColor;
    private Color jupiterColor;
    private Color saturnColor;
    private Color uranusColor;
    private Color neptuneColor;
    private Color plutoColor;
    private Color gaiaColor;
    private Color nodesColor;
    private Color cuspsColor;
    private Color asteroidsColor;
    private Color vulcanColor;
    private Color variousColor;
    private Color fireColor;
    private Color earthColor;
    private Color airColor;
    private Color waterColor;
    private Color neutralColor;
    private Color dynamicColor;
    private Color harmonicColor;
    private Color colorAspect0;
    private Color colorAspect1;
    private Color colorAspect2;
    private Color colorAspect3;
    private Color colorAspect4;
    private Color colorAspect5;
    private Color colorAspect6;
    private Color colorAspect7;
    private Color colorAspect8;
    private Color colorAspect9;
    private Color colorAspect10;
    private Color colorAspect11;
    private Color colorAspect12;
    private Color colorAspect13;
    private Color colorAspect14;
    private Color colorAspect15;
    private Color colorAspect16;
    private Color colorAspect17;
    private Color colorBackground;
    private Color colorForeground;
    private Color colorLabelsBackground;
    private Color colorLabelsForeground;
    private Color colorTextZonesBackground;
    private Color colorTextZonesForeground;
    private Color colorButtonsBackground;
    private Color colorButtonsForeground;
    private boolean defaultConfiguration;
    private boolean shownSun;
    private boolean shownMoon;
    private boolean shownMercury;
    private boolean shownVenus;
    private boolean shownMars;
    private boolean shownJupiter;
    private boolean shownSaturn;
    private boolean shownUranus;
    private boolean shownNeptune;
    private boolean shownPluto;
    private boolean shownGaia;
    private boolean shownNorthNode;
    private boolean shownLilith;
    private boolean shownEast;
    private boolean shownZenith;
    private boolean shownVertex;
    private boolean shownVulcan;
    private boolean shownOtherPoint;
    private boolean shownCeres;
    private boolean shownPallas;
    private boolean shownJuno;
    private boolean shownVesta;
    private boolean shownChiron;
    private boolean trueLilith;
    private boolean coloredAspects;
    private boolean housesCoords;
    private boolean signsNames;
    private boolean leftAsct;
    private boolean symbolAspects;
    private boolean viewStars;
    private boolean viewAsteroids;
    private boolean viewCoordinates;
    private boolean viewStraightLines;
    private boolean viewHouses;
    private boolean viewConstellations;
    private boolean viewShadedLines;
    private boolean viewAspects;
    private boolean viewBarycenter;
    private boolean horizon;
    private boolean aspectsSun;
    private boolean aspectsMoon;
    private boolean aspectsMercury;
    private boolean aspectsVenus;
    private boolean aspectsMars;
    private boolean aspectsJupiter;
    private boolean aspectsSaturn;
    private boolean aspectsUranus;
    private boolean aspectsNeptune;
    private boolean aspectsPluto;
    private boolean aspectsGaia;
    private boolean aspectsNorthNode;
    private boolean aspectsLilith;
    private boolean aspectsEast;
    private boolean aspectsZenith;
    private boolean aspectsVertex;
    private boolean aspectsVulcan;
    private boolean aspectsOtherPoint;
    private boolean aspectsCeres;
    private boolean aspectsPallas;
    private boolean aspectsJuno;
    private boolean aspectsVesta;
    private boolean aspectsChiron;
    private boolean aspectsAS;
    private boolean aspectsMC;
    private boolean shownAspect0;
    private boolean shownAspect1;
    private boolean shownAspect2;
    private boolean shownAspect3;
    private boolean shownAspect4;
    private boolean shownAspect5;
    private boolean shownAspect6;
    private boolean shownAspect7;
    private boolean shownAspect8;
    private boolean shownAspect9;
    private boolean shownAspect10;
    private boolean shownAspect11;
    private boolean shownAspect12;
    private boolean shownAspect13;
    private boolean shownAspect14;
    private boolean shownAspect15;
    private boolean shownAspect16;
    private boolean shownAspect17;
    private boolean chartSelectSingle;
    private boolean chartReturnPrecess;
    private String limitMag;
    private String orbLightLight;
    private String orbLightTell;
    private String orbLightOtherInd;
    private String orbLightColl;
    private String orbLightVirtMax;
    private String orbLightVirtMin;
    private String orbTellTell;
    private String orbTellOtherInd;
    private String orbTellColl;
    private String orbTellVirtMax;
    private String orbTellVirtMin;
    private String orbOtherIndOtherInd;
    private String orbOtherIndColl;
    private String orbOtherIndVirtMax;
    private String orbOtherIndVirtMin;
    private String orbCollColl;
    private String orbCollVirtMax;
    private String orbCollVirtMin;
    private String orbVirtMaxVirtMax;
    private String orbVirtMaxVirtMin;
    private String orbVirtMinVirtMin;
    private String divMin;
    private String divConjuntion;
    private String divSextil;
    private String divSquare;
    private String divTrine;
    private String divOpposition;
    private String otherAspectValue;
    private String chartDir1Corresp;
    private String chartDir2Corresp;
    private String chartDirSCorresp;
    private String chartDir1Degree;
    private String chartDir2Day;
    private String chartDirSDegree;
    private boolean singleWeight;
    private ResourceBundle bundle = MainClass.bundle;
    private JFrame parentForm;

    /**
     * Creates new form ChartChoiceForm
     */
    public ChartsOptionsForm(JFrame parent)
    {
        initComponents();
        setPreferredSize(new java.awt.Dimension(1020, 730));

        parentForm = parent;
        //jPanel55.setVisible(false);
        tabSettings.setTitleAt(0, bundle.getString("ChartKind"));
        tabSettings.setTitleAt(1, bundle.getString("CoordinatesSystem"));
        tabSettings.setTitleAt(2, bundle.getString("HousesSystem"));
        tabSettings.setTitleAt(3, bundle.getString("ChartLook"));
        tabSettings.setTitleAt(4, bundle.getString("Planets"));
        tabSettings.setTitleAt(5, bundle.getString("Aspects"));
        tabSettings.setTitleAt(6, bundle.getString("Orbs"));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        //this.setExtendedState(MAXIMIZED_BOTH);
        pnlOtherPoint.setVisible(false);
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);

        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/choix_cartes.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        option = MainClass.getCurrentOption();

        //initialize data
        initData(option.getId());
        resetColors();
        setNormalMode();
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    private int askToSave()
    {
        int result = JOptionPane.NO_OPTION;
        
        if (bolEditing||bolAdding)
        {
            if (!configurationName.equals(""))
            {
                //if (bClosing)
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                    result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("ConfigurationName").concat(" : ").concat(configurationName),JOptionPane.YES_NO_OPTION);
                else
                    result = JOptionPane.YES_OPTION;
                //else
                //    result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingEvent"),bundle.getString("Event").concat(" : ").concat(nomEvent),JOptionPane.YES_NO_OPTION);
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }

    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            if (removeEmptyFields() == true)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                return false;
            }
            else
            {
                //update data
                setTextToData();
                option.setConfigurationName(configurationName);
                option.setSunColor(sunColor);
                option.setMoonColor(moonColor);
                option.setMercuryColor(mercuryColor);
                option.setVenusColor(venusColor);
                option.setMarsColor(marsColor);
                option.setJupiterColor(jupiterColor);
                option.setSaturnColor(saturnColor);
                option.setUranusColor(uranusColor);
                option.setNeptuneColor(neptuneColor);
                option.setPlutoColor(plutoColor);
                option.setGaiaColor(gaiaColor);
                option.setNodesColor(nodesColor);
                option.setCuspsColor(cuspsColor);
                option.setAsteroidsColor(asteroidsColor);
                option.setVulcanColor(vulcanColor);
                option.setVariousColor(variousColor);
                option.setFireColor(fireColor);
                option.setEarthColor(earthColor);
                option.setAirColor(airColor);
                option.setWaterColor(waterColor);
                option.setNeutralColor(neutralColor);
                option.setDynamicColor(dynamicColor);
                option.setHarmonicColor(harmonicColor);
                option.setZodiacSize(zodiacSize);
                option.setSignSize(signSize);
                option.setPlanetSize(planetSize);
                option.setCharacterSize(characterSize);
                option.setDefaultConfiguration(defaultConfiguration);
                option.setDefaultEvent(defaultEvent);
                option.setDefaultPlace(defaultPlace);
                option.setShownSun(shownSun);
                option.setShownMoon(shownMoon);
                option.setShownMercury(shownMercury);
                option.setShownVenus(shownVenus);
                option.setShownMars(shownMars);
                option.setShownJupiter(shownJupiter);
                option.setShownSaturn(shownSaturn);
                option.setShownUranus(shownUranus);
                option.setShownNeptune(shownNeptune);
                option.setShownPluto(shownPluto);
                option.setShownGaia(shownGaia);
                option.setShownNorthNode(shownNorthNode);
                option.setShownLilith(shownLilith);
                option.setShownEast(shownEast);
                option.setShownZenith(shownZenith);
                option.setShownVertex(shownVertex);
                option.setShownVulcan(shownVulcan);
                option.setShownOtherPoint(shownOtherPoint);
                option.setShownCeres(shownCeres);
                option.setShownPallas(shownPallas);
                option.setShownJuno(shownJuno);
                option.setShownVesta(shownVesta);
                option.setShownChiron(shownChiron);
                option.setTrueLilith(trueLilith);
                option.setOtherPointType(otherPointType);
                option.setOtherPointName(otherPointName);
                option.setColoredAspects(coloredAspects);
                option.setCoordSys(coordSys);
                option.setHouseSys(houseSys);
                option.setHousesCoords(housesCoords);
                option.setSignsNames(signsNames);
                option.setLeftAsct(leftAsct);
                option.setLimitMag(limitMag);
                option.setSymbolAspects(symbolAspects);
                option.setViewStars(viewStars);
                option.setViewAsteroids(viewAsteroids);
                option.setViewCoordinates(viewCoordinates);
                option.setViewStraightLines(viewStraightLines);
                option.setViewHouses(viewHouses);
                option.setViewConstellations(viewConstellations);
                option.setViewShadedLines(viewShadedLines);
                option.setViewAspects(viewAspects);
                option.setViewBarycenter(viewBarycenter);
                option.setHorizon(horizon);
                option.setAspectsSun(aspectsSun);
                option.setAspectsMoon(aspectsMoon);
                option.setAspectsMercury(aspectsMercury);
                option.setAspectsVenus(aspectsVenus);
                option.setAspectsMars(aspectsMars);
                option.setAspectsJupiter(aspectsJupiter);
                option.setAspectsSaturn(aspectsSaturn);
                option.setAspectsUranus(aspectsUranus);
                option.setAspectsNeptune(aspectsNeptune);
                option.setAspectsPluto(aspectsPluto);
                option.setAspectsGaia(aspectsGaia);
                option.setAspectsNorthNode(aspectsNorthNode);
                option.setAspectsLilith(aspectsLilith);
                option.setAspectsEast(aspectsEast);
                option.setAspectsZenith(aspectsZenith);
                option.setAspectsVertex(aspectsVertex);
                option.setAspectsVulcan(aspectsVulcan);
                option.setAspectsOtherPoint(aspectsOtherPoint);
                option.setAspectsCeres(aspectsCeres);
                option.setAspectsPallas(aspectsPallas);
                option.setAspectsJuno(aspectsJuno);
                option.setAspectsVesta(aspectsVesta);
                option.setAspectsChiron(aspectsChiron);
                option.setAspectsAS(aspectsAS);
                option.setAspectsMC(aspectsMC);
                option.setShownAspect0(shownAspect0);
                option.setShownAspect1(shownAspect1);
                option.setShownAspect2(shownAspect2);
                option.setShownAspect3(shownAspect3);
                option.setShownAspect4(shownAspect4);
                option.setShownAspect5(shownAspect5);
                option.setShownAspect6(shownAspect6);
                option.setShownAspect7(shownAspect7);
                option.setShownAspect8(shownAspect8);
                option.setShownAspect9(shownAspect9);
                option.setShownAspect10(shownAspect10);
                option.setShownAspect11(shownAspect11);
                option.setShownAspect12(shownAspect12);
                option.setShownAspect13(shownAspect13);
                option.setShownAspect14(shownAspect14);
                option.setShownAspect15(shownAspect15);
                option.setShownAspect16(shownAspect16);
                option.setShownAspect17(shownAspect17);
                option.setColorAspect0(colorAspect0);
                option.setColorAspect1(colorAspect1);
                option.setColorAspect2(colorAspect2);
                option.setColorAspect3(colorAspect3);
                option.setColorAspect4(colorAspect4);
                option.setColorAspect5(colorAspect5);
                option.setColorAspect6(colorAspect6);
                option.setColorAspect7(colorAspect7);
                option.setColorAspect8(colorAspect8);
                option.setColorAspect9(colorAspect9);
                option.setColorAspect10(colorAspect10);
                option.setColorAspect11(colorAspect11);
                option.setColorAspect12(colorAspect12);
                option.setColorAspect13(colorAspect13);
                option.setColorAspect14(colorAspect14);
                option.setColorAspect15(colorAspect15);
                option.setColorAspect16(colorAspect16);
                option.setColorAspect17(colorAspect17);
                option.setColorBackground(colorBackground);
                option.setColorForeground(colorForeground);
                option.setColorLabelsBackground(colorLabelsBackground);
                option.setColorLabelsForeground(colorLabelsForeground);
                option.setColorTextZonesBackground(colorTextZonesBackground);
                option.setColorTextZonesForeground(colorTextZonesForeground);
                option.setColorButtonsBackground(colorButtonsBackground);
                option.setColorButtonsForeground(colorButtonsForeground);
                option.setTypeAspect0(typeAspect0);
                option.setTypeAspect1(typeAspect1);
                option.setTypeAspect2(typeAspect2);
                option.setTypeAspect3(typeAspect3);
                option.setTypeAspect4(typeAspect4);
                option.setTypeAspect5(typeAspect5);
                option.setTypeAspect6(typeAspect6);
                option.setTypeAspect7(typeAspect7);
                option.setTypeAspect8(typeAspect8);
                option.setTypeAspect9(typeAspect9);
                option.setTypeAspect10(typeAspect10);
                option.setTypeAspect11(typeAspect11);
                option.setTypeAspect12(typeAspect12);
                option.setTypeAspect13(typeAspect13);
                option.setTypeAspect14(typeAspect14);
                option.setTypeAspect15(typeAspect15);
                option.setTypeAspect16(typeAspect16);
                option.setTypeAspect17(typeAspect17);
                option.setOtherAspectValue(otherAspectValue);
                option.setOtherAspectName(otherAspectName);
                option.setOrbLightLight(orbLightLight);
                option.setOrbLightTell(orbLightTell);
                option.setOrbLightOtherInd(orbLightOtherInd);
                option.setOrbLightColl(orbLightColl);
                option.setOrbLightVirtMax(orbLightVirtMax);
                option.setOrbLightVirtMin(orbLightVirtMin);
                option.setOrbTellTell(orbTellTell);
                option.setOrbTellOtherInd(orbTellOtherInd);
                option.setOrbTellColl(orbTellColl);
                option.setOrbTellVirtMax(orbTellVirtMax);
                option.setOrbTellVirtMin(orbTellVirtMin);
                option.setOrbOtherIndOtherInd(orbOtherIndOtherInd);
                option.setOrbOtherIndColl(orbOtherIndColl);
                option.setOrbOtherIndVirtMax(orbOtherIndVirtMax);
                option.setOrbOtherIndVirtMin(orbOtherIndVirtMin);
                option.setOrbCollColl(orbCollColl);
                option.setOrbCollVirtMax(orbCollVirtMax);
                option.setOrbCollVirtMin(orbCollVirtMin);
                option.setOrbVirtMaxVirtMax(orbVirtMaxVirtMax);
                option.setOrbVirtMaxVirtMin(orbVirtMaxVirtMin);
                option.setOrbVirtMinVirtMin(orbVirtMinVirtMin);
                option.setDivMin(divMin);
                option.setDivConjuntion(divConjuntion);
                option.setDivSextil(divSextil);
                option.setDivSquare(divSquare);
                option.setDivTrine(divTrine);
                option.setDivOpposition(divOpposition);
                option.setChartSelectSingle(chartSelectSingle);
                option.setChartKinds(chartKinds);
                option.setChartDir1Corresp(chartDir1Corresp);
                option.setChartDir2Corresp(chartDir2Corresp);
                option.setChartDirSCorresp(chartDirSCorresp);
                option.setChartDir1Degree(chartDir1Degree);
                option.setChartDir2Day(chartDir2Day);
                option.setChartDirSDegree(chartDirSDegree);
                option.setChartDir1SpaceKind(chartDir1SpaceKind);
                option.setChartDir2SpaceKind(chartDir2SpaceKind);
                option.setChartDirSSpaceKind(chartDirSSpaceKind);
                option.setChartReturnPrecess(chartReturnPrecess);
                option.setChartReturnPlaceID(chartReturnPlaceID);
                option.setChartCyclePlaceID(chartCyclePlaceID);
                option.setChartReturnPlanet(chartReturnPlanet);
                option.setChartCyclePlanet1(chartCyclePlanet1);
                option.setChartCyclePlanet2(chartCyclePlanet2);
                option.setChartCompositeNB(chartCompositeNB);
                option.setChartHarmonicNB(chartHarmonicNB);
                option.setSingleWeight(singleWeight);
                option.setAdding(bolAdding);
                starLoginManager.setOption(option);

                if (bolAdding == true)
                {
                    saveOptionRow = option.getRow();
                }
                bolEditing = false;
                bolAdding = false;
                bolDeleting = false;
                refreshRecord();
                setNormalMode();
            }
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    private void setEditMode()
    {
        pnlControlBar.setBackground(bgEdit);
        txtCounter.setEditable(false);
    }

    private void setNormalMode()
    {
        pnlControlBar.setBackground(bgNormal);
        txtCounter.setEditable(true);
        cboDefaultPlace.setEditable(false);
        cboPlaceCycle.setEditable(false);
        cboPlaceReturn.setEditable(false);
        cboDefaultEvent.setEditable(false);
    }

    private void addRecord()
    {
        if (askToSave() == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveOptionRow = optionRow;
        initData("-1");
        setFieldsLocked(true);
        bolEditing = false;
        bolAdding = true;
        setEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void refreshRecord()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            //show the record data
            setControls();
            showOption(saveOptionRow);
            resetColors();
        }
    }

    private void removeRec()
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            if (nbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeOption(option);
                    options = starLoginManager.getOptions();

                    setControls();
                    if (optionRow > 1)
                    {
                        showOption(optionRow - 1);
                        resetColors();
                    }
                    else
                    {
                        showOption(optionRow + 1);
                        resetColors();
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private void setRectrict(Container container, boolean enabled)
    {
        Component components[] = container.getComponents();
        for (int i = 0; i < container.getComponentCount(); i++)
        {
            Component component = components[i];
            if (component instanceof JComboBox || component instanceof JFormattedTextField || component instanceof JCheckBox || component instanceof JTextArea || component instanceof JTextPane || component instanceof JTextField || component instanceof JList)
            {
                if (component instanceof JComboBox)
                {
                    ((JComboBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JFormattedTextField)
                {
                    ((JFormattedTextField) (JComponent) (Container) component).setEditable(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JCheckBox)
                {
                    ((JCheckBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JTextArea)
                {
                    ((JTextArea) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextArea) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextArea) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextPane)
                {
                    ((JTextPane) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextPane) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextPane) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextField)
                {
                    ((JTextField) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JList)
                {
                    ((JList) (JComponent) (Container) component).setEnabled(enabled);
                }
            }
            Container subContainer = (Container) component;
            setRectrict(subContainer, enabled);
        }
    }

    private void setFieldsLocked(boolean enabled)
    {
        setRectrict(pnlAspectColorChoice, enabled);
        setRectrict(pnlAspects, enabled);
        setRectrict(pnlChartColorChoice, enabled);
        setRectrict(pnlChartKind, enabled);
        setRectrict(pnlChartLook, enabled);
        setRectrict(pnlComposite, enabled);
        setRectrict(pnlCoordSystem, enabled);
        setRectrict(pnlCycle, enabled);
        setRectrict(pnlHarmonic, enabled);
        setRectrict(pnlHouseSystem, enabled);
        setRectrict(pnlLocal, enabled);
        setRectrict(pnlOrbs, enabled);
        setRectrict(pnlOtherPoint, enabled);
        setRectrict(pnlOtherPtPart, enabled);
        setRectrict(pnlOtherPtStar, enabled);
        setRectrict(pnlPlanets, enabled);
        setRectrict(pnlPrimaryDir, enabled);
        setRectrict(pnlRevolution, enabled);
        setRectrict(pnlSecondaryDir, enabled);
        setRectrict(pnlSymbolicDir, enabled);
        setRectrict(pnlWindows, enabled);
        cboDefaultPlace.setEnabled(enabled);
        cboDefaultEvent.setEnabled(enabled);
    }

    public void setColor(Color color)
    {
        this.color = color;
    }

    public Color getColor()
    {
        return color;
    }

    private void initData(String strID)
    {
        setControls();
        showOption(strID);
        if ((strID.equals("")) || (strID.equals("-1")))
        {
            nbOfRows += 1;
            bolAdding = true;
            optionRow += 1;
        }
    }

    private void showOption(int row)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        optionID = options.getIDFromRow(row);
        option = starLoginManager.getOption(optionID);
        optionRow = row;
        saveOptionRow = optionRow;
        nbOfRows = option.getRowNB();
        chartReturnPlaceID = option.getChartReturnPlaceID();
        chartCyclePlaceID = option.getChartCyclePlaceID();
        defaultEvent = option.getDefaultEvent();
        defaultPlace = option.getDefaultPlace();
        coordSys = option.getCoordSys();
        houseSys = option.getHouseSys();
        otherPointType = option.getOtherPointType();
        chartReturnPlanet = option.getChartReturnPlanet();
        chartCyclePlanet1 = option.getChartCyclePlanet1();
        chartCyclePlanet2 = option.getChartCyclePlanet2();
        chartCompositeNB = option.getChartCompositeNB();
        chartHarmonicNB = option.getChartHarmonicNB();
        chartDir1SpaceKind = option.getChartDir1SpaceKind();
        chartDir2SpaceKind = option.getChartDir2SpaceKind();
        chartDirSSpaceKind = option.getChartDirSSpaceKind();
        otherPointName = option.getOtherPointName();
        configurationName = option.getConfigurationName();
        zodiacSize = option.getZodiacSize();
        signSize = option.getSignSize();
        planetSize = option.getPlanetSize();
        characterSize = option.getCharacterSize();
        typeAspect0 = option.getTypeAspect0();
        typeAspect1 = option.getTypeAspect1();
        typeAspect2 = option.getTypeAspect2();
        typeAspect3 = option.getTypeAspect3();
        typeAspect4 = option.getTypeAspect4();
        typeAspect5 = option.getTypeAspect5();
        typeAspect6 = option.getTypeAspect6();
        typeAspect7 = option.getTypeAspect7();
        typeAspect8 = option.getTypeAspect8();
        typeAspect9 = option.getTypeAspect9();
        typeAspect10 = option.getTypeAspect10();
        typeAspect11 = option.getTypeAspect11();
        typeAspect12 = option.getTypeAspect12();
        typeAspect13 = option.getTypeAspect13();
        typeAspect14 = option.getTypeAspect14();
        typeAspect15 = option.getTypeAspect15();
        typeAspect16 = option.getTypeAspect16();
        typeAspect17 = option.getTypeAspect17();
        otherAspectName = option.getOtherAspectName();
        chartKinds = option.getChartKinds();
        sunColor = option.getSunColor();
        moonColor = option.getMoonColor();
        mercuryColor = option.getMercuryColor();
        venusColor = option.getVenusColor();
        marsColor = option.getMarsColor();
        jupiterColor = option.getJupiterColor();
        saturnColor = option.getSaturnColor();
        uranusColor = option.getUranusColor();
        neptuneColor = option.getNeptuneColor();
        plutoColor = option.getPlutoColor();
        gaiaColor = option.getGaiaColor();
        nodesColor = option.getNodesColor();
        cuspsColor = option.getCuspsColor();
        asteroidsColor = option.getAsteroidsColor();
        vulcanColor = option.getVulcanColor();
        variousColor = option.getVariousColor();
        fireColor = option.getFireColor();
        earthColor = option.getEarthColor();
        airColor = option.getAirColor();
        waterColor = option.getWaterColor();
        neutralColor = option.getNeutralColor();
        dynamicColor = option.getDynamicColor();
        harmonicColor = option.getHarmonicColor();
        colorAspect0 = option.getColorAspect0();
        colorAspect1 = option.getColorAspect1();
        colorAspect2 = option.getColorAspect2();
        colorAspect3 = option.getColorAspect3();
        colorAspect4 = option.getColorAspect4();
        colorAspect5 = option.getColorAspect5();
        colorAspect6 = option.getColorAspect6();
        colorAspect7 = option.getColorAspect7();
        colorAspect8 = option.getColorAspect8();
        colorAspect9 = option.getColorAspect9();
        colorAspect10 = option.getColorAspect10();
        colorAspect11 = option.getColorAspect11();
        colorAspect12 = option.getColorAspect12();
        colorAspect13 = option.getColorAspect13();
        colorAspect14 = option.getColorAspect14();
        colorAspect15 = option.getColorAspect15();
        colorAspect16 = option.getColorAspect16();
        colorAspect17 = option.getColorAspect17();
        colorBackground = option.getColorBackground();
        colorForeground = option.getColorForeground();
        colorLabelsBackground = option.getColorLabelsBackground();
        colorLabelsForeground = option.getColorLabelsForeground();
        colorTextZonesBackground = option.getColorTextZonesBackground();
        colorTextZonesForeground = option.getColorTextZonesForeground();
        colorButtonsBackground = option.getColorButtonsBackground();
        colorButtonsForeground = option.getColorButtonsForeground();
        defaultConfiguration = option.getDefaultConfiguration();
        shownSun = option.getShownSun();
        shownMoon = option.getShownMoon();
        shownMercury = option.getShownMercury();
        shownVenus = option.getShownVenus();
        shownMars = option.getShownMars();
        shownJupiter = option.getShownJupiter();
        shownSaturn = option.getShownSaturn();
        shownUranus = option.getShownUranus();
        shownNeptune = option.getShownNeptune();
        shownPluto = option.getShownPluto();
        shownGaia = option.getShownGaia();
        shownNorthNode = option.getShownNorthNode();
        shownLilith = option.getShownLilith();
        shownEast = option.getShownEast();
        shownZenith = option.getShownZenith();
        shownVertex = option.getShownVertex();
        shownVulcan = option.getShownVulcan();
        shownOtherPoint = option.getShownOtherPoint();
        shownCeres = option.getShownCeres();
        shownPallas = option.getShownPallas();
        shownJuno = option.getShownJuno();
        shownVesta = option.getShownVesta();
        shownChiron = option.getShownChiron();
        trueLilith = option.getTrueLilith();
        coloredAspects = option.getColoredAspects();
        housesCoords = option.getHousesCoords();
        signsNames = option.getSignsNames();
        leftAsct = option.getLeftAsct();
        symbolAspects = option.getSymbolAspects();
        viewStars = option.getViewStars();
        viewAsteroids = option.getViewAsteroids();
        viewCoordinates = option.getViewCoordinates();
        viewStraightLines = option.getViewStraightLines();
        viewHouses = option.getViewHouses();
        viewConstellations = option.getViewConstellations();
        viewShadedLines = option.getViewShadedLines();
        viewAspects = option.getViewAspects();
        viewBarycenter = option.getViewBarycenter();
        horizon = option.getHorizon();
        aspectsSun = option.getAspectsSun();
        aspectsMoon = option.getAspectsMoon();
        aspectsMercury = option.getAspectsMercury();
        aspectsVenus = option.getAspectsVenus();
        aspectsMars = option.getAspectsMars();
        aspectsJupiter = option.getAspectsJupiter();
        aspectsSaturn = option.getAspectsSaturn();
        aspectsUranus = option.getAspectsUranus();
        aspectsNeptune = option.getAspectsNeptune();
        aspectsPluto = option.getAspectsPluto();
        aspectsGaia = option.getAspectsGaia();
        aspectsNorthNode = option.getAspectsNorthNode();
        aspectsLilith = option.getAspectsLilith();
        aspectsEast = option.getAspectsEast();
        aspectsZenith = option.getAspectsZenith();
        aspectsVertex = option.getAspectsVertex();
        aspectsVulcan = option.getAspectsVulcan();
        aspectsOtherPoint = option.getAspectsOtherPoint();
        aspectsCeres = option.getAspectsCeres();
        aspectsPallas = option.getAspectsPallas();
        aspectsJuno = option.getAspectsJuno();
        aspectsVesta = option.getAspectsVesta();
        aspectsChiron = option.getAspectsChiron();
        aspectsAS = option.getAspectsAS();
        aspectsMC = option.getAspectsMC();
        shownAspect0 = option.getShownAspect0();
        shownAspect1 = option.getShownAspect1();
        shownAspect2 = option.getShownAspect2();
        shownAspect3 = option.getShownAspect3();
        shownAspect4 = option.getShownAspect4();
        shownAspect5 = option.getShownAspect5();
        shownAspect6 = option.getShownAspect6();
        shownAspect7 = option.getShownAspect7();
        shownAspect8 = option.getShownAspect8();
        shownAspect9 = option.getShownAspect9();
        shownAspect10 = option.getShownAspect10();
        shownAspect11 = option.getShownAspect11();
        shownAspect12 = option.getShownAspect12();
        shownAspect13 = option.getShownAspect13();
        shownAspect14 = option.getShownAspect14();
        shownAspect15 = option.getShownAspect15();
        shownAspect16 = option.getShownAspect16();
        shownAspect17 = option.getShownAspect17();
        chartSelectSingle = option.getChartSelectSingle();
        chartReturnPrecess = option.getChartReturnPrecess();
        limitMag = option.getLimitMag();
        orbLightLight = option.getOrbLightLight();
        orbLightTell = option.getOrbLightTell();
        orbLightOtherInd = option.getOrbLightOtherInd();
        orbLightColl = option.getOrbLightColl();
        orbLightVirtMax = option.getOrbLightVirtMax();
        orbLightVirtMin = option.getOrbLightVirtMin();
        orbTellTell = option.getOrbTellTell();
        orbTellOtherInd = option.getOrbTellOtherInd();
        orbTellColl = option.getOrbTellColl();
        orbTellVirtMax = option.getOrbTellVirtMax();
        orbTellVirtMin = option.getOrbTellVirtMin();
        orbOtherIndOtherInd = option.getOrbOtherIndOtherInd();
        orbOtherIndColl = option.getOrbOtherIndColl();
        orbOtherIndVirtMax = option.getOrbOtherIndVirtMax();
        orbOtherIndVirtMin = option.getOrbOtherIndVirtMin();
        orbCollColl = option.getOrbCollColl();
        orbCollVirtMax = option.getOrbCollVirtMax();
        orbCollVirtMin = option.getOrbCollVirtMin();
        orbVirtMaxVirtMax = option.getOrbVirtMaxVirtMax();
        orbVirtMaxVirtMin = option.getOrbVirtMaxVirtMin();
        orbVirtMinVirtMin = option.getOrbVirtMinVirtMin();
        divMin = option.getDivMin();
        divConjuntion = option.getDivConjuntion();
        divSextil = option.getDivSextil();
        divSquare = option.getDivSquare();
        divTrine = option.getDivTrine();
        divOpposition = option.getDivOpposition();
        otherAspectValue = option.getOtherAspectValue();
        chartDir1Corresp = option.getChartDir1Corresp();
        chartDir2Corresp = option.getChartDir2Corresp();
        chartDirSCorresp = option.getChartDirSCorresp();
        chartDir1Degree = option.getChartDir1Degree();
        chartDir2Day = option.getChartDir2Day();
        chartDirSDegree = option.getChartDirSDegree();
        singleWeight = option.getSingleWeight();
        setDataToText();
        MainClass.setCurrentOption(option);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }

    private void showOption(String strID)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        optionID = strID;
        option = starLoginManager.getOption(optionID);
        optionRow = option.getRow();
        saveOptionRow = optionRow;
        nbOfRows = option.getRowNB();
        chartReturnPlaceID = option.getChartReturnPlaceID();
        chartCyclePlaceID = option.getChartCyclePlaceID();
        defaultEvent = option.getDefaultEvent();
        defaultPlace = option.getDefaultPlace();
        coordSys = option.getCoordSys();
        houseSys = option.getHouseSys();
        otherPointType = option.getOtherPointType();
        chartReturnPlanet = option.getChartReturnPlanet();
        chartCyclePlanet1 = option.getChartCyclePlanet1();
        chartCyclePlanet2 = option.getChartCyclePlanet2();
        chartCompositeNB = option.getChartCompositeNB();
        chartHarmonicNB = option.getChartHarmonicNB();
        chartDir1SpaceKind = option.getChartDir1SpaceKind();
        chartDir2SpaceKind = option.getChartDir2SpaceKind();
        chartDirSSpaceKind = option.getChartDirSSpaceKind();
        otherPointName = option.getOtherPointName();
        configurationName = option.getConfigurationName();
        zodiacSize = option.getZodiacSize();
        signSize = option.getSignSize();
        planetSize = option.getPlanetSize();
        characterSize = option.getCharacterSize();
        typeAspect0 = option.getTypeAspect0();
        typeAspect1 = option.getTypeAspect1();
        typeAspect2 = option.getTypeAspect2();
        typeAspect3 = option.getTypeAspect3();
        typeAspect4 = option.getTypeAspect4();
        typeAspect5 = option.getTypeAspect5();
        typeAspect6 = option.getTypeAspect6();
        typeAspect7 = option.getTypeAspect7();
        typeAspect8 = option.getTypeAspect8();
        typeAspect9 = option.getTypeAspect9();
        typeAspect10 = option.getTypeAspect10();
        typeAspect11 = option.getTypeAspect11();
        typeAspect12 = option.getTypeAspect12();
        typeAspect13 = option.getTypeAspect13();
        typeAspect14 = option.getTypeAspect14();
        typeAspect15 = option.getTypeAspect15();
        typeAspect16 = option.getTypeAspect16();
        typeAspect17 = option.getTypeAspect17();
        otherAspectName = option.getOtherAspectName();
        chartKinds = option.getChartKinds();
        sunColor = option.getSunColor();
        moonColor = option.getMoonColor();
        mercuryColor = option.getMercuryColor();
        venusColor = option.getVenusColor();
        marsColor = option.getMarsColor();
        jupiterColor = option.getJupiterColor();
        saturnColor = option.getSaturnColor();
        uranusColor = option.getUranusColor();
        neptuneColor = option.getNeptuneColor();
        plutoColor = option.getPlutoColor();
        gaiaColor = option.getGaiaColor();
        nodesColor = option.getNodesColor();
        cuspsColor = option.getCuspsColor();
        asteroidsColor = option.getAsteroidsColor();
        vulcanColor = option.getVulcanColor();
        variousColor = option.getVariousColor();
        fireColor = option.getFireColor();
        earthColor = option.getEarthColor();
        airColor = option.getAirColor();
        waterColor = option.getWaterColor();
        neutralColor = option.getNeutralColor();
        dynamicColor = option.getDynamicColor();
        harmonicColor = option.getHarmonicColor();
        colorAspect0 = option.getColorAspect0();
        colorAspect1 = option.getColorAspect1();
        colorAspect2 = option.getColorAspect2();
        colorAspect3 = option.getColorAspect3();
        colorAspect4 = option.getColorAspect4();
        colorAspect5 = option.getColorAspect5();
        colorAspect6 = option.getColorAspect6();
        colorAspect7 = option.getColorAspect7();
        colorAspect8 = option.getColorAspect8();
        colorAspect9 = option.getColorAspect9();
        colorAspect10 = option.getColorAspect10();
        colorAspect11 = option.getColorAspect11();
        colorAspect12 = option.getColorAspect12();
        colorAspect13 = option.getColorAspect13();
        colorAspect14 = option.getColorAspect14();
        colorAspect15 = option.getColorAspect15();
        colorAspect16 = option.getColorAspect16();
        colorAspect17 = option.getColorAspect17();
        colorBackground = option.getColorBackground();
        colorForeground = option.getColorForeground();
        colorLabelsBackground = option.getColorLabelsBackground();
        colorLabelsForeground = option.getColorLabelsForeground();
        colorTextZonesBackground = option.getColorTextZonesBackground();
        colorTextZonesForeground = option.getColorTextZonesForeground();
        colorButtonsBackground = option.getColorButtonsBackground();
        colorButtonsForeground = option.getColorButtonsForeground();
        defaultConfiguration = option.getDefaultConfiguration();
        defaultConfiguration = option.getDefaultConfiguration();
        shownSun = option.getShownSun();
        shownMoon = option.getShownMoon();
        shownMercury = option.getShownMercury();
        shownVenus = option.getShownVenus();
        shownMars = option.getShownMars();
        shownJupiter = option.getShownJupiter();
        shownSaturn = option.getShownSaturn();
        shownUranus = option.getShownUranus();
        shownNeptune = option.getShownNeptune();
        shownPluto = option.getShownPluto();
        shownGaia = option.getShownGaia();
        shownNorthNode = option.getShownNorthNode();
        shownLilith = option.getShownLilith();
        shownEast = option.getShownEast();
        shownZenith = option.getShownZenith();
        shownVertex = option.getShownVertex();
        shownVulcan = option.getShownVulcan();
        shownOtherPoint = option.getShownOtherPoint();
        shownCeres = option.getShownCeres();
        shownPallas = option.getShownPallas();
        shownJuno = option.getShownJuno();
        shownVesta = option.getShownVesta();
        shownChiron = option.getShownChiron();
        trueLilith = option.getTrueLilith();
        coloredAspects = option.getColoredAspects();
        housesCoords = option.getHousesCoords();
        signsNames = option.getSignsNames();
        leftAsct = option.getLeftAsct();
        symbolAspects = option.getSymbolAspects();
        viewStars = option.getViewStars();
        viewAsteroids = option.getViewAsteroids();
        viewCoordinates = option.getViewCoordinates();
        viewStraightLines = option.getViewStraightLines();
        viewHouses = option.getViewHouses();
        viewConstellations = option.getViewConstellations();
        viewShadedLines = option.getViewShadedLines();
        viewAspects = option.getViewAspects();
        viewBarycenter = option.getViewBarycenter();
        horizon = option.getHorizon();
        aspectsSun = option.getAspectsSun();
        aspectsMoon = option.getAspectsMoon();
        aspectsMercury = option.getAspectsMercury();
        aspectsVenus = option.getAspectsVenus();
        aspectsMars = option.getAspectsMars();
        aspectsJupiter = option.getAspectsJupiter();
        aspectsSaturn = option.getAspectsSaturn();
        aspectsUranus = option.getAspectsUranus();
        aspectsNeptune = option.getAspectsNeptune();
        aspectsPluto = option.getAspectsPluto();
        aspectsGaia = option.getAspectsGaia();
        aspectsNorthNode = option.getAspectsNorthNode();
        aspectsLilith = option.getAspectsLilith();
        aspectsEast = option.getAspectsEast();
        aspectsZenith = option.getAspectsZenith();
        aspectsVertex = option.getAspectsVertex();
        aspectsVulcan = option.getAspectsVulcan();
        aspectsOtherPoint = option.getAspectsOtherPoint();
        aspectsCeres = option.getAspectsCeres();
        aspectsPallas = option.getAspectsPallas();
        aspectsJuno = option.getAspectsJuno();
        aspectsVesta = option.getAspectsVesta();
        aspectsChiron = option.getAspectsChiron();
        aspectsAS = option.getAspectsAS();
        aspectsMC = option.getAspectsMC();
        shownAspect0 = option.getShownAspect0();
        shownAspect1 = option.getShownAspect1();
        shownAspect2 = option.getShownAspect2();
        shownAspect3 = option.getShownAspect3();
        shownAspect4 = option.getShownAspect4();
        shownAspect5 = option.getShownAspect5();
        shownAspect6 = option.getShownAspect6();
        shownAspect7 = option.getShownAspect7();
        shownAspect8 = option.getShownAspect8();
        shownAspect9 = option.getShownAspect9();
        shownAspect10 = option.getShownAspect10();
        shownAspect11 = option.getShownAspect11();
        shownAspect12 = option.getShownAspect12();
        shownAspect13 = option.getShownAspect13();
        shownAspect14 = option.getShownAspect14();
        shownAspect15 = option.getShownAspect15();
        shownAspect16 = option.getShownAspect16();
        shownAspect17 = option.getShownAspect17();
        chartSelectSingle = option.getChartSelectSingle();
        chartReturnPrecess = option.getChartReturnPrecess();
        limitMag = option.getLimitMag();
        orbLightLight = option.getOrbLightLight();
        orbLightTell = option.getOrbLightTell();
        orbLightOtherInd = option.getOrbLightOtherInd();
        orbLightColl = option.getOrbLightColl();
        orbLightVirtMax = option.getOrbLightVirtMax();
        orbLightVirtMin = option.getOrbLightVirtMin();
        orbTellTell = option.getOrbTellTell();
        orbTellOtherInd = option.getOrbTellOtherInd();
        orbTellColl = option.getOrbTellColl();
        orbTellVirtMax = option.getOrbTellVirtMax();
        orbTellVirtMin = option.getOrbTellVirtMin();
        orbOtherIndOtherInd = option.getOrbOtherIndOtherInd();
        orbOtherIndColl = option.getOrbOtherIndColl();
        orbOtherIndVirtMax = option.getOrbOtherIndVirtMax();
        orbOtherIndVirtMin = option.getOrbOtherIndVirtMin();
        orbCollColl = option.getOrbCollColl();
        orbCollVirtMax = option.getOrbCollVirtMax();
        orbCollVirtMin = option.getOrbCollVirtMin();
        orbVirtMaxVirtMax = option.getOrbVirtMaxVirtMax();
        orbVirtMaxVirtMin = option.getOrbVirtMaxVirtMin();
        orbVirtMinVirtMin = option.getOrbVirtMinVirtMin();
        divMin = option.getDivMin();
        divConjuntion = option.getDivConjuntion();
        divSextil = option.getDivSextil();
        divSquare = option.getDivSquare();
        divTrine = option.getDivTrine();
        divOpposition = option.getDivOpposition();
        otherAspectValue = option.getOtherAspectValue();
        chartDir1Corresp = option.getChartDir1Corresp();
        chartDir2Corresp = option.getChartDir2Corresp();
        chartDirSCorresp = option.getChartDirSCorresp();
        chartDir1Degree = option.getChartDir1Degree();
        chartDir2Day = option.getChartDir2Day();
        chartDirSDegree = option.getChartDirSDegree();
        singleWeight = option.getSingleWeight();
        setDataToText();
        MainClass.setCurrentOption(option);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void setTextToData()
    {
        configurationName = txtConfiguration.getText();
        defaultConfiguration = chkDefaultConfiguration.isSelected();
        defaultPlace = starLoginManager.getStringFieldValue("Places", "ID", " WHERE PlaceName='" + cboDefaultPlace.getSelectedItem().toString().replace("'", "''") + "'");// getPlaceID(places, cboDefaultPlace.getSelectedItem().toString());
        defaultEvent = getEventID(events, cboDefaultEvent.getSelectedItem().toString());

        /*
         * if (chkTropical.isSelected() == true) { coordSys = CoordSystem.Tropical; } else if
         * (chkSidereal.isSelected() == true) { coordSys = CoordSystem.Sidereal; } else if
         * (chkLocal.isSelected() == true) { coordSys = CoordSystem.Local; } else if
         * (chkDomitudes.isSelected() == true) { coordSys = CoordSystem.Domitudes; } else if
         * (chkEquatorial.isSelected() == true) { coordSys = CoordSystem.Equatorial; } else if
         * (chkEcliptic.isSelected() == true) { coordSys = CoordSystem.Ecliptic; } else if
         * (chkHeliocentricNormal.isSelected() == true) { coordSys = CoordSystem.HelioNormal; } else
         * if (chkHeliocentricSidereal.isSelected() == true) { coordSys = CoordSystem.HelioSidereal;
		 }
         */

        //houses system
        /*
         * if (optAbenragel.isSelected() == true) { houseSys = HouseSystem.Abenragel; } else if
         * (optCampanus.isSelected() == true) { houseSys = HouseSystem.Campanus; } else if
         * (optPlacidus.isSelected() == true) { houseSys = HouseSystem.Placidus; } else if
         * (optKoch.isSelected() == true) { houseSys = HouseSystem.Koch; } else if
         * (optZodiacal.isSelected() == true) { houseSys = HouseSystem.Zodiacal; } else if
         * (optZenithal.isSelected() == true) { houseSys = HouseSystem.Zenithal; } else if
         * (optWiesel.isSelected() == true) { houseSys = HouseSystem.Wiesel; } else if
         * (optTwoHours.isSelected() == true) { houseSys = HouseSystem.TwoHours; } else if
         * (optSolar.isSelected() == true) { houseSys = HouseSystem.Solar; } else if
         * (optRegiomontanus.isSelected() == true) { houseSys = HouseSystem.Regiomontanus; } else if
         * (optSemiAngular.isSelected() == true) { houseSys = HouseSystem.SemiAngular; } else if
         * (optPorpyre.isSelected() == true) { houseSys = HouseSystem.Porphyre; } else if
         * (optNodal.isSelected() == true) { houseSys = HouseSystem.Nodal; } else if
         * (optMaternusMC.isSelected() == true) { houseSys = HouseSystem.MaternusMC; } else if
         * (optMaternusAs.isSelected() == true) { houseSys = HouseSystem.MaternusAs; } else if
         * (optEquatorialRegular.isSelected() == true) { houseSys = HouseSystem.EquatorialRegular; }
         * else if (optColinEvans.isSelected() == true) { houseSys = HouseSystem.ColinEvans; } else
         * if (optBazchenoff.isSelected() == true) { houseSys = HouseSystem.Bazchenoff; } else if
         * (optAncient.isSelected() == true) { houseSys = HouseSystem.Ancient; } else if
         * (optAlcabitius.isSelected() == true) { houseSys = HouseSystem.Alcabitius; } else if
         * (optAlbategnius.isSelected() == true) { houseSys = HouseSystem.Albategnius;
		 }
         */

        //other point
        if (optOtherPtAsteroid.isSelected() == true)
        {
            otherPointName = cboAsteroid.getSelectedItem().toString();
            otherPointType = OtherPt.asteroid;
        }
        else if (optOtherPtPart.isSelected() == true)
        {
            otherPointName = cboPart.getSelectedItem().toString();
            otherPointType = OtherPt.part;
        }
        else if (optOtherPtStar.isSelected() == true)
        {
            otherPointName = cboStarIdentity.getSelectedItem().toString();
            otherPointType = OtherPt.star;
        }
        else if (optOtherPtComet.isSelected() == true)
        {
            otherPointName = cboComet.getSelectedItem().toString();
            otherPointType = OtherPt.comet;
        }
        else
        {
            otherPointName = "";
            otherPointType = OtherPt.none;
        }

        //other aspect
        otherAspectName = txtOtherAspectName.getText();
        shownAspect17 = chkOtherAspect.isSelected();
        otherAspectValue = txtValueOtherAspect.getText();
        colorAspect17 = lblColorOtherAspect.getBackground();
        typeAspect17 = txtOtherAspect.getText();

        defaultConfiguration = option.getDefaultConfiguration();

        //selected charts with their characteristics
        chartKinds = "";
        if (chkNormal.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.normal;
        }
        if (chkAstronomical.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.local;
        }
        if (chkSymbolicDir.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.symbolicDir;
        }
        if (chkPrimaryDir.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.primaryDir;
        }
        if (chkSecondaryDir.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.secondaryDir;
        }
        if (chkTransits.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.transit;
        }
        if (chkRevolution.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.revolution;
        }
        if (chkCycle.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.cycle;
        }
        if (chkSynastry.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.synastry;
        }
        if (chkComposite.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.composite;
        }
        if (chkFree.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.free;
        }
        if (chkHarmonic.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.harmonic;
        }
        if (chkSeed.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.seed;
        }
        if (chkProjective.isSelected())
        {
            chartKinds = chartKinds + ";" + ChartKind.projective;
        }
        chartKinds = chartKinds.substring(1);   //remove the first ";"

        symbolAspects = chkAspectsSymbol.isSelected();
        housesCoords = chkHousesCoord.isSelected();
        signsNames = chkSignsName.isSelected();
        viewStars = chkStars.isSelected();
        limitMag = new Double((double) sldStars.getValue() / 2.0).toString();
        viewConstellations = chkConstellations.isSelected();
        viewAsteroids = chkAsteroids.isSelected();
        viewHouses = chkHouses.isSelected();
        viewAspects = chkAspects.isSelected();
        viewCoordinates = chkCoordinates.isSelected();
        viewStraightLines = chkStraightLines.isSelected();
        viewShadedLines = chkShaded.isSelected();
        viewBarycenter = chkBarycenter.isSelected();
        singleWeight = optSingleWeight.isSelected();
        chartSelectSingle = jOptSingleSelection.isSelected();
        leftAsct = optEastAS.isSelected();
        coloredAspects = optColorMode2.isSelected();
        horizon = optHorizon.isSelected();
        chartDirSCorresp = txtCorrespondDS.getText();
        chartDirSDegree = txtEqualsDS.getText();
        chartDirSSpaceKind = new Integer(cboDS.getSelectedIndex()).toString();
        chartDir1Corresp = txtCorrespondD1.getText();
        chartDir1Degree = txtEqualsD1.getText();
        chartDir1SpaceKind = new Integer(cboD1.getSelectedIndex()).toString();
        chartDir2Corresp = txtCorrespondD2.getText();
        chartDir2Day = txtEqualsD2.getText();
        chartDir2SpaceKind = new Integer(cboD2.getSelectedIndex()).toString();
        chartReturnPrecess = chkPrecession.isSelected();
        chartReturnPlanet = getPlanetID(cboPlanetReturn);
        chartCyclePlanet1 = getPlanetID(cboPlanet1Cycle);
        chartCyclePlanet2 = getPlanetID(cboPlanet2Cycle);
        chartCyclePlaceID = getPlaceID(places, cboPlaceCycle.getSelectedItem().toString());
        chartReturnPlaceID = getPlaceID(places, cboPlaceReturn.getSelectedItem().toString());
        chartCompositeNB = txtCompositeChartsNB.getText();
        chartHarmonicNB = txtHarmonicNB.getText();

        //chart colors
        sunColor = lblColorSun.getBackground();
        moonColor = lblColorMoon.getBackground();
        mercuryColor = lblColorMercury.getBackground();
        venusColor = lblColorVenus.getBackground();
        marsColor = lblColorMars.getBackground();
        jupiterColor = lblColorJupiter.getBackground();
        saturnColor = lblColorSaturn.getBackground();
        uranusColor = lblColorUranus.getBackground();
        neptuneColor = lblColorNeptune.getBackground();
        plutoColor = lblColorPluto.getBackground();
        gaiaColor = lblColorGaia.getBackground();
        nodesColor = lblColorNodes.getBackground();
        cuspsColor = lblColorHouses.getBackground();
        asteroidsColor = lblColorAsteroids.getBackground();
        vulcanColor = lblColorVulcan.getBackground();
        variousColor = lblColorText.getBackground();
        fireColor = lblColorFire.getBackground();
        earthColor = lblColorEarth.getBackground();
        airColor = lblColorAir.getBackground();
        waterColor = lblColorWater.getBackground();
        neutralColor = lblColorNeutral.getBackground();
        dynamicColor = lblColorDynamic.getBackground();
        harmonicColor = lblColorHarmonic.getBackground();

        //chart sizes
        zodiacSize = sldZodiac.getValue();
        signSize = sldSigns.getValue();
        planetSize = sldPlanets.getValue();
        characterSize = sldCharacters.getValue();

        //selected planets
        shownSun = chkSun.isSelected();
        shownMoon = chkMoon.isSelected();
        shownMercury = chkMercury.isSelected();
        shownVenus = chkVenus.isSelected();
        shownMars = chkMars.isSelected();
        shownJupiter = chkJupiter.isSelected();
        shownSaturn = chkSaturn.isSelected();
        shownUranus = chkUranus.isSelected();
        shownNeptune = chkNeptune.isSelected();
        shownPluto = chkPluto.isSelected();
        shownGaia = chkGaia.isSelected();
        shownNorthNode = chkNN.isSelected();
        shownLilith = chkLilith.isSelected();
        trueLilith = chkTrueLilith.isSelected();
        shownEast = chkEast.isSelected();
        shownZenith = chkZenith.isSelected();
        shownVertex = chkVertex.isSelected();
        shownVulcan = chkVulcan.isSelected();
        shownOtherPoint = chkOtherPoint.isSelected();
        shownCeres = chkCeres.isSelected();
        shownPallas = chkPallas.isSelected();
        shownJuno = chkJuno.isSelected();
        shownVesta = chkVesta.isSelected();
        shownChiron = chkChiron.isSelected();

        //aspects definition
        shownAspect0 = chkConjunction.isSelected();
        typeAspect0 = txtConjunction.getText();
        colorAspect0 = lblColorConjunction.getBackground();
        shownAspect1 = chkSextile.isSelected();
        typeAspect1 = txtSextile.getText();
        colorAspect1 = lblColorSextile.getBackground();
        shownAspect2 = chkSquare.isSelected();
        typeAspect2 = txtSquare.getText();
        colorAspect2 = lblColorSquare.getBackground();
        shownAspect3 = chkTrine.isSelected();
        typeAspect3 = txtTrine.getText();
        colorAspect3 = lblColorTrine.getBackground();
        shownAspect4 = chkOpposition.isSelected();
        typeAspect4 = txtOpposition.getText();
        colorAspect4 = lblColorOpposition.getBackground();
        shownAspect5 = chkVigintile.isSelected();
        typeAspect5 = txtVigintile.getText();
        colorAspect5 = lblColorVigintile.getBackground();
        shownAspect6 = chkSemiSextile.isSelected();
        typeAspect6 = txtSemiSextile.getText();
        colorAspect6 = lblColorSemiSextile.getBackground();
        shownAspect7 = chkSemiQuintile.isSelected();
        typeAspect7 = txtSemiQuintile.getText();
        colorAspect7 = lblColorSemiQuintile.getBackground();
        shownAspect8 = chkNonagon.isSelected();
        typeAspect8 = txtNonagone.getText();
        colorAspect8 = lblColorNonagon.getBackground();
        shownAspect9 = chkSemiSquare.isSelected();
        typeAspect9 = txtSemiSquare.getText();
        colorAspect9 = lblColorSemiSquare.getBackground();
        shownAspect10 = chkSeptile.isSelected();
        typeAspect10 = txtSeptile.getText();
        colorAspect10 = lblColorSeptile.getBackground();
        shownAspect11 = chkQuintile.isSelected();
        typeAspect11 = txtQuintile.getText();
        colorAspect11 = lblColorQuintile.getBackground();
        shownAspect12 = chkTriDectile.isSelected();
        typeAspect12 = txtTriDectile.getText();
        colorAspect12 = lblColorTridectile.getBackground();
        shownAspect13 = chkSesquiSquare.isSelected();
        typeAspect13 = txtSesquiSquare.getText();
        colorAspect13 = lblColorSesquiSquare.getBackground();
        shownAspect14 = chkBiQuintile.isSelected();
        typeAspect14 = txtBiquintile.getText();
        colorAspect14 = lblColorBiQuintile.getBackground();
        shownAspect15 = chkInconjunct.isSelected();
        typeAspect15 = txtInconjunct.getText();
        colorAspect15 = lblColorInconjunct.getBackground();
        shownAspect16 = chkQuadriNonagon.isSelected();
        typeAspect16 = txtQuadriNonagon.getText();
        colorAspect16 = lblColorQuadriNonagon.getBackground();

        //Aspected planets
        aspectsSun = chkAspectSun.isSelected();
        aspectsMoon = chkAspectMoon.isSelected();
        aspectsMercury = chkAspectMercury.isSelected();
        aspectsVenus = chkAspectVenus.isSelected();
        aspectsMars = chkAspectMars.isSelected();
        aspectsJupiter = chkAspectJupiter.isSelected();
        aspectsSaturn = chkAspectSaturn.isSelected();
        aspectsUranus = chkAspectUranus.isSelected();
        aspectsNeptune = chkAspectNeptune.isSelected();
        aspectsPluto = chkAspectPluto.isSelected();
        aspectsGaia = chkAspectGaia.isSelected();
        aspectsNorthNode = chkAspectNodes.isSelected();
        aspectsLilith = chkAspectLilith.isSelected();
        aspectsEast = chkAspectEast.isSelected();
        aspectsZenith = chkAspectZenith.isSelected();
        aspectsVertex = chkAspectVertex.isSelected();
        aspectsVulcan = chkAspectVulcan.isSelected();
        aspectsCeres = chkAspectCeres.isSelected();
        aspectsPallas = chkAspectPallas.isSelected();
        aspectsJuno = chkAspectJuno.isSelected();
        aspectsVesta = chkAspectVesta.isSelected();
        aspectsChiron = chkAspectChiron.isSelected();
        aspectsAS = chkAspectAS.isSelected();
        aspectsMC = chkAspectMC.isSelected();
        aspectsOtherPoint = chkAspectOtherPoint.isSelected();

        //Orbs
        orbLightLight = txtOrbLumLum.getText();
        orbLightTell = txtOrbLumIndiv.getText();
        orbLightOtherInd = txtOrbLumJS.getText();
        orbLightColl = txtOrbLumCol.getText();
        orbLightVirtMax = txtOrbLumVirtMaj.getText();
        orbLightVirtMin = txtOrbLumVirtMin.getText();
        orbTellTell = txtOrbIndivIndiv.getText();
        orbTellOtherInd = txtOrbIndivJS.getText();
        orbTellColl = txtOrbIndivCol.getText();
        orbTellVirtMax = txtOrbIndivVirtMaj.getText();
        orbTellVirtMin = txtOrbIndivVirtMin.getText();
        orbOtherIndOtherInd = txtOrbJSJS.getText();
        orbOtherIndColl = txtOrbJSCol.getText();
        orbOtherIndVirtMax = txtOrbJSvirtMaj.getText();
        orbOtherIndVirtMin = txtOrbJSVirtMin.getText();
        orbCollColl = txtOrbColCol.getText();
        orbCollVirtMax = txtOrbColVirtMaj.getText();
        orbCollVirtMin = txtOrbColVirtMin.getText();
        orbVirtMaxVirtMax = txtOrbVirtMajVirtMaj.getText();
        orbVirtMaxVirtMin = txtOrbVirtMajVirtMin.getText();
        orbVirtMinVirtMin = txtOrbvirtMinVirtMin.getText();

        //orbs divisors
        divConjuntion = txtDivConjunction.getText();
        divSextil = txtDivSextile.getText();
        divSquare = txtDivSquare.getText();
        divTrine = txtDivTrine.getText();
        divOpposition = txtDivOpposition.getText();
        divMin = txtDivOther.getText();
    }

    private void resetColors()
    {
        lblColorSun.setBackground(sunColor);
        lblColorMoon.setBackground(moonColor);
        lblColorMercury.setBackground(mercuryColor);
        lblColorVenus.setBackground(venusColor);
        lblColorMars.setBackground(marsColor);
        lblColorJupiter.setBackground(jupiterColor);
        lblColorSaturn.setBackground(saturnColor);
        lblColorUranus.setBackground(uranusColor);
        lblColorNeptune.setBackground(neptuneColor);
        lblColorPluto.setBackground(plutoColor);
        lblColorGaia.setBackground(gaiaColor);
        lblColorNodes.setBackground(nodesColor);
        lblColorHouses.setBackground(cuspsColor);
        lblColorAsteroids.setBackground(asteroidsColor);
        lblColorVulcan.setBackground(vulcanColor);
        lblColorText.setBackground(variousColor);
        lblColorFire.setBackground(fireColor);
        lblColorEarth.setBackground(earthColor);
        lblColorAir.setBackground(airColor);
        lblColorWater.setBackground(waterColor);
        lblColorNeutral.setBackground(neutralColor);
        lblColorDynamic.setBackground(dynamicColor);
        lblColorHarmonic.setBackground(harmonicColor);
        txtConjunction.setForeground(getColorTypeAspect(typeAspect0));
        lblColorConjunction.setBackground(colorAspect0);
        txtSextile.setForeground(getColorTypeAspect(typeAspect1));
        lblColorSextile.setBackground(colorAspect1);
        txtSquare.setForeground(getColorTypeAspect(typeAspect2));
        lblColorSquare.setBackground(colorAspect2);
        txtTrine.setForeground(getColorTypeAspect(typeAspect3));
        lblColorTrine.setBackground(colorAspect3);
        txtOpposition.setForeground(getColorTypeAspect(typeAspect4));
        lblColorOpposition.setBackground(colorAspect4);
        txtVigintile.setForeground(getColorTypeAspect(typeAspect5));
        lblColorVigintile.setBackground(colorAspect5);
        txtSemiSextile.setForeground(getColorTypeAspect(typeAspect6));
        lblColorSemiSextile.setBackground(colorAspect6);
        txtSemiQuintile.setForeground(getColorTypeAspect(typeAspect7));
        lblColorSemiQuintile.setBackground(colorAspect7);
        txtNonagone.setForeground(getColorTypeAspect(typeAspect8));
        lblColorNonagon.setBackground(colorAspect8);
        txtSemiSquare.setForeground(getColorTypeAspect(typeAspect9));
        lblColorSemiSquare.setBackground(colorAspect9);
        txtSeptile.setForeground(getColorTypeAspect(typeAspect10));
        lblColorSeptile.setBackground(colorAspect10);
        txtQuintile.setForeground(getColorTypeAspect(typeAspect11));
        lblColorQuintile.setBackground(colorAspect11);
        txtTriDectile.setForeground(getColorTypeAspect(typeAspect12));
        lblColorTridectile.setBackground(colorAspect12);
        txtSesquiSquare.setForeground(getColorTypeAspect(typeAspect13));
        lblColorSesquiSquare.setBackground(colorAspect13);
        txtBiquintile.setForeground(getColorTypeAspect(typeAspect14));
        lblColorBiQuintile.setBackground(colorAspect14);
        txtInconjunct.setForeground(getColorTypeAspect(typeAspect15));
        lblColorInconjunct.setBackground(colorAspect15);
        txtQuadriNonagon.setForeground(getColorTypeAspect(typeAspect16));
        lblColorQuadriNonagon.setBackground(colorAspect16);
        txtOtherAspect.setForeground(getColorTypeAspect(typeAspect17));
        lblColorOtherAspect.setBackground(colorAspect17);
    }

    private void setDataToText()
    {
        bolSetting = true;

        //Get the default options
        txtConfiguration.setText(configurationName);
        chkDefaultConfiguration.setSelected(defaultConfiguration);

        //coordinates system
        byte system = coordSys;
        switch ((int) system)
        {
            case CoordSystem.Tropical:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
                break;
            case CoordSystem.Sidereal:
                chkGeocentric.setSelected(true);
                chkSidereal.setSelected(true);
                break;
            case CoordSystem.Local:
                chkGeocentric.setSelected(true);
                chkLocal.setSelected(true);
                break;
            case CoordSystem.Domitudes:
                chkGeocentric.setSelected(true);
                chkDomitudes.setSelected(true);
                break;
            case CoordSystem.Equatorial:
                chkGeocentric.setSelected(true);
                chkEquatorial.setSelected(true);
                break;
            case CoordSystem.Ecliptic:
                chkGeocentric.setSelected(true);
                chkEcliptic.setSelected(true);
                break;
            case CoordSystem.HelioNormal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricNormal.setSelected(true);
                break;
            case CoordSystem.HelioSidereal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricSidereal.setSelected(true);
                break;
            default:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
        }

        //houses system
        byte domif = houseSys;
        switch ((int) domif)
        {
            case HouseSystem.Abenragel:
                optAbenragel.setSelected(true);
                break;
            case HouseSystem.Albategnius:
                optAlbategnius.setSelected(true);
                break;
            case HouseSystem.Alcabitius:
                optAlcabitius.setSelected(true);
                break;
            case HouseSystem.Ancient:
                optAncient.setSelected(true);
                break;
            case HouseSystem.Bazchenoff:
                optBazchenoff.setSelected(true);
                break;
            case HouseSystem.Campanus:
                optCampanus.setSelected(true);
                break;
            case HouseSystem.ColinEvans:
                optColinEvans.setSelected(true);
                break;
            case HouseSystem.EquatorialRegular:
                optEquatorialRegular.setSelected(true);
                break;
            case HouseSystem.Koch:
                optKoch.setSelected(true);
                break;
            case HouseSystem.MaternusAs:
                optMaternusAs.setSelected(true);
                break;
            case HouseSystem.MaternusMC:
                optMaternusMC.setSelected(true);
                break;
            case HouseSystem.Nodal:
                optNodal.setSelected(true);
                break;
            case HouseSystem.Placidus:
                optPlacidus.setSelected(true);
                break;
            case HouseSystem.Porphyre:
                optPorpyre.setSelected(true);
                break;
            case HouseSystem.Regiomontanus:
                optRegiomontanus.setSelected(true);
                break;
            case HouseSystem.SemiAngular:
                optSemiAngular.setSelected(true);
                break;
            case HouseSystem.Solar:
                optSolar.setSelected(true);
                break;
            case HouseSystem.TwoHours:
                optTwoHours.setSelected(true);
                break;
            case HouseSystem.Wiesel:
                optWiesel.setSelected(true);
                break;
            case HouseSystem.Zenithal:
                optZenithal.setSelected(true);
                break;
            case HouseSystem.Zodiacal:
                optZodiacal.setSelected(true);
                break;
            default:
                optCampanus.setSelected(true);
        }

        //other point
        byte otherPt = otherPointType;
        switch ((int) otherPt)
        {
            case OtherPt.asteroid:
                optOtherPtAsteroid.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(true);
                cboComet.setVisible(false);
                cboAsteroid.setSelectedItem(otherPointName);
                break;
            case OtherPt.part:
                optOtherPtPart.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(true);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
                cboPart.setSelectedItem(otherPointName);
                setPart();
                break;
            case OtherPt.star:
                optOtherPtStar.setSelected(true);
                pnlOtherPtStar.setVisible(true);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
                cboStarIdentity.setSelectedItem(otherPointName);
                setStar();
                break;
            case OtherPt.comet:
                optOtherPtComet.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(true);
                cboComet.setSelectedItem(otherPointName);
                break;
            default:
                optOtherPtNone.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
        }

        //other aspect
        txtOtherAspectName.setText(otherAspectName);
        chkOtherAspect.setSelected(shownAspect17);
        txtOtherAspect.setText(typeAspect17);
        txtOtherAspect.setForeground(getColorTypeAspect(typeAspect17));
        lblColorOtherAspect.setBackground(colorAspect17);
        txtValueOtherAspect.setText(otherAspectValue);

        //selected charts with their characteristics
        String sChartKinds = chartKinds;
        int pos = sChartKinds.indexOf(';');
        String chart;

        if (pos > 0)
        {
            while (pos > 0)
            {
                chart = sChartKinds.substring(0, pos);
                setChart(new Integer(chart).intValue());
                sChartKinds = sChartKinds.substring(pos + 1);
                pos = sChartKinds.indexOf(';');
            }
            if (!sChartKinds.equals(""))
            {
                setChart(new Integer(sChartKinds).intValue());
            }
        }
        else
        {
            setChart(new Integer(sChartKinds).intValue());
        }

        chkAspectsSymbol.setSelected(symbolAspects);
        chkHousesCoord.setSelected(housesCoords);
        chkSignsName.setSelected(signsNames);
        chkStars.setSelected(viewStars);
        sldStars.setValue((int) (new Double(limitMag).doubleValue() * 2.0));
        chkConstellations.setSelected(viewConstellations);
        chkAsteroids.setSelected(viewAsteroids);
        chkHouses.setSelected(viewHouses);
        chkAspects.setSelected(viewAspects);
        chkCoordinates.setSelected(viewCoordinates);
        chkStraightLines.setSelected(viewStraightLines);
        chkShaded.setSelected(viewShadedLines);
        chkBarycenter.setSelected(viewBarycenter);
        if (singleWeight == true)
        {
            optSingleWeight.setSelected(true);
        }
        else
        {
            optDifferentWeights.setSelected(true);
        }
        if (chartSelectSingle == true)
        {
            jOptSingleSelection.setSelected(true);
        }
        else
        {
            jOptMultiSelection.setSelected(true);
        }
        if (coloredAspects == true)
        {
            optColorMode2.setSelected(true);
        }
        else
        {
            optColorMode1.setSelected(true);
        }
        if (leftAsct == true)
        {
            optEastAS.setSelected(true);
        }
        else
        {
            optEastAries.setSelected(true);
        }
        if (horizon == true)
        {
            optHorizon.setSelected(true);
        }
        else
        {
            optZenith.setSelected(true);
        }
        txtCorrespondDS.setText(chartDirSCorresp);
        txtEqualsDS.setText(chartDirSDegree);
        cboDS.setSelectedIndex(new Integer(chartDirSSpaceKind).intValue());
        txtCorrespondD1.setText(chartDir1Corresp);
        txtEqualsD1.setText(chartDir1Degree);
        cboD1.setSelectedIndex(new Integer(chartDir1SpaceKind).intValue());
        txtCorrespondD2.setText(chartDir2Corresp);
        txtEqualsD2.setText(chartDir2Day);
        cboD2.setSelectedIndex(new Integer(chartDir2SpaceKind).intValue());
        chkPrecession.setSelected(chartReturnPrecess);
        cboPlanetReturn.setSelectedIndex(new Integer(chartReturnPlanet).intValue());
        cboPlanet1Cycle.setSelectedIndex(new Integer(chartCyclePlanet1).intValue());
        cboPlanet2Cycle.setSelectedIndex(new Integer(chartCyclePlanet2).intValue());

        Place place = starLoginManager.getPlace(chartCyclePlaceID);
        cboPlaceCycle.setSelectedItem(place.getPlaceName());
        lblLatitudeCycle.setText(place.getPlaceLatitude());
        lblLongitudeCycle.setText(place.getPlaceLongitude());
        place = starLoginManager.getPlace(chartReturnPlaceID);
        cboPlaceReturn.setSelectedItem(place.getPlaceName());
        lblLatitudeReturn.setText(place.getPlaceLatitude());
        lblLongitudeReturn.setText(place.getPlaceLongitude());

        txtCompositeChartsNB.setText(chartCompositeNB);
        txtHarmonicNB.setText(chartHarmonicNB);

        //chart colors
        lblColorSun.setBackground(sunColor);
        lblColorMoon.setBackground(moonColor);
        lblColorMercury.setBackground(mercuryColor);
        lblColorVenus.setBackground(venusColor);
        lblColorMars.setBackground(marsColor);
        lblColorJupiter.setBackground(jupiterColor);
        lblColorSaturn.setBackground(saturnColor);
        lblColorUranus.setBackground(uranusColor);
        lblColorNeptune.setBackground(neptuneColor);
        lblColorPluto.setBackground(plutoColor);
        lblColorGaia.setBackground(gaiaColor);
        lblColorNodes.setBackground(nodesColor);
        lblColorHouses.setBackground(cuspsColor);
        lblColorAsteroids.setBackground(asteroidsColor);
        lblColorVulcan.setBackground(vulcanColor);
        lblColorText.setBackground(variousColor);
        lblColorFire.setBackground(fireColor);
        lblColorEarth.setBackground(earthColor);
        lblColorAir.setBackground(airColor);
        lblColorWater.setBackground(waterColor);
        lblColorNeutral.setBackground(neutralColor);
        lblColorDynamic.setBackground(dynamicColor);
        lblColorHarmonic.setBackground(harmonicColor);

        //chart sizes
        sldZodiac.setValue(zodiacSize);
        sldSigns.setValue(signSize);
        sldPlanets.setValue(planetSize);
        sldCharacters.setValue(characterSize);

        //selected planets
        chkSun.setSelected(shownSun);
        chkMoon.setSelected(shownMoon);
        chkMercury.setSelected(shownMercury);
        chkVenus.setSelected(shownVenus);
        chkMars.setSelected(shownMars);
        chkJupiter.setSelected(shownJupiter);
        chkSaturn.setSelected(shownSaturn);
        chkUranus.setSelected(shownUranus);
        chkNeptune.setSelected(shownNeptune);
        chkPluto.setSelected(shownPluto);
        chkGaia.setSelected(shownGaia);
        chkNN.setSelected(shownNorthNode);
        chkLilith.setSelected(shownLilith);
        chkTrueLilith.setSelected(trueLilith);
        chkEast.setSelected(shownEast);
        chkZenith.setSelected(shownZenith);
        chkVertex.setSelected(shownVertex);
        chkVulcan.setSelected(shownVulcan);
        chkOtherPoint.setSelected(shownOtherPoint);
        pnlOtherPoint.setVisible(shownOtherPoint);
        chkCeres.setSelected(shownCeres);
        chkPallas.setSelected(shownPallas);
        chkJuno.setSelected(shownJuno);
        chkVesta.setSelected(shownVesta);
        chkChiron.setSelected(shownChiron);

        //aspects definition
        chkConjunction.setSelected(shownAspect0);
        txtConjunction.setText(typeAspect0);
        txtConjunction.setForeground(getColorTypeAspect(typeAspect0));
        lblColorConjunction.setBackground(colorAspect0);
        chkSextile.setSelected(shownAspect1);
        txtSextile.setText(typeAspect1);
        txtSextile.setForeground(getColorTypeAspect(typeAspect1));
        lblColorSextile.setBackground(colorAspect1);
        chkSquare.setSelected(shownAspect2);
        txtSquare.setText(typeAspect2);
        txtSquare.setForeground(getColorTypeAspect(typeAspect2));
        lblColorSquare.setBackground(colorAspect2);
        chkTrine.setSelected(shownAspect3);
        txtTrine.setText(typeAspect3);
        txtTrine.setForeground(getColorTypeAspect(typeAspect3));
        lblColorTrine.setBackground(colorAspect3);
        chkOpposition.setSelected(shownAspect4);
        txtOpposition.setText(typeAspect4);
        txtOpposition.setForeground(getColorTypeAspect(typeAspect4));
        lblColorOpposition.setBackground(colorAspect4);
        chkVigintile.setSelected(shownAspect5);
        txtVigintile.setText(typeAspect5);
        txtVigintile.setForeground(getColorTypeAspect(typeAspect5));
        lblColorVigintile.setBackground(colorAspect5);
        chkSemiSextile.setSelected(shownAspect6);
        txtSemiSextile.setText(typeAspect6);
        txtSemiSextile.setForeground(getColorTypeAspect(typeAspect6));
        lblColorSemiSextile.setBackground(colorAspect6);
        chkSemiQuintile.setSelected(shownAspect7);
        txtSemiQuintile.setText(typeAspect7);
        txtSemiQuintile.setForeground(getColorTypeAspect(typeAspect7));
        lblColorSemiQuintile.setBackground(colorAspect7);
        chkNonagon.setSelected(shownAspect8);
        txtNonagone.setText(typeAspect8);
        txtNonagone.setForeground(getColorTypeAspect(typeAspect8));
        lblColorNonagon.setBackground(colorAspect8);
        chkSemiSquare.setSelected(shownAspect9);
        txtSemiSquare.setText(typeAspect9);
        txtSemiSquare.setForeground(getColorTypeAspect(typeAspect9));
        lblColorSemiSquare.setBackground(colorAspect9);
        chkSeptile.setSelected(shownAspect10);
        txtSeptile.setText(typeAspect10);
        txtSeptile.setForeground(getColorTypeAspect(typeAspect10));
        lblColorSeptile.setBackground(colorAspect10);
        chkQuintile.setSelected(shownAspect11);
        txtQuintile.setText(typeAspect11);
        txtQuintile.setForeground(getColorTypeAspect(typeAspect11));
        lblColorQuintile.setBackground(colorAspect11);
        chkTriDectile.setSelected(shownAspect12);
        txtTriDectile.setText(typeAspect12);
        txtTriDectile.setForeground(getColorTypeAspect(typeAspect12));
        lblColorTridectile.setBackground(colorAspect12);
        chkSesquiSquare.setSelected(shownAspect13);
        txtSesquiSquare.setText(typeAspect13);
        txtSesquiSquare.setForeground(getColorTypeAspect(typeAspect13));
        lblColorSesquiSquare.setBackground(colorAspect13);
        chkBiQuintile.setSelected(shownAspect14);
        txtBiquintile.setText(typeAspect14);
        txtBiquintile.setForeground(getColorTypeAspect(typeAspect14));
        lblColorBiQuintile.setBackground(colorAspect14);
        chkInconjunct.setSelected(shownAspect15);
        txtInconjunct.setText(typeAspect15);
        txtInconjunct.setForeground(getColorTypeAspect(typeAspect15));
        lblColorInconjunct.setBackground(colorAspect15);
        chkQuadriNonagon.setSelected(shownAspect16);
        txtQuadriNonagon.setText(typeAspect16);
        txtQuadriNonagon.setForeground(getColorTypeAspect(typeAspect16));
        lblColorQuadriNonagon.setBackground(colorAspect16);

        //Aspected planets
        chkAspectSun.setSelected(aspectsSun);
        chkAspectMoon.setSelected(aspectsMoon);
        chkAspectMercury.setSelected(aspectsMercury);
        chkAspectVenus.setSelected(aspectsVenus);
        chkAspectMars.setSelected(aspectsMars);
        chkAspectJupiter.setSelected(aspectsJupiter);
        chkAspectSaturn.setSelected(aspectsSaturn);
        chkAspectUranus.setSelected(aspectsUranus);
        chkAspectNeptune.setSelected(aspectsNeptune);
        chkAspectPluto.setSelected(aspectsPluto);
        chkAspectGaia.setSelected(aspectsGaia);
        chkAspectNodes.setSelected(aspectsNorthNode);
        chkAspectLilith.setSelected(aspectsLilith);
        chkAspectEast.setSelected(aspectsEast);
        chkAspectZenith.setSelected(aspectsZenith);
        chkAspectVertex.setSelected(aspectsVertex);
        chkAspectVulcan.setSelected(aspectsVulcan);
        chkAspectCeres.setSelected(aspectsCeres);
        chkAspectPallas.setSelected(aspectsPallas);
        chkAspectJuno.setSelected(aspectsJuno);
        chkAspectVesta.setSelected(aspectsVesta);
        chkAspectChiron.setSelected(aspectsChiron);
        chkAspectAS.setSelected(aspectsAS);
        chkAspectMC.setSelected(aspectsMC);
        chkAspectOtherPoint.setSelected(aspectsOtherPoint);

        //Orbs
        txtOrbLumLum.setText(orbLightLight);
        txtOrbLumIndiv.setText(orbLightTell);
        txtOrbLumJS.setText(orbLightOtherInd);
        txtOrbLumCol.setText(orbLightColl);
        txtOrbLumVirtMaj.setText(orbLightVirtMax);
        txtOrbLumVirtMin.setText(orbLightVirtMin);
        txtOrbIndivIndiv.setText(orbTellTell);
        txtOrbIndivJS.setText(orbTellOtherInd);
        txtOrbIndivCol.setText(orbTellColl);
        txtOrbIndivVirtMaj.setText(orbTellVirtMax);
        txtOrbIndivVirtMin.setText(orbTellVirtMin);
        txtOrbJSJS.setText(orbOtherIndOtherInd);
        txtOrbJSCol.setText(orbOtherIndColl);
        txtOrbJSvirtMaj.setText(orbOtherIndVirtMax);
        txtOrbJSVirtMin.setText(orbOtherIndVirtMin);
        txtOrbColCol.setText(orbCollColl);
        txtOrbColVirtMaj.setText(orbCollVirtMax);
        txtOrbColVirtMin.setText(orbCollVirtMin);
        txtOrbVirtMajVirtMaj.setText(orbVirtMaxVirtMax);
        txtOrbVirtMajVirtMin.setText(orbVirtMaxVirtMin);
        txtOrbvirtMinVirtMin.setText(orbVirtMinVirtMin);

        //orbs divisors
        txtDivConjunction.setText(divConjuntion);
        txtDivSextile.setText(divSextil);
        txtDivSquare.setText(divSquare);
        txtDivTrine.setText(divTrine);
        txtDivOpposition.setText(divOpposition);
        txtDivOther.setText(divMin);


        if (limitMag.equals(""))
        {
            cboDefaultEvent.setSelectedIndex(-1);
            cboDefaultPlace.setSelectedIndex(-1);
            cboPlaceCycle.setSelectedIndex(-1);
            cboPlaceReturn.setSelectedIndex(-1);
        }
        int carretPos = txtCounter.getCaretPosition();
        if (bolAdding == true)
        {
            txtCounter.setText(bundle.getString("NewConfiguration"));
        }
        else
        {
            txtCounter.setText(String.valueOf(optionRow) + " / " + String.valueOf(nbOfRows));
        }
        int len = txtCounter.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounter.setCaretPosition(carretPos);

        //setSliderMinMax();
        bolSetting = false;
    }

    private Color getColorTypeAspect(String typeAspect)
    {
        if (typeAspect == null || typeAspect.equals(""))
        {
            return Color.BLACK;
        }
        char ch = typeAspect.charAt(0);
        if ((ch == 'n') || (ch == 'N'))
        {
            return neutralColor;
        }
        else if ((ch == 'd') || (ch == 'D'))
        {
            return dynamicColor;
        }
        else if ((ch == 'h') || (ch == 'H'))
        {
            return harmonicColor;
        }
        else
        {
            return Color.BLACK;
        }
    }

    private void setChart(int chart)
    {
        switch (chart)
        {
            case ChartKind.normal:
                chkNormal.setSelected(true);
                break;
            case ChartKind.local:
                chkAstronomical.setSelected(true);
                break;
            case ChartKind.symbolicDir:
                chkSymbolicDir.setSelected(true);
                break;
            case ChartKind.primaryDir:
                chkPrimaryDir.setSelected(true);
                break;
            case ChartKind.secondaryDir:
                chkSecondaryDir.setSelected(true);
                break;
            case ChartKind.transit:
                chkTransits.setSelected(true);
                break;
            case ChartKind.revolution:
                chkRevolution.setSelected(true);
                break;
            case ChartKind.cycle:
                chkCycle.setSelected(true);
                break;
            case ChartKind.synastry:
                chkSynastry.setSelected(true);
                break;
            case ChartKind.composite:
                chkComposite.setSelected(true);
                break;
            case ChartKind.free:
                chkFree.setSelected(true);
                break;
            case ChartKind.harmonic:
                chkHarmonic.setSelected(true);
                break;
            case ChartKind.seed:
                chkSeed.setSelected(true);
                break;
            case ChartKind.projective:
                chkProjective.setSelected(true);
                break;
            default:
                chkNormal.setSelected(true);
        }
    }

    private void setControls()
    {
        bolSetting = true;
        events = starLoginManager.getEvents(null);
        places = starLoginManager.getPlaces();
        options = starLoginManager.getOptions();
        ArrayList getFields = options.fieldsValues();
        DefaultComboBoxModel comboModel = (DefaultComboBoxModel) getFields.get(3);
        cboDefaultEvent.setModel(comboModel);
        StarLogin.Systeme.Data.Event event = starLoginManager.getEvent(option.getDefaultEvent());
        cboDefaultEvent.setSelectedItem(event.getSurname() + "; " + event.getOtherNames() + "; " + event.getEventName());

        DefaultComboBoxModel comboModel1 = starLoginManager.getListe("SELECT PlaceName FROM Places ORDER BY PlaceName");
        cboPlaceReturn.setModel(comboModel1);

        DefaultComboBoxModel comboModel2 = starLoginManager.getListe("SELECT PlaceName FROM Places ORDER BY PlaceName");
        cboPlaceCycle.setModel(comboModel2);

        DefaultComboBoxModel comboModel3 = starLoginManager.getListe("SELECT PlaceName FROM Places ORDER BY PlaceName");
        cboDefaultPlace.setModel(comboModel3);
        Place place = starLoginManager.getPlace(option.getDefaultPlace());
        cboDefaultPlace.setSelectedItem(place.getPlaceName());

        cboPlaceReturn.setKeySelectionManager(new MultiKeySelectionManager());
        cboPlaceCycle.setKeySelectionManager(new MultiKeySelectionManager());
        cboDefaultPlace.setKeySelectionManager(new MultiKeySelectionManager());
        cboDefaultEvent.setKeySelectionManager(new MultiKeySelectionManager());

        cboD2.removeAllItems();
        cboD1.removeAllItems();
        cboDS.removeAllItems();
        cboD2.addItem(bundle.getString("year"));
        cboD2.addItem(bundle.getString("month"));
        cboD2.addItem(bundle.getString("week"));
        cboD1.addItem(bundle.getString("year"));
        cboD1.addItem(bundle.getString("month"));
        cboD1.addItem(bundle.getString("week"));
        cboDS.addItem(bundle.getString("year"));
        cboDS.addItem(bundle.getString("month"));
        cboDS.addItem(bundle.getString("week"));
        cboD2.setSelectedIndex(0);
        cboD1.setSelectedIndex(0);
        cboDS.setSelectedIndex(0);
        cboPlanetReturn.removeAllItems();
        cboPlanet1Cycle.removeAllItems();
        cboPlanet2Cycle.removeAllItems();
        String planet;
        for (byte i = 0; i <= Planets.Lilith; i++)
        {
            if (i == Planets.Gaia)
            {
                i++;
            }
            planet = MainForm.planetName[i];
            cboPlanetReturn.addItem(planet);
            cboPlanet1Cycle.addItem(planet);
            cboPlanet2Cycle.addItem(planet);
        }
        planet = MainForm.planetName[Planets.Chiron];
        cboPlanetReturn.addItem(planet);
        cboPlanet1Cycle.addItem(planet);
        cboPlanet2Cycle.addItem(planet);
        cboPlanetReturn.setSelectedIndex(Planets.Sun);
        cboPlanet1Cycle.setSelectedIndex(Planets.Jupiter);
        cboPlanet2Cycle.setSelectedIndex(Planets.Saturn);
        cboPartRef.removeAllItems();
        cboPartPlus.removeAllItems();
        cboPartMinus.removeAllItems();
        for (byte i = 0; i <= Planets.MC; i++)
        {
            planet = MainForm.planetName[i];
            cboPartRef.addItem(planet);
            cboPartPlus.addItem(planet);
            cboPartMinus.addItem(planet);
        }

        Asteroids asteroids = starLoginManager.getAsteroids();
        getFields = asteroids.fieldsValues();
        comboModel = (DefaultComboBoxModel) getFields.get(1);
        cboAsteroid.setModel(comboModel);

        stars = starLoginManager.getStars();
        getFields = stars.fieldsValues();
        comboModel = (DefaultComboBoxModel) getFields.get(3);
        cboStarIdentity.setModel(comboModel);

        Comets comets = starLoginManager.getComets();
        getFields = comets.fieldsValues();
        comboModel = (DefaultComboBoxModel) getFields.get(1);
        cboComet.setModel(comboModel);

        parts = starLoginManager.getParts();
        getFields = parts.fieldsValues();
        comboModel = (DefaultComboBoxModel) getFields.get(1);
        cboPart.setModel(comboModel);

        unselectAllChartKinds();
        currentSelectedChart = ChartKind.all;
        chkNormal.setSelected(true);
        pnlChartColorChoice.setVisible(false);
        pnlAspectColorChoice.setVisible(false);
        chkHeliocentricNormal.setVisible(false);
        chkHeliocentricSidereal.setVisible(false);
        bolSetting = false;
    }

    private void txtCounterKeyReleased(java.awt.event.KeyEvent evt)
    {
        if ((bolSetting == false) && (bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            String value = txtCounter.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            optionRow = new Integer(value).intValue();
            if (optionRow > nbOfRows)
            {
                optionRow = nbOfRows;
            }
            showOption(optionRow);
        }
    }

    private void setPlanetsPanel()
    {


        pnlPlanets.setLayout(new java.awt.BorderLayout());

        //jPanel48.setAlignmentX(0.0F);
        //jPanel48.setAlignmentY(0.0F);
        jPanel48.setPreferredSize(new java.awt.Dimension(200, 600));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText(bundle.getString("Main"));
        //jLabel40.setAlignmentX(0.5F);
        jLabel40.setPreferredSize(new java.awt.Dimension(175, 18));
        jLabel40.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel40.setOpaque(true);
        jPanel48.add(jLabel40);

        chkSun.setSelected(true);
        chkSun.setText(bundle.getString("Sun"));
        chkSun.setPreferredSize(new java.awt.Dimension(175, 24));
        chkSun.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSunActionPerformed(evt);
            }
        });

        jPanel48.add(chkSun);

        chkMoon.setSelected(true);
        chkMoon.setText(bundle.getString("Moon"));
        chkMoon.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMoon.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkMoonActionPerformed(evt);
            }
        });

        jPanel48.add(chkMoon);

        chkMercury.setSelected(true);
        chkMercury.setText(bundle.getString("Mercury"));
        chkMercury.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMercury.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkMercuryActionPerformed(evt);
            }
        });

        jPanel48.add(chkMercury);

        chkVenus.setSelected(true);
        chkVenus.setText(bundle.getString("Venus"));
        chkVenus.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVenus.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkVenusActionPerformed(evt);
            }
        });

        jPanel48.add(chkVenus);

        chkMars.setSelected(true);
        chkMars.setText(bundle.getString("Mars"));
        chkMars.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMars.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkMarsActionPerformed(evt);
            }
        });

        jPanel48.add(chkMars);

        chkJupiter.setSelected(true);
        chkJupiter.setText(bundle.getString("Jupiter"));
        chkJupiter.setPreferredSize(new java.awt.Dimension(175, 24));
        chkJupiter.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkJupiterActionPerformed(evt);
            }
        });

        jPanel48.add(chkJupiter);

        chkSaturn.setSelected(true);
        chkSaturn.setText(bundle.getString("Saturn"));
        chkSaturn.setPreferredSize(new java.awt.Dimension(175, 24));
        chkSaturn.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSaturnActionPerformed(evt);
            }
        });

        jPanel48.add(chkSaturn);

        chkUranus.setSelected(true);
        chkUranus.setText(bundle.getString("Uranus"));
        chkUranus.setPreferredSize(new java.awt.Dimension(175, 24));
        chkUranus.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkUranusActionPerformed(evt);
            }
        });

        jPanel48.add(chkUranus);

        chkNeptune.setSelected(true);
        chkNeptune.setText(bundle.getString("Neptune"));
        chkNeptune.setPreferredSize(new java.awt.Dimension(175, 24));
        chkNeptune.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkNeptuneActionPerformed(evt);
            }
        });

        jPanel48.add(chkNeptune);

        chkPluto.setSelected(true);
        chkPluto.setText(bundle.getString("Pluto"));
        chkPluto.setPreferredSize(new java.awt.Dimension(175, 24));
        chkPluto.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkPlutoActionPerformed(evt);
            }
        });

        jPanel48.add(chkPluto);

        jPanel54.add(jPanel48);

        jPanel50.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel50.setMaximumSize(new java.awt.Dimension(200, 600));
        jPanel50.setPreferredSize(new java.awt.Dimension(200, 600));
        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setText(bundle.getString("Other"));
        jLabel44.setPreferredSize(new java.awt.Dimension(175, 18));
        jLabel44.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel44.setOpaque(true);
        jPanel50.add(jLabel44);

        chkGaia.setText(bundle.getString("Gaia"));
        chkGaia.setPreferredSize(new java.awt.Dimension(175, 24));
        chkGaia.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkGaiaActionPerformed(evt);
            }
        });

        jPanel50.add(chkGaia);

        chkNN.setSelected(true);
        chkNN.setText(bundle.getString("NorthNode"));
        chkNN.setPreferredSize(new java.awt.Dimension(175, 24));
        chkNN.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkNNActionPerformed(evt);
            }
        });

        jPanel50.add(chkNN);

        jPanel56.setLayout(new javax.swing.BoxLayout(jPanel56, javax.swing.BoxLayout.X_AXIS));

        jPanel56.setPreferredSize(new java.awt.Dimension(175, 24));
        chkLilith.setSelected(true);
        chkLilith.setText(bundle.getString("Lilith"));
        chkLilith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkLilithActionPerformed(evt);
            }
        });

        jPanel56.add(chkLilith);

        chkTrueLilith.setSelected(true);
        chkTrueLilith.setText(bundle.getString("True"));
        chkTrueLilith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkTrueLilithActionPerformed(evt);
            }
        });

        jPanel56.add(chkTrueLilith);

        jPanel50.add(jPanel56);

        chkEast.setText(bundle.getString("East"));
        chkEast.setPreferredSize(new java.awt.Dimension(175, 24));
        chkEast.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkEastActionPerformed(evt);
            }
        });

        jPanel50.add(chkEast);

        chkZenith.setText(bundle.getString("Zenith"));
        chkZenith.setPreferredSize(new java.awt.Dimension(175, 24));
        chkZenith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkZenithActionPerformed(evt);
            }
        });

        jPanel50.add(chkZenith);

        chkVertex.setText(bundle.getString("Vertex"));
        chkVertex.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVertex.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkVertexActionPerformed(evt);
            }
        });

        jPanel50.add(chkVertex);

        chkVulcan.setText(bundle.getString("Vulcan"));
        chkVulcan.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVulcan.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkVulcanActionPerformed(evt);
            }
        });

        jPanel50.add(chkVulcan);

        chkCeres.setText(bundle.getString("Ceres"));
        chkCeres.setPreferredSize(new java.awt.Dimension(175, 24));
        chkCeres.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkCeresActionPerformed(evt);
            }
        });

        jPanel50.add(chkCeres);

        chkPallas.setText(bundle.getString("Pallas"));
        chkPallas.setPreferredSize(new java.awt.Dimension(175, 24));
        chkPallas.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkPallasActionPerformed(evt);
            }
        });

        jPanel50.add(chkPallas);

        chkJuno.setText(bundle.getString("Juno"));
        chkJuno.setPreferredSize(new java.awt.Dimension(175, 24));
        chkJuno.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkJunoActionPerformed(evt);
            }
        });

        jPanel50.add(chkJuno);

        chkVesta.setText(bundle.getString("Vesta"));
        chkVesta.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVesta.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkVestaActionPerformed(evt);
            }
        });

        jPanel50.add(chkVesta);

        chkChiron.setSelected(true);
        chkChiron.setText(bundle.getString("Chiron"));
        chkChiron.setPreferredSize(new java.awt.Dimension(175, 24));
        chkChiron.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkChironActionPerformed(evt);
            }
        });

        jPanel50.add(chkChiron);

        chkOtherPoint.setText(bundle.getString("OtherPoint"));
        chkOtherPoint.setPreferredSize(new java.awt.Dimension(175, 24));
        chkOtherPoint.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkOtherPointActionPerformed(evt);
            }
        });

        jPanel50.add(chkOtherPoint);

        jPanel54.add(jPanel50);

        pnlOtherPoint.setPreferredSize(new java.awt.Dimension(200, 600));
        pnlOtherPoint.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel125.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel125.setText(bundle.getString("OtherPoint"));
        jLabel125.setPreferredSize(new java.awt.Dimension(175, 18));
        jLabel125.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel125.setOpaque(true);
        pnlOtherPoint.add(jLabel125);

        optOtherPtStar.setText(bundle.getString("Star"));
        grpOtherPoint.add(optOtherPtStar);
        optOtherPtStar.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtStar.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optOtherPtStarActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(optOtherPtStar);

        pnlOtherPtStar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        pnlOtherPtStar.setPreferredSize(new java.awt.Dimension(175, 70));
        lblStarName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStarName.setPreferredSize(new java.awt.Dimension(175, 22));
        lblStarName.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblStarName.setOpaque(true);
        pnlOtherPtStar.add(lblStarName);

        cboStarIdentity.setPreferredSize(new java.awt.Dimension(175, 25));
        cboStarIdentity.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboStarIdentityActionPerformed(evt);
            }
        });

        pnlOtherPtStar.add(cboStarIdentity);

        pnlOtherPoint.add(pnlOtherPtStar);

        optOtherPtPart.setText(bundle.getString("ArabianPart"));
        grpOtherPoint.add(optOtherPtPart);
        optOtherPtPart.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtPart.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optOtherPtPartActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(optOtherPtPart);

        pnlOtherPtPart.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 5));

        pnlOtherPtPart.setPreferredSize(new java.awt.Dimension(175, 130));
        cboPart.setPreferredSize(new java.awt.Dimension(175, 25));
        cboPart.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboPartActionPerformed(evt);
            }
        });

        pnlOtherPtPart.add(cboPart);

        jLabel126.setFont(new java.awt.Font("Dialog", 1, 16));
        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("=");
        jLabel126.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel126.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel126.setOpaque(true);
        pnlOtherPtPart.add(jLabel126);

        cboPartRef.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartRef.setEnabled(false);
        pnlOtherPtPart.add(cboPartRef);

        jLabel127.setFont(new java.awt.Font("Dialog", 1, 16));
        jLabel127.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel127.setText("+");
        jLabel127.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel127.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel127.setOpaque(true);
        pnlOtherPtPart.add(jLabel127);

        cboPartPlus.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartPlus.setEnabled(false);
        pnlOtherPtPart.add(cboPartPlus);

        jLabel128.setFont(new java.awt.Font("Dialog", 1, 16));
        jLabel128.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel128.setText("-");
        jLabel128.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel128.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel128.setOpaque(true);
        pnlOtherPtPart.add(jLabel128);

        cboPartMinus.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartMinus.setEnabled(false);
        pnlOtherPtPart.add(cboPartMinus);

        pnlOtherPoint.add(pnlOtherPtPart);

        optOtherPtComet.setText(bundle.getString("Comet"));
        grpOtherPoint.add(optOtherPtComet);
        optOtherPtComet.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtComet.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optOtherPtCometActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(optOtherPtComet);

        cboComet.setPreferredSize(new java.awt.Dimension(175, 25));
        cboComet.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboCometActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(cboComet);

        optOtherPtAsteroid.setText(bundle.getString("Asteroid"));
        grpOtherPoint.add(optOtherPtAsteroid);
        optOtherPtAsteroid.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtAsteroid.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optOtherPtAsteroidActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(optOtherPtAsteroid);

        cboAsteroid.setPreferredSize(new java.awt.Dimension(175, 25));
        cboAsteroid.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboAsteroidActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(cboAsteroid);

        optOtherPtNone.setSelected(true);
        optOtherPtNone.setText(bundle.getString("None"));
        grpOtherPoint.add(optOtherPtNone);
        optOtherPtNone.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtNone.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optOtherPtNoneActionPerformed(evt);
            }
        });

        pnlOtherPoint.add(optOtherPtNone);

        jPanel54.add(pnlOtherPoint);

        jPanel52.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel52.setPreferredSize(new java.awt.Dimension(305, 600));
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText(bundle.getString("Display"));
        jLabel46.setPreferredSize(new java.awt.Dimension(300, 18));
        jLabel46.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel46.setOpaque(true);
        jPanel52.add(jLabel46);

        jPanel57.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jPanel57.setPreferredSize(new java.awt.Dimension(300, 85));
        chkStars.setText(bundle.getString("Stars"));
        chkStars.setPreferredSize(new java.awt.Dimension(300, 18));
        chkStars.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkStarsActionPerformed(evt);
            }
        });

        jPanel57.add(chkStars);

        sldStars.setForeground(java.awt.Color.black);
        sldStars.setMajorTickSpacing(2);
        sldStars.setMaximum(12);
        sldStars.setMinorTickSpacing(1);
        sldStars.setPaintTicks(true);
        sldStars.setValue(5);
        sldStars.setPreferredSize(new Dimension(300,18));
        sldStars.addChangeListener(new javax.swing.event.ChangeListener()
        {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                sldStarsStateChanged(evt);
            }
        });

        jPanel57.add(sldStars);

        jLabel50.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel50.setText("-");
        jLabel50.setPreferredSize(new java.awt.Dimension(150, 18));
        jLabel50.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jPanel57.add(jLabel50);

        jLabel52.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel52.setText("+");
        jLabel52.setPreferredSize(new java.awt.Dimension(150, 18));
        jLabel52.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jPanel57.add(jLabel52);

        jPanel52.add(jPanel57);

        chkConstellations.setText(bundle.getString("Constellations"));
        chkConstellations.setPreferredSize(new java.awt.Dimension(300, 18));
        chkConstellations.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkConstellationsActionPerformed(evt);
            }
        });

        jPanel52.add(chkConstellations);

        chkAsteroids.setSelected(true);
        chkAsteroids.setText(bundle.getString("Asteroids"));
        chkAsteroids.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAsteroids.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAsteroidsActionPerformed(evt);
            }
        });

        jPanel52.add(chkAsteroids);

        chkHouses.setSelected(true);
        chkHouses.setText(bundle.getString("Houses"));
        chkHouses.setPreferredSize(new java.awt.Dimension(300, 18));
        chkHouses.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkHousesActionPerformed(evt);
            }
        });

        jPanel52.add(chkHouses);

        chkAspects.setSelected(true);
        chkAspects.setText(bundle.getString("Aspects"));
        chkAspects.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAspects.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectsActionPerformed(evt);
            }
        });

        jPanel52.add(chkAspects);

        chkCoordinates.setText(bundle.getString("Coordinates"));
        chkCoordinates.setPreferredSize(new java.awt.Dimension(300, 18));
        chkCoordinates.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkCoordinatesActionPerformed(evt);
            }
        });

        jPanel52.add(chkCoordinates);

        chkStraightLines.setText(bundle.getString("StraightLines"));
        chkStraightLines.setPreferredSize(new java.awt.Dimension(300, 18));
        chkStraightLines.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkStraightLinesActionPerformed(evt);
            }
        });

        jPanel52.add(chkStraightLines);

        chkShaded.setSelected(true);
        chkShaded.setText(bundle.getString("ShadedColors"));
        chkShaded.setPreferredSize(new java.awt.Dimension(300, 18));
        chkShaded.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkShadedActionPerformed(evt);
            }
        });

        jPanel52.add(chkShaded);

        jPanel62.setPreferredSize(new java.awt.Dimension(300, 9));
        jPanel52.add(jPanel62);

        jPanel58.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel58.setPreferredSize(new java.awt.Dimension(300, 75));
        chkBarycenter.setText(bundle.getString("Barycenter"));
        chkBarycenter.setPreferredSize(new java.awt.Dimension(300, 18));
        chkBarycenter.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkBarycenterActionPerformed(evt);
            }
        });

        jPanel58.add(chkBarycenter);

        optSingleWeight.setSelected(true);
        optSingleWeight.setText(bundle.getString("SameWeight"));
        grpBarycenter.add(optSingleWeight);
        optSingleWeight.setPreferredSize(new java.awt.Dimension(300, 24));
        optSingleWeight.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optSingleWeightActionPerformed(evt);
            }
        });

        jPanel58.add(optSingleWeight);

        optDifferentWeights.setText(bundle.getString("DifferentWeights"));
        grpBarycenter.add(optDifferentWeights);
        optDifferentWeights.setPreferredSize(new java.awt.Dimension(300, 24));
        optDifferentWeights.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optDifferentWeightsActionPerformed(evt);
            }
        });

        jPanel58.add(optDifferentWeights);

        jPanel52.add(jPanel58);

        jPanel63.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel63.setPreferredSize(new java.awt.Dimension(300, 75));
        jLabel48.setText(bundle.getString("ZodiacDirection"));
        jLabel48.setAlignmentX(0.5F);
        jLabel48.setPreferredSize(new java.awt.Dimension(300, 18));
        jLabel48.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel48.setOpaque(true);
        jPanel63.add(jLabel48);

        optEastAS.setSelected(true);
        optEastAS.setText(bundle.getString("LeftAS"));
        grpZodDir.add(optEastAS);
        optEastAS.setPreferredSize(new java.awt.Dimension(300, 24));
        optEastAS.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optEastASActionPerformed(evt);
            }
        });

        jPanel63.add(optEastAS);

        optEastAries.setText(bundle.getString("LeftAries"));
        grpZodDir.add(optEastAries);
        optEastAries.setPreferredSize(new java.awt.Dimension(300, 24));
        optEastAries.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optEastAriesActionPerformed(evt);
            }
        });

        jPanel63.add(optEastAries);

        jPanel52.add(jPanel63);

        chkAspectsSymbol.setText(bundle.getString("AspectsSymbol"));
        chkAspectsSymbol.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAspectsSymbol.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectsSymbolActionPerformed(evt);
            }
        });

        jPanel52.add(chkAspectsSymbol);

        chkSignsName.setText(bundle.getString("SignsName"));
        chkSignsName.setPreferredSize(new java.awt.Dimension(300, 18));
        chkSignsName.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSignsNameActionPerformed(evt);
            }
        });

        jPanel52.add(chkSignsName);

        chkHousesCoord.setText(bundle.getString("HousesCoords"));
        chkHousesCoord.setPreferredSize(new java.awt.Dimension(300, 18));
        chkHousesCoord.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkHousesCoordActionPerformed(evt);
            }
        });

        jPanel52.add(chkHousesCoord);

        jPanel54.add(jPanel52);

        pnlPlanets.add(jPanel54, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Planets", null, pnlPlanets, "");
    }

    private void setChartLookPanel()
    {
        pnlChartLook.setLayout(new java.awt.BorderLayout());

        jPanel5.setLayout(new java.awt.BorderLayout());


        jPanel5.setPreferredSize(new java.awt.Dimension(220, 632));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        jPanel6.setPreferredSize(new java.awt.Dimension(210, 632));

        jPanel6.setBorder(new javax.swing.border.EtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText(bundle.getString("Colors"));
        jLabel11.setPreferredSize(new java.awt.Dimension(185, 18));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel11.setOpaque(true);
        jPanel6.add(jLabel11);

        jPanel7.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText(bundle.getString("Sun"));
        jLabel13.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel13.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel13.setOpaque(true);
        jPanel7.add(jLabel13);

        lblColorSun.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorSun.setText("A");
        lblColorSun.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblColorSun.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorSun.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSun.setOpaque(true);
        lblColorSun.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSunMouseClicked(evt);
            }
        });

        jPanel7.add(lblColorSun);

        jPanel6.add(jPanel7);

        jPanel8.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText(bundle.getString("Moon"));
        jLabel29.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel29.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel29.setOpaque(true);
        jPanel8.add(jLabel29);

        lblColorMoon.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorMoon.setText("B");
        lblColorMoon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMoon.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMoon.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorMoon.setOpaque(true);
        lblColorMoon.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorMoonMouseClicked(evt);
            }
        });

        jPanel8.add(lblColorMoon);

        jPanel6.add(jPanel8);

        jPanel9.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setText(bundle.getString("Mercury"));
        jLabel31.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel31.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel31.setOpaque(true);
        jPanel9.add(jLabel31);

        lblColorMercury.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorMercury.setText("C");
        lblColorMercury.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMercury.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMercury.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorMercury.setOpaque(true);
        lblColorMercury.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorMercuryMouseClicked(evt);
            }
        });

        jPanel9.add(lblColorMercury);

        jPanel6.add(jPanel9);

        jPanel10.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText(bundle.getString("Venus"));
        jLabel33.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel33.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel33.setOpaque(true);
        jPanel10.add(jLabel33);

        lblColorVenus.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorVenus.setText("D");
        //lblColorVenus.setBackground(new java.awt.Color(255, 0, 204));
        lblColorVenus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorVenus.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorVenus.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorVenus.setOpaque(true);
        lblColorVenus.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorVenusMouseClicked(evt);
            }
        });

        jPanel10.add(lblColorVenus);

        jPanel6.add(jPanel10);

        jPanel11.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText(bundle.getString("Mars"));
        jLabel35.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel35.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel35.setOpaque(true);
        jPanel11.add(jLabel35);

        lblColorMars.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorMars.setText("E");
        lblColorMars.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMars.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMars.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorMars.setOpaque(true);
        lblColorMars.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorMarsMouseClicked(evt);
            }
        });

        jPanel11.add(lblColorMars);

        jPanel6.add(jPanel11);

        jPanel14.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setText(bundle.getString("Jupiter"));
        jLabel37.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel37.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel37.setOpaque(true);
        jPanel14.add(jLabel37);

        lblColorJupiter.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorJupiter.setText("F");
        lblColorJupiter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorJupiter.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblColorJupiter.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorJupiter.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorJupiter.setOpaque(true);
        lblColorJupiter.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorJupiterMouseClicked(evt);
            }
        });

        jPanel14.add(lblColorJupiter);

        jPanel6.add(jPanel14);

        jPanel15.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText(bundle.getString("Saturn"));
        jLabel39.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel39.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel39.setOpaque(true);
        jPanel15.add(jLabel39);

        lblColorSaturn.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorSaturn.setText("G");
        lblColorSaturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSaturn.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorSaturn.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSaturn.setOpaque(true);
        lblColorSaturn.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSaturnMouseClicked(evt);
            }
        });

        jPanel15.add(lblColorSaturn);

        jPanel6.add(jPanel15);

        jPanel16.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setText(bundle.getString("Uranus"));
        jLabel41.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel41.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel41.setOpaque(true);
        jPanel16.add(jLabel41);

        lblColorUranus.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorUranus.setText("H");
        lblColorUranus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorUranus.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorUranus.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorUranus.setOpaque(true);
        lblColorUranus.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorUranusMouseClicked(evt);
            }
        });

        jPanel16.add(lblColorUranus);

        jPanel6.add(jPanel16);

        jPanel17.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setText(bundle.getString("Neptune"));
        jLabel43.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel43.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel43.setOpaque(true);
        jPanel17.add(jLabel43);

        lblColorNeptune.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorNeptune.setText("I");
        lblColorNeptune.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNeptune.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNeptune.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorNeptune.setOpaque(true);
        lblColorNeptune.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorNeptuneMouseClicked(evt);
            }
        });

        jPanel17.add(lblColorNeptune);

        jPanel6.add(jPanel17);

        jPanel18.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText(bundle.getString("Pluto"));
        jLabel45.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel45.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel45.setOpaque(true);
        jPanel18.add(jLabel45);

        lblColorPluto.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorPluto.setText("J");
        lblColorPluto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPluto.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorPluto.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorPluto.setOpaque(true);
        lblColorPluto.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorPlutoMouseClicked(evt);
            }
        });

        jPanel18.add(lblColorPluto);

        jPanel6.add(jPanel18);

        jPanel19.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText(bundle.getString("Gaia"));
        jLabel47.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel47.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel47.setOpaque(true);
        jPanel19.add(jLabel47);

        lblColorGaia.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorGaia.setText("K");
        lblColorGaia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorGaia.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorGaia.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorGaia.setOpaque(true);
        lblColorGaia.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorGaiaMouseClicked(evt);
            }
        });

        jPanel19.add(lblColorGaia);

        jPanel6.add(jPanel19);

        jPanel20.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setText(bundle.getString("Nodes"));
        jLabel49.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel49.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel49.setOpaque(true);
        jPanel20.add(jLabel49);

        lblColorNodes.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorNodes.setText("L Z");
        lblColorNodes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNodes.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblColorNodes.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNodes.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorNodes.setOpaque(true);
        lblColorNodes.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorNodesMouseClicked(evt);
            }
        });

        jPanel20.add(lblColorNodes);

        jPanel6.add(jPanel20);

        jPanel21.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setText(bundle.getString("Houses"));
        jLabel51.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel51.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel51.setOpaque(true);
        jPanel21.add(jLabel51);

        lblColorHouses.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorHouses.setText("X   Y");
        lblColorHouses.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorHouses.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorHouses.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorHouses.setOpaque(true);
        lblColorHouses.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorHousesMouseClicked(evt);
            }
        });

        jPanel21.add(lblColorHouses);

        jPanel6.add(jPanel21);

        jPanel22.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setText(bundle.getString("Asteroids"));
        jLabel53.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel53.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel53.setOpaque(true);
        jPanel22.add(jLabel53);

        lblColorAsteroids.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorAsteroids.setText("S T U V W");
        lblColorAsteroids.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorAsteroids.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorAsteroids.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorAsteroids.setOpaque(true);
        lblColorAsteroids.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorAsteroidsMouseClicked(evt);
            }
        });

        jPanel22.add(lblColorAsteroids);

        jPanel6.add(jPanel22);

        jPanel23.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel55.setText(bundle.getString("Vulcan"));
        jLabel55.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel55.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel55.setOpaque(true);
        jPanel23.add(jLabel55);

        lblColorVulcan.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorVulcan.setText("Q");
        lblColorVulcan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorVulcan.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorVulcan.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorVulcan.setOpaque(true);
        lblColorVulcan.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorVulcanMouseClicked(evt);
            }
        });

        jPanel23.add(lblColorVulcan);

        jPanel6.add(jPanel23);

        jPanel24.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText(bundle.getString("Text"));
        jLabel57.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel57.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel57.setOpaque(true);
        jPanel24.add(jLabel57);

        lblColorText.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorText.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorText.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorText.setOpaque(true);
        lblColorText.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorTextMouseClicked(evt);
            }
        });

        jPanel24.add(lblColorText);

        jPanel6.add(jPanel24);

        jPanel25.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel59.setText(bundle.getString("Fire"));
        jLabel59.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel59.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel59.setOpaque(true);
        jPanel25.add(jLabel59);

        lblColorFire.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorFire.setText("s w {");
        lblColorFire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFire.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorFire.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorFire.setOpaque(true);
        lblColorFire.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorFireMouseClicked(evt);
            }
        });

        jPanel25.add(lblColorFire);

        jPanel6.add(jPanel25);

        jPanel26.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel61.setText(bundle.getString("Earth"));
        jLabel61.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel61.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel61.setOpaque(true);
        jPanel26.add(jLabel61);

        lblColorEarth.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorEarth.setText("t x |");
        lblColorEarth.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorEarth.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblColorEarth.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorEarth.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorEarth.setOpaque(true);
        lblColorEarth.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorEarthMouseClicked(evt);
            }
        });

        jPanel26.add(lblColorEarth);

        jPanel6.add(jPanel26);

        jPanel27.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setText(bundle.getString("Air"));
        jLabel63.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel63.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel63.setOpaque(true);
        jPanel27.add(jLabel63);

        lblColorAir.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorAir.setText("u y }");
        lblColorAir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorAir.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorAir.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorAir.setOpaque(true);
        lblColorAir.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorAirMouseClicked(evt);
            }
        });

        jPanel27.add(lblColorAir);

        jPanel6.add(jPanel27);

        jPanel28.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setText(bundle.getString("Water"));
        jLabel65.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel65.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel65.setOpaque(true);
        jPanel28.add(jLabel65);

        lblColorWater.setFont(new java.awt.Font("StarLogin", 0, 13));
        lblColorWater.setText("v z ~");
        lblColorWater.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorWater.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorWater.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorWater.setOpaque(true);
        lblColorWater.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorWaterMouseClicked(evt);
            }
        });

        jPanel28.add(lblColorWater);

        jPanel6.add(jPanel28);

        jPanel30.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel67.setText(bundle.getString("Neutral"));
        jLabel67.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel67.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel67.setOpaque(true);
        jPanel30.add(jLabel67);

        lblColorNeutral.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNeutral.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNeutral.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorNeutral.setOpaque(true);
        lblColorNeutral.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorNeutralMouseClicked(evt);
            }
        });

        jPanel30.add(lblColorNeutral);

        jPanel6.add(jPanel30);

        jPanel32.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setText(bundle.getString("Dynamic"));
        jLabel69.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel69.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel69.setOpaque(true);
        jPanel32.add(jLabel69);

        lblColorDynamic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorDynamic.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorDynamic.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorDynamic.setOpaque(true);
        lblColorDynamic.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorDynamicMouseClicked(evt);
            }
        });

        jPanel32.add(lblColorDynamic);

        jPanel6.add(jPanel32);

        jPanel34.setPreferredSize(new java.awt.Dimension(200, 23));
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText(bundle.getString("Harmonic"));
        jLabel71.setPreferredSize(new java.awt.Dimension(100, 18));
        jLabel71.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel71.setOpaque(true);
        jPanel34.add(jLabel71);

        lblColorHarmonic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorHarmonic.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorHarmonic.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorHarmonic.setOpaque(true);
        lblColorHarmonic.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorHarmonicMouseClicked(evt);
            }
        });

        jPanel34.add(lblColorHarmonic);

        jPanel6.add(jPanel34);

        jPanel5.add(jPanel6, java.awt.BorderLayout.CENTER);

        pnlChartLook.add(jPanel5, java.awt.BorderLayout.WEST);

        jPanel36.setLayout(new java.awt.BorderLayout());
        jPanel36.setPreferredSize(new java.awt.Dimension(224, 622));

        jPanel38.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 1));
        jPanel38.setBorder(new javax.swing.border.EtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel38.setPreferredSize(new java.awt.Dimension(214, 612));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText(bundle.getString("Sizes"));
        jLabel22.setAlignmentX(0.5F);
        jLabel22.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel22.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel22.setOpaque(true);
        jPanel38.add(jLabel22);

        jPanel40.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jPanel40.setPreferredSize(new java.awt.Dimension(210, 150));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText(bundle.getString("Zodiac"));
        jLabel30.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel30.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel30.setOpaque(true);
        jPanel40.add(jLabel30);

        sldZodiac.setForeground(java.awt.Color.black);
        sldZodiac.setMajorTickSpacing(10);
        sldZodiac.setMinimum(50);
        sldZodiac.setMinorTickSpacing(5);
        sldZodiac.setPaintLabels(true);
        sldZodiac.setPaintTicks(true);
        sldZodiac.setValue(75);
        sldZodiac.addChangeListener(new javax.swing.event.ChangeListener()
        {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                sldZodiacStateChanged(evt);
            }
        });

        jPanel40.add(sldZodiac);

        lblZodiacSize.setFont(new java.awt.Font("Dialog", 0, 18));
        lblZodiacSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblZodiacSize.setText("%");
        lblZodiacSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblZodiacSize.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jPanel40.add(lblZodiacSize);

        jPanel38.add(jPanel40);

        jPanel42.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel42.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText(bundle.getString("Signs"));
        jLabel34.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel34.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel34.setOpaque(true);
        jPanel42.add(jLabel34);

        sldSigns.setForeground(java.awt.Color.black);
        sldSigns.setMajorTickSpacing(2);
        sldSigns.setMaximum(72);
        sldSigns.setMinimum(10);
        sldSigns.setMinorTickSpacing(1);
        sldSigns.setPaintTicks(true);
        sldSigns.setValue(20);
        sldSigns.addChangeListener(new javax.swing.event.ChangeListener()
        {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                sldSignsStateChanged(evt);
            }
        });

        jPanel42.add(sldSigns);

        lblSignSize.setFont(new java.awt.Font("StarLogin", 1, 20));
        lblSignSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSignSize.setText("}");
        lblSignSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblSignSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel42.add(lblSignSize);

        jPanel38.add(jPanel42);

        jPanel44.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel44.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText(bundle.getString("Planets"));
        jLabel38.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel38.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel38.setOpaque(true);
        jPanel44.add(jLabel38);

        sldPlanets.setMajorTickSpacing(2);
        sldPlanets.setMaximum(72);
        sldPlanets.setMinimum(8);
        sldPlanets.setMinorTickSpacing(1);
        sldPlanets.setPaintTicks(true);
        sldPlanets.setValue(12);
        sldPlanets.addChangeListener(new javax.swing.event.ChangeListener()
        {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                sldPlanetsStateChanged(evt);
            }
        });

        jPanel44.add(sldPlanets);

        lblPlanetSize.setFont(new java.awt.Font("StarLogin", 1, 14));
        lblPlanetSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPlanetSize.setText("H");
        lblPlanetSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblPlanetSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel44.add(lblPlanetSize);

        jPanel38.add(jPanel44);

        jPanel46.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel46.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText(bundle.getString("Characters"));
        jLabel42.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel42.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel42.setOpaque(true);
        jPanel46.add(jLabel42);

        sldCharacters.setForeground(java.awt.Color.black);
        sldCharacters.setMajorTickSpacing(2);
        sldCharacters.setMaximum(48);
        sldCharacters.setMinimum(8);
        sldCharacters.setMinorTickSpacing(1);
        sldCharacters.setPaintTicks(true);
        sldCharacters.setValue(10);
        sldCharacters.addChangeListener(new javax.swing.event.ChangeListener()
        {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                sldCharactersStateChanged(evt);
            }
        });

        jPanel46.add(sldCharacters);

        lblCharactersSize.setFont(new java.awt.Font("Arial", 0, 10));
        lblCharactersSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCharactersSize.setText("18\u00b023'");
        lblCharactersSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblCharactersSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel46.add(lblCharactersSize);

        jPanel38.add(jPanel46);

        jPanel36.add(jPanel38, java.awt.BorderLayout.CENTER);

        pnlChartLook.add(jPanel36, java.awt.BorderLayout.EAST);

        pnlChartColorChoice.setLayout(new javax.swing.BoxLayout(pnlChartColorChoice, javax.swing.BoxLayout.Y_AXIS));

        pnlChartLook.add(pnlChartColorChoice, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Chart look", null, pnlChartLook, "");
    }

    private void setHouseSysPanel()
    {
        pnlHouseSystem.setLayout(new java.awt.BorderLayout());

        jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel4.setPreferredSize(new java.awt.Dimension(250, 511));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        grpHouseSystem.add(optAncient);
        optAncient.setText(bundle.getString("Ancient")); // NOI18N
        optAncient.setMaximumSize(new java.awt.Dimension(235, 24));
        optAncient.setMinimumSize(new java.awt.Dimension(235, 24));
        optAncient.setPreferredSize(new java.awt.Dimension(235, 24));
        optAncient.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAncientActionPerformed(evt);
            }
        });
        jPanel4.add(optAncient);

        grpHouseSystem.add(optTwoHours);
        optTwoHours.setText(bundle.getString("TwoHours")); // NOI18N
        optTwoHours.setMaximumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setMinimumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setPreferredSize(new java.awt.Dimension(235, 24));
        optTwoHours.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optTwoHoursActionPerformed(evt);
            }
        });
        jPanel4.add(optTwoHours);

        grpHouseSystem.add(optSemiAngular);
        optSemiAngular.setText(bundle.getString("SemiAngular")); // NOI18N
        optSemiAngular.setMaximumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setMinimumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setPreferredSize(new java.awt.Dimension(235, 24));
        optSemiAngular.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSemiAngularActionPerformed(evt);
            }
        });
        jPanel4.add(optSemiAngular);

        grpHouseSystem.add(optCampanus);
        optCampanus.setSelected(true);
        optCampanus.setText("Campanus");
        optCampanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optCampanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optCampanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optCampanus.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optCampanusActionPerformed(evt);
            }
        });
        jPanel4.add(optCampanus);

        grpHouseSystem.add(optEquatorialRegular);
        optEquatorialRegular.setText(bundle.getString("EquatorialRegular")); // NOI18N
        optEquatorialRegular.setMaximumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setMinimumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setPreferredSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optEquatorialRegularActionPerformed(evt);
            }
        });
        jPanel4.add(optEquatorialRegular);

        grpHouseSystem.add(optColinEvans);
        optColinEvans.setText(bundle.getString("ColinEvans")); // NOI18N
        optColinEvans.setMaximumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setMinimumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setPreferredSize(new java.awt.Dimension(235, 24));
        optColinEvans.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optColinEvansActionPerformed(evt);
            }
        });
        jPanel4.add(optColinEvans);

        grpHouseSystem.add(optBazchenoff);
        optBazchenoff.setText(bundle.getString("Bazchenoff")); // NOI18N
        optBazchenoff.setMaximumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setMinimumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setPreferredSize(new java.awt.Dimension(235, 24));
        optBazchenoff.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optBazchenoffActionPerformed(evt);
            }
        });
        jPanel4.add(optBazchenoff);

        grpHouseSystem.add(optMaternusAs);
        optMaternusAs.setText("Maternus / AS");
        optMaternusAs.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusAs.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusAsActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusAs);

        grpHouseSystem.add(optMaternusMC);
        optMaternusMC.setText("Maternus / MC");
        optMaternusMC.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusMC.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusMCActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusMC);

        grpHouseSystem.add(optNodal);
        optNodal.setText(bundle.getString("Nodal")); // NOI18N
        optNodal.setMaximumSize(new java.awt.Dimension(235, 24));
        optNodal.setMinimumSize(new java.awt.Dimension(235, 24));
        optNodal.setPreferredSize(new java.awt.Dimension(235, 24));
        optNodal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optNodalActionPerformed(evt);
            }
        });
        jPanel4.add(optNodal);

        grpHouseSystem.add(optPorpyre);
        optPorpyre.setText("Porphyre");
        optPorpyre.setMaximumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setMinimumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setPreferredSize(new java.awt.Dimension(235, 24));
        optPorpyre.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPorpyreActionPerformed(evt);
            }
        });
        jPanel4.add(optPorpyre);

        grpHouseSystem.add(optRegiomontanus);
        optRegiomontanus.setText("Regiomontanus");
        optRegiomontanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optRegiomontanusActionPerformed(evt);
            }
        });
        jPanel4.add(optRegiomontanus);

        grpHouseSystem.add(optSolar);
        optSolar.setText(bundle.getString("Solar")); // NOI18N
        optSolar.setMaximumSize(new java.awt.Dimension(235, 24));
        optSolar.setMinimumSize(new java.awt.Dimension(235, 24));
        optSolar.setPreferredSize(new java.awt.Dimension(235, 24));
        optSolar.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSolarActionPerformed(evt);
            }
        });
        jPanel4.add(optSolar);

        grpHouseSystem.add(optWiesel);
        optWiesel.setText("Wiesel");
        optWiesel.setMaximumSize(new java.awt.Dimension(235, 24));
        optWiesel.setMinimumSize(new java.awt.Dimension(235, 24));
        optWiesel.setPreferredSize(new java.awt.Dimension(235, 24));
        optWiesel.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optWieselActionPerformed(evt);
            }
        });
        jPanel4.add(optWiesel);

        grpHouseSystem.add(optZenithal);
        optZenithal.setText(bundle.getString("Zenithal")); // NOI18N
        optZenithal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZenithal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZenithal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZenithal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZenithalActionPerformed(evt);
            }
        });
        jPanel4.add(optZenithal);

        grpHouseSystem.add(optZodiacal);
        optZodiacal.setText(bundle.getString("Zodiacal")); // NOI18N
        optZodiacal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZodiacal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZodiacalActionPerformed(evt);
            }
        });
        jPanel4.add(optZodiacal);

        jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator1.setMaximumSize(new java.awt.Dimension(32767, 2));
        jSeparator1.setPreferredSize(new java.awt.Dimension(175, 2));
        jPanel4.add(jSeparator1);

        grpHouseSystem.add(optAbenragel);
        optAbenragel.setText("Abenragel");
        optAbenragel.setMaximumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setMinimumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setPreferredSize(new java.awt.Dimension(235, 24));
        optAbenragel.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAbenragelActionPerformed(evt);
            }
        });
        jPanel4.add(optAbenragel);

        grpHouseSystem.add(optAlbategnius);
        optAlbategnius.setText("Albategnius");
        optAlbategnius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlbategnius.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlbategniusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlbategnius);

        grpHouseSystem.add(optAlcabitius);
        optAlcabitius.setText("Alcabitius");
        optAlcabitius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlcabitius.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlcabitiusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlcabitius);

        grpHouseSystem.add(optKoch);
        optKoch.setText("Koch");
        optKoch.setMaximumSize(new java.awt.Dimension(235, 24));
        optKoch.setMinimumSize(new java.awt.Dimension(235, 24));
        optKoch.setPreferredSize(new java.awt.Dimension(235, 24));
        optKoch.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optKochActionPerformed(evt);
            }
        });
        jPanel4.add(optKoch);

        grpHouseSystem.add(optPlacidus);
        optPlacidus.setText("Placidus");
        optPlacidus.setMaximumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setMinimumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setPreferredSize(new java.awt.Dimension(235, 24));
        optPlacidus.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPlacidusActionPerformed(evt);
            }
        });
        jPanel4.add(optPlacidus);

        pnlHouseSystem.add(jPanel4, java.awt.BorderLayout.WEST);

        tabSettings.addTab("Houses system", null, pnlHouseSystem, "");
    }

    private void setCoordSysPanel()
    {
        pnlCoordSystem.setLayout(new java.awt.BorderLayout());

        jPanel64b.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel2.setPreferredSize(new java.awt.Dimension(200, 75));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        grpGeoHelio.add(chkGeocentric);
        chkGeocentric.setSelected(true);
        chkGeocentric.setText(bundle.getString("Geocentric")); // NOI18N
        chkGeocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkGeocentric.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkGeocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkGeocentric);

        grpGeoHelio.add(chkHeliocentric);
        chkHeliocentric.setText(bundle.getString("Heliocentric")); // NOI18N
        chkHeliocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkHeliocentric);

        jPanel64b.add(jPanel2);

        jPanel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 0, 5));
        jPanel3.setPreferredSize(new java.awt.Dimension(210, 460));

        grpGeo.add(chkTropical);
        chkTropical.setSelected(true);
        chkTropical.setText(bundle.getString("Tropical")); // NOI18N
        chkTropical.setPreferredSize(new java.awt.Dimension(200, 31));
        chkTropical.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTropicalActionPerformed(evt);
            }
        });
        jPanel3.add(chkTropical);

        grpGeo.add(chkSidereal);
        chkSidereal.setText(bundle.getString("Sidereal")); // NOI18N
        chkSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkSidereal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkSidereal);

        grpGeo.add(chkEquatorial);
        chkEquatorial.setText(bundle.getString("Equatorial")); // NOI18N
        chkEquatorial.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEquatorial.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEquatorialActionPerformed(evt);
            }
        });
        jPanel3.add(chkEquatorial);

        grpGeo.add(chkEcliptic);
        chkEcliptic.setText(bundle.getString("Ecliptic")); // NOI18N
        chkEcliptic.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEcliptic.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEclipticActionPerformed(evt);
            }
        });
        jPanel3.add(chkEcliptic);

        grpGeo.add(chkLocal);
        chkLocal.setText(bundle.getString("Local")); // NOI18N
        chkLocal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkLocal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkLocalActionPerformed(evt);
            }
        });
        jPanel3.add(chkLocal);

        grpGeo.add(chkDomitudes);
        chkDomitudes.setText(bundle.getString("Domitudes")); // NOI18N
        chkDomitudes.setPreferredSize(new java.awt.Dimension(200, 31));
        chkDomitudes.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDomitudesActionPerformed(evt);
            }
        });
        jPanel3.add(chkDomitudes);

        grpHelio.add(chkHeliocentricNormal);
        chkHeliocentricNormal.setSelected(true);
        chkHeliocentricNormal.setText(bundle.getString("HeliocentricNormal")); // NOI18N
        chkHeliocentricNormal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricNormal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricNormalActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricNormal);

        grpHelio.add(chkHeliocentricSidereal);
        chkHeliocentricSidereal.setText(bundle.getString("HeliocentricSidereal")); // NOI18N
        chkHeliocentricSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricSidereal.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricSidereal);

        jPanel64b.add(jPanel3);

        pnlCoordSystem.add(jPanel64b, java.awt.BorderLayout.CENTER);
        tabSettings.addTab("Coordinates system", null, pnlCoordSystem, "");
    }

    private void mnuDeleteActionPerformed(java.awt.event.ActionEvent evt)
    {
       
        removeRec();
    }

    private void initComponents()
    {
        jPMenuDelete = new javax.swing.JPopupMenu();
        mnuDelete = new javax.swing.JMenuItem();
        mnuDelete.setText(bundle.getString("SUPPRIMER_L'ENREGISTREMENT_SELECTIONNE"));
        mnuDelete.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                mnuDeleteActionPerformed(evt);
            }
        });
        jPMenuDelete.add(mnuDelete);

        grpChartChoice = new javax.swing.ButtonGroup();
        grpSavedCharts = new javax.swing.ButtonGroup();
        grpGeoHelio = new javax.swing.ButtonGroup();
        grpGeo = new javax.swing.ButtonGroup();
        grpHelio = new javax.swing.ButtonGroup();
        grpHouseSystem = new javax.swing.ButtonGroup();
        grpAstronView = new javax.swing.ButtonGroup();
        grpBarycenter = new javax.swing.ButtonGroup();
        grpZodDir = new javax.swing.ButtonGroup();
        grpColorMode = new javax.swing.ButtonGroup();
        grpOtherPoint = new javax.swing.ButtonGroup();
        grpCompositeFrom = new javax.swing.ButtonGroup();
        tabSettings = new javax.swing.JTabbedPane();
        pnlChartKind = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jOptSingleSelection = new javax.swing.JRadioButton();
        jOptMultiSelection = new javax.swing.JRadioButton();
        btnSelectAll = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        chkNormal = new javax.swing.JCheckBox();
        jPanel29 = new javax.swing.JPanel();
        chkAstronomical = new javax.swing.JCheckBox();
        pnlLocal = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        optHorizon = new javax.swing.JRadioButton();
        optZenith = new javax.swing.JRadioButton();
        jPanel33 = new javax.swing.JPanel();
        chkSymbolicDir = new javax.swing.JCheckBox();
        pnlSymbolicDir = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        txtCorrespondDS = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtEqualsDS = new javax.swing.JTextField();
        cboDS = new javax.swing.JComboBox();
        jPanel35 = new javax.swing.JPanel();
        chkPrimaryDir = new javax.swing.JCheckBox();
        pnlPrimaryDir = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        txtCorrespondD1 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtEqualsD1 = new javax.swing.JTextField();
        cboD1 = new javax.swing.JComboBox();
        jPanel37 = new javax.swing.JPanel();
        chkSecondaryDir = new javax.swing.JCheckBox();
        pnlSecondaryDir = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txtCorrespondD2 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtEqualsD2 = new javax.swing.JTextField();
        cboD2 = new javax.swing.JComboBox();
        jPanel39 = new javax.swing.JPanel();
        chkTransits = new javax.swing.JCheckBox();
        jPanel41 = new javax.swing.JPanel();
        chkRevolution = new javax.swing.JCheckBox();
        pnlRevolution = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        chkPrecession = new javax.swing.JCheckBox();
        jLabel21 = new javax.swing.JLabel();
        cboPlanetReturn = new javax.swing.JComboBox();
        jPanel61 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        cboPlaceReturn = new javax.swing.JComboBox();
        jLabel19 = new javax.swing.JLabel();
        lblLatitudeReturn = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblLongitudeReturn = new javax.swing.JLabel();
        jPanel43 = new javax.swing.JPanel();
        chkCycle = new javax.swing.JCheckBox();
        pnlCycle = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        cboPlanet1Cycle = new javax.swing.JComboBox();
        jLabel27 = new javax.swing.JLabel();
        cboPlanet2Cycle = new javax.swing.JComboBox();
        jPanel66 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        cboPlaceCycle = new javax.swing.JComboBox();
        jLabel24 = new javax.swing.JLabel();
        lblLatitudeCycle = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        lblLongitudeCycle = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        chkSynastry = new javax.swing.JCheckBox();
        jPanel47 = new javax.swing.JPanel();
        chkComposite = new javax.swing.JCheckBox();
        pnlComposite = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtCompositeChartsNB = new javax.swing.JTextField();
        lblFrom = new javax.swing.JLabel();
        optCompositeFromAS = new javax.swing.JRadioButton();
        optCompositeFromMC = new javax.swing.JRadioButton();
        jPanel49 = new javax.swing.JPanel();
        chkFree = new javax.swing.JCheckBox();
        jPanel53 = new javax.swing.JPanel();
        chkHarmonic = new javax.swing.JCheckBox();
        pnlHarmonic = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtHarmonicNB = new javax.swing.JTextField();
        jPanel51 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        chkSeed = new javax.swing.JCheckBox();
        jPanel55 = new javax.swing.JPanel();
        chkProjective = new javax.swing.JCheckBox();
        pnlCoordSystem = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        chkGeocentric = new javax.swing.JRadioButton();
        chkHeliocentric = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        chkTropical = new javax.swing.JRadioButton();
        chkSidereal = new javax.swing.JRadioButton();
        chkEquatorial = new javax.swing.JRadioButton();
        chkEcliptic = new javax.swing.JRadioButton();
        chkLocal = new javax.swing.JRadioButton();
        chkDomitudes = new javax.swing.JRadioButton();
        chkHeliocentricNormal = new javax.swing.JRadioButton();
        chkHeliocentricSidereal = new javax.swing.JRadioButton();
        pnlHouseSystem = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        optAncient = new javax.swing.JRadioButton();
        optTwoHours = new javax.swing.JRadioButton();
        optSemiAngular = new javax.swing.JRadioButton();
        optCampanus = new javax.swing.JRadioButton();
        optEquatorialRegular = new javax.swing.JRadioButton();
        optColinEvans = new javax.swing.JRadioButton();
        optBazchenoff = new javax.swing.JRadioButton();
        optMaternusAs = new javax.swing.JRadioButton();
        optMaternusMC = new javax.swing.JRadioButton();
        optNodal = new javax.swing.JRadioButton();
        optPorpyre = new javax.swing.JRadioButton();
        optRegiomontanus = new javax.swing.JRadioButton();
        optSolar = new javax.swing.JRadioButton();
        optWiesel = new javax.swing.JRadioButton();
        optZenithal = new javax.swing.JRadioButton();
        optZodiacal = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        optAbenragel = new javax.swing.JRadioButton();
        optAlbategnius = new javax.swing.JRadioButton();
        optAlcabitius = new javax.swing.JRadioButton();
        optKoch = new javax.swing.JRadioButton();
        optPlacidus = new javax.swing.JRadioButton();
        pnlChartLook = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        lblColorSun = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        lblColorMoon = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        lblColorMercury = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        lblColorVenus = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        lblColorMars = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        lblColorJupiter = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        lblColorSaturn = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        lblColorUranus = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        lblColorNeptune = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        lblColorPluto = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        lblColorGaia = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        lblColorNodes = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        lblColorHouses = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        lblColorAsteroids = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        lblColorVulcan = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        lblColorText = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        lblColorFire = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        lblColorEarth = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        lblColorAir = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        lblColorWater = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        lblColorNeutral = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        lblColorDynamic = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        lblColorHarmonic = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        sldZodiac = new javax.swing.JSlider();
        lblZodiacSize = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        sldSigns = new javax.swing.JSlider();
        lblSignSize = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        sldPlanets = new javax.swing.JSlider();
        lblPlanetSize = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        sldCharacters = new javax.swing.JSlider();
        lblCharactersSize = new javax.swing.JLabel();
        pnlChartColorChoice = new javax.swing.JPanel();
        pnlPlanets = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        chkSun = new javax.swing.JCheckBox();
        chkMoon = new javax.swing.JCheckBox();
        chkMercury = new javax.swing.JCheckBox();
        chkVenus = new javax.swing.JCheckBox();
        chkMars = new javax.swing.JCheckBox();
        chkJupiter = new javax.swing.JCheckBox();
        chkSaturn = new javax.swing.JCheckBox();
        chkUranus = new javax.swing.JCheckBox();
        chkNeptune = new javax.swing.JCheckBox();
        chkPluto = new javax.swing.JCheckBox();
        jPanel50 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        chkGaia = new javax.swing.JCheckBox();
        chkNN = new javax.swing.JCheckBox();
        jPanel56 = new javax.swing.JPanel();
        chkLilith = new javax.swing.JCheckBox();
        chkTrueLilith = new javax.swing.JCheckBox();
        chkEast = new javax.swing.JCheckBox();
        chkZenith = new javax.swing.JCheckBox();
        chkVertex = new javax.swing.JCheckBox();
        chkVulcan = new javax.swing.JCheckBox();
        chkCeres = new javax.swing.JCheckBox();
        chkPallas = new javax.swing.JCheckBox();
        chkJuno = new javax.swing.JCheckBox();
        chkVesta = new javax.swing.JCheckBox();
        chkChiron = new javax.swing.JCheckBox();
        chkOtherPoint = new javax.swing.JCheckBox();
        pnlOtherPoint = new javax.swing.JPanel();
        jLabel125 = new javax.swing.JLabel();
        optOtherPtStar = new javax.swing.JRadioButton();
        pnlOtherPtStar = new javax.swing.JPanel();
        lblStarName = new javax.swing.JLabel();
        cboStarIdentity = new javax.swing.JComboBox();
        optOtherPtPart = new javax.swing.JRadioButton();
        pnlOtherPtPart = new javax.swing.JPanel();
        cboPart = new javax.swing.JComboBox();
        jLabel126 = new javax.swing.JLabel();
        cboPartRef = new javax.swing.JComboBox();
        jLabel127 = new javax.swing.JLabel();
        cboPartPlus = new javax.swing.JComboBox();
        jLabel128 = new javax.swing.JLabel();
        cboPartMinus = new javax.swing.JComboBox();
        optOtherPtComet = new javax.swing.JRadioButton();
        cboComet = new javax.swing.JComboBox();
        optOtherPtAsteroid = new javax.swing.JRadioButton();
        cboAsteroid = new javax.swing.JComboBox();
        optOtherPtNone = new javax.swing.JRadioButton();
        jPanel52 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        chkStars = new javax.swing.JCheckBox();
        sldStars = new javax.swing.JSlider();
        jLabel50 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        chkConstellations = new javax.swing.JCheckBox();
        chkAsteroids = new javax.swing.JCheckBox();
        chkHouses = new javax.swing.JCheckBox();
        chkAspects = new javax.swing.JCheckBox();
        chkCoordinates = new javax.swing.JCheckBox();
        chkStraightLines = new javax.swing.JCheckBox();
        chkShaded = new javax.swing.JCheckBox();
        jPanel62 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        chkBarycenter = new javax.swing.JCheckBox();
        optSingleWeight = new javax.swing.JRadioButton();
        optDifferentWeights = new javax.swing.JRadioButton();
        jPanel63 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        optEastAS = new javax.swing.JRadioButton();
        optEastAries = new javax.swing.JRadioButton();
        chkAspectsSymbol = new javax.swing.JCheckBox();
        chkSignsName = new javax.swing.JCheckBox();
        chkHousesCoord = new javax.swing.JCheckBox();
        pnlAspects = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jPanel90 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jPanel71 = new javax.swing.JPanel();
        lblAspectsColorMode = new javax.swing.JLabel();
        optColorMode1 = new javax.swing.JRadioButton();
        optColorMode2 = new javax.swing.JRadioButton();
        jPanel72 = new javax.swing.JPanel();
        chkConjunction = new javax.swing.JCheckBox();
        txtConjunction = new javax.swing.JTextField();
        lblColorConjunction = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jPanel73 = new javax.swing.JPanel();
        chkSextile = new javax.swing.JCheckBox();
        txtSextile = new javax.swing.JTextField();
        lblColorSextile = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        chkSquare = new javax.swing.JCheckBox();
        txtSquare = new javax.swing.JTextField();
        lblColorSquare = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jPanel75 = new javax.swing.JPanel();
        chkTrine = new javax.swing.JCheckBox();
        txtTrine = new javax.swing.JTextField();
        lblColorTrine = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jPanel76 = new javax.swing.JPanel();
        chkOpposition = new javax.swing.JCheckBox();
        txtOpposition = new javax.swing.JTextField();
        lblColorOpposition = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jPanel77 = new javax.swing.JPanel();
        chkVigintile = new javax.swing.JCheckBox();
        txtVigintile = new javax.swing.JTextField();
        lblColorVigintile = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        chkSemiSextile = new javax.swing.JCheckBox();
        txtSemiSextile = new javax.swing.JTextField();
        lblColorSemiSextile = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jPanel79 = new javax.swing.JPanel();
        chkSemiQuintile = new javax.swing.JCheckBox();
        txtSemiQuintile = new javax.swing.JTextField();
        lblColorSemiQuintile = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        chkNonagon = new javax.swing.JCheckBox();
        txtNonagone = new javax.swing.JTextField();
        lblColorNonagon = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jPanel81 = new javax.swing.JPanel();
        chkSemiSquare = new javax.swing.JCheckBox();
        txtSemiSquare = new javax.swing.JTextField();
        lblColorSemiSquare = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jPanel82 = new javax.swing.JPanel();
        chkSeptile = new javax.swing.JCheckBox();
        txtSeptile = new javax.swing.JTextField();
        lblColorSeptile = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        chkQuintile = new javax.swing.JCheckBox();
        txtQuintile = new javax.swing.JTextField();
        lblColorQuintile = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        chkTriDectile = new javax.swing.JCheckBox();
        txtTriDectile = new javax.swing.JTextField();
        lblColorTridectile = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jPanel85 = new javax.swing.JPanel();
        chkSesquiSquare = new javax.swing.JCheckBox();
        txtSesquiSquare = new javax.swing.JTextField();
        lblColorSesquiSquare = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        chkBiQuintile = new javax.swing.JCheckBox();
        txtBiquintile = new javax.swing.JTextField();
        lblColorBiQuintile = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        chkInconjunct = new javax.swing.JCheckBox();
        txtInconjunct = new javax.swing.JTextField();
        lblColorInconjunct = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        chkQuadriNonagon = new javax.swing.JCheckBox();
        txtQuadriNonagon = new javax.swing.JTextField();
        lblColorQuadriNonagon = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jPanel89 = new javax.swing.JPanel();
        chkOtherAspect = new javax.swing.JCheckBox();
        txtOtherAspect = new javax.swing.JTextField();
        lblColorOtherAspect = new javax.swing.JLabel();
        txtValueOtherAspect = new javax.swing.JTextField();
        jLabel118 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        txtOtherAspectName = new javax.swing.JTextField();
        pnlAspectColorChoice = new javax.swing.JPanel();
        jPanel94 = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        chkAspectSun = new javax.swing.JCheckBox();
        chkAspectMoon = new javax.swing.JCheckBox();
        chkAspectMercury = new javax.swing.JCheckBox();
        chkAspectVenus = new javax.swing.JCheckBox();
        chkAspectMars = new javax.swing.JCheckBox();
        chkAspectJupiter = new javax.swing.JCheckBox();
        chkAspectSaturn = new javax.swing.JCheckBox();
        chkAspectUranus = new javax.swing.JCheckBox();
        chkAspectNeptune = new javax.swing.JCheckBox();
        chkAspectPluto = new javax.swing.JCheckBox();
        chkAspectGaia = new javax.swing.JCheckBox();
        chkAspectNodes = new javax.swing.JCheckBox();
        chkAspectLilith = new javax.swing.JCheckBox();
        chkAspectEast = new javax.swing.JCheckBox();
        chkAspectZenith = new javax.swing.JCheckBox();
        chkAspectVertex = new javax.swing.JCheckBox();
        chkAspectVulcan = new javax.swing.JCheckBox();
        chkAspectCeres = new javax.swing.JCheckBox();
        chkAspectPallas = new javax.swing.JCheckBox();
        chkAspectJuno = new javax.swing.JCheckBox();
        chkAspectVesta = new javax.swing.JCheckBox();
        chkAspectChiron = new javax.swing.JCheckBox();
        chkAspectAS = new javax.swing.JCheckBox();
        chkAspectMC = new javax.swing.JCheckBox();
        chkAspectOtherPoint = new javax.swing.JCheckBox();
        pnlOrbs = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jPanel98 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jPanel99 = new javax.swing.JPanel();
        jLabel70 = new javax.swing.JLabel();
        jPanel100 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jPanel101 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jPanel102 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jPanel103 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        jPanel104 = new javax.swing.JPanel();
        txtOrbLumLum = new javax.swing.JTextField();
        jPanel105 = new javax.swing.JPanel();
        txtOrbLumIndiv = new javax.swing.JTextField();
        jPanel106 = new javax.swing.JPanel();
        txtOrbLumJS = new javax.swing.JTextField();
        jPanel107 = new javax.swing.JPanel();
        txtOrbLumCol = new javax.swing.JTextField();
        jPanel108 = new javax.swing.JPanel();
        txtOrbLumVirtMaj = new javax.swing.JTextField();
        jPanel109 = new javax.swing.JPanel();
        txtOrbLumVirtMin = new javax.swing.JTextField();
        jPanel110 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jPanel111 = new javax.swing.JPanel();
        jPanel113 = new javax.swing.JPanel();
        txtOrbIndivIndiv = new javax.swing.JTextField();
        jPanel114 = new javax.swing.JPanel();
        txtOrbIndivJS = new javax.swing.JTextField();
        jPanel115 = new javax.swing.JPanel();
        txtOrbIndivCol = new javax.swing.JTextField();
        jPanel116 = new javax.swing.JPanel();
        txtOrbIndivVirtMaj = new javax.swing.JTextField();
        jPanel117 = new javax.swing.JPanel();
        txtOrbIndivVirtMin = new javax.swing.JTextField();
        jPanel118 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jPanel119 = new javax.swing.JPanel();
        jPanel120 = new javax.swing.JPanel();
        jPanel121 = new javax.swing.JPanel();
        txtOrbJSJS = new javax.swing.JTextField();
        jPanel122 = new javax.swing.JPanel();
        txtOrbJSCol = new javax.swing.JTextField();
        jPanel123 = new javax.swing.JPanel();
        txtOrbJSvirtMaj = new javax.swing.JTextField();
        jPanel124 = new javax.swing.JPanel();
        txtOrbJSVirtMin = new javax.swing.JTextField();
        jPanel125 = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jPanel126 = new javax.swing.JPanel();
        jPanel127 = new javax.swing.JPanel();
        jPanel128 = new javax.swing.JPanel();
        jPanel129 = new javax.swing.JPanel();
        txtOrbColCol = new javax.swing.JTextField();
        jPanel130 = new javax.swing.JPanel();
        txtOrbColVirtMaj = new javax.swing.JTextField();
        jPanel131 = new javax.swing.JPanel();
        txtOrbColVirtMin = new javax.swing.JTextField();
        jPanel132 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jPanel133 = new javax.swing.JPanel();
        jPanel134 = new javax.swing.JPanel();
        jPanel135 = new javax.swing.JPanel();
        jPanel136 = new javax.swing.JPanel();
        jPanel137 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMaj = new javax.swing.JTextField();
        jPanel138 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMin = new javax.swing.JTextField();
        jPanel139 = new javax.swing.JPanel();
        jLabel98 = new javax.swing.JLabel();
        jPanel140 = new javax.swing.JPanel();
        jPanel141 = new javax.swing.JPanel();
        jPanel142 = new javax.swing.JPanel();
        jPanel143 = new javax.swing.JPanel();
        jPanel144 = new javax.swing.JPanel();
        jPanel112 = new javax.swing.JPanel();
        txtOrbvirtMinVirtMin = new javax.swing.JTextField();
        jPanel95 = new javax.swing.JPanel();
        jPanel145 = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        jPanel146 = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        jPanel147 = new javax.swing.JPanel();
        jLabel107 = new javax.swing.JLabel();
        jPanel148 = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        jPanel149 = new javax.swing.JPanel();
        jLabel113 = new javax.swing.JLabel();
        jPanel150 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        jPanel151 = new javax.swing.JPanel();
        jLabel117 = new javax.swing.JLabel();
        txtDivConjunction = new javax.swing.JTextField();
        jPanel152 = new javax.swing.JPanel();
        jLabel120 = new javax.swing.JLabel();
        txtDivSextile = new javax.swing.JTextField();
        jPanel153 = new javax.swing.JPanel();
        jLabel121 = new javax.swing.JLabel();
        txtDivSquare = new javax.swing.JTextField();
        jPanel154 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        txtDivTrine = new javax.swing.JTextField();
        jPanel155 = new javax.swing.JPanel();
        jLabel123 = new javax.swing.JLabel();
        txtDivOpposition = new javax.swing.JTextField();
        jPanel156 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        txtDivOther = new javax.swing.JTextField();
        pnlWindows = new javax.swing.JPanel();
        pnl2 = new javax.swing.JPanel();
        pnlControlBar = new javax.swing.JPanel();
        btnFirst = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        txtCounter = new javax.swing.JTextField();
        btnNext = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        
        btnFirst.setBorder(null);
        btnPrevious.setBorder(null);
        btnNext.setBorder(null);
        btnLast.setBorder(null);
        btnRemove.setBorder(null);
        btnAdd.setBorder(null);
        btnUpdate.setBorder(null);
        btnCancel.setBorder(null);
        btnFirst.setBorderPainted(false);
        btnPrevious.setBorderPainted(false);
        btnNext.setBorderPainted(false);
        btnLast.setBorderPainted(false);
        btnRemove.setBorderPainted(false);
        btnAdd.setBorderPainted(false);
        btnUpdate.setBorderPainted(false);
        btnCancel.setBorderPainted(false);
        btnFirst.setContentAreaFilled(false);
        btnPrevious.setContentAreaFilled(false);
        btnNext.setContentAreaFilled(false);
        btnLast.setContentAreaFilled(false);
        btnRemove.setContentAreaFilled(false);
        btnAdd.setContentAreaFilled(false);
        btnUpdate.setContentAreaFilled(false);
        btnCancel.setContentAreaFilled(false);
        btnPrevious.setPreferredSize(new java.awt.Dimension(32, 32));
        btnNext.setPreferredSize(new java.awt.Dimension(32, 32));
        btnLast.setPreferredSize(new java.awt.Dimension(32, 32));
        btnRemove.setPreferredSize(new java.awt.Dimension(32, 32));
        btnAdd.setPreferredSize(new java.awt.Dimension(32, 32));
        btnUpdate.setPreferredSize(new java.awt.Dimension(32, 32));
        btnCancel.setPreferredSize(new java.awt.Dimension(32, 32));
        btnFirst.setPreferredSize(new java.awt.Dimension(32, 32));
        jPanel64b = new javax.swing.JPanel();
        jLabel131 = new javax.swing.JLabel();
        txtConfiguration = new javax.swing.JTextField();
        chkDefaultConfiguration = new javax.swing.JCheckBox();
        jPanel67 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cboDefaultEvent = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        cboDefaultPlace = new javax.swing.JComboBox();

        setTitle(bundle.getString("OptionsConfigurations"));
        addWindowListener(new java.awt.event.WindowAdapter()
        {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
                exitForm(evt);
            }
        });

        tabSettings.setPreferredSize(new java.awt.Dimension(1020, 640));
        tabSettings.setMaximumSize(new java.awt.Dimension(1020, 640));
        //pnlChartKind.setLayout(new java.awt.BorderLayout());
        pnlChartKind.setPreferredSize(new java.awt.Dimension(988, 554));
        pnlChartKind.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));


        jPanel1.setPreferredSize(new java.awt.Dimension(994, 35));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 5));
        jOptSingleSelection.setText(bundle.getString("SingleChartSelection"));
        grpChartChoice.add(jOptSingleSelection);
        jOptSingleSelection.setPreferredSize(new java.awt.Dimension(220, 24));
        jOptSingleSelection.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jOptSingleSelectionActionPerformed(evt);
            }
        });

        jPanel1.add(jOptSingleSelection);

        jOptMultiSelection.setSelected(true);
        jOptMultiSelection.setText(bundle.getString("MultiChartSelection"));
        grpChartChoice.add(jOptMultiSelection);
        jOptMultiSelection.setPreferredSize(new java.awt.Dimension(220, 24));
        jOptMultiSelection.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jOptMultiSelectionActionPerformed(evt);
            }
        });

        jPanel1.add(jOptMultiSelection);

        btnSelectAll.setText(bundle.getString("SelectAllKinds"));
        btnSelectAll.setPreferredSize(new java.awt.Dimension(280, 24));
        btnSelectAll.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSelectAllActionPerformed(evt);
            }
        });

        jPanel1.add(btnSelectAll);

        pnlChartKind.add(jPanel1, java.awt.BorderLayout.NORTH);

        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel12.setPreferredSize(new java.awt.Dimension(994, 554));
        jPanel12.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel13.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkNormal.setSelected(true);
        chkNormal.setText(bundle.getString("NormalChart"));
        chkNormal.setPreferredSize(new java.awt.Dimension(215, 31));
        chkNormal.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkNormalActionPerformed(evt);
            }
        });

        jPanel13.add(chkNormal, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel13);

        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel29.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel29.setLayout(new java.awt.BorderLayout());

        chkAstronomical.setText(bundle.getString("LocalChart"));
        chkAstronomical.setPreferredSize(new java.awt.Dimension(215, 31));
        chkAstronomical.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAstronomicalActionPerformed(evt);
            }
        });

        jPanel29.add(chkAstronomical, java.awt.BorderLayout.WEST);

        pnlLocal.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        pnlLocal.setPreferredSize(new java.awt.Dimension(10, 31));
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText(bundle.getString("View"));
        jLabel36.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel36.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel36.setOpaque(true);
        pnlLocal.add(jLabel36);

        optHorizon.setText(bundle.getString("Horizon"));
        grpAstronView.add(optHorizon);
        optHorizon.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optHorizonActionPerformed(evt);
            }
        });

        pnlLocal.add(optHorizon);

        optZenith.setSelected(true);
        optZenith.setText(bundle.getString("Zenith"));
        grpAstronView.add(optZenith);
        optZenith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optZenithActionPerformed(evt);
            }
        });

        pnlLocal.add(optZenith);

        jPanel29.add(pnlLocal, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel29);

        jPanel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel33.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel33.setLayout(new java.awt.BorderLayout());

        chkSymbolicDir.setText(bundle.getString("SymbolicDir"));
        chkSymbolicDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSymbolicDir.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSymbolicDirActionPerformed(evt);
            }
        });

        jPanel33.add(chkSymbolicDir, java.awt.BorderLayout.WEST);

        pnlSymbolicDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText(bundle.getString("WithCorrespondance"));
        jLabel16.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel16.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel16.setOpaque(true);
        pnlSymbolicDir.add(jLabel16);

        txtCorrespondDS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondDS.setText("1");
        txtCorrespondDS.setPreferredSize(new java.awt.Dimension(50, 21));
        txtCorrespondDS.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtCorrespondDSFocusLost(evt);
            }
        });
        txtCorrespondDS.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtCorrespondDSkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlSymbolicDir.add(txtCorrespondDS);

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText(bundle.getString("DegreeEquals"));
        jLabel17.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel17.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel17.setOpaque(true);
        pnlSymbolicDir.add(jLabel17);

        txtEqualsDS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsDS.setText("1");
        txtEqualsDS.setPreferredSize(new java.awt.Dimension(50, 21));
        txtEqualsDS.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtEqualsDSFocusLost(evt);
            }
        });
        txtEqualsDS.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtEqualsDSkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlSymbolicDir.add(txtEqualsDS);

        cboDS.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlSymbolicDir.add(cboDS);

        jPanel33.add(pnlSymbolicDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel33);

        jPanel35.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel35.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel35.setLayout(new java.awt.BorderLayout());

        chkPrimaryDir.setText(bundle.getString("PrimaryDir"));
        chkPrimaryDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkPrimaryDir.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkPrimaryDirActionPerformed(evt);
            }
        });

        jPanel35.add(chkPrimaryDir, java.awt.BorderLayout.WEST);

        pnlPrimaryDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText(bundle.getString("WithCorrespondance"));
        jLabel14.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel14.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel14.setOpaque(true);
        pnlPrimaryDir.add(jLabel14);

        txtCorrespondD1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondD1.setText("1");
        txtCorrespondD1.setPreferredSize(new java.awt.Dimension(50, 21));
        txtCorrespondD1.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtCorrespondD1FocusLost(evt);
            }
        });
        txtCorrespondD1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtCorrespondD1keyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlPrimaryDir.add(txtCorrespondD1);

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText(bundle.getString("DegreeEquals"));
        jLabel15.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel15.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel15.setOpaque(true);
        pnlPrimaryDir.add(jLabel15);

        txtEqualsD1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsD1.setText("1");
        txtEqualsD1.setPreferredSize(new java.awt.Dimension(50, 21));
        txtEqualsD1.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtEqualsD1FocusLost(evt);
            }
        });
        txtEqualsD1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtEqualsD1keyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlPrimaryDir.add(txtEqualsD1);

        cboD1.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlPrimaryDir.add(cboD1);

        jPanel35.add(pnlPrimaryDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel35);

        jPanel37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel37.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel37.setLayout(new java.awt.BorderLayout());

        chkSecondaryDir.setText(bundle.getString("SecondaryDir"));
        chkSecondaryDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSecondaryDir.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSecondaryDirActionPerformed(evt);
            }
        });

        jPanel37.add(chkSecondaryDir, java.awt.BorderLayout.WEST);

        pnlSecondaryDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText(bundle.getString("WithCorrespondance"));
        jLabel10.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel10.setOpaque(true);
        pnlSecondaryDir.add(jLabel10);

        txtCorrespondD2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondD2.setText("1");
        txtCorrespondD2.setPreferredSize(new java.awt.Dimension(50, 21));
        txtCorrespondD2.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtCorrespondD2FocusLost(evt);
            }
        });
        txtCorrespondD2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtCorrespondD2keyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlSecondaryDir.add(txtCorrespondD2);

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText(bundle.getString("DayEquals"));
        jLabel12.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel12.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel12.setOpaque(true);
        pnlSecondaryDir.add(jLabel12);

        txtEqualsD2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsD2.setText("1");
        txtEqualsD2.setPreferredSize(new java.awt.Dimension(50, 21));
        txtEqualsD2.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtEqualsD2FocusLost(evt);
            }
        });
        txtEqualsD2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtEqualsD2keyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlSecondaryDir.add(txtEqualsD2);

        cboD2.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlSecondaryDir.add(cboD2);

        jPanel37.add(pnlSecondaryDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel37);

        jPanel39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel39.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel39.setLayout(new java.awt.BorderLayout());

        chkTransits.setText(bundle.getString("Transits"));
        chkTransits.setPreferredSize(new java.awt.Dimension(215, 31));
        chkTransits.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkTransitsActionPerformed(evt);
            }
        });

        jPanel39.add(chkTransits, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel39);

        jPanel41.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel41.setPreferredSize(new java.awt.Dimension(990, 65));
        jPanel41.setLayout(new java.awt.BorderLayout());

        chkRevolution.setText(bundle.getString("Revolution"));
        chkRevolution.setPreferredSize(new java.awt.Dimension(215, 60));
        chkRevolution.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkRevolutionActionPerformed(evt);
            }
        });

        jPanel41.add(chkRevolution, java.awt.BorderLayout.WEST);

        pnlRevolution.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 1));
        pnlRevolution.setPreferredSize(new java.awt.Dimension(654, 60));
        jPanel60.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        chkPrecession.setText(bundle.getString("Precessionned"));
        jPanel60.add(chkPrecession);

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText(bundle.getString("Planet"));
        jLabel21.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel21.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel21.setOpaque(true);
        jPanel60.add(jLabel21);

        cboPlanetReturn.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel60.add(cboPlanetReturn);

        pnlRevolution.add(jPanel60);

        jPanel61.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText(bundle.getString("Place"));
        jLabel18.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel18.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel18.setOpaque(true);
        jPanel61.add(jLabel18);

        cboPlaceReturn.setMaximumRowCount(10);
        cboPlaceReturn.setToolTipText("");
        cboPlaceReturn.setPreferredSize(new java.awt.Dimension(220, 24));
        cboPlaceReturn.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboPlaceReturnActionPerformed(evt);
            }
        });

        jPanel61.add(cboPlaceReturn);

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText(bundle.getString("Latitude"));
        jLabel19.setPreferredSize(new java.awt.Dimension(110, 18));
        jLabel19.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel19.setOpaque(true);
        jPanel61.add(jLabel19);

        lblLatitudeReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLatitudeReturn.setPreferredSize(new java.awt.Dimension(100, 21));
        lblLatitudeReturn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLatitudeReturn.setOpaque(true);
        jPanel61.add(lblLatitudeReturn);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText(bundle.getString("Longitude"));
        jLabel4.setPreferredSize(new java.awt.Dimension(110, 18));
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel4.setOpaque(true);
        jPanel61.add(jLabel4);

        lblLongitudeReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLongitudeReturn.setAlignmentX(0.5F);
        lblLongitudeReturn.setPreferredSize(new java.awt.Dimension(100, 21));
        lblLongitudeReturn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLongitudeReturn.setOpaque(true);
        jPanel61.add(lblLongitudeReturn);

        pnlRevolution.add(jPanel61);

        jPanel41.add(pnlRevolution, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel41);

        jPanel43.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel43.setPreferredSize(new java.awt.Dimension(990, 65));
        jPanel43.setLayout(new java.awt.BorderLayout());

        chkCycle.setText(bundle.getString("Cycle"));
        chkCycle.setPreferredSize(new java.awt.Dimension(215, 60));
        chkCycle.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkCycleActionPerformed(evt);
            }
        });

        jPanel43.add(chkCycle, java.awt.BorderLayout.WEST);

        pnlCycle.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 1));

        pnlCycle.setPreferredSize(new java.awt.Dimension(654, 60));
        jPanel65.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText(bundle.getString("Planet1"));
        jLabel26.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel26.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel26.setOpaque(true);
        jPanel65.add(jLabel26);

        cboPlanet1Cycle.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel65.add(cboPlanet1Cycle);

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText(bundle.getString("Planet2"));
        jLabel27.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel27.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel27.setOpaque(true);
        jPanel65.add(jLabel27);

        cboPlanet2Cycle.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel65.add(cboPlanet2Cycle);

        pnlCycle.add(jPanel65);

        jPanel66.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 1));

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText(bundle.getString("Place"));
        jLabel23.setPreferredSize(new java.awt.Dimension(80, 18));
        jLabel23.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel23.setOpaque(true);
        jPanel66.add(jLabel23);

        cboPlaceCycle.setMaximumRowCount(10);
        cboPlaceCycle.setToolTipText("");
        cboPlaceCycle.setPreferredSize(new java.awt.Dimension(220, 24));
        cboPlaceCycle.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboPlaceCycleActionPerformed(evt);
            }
        });

        jPanel66.add(cboPlaceCycle);

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText(bundle.getString("Latitude"));
        jLabel24.setPreferredSize(new java.awt.Dimension(110, 18));
        jLabel24.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel24.setOpaque(true);
        jPanel66.add(jLabel24);

        lblLatitudeCycle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLatitudeCycle.setPreferredSize(new java.awt.Dimension(100, 21));
        lblLatitudeCycle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLatitudeCycle.setOpaque(true);
        jPanel66.add(lblLatitudeCycle);

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText(bundle.getString("Longitude"));
        jLabel25.setPreferredSize(new java.awt.Dimension(110, 18));
        jLabel25.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel25.setOpaque(true);
        jPanel66.add(jLabel25);

        lblLongitudeCycle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLongitudeCycle.setAlignmentX(0.5F);
        lblLongitudeCycle.setPreferredSize(new java.awt.Dimension(100, 21));
        lblLongitudeCycle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblLongitudeCycle.setOpaque(true);
        jPanel66.add(lblLongitudeCycle);

        pnlCycle.add(jPanel66);

        jPanel43.add(pnlCycle, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel43);

        jPanel45.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel45.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel45.setLayout(new java.awt.BorderLayout());

        chkSynastry.setText(bundle.getString("Synastry"));
        chkSynastry.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSynastry.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSynastryActionPerformed(evt);
            }
        });

        jPanel45.add(chkSynastry, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel45);

        jPanel47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel47.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel47.setLayout(new java.awt.BorderLayout());

        chkComposite.setText(bundle.getString("Composite"));
        chkComposite.setPreferredSize(new java.awt.Dimension(215, 31));
        chkComposite.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkCompositeActionPerformed(evt);
            }
        });

        jPanel47.add(chkComposite, java.awt.BorderLayout.WEST);

        pnlComposite.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 2));

        pnlComposite.setPreferredSize(new java.awt.Dimension(654, 31));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText(bundle.getString("ChartNBComposite"));
        jLabel8.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel8.setOpaque(true);
        pnlComposite.add(jLabel8);

        txtCompositeChartsNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCompositeChartsNB.setText("2");
        txtCompositeChartsNB.setPreferredSize(new java.awt.Dimension(50, 21));
        txtCompositeChartsNB.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtCompositeChartsNBkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });
        txtCompositeChartsNB.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtCompositeChartsNBFocusLost(evt);
            }
        });

        pnlComposite.add(txtCompositeChartsNB);

        lblFrom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrom.setText(bundle.getString("From"));
        lblFrom.setPreferredSize(new java.awt.Dimension(80, 18));
        lblFrom.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblFrom.setOpaque(true);
        pnlComposite.add(lblFrom);

        optCompositeFromAS.setText("AS");
        grpCompositeFrom.add(optCompositeFromAS);
        optCompositeFromAS.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optCompositeFromASActionPerformed(evt);
            }
        });

        pnlComposite.add(optCompositeFromAS);

        optCompositeFromMC.setSelected(true);
        optCompositeFromMC.setText("MC");
        grpCompositeFrom.add(optCompositeFromMC);
        optCompositeFromMC.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optCompositeFromMCActionPerformed(evt);
            }
        });

        pnlComposite.add(optCompositeFromMC);

        jPanel47.add(pnlComposite, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel47);

        jPanel49.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel49.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel49.setLayout(new java.awt.BorderLayout());

        chkFree.setText(bundle.getString("FreeChart"));
        chkFree.setPreferredSize(new java.awt.Dimension(215, 31));
        chkFree.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkFreeActionPerformed(evt);
            }
        });

        jPanel49.add(chkFree, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel49);

        jPanel53.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel53.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel53.setLayout(new java.awt.BorderLayout());

        chkHarmonic.setText(bundle.getString("HarmonicChart"));
        chkHarmonic.setPreferredSize(new java.awt.Dimension(215, 31));
        chkHarmonic.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkHarmonicActionPerformed(evt);
            }
        });

        jPanel53.add(chkHarmonic, java.awt.BorderLayout.WEST);

        pnlHarmonic.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 3));

        pnlHarmonic.setPreferredSize(new java.awt.Dimension(654, 31));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText(bundle.getString("HarmonicNB"));
        jLabel9.setPreferredSize(new java.awt.Dimension(200, 18));
        jLabel9.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel9.setOpaque(true);
        pnlHarmonic.add(jLabel9);

        txtHarmonicNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtHarmonicNB.setText("2");
        txtHarmonicNB.setPreferredSize(new java.awt.Dimension(50, 21));
        txtHarmonicNB.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtHarmonicNBkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        pnlHarmonic.add(txtHarmonicNB);

        jPanel53.add(pnlHarmonic, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel53);

        jPanel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel31.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel31.setLayout(new java.awt.BorderLayout());

        chkSeed.setText(bundle.getString("SeedHoroscope"));
        chkSeed.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSeed.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSeedActionPerformed(evt);
            }
        });

        jPanel31.add(chkSeed, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel31);

        jPanel55.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel55.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel55.setLayout(new java.awt.BorderLayout());

        chkProjective.setText(bundle.getString("ProjectiveChart"));
        chkProjective.setPreferredSize(new java.awt.Dimension(215, 31));
        chkProjective.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkProjectiveActionPerformed(evt);
            }
        });

        jPanel55.add(chkProjective, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel55);

        pnlChartKind.add(jPanel12, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Chart kind", null, pnlChartKind, "");

        setCoordSysPanel();
        setHouseSysPanel();
        setChartLookPanel();
        setPlanetsPanel();

        pnlAspects.setLayout(new java.awt.BorderLayout());

        jPanel68.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        jPanel68.setPreferredSize(new java.awt.Dimension(500, 30));
        jPanel90.setPreferredSize(new java.awt.Dimension(210, 9));
        jPanel68.add(jPanel90);

        jPanel70.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel70.setPreferredSize(new java.awt.Dimension(410, 24));
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText(bundle.getString("AspectDefinition"));
        jLabel54.setPreferredSize(new java.awt.Dimension(410, 18));
        jLabel54.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel54.setOpaque(true);
        jPanel70.add(jLabel54);

        jPanel68.add(jPanel70);
        
        jPanel71.setPreferredSize(new java.awt.Dimension(500, 24));
        jPanel71.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));

        jPanel51.setPreferredSize(new java.awt.Dimension(490, 24));
        jPanel51.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblAspectsColorMode.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAspectsColorMode.setOpaque(true);
        lblAspectsColorMode.setText(bundle.getString("AspectsColorMode"));
        lblAspectsColorMode.setPreferredSize(new java.awt.Dimension(135, 24));
        jPanel51.add(lblAspectsColorMode);

        grpColorMode.add(optColorMode1);
        optColorMode1.setSelected(true);
        optColorMode1.setText(bundle.getString("ByAspectKind"));
        optColorMode1.setPreferredSize(new java.awt.Dimension(150, 24));
        optColorMode1.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optColorMode1ActionPerformed(evt);
            }
        });
        jPanel51.add(optColorMode1);

        grpColorMode.add(optColorMode2);
        optColorMode2.setText(bundle.getString("ForEachAspect"));
        optColorMode2.setPreferredSize(new java.awt.Dimension(160, 24));

        optColorMode2.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optColorMode2ActionPerformed(evt);
            }
        });
        jPanel51.add(optColorMode2);

        jPanel71.add(jPanel51);

        jPanel68.add(jPanel71);

        jPanel72.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel72.setPreferredSize(new java.awt.Dimension(410, 24));
        chkConjunction.setSelected(true);
        chkConjunction.setText(bundle.getString("Conjunction"));
        chkConjunction.setPreferredSize(new java.awt.Dimension(160, 18));
        chkConjunction.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkConjunctionActionPerformed(evt);
            }
        });

        jPanel72.add(chkConjunction);

        txtConjunction.setFont(new java.awt.Font("Dialog", 1, 14));
        txtConjunction.setForeground(java.awt.Color.green);
        txtConjunction.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtConjunction.setText("N");
        txtConjunction.setPreferredSize(new java.awt.Dimension(30, 20));
        txtConjunction.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtConjunctionkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel72.add(txtConjunction);
        lblColorConjunction.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorConjunction.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorConjunction.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorConjunction.setOpaque(true);
        lblColorConjunction.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorConjunctionMouseClicked(evt);
            }
        });

        jPanel72.add(lblColorConjunction);

        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel60.setText("0\u00b0");
        jLabel60.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel60.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel72.add(jLabel60);

        jLabel62.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel62.setText("a");
        jLabel62.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel62.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel72.add(jLabel62);

        jPanel68.add(jPanel72);

        jPanel73.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel73.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSextile.setSelected(true);
        chkSextile.setText(bundle.getString("Sextile"));
        chkSextile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSextile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSextileActionPerformed(evt);
            }
        });

        jPanel73.add(chkSextile);

        txtSextile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSextile.setForeground(java.awt.Color.blue);
        txtSextile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSextile.setText("H");
        txtSextile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSextile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSextilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel73.add(txtSextile);
        lblColorSextile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSextile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSextile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSextile.setOpaque(true);
        lblColorSextile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSextileMouseClicked(evt);
            }
        });

        jPanel73.add(lblColorSextile);

        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel66.setText("60\u00b0");
        jLabel66.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel66.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel73.add(jLabel66);

        jLabel68.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel68.setText("b");
        jLabel68.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel68.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel73.add(jLabel68);

        jPanel68.add(jPanel73);

        jPanel74.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel74.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSquare.setSelected(true);
        chkSquare.setText(bundle.getString("Square"));
        chkSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSquare.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSquareActionPerformed(evt);
            }
        });

        jPanel74.add(chkSquare);

        txtSquare.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSquare.setForeground(java.awt.Color.red);
        txtSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSquare.setText("D");
        txtSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSquare.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSquarekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel74.add(txtSquare);

        lblColorSquare.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSquare.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSquare.setOpaque(true);
        lblColorSquare.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSquareMouseClicked(evt);
            }
        });

        jPanel74.add(lblColorSquare);

        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel72.setText("90\u00b0");
        jLabel72.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel72.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel74.add(jLabel72);

        jLabel73.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel73.setText("c");
        jLabel73.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel73.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel74.add(jLabel73);

        jPanel68.add(jPanel74);

        jPanel75.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel75.setPreferredSize(new java.awt.Dimension(410, 24));
        chkTrine.setSelected(true);
        chkTrine.setText(bundle.getString("Trine"));
        chkTrine.setPreferredSize(new java.awt.Dimension(160, 18));
        chkTrine.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkTrineActionPerformed(evt);
            }
        });

        jPanel75.add(chkTrine);

        txtTrine.setFont(new java.awt.Font("Dialog", 1, 14));
        txtTrine.setForeground(java.awt.Color.blue);
        txtTrine.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtTrine.setText("H");
        txtTrine.setPreferredSize(new java.awt.Dimension(30, 20));
        txtTrine.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtTrinekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel75.add(txtTrine);

        lblColorTrine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorTrine.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorTrine.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorTrine.setOpaque(true);
        lblColorTrine.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorTrineMouseClicked(evt);
            }
        });

        jPanel75.add(lblColorTrine);

        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel75.setText("120\u00b0");
        jLabel75.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel75.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel75.add(jLabel75);

        jLabel76.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel76.setText("d");
        jLabel76.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel76.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel75.add(jLabel76);

        jPanel68.add(jPanel75);

        jPanel76.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel76.setPreferredSize(new java.awt.Dimension(410, 24));
        chkOpposition.setSelected(true);
        chkOpposition.setText(bundle.getString("Opposition"));
        chkOpposition.setPreferredSize(new java.awt.Dimension(160, 18));
        chkOpposition.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkOppositionActionPerformed(evt);
            }
        });

        jPanel76.add(chkOpposition);

        txtOpposition.setFont(new java.awt.Font("Dialog", 1, 14));
        txtOpposition.setForeground(java.awt.Color.red);
        txtOpposition.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtOpposition.setText("D");
        txtOpposition.setPreferredSize(new java.awt.Dimension(30, 20));
        txtOpposition.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOppositionkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel76.add(txtOpposition);

        lblColorOpposition.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorOpposition.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorOpposition.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorOpposition.setOpaque(true);
        lblColorOpposition.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorOppositionMouseClicked(evt);
            }
        });

        jPanel76.add(lblColorOpposition);

        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel78.setText("180\u00b0");
        jLabel78.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel78.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel76.add(jLabel78);

        jLabel79.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel79.setText("e");
        jLabel79.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel79.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel76.add(jLabel79);

        jPanel68.add(jPanel76);

        jPanel77.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel77.setPreferredSize(new java.awt.Dimension(410, 24));
        chkVigintile.setText(bundle.getString("Vigintile"));
        chkVigintile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkVigintile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkVigintileActionPerformed(evt);
            }
        });

        jPanel77.add(chkVigintile);

        txtVigintile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtVigintile.setForeground(java.awt.Color.green);
        txtVigintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtVigintile.setText("N");
        txtVigintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtVigintile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtVigintilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel77.add(txtVigintile);

        lblColorVigintile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorVigintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorVigintile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorVigintile.setOpaque(true);
        lblColorVigintile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorVigintileMouseClicked(evt);
            }
        });

        jPanel77.add(lblColorVigintile);

        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel81.setText("18\u00b0");
        jLabel81.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel81.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel77.add(jLabel81);

        jLabel82.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel82.setText("q");
        jLabel82.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel82.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel77.add(jLabel82);

        jPanel68.add(jPanel77);

        jPanel78.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel78.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSemiSextile.setText(bundle.getString("SemiSextile"));
        chkSemiSextile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSemiSextile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSemiSextileActionPerformed(evt);
            }
        });

        jPanel78.add(chkSemiSextile);

        txtSemiSextile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSemiSextile.setForeground(java.awt.Color.green);
        txtSemiSextile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSemiSextile.setText("N");
        txtSemiSextile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiSextile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSemiSextilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel78.add(txtSemiSextile);

        lblColorSemiSextile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSemiSextile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiSextile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSemiSextile.setOpaque(true);
        lblColorSemiSextile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSemiSextileMouseClicked(evt);
            }
        });

        jPanel78.add(lblColorSemiSextile);

        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel84.setText("30\u00b0");
        jLabel84.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel84.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel78.add(jLabel84);

        jLabel85.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel85.setText("f");
        jLabel85.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel85.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel78.add(jLabel85);

        jPanel68.add(jPanel78);

        jPanel79.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel79.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSemiQuintile.setText(bundle.getString("SemiQuintile"));
        chkSemiQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSemiQuintile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSemiQuintileActionPerformed(evt);
            }
        });

        jPanel79.add(chkSemiQuintile);

        txtSemiQuintile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSemiQuintile.setForeground(java.awt.Color.green);
        txtSemiQuintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSemiQuintile.setText("N");
        txtSemiQuintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiQuintile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSemiQuintilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel79.add(txtSemiQuintile);

        lblColorSemiQuintile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSemiQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSemiQuintile.setOpaque(true);
        lblColorSemiQuintile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSemiQuintileMouseClicked(evt);
            }
        });

        jPanel79.add(lblColorSemiQuintile);

        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel87.setText("36\u00b0");
        jLabel87.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel87.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel79.add(jLabel87);

        jLabel88.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel88.setText("g");
        jLabel88.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel88.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel79.add(jLabel88);

        jPanel68.add(jPanel79);

        jPanel80.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel80.setPreferredSize(new java.awt.Dimension(410, 24));
        chkNonagon.setText(bundle.getString("Nonagon"));
        chkNonagon.setPreferredSize(new java.awt.Dimension(160, 18));
        chkNonagon.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkNonagonActionPerformed(evt);
            }
        });

        jPanel80.add(chkNonagon);

        txtNonagone.setFont(new java.awt.Font("Dialog", 1, 14));
        txtNonagone.setForeground(java.awt.Color.green);
        txtNonagone.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtNonagone.setText("N");
        txtNonagone.setPreferredSize(new java.awt.Dimension(30, 20));
        txtNonagone.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtNonagonekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel80.add(txtNonagone);

        lblColorNonagon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNonagon.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorNonagon.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorNonagon.setOpaque(true);
        lblColorNonagon.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorNonagonMouseClicked(evt);
            }
        });

        jPanel80.add(lblColorNonagon);

        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel90.setText("40\u00b0");
        jLabel90.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel90.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel80.add(jLabel90);

        jLabel91.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel91.setText("h");
        jLabel91.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel91.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel80.add(jLabel91);

        jPanel68.add(jPanel80);

        jPanel81.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel81.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSemiSquare.setText(bundle.getString("SemiSquare"));
        chkSemiSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSemiSquare.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSemiSquareActionPerformed(evt);
            }
        });

        jPanel81.add(chkSemiSquare);

        txtSemiSquare.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSemiSquare.setForeground(java.awt.Color.red);
        txtSemiSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSemiSquare.setText("D");
        txtSemiSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiSquare.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSemiSquarekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel81.add(txtSemiSquare);

        lblColorSemiSquare.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSemiSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiSquare.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSemiSquare.setOpaque(true);
        lblColorSemiSquare.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSemiSquareMouseClicked(evt);
            }
        });

        jPanel81.add(lblColorSemiSquare);

        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel93.setText("45\u00b0");
        jLabel93.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel93.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel81.add(jLabel93);

        jLabel94.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel94.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel94.setText("i");
        jLabel94.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel94.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel81.add(jLabel94);

        jPanel68.add(jPanel81);

        jPanel82.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel82.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSeptile.setText(bundle.getString("Septile"));
        chkSeptile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSeptile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSeptileActionPerformed(evt);
            }
        });

        jPanel82.add(chkSeptile);

        txtSeptile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSeptile.setForeground(java.awt.Color.green);
        txtSeptile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSeptile.setText("N");
        txtSeptile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSeptile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSeptilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel82.add(txtSeptile);

        lblColorSeptile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSeptile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSeptile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSeptile.setOpaque(true);
        lblColorSeptile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSeptileMouseClicked(evt);
            }
        });

        jPanel82.add(lblColorSeptile);

        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel96.setText("51\u00b0");
        jLabel96.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel96.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel82.add(jLabel96);

        jLabel97.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel97.setText("j");
        jLabel97.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel97.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel82.add(jLabel97);

        jPanel68.add(jPanel82);

        jPanel83.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel83.setPreferredSize(new java.awt.Dimension(410, 24));
        chkQuintile.setText(bundle.getString("Quintile"));
        chkQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkQuintile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkQuintileActionPerformed(evt);
            }
        });

        jPanel83.add(chkQuintile);

        txtQuintile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtQuintile.setForeground(java.awt.Color.green);
        txtQuintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtQuintile.setText("N");
        txtQuintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtQuintile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtQuintilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel83.add(txtQuintile);

        lblColorQuintile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorQuintile.setOpaque(true);
        lblColorQuintile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorQuintileMouseClicked(evt);
            }
        });

        jPanel83.add(lblColorQuintile);

        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel99.setText("72\u00b0");
        jLabel99.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel99.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel83.add(jLabel99);

        jLabel100.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel100.setText("k");
        jLabel100.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel100.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel83.add(jLabel100);

        jPanel68.add(jPanel83);

        jPanel84.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel84.setPreferredSize(new java.awt.Dimension(410, 24));
        chkTriDectile.setText(bundle.getString("TriDectile"));
        chkTriDectile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkTriDectile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkTriDectileActionPerformed(evt);
            }
        });

        jPanel84.add(chkTriDectile);

        txtTriDectile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtTriDectile.setForeground(java.awt.Color.green);
        txtTriDectile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtTriDectile.setText("N");
        txtTriDectile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtTriDectile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtTriDectilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel84.add(txtTriDectile);

        lblColorTridectile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorTridectile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorTridectile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorTridectile.setOpaque(true);
        lblColorTridectile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorTridectileMouseClicked(evt);
            }
        });

        jPanel84.add(lblColorTridectile);

        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel102.setText("108\u00b0");
        jLabel102.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel102.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel84.add(jLabel102);

        jLabel103.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel103.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel103.setText("l");
        jLabel103.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel103.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel84.add(jLabel103);

        jPanel68.add(jPanel84);

        jPanel85.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel85.setPreferredSize(new java.awt.Dimension(410, 24));
        chkSesquiSquare.setText(bundle.getString("SesquiSquare"));
        chkSesquiSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        chkSesquiSquare.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkSesquiSquareActionPerformed(evt);
            }
        });

        jPanel85.add(chkSesquiSquare);

        txtSesquiSquare.setFont(new java.awt.Font("Dialog", 1, 14));
        txtSesquiSquare.setForeground(java.awt.Color.red);
        txtSesquiSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtSesquiSquare.setText("D");
        txtSesquiSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSesquiSquare.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtSesquiSquarekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel85.add(txtSesquiSquare);

        lblColorSesquiSquare.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSesquiSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSesquiSquare.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorSesquiSquare.setOpaque(true);
        lblColorSesquiSquare.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorSesquiSquareMouseClicked(evt);
            }
        });

        jPanel85.add(lblColorSesquiSquare);

        jLabel105.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel105.setText("135\u00b0");
        jLabel105.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel105.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel85.add(jLabel105);

        jLabel106.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel106.setText("m");
        jLabel106.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel106.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel85.add(jLabel106);

        jPanel68.add(jPanel85);

        jPanel86.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel86.setPreferredSize(new java.awt.Dimension(410, 24));
        chkBiQuintile.setText(bundle.getString("BiQuintile"));
        chkBiQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        chkBiQuintile.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkBiQuintileActionPerformed(evt);
            }
        });

        jPanel86.add(chkBiQuintile);

        txtBiquintile.setFont(new java.awt.Font("Dialog", 1, 14));
        txtBiquintile.setForeground(java.awt.Color.green);
        txtBiquintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtBiquintile.setText("N");
        txtBiquintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtBiquintile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtBiquintilekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel86.add(txtBiquintile);

        lblColorBiQuintile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorBiQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorBiQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorBiQuintile.setOpaque(true);
        lblColorBiQuintile.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorBiQuintileMouseClicked(evt);
            }
        });

        jPanel86.add(lblColorBiQuintile);

        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel108.setText("144\u00b0");
        jLabel108.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel108.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel86.add(jLabel108);

        jLabel109.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel109.setText("n");
        jLabel109.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel109.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel86.add(jLabel109);

        jPanel68.add(jPanel86);

        jPanel87.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel87.setPreferredSize(new java.awt.Dimension(410, 24));
        chkInconjunct.setSelected(true);
        chkInconjunct.setText(bundle.getString("Inconjunct"));
        chkInconjunct.setPreferredSize(new java.awt.Dimension(160, 18));
        chkInconjunct.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkInconjunctActionPerformed(evt);
            }
        });

        jPanel87.add(chkInconjunct);

        txtInconjunct.setFont(new java.awt.Font("Dialog", 1, 14));
        txtInconjunct.setForeground(java.awt.Color.green);
        txtInconjunct.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtInconjunct.setText("N");
        txtInconjunct.setPreferredSize(new java.awt.Dimension(30, 20));
        txtInconjunct.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtInconjunctkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel87.add(txtInconjunct);

        lblColorInconjunct.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorInconjunct.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorInconjunct.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorInconjunct.setOpaque(true);
        lblColorInconjunct.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorInconjunctMouseClicked(evt);
            }
        });

        jPanel87.add(lblColorInconjunct);

        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111.setText("150\u00b0");
        jLabel111.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel111.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel87.add(jLabel111);

        jLabel112.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel112.setText("o");
        jLabel112.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel112.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel87.add(jLabel112);

        jPanel68.add(jPanel87);

        jPanel88.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel88.setPreferredSize(new java.awt.Dimension(410, 24));
        chkQuadriNonagon.setText(bundle.getString("QuadriNonagon"));
        chkQuadriNonagon.setPreferredSize(new java.awt.Dimension(160, 18));
        chkQuadriNonagon.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkQuadriNonagonActionPerformed(evt);
            }
        });

        jPanel88.add(chkQuadriNonagon);

        txtQuadriNonagon.setFont(new java.awt.Font("Dialog", 1, 14));
        txtQuadriNonagon.setForeground(java.awt.Color.green);
        txtQuadriNonagon.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtQuadriNonagon.setText("N");
        txtQuadriNonagon.setPreferredSize(new java.awt.Dimension(30, 20));
        txtQuadriNonagon.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtQuadriNonagonkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel88.add(txtQuadriNonagon);

        lblColorQuadriNonagon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorQuadriNonagon.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorQuadriNonagon.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorQuadriNonagon.setOpaque(true);
        lblColorQuadriNonagon.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorQuadriNonagonMouseClicked(evt);
            }
        });

        jPanel88.add(lblColorQuadriNonagon);

        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel114.setText("160\u00b0");
        jLabel114.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel114.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel88.add(jLabel114);

        jLabel115.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel115.setText("p");
        jLabel115.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel115.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel88.add(jLabel115);

        jPanel68.add(jPanel88);

        jPanel89.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel89.setPreferredSize(new java.awt.Dimension(410, 48));
        chkOtherAspect.setText(bundle.getString("OtherAspect"));
        chkOtherAspect.setPreferredSize(new java.awt.Dimension(160, 18));
        chkOtherAspect.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkOtherAspectActionPerformed(evt);
            }
        });

        jPanel89.add(chkOtherAspect);

        txtOtherAspect.setFont(new java.awt.Font("Dialog", 1, 14));
        txtOtherAspect.setForeground(java.awt.Color.green);
        txtOtherAspect.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        //txtOtherAspect.setText("N");
        txtOtherAspect.setPreferredSize(new java.awt.Dimension(30, 20));
        txtOtherAspect.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOtherAspectkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel89.add(txtOtherAspect);

        lblColorOtherAspect.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorOtherAspect.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorOtherAspect.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        lblColorOtherAspect.setOpaque(true);
        lblColorOtherAspect.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                lblColorOtherAspectMouseClicked(evt);
            }
        });

        jPanel89.add(lblColorOtherAspect);

        txtValueOtherAspect.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtValueOtherAspect.setText("0");
        txtValueOtherAspect.setPreferredSize(new java.awt.Dimension(40, 20));
        txtValueOtherAspect.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtValueOtherAspectFocusLost(evt);
            }
        });
        txtValueOtherAspect.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtValueOtherAspectkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel89.add(txtValueOtherAspect);

        jLabel118.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel118.setText("r");
        jLabel118.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel118.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel89.add(jLabel118);

        jLabel129.setText(bundle.getString("OtherAspectName"));
        jLabel129.setPreferredSize(new java.awt.Dimension(175, 18));
        jLabel129.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel129.setOpaque(true);
        jPanel89.add(jLabel129);

        txtOtherAspectName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOtherAspectName.setPreferredSize(new java.awt.Dimension(175, 20));
        txtOtherAspectName.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOtherAspectNamekeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel89.add(txtOtherAspectName);

        jPanel68.add(jPanel89);

        pnlAspects.add(jPanel68, java.awt.BorderLayout.WEST);

        pnlAspectColorChoice.setLayout(new javax.swing.BoxLayout(pnlAspectColorChoice, javax.swing.BoxLayout.Y_AXIS));

        jPanel94.setPreferredSize(new java.awt.Dimension(210, 9));
        pnlAspectColorChoice.add(jPanel94);

        pnlAspects.add(pnlAspectColorChoice, java.awt.BorderLayout.CENTER);

        jPanel69.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel69.setPreferredSize(new java.awt.Dimension(150, 34));
        jPanel91.setPreferredSize(new java.awt.Dimension(150, 14));
        jPanel69.add(jPanel91);

        jPanel92.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel92.setPreferredSize(new java.awt.Dimension(150, 24));
        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel119.setText(bundle.getString("AspectedPlanets"));
        jLabel119.setAlignmentX(0.5F);
        jLabel119.setPreferredSize(new java.awt.Dimension(140, 18));
        jLabel119.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel119.setOpaque(true);
        jPanel92.add(jLabel119);

        jPanel69.add(jPanel92);

        chkAspectSun.setSelected(true);
        chkAspectSun.setText(bundle.getString("Sun"));
        chkAspectSun.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectSun.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectSunActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectSun);

        chkAspectMoon.setSelected(true);
        chkAspectMoon.setText(bundle.getString("Moon"));
        chkAspectMoon.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMoon.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectMoonActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectMoon);

        chkAspectMercury.setSelected(true);
        chkAspectMercury.setText(bundle.getString("Mercury"));
        chkAspectMercury.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMercury.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectMercuryActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectMercury);

        chkAspectVenus.setSelected(true);
        chkAspectVenus.setText(bundle.getString("Venus"));
        chkAspectVenus.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVenus.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectVenusActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectVenus);

        chkAspectMars.setSelected(true);
        chkAspectMars.setText(bundle.getString("Mars"));
        chkAspectMars.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMars.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectMarsActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectMars);

        chkAspectJupiter.setSelected(true);
        chkAspectJupiter.setText(bundle.getString("Jupiter"));
        chkAspectJupiter.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectJupiter.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectJupiterActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectJupiter);

        chkAspectSaturn.setSelected(true);
        chkAspectSaturn.setText(bundle.getString("Saturn"));
        chkAspectSaturn.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectSaturn.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectSaturnActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectSaturn);

        chkAspectUranus.setSelected(true);
        chkAspectUranus.setText(bundle.getString("Uranus"));
        chkAspectUranus.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectUranus.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectUranusActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectUranus);

        chkAspectNeptune.setSelected(true);
        chkAspectNeptune.setText(bundle.getString("Neptune"));
        chkAspectNeptune.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectNeptune.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectNeptuneActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectNeptune);

        chkAspectPluto.setSelected(true);
        chkAspectPluto.setText(bundle.getString("Pluto"));
        chkAspectPluto.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectPluto.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectPlutoActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectPluto);

        chkAspectGaia.setText(bundle.getString("Gaia"));
        chkAspectGaia.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectGaia.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectGaiaActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectGaia);

        chkAspectNodes.setSelected(true);
        chkAspectNodes.setText(bundle.getString("NorthNode"));
        chkAspectNodes.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectNodes.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectNodesActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectNodes);

        chkAspectLilith.setSelected(true);
        chkAspectLilith.setText(bundle.getString("Lilith"));
        chkAspectLilith.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectLilith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectLilithActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectLilith);

        chkAspectEast.setText(bundle.getString("East"));
        chkAspectEast.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectEast.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectEastActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectEast);

        chkAspectZenith.setText(bundle.getString("Zenith"));
        chkAspectZenith.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectZenith.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectZenithActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectZenith);

        chkAspectVertex.setText(bundle.getString("Vertex"));
        chkAspectVertex.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVertex.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectVertexActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectVertex);

        chkAspectVulcan.setText(bundle.getString("Vulcan"));
        chkAspectVulcan.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVulcan.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectVulcanActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectVulcan);

        chkAspectCeres.setText(bundle.getString("Ceres"));
        chkAspectCeres.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectCeres.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectCeresActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectCeres);

        chkAspectPallas.setText(bundle.getString("Pallas"));
        chkAspectPallas.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectPallas.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectPallasActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectPallas);

        chkAspectJuno.setText(bundle.getString("Juno"));
        chkAspectJuno.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectJuno.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectJunoActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectJuno);

        chkAspectVesta.setText(bundle.getString("Vesta"));
        chkAspectVesta.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVesta.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectVestaActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectVesta);

        chkAspectChiron.setSelected(true);
        chkAspectChiron.setText(bundle.getString("Chiron"));
        chkAspectChiron.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectChiron.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectChironActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectChiron);

        chkAspectAS.setText(bundle.getString("Ascendant"));
        chkAspectAS.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectAS.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectASActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectAS);

        chkAspectMC.setText(bundle.getString("Midheaven"));
        chkAspectMC.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMC.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectMCActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectMC);

        chkAspectOtherPoint.setText(bundle.getString("OtherPointName"));
        chkAspectOtherPoint.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectOtherPoint.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAspectOtherPointActionPerformed(evt);
            }
        });

        jPanel69.add(chkAspectOtherPoint);

        pnlAspects.add(jPanel69, java.awt.BorderLayout.EAST);

        tabSettings.addTab("Aspects", null, pnlAspects, "");

        pnlOrbs.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 85));

        jPanel93.setLayout(new java.awt.GridLayout(7, 7));

        jPanel93.setBorder(new javax.swing.border.EtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel93.setPreferredSize(new java.awt.Dimension(700, 230));
        jPanel93.add(jPanel96);

        jLabel58.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel58.setForeground(new java.awt.Color(51, 153, 255));
        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel58.setText("AB");
        jLabel58.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel58.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel97.add(jLabel58);

        jPanel93.add(jPanel97);

        jLabel64.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel64.setForeground(new java.awt.Color(51, 102, 255));
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("CDE");
        jLabel64.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel64.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel98.add(jLabel64);

        jPanel93.add(jPanel98);

        jLabel70.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel70.setForeground(new java.awt.Color(0, 51, 255));
        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText("FG");
        jLabel70.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel70.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel99.add(jLabel70);

        jPanel93.add(jPanel99);

        jLabel74.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel74.setForeground(new java.awt.Color(0, 0, 204));
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setText("HIJKQ...");
        jLabel74.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel74.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel100.add(jLabel74);

        jPanel93.add(jPanel100);

        jLabel77.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel77.setForeground(new java.awt.Color(51, 0, 153));
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel77.setText("LMX Y");
        jLabel77.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel77.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel101.add(jLabel77);

        jPanel93.add(jPanel101);

        jLabel80.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel80.setText("NOPR");
        jLabel80.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel80.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel102.add(jLabel80);

        jPanel93.add(jPanel102);

        jLabel83.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel83.setForeground(new java.awt.Color(51, 153, 255));
        jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel83.setText("AB");
        jLabel83.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel83.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel103.add(jLabel83);

        jPanel93.add(jPanel103);

        txtOrbLumLum.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumLum.setText("0");
        txtOrbLumLum.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumLum.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumLumkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel104.add(txtOrbLumLum);

        jPanel93.add(jPanel104);

        txtOrbLumIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumIndiv.setText("0");
        txtOrbLumIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumIndiv.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumIndivkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel105.add(txtOrbLumIndiv);

        jPanel93.add(jPanel105);

        txtOrbLumJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumJS.setText("0");
        txtOrbLumJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumJS.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumJSkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel106.add(txtOrbLumJS);

        jPanel93.add(jPanel106);

        txtOrbLumCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumCol.setText("0");
        txtOrbLumCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumCol.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumColkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel107.add(txtOrbLumCol);

        jPanel93.add(jPanel107);

        txtOrbLumVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMaj.setText("0");
        txtOrbLumVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMaj.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumVirtMajkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel108.add(txtOrbLumVirtMaj);

        jPanel93.add(jPanel108);

        txtOrbLumVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMin.setText("0");
        txtOrbLumVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbLumVirtMinkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel109.add(txtOrbLumVirtMin);

        jPanel93.add(jPanel109);

        jLabel86.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel86.setForeground(new java.awt.Color(51, 102, 255));
        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel86.setText("CDE");
        jLabel86.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel86.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel110.add(jLabel86);

        jPanel93.add(jPanel110);

        jPanel93.add(jPanel111);

        txtOrbIndivIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivIndiv.setText("0");
        txtOrbIndivIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivIndiv.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbIndivIndivkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel113.add(txtOrbIndivIndiv);

        jPanel93.add(jPanel113);

        txtOrbIndivJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivJS.setText("0");
        txtOrbIndivJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivJS.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbIndivJSkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel114.add(txtOrbIndivJS);

        jPanel93.add(jPanel114);

        txtOrbIndivCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivCol.setText("0");
        txtOrbIndivCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivCol.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbIndivColkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel115.add(txtOrbIndivCol);

        jPanel93.add(jPanel115);

        txtOrbIndivVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMaj.setText("0");
        txtOrbIndivVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMaj.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbIndivVirtMajkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel116.add(txtOrbIndivVirtMaj);

        jPanel93.add(jPanel116);

        txtOrbIndivVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMin.setText("0");
        txtOrbIndivVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbIndivVirtMinkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel117.add(txtOrbIndivVirtMin);

        jPanel93.add(jPanel117);

        jLabel89.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel89.setForeground(new java.awt.Color(0, 51, 255));
        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("FG");
        jLabel89.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel89.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel118.add(jLabel89);

        jPanel93.add(jPanel118);

        jPanel93.add(jPanel119);

        jPanel93.add(jPanel120);

        txtOrbJSJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSJS.setText("0");
        txtOrbJSJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSJS.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbJSJSkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel121.add(txtOrbJSJS);

        jPanel93.add(jPanel121);

        txtOrbJSCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSCol.setText("0");
        txtOrbJSCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSCol.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbJSColkeyTyped(evt);
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }
        });

        jPanel122.add(txtOrbJSCol);

        jPanel93.add(jPanel122);

        txtOrbJSvirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSvirtMaj.setText("0");
        txtOrbJSvirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSvirtMaj.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                }
            }

            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbJSvirtMajkeyTyped(evt);
            }
        });

        jPanel123.add(txtOrbJSvirtMaj);

        jPanel93.add(jPanel123);

        txtOrbJSVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSVirtMin.setText("0");
        txtOrbJSVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbJSVirtMinkeyTyped(evt);
            }
        });

        jPanel124.add(txtOrbJSVirtMin);

        jPanel93.add(jPanel124);

        jLabel92.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel92.setForeground(new java.awt.Color(0, 0, 204));
        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel92.setText("HIJKQ...");
        jLabel92.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel92.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel125.add(jLabel92);

        jPanel93.add(jPanel125);

        jPanel93.add(jPanel126);

        jPanel93.add(jPanel127);

        jPanel93.add(jPanel128);

        txtOrbColCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColCol.setText("0");
        txtOrbColCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColCol.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbColColkeyTyped(evt);
            }
        });

        jPanel129.add(txtOrbColCol);

        jPanel93.add(jPanel129);

        txtOrbColVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMaj.setText("0");
        txtOrbColVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMaj.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbColVirtMajkeyTyped(evt);
            }
        });

        jPanel130.add(txtOrbColVirtMaj);

        jPanel93.add(jPanel130);

        txtOrbColVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMin.setText("0");
        txtOrbColVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbColVirtMinkeyTyped(evt);
            }
        });

        jPanel131.add(txtOrbColVirtMin);

        jPanel93.add(jPanel131);

        jLabel95.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel95.setForeground(new java.awt.Color(51, 0, 153));
        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel95.setText("LMX Y");
        jLabel95.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel95.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel132.add(jLabel95);

        jPanel93.add(jPanel132);

        jPanel93.add(jPanel133);

        jPanel93.add(jPanel134);

        jPanel93.add(jPanel135);

        jPanel93.add(jPanel136);

        txtOrbVirtMajVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMaj.setText("0");
        txtOrbVirtMajVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMaj.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbVirtMajVirtMajkeyTyped(evt);
            }
        });

        jPanel137.add(txtOrbVirtMajVirtMaj);

        jPanel93.add(jPanel137);

        txtOrbVirtMajVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMin.setText("0");
        txtOrbVirtMajVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbVirtMajVirtMinkeyTyped(evt);
            }
        });

        jPanel138.add(txtOrbVirtMajVirtMin);

        jPanel93.add(jPanel138);

        jLabel98.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel98.setText("NOPR");
        jLabel98.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel98.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel139.add(jLabel98);

        jPanel93.add(jPanel139);

        jPanel93.add(jPanel140);

        jPanel93.add(jPanel141);

        jPanel93.add(jPanel142);

        jPanel93.add(jPanel143);

        jPanel93.add(jPanel144);

        txtOrbvirtMinVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbvirtMinVirtMin.setText("0");
        txtOrbvirtMinVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbvirtMinVirtMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtOrbvirtMinVirtMinkeyTyped(evt);
            }
        });

        jPanel112.add(txtOrbvirtMinVirtMin);

        jPanel93.add(jPanel112);

        pnlOrbs.add(jPanel93);

        jPanel95.setLayout(new java.awt.GridLayout(2, 6));

        jPanel95.setBorder(new javax.swing.border.EtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel95.setPreferredSize(new java.awt.Dimension(600, 80));
        jLabel101.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel101.setForeground(new java.awt.Color(51, 153, 255));
        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel101.setText("a");
        jLabel101.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel101.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel145.add(jLabel101);

        jPanel95.add(jPanel145);

        jLabel104.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel104.setForeground(new java.awt.Color(51, 102, 255));
        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel104.setText("b");
        jLabel104.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel104.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel146.add(jLabel104);

        jPanel95.add(jPanel146);

        jLabel107.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel107.setForeground(new java.awt.Color(0, 51, 255));
        jLabel107.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel107.setText("c");
        jLabel107.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel107.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel147.add(jLabel107);

        jPanel95.add(jPanel147);

        jLabel110.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel110.setForeground(new java.awt.Color(0, 0, 204));
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("d");
        jLabel110.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel110.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel148.add(jLabel110);

        jPanel95.add(jPanel148);

        jLabel113.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel113.setForeground(new java.awt.Color(51, 0, 153));
        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel113.setText("e");
        jLabel113.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel113.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel149.add(jLabel113);

        jPanel95.add(jPanel149);

        jLabel116.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("...");
        jLabel116.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel116.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel150.add(jLabel116);

        jPanel95.add(jPanel150);

        jPanel151.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel117.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel117.setText("/");
        jLabel117.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel117.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel151.add(jLabel117);

        txtDivConjunction.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivConjunction.setText("0");
        txtDivConjunction.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivConjunction.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivConjunctionFocusLost(evt);
            }
        });
        txtDivConjunction.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivConjunctionkeyTyped(evt);
            }
        });

        jPanel151.add(txtDivConjunction);

        jPanel95.add(jPanel151);

        jPanel152.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel120.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("/");
        jLabel120.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel120.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel152.add(jLabel120);

        txtDivSextile.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSextile.setText("0");
        txtDivSextile.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSextile.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivSextileFocusLost(evt);
            }
        });
        txtDivSextile.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivSextilekeyTyped(evt);
            }
        });

        jPanel152.add(txtDivSextile);

        jPanel95.add(jPanel152);

        jPanel153.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel121.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("/");
        jLabel121.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel121.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel153.add(jLabel121);

        txtDivSquare.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSquare.setText("0");
        txtDivSquare.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSquare.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivSquareFocusLost(evt);
            }
        });
        txtDivSquare.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivSquarekeyTyped(evt);
            }
        });

        jPanel153.add(txtDivSquare);

        jPanel95.add(jPanel153);

        jPanel154.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel122.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("/");
        jLabel122.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel122.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel154.add(jLabel122);

        txtDivTrine.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivTrine.setText("0");
        txtDivTrine.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivTrine.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivTrineFocusLost(evt);
            }
        });
        txtDivTrine.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivTrinekeyTyped(evt);
            }
        });

        jPanel154.add(txtDivTrine);

        jPanel95.add(jPanel154);

        jPanel155.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel123.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel123.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel123.setText("/");
        jLabel123.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel123.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel155.add(jLabel123);

        txtDivOpposition.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOpposition.setText("0");
        txtDivOpposition.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOpposition.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivOppositionFocusLost(evt);
            }
        });
        txtDivOpposition.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivOppositionkeyTyped(evt);
            }
        });

        jPanel155.add(txtDivOpposition);

        jPanel95.add(jPanel155);

        jPanel156.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel124.setFont(new java.awt.Font("Dialog", 0, 18));
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("/");
        jLabel124.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel124.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel156.add(jLabel124);

        txtDivOther.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOther.setText("0");
        txtDivOther.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOther.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDivOtherFocusLost(evt);
            }
        });
        txtDivOther.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDivOtherkeyTyped(evt);
            }
        });

        jPanel156.add(txtDivOther);

        jPanel95.add(jPanel156);

        pnlOrbs.add(jPanel95);

        tabSettings.addTab("Orbs", null, pnlOrbs, "");

        pnlWindows.setLayout(new java.awt.BorderLayout());

        getContentPane().add(tabSettings, java.awt.BorderLayout.CENTER);

        pnl2.setPreferredSize(new Dimension(1000, 91));
        pnlControlBar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,2, -2));
        pnlControlBar.setPreferredSize(new Dimension(1000,30));

        btnFirst.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png")));
        btnFirst.setToolTipText(bundle.getString("FirstConfiguration"));
        btnFirst.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnFirst);

        btnPrevious.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png")));
        btnPrevious.setToolTipText(bundle.getString("PreviousConfiguration"));
        btnPrevious.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnPrevious);

        //txtCounter.setFont(new java.awt.Font("Arial", 1, 8));
        txtCounter.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCounter.setText(bundle.getString("NewConfiguration")); // NOI18N
        txtCounter.setPreferredSize(new java.awt.Dimension(200, 19));
        txtCounter.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt)
            {
                txtCounterKeyReleased(evt);
            }
        });
        pnlControlBar.add(txtCounter);

        btnNext.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png")));
        btnNext.setToolTipText(bundle.getString("NextConfiguration"));
        btnNext.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnNext);

        btnLast.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png")));
        btnLast.setToolTipText(bundle.getString("LastConfiguration"));
        btnLast.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnLast);

        btnRemove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png")));
        btnRemove.setToolTipText(bundle.getString("RemoveConfiguration"));
        btnRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemove.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnRemoveActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnRemove);

        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png")));
        btnAdd.setToolTipText(bundle.getString("AddConfiguration"));
        btnAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAdd.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnAddActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnAdd);

        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png")));
        btnUpdate.setToolTipText(bundle.getString("UpdateModif"));
        btnUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnUpdate.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnUpdateActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnUpdate);

        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png")));
        btnCancel.setToolTipText(bundle.getString("CancelModif"));
        btnCancel.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCancel.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelActionPerformed(evt);
            }
        });

        pnlControlBar.add(btnCancel);
        
        pnl2.add(pnlControlBar);

        jLabel131.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel131.setText(bundle.getString("Configuration"));
        jLabel131.setPreferredSize(new java.awt.Dimension(110, 18));
        jLabel131.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel131.setOpaque(true);
        jPanel64.setPreferredSize(new java.awt.Dimension(1000, 21));
        jPanel64.add(jLabel131);

        txtConfiguration.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtConfiguration.setPreferredSize(new java.awt.Dimension(300, 19));
        txtConfiguration.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtConfigurationkeyTyped(evt);
            }
        });

        jPanel64.add(txtConfiguration);

        chkDefaultConfiguration.setText(bundle.getString("DefaultConfiguration"));
        chkDefaultConfiguration.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkDefaultConfigurationActionPerformed(evt);
            }
        });

        jPanel64.add(chkDefaultConfiguration);
        jPanel64.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        pnl2.add(jPanel64);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText(bundle.getString("DefaultEvent"));
        jLabel2.setPreferredSize(new java.awt.Dimension(170, 18));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel2.setOpaque(true);
        jPanel67.setPreferredSize(new java.awt.Dimension(1000, 22));
        jPanel67.add(jLabel2);

        cboDefaultEvent.setMaximumRowCount(10);
        cboDefaultEvent.setToolTipText("");
        cboDefaultEvent.setPreferredSize(new java.awt.Dimension(300, 22));
        cboDefaultEvent.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboDefaultEventActionPerformed(evt);
            }
        });

        jPanel67.add(cboDefaultEvent);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(bundle.getString("DefaultPlace"));
        jLabel1.setPreferredSize(new java.awt.Dimension(170, 18));
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
        jLabel1.setOpaque(true);
        jPanel67.add(jLabel1);

        cboDefaultPlace.setMaximumRowCount(10);
        cboDefaultPlace.setPreferredSize(new java.awt.Dimension(250, 22));
        cboDefaultPlace.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboDefaultPlaceActionPerformed(evt);
            }
        });

        jPanel67.add(cboDefaultPlace);

        pnl2.add(jPanel67);
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        jPanel67.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        getContentPane().add(pnl2, java.awt.BorderLayout.SOUTH);

        pack();
    }

    private void optCompositeFromMCActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optCompositeFromASActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optZenithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optHorizonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectOtherPointActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectMCActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectASActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectChironActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectVestaActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectJunoActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectPallasActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectCeresActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectVulcanActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectVertexActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectZenithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void sldZodiacStateChanged(javax.swing.event.ChangeEvent evt)
    {
        int value = sldZodiac.getValue();
        Font f = lblZodiacSize.getFont();
        lblZodiacSize.setFont(new Font(f.getName(), Font.PLAIN, value));
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectEastActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectLilithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectNodesActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectGaiaActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectPlutoActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectNeptuneActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectUranusActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectSaturnActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectJupiterActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectMarsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectVenusActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectMercuryActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectMoonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectSunActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOtherAspectNamekeyTyped(java.awt.event.KeyEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkOtherAspectActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkQuadriNonagonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkInconjunctActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkBiQuintileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSesquiSquareActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkTriDectileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkQuintileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSeptileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSemiSquareActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkNonagonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSemiQuintileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSemiSextileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkVigintileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkOppositionActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkTrineActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSquareActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSextileActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkConjunctionActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optColorMode2ActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optColorMode1ActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHousesCoordActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSignsNameActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectsSymbolActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optEastAriesActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optEastASActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optDifferentWeightsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optSingleWeightActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkBarycenterActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkShadedActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkStraightLinesActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkCoordinatesActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtConfigurationkeyTyped(java.awt.event.KeyEvent evt)
    {
        String sText = txtConfiguration.getText();
        if (sText.length() > 100)
        {
            sText = sText.substring(0, 100);
            txtConfiguration.setText(sText);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAspectsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHousesActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAsteroidsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkConstellationsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void sldStarsStateChanged(javax.swing.event.ChangeEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkStarsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboAsteroidActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboCometActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboPartActionPerformed(java.awt.event.ActionEvent evt)
    {
        setPart();
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void setPart()
    {
        ArrayList p = parts.getRecords();
        for (int i = 0; i < p.size(); i++)
        {
            ArrayList v = (ArrayList) p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1));
            String selectedPart = null2String(cboPart.getSelectedItem());
            if (strName.equals(selectedPart))
            {
                Part part = starLoginManager.getPart(strID);
                cboPartRef.setSelectedIndex(part.getRef());
                cboPartPlus.setSelectedIndex(part.getPlus());
                cboPartMinus.setSelectedIndex(part.getMinus());
                break;
            }
        }
    }

    private void cboStarIdentityActionPerformed(java.awt.event.ActionEvent evt)
    {
        setStar();
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void setStar()
    {
        ArrayList p = stars.getRecords();
        for (int i = 0; i < p.size(); i++)
        {
            ArrayList v = (ArrayList) p.get(i);
            String strID = String.valueOf(v.get(0));
            String strIdentity = String.valueOf(v.get(3));
            String selectedStar = null2String(cboStarIdentity.getSelectedItem());
            if (strIdentity.equals(selectedStar))
            {
                Star star = starLoginManager.getStar(strID, "");
                lblStarName.setText(star.getStarName());
                break;
            }
        }
    }

    private void chkChironActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkVestaActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkJunoActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkPallasActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkCeresActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkVulcanActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkVertexActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkZenithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkEastActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkTrueLilithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkLilithActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkNNActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkGaiaActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkPlutoActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkNeptuneActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkUranusActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSaturnActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkJupiterActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkMarsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkVenusActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkMercuryActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkMoonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSunActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkDefaultConfigurationActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboDefaultPlaceActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboDefaultEventActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (bolAdding == true)
        {
            optionRow = saveOptionRow;
        }
        bolEditing = false;
        bolAdding = false;
        //showOption(optionRow);
        setNormalMode();
        refreshRecord();
        resetColors();
        //changeColors();
    }

    private boolean removeEmptyFields()
    {
        if (txtConfiguration.getText().trim().equals(""))
        {
            JOptionPane.showMessageDialog(this, bundle.getString("ThisFieldCantBeEmpty") + "\r\n" + bundle.getString("ConfigurationName"), bundle.getString("Impossible2Update"), JOptionPane.WARNING_MESSAGE);
            return true;
        }

        return false;
    }

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt)
    {
        save();
    }

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt)
    {
        if ((bolAdding == false) && (bolEditing == false) && (bolDeleting == false))
        {
            addRecord();
        }
    }

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt)
    {
        removeRec();
    }

    /*
     * private void updateColors() { pnlControlBar.setBackground(colorButtonsBackground);
     * resetColors();
    }
     */
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt)
    {
        if ((bolAdding == false) && (bolEditing == false))
        {
            showOption(nbOfRows);
            resetColors();
        }
    }

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt)
    {
        if ((optionRow < nbOfRows) && (bolAdding == false) && (bolEditing == false))
        {
            showOption(optionRow + 1);
            resetColors();
        }
    }

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt)
    {
        if ((optionRow > 1) && (bolAdding == false) && (bolEditing == false))
        {
            showOption(optionRow - 1);
            resetColors();
        }
    }

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt)
    {
        if ((bolAdding == false) && (bolEditing == false))
        {
            showOption(1);
            resetColors();
        }
    }

    /*
     * private void sldConfigStateChanged(javax.swing.event.ChangeEvent evt) { if ((bolSetting ==
     * false) && (bolAdding == false) && (bolEditing == false)) { optionRow = sldConfig.getValue();
     * showOption(optionRow); resetColors(); }
	 }
     */
    private void optOtherPtNoneActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optOtherPtAsteroidActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(true);
        cboComet.setVisible(false);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optOtherPtCometActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(true);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optOtherPtPartActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(true);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optOtherPtStarActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPtStar.setVisible(true);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkOtherPointActionPerformed(java.awt.event.ActionEvent evt)
    {
        pnlOtherPoint.setVisible(chkOtherPoint.isSelected());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private String getPlanetID(JComboBox planet)
    {
        String planetName = planet.getSelectedItem().toString();
        for (byte i = 0; i < Planets.getLast(); i++)
        {
            String strName = Planets.getPlanetName(i);
            if (strName.equals(planetName))
            {
                return new Integer(i).toString();
            }
        }
        return "-1";
    }

    private String getPlaceID(Places allPlaces, String placeName)
    {
        ArrayList p = allPlaces.getRecords();
        for (int i = 0; i < p.size(); i++)
        {
            ArrayList v = (ArrayList) p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1));
            if (strName.equals(placeName))
            {
                return strID;
            }
        }
        return "-1";
    }

    private String getEventID(Events allEvents, String eventName)
    {
        ArrayList p = allEvents.getRecords();
        for (int i = 0; i < p.size(); i++)
        {
            ArrayList v = (ArrayList) p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1)) + "; " + String.valueOf(v.get(2)) + "; " + String.valueOf(v.get(4));
            if (strName.equals(eventName))
            {
                return strID;
            }
        }
        return "-1";
    }

    private void cboPlaceCycleActionPerformed(java.awt.event.ActionEvent evt)
    {
        String selectedPlace = null2String(cboPlaceCycle.getSelectedItem());
        String strID = getPlaceID(places, selectedPlace);
        Place place = starLoginManager.getPlace(strID);
        lblLatitudeCycle.setText(place.getPlaceLatitude());
        lblLongitudeCycle.setText(place.getPlaceLongitude());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void cboPlaceReturnActionPerformed(java.awt.event.ActionEvent evt)
    {
        String selectedPlace = null2String(cboPlaceReturn.getSelectedItem());
        String strID = getPlaceID(places, selectedPlace);
        Place place = starLoginManager.getPlace(strID);
        lblLatitudeReturn.setText(place.getPlaceLatitude());
        lblLongitudeReturn.setText(place.getPlaceLongitude());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivOtherFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivOther.getText().equals(""))
        {
            txtDivOther.setText("0");
        }
        Double d = new Double(txtDivOther.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivOther.setText("1.0");
        }
    }

    private void txtDivOppositionFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivOpposition.getText().equals(""))
        {
            txtDivOpposition.setText("0");
        }
        Double d = new Double(txtDivOpposition.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivOpposition.setText("1.0");
        }
    }

    private void txtDivTrineFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivTrine.getText().equals(""))
        {
            txtDivTrine.setText("0");
        }
        Double d = new Double(txtDivTrine.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivTrine.setText("1.0");
        }
    }

    private void txtDivSquareFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivSquare.getText().equals(""))
        {
            txtDivSquare.setText("0");
        }
        Double d = new Double(txtDivSquare.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivSquare.setText("1.0");
        }
    }

    private void txtDivSextileFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivSextile.getText().equals(""))
        {
            txtDivSextile.setText("0");
        }
        Double d = new Double(txtDivSextile.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivSextile.setText("1.0");
        }
    }

    private void txtDivConjunctionFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtDivConjunction.getText().equals(""))
        {
            txtDivConjunction.setText("0");
        }
        Double d = new Double(txtDivConjunction.getText());
        if (d.doubleValue() < 1.0)
        {
            txtDivConjunction.setText("1.0");
        }
    }

    private void txtDivOtherkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivOther, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivOppositionkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivOpposition, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivTrinekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivTrine, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivSquarekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivSquare, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivSextilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivSextile, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtDivConjunctionkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtDivConjunction, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbvirtMinVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbvirtMinVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbVirtMajVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbVirtMajVirtMajkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMaj, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbColVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbColVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbColVirtMajkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbColVirtMaj, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbColColkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbColCol, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbJSVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbJSVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbJSvirtMajkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbJSvirtMaj, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbJSColkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbJSCol, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbJSJSkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbJSJS, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbIndivVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbIndivVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbIndivVirtMajkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbIndivVirtMaj, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbIndivColkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbIndivCol, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbIndivJSkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbIndivJS, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbIndivIndivkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbIndivIndiv, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumVirtMinkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumVirtMin, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumVirtMajkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumVirtMaj, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumColkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumCol, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumJSkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumJS, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumIndivkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumIndiv, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOrbLumLumkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtOrbLumLum, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtEqualsD2FocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtEqualsD2.getText().equals(""))
        {
            txtEqualsD2.setText("1");
        }
        Double d = new Double(txtEqualsD2.getText());
        String sText = d.toString();
        txtEqualsD2.setText(sText);
    }

    private void txtCorrespondD2FocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtCorrespondD2.getText().equals(""))
        {
            txtCorrespondD2.setText("1");
        }
        Double d = new Double(txtCorrespondD2.getText());
        String sText = d.toString();
        txtCorrespondD2.setText(sText);
    }

    private void txtEqualsD1FocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtEqualsD1.getText().equals(""))
        {
            txtEqualsD1.setText("1");
        }
        Double d = new Double(txtEqualsD1.getText());
        String sText = d.toString();
        txtEqualsD1.setText(sText);
    }

    private void txtCorrespondD1FocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtCorrespondD1.getText().equals(""))
        {
            txtCorrespondD1.setText("1");
        }
        Double d = new Double(txtCorrespondD1.getText());
        String sText = d.toString();
        txtCorrespondD1.setText(sText);
    }

    private void txtEqualsDSFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtEqualsDS.getText().equals(""))
        {
            txtEqualsDS.setText("1");
        }
        Double d = new Double(txtEqualsDS.getText());
        String sText = d.toString();
        txtEqualsDS.setText(sText);
    }

    private void txtCorrespondDSFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtCorrespondDS.getText().equals(""))
        {
            txtCorrespondDS.setText("1");
        }
        Double d = new Double(txtCorrespondDS.getText());
        String sText = d.toString();
        txtCorrespondDS.setText(sText);
    }

    private void txtCompositeChartsNBkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedInteger ui = new KTUnsignedInteger(evt, txtCompositeChartsNB, 2, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtCompositeChartsNBFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtCompositeChartsNB.getText().equals("") || txtCompositeChartsNB.getText().equals("1"))
        {
            txtCompositeChartsNB.setText("2");
        }
    }

    private void txtEqualsD2keyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtEqualsD2, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtCorrespondD2keyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtCorrespondD2, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtEqualsD1keyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtEqualsD1, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtCorrespondD1keyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtCorrespondD1, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtEqualsDSkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtEqualsDS, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtCorrespondDSkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtCorrespondDS, 5, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtValueOtherAspectFocusLost(java.awt.event.FocusEvent evt)
    {
        if (txtValueOtherAspect.getText().equals(""))
        {
            txtValueOtherAspect.setText("0");
        }
        Integer i = new Integer(txtValueOtherAspect.getText());
        if (i.intValue() > 180)
        {
            txtValueOtherAspect.setText("180");
        }
    }

    private void txtValueOtherAspectkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedInteger ui = new KTUnsignedInteger(evt, txtValueOtherAspect, 3, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOtherAspectkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtOtherAspect, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtQuadriNonagonkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtQuadriNonagon, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtInconjunctkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtInconjunct, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtBiquintilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtBiquintile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSesquiSquarekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSesquiSquare, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtTriDectilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtTriDectile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtQuintilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtQuintile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSeptilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSeptile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSemiSquarekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSemiSquare, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtNonagonekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtNonagone, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSemiQuintilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSemiQuintile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSemiSextilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSemiSextile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtVigintilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtVigintile, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtOppositionkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtOpposition, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtTrinekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtTrine, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSquarekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtSquare, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtSextilekeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtConjunction, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorQuadriNonagonMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorQuadriNonagon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorQuadriNonagon.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtConjunctionkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTAspectKind ak = new KTAspectKind(evt, txtConjunction, 1, neutralColor, dynamicColor, harmonicColor, evt.getKeyCode());
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorOtherAspectMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorOtherAspect.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorOtherAspect.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorInconjunctMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorInconjunct.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorInconjunct.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorBiQuintileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorBiQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorBiQuintile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSesquiSquareMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSesquiSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSesquiSquare.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorTridectileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorTridectile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorTridectile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorQuintileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorQuintile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSeptileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSeptile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSeptile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSemiSquareMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSemiSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSemiSquare.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorNonagonMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorNonagon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorNonagon.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSemiQuintileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSemiQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSemiQuintile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSemiSextileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSemiSextile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSemiSextile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorVigintileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorVigintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorVigintile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorOppositionMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorOpposition.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorOpposition.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorTrineMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorTrine.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorTrine.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSquareMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSquare.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSextileMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSextile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSextile.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorConjunctionMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorConjunction.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorConjunction.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void txtHarmonicNBkeyTyped(java.awt.event.KeyEvent evt)
    {
        KTUnsignedInteger ui = new KTUnsignedInteger(evt, txtHarmonicNB, 2, kc);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void sldCharactersStateChanged(javax.swing.event.ChangeEvent evt)
    {
        int value = sldCharacters.getValue();
        Font f = lblCharactersSize.getFont();
        lblCharactersSize.setFont(new Font(f.getName(), Font.PLAIN, value));
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void sldPlanetsStateChanged(javax.swing.event.ChangeEvent evt)
    {
        int value = sldPlanets.getValue();
        Font f = lblPlanetSize.getFont();
        lblPlanetSize.setFont(new Font(f.getName(), Font.BOLD, value));
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void sldSignsStateChanged(javax.swing.event.ChangeEvent evt)
    {
        int value = sldSigns.getValue();
        Font f = lblSignSize.getFont();
        lblSignSize.setFont(new Font(f.getName(), Font.BOLD, value));
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorHarmonicMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorHarmonic.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorHarmonic.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorDynamicMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorDynamic.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorDynamic.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorNeutralMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorNeutral.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorNeutral.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorWaterMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorWater.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorWater.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorAirMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorAir.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorAir.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorEarthMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorEarth.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorEarth.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorFireMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorFire.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFire.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorTextMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorText.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorText.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorVulcanMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorVulcan.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorVulcan.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorAsteroidsMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorAsteroids.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorAsteroids.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorHousesMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorHouses.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorHouses.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorNodesMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorNodes.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorNodes.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorGaiaMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorGaia.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorGaia.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorPlutoMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorPluto.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPluto.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorNeptuneMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorNeptune.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorNeptune.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorUranusMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorUranus.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorUranus.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSaturnMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSaturn.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSaturn.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorJupiterMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorJupiter.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorJupiter.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorMarsMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorMars.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorMars.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorVenusMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorVenus.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorVenus.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorMercuryMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorMercury.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorMercury.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorMoonMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorMoon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorMoon.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void lblColorSunMouseClicked(java.awt.event.MouseEvent evt)
    {
        color = lblColorSun.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSun.setBackground(color);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optPlacidusActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Placidus;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optKochActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Koch;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optAlcabitiusActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Alcabitius;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optAlbategniusActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Albategnius;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optAbenragelActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Abenragel;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optZodiacalActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Zodiacal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optZenithalActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Zenithal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optWieselActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Wiesel;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optSolarActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Solar;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optRegiomontanusActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Regiomontanus;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optPorpyreActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Porphyre;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optNodalActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Nodal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optMaternusMCActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.MaternusMC;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optMaternusAsActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.MaternusAs;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optBazchenoffActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Bazchenoff;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optColinEvansActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.ColinEvans;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optEquatorialRegularActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.EquatorialRegular;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optCampanusActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Campanus;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optSemiAngularActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.SemiAngular;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optTwoHoursActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.TwoHours;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void optAncientActionPerformed(java.awt.event.ActionEvent evt)
    {
        houseSys = HouseSystem.Ancient;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHeliocentricSiderealActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.HelioSidereal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHeliocentricNormalActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.HelioNormal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkLocalActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Local;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkDomitudesActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Domitudes;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkEclipticActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Ecliptic;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkEquatorialActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Equatorial;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSiderealActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Sidereal;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkTropicalActionPerformed(java.awt.event.ActionEvent evt)
    {
        coordSys = CoordSystem.Tropical;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHeliocentricActionPerformed(java.awt.event.ActionEvent evt)
    {
        boolean bolHelio = chkHeliocentric.isSelected();
        chkTropical.setVisible(!bolHelio);
        chkSidereal.setVisible(!bolHelio);
        chkEquatorial.setVisible(!bolHelio);
        chkEcliptic.setVisible(!bolHelio);
        chkLocal.setVisible(!bolHelio);
        chkDomitudes.setVisible(!bolHelio);
        chkHeliocentricNormal.setVisible(bolHelio);
        chkHeliocentricSidereal.setVisible(bolHelio);
    }

    private void chkGeocentricActionPerformed(java.awt.event.ActionEvent evt)
    {
        boolean bolGeo = chkGeocentric.isSelected();
        chkTropical.setVisible(bolGeo);
        chkSidereal.setVisible(bolGeo);
        chkEquatorial.setVisible(bolGeo);
        chkEcliptic.setVisible(bolGeo);
        chkLocal.setVisible(bolGeo);
        chkDomitudes.setVisible(bolGeo);
        chkHeliocentricNormal.setVisible(!bolGeo);
        chkHeliocentricSidereal.setVisible(!bolGeo);
    }

    private void chkProjectiveActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkProjective.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.projective)
        {
            chkProjective.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.projective;
            chkProjective.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkHarmonicActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkHarmonic.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.harmonic)
        {
            chkHarmonic.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.harmonic;
            chkHarmonic.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkFreeActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkFree.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.free)
        {
            chkFree.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.free;
            chkFree.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private byte selectedCharts()
    {
        byte i = 0;
        if (chkNormal.isSelected() == true)
        {
            i += 1;
        }
        if (chkAstronomical.isSelected() == true)
        {
            i += 1;
        }
        if (chkSeed.isSelected() == true)
        {
            i += 1;
        }
        if (chkSymbolicDir.isSelected() == true)
        {
            i += 1;
        }
        if (chkPrimaryDir.isSelected() == true)
        {
            i += 1;
        }
        if (chkSecondaryDir.isSelected() == true)
        {
            i += 1;
        }
        if (chkTransits.isSelected() == true)
        {
            i += 1;
        }
        if (chkRevolution.isSelected() == true)
        {
            i += 1;
        }
        if (chkCycle.isSelected() == true)
        {
            i += 1;
        }
        if (chkSynastry.isSelected() == true)
        {
            i += 1;
        }
        if (chkComposite.isSelected() == true)
        {
            i += 1;
        }
        if (chkFree.isSelected() == true)
        {
            i += 1;
        }
        if (chkProjective.isSelected() == true)
        {
            i += 1;
        }
        if (chkHarmonic.isSelected() == true)
        {
            i += 1;
        }
        return i;
    }

    private void chkCompositeActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkComposite.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.composite)
        {
            chkComposite.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.composite;
            chkComposite.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSynastryActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSynastry.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.synastry)
        {
            chkSynastry.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.synastry;
            chkSynastry.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkCycleActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkCycle.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.cycle)
        {
            chkCycle.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.cycle;
            chkCycle.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkRevolutionActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkRevolution.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.revolution)
        {
            chkRevolution.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.revolution;
            chkRevolution.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkTransitsActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkTransits.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.transit)
        {
            chkTransits.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.transit;
            chkTransits.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSecondaryDirActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSecondaryDir.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.secondaryDir)
        {
            chkSecondaryDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.secondaryDir;
            chkSecondaryDir.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkPrimaryDirActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkPrimaryDir.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.primaryDir)
        {
            chkPrimaryDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.primaryDir;
            chkPrimaryDir.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSymbolicDirActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSymbolicDir.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.symbolicDir)
        {
            chkSymbolicDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.symbolicDir;
            chkSymbolicDir.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkSeedActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSeed.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.seed)
        {
            chkSeed.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.seed;
            chkSeed.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkNormalActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkNormal.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.normal)
        {
            chkNormal.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.normal;
            chkNormal.setSelected(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void chkAstronomicalActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkAstronomical.setSelected(true);
            }
        }
        else if (currentSelectedChart == ChartKind.local)
        {
            chkAstronomical.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.local;
            chkAstronomical.setSelected(true);
            pnlCoordSystem.setEnabled(false);
            pnlHouseSystem.setEnabled(false);
        }
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void jOptSingleSelectionActionPerformed(java.awt.event.ActionEvent evt)
    {
        unselectAllChartKinds();
        chkNormal.setSelected(true);
        currentSelectedChart = ChartKind.normal;
        //btnSelectAll.setVisible(false);
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void jOptMultiSelectionActionPerformed(java.awt.event.ActionEvent evt)
    {
        //btnSelectAll.setVisible(true);
        currentSelectedChart = ChartKind.all;
        if (bolSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }

    private void unselectAllChartKinds()
    {
        chkNormal.setSelected(false);
        chkAstronomical.setSelected(false);
        chkSeed.setSelected(false);
        chkSymbolicDir.setSelected(false);
        chkPrimaryDir.setSelected(false);
        chkSecondaryDir.setSelected(false);
        chkTransits.setSelected(false);
        chkRevolution.setSelected(false);
        chkCycle.setSelected(false);
        chkSynastry.setSelected(false);
        chkComposite.setSelected(false);
        chkFree.setSelected(false);
        chkProjective.setSelected(false);
        chkHarmonic.setSelected(false);
    }

    private void btnSelectAllActionPerformed(java.awt.event.ActionEvent evt)
    {
        chkNormal.setSelected(true);
        chkAstronomical.setSelected(true);
        chkSeed.setSelected(true);
        chkSymbolicDir.setSelected(true);
        chkPrimaryDir.setSelected(true);
        chkSecondaryDir.setSelected(true);
        chkTransits.setSelected(true);
        chkRevolution.setSelected(true);
        chkCycle.setSelected(true);
        chkSynastry.setSelected(true);
        chkComposite.setSelected(true);
        chkFree.setSelected(true);
        chkProjective.setSelected(true);
        chkHarmonic.setSelected(true);
        jOptMultiSelection.setSelected(true);
        bolEditing = true;
        setEditMode();
    }

    /**
     * close the window
     */
    private void exitForm(java.awt.event.WindowEvent evt)
    {
        if (askToSave() == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
        {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        if (parentForm instanceof OutilsForm)
        {
            ((OutilsForm) parentForm).setChartsOptionsFrame(false);
        }
        setVisible(false);
        //MainClass.changeColors();
        dispose();
    }
    // Variables declaration
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSelectAll;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox cboAsteroid;
    private javax.swing.JComboBox cboComet;
    private javax.swing.JComboBox cboD1;
    private javax.swing.JComboBox cboD2;
    private javax.swing.JComboBox cboDS;
    private javax.swing.JComboBox cboPart;
    private javax.swing.JComboBox cboPartMinus;
    private javax.swing.JComboBox cboPartPlus;
    private javax.swing.JComboBox cboPartRef;
    private javax.swing.JComboBox cboDefaultEvent;
    private javax.swing.JComboBox cboDefaultPlace;
    private javax.swing.JComboBox cboPlaceCycle;
    private javax.swing.JComboBox cboPlaceReturn;
    private javax.swing.JComboBox cboPlanet1Cycle;
    private javax.swing.JComboBox cboPlanet2Cycle;
    private javax.swing.JComboBox cboPlanetReturn;
    private javax.swing.JComboBox cboStarIdentity;
    private javax.swing.JCheckBox chkAspectAS;
    private javax.swing.JCheckBox chkAspectCeres;
    private javax.swing.JCheckBox chkAspectChiron;
    private javax.swing.JCheckBox chkAspectEast;
    private javax.swing.JCheckBox chkAspectGaia;
    private javax.swing.JCheckBox chkAspectJuno;
    private javax.swing.JCheckBox chkAspectJupiter;
    private javax.swing.JCheckBox chkAspectLilith;
    private javax.swing.JCheckBox chkAspectMC;
    private javax.swing.JCheckBox chkAspectMars;
    private javax.swing.JCheckBox chkAspectMercury;
    private javax.swing.JCheckBox chkAspectMoon;
    private javax.swing.JCheckBox chkAspectNeptune;
    private javax.swing.JCheckBox chkAspectNodes;
    private javax.swing.JCheckBox chkAspectOtherPoint;
    private javax.swing.JCheckBox chkAspectPallas;
    private javax.swing.JCheckBox chkAspectPluto;
    private javax.swing.JCheckBox chkAspectSaturn;
    private javax.swing.JCheckBox chkAspectSun;
    private javax.swing.JCheckBox chkAspectUranus;
    private javax.swing.JCheckBox chkAspectVenus;
    private javax.swing.JCheckBox chkAspectVertex;
    private javax.swing.JCheckBox chkAspectVesta;
    private javax.swing.JCheckBox chkAspectVulcan;
    private javax.swing.JCheckBox chkAspectZenith;
    private javax.swing.JCheckBox chkAspects;
    private javax.swing.JCheckBox chkAspectsSymbol;
    private javax.swing.JCheckBox chkAsteroids;
    private javax.swing.JCheckBox chkAstronomical;
    private javax.swing.JCheckBox chkBarycenter;
    private javax.swing.JCheckBox chkBiQuintile;
    private javax.swing.JCheckBox chkCeres;
    private javax.swing.JCheckBox chkChiron;
    private javax.swing.JCheckBox chkComposite;
    private javax.swing.JCheckBox chkConjunction;
    private javax.swing.JCheckBox chkConstellations;
    private javax.swing.JCheckBox chkCoordinates;
    private javax.swing.JCheckBox chkCycle;
    private javax.swing.JCheckBox chkDefaultConfiguration;
    private javax.swing.JCheckBox chkEast;
    private javax.swing.JRadioButton chkEcliptic;
    private javax.swing.JRadioButton chkEquatorial;
    private javax.swing.JCheckBox chkFree;
    private javax.swing.JCheckBox chkGaia;
    private javax.swing.JRadioButton chkGeocentric;
    private javax.swing.JCheckBox chkHarmonic;
    private javax.swing.JRadioButton chkHeliocentric;
    private javax.swing.JRadioButton chkHeliocentricNormal;
    private javax.swing.JRadioButton chkHeliocentricSidereal;
    private javax.swing.JCheckBox chkHouses;
    private javax.swing.JCheckBox chkHousesCoord;
    private javax.swing.JCheckBox chkInconjunct;
    private javax.swing.JCheckBox chkJuno;
    private javax.swing.JCheckBox chkJupiter;
    private javax.swing.JCheckBox chkLilith;
    private javax.swing.JRadioButton chkLocal;
    private javax.swing.JRadioButton chkDomitudes;
    private javax.swing.JCheckBox chkMars;
    private javax.swing.JCheckBox chkMercury;
    private javax.swing.JCheckBox chkMoon;
    private javax.swing.JCheckBox chkNN;
    private javax.swing.JCheckBox chkNeptune;
    private javax.swing.JCheckBox chkNonagon;
    private javax.swing.JCheckBox chkNormal;
    private javax.swing.JCheckBox chkOpposition;
    private javax.swing.JCheckBox chkOtherAspect;
    private javax.swing.JCheckBox chkOtherPoint;
    private javax.swing.JCheckBox chkPallas;
    private javax.swing.JCheckBox chkPluto;
    private javax.swing.JCheckBox chkPrecession;
    private javax.swing.JCheckBox chkPrimaryDir;
    private javax.swing.JCheckBox chkProjective;
    private javax.swing.JCheckBox chkQuadriNonagon;
    private javax.swing.JCheckBox chkQuintile;
    private javax.swing.JCheckBox chkRevolution;
    private javax.swing.JCheckBox chkSaturn;
    private javax.swing.JCheckBox chkSecondaryDir;
    private javax.swing.JCheckBox chkSeed;
    private javax.swing.JCheckBox chkSemiQuintile;
    private javax.swing.JCheckBox chkSemiSextile;
    private javax.swing.JCheckBox chkSemiSquare;
    private javax.swing.JCheckBox chkSeptile;
    private javax.swing.JCheckBox chkSesquiSquare;
    private javax.swing.JCheckBox chkSextile;
    private javax.swing.JCheckBox chkShaded;
    private javax.swing.JRadioButton chkSidereal;
    private javax.swing.JCheckBox chkSignsName;
    private javax.swing.JCheckBox chkSquare;
    private javax.swing.JCheckBox chkStars;
    private javax.swing.JCheckBox chkStraightLines;
    private javax.swing.JCheckBox chkSun;
    private javax.swing.JCheckBox chkSymbolicDir;
    private javax.swing.JCheckBox chkSynastry;
    private javax.swing.JCheckBox chkTransits;
    private javax.swing.JCheckBox chkTriDectile;
    private javax.swing.JCheckBox chkTrine;
    private javax.swing.JRadioButton chkTropical;
    private javax.swing.JCheckBox chkTrueLilith;
    private javax.swing.JCheckBox chkUranus;
    private javax.swing.JCheckBox chkVenus;
    private javax.swing.JCheckBox chkVertex;
    private javax.swing.JCheckBox chkVesta;
    private javax.swing.JCheckBox chkVigintile;
    private javax.swing.JCheckBox chkVulcan;
    private javax.swing.JCheckBox chkZenith;
    private javax.swing.ButtonGroup grpAstronView;
    private javax.swing.ButtonGroup grpBarycenter;
    private javax.swing.ButtonGroup grpChartChoice;
    private javax.swing.ButtonGroup grpColorMode;
    private javax.swing.ButtonGroup grpCompositeFrom;
    private javax.swing.ButtonGroup grpGeo;
    private javax.swing.ButtonGroup grpGeoHelio;
    private javax.swing.ButtonGroup grpHelio;
    private javax.swing.ButtonGroup grpHouseSystem;
    private javax.swing.ButtonGroup grpOtherPoint;
    private javax.swing.ButtonGroup grpSavedCharts;
    private javax.swing.ButtonGroup grpZodDir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    //private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    //private javax.swing.JLabel jLabel132;
    //private javax.swing.JLabel jLabel133;
    //private javax.swing.JLabel jLabel134;
    //private javax.swing.JLabel jLabel135;
    //private javax.swing.JLabel jLabel136;
    //private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    //private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    //private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel lblZodiacSize;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel lblAspectsColorMode;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JRadioButton jOptMultiSelection;
    private javax.swing.JRadioButton jOptSingleSelection;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel108;
    private javax.swing.JPanel jPanel109;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel110;
    private javax.swing.JPanel jPanel111;
    private javax.swing.JPanel jPanel112;
    private javax.swing.JPanel jPanel113;
    private javax.swing.JPanel jPanel114;
    private javax.swing.JPanel jPanel115;
    private javax.swing.JPanel jPanel116;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel118;
    private javax.swing.JPanel jPanel119;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel120;
    private javax.swing.JPanel jPanel121;
    private javax.swing.JPanel jPanel122;
    private javax.swing.JPanel jPanel123;
    private javax.swing.JPanel jPanel124;
    private javax.swing.JPanel jPanel125;
    private javax.swing.JPanel jPanel126;
    private javax.swing.JPanel jPanel127;
    private javax.swing.JPanel jPanel128;
    private javax.swing.JPanel jPanel129;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel130;
    private javax.swing.JPanel jPanel131;
    private javax.swing.JPanel jPanel132;
    private javax.swing.JPanel jPanel133;
    private javax.swing.JPanel jPanel134;
    private javax.swing.JPanel jPanel135;
    private javax.swing.JPanel jPanel136;
    private javax.swing.JPanel jPanel137;
    private javax.swing.JPanel jPanel138;
    private javax.swing.JPanel jPanel139;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel140;
    private javax.swing.JPanel jPanel141;
    private javax.swing.JPanel jPanel142;
    private javax.swing.JPanel jPanel143;
    private javax.swing.JPanel jPanel144;
    private javax.swing.JPanel jPanel145;
    private javax.swing.JPanel jPanel146;
    private javax.swing.JPanel jPanel147;
    private javax.swing.JPanel jPanel148;
    private javax.swing.JPanel jPanel149;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel150;
    private javax.swing.JPanel jPanel151;
    private javax.swing.JPanel jPanel152;
    private javax.swing.JPanel jPanel153;
    private javax.swing.JPanel jPanel154;
    private javax.swing.JPanel jPanel155;
    private javax.swing.JPanel jPanel156;
    private javax.swing.JPanel jPanel157;
    private javax.swing.JPanel jPanel158;
    private javax.swing.JPanel jPanel159;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel160;
    private javax.swing.JPanel jPanel161;
    private javax.swing.JPanel jPanel162;
    private javax.swing.JPanel jPanel163;
    private javax.swing.JPanel jPanel164;
    private javax.swing.JPanel jPanel165;
    private javax.swing.JPanel jPanel166;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel pnlControlBar;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel64b;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblCharactersSize;
    private javax.swing.JLabel lblColorAir;
    private javax.swing.JLabel lblColorAsteroids;
    private javax.swing.JLabel lblColorBiQuintile;
    private javax.swing.JLabel lblColorConjunction;
    private javax.swing.JLabel lblColorDynamic;
    private javax.swing.JLabel lblColorEarth;
    private javax.swing.JLabel lblColorFire;
    private javax.swing.JLabel lblColorGaia;
    private javax.swing.JLabel lblColorHarmonic;
    private javax.swing.JLabel lblColorHouses;
    private javax.swing.JLabel lblColorInconjunct;
    private javax.swing.JLabel lblColorJupiter;
    private javax.swing.JLabel lblColorMars;
    private javax.swing.JLabel lblColorMercury;
    private javax.swing.JLabel lblColorMoon;
    private javax.swing.JLabel lblColorNeptune;
    private javax.swing.JLabel lblColorNeutral;
    private javax.swing.JLabel lblColorNodes;
    private javax.swing.JLabel lblColorNonagon;
    private javax.swing.JLabel lblColorOpposition;
    private javax.swing.JLabel lblColorOtherAspect;
    private javax.swing.JLabel lblColorPluto;
    private javax.swing.JLabel lblColorQuadriNonagon;
    private javax.swing.JLabel lblColorQuintile;
    private javax.swing.JLabel lblColorSaturn;
    private javax.swing.JLabel lblColorSemiQuintile;
    private javax.swing.JLabel lblColorSemiSextile;
    private javax.swing.JLabel lblColorSemiSquare;
    private javax.swing.JLabel lblColorSeptile;
    private javax.swing.JLabel lblColorSesquiSquare;
    private javax.swing.JLabel lblColorSextile;
    private javax.swing.JLabel lblColorSquare;
    private javax.swing.JLabel lblColorSun;
    private javax.swing.JLabel lblColorText;
    private javax.swing.JLabel lblColorTridectile;
    private javax.swing.JLabel lblColorTrine;
    private javax.swing.JLabel lblColorUranus;
    private javax.swing.JLabel lblColorVenus;
    private javax.swing.JLabel lblColorVigintile;
    private javax.swing.JLabel lblColorVulcan;
    private javax.swing.JLabel lblColorWater;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblLatitudeCycle;
    private javax.swing.JLabel lblLatitudeReturn;
    private javax.swing.JLabel lblLongitudeCycle;
    private javax.swing.JLabel lblLongitudeReturn;
    private javax.swing.JLabel lblPlanetSize;
    private javax.swing.JLabel lblSignSize;
    private javax.swing.JLabel lblStarName;
    private javax.swing.JRadioButton optAbenragel;
    private javax.swing.JRadioButton optAlbategnius;
    private javax.swing.JRadioButton optAlcabitius;
    private javax.swing.JRadioButton optAncient;
    private javax.swing.JRadioButton optBazchenoff;
    private javax.swing.JRadioButton optCampanus;
    private javax.swing.JRadioButton optColinEvans;
    private javax.swing.JRadioButton optColorMode1;
    private javax.swing.JRadioButton optColorMode2;
    private javax.swing.JRadioButton optCompositeFromAS;
    private javax.swing.JRadioButton optCompositeFromMC;
    private javax.swing.JRadioButton optDifferentWeights;
    private javax.swing.JRadioButton optEastAS;
    private javax.swing.JRadioButton optEastAries;
    private javax.swing.JRadioButton optEquatorialRegular;
    private javax.swing.JRadioButton optHorizon;
    private javax.swing.JRadioButton optKoch;
    private javax.swing.JRadioButton optMaternusAs;
    private javax.swing.JRadioButton optMaternusMC;
    private javax.swing.JRadioButton optNodal;
    private javax.swing.JRadioButton optOtherPtAsteroid;
    private javax.swing.JRadioButton optOtherPtComet;
    private javax.swing.JRadioButton optOtherPtNone;
    private javax.swing.JRadioButton optOtherPtPart;
    private javax.swing.JRadioButton optOtherPtStar;
    private javax.swing.JRadioButton optPlacidus;
    private javax.swing.JRadioButton optPorpyre;
    private javax.swing.JRadioButton optRegiomontanus;
    private javax.swing.JRadioButton optSemiAngular;
    private javax.swing.JRadioButton optSingleWeight;
    private javax.swing.JRadioButton optSolar;
    private javax.swing.JRadioButton optTwoHours;
    private javax.swing.JRadioButton optWiesel;
    private javax.swing.JRadioButton optZenith;
    private javax.swing.JRadioButton optZenithal;
    private javax.swing.JRadioButton optZodiacal;
    //private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnlAspectColorChoice;
    private javax.swing.JPanel pnlAspects;
    private javax.swing.JPanel pnlChartColorChoice;
    private javax.swing.JPanel pnlChartKind;
    private javax.swing.JPanel pnlChartLook;
    private javax.swing.JPanel pnlComposite;
    private javax.swing.JPanel pnlCoordSystem;
    private javax.swing.JPanel pnlCycle;
    private javax.swing.JPanel pnlHarmonic;
    private javax.swing.JPanel pnlHouseSystem;
    private javax.swing.JPanel pnlLocal;
    private javax.swing.JPanel pnlOrbs;
    private javax.swing.JPanel pnlOtherPoint;
    private javax.swing.JPanel pnlOtherPtPart;
    private javax.swing.JPanel pnlOtherPtStar;
    private javax.swing.JPanel pnlPlanets;
    private javax.swing.JPanel pnlPrimaryDir;
    private javax.swing.JPanel pnlRevolution;
    private javax.swing.JPanel pnlSecondaryDir;
    private javax.swing.JPanel pnlSymbolicDir;
    private javax.swing.JPanel pnlWindows;
    private javax.swing.JSlider sldCharacters;
    //private javax.swing.JSlider sldConfig;
    private javax.swing.JSlider sldPlanets;
    private javax.swing.JSlider sldSigns;
    private javax.swing.JSlider sldStars;
    private javax.swing.JSlider sldZodiac;
    private javax.swing.JTabbedPane tabSettings;
    private javax.swing.JTextField txtCounter;
    private javax.swing.JTextField txtBiquintile;
    private javax.swing.JTextField txtCompositeChartsNB;
    private javax.swing.JTextField txtConfiguration;
    private javax.swing.JTextField txtConjunction;
    private javax.swing.JTextField txtCorrespondD1;
    private javax.swing.JTextField txtCorrespondD2;
    private javax.swing.JTextField txtCorrespondDS;
    private javax.swing.JTextField txtDivConjunction;
    private javax.swing.JTextField txtDivOpposition;
    private javax.swing.JTextField txtDivOther;
    private javax.swing.JTextField txtDivSextile;
    private javax.swing.JTextField txtDivSquare;
    private javax.swing.JTextField txtDivTrine;
    private javax.swing.JTextField txtEqualsD1;
    private javax.swing.JTextField txtEqualsD2;
    private javax.swing.JTextField txtEqualsDS;
    private javax.swing.JTextField txtHarmonicNB;
    private javax.swing.JTextField txtInconjunct;
    private javax.swing.JTextField txtNonagone;
    private javax.swing.JTextField txtOpposition;
    private javax.swing.JTextField txtOrbColCol;
    private javax.swing.JTextField txtOrbColVirtMaj;
    private javax.swing.JTextField txtOrbColVirtMin;
    private javax.swing.JTextField txtOrbIndivCol;
    private javax.swing.JTextField txtOrbIndivIndiv;
    private javax.swing.JTextField txtOrbIndivJS;
    private javax.swing.JTextField txtOrbIndivVirtMaj;
    private javax.swing.JTextField txtOrbIndivVirtMin;
    private javax.swing.JTextField txtOrbJSCol;
    private javax.swing.JTextField txtOrbJSJS;
    private javax.swing.JTextField txtOrbJSVirtMin;
    private javax.swing.JTextField txtOrbJSvirtMaj;
    private javax.swing.JTextField txtOrbLumCol;
    private javax.swing.JTextField txtOrbLumIndiv;
    private javax.swing.JTextField txtOrbLumJS;
    private javax.swing.JTextField txtOrbLumLum;
    private javax.swing.JTextField txtOrbLumVirtMaj;
    private javax.swing.JTextField txtOrbLumVirtMin;
    private javax.swing.JTextField txtOrbVirtMajVirtMaj;
    private javax.swing.JTextField txtOrbVirtMajVirtMin;
    private javax.swing.JTextField txtOrbvirtMinVirtMin;
    private javax.swing.JTextField txtOtherAspect;
    private javax.swing.JTextField txtOtherAspectName;
    private javax.swing.JTextField txtQuadriNonagon;
    private javax.swing.JTextField txtQuintile;
    private javax.swing.JTextField txtSemiQuintile;
    private javax.swing.JTextField txtSemiSextile;
    private javax.swing.JTextField txtSemiSquare;
    private javax.swing.JTextField txtSeptile;
    private javax.swing.JTextField txtSesquiSquare;
    private javax.swing.JTextField txtSextile;
    private javax.swing.JTextField txtSquare;
    private javax.swing.JTextField txtTriDectile;
    private javax.swing.JTextField txtTrine;
    private javax.swing.JTextField txtValueOtherAspect;
    private javax.swing.JTextField txtVigintile;
    private javax.swing.JPopupMenu jPMenuDelete;
    private javax.swing.JMenuItem mnuDelete;
}
