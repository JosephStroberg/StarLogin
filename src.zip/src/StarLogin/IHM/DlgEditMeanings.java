package StarLogin.IHM;

import StarLogin.StarLoginManager;
import java.awt.Cursor;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author Francois DESCHAMPS
 * @version 1.0.0
 */
public class DlgEditMeanings extends javax.swing.JDialog
{
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private boolean bolEditing = false;
    private boolean bSetting = true;
    private int kc; //key code
    private String meaning = "";
    private int opt = 0;
    private int indexHouses = 0;
    private int indexSigns = 0;
    private int indexPlanets = 0;
    private int indexPlanets2 = 0;

    
    /** Creates new form DialogColor */
    public DlgEditMeanings(java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        resetLangue();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bSetting = false;
        setNormalMode();
        setData();
        setVisible(true);
    }
    
    private void setData()
    {
        if (optHinS.isSelected())
        {
            meaning = starLoginManager.getStringFieldValue("houseinsign", "MEANING", " WHERE ID=" + cboHouses.getSelectedIndex() + " AND S_I=" + cboSigns.getSelectedIndex());
            cboHouses.setVisible(true);
            cboPlanets.setVisible(false);
            cboSigns.setVisible(true);
            cboPlanets2.setVisible(false);
            opt = 1;
        }
        else if (optPinS.isSelected())
        {
            meaning = starLoginManager.getStringFieldValue("planetinsign", "MEANING", " WHERE ID=" + cboPlanets.getSelectedIndex() + " AND S_I=" + cboSigns.getSelectedIndex());
            cboHouses.setVisible(false);
            cboPlanets.setVisible(true);
            cboSigns.setVisible(true);
            cboPlanets2.setVisible(false);
            opt = 2;
        }
        else if (optPinH.isSelected())
        {
            meaning = starLoginManager.getStringFieldValue("planetinhouse", "MEANING", " WHERE ID=" + cboPlanets.getSelectedIndex() + " AND H_I=" + cboHouses.getSelectedIndex());
            cboHouses.setVisible(true);
            cboPlanets.setVisible(true);
            cboSigns.setVisible(false);
            cboPlanets2.setVisible(false);
            opt = 0;
        }
        else
        {
            meaning = starLoginManager.getStringFieldValue("relationships", "MEANING", " WHERE ID1=" + cboPlanets.getSelectedIndex() + " AND ID2=" + cboPlanets2.getSelectedIndex());
            cboHouses.setVisible(false);
            cboPlanets.setVisible(true);
            cboSigns.setVisible(false);
            cboPlanets2.setVisible(true);
            opt = 3;
        }
        meaning = meaning.replace("\\r\\n", "\r\n");
        if (meaning.equals("-1"))
            meaning = "";
        txtMeaning.setText(meaning);
    }
    
    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        boolean result = true;
        meaning = txtMeaning.getText();
        meaning = meaning.replace("'", "''").replace("\\", "\\\\");
        if (bolEditing == true)
        {
            switch(opt)
            {
                case 0 : result = starLoginManager.updateDataBase("update planetinhouse SET MEANING='" + meaning + "' WHERE ID=" + indexPlanets + " AND H_I=" + indexHouses); break;
                case 1 : result = starLoginManager.updateDataBase("update houseinsign SET MEANING='" + meaning + "' WHERE ID=" + indexHouses + " AND S_I=" + indexSigns); break;
                case 2 : result = starLoginManager.updateDataBase("update planetinsign SET MEANING='" + meaning + "' WHERE ID=" + indexPlanets + " AND S_I=" + indexSigns); break;
                default : result = starLoginManager.updateDataBase("update relationships SET MEANING='" + meaning + "' WHERE ID1=" + indexPlanets + " AND ID2=" + indexPlanets2);
            }
            bolEditing = false;
            setNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return result;
    }
    
    private void keepOpt()
    {
        switch (opt)
        {
            case 0 : optPinH.setSelected(true); break;
            case 1 : optHinS.setSelected(true); break;
            case 2 : optPinS.setSelected(true); break;
            default : optAspects.setSelected(true);
        }
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        
        if (bolEditing)
        {
            if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
            {
                if (bClosing)
                    result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Meaning"),JOptionPane.YES_NO_OPTION);
                else
                    result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingEvent"),bundle.getString("Meaning"),JOptionPane.YES_NO_OPTION);
            }
            else
                result = JOptionPane.YES_OPTION;
            
        }
        return result;
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }
    
    private void resetLangue()
    {
        setTitle(bundle.getString("EditMeaning"));
        optPinH.setText(bundle.getString("PlanetInHouse"));
        optHinS.setText(bundle.getString("HouseInSign"));
        optPinS.setText(bundle.getString("PlanetInSign"));
        optAspects.setText(bundle.getString("Aspects"));
        lblMeaning.setText(bundle.getString("Meaning"));
    }

    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpTable = new javax.swing.ButtonGroup();
        pnlParams = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        optPinH = new javax.swing.JRadioButton();
        optHinS = new javax.swing.JRadioButton();
        optPinS = new javax.swing.JRadioButton();
        optAspects = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        cboPlanets = new javax.swing.JComboBox();
        cboHouses = new javax.swing.JComboBox();
        cboSigns = new javax.swing.JComboBox();
        cboPlanets2 = new javax.swing.JComboBox();
        pnlBoutons = new javax.swing.JPanel();
        lblMeaning = new javax.swing.JLabel();
        scrMeaning = new javax.swing.JScrollPane();
        txtMeaning = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new java.awt.BorderLayout(0, 5));

        pnlParams.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(910, 35));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel3.setOpaque(false);
        jPanel3.setPreferredSize(new java.awt.Dimension(745, 35));

        grpTable.add(optPinH);
        optPinH.setSelected(true);
        optPinH.setPreferredSize(new java.awt.Dimension(190, 23));
        optPinH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPinHActionPerformed(evt);
            }
        });
        jPanel3.add(optPinH);

        grpTable.add(optHinS);
        optHinS.setPreferredSize(new java.awt.Dimension(190, 23));
        optHinS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optHinSActionPerformed(evt);
            }
        });
        jPanel3.add(optHinS);

        grpTable.add(optPinS);
        optPinS.setPreferredSize(new java.awt.Dimension(190, 23));
        optPinS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPinSActionPerformed(evt);
            }
        });
        jPanel3.add(optPinS);

        grpTable.add(optAspects);
        optAspects.setPreferredSize(new java.awt.Dimension(190, 23));
        optAspects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAspectsActionPerformed(evt);
            }
        });
        jPanel3.add(optAspects);

        jPanel2.add(jPanel3, java.awt.BorderLayout.CENTER);

        jPanel4.setOpaque(false);
        jPanel4.setPreferredSize(new java.awt.Dimension(155, 35));

        cboPlanets.setFont(new java.awt.Font("StarLogin", 0, 14)); // NOI18N
        cboPlanets.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" }));
        cboPlanets.setPreferredSize(new java.awt.Dimension(70, 24));
        cboPlanets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPlanetsActionPerformed(evt);
            }
        });
        jPanel4.add(cboPlanets);

        cboHouses.setFont(new java.awt.Font("StarLogin", 0, 14)); // NOI18N
        cboHouses.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboHouses.setPreferredSize(new java.awt.Dimension(70, 24));
        cboHouses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboHousesActionPerformed(evt);
            }
        });
        jPanel4.add(cboHouses);

        cboSigns.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        cboSigns.setMaximumRowCount(12);
        cboSigns.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
        cboSigns.setPreferredSize(new java.awt.Dimension(70, 24));
        cboSigns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboSignsActionPerformed(evt);
            }
        });
        jPanel4.add(cboSigns);

        cboPlanets2.setFont(new java.awt.Font("StarLogin", 0, 14)); // NOI18N
        cboPlanets2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" }));
        cboPlanets2.setPreferredSize(new java.awt.Dimension(70, 24));
        cboPlanets2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPlanets2ActionPerformed(evt);
            }
        });
        jPanel4.add(cboPlanets2);

        jPanel2.add(jPanel4, java.awt.BorderLayout.EAST);

        pnlParams.add(jPanel2, java.awt.BorderLayout.NORTH);

        lblMeaning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMeaning.setPreferredSize(new java.awt.Dimension(150, 22));
        pnlBoutons.add(lblMeaning);

        scrMeaning.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        scrMeaning.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrMeaning.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrMeaning.setPreferredSize(new java.awt.Dimension(800, 500));

        txtMeaning.setLineWrap(true);
        txtMeaning.setWrapStyleWord(true);
        txtMeaning.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtMeaningKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtMeaningKeyPressed(evt);
            }
        });
        scrMeaning.setViewportView(txtMeaning);

        pnlBoutons.add(scrMeaning);

        pnlParams.add(pnlBoutons, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlParams, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
        {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
    }//GEN-LAST:event_formWindowClosing

    private void txtMeaningKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtMeaningKeyTyped
    {//GEN-HEADEREND:event_txtMeaningKeyTyped
        bolEditing = true;
        setEditMode();
        int size = 10000;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtMeaning.getText().length() >= size)
        {
            txtMeaning.setText(txtMeaning.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtMeaningKeyTyped

    private void txtMeaningKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtMeaningKeyPressed
    {//GEN-HEADEREND:event_txtMeaningKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtMeaning.setText(meaning);
        }
    }//GEN-LAST:event_txtMeaningKeyPressed

    private void optPinHActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPinHActionPerformed
    {//GEN-HEADEREND:event_optPinHActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                keepOpt();
                bSetting = false;
            }
            else
            {
                opt = 0;
                setData();
            }
        }
        else
        {
            opt = 0;
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_optPinHActionPerformed

    private void optHinSActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optHinSActionPerformed
    {//GEN-HEADEREND:event_optHinSActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                keepOpt();
                bSetting = false;
            }
            else
            {
                opt = 1;
                setData();
            }
        }
        else
        {
            opt = 1;
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_optHinSActionPerformed

    private void optPinSActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPinSActionPerformed
    {//GEN-HEADEREND:event_optPinSActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                keepOpt();
                bSetting = false;
            }
            else
            {
                opt = 2;
                setData();
            }
        }
        else
        {
            opt = 2;
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_optPinSActionPerformed

    private void cboPlanetsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboPlanetsActionPerformed
    {//GEN-HEADEREND:event_cboPlanetsActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                cboPlanets.setSelectedIndex(indexPlanets);
                bSetting = false;
            }
            else
            {
                indexPlanets = cboPlanets.getSelectedIndex();
                setData();
            }
        }
        else
        {
            indexPlanets = cboPlanets.getSelectedIndex();
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_cboPlanetsActionPerformed

    private void cboHousesActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboHousesActionPerformed
    {//GEN-HEADEREND:event_cboHousesActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                cboHouses.setSelectedIndex(indexHouses);
                bSetting = false;
            }
            else
            {
                indexHouses = cboHouses.getSelectedIndex();
                setData();
            }
        }
        else
        {
            indexHouses = cboHouses.getSelectedIndex();
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_cboHousesActionPerformed

    private void cboSignsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboSignsActionPerformed
    {//GEN-HEADEREND:event_cboSignsActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                cboSigns.setSelectedIndex(indexSigns);
                bSetting = false;
            }
            else
            {
                indexSigns = cboSigns.getSelectedIndex();
                setData();
            }
        }
        else
        {
            indexSigns = cboSigns.getSelectedIndex();
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_cboSignsActionPerformed

    private void cboPlanets2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboPlanets2ActionPerformed
    {//GEN-HEADEREND:event_cboPlanets2ActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                cboPlanets2.setSelectedIndex(indexPlanets2);
                bSetting = false;
            }
            else
            {
                indexPlanets2 = cboPlanets2.getSelectedIndex();
                setData();
            }
        }
        else
        {
            indexPlanets2 = cboPlanets2.getSelectedIndex();
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_cboPlanets2ActionPerformed

    private void optAspectsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAspectsActionPerformed
    {//GEN-HEADEREND:event_optAspectsActionPerformed
        if (bSetting)
            return;
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                bSetting = true;
                keepOpt();
                bSetting = false;
            }
            else
            {
                opt = 3;
                setData();
            }
        }
        else
        {
            opt = 3;
            bolEditing = false;
            setNormalMode();
            setData();
        }
    }//GEN-LAST:event_optAspectsActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cboHouses;
    private javax.swing.JComboBox cboPlanets;
    private javax.swing.JComboBox cboPlanets2;
    private javax.swing.JComboBox cboSigns;
    private javax.swing.ButtonGroup grpTable;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblMeaning;
    private javax.swing.JRadioButton optAspects;
    private javax.swing.JRadioButton optHinS;
    private javax.swing.JRadioButton optPinH;
    private javax.swing.JRadioButton optPinS;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlParams;
    private javax.swing.JScrollPane scrMeaning;
    private javax.swing.JTextArea txtMeaning;
    // End of variables declaration//GEN-END:variables
    
}
