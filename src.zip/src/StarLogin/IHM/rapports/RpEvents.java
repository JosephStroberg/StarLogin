/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * pfContratForm.java
 *
 * Created on 2011-07-12, 10:49:17
 */
package StarLogin.IHM.rapports;

import StarLogin.IHM.MainClass;
import StarLogin.IHM.MyReportViewer;
import StarLogin.IHM.components.KeyType.KTDateAstro;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.Enum.OS;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois
 */
public class RpEvents extends javax.swing.JFrame
{
    private java.util.ResourceBundle bundle;
    private StarLoginManager StarLoginManager = MainClass.starLoginManager;
    private String datemin = MainClass.getFormatedDate(" 1800-01-01");
    private String datemax = MainClass.no2defaultDate("", MainClass.DATE_CURRENT);
    private String critereField3 = "";
    private String critereField4 = "";
    private String critereField5 = "";
    private String critereField6 = "";
    private String critereField7 = "";
    private String critereDate = "";
    private String claircritereDate = "";
    private String claircritereField3 = "";
    private String claircritereField4 = "";
    private String claircritereField5 = "";
    private String claircritereField6 = "";
    private String claircritereField7 = "";
    private String filtreclair = "";
    private String filtre = "";
    private String ireportPath = new java.io.File("").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "").concat(OS.getSeparator()).concat("ireport").concat(OS.getSeparator());
    private int kc; //key code
    private int cp; //caret position
    private final String TABLE = "events";
    private final String FIELD1 = "SURNAME";
    private final String FIELD2 = "OTHERNAMES";
    private final String FIELD3 = "EVENTTYPE";
    private final String FIELD4 = "ENTITYTYPE";
    private final String FIELD5 = "PLACENAME";
    private final String FIELD6 = "SIGN";
    private final String FIELD7 = "ASCENDANT";
    
    /** Creates new form pfContratForm */
    public RpEvents(boolean bHide)
    {
        if (bHide)
        {
            btnPrintActionPerformed(null);
            this.dispose();
            return;
        }
        
        initComponents();
        //String date = FDate.curFrFormDate();
        datemax = " ".concat(datemax);
        txtDateMin.setText(datemin);
        txtDateMax.setText(datemax);
        resetLangue();
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/rapports.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        setCombos();
        
        this.setPreferredSize(new Dimension(1000, 700));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
    }
    
    private void setCombos()
    {
        DefaultListModel listModel3 = StarLoginManager.getListe2("SELECT distinct " + FIELD3 + " FROM events ORDER BY " + FIELD3);
        lstField3.setModel(listModel3);
        lstField3.setSelectedIndex(-1);
        DefaultListModel listModel4 = StarLoginManager.getListe2("SELECT distinct " + FIELD4 + " FROM events ORDER BY " + FIELD4);
        lstField4.setModel(listModel4);
        lstField4.setSelectedIndex(-1);
        DefaultListModel listModel5 = StarLoginManager.getListe2("SELECT distinct " + FIELD5 + " FROM events ORDER BY " + FIELD5);
        lstField5.setModel(listModel5);
        lstField5.setSelectedIndex(-1);
        DefaultListModel listModel6 = StarLoginManager.getListe2("SELECT distinct " + FIELD6 + " FROM events ORDER BY " + FIELD6);
        lstField6.setModel(listModel6);
        lstField6.setSelectedIndex(-1);
        DefaultListModel listModel7 = StarLoginManager.getListe2("SELECT distinct " + FIELD7 + " FROM events ORDER BY " + FIELD7);
        lstField7.setModel(listModel7);
        lstField7.setSelectedIndex(-1);
        
        if (!listModel3.isEmpty())
        {
            if (listModel3.lastElement() == "")
                listModel3.set(listModel3.getSize()-1, " ");
        }
        if (!listModel4.isEmpty())
        {
            if (listModel4.lastElement() == "")
                listModel4.set(listModel4.getSize()-1, " ");
        }
        if (!listModel5.isEmpty())
        {
            if (listModel5.lastElement() == "")
                listModel5.set(listModel5.getSize()-1, " ");
        }
        if (!listModel6.isEmpty())
        {
            if (listModel6.lastElement() == "")
                listModel6.set(listModel6.getSize()-1, " ");
        }
        if (!listModel7.isEmpty())
        {
            if (listModel7.lastElement() == "")
                listModel7.set(listModel7.getSize()-1, " ");
        }
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private void resetLangue()
    {
        bundle = MainClass.bundle;
        setTitle(bundle.getString("ParametresRapport"));
        btnReport.setToolTipText(bundle.getString("AfficherRapport"));
        btnPrint.setToolTipText(bundle.getString("ImprimerRapport"));
        btnSave.setToolTipText(bundle.getString("SauverRapport"));
        lblDateMin.setText(bundle.getString("EntreDateDu"));
        lblDateMax.setText(bundle.getString("EtDu"));
        chkField3.setText(bundle.getString("Graph"));
        chkField4.setText(bundle.getString("Graph"));
        chkField5.setText(bundle.getString("Graph"));
        chkField6.setText(bundle.getString("Graph"));
        chkField7.setText(bundle.getString("Graph"));
        btnGraphs.setText(bundle.getString("Graphs"));
        btnGraphs.setToolTipText(bundle.getString("DisplaySelectedGraphs"));
        lblField3.setText(bundle.getString(TABLE.concat(FIELD3)));
        lblField4.setText(bundle.getString(TABLE.concat(FIELD4)));
        lblField5.setText(bundle.getString(TABLE.concat(FIELD5)));
        lblField6.setText(bundle.getString(TABLE.concat(FIELD6)));
        lblField7.setText(bundle.getString(TABLE.concat(FIELD7)));
        optField4.setText(bundle.getString("Grouping"));
        optField3.setText(bundle.getString("Grouping"));
        optField5.setText(bundle.getString("Grouping"));
        optField6.setText(bundle.getString("Grouping"));
        optField7.setText(bundle.getString("Grouping"));
        optGroupNone.setText(bundle.getString("NoGrouping"));
        lblTri.setText(bundle.getString("Sorting"));
        cboTri1.addItem("");
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri2.addItem("");
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri3.addItem("");
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri4.addItem("");
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri1.setSelectedIndex(0);
        cboTri2.setSelectedIndex(0);
        cboTri3.setSelectedIndex(0);
        cboTri4.setSelectedIndex(0);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpGroup = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        btnReport = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        lblTri = new javax.swing.JLabel();
        cboTri1 = new javax.swing.JComboBox();
        cboTri2 = new javax.swing.JComboBox();
        cboTri3 = new javax.swing.JComboBox();
        cboTri4 = new javax.swing.JComboBox();
        jPanel14 = new javax.swing.JPanel();
        btnGraphs = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jPanel0 = new javax.swing.JPanel();
        lblDateMin = new javax.swing.JLabel();
        txtDateMin = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        lblDateMax = new javax.swing.JLabel();
        txtDateMax = new javax.swing.JTextField();
        pnlSelect1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblField3 = new javax.swing.JLabel();
        optField3 = new javax.swing.JRadioButton();
        chkField3 = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstField3 = new javax.swing.JList();
        pnlSelect2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        lblField4 = new javax.swing.JLabel();
        optField4 = new javax.swing.JRadioButton();
        chkField4 = new javax.swing.JCheckBox();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstField4 = new javax.swing.JList();
        pnlSelect3 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        lblField5 = new javax.swing.JLabel();
        optField5 = new javax.swing.JRadioButton();
        chkField5 = new javax.swing.JCheckBox();
        jScrollPane4 = new javax.swing.JScrollPane();
        lstField5 = new javax.swing.JList();
        pnlSelect4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        lblField6 = new javax.swing.JLabel();
        optField6 = new javax.swing.JRadioButton();
        chkField6 = new javax.swing.JCheckBox();
        jScrollPane5 = new javax.swing.JScrollPane();
        lstField6 = new javax.swing.JList();
        pnlSelect5 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        lblField7 = new javax.swing.JLabel();
        optField7 = new javax.swing.JRadioButton();
        chkField7 = new javax.swing.JCheckBox();
        jScrollPane6 = new javax.swing.JScrollPane();
        lstField7 = new javax.swing.JList();
        jPanel8 = new javax.swing.JPanel();
        optGroupNone = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel2.setPreferredSize(new java.awt.Dimension(123, 79));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/rapports2.png"))); // NOI18N
        btnReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportActionPerformed(evt);
            }
        });
        jPanel2.add(btnReport);

        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/printer2.png"))); // NOI18N
        btnPrint.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        jPanel2.add(btnPrint);

        btnSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/save2.png"))); // NOI18N
        btnSave.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel2.add(btnSave);

        jPanel13.setPreferredSize(new java.awt.Dimension(120, 650));

        lblTri.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTri.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(lblTri);

        cboTri1.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri1);

        cboTri2.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri2);

        cboTri3.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri3);

        cboTri4.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri4);

        jPanel14.setPreferredSize(new java.awt.Dimension(100, 200));
        jPanel13.add(jPanel14);

        btnGraphs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/chart.png"))); // NOI18N
        btnGraphs.setSize(new java.awt.Dimension(120, 36));
        btnGraphs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraphsActionPerformed(evt);
            }
        });
        jPanel13.add(btnGraphs);

        jPanel2.add(jPanel13);

        getContentPane().add(jPanel2, java.awt.BorderLayout.EAST);

        jPanel9.setPreferredSize(new java.awt.Dimension(380, 700));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel0.setPreferredSize(new java.awt.Dimension(210, 30));
        jPanel0.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblDateMin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin.setOpaque(true);
        lblDateMin.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel0.add(lblDateMin);

        txtDateMin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txtDateMin.setName(""); // NOI18N
        txtDateMin.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateMinMousePressed(evt);
            }
        });
        txtDateMin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDateMinFocusLost(evt);
            }
        });
        txtDateMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateMinKeyTyped(evt);
            }
        });
        jPanel0.add(txtDateMin);

        jPanel9.add(jPanel0);

        jPanel1.setPreferredSize(new java.awt.Dimension(150, 30));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblDateMax.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax.setOpaque(true);
        lblDateMax.setPreferredSize(new java.awt.Dimension(60, 22));
        jPanel1.add(lblDateMax);

        txtDateMax.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txtDateMax.setName(""); // NOI18N
        txtDateMax.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateMax.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateMaxMousePressed(evt);
            }
        });
        txtDateMax.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDateMaxFocusLost(evt);
            }
        });
        txtDateMax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateMaxKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateMaxKeyTyped(evt);
            }
        });
        jPanel1.add(txtDateMax);

        jPanel9.add(jPanel1);

        pnlSelect1.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel3.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField3.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField3.setOpaque(true);
        lblField3.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel3.add(lblField3);

        grpGroup.add(optField3);
        optField3.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel3.add(optField3);
        jPanel3.add(chkField3);

        pnlSelect1.add(jPanel3);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane2.setRequestFocusEnabled(false);
        jScrollPane2.setViewportView(lstField3);

        pnlSelect1.add(jScrollPane2);

        jPanel9.add(pnlSelect1);

        pnlSelect2.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel7.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField4.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField4.setOpaque(true);
        lblField4.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel7.add(lblField4);

        grpGroup.add(optField4);
        optField4.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel7.add(optField4);
        jPanel7.add(chkField4);

        pnlSelect2.add(jPanel7);

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane3.setRequestFocusEnabled(false);
        jScrollPane3.setViewportView(lstField4);

        pnlSelect2.add(jScrollPane3);

        jPanel9.add(pnlSelect2);

        pnlSelect3.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel10.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel10.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField5.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField5.setOpaque(true);
        lblField5.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel10.add(lblField5);

        grpGroup.add(optField5);
        optField5.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel10.add(optField5);
        jPanel10.add(chkField5);

        pnlSelect3.add(jPanel10);

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane4.setRequestFocusEnabled(false);
        jScrollPane4.setViewportView(lstField5);

        pnlSelect3.add(jScrollPane4);

        jPanel9.add(pnlSelect3);

        pnlSelect4.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel11.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel11.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField6.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField6.setOpaque(true);
        lblField6.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel11.add(lblField6);

        grpGroup.add(optField6);
        optField6.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel11.add(optField6);
        jPanel11.add(chkField6);

        pnlSelect4.add(jPanel11);

        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane5.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane5.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane5.setRequestFocusEnabled(false);
        jScrollPane5.setViewportView(lstField6);

        pnlSelect4.add(jScrollPane5);

        jPanel9.add(pnlSelect4);

        pnlSelect5.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel12.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel12.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField7.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField7.setOpaque(true);
        lblField7.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel12.add(lblField7);

        grpGroup.add(optField7);
        optField7.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel12.add(optField7);
        jPanel12.add(chkField7);

        pnlSelect5.add(jPanel12);

        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane6.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane6.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane6.setRequestFocusEnabled(false);
        jScrollPane6.setViewportView(lstField7);

        pnlSelect5.add(jScrollPane6);

        jPanel9.add(pnlSelect5);

        jPanel8.setPreferredSize(new java.awt.Dimension(250, 30));
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpGroup.add(optGroupNone);
        optGroupNone.setSelected(true);
        optGroupNone.setPreferredSize(new java.awt.Dimension(250, 23));
        jPanel8.add(optGroupNone);

        jPanel9.add(jPanel8);

        getContentPane().add(jPanel9, java.awt.BorderLayout.WEST);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @SuppressWarnings("unchecked")
    private String getReport(HashMap param)
    {
        critereField3 = "";
        critereField4 = "";
        critereField5 = "";
        critereField6 = "";
        critereField7 = "";
        critereDate = "";
        claircritereDate = "";
        claircritereField3 = "";
        claircritereField4 = "";
        claircritereField5 = "";
        claircritereField6 = "";
        claircritereField7 = "";
        filtreclair = "";
            filtre = "";
            Object[] selectedField3 = lstField3.getSelectedValues();
            if (selectedField3.length > 0)
            {
                if (selectedField3.length == lstField3.getModel().getSize())
                {
                    claircritereField3 = bundle.getString(TABLE.concat(FIELD3)).concat("=").concat(bundle.getString("all"));
                    critereField3 = "(1=1)";
                }
                else
                {
                    critereField3 = "(";
                    claircritereField3 = "(";
                    for(int i=0; i < selectedField3.length; i++)
                    {
                        String field3 = null2String(selectedField3[i]);
                        if (field3.equals("")||field3.equals(" "))
                            field3 = "null";
                        String clairField3 = bundle.getString(TABLE.concat(FIELD3)).concat("=").concat(field3);
                        field3 = FIELD3.concat("='").concat(field3.replace("'", "''")).concat("'");
                        if (critereField3.endsWith("("))
                        {
                            critereField3 = critereField3.concat(field3);
                            claircritereField3 = claircritereField3.concat(clairField3);
                        }
                        else
                        {
                            critereField3 = critereField3.concat(" or ").concat(field3);
                            claircritereField3 = claircritereField3.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField3);
                        }
                    }
                    critereField3 = critereField3.concat(")");
                    claircritereField3 = claircritereField3.concat(")");
                }
            }
            else
            {
                critereField3 = "";
            }

        Object[] selectedField4 = lstField4.getSelectedValues();
        if (selectedField4.length > 0)
        {
            if (selectedField4.length == lstField4.getModel().getSize())
            {
                claircritereField4 = bundle.getString(TABLE.concat(FIELD4)).concat("=").concat(bundle.getString("all"));
                critereField4 = "(1=1)";
            }
            else
            {
                critereField4 = "(";
                claircritereField4 = "(";
                for(int i=0; i < selectedField4.length; i++)
                {
                    String field4 = null2String(selectedField4[i]);
                    if (field4.equals("")||field4.equals(" "))
                        field4 = "null";
                    String clairField4 = bundle.getString(TABLE.concat(FIELD4)).concat("=").concat(field4);
                    field4 = FIELD4.concat("='").concat(field4.replace("'", "''")).concat("'");
                    if (critereField4.endsWith("("))
                    {
                        critereField4 = critereField4.concat(field4);
                        claircritereField4 = claircritereField4.concat(clairField4);
                    }
                    else
                    {
                        critereField4 = critereField4.concat(" or ").concat(field4);
                        claircritereField4 = claircritereField4.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField4);
                    }
                }
                critereField4 = critereField4.concat(")");
                claircritereField4 = claircritereField4.concat(")");
            }
        }
        else
        {
            critereField4 = "";
        }
        
        Object[] selectedField5 = lstField5.getSelectedValues();
        if (selectedField5.length > 0)
        {
            if (selectedField5.length == lstField5.getModel().getSize())
            {
                claircritereField5 = bundle.getString(TABLE.concat(FIELD5)).concat("=").concat(bundle.getString("all"));
                critereField5 = "(1=1)";
            }
            else
            {
                critereField5 = "(";
                claircritereField5 = "(";
                for(int i=0; i < selectedField5.length; i++)
                {
                    String field5 = null2String(selectedField5[i]);
                    if (field5.equals("")||field5.equals(" "))
                        field5 = "null";
                    String clairField5 = bundle.getString(TABLE.concat(FIELD5)).concat("=").concat(field5);
                    field5 = FIELD5.concat("='").concat(field5.replace("'", "''")).concat("'");
                    if (critereField5.endsWith("("))
                    {
                        critereField5 = critereField5.concat(field5);
                        claircritereField5 = claircritereField5.concat(clairField5);
                    }
                    else
                    {
                        critereField5 = critereField5.concat(" or ").concat(field5);
                        claircritereField5 = claircritereField5.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField5);
                    }
                }
                critereField5 = critereField5.concat(")");
                claircritereField5 = claircritereField5.concat(")");
            }
        }
        else
        {
            critereField5 = "";
        }

        Object[] selectedField6 = lstField6.getSelectedValues();
        if (selectedField6.length > 0)
        {
            if (selectedField6.length == lstField6.getModel().getSize())
            {
                claircritereField6 = bundle.getString(TABLE.concat(FIELD6)).concat("=").concat(bundle.getString("all"));
                critereField6 = "(1=1)";
            }
            else
            {
                critereField6 = "(";
                claircritereField6 = "(";
                for(int i=0; i < selectedField6.length; i++)
                {
                    String field6 = null2String(selectedField6[i]);
                    if (field6.equals("")||field6.equals(" "))
                        field6 = "null";
                    String clairField6 = bundle.getString(TABLE.concat(FIELD6)).concat("=").concat(field6);
                    field6 = FIELD6.concat("='").concat(field6.replace("'", "''")).concat("'");
                    if (critereField6.endsWith("("))
                    {
                        critereField6 = critereField6.concat(field6);
                        claircritereField6 = claircritereField6.concat(clairField6);
                    }
                    else
                    {
                        critereField6 = critereField6.concat(" or ").concat(field6);
                        claircritereField6 = claircritereField6.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField6);
                    }
                }
                critereField6 = critereField6.concat(")");
                claircritereField6 = claircritereField6.concat(")");
            }
        }
        else
        {
            critereField6 = "";
        }

        Object[] selectedField7 = lstField7.getSelectedValues();
        if (selectedField7.length > 0)
        {
            if (selectedField7.length == lstField7.getModel().getSize())
            {
                claircritereField7 = bundle.getString(TABLE.concat(FIELD7)).concat("=").concat(bundle.getString("all"));
                critereField7 = "(1=1)";
            }
            else
            {
                critereField7 = "(";
                claircritereField7 = "(";
                for(int i=0; i < selectedField7.length; i++)
                {
                    String field7 = null2String(selectedField7[i]);
                    if (field7.equals("")||field7.equals(" "))
                        field7 = "null";
                    String clairField7 = bundle.getString(TABLE.concat(FIELD7)).concat("=").concat(field7);
                    field7 = FIELD7.concat("='").concat(field7.replace("'", "''")).concat("'");
                    if (critereField7.endsWith("("))
                    {
                        critereField7 = critereField7.concat(field7);
                        claircritereField7 = claircritereField7.concat(clairField7);
                    }
                    else
                    {
                        critereField7 = critereField7.concat(" or ").concat(field7);
                        claircritereField7 = claircritereField7.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField7);
                    }
                }
                critereField7 = critereField7.concat(")");
                claircritereField7 = claircritereField7.concat(")");
            }
        }
        else
        {
            critereField7 = "";
        }
        
        if (!critereField3.equals(""))
        {
            filtre = critereField3;
            filtreclair = claircritereField3;
        }
        
        if (filtre.equals(""))
        {
            if (!critereField4.equals(""))
            {
                filtre = critereField4;
                filtreclair = claircritereField4;
            }
        }
        else
        {
            if (!critereField4.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField4);
                filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereField4);
            }
        }
        
        if (filtre.equals(""))
        {
            if (!critereField5.equals(""))
            {
                filtre = critereField5;
                filtreclair = claircritereField5;
            }
        }
        else
        {
            if (!critereField5.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField5);
                filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereField5);
            }
        }
        
        if (filtre.equals(""))
        {
            if (!critereField6.equals(""))
            {
                filtre = critereField6;
                filtreclair = claircritereField6;
            }
        }
        else
        {
            if (!critereField6.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField6);
                filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereField6);
            }
        }
        
        if (filtre.equals(""))
        {
            if (!critereField7.equals(""))
            {
                filtre = critereField7;
                filtreclair = claircritereField7;
            }
        }
        else
        {
            if (!critereField7.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField7);
                filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereField7);
            }
        }
        filtre = filtre.replace("='null'", " is null");
        filtre = filtre.replace("= 'null'", " is null");
        filtreclair = filtreclair.replace("=null", "=\"\"");
        datemin = txtDateMin.getText();
        datemax = txtDateMax.getText();
        datemin = FDate.fr2us(datemin);
        datemax = FDate.fr2us(datemax);
        critereDate = "(LOCALDATE>='".concat(datemin).concat("' AND ").concat("LOCALDATE<='").concat(datemax).concat("')");
        claircritereDate = "(".concat(bundle.getString("eventsLOCALDATE")).concat(">=").concat(datemin).concat(" ").concat(bundle.getString("et")).concat(" ").concat(bundle.getString("eventsLOCALDATE")).concat("<=").concat(datemax).concat(")");
        if (filtre.equals(""))
        {
            filtre = critereDate;
            filtreclair = claircritereDate;
        }
        else
        {
            filtre = filtre.concat(" AND ").concat(critereDate);
            filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereDate);
        }
        param.put("wherefilter", filtre);
        param.put("filtreclair", filtreclair);
        String tri1 = "";
        String tri2 = "";
        String tri3 = "";
        String tri4 = "";
        String tri = "";
        
        switch (cboTri1.getSelectedIndex())
        {
            case 1: tri1 = FIELD1;break;
            case 2: tri1 = FIELD2;break;
            case 3: tri1 = FIELD3;break;
            case 4: tri1 = FIELD4;break;
            case 5: tri1 = FIELD5;break;
            case 6: tri1 = FIELD6;break;
            case 7: tri1 = FIELD7;break;
            default: break;
        }
        switch (cboTri2.getSelectedIndex())
        {
            case 1: tri2 = FIELD1;break;
            case 2: tri2 = FIELD2;break;
            case 3: tri2 = FIELD3;break;
            case 4: tri2 = FIELD4;break;
            case 5: tri2 = FIELD5;break;
            case 6: tri2 = FIELD6;break;
            case 7: tri2 = FIELD7;break;
            default: break;
        }
        switch (cboTri3.getSelectedIndex())
        {
            case 1: tri3 = FIELD1;break;
            case 2: tri3 = FIELD2;break;
            case 3: tri3 = FIELD3;break;
            case 4: tri3 = FIELD4;break;
            case 5: tri3 = FIELD5;break;
            case 6: tri3 = FIELD6;break;
            case 7: tri3 = FIELD7;break;
            default: break;
        }
        switch (cboTri4.getSelectedIndex())
        {
            case 1: tri4 = FIELD1;break;
            case 2: tri4 = FIELD2;break;
            case 3: tri4 = FIELD3;break;
            case 4: tri4 = FIELD4;break;
            case 5: tri4 = FIELD5;break;
            case 6: tri4 = FIELD6;break;
            case 7: tri4 = FIELD7;break;
            default: break;
        }
        if (!tri1.equals(""))
            tri = "ORDER BY ".concat(tri1);
        if (!tri2.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri2);
            else
                tri = tri.concat(",").concat(tri2);
        }
        if (!tri3.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri3);
            else
                tri = tri.concat(",").concat(tri3);
        }
        if (!tri4.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri4);
            else
                tri = tri.concat(",").concat(tri4);
        }
        
        param.put("orderby", tri);
        param.put("REPORT_LOCALE", MainClass.locale);
        param.put("REPORT_RESOURCE_BUNDLE", MainClass.bundle);
        String fileName = "rp_events.jasper";
        if (optField3.isSelected())
            fileName = "rp_events_type_grp.jasper";
        else if (optField4.isSelected())
            fileName = "rp_events_entity_grp.jasper";
        else if (optField5.isSelected())
            fileName = "rp_events_place_grp.jasper";
        else if (optField6.isSelected())
            fileName = "rp_events_sign_grp.jasper";
        else if (optField7.isSelected())
            fileName = "rp_events_ascendant_grp.jasper";
        String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
        return file;
    }
    
    private void btnReportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnReportActionPerformed
    {//GEN-HEADEREND:event_btnReportActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param);
        viewer.setVisible(true);
}//GEN-LAST:event_btnReportActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveActionPerformed
    {//GEN-HEADEREND:event_btnSaveActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.saveReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnSaveActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrintActionPerformed
    {//GEN-HEADEREND:event_btnPrintActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.printReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnPrintActionPerformed

    private void txtDateMinMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMinMousePressed
    {//GEN-HEADEREND:event_txtDateMinMousePressed
        /*if (evt.getButton() == 1)
        {
            datemin = DlgCalendar.ShowCalendar(datemin);
            datemin = MainClass.getFormatedDate(datemin);
            txtDateMin.setText(datemin);
        }*/
    }//GEN-LAST:event_txtDateMinMousePressed

    private void txtDateMinKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyTyped
    {//GEN-HEADEREND:event_txtDateMinKeyTyped
        //KTDate d = new KTDate(evt, txtDateMin);
        KTDateAstro d = new KTDateAstro(evt, txtDateMin, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMin.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMinKeyTyped

    private void txtDateMaxMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMaxMousePressed
    {//GEN-HEADEREND:event_txtDateMaxMousePressed
        /*if (evt.getButton() == 1)
        {
            datemax = DlgCalendar.ShowCalendar(datemax);
            datemax = MainClass.getFormatedDate(datemax);
            txtDateMax.setText(datemax);
        }*/
    }//GEN-LAST:event_txtDateMaxMousePressed

    private void txtDateMaxKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMaxKeyTyped
    {//GEN-HEADEREND:event_txtDateMaxKeyTyped
        //KTDate d = new KTDate(evt, txtDateMax);
        KTDateAstro d = new KTDateAstro(evt, txtDateMax, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMax.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMaxKeyTyped

    private void txtDateMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyPressed
    {//GEN-HEADEREND:event_txtDateMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMin.getCaretPosition();
        }
        //KTDate td;
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            //td = new KTDate(evt, txtDateMin);
            td = new KTDateAstro(evt, txtDateMin, kc);
    }//GEN-LAST:event_txtDateMinKeyPressed

    private void txtDateMaxKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMaxKeyPressed
    {//GEN-HEADEREND:event_txtDateMaxKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMax.getCaretPosition();
        }
        //KTDate td;
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            //td = new KTDate(evt, txtDateMax);
            td = new KTDateAstro(evt, txtDateMax, kc);   
    }//GEN-LAST:event_txtDateMaxKeyPressed

    private void txtDateMinFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateMinFocusLost
    {//GEN-HEADEREND:event_txtDateMinFocusLost
        String sText = txtDateMin.getText();
        sText = MainClass.getFormatedDate(sText);
        txtDateMin.setText(sText);
    }//GEN-LAST:event_txtDateMinFocusLost

    private void txtDateMaxFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateMaxFocusLost
    {//GEN-HEADEREND:event_txtDateMaxFocusLost
        String sText = txtDateMax.getText();
        sText = MainClass.getFormatedDate(sText);
        txtDateMax.setText(sText);
    }//GEN-LAST:event_txtDateMaxFocusLost

    private void btnGraphsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnGraphsActionPerformed
    {//GEN-HEADEREND:event_btnGraphsActionPerformed
        String fileName;
        HashMap param = new HashMap();
        getReport(param);
        param.remove("orderby");
        fileName = "rp_events_crosstab.jasper";
        String file0 = new File(ireportPath.concat(fileName)).getAbsolutePath();
        MyReportViewer viewer0 = new MyReportViewer(file0, param);
        viewer0.setVisible(true);
        if (chkField3.isSelected())
        {
            fileName = "rp_events_type_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        if (chkField4.isSelected())
        {
            fileName = "rp_events_entity_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        if (chkField5.isSelected())
        {
            fileName = "rp_events_place_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        if (chkField6.isSelected())
        {
            fileName = "rp_events_sign_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        if (chkField7.isSelected())
        {
            fileName = "rp_events_ascendant_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        
    }//GEN-LAST:event_btnGraphsActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGraphs;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnReport;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox cboTri1;
    private javax.swing.JComboBox cboTri2;
    private javax.swing.JComboBox cboTri3;
    private javax.swing.JComboBox cboTri4;
    private javax.swing.JCheckBox chkField3;
    private javax.swing.JCheckBox chkField4;
    private javax.swing.JCheckBox chkField5;
    private javax.swing.JCheckBox chkField6;
    private javax.swing.JCheckBox chkField7;
    private javax.swing.ButtonGroup grpGroup;
    private javax.swing.JPanel jPanel0;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lblDateMax;
    private javax.swing.JLabel lblDateMin;
    private javax.swing.JLabel lblField3;
    private javax.swing.JLabel lblField4;
    private javax.swing.JLabel lblField5;
    private javax.swing.JLabel lblField6;
    private javax.swing.JLabel lblField7;
    private javax.swing.JLabel lblTri;
    private javax.swing.JList lstField3;
    private javax.swing.JList lstField4;
    private javax.swing.JList lstField5;
    private javax.swing.JList lstField6;
    private javax.swing.JList lstField7;
    private javax.swing.JRadioButton optField3;
    private javax.swing.JRadioButton optField4;
    private javax.swing.JRadioButton optField5;
    private javax.swing.JRadioButton optField6;
    private javax.swing.JRadioButton optField7;
    private javax.swing.JRadioButton optGroupNone;
    private javax.swing.JPanel pnlSelect1;
    private javax.swing.JPanel pnlSelect2;
    private javax.swing.JPanel pnlSelect3;
    private javax.swing.JPanel pnlSelect4;
    private javax.swing.JPanel pnlSelect5;
    private javax.swing.JTextField txtDateMax;
    private javax.swing.JTextField txtDateMin;
    // End of variables declaration//GEN-END:variables
}
