/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * pfContratForm.java
 *
 * Created on 2011-07-12, 10:49:17
 */
package StarLogin.IHM.rapports;

import StarLogin.IHM.MainClass;
import StarLogin.IHM.MyReportViewer;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Enum.OS;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois
 */
public class RpParts extends javax.swing.JFrame
{
    private java.util.ResourceBundle bundle;
    private StarLoginManager StarLoginManager = MainClass.starLoginManager;
    private String critereField1 = "";
    private String claircritereField1 = "";
    private String critereField2 = "";
    private String claircritereField2 = "";
    private String critereField3 = "";
    private String claircritereField3 = "";
    private String filtreclair = "";
    private String filtre = "";
    private int kc; //key code
    private int cp; //caret position
    private String ireportPath = new java.io.File("").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "").concat(OS.getSeparator()).concat("ireport").concat(OS.getSeparator());
    private final String TABLE = "parts";
    private final String FIELD1 = "REF";
    private final String FIELD2 = "PLUS";
    private final String FIELD3 = "MINUS";
    private final String FIELD4 = "PART";
    
    /** Creates new form pfContratForm */
    public RpParts(boolean bHide)
    {
        if (bHide)
        {
            btnPrintActionPerformed(null);
            this.dispose();
            return;
        }
        
        initComponents();
        resetLangue();
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/rapports.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        setCombos();
        
        this.setPreferredSize(new Dimension(1000, 700));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
    }
    
    private void setCombos()
    {
        DefaultListModel listModel1 = new DefaultListModel();
        DefaultListModel listModel2 = new DefaultListModel();
        DefaultListModel listModel3 = new DefaultListModel();
        listModel1.addElement("A");
        listModel1.addElement("B");
        listModel1.addElement("C");
        listModel1.addElement("D");
        listModel1.addElement("E");
        listModel1.addElement("F");
        listModel1.addElement("G");
        listModel1.addElement("H");
        listModel1.addElement("I");
        listModel1.addElement("J");
        listModel1.addElement("K");
        listModel1.addElement("L");
        listModel1.addElement("M");
        listModel1.addElement("N");
        listModel1.addElement("O");
        listModel1.addElement("P");
        listModel1.addElement("Q");
        listModel1.addElement("R");
        listModel1.addElement("S");
        listModel1.addElement("T");
        listModel1.addElement("U");
        listModel1.addElement("V");
        listModel1.addElement("W");
        listModel1.addElement("X");
        listModel1.addElement("Y");
        lstField1.setModel(listModel1);
        lstField1.setSelectedIndex(-1);
        if (!listModel1.isEmpty())
        {
            if (listModel1.lastElement() == "")
                listModel1.set(listModel1.getSize()-1, " ");
        }
        listModel2.addElement("A");
        listModel2.addElement("B");
        listModel2.addElement("C");
        listModel2.addElement("D");
        listModel2.addElement("E");
        listModel2.addElement("F");
        listModel2.addElement("G");
        listModel2.addElement("H");
        listModel2.addElement("I");
        listModel2.addElement("J");
        listModel2.addElement("K");
        listModel2.addElement("L");
        listModel2.addElement("M");
        listModel2.addElement("N");
        listModel2.addElement("O");
        listModel2.addElement("P");
        listModel2.addElement("Q");
        listModel2.addElement("R");
        listModel2.addElement("S");
        listModel2.addElement("T");
        listModel2.addElement("U");
        listModel2.addElement("V");
        listModel2.addElement("W");
        listModel2.addElement("X");
        listModel2.addElement("Y");
        lstField2.setModel(listModel2);
        lstField2.setSelectedIndex(-1);
        if (!listModel2.isEmpty())
        {
        if (listModel2.lastElement() == "")
            listModel2.set(listModel2.getSize()-1, " ");
        }
        listModel3.addElement("A");
        listModel3.addElement("B");
        listModel3.addElement("C");
        listModel3.addElement("D");
        listModel3.addElement("E");
        listModel3.addElement("F");
        listModel3.addElement("G");
        listModel3.addElement("H");
        listModel3.addElement("I");
        listModel3.addElement("J");
        listModel3.addElement("K");
        listModel3.addElement("L");
        listModel3.addElement("M");
        listModel3.addElement("N");
        listModel3.addElement("O");
        listModel3.addElement("P");
        listModel3.addElement("Q");
        listModel3.addElement("R");
        listModel3.addElement("S");
        listModel3.addElement("T");
        listModel3.addElement("U");
        listModel3.addElement("V");
        listModel3.addElement("W");
        listModel3.addElement("X");
        listModel3.addElement("Y");
        lstField3.setModel(listModel3);
        lstField3.setSelectedIndex(-1);
        if (!listModel1.isEmpty())
        {
            if (listModel3.lastElement() == "")
                listModel3.set(listModel3.getSize()-1, " ");
        }
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private void resetLangue()
    {
        bundle = MainClass.bundle;
        setTitle(bundle.getString("ParametresRapport"));
        btnReport.setToolTipText(bundle.getString("AfficherRapport"));
        btnPrint.setToolTipText(bundle.getString("ImprimerRapport"));
        btnSave.setToolTipText(bundle.getString("SauverRapport"));
        lblField1.setText(bundle.getString(TABLE.concat(FIELD1)));
        lblField2.setText(bundle.getString(TABLE.concat(FIELD2)));
        lblField3.setText(bundle.getString(TABLE.concat(FIELD3)));
        lblTri.setText(bundle.getString("Sorting"));
        cboTri1.addItem("");
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri2.addItem("");
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri3.addItem("");
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri4.addItem("");
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri1.setSelectedIndex(0);
        cboTri2.setSelectedIndex(0);
        cboTri3.setSelectedIndex(0);
        cboTri4.setSelectedIndex(0);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpGroup = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        btnReport = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        lblTri = new javax.swing.JLabel();
        cboTri1 = new javax.swing.JComboBox();
        cboTri2 = new javax.swing.JComboBox();
        cboTri3 = new javax.swing.JComboBox();
        cboTri4 = new javax.swing.JComboBox();
        jPanel9 = new javax.swing.JPanel();
        pnlSelect1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblField1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstField1 = new javax.swing.JList();
        pnlSelect2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        lblField2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstField2 = new javax.swing.JList();
        pnlSelect3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        lblField3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        lstField3 = new javax.swing.JList();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel2.setPreferredSize(new java.awt.Dimension(123, 79));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/rapports2.png"))); // NOI18N
        btnReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportActionPerformed(evt);
            }
        });
        jPanel2.add(btnReport);

        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/printer2.png"))); // NOI18N
        btnPrint.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        jPanel2.add(btnPrint);

        btnSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/save2.png"))); // NOI18N
        btnSave.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel2.add(btnSave);

        jPanel13.setPreferredSize(new java.awt.Dimension(120, 650));

        lblTri.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTri.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(lblTri);

        cboTri1.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri1);

        cboTri2.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri2);

        cboTri3.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri3);

        cboTri4.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri4);

        jPanel2.add(jPanel13);

        getContentPane().add(jPanel2, java.awt.BorderLayout.EAST);

        jPanel9.setPreferredSize(new java.awt.Dimension(390, 380));

        pnlSelect1.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel3.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField1.setOpaque(true);
        lblField1.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel3.add(lblField1);

        pnlSelect1.add(jPanel3);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane2.setRequestFocusEnabled(false);

        lstField1.setFont(new java.awt.Font("StarLogin", 0, 18)); // NOI18N
        jScrollPane2.setViewportView(lstField1);

        pnlSelect1.add(jScrollPane2);

        jPanel9.add(pnlSelect1);

        pnlSelect2.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel4.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField2.setOpaque(true);
        lblField2.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel4.add(lblField2);

        pnlSelect2.add(jPanel4);

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane3.setRequestFocusEnabled(false);

        lstField2.setFont(new java.awt.Font("StarLogin", 0, 18)); // NOI18N
        jScrollPane3.setViewportView(lstField2);

        pnlSelect2.add(jScrollPane3);

        jPanel9.add(pnlSelect2);

        pnlSelect3.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel6.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField3.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField3.setOpaque(true);
        lblField3.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel6.add(lblField3);

        pnlSelect3.add(jPanel6);

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane4.setRequestFocusEnabled(false);

        lstField3.setFont(new java.awt.Font("StarLogin", 0, 18)); // NOI18N
        jScrollPane4.setViewportView(lstField3);

        pnlSelect3.add(jScrollPane4);

        jPanel9.add(pnlSelect3);

        getContentPane().add(jPanel9, java.awt.BorderLayout.WEST);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @SuppressWarnings("unchecked")
    private String getReport(HashMap param)
    {
        critereField1 = "";
        claircritereField1 = "";
        filtreclair = "";
        filtre = "";
        int[] selectedField1 = lstField1.getSelectedIndices();
        Object[] selectedValues1 = lstField1.getSelectedValues();
        if (selectedField1.length > 0)
        {
            if (selectedField1.length == lstField1.getModel().getSize())
            {
                claircritereField1 = "";
                critereField1 = "(1=1)";
            }
            else
            {
                critereField1 = "(";
                claircritereField1 = "(/: ";
                for(int i=0; i < selectedField1.length; i++)
                {
                    String field1 = null2String(selectedField1[i]);
                    if (field1.equals("")||field1.equals(" "))
                        field1 = "-1";
                    String clairField1 = null2String(selectedValues1[i]);
                    field1 = FIELD1.concat("=").concat(field1);
                    if (critereField1.endsWith("("))
                    {
                        critereField1 = critereField1.concat(field1);
                        claircritereField1 = claircritereField1.concat(clairField1);
                    }
                    else
                    {
                        critereField1 = critereField1.concat(" or ").concat(field1);
                        claircritereField1 = claircritereField1.concat(clairField1);
                    }
                }
                critereField1 = critereField1.concat(")");
                claircritereField1 = claircritereField1.concat(")");
            }
        }
        else
        {
            critereField1 = "";
        }

        int[] selectedField2 = lstField2.getSelectedIndices();
        Object[] selectedValues2 = lstField2.getSelectedValues();
        if (selectedField2.length > 0)
        {
            if (selectedField2.length == lstField2.getModel().getSize())
            {
                claircritereField2 = "";
                critereField2 = "(1=1)";
            }
            else
            {
                critereField2 = "(";
                claircritereField2 = "(+: ";
                for(int i=0; i < selectedField2.length; i++)
                {
                    String field2 = null2String(selectedField2[i]);
                    if (field2.equals("")||field2.equals(" "))
                        field2 = "-1";
                    String clairField2 = null2String(selectedValues2[i]);
                    field2 = FIELD2.concat("=").concat(field2);
                    if (critereField2.endsWith("("))
                    {
                        critereField2 = critereField2.concat(field2);
                        claircritereField2 = claircritereField2.concat(clairField2);
                    }
                    else
                    {
                        critereField2 = critereField2.concat(" or ").concat(field2);
                        claircritereField2 = claircritereField2.concat(clairField2);
                    }
                }
                critereField2 = critereField2.concat(")");
                claircritereField2 = claircritereField2.concat(")");
            }
        }
        else
        {
            critereField2 = "";
        }
        
        int[] selectedField3 = lstField3.getSelectedIndices();
        Object[] selectedValues3 = lstField3.getSelectedValues();
        if (selectedField3.length > 0)
        {
            if (selectedField3.length == lstField3.getModel().getSize())
            {
                claircritereField3 = "";
                critereField3 = "(1=1)";
            }
            else
            {
                critereField3 = "(";
                claircritereField3 = "(-: ";
                for(int i=0; i < selectedField3.length; i++)
                {
                    String field3 = null2String(selectedField3[i]);
                    if (field3.equals("")||field3.equals(" "))
                        field3 = "-1";
                    String clairField3 = null2String(selectedValues3[i]);
                    field3 = FIELD3.concat("=").concat(field3);
                    if (critereField3.endsWith("("))
                    {
                        critereField3 = critereField3.concat(field3);
                        claircritereField3 = claircritereField3.concat(clairField3);
                    }
                    else
                    {
                        critereField3 = critereField3.concat(" or ").concat(field3);
                        claircritereField3 = claircritereField3.concat(clairField3);
                    }
                }
                critereField3 = critereField3.concat(")");
                claircritereField3 = claircritereField3.concat(")");
            }
        }
        else
        {
            critereField3 = "";
        }

        if (!critereField1.equals(""))
        {
            filtre = critereField1;
            filtreclair = claircritereField1;
        }
        
        if (filtre.equals(""))
        {
            if (!critereField2.equals(""))
            {
                filtre = critereField2;
                filtreclair = claircritereField2;
            }
        }
        else
        {
            if (!critereField2.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField2);
                filtreclair = filtreclair.concat(" ").concat(claircritereField2);
            }
        }
        
        if (filtre.equals(""))
        {
            if (!critereField3.equals(""))
            {
                filtre = critereField3;
                filtreclair = claircritereField3;
            }
        }
        else
        {
            if (!critereField3.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField3);
                filtreclair = filtreclair.concat(" ").concat(claircritereField3);
            }
        }
        
        filtre = filtre.replace("='null'", " is null");
        filtre = filtre.replace("= 'null'", " is null");
        filtreclair = filtreclair.replace("=null", "=\"\"");
        if (filtre.equals(""))
            filtre = "1=1";
        
        param.put("wherefilter", filtre);
        param.put("filtreclair", filtreclair);
        String tri1 = "";
        String tri2 = "";
        String tri3 = "";
        String tri4 = "";
        String tri = "";
        
        switch (cboTri1.getSelectedIndex())
        {
            case 1: tri1 = FIELD1;break;
            case 2: tri1 = FIELD2;break;
            case 3: tri1 = FIELD3;break;
            case 4: tri1 = FIELD4;break;
            default: break;
        }
        switch (cboTri2.getSelectedIndex())
        {
            case 1: tri2 = FIELD1;break;
            case 2: tri2 = FIELD2;break;
            case 3: tri2 = FIELD3;break;
            case 4: tri2 = FIELD4;break;
            default: break;
        }
        switch (cboTri3.getSelectedIndex())
        {
            case 1: tri3 = FIELD1;break;
            case 2: tri3 = FIELD2;break;
            case 3: tri3 = FIELD3;break;
            case 4: tri3 = FIELD4;break;
            default: break;
        }
        switch (cboTri4.getSelectedIndex())
        {
            case 1: tri4 = FIELD1;break;
            case 2: tri4 = FIELD2;break;
            case 3: tri4 = FIELD3;break;
            case 4: tri4 = FIELD4;break;
            default: break;
        }
        if (!tri1.equals(""))
            tri = "ORDER BY ".concat(tri1);
        if (!tri2.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri2);
            else
                tri = tri.concat(",").concat(tri2);
        }
        if (!tri3.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri3);
            else
                tri = tri.concat(",").concat(tri3);
        }
        if (!tri4.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri4);
            else
                tri = tri.concat(",").concat(tri4);
        }
        
        param.put("orderby", tri);
        param.put("REPORT_LOCALE", MainClass.locale);
        param.put("REPORT_RESOURCE_BUNDLE", MainClass.bundle);
        String fileName = "rp_parts.jasper";
        String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
        return file;
    }
    
    private void btnReportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnReportActionPerformed
    {//GEN-HEADEREND:event_btnReportActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param);
        viewer.setVisible(true);
}//GEN-LAST:event_btnReportActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveActionPerformed
    {//GEN-HEADEREND:event_btnSaveActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.saveReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnSaveActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrintActionPerformed
    {//GEN-HEADEREND:event_btnPrintActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.printReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnPrintActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnReport;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox cboTri1;
    private javax.swing.JComboBox cboTri2;
    private javax.swing.JComboBox cboTri3;
    private javax.swing.JComboBox cboTri4;
    private javax.swing.ButtonGroup grpGroup;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblField1;
    private javax.swing.JLabel lblField2;
    private javax.swing.JLabel lblField3;
    private javax.swing.JLabel lblTri;
    private javax.swing.JList lstField1;
    private javax.swing.JList lstField2;
    private javax.swing.JList lstField3;
    private javax.swing.JPanel pnlSelect1;
    private javax.swing.JPanel pnlSelect2;
    private javax.swing.JPanel pnlSelect3;
    // End of variables declaration//GEN-END:variables
}
