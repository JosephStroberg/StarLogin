/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * pfContratForm.java
 *
 * Created on 2011-07-12, 10:49:17
 */
package StarLogin.IHM.rapports;

import StarLogin.IHM.MainClass;
import StarLogin.IHM.MyReportViewer;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Enum.OS;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois
 */
public class RpAsteroids extends javax.swing.JFrame
{
    private java.util.ResourceBundle bundle;
    private StarLoginManager StarLoginManager = MainClass.starLoginManager;
    private String critereField1 = "";
    private String critereField2 = "";
    private String claircritereField1 = "";
    private String claircritereField2 = "";
    private String filtreclair = "";
    private String filtre = "";
    private String ireportPath = new java.io.File("").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "").concat(OS.getSeparator()).concat("ireport").concat(OS.getSeparator());
    private final String TABLE = "asteroids";
    private final String FIELD1 = "HMAGNITUDE";
    private final String FIELD2 = "EPOCH";
    private final String FIELD3 = "ASTEROID";
    private final String FIELD4 = "NUMERO";
    private final String FIELD5 = "MEANANOMALY";
    private final String FIELD6 = "ECCENTRICITY";
    private final String FIELD7 = "PERIHELIONLONGITUDE";
    private final String FIELD8 = "NORTHNODELONGITUDE";
    private final String FIELD9 = "INCLINATION";
    private final String FIELD10 = "SEMIMAJORAXIS";
    private final String FIELD11 = "DAILYMOTION";
    
    /** Creates new form pfContratForm */
    public RpAsteroids(boolean bHide)
    {
        if (bHide)
        {
            btnPrintActionPerformed(null);
            this.dispose();
            return;
        }
        
        initComponents();
        //String date = FDate.curFrFormDate();
        resetLangue();
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/rapports.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        setCombos();
        
        this.setPreferredSize(new Dimension(1000, 700));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
    }
    
    private void setCombos()
    {
        DefaultListModel listModel1 = StarLoginManager.getListe2("SELECT distinct FLOOR(" + FIELD1 + ") AS " + FIELD1 + " FROM asteroids ORDER BY " + FIELD1);
        lstField1.setModel(listModel1);
        lstField1.setSelectedIndex(-1);
        DefaultListModel listModel2 = StarLoginManager.getListe2("SELECT distinct " + FIELD2 + " FROM asteroids ORDER BY " + FIELD2);
        lstField2.setModel(listModel2);
        lstField2.setSelectedIndex(-1);
        if (!listModel1.isEmpty())
        {
            if (listModel1.lastElement() == "")
                listModel1.set(listModel1.getSize()-1, " ");
        }
        if (!listModel2.isEmpty())
        {
            if (listModel2.lastElement() == "")
                listModel2.set(listModel2.getSize()-1, " ");
        }
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private void resetLangue()
    {
        bundle = MainClass.bundle;
        setTitle(bundle.getString("ParametresRapport"));
        btnReport.setToolTipText(bundle.getString("AfficherRapport"));
        btnPrint.setToolTipText(bundle.getString("ImprimerRapport"));
        btnSave.setToolTipText(bundle.getString("SauverRapport"));
        chkField1.setText(bundle.getString("Graph"));
        chkField2.setText(bundle.getString("Graph"));
        btnGraphs.setText(bundle.getString("Graphs"));
        btnGraphs.setToolTipText(bundle.getString("DisplaySelectedGraphs"));
        lblField1.setText(bundle.getString(TABLE.concat(FIELD1)));
        lblField2.setText(bundle.getString(TABLE.concat(FIELD2)));
        optField2.setText(bundle.getString("Grouping"));
        optField1.setText(bundle.getString("Grouping"));
        optGroupNone.setText(bundle.getString("NoGrouping"));
        lblTri.setText(bundle.getString("Sorting"));
        cboTri1.addItem("");
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD8)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD9)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD10)));
        cboTri1.addItem(bundle.getString(TABLE.concat(FIELD11)));
        cboTri2.addItem("");
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD8)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD9)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD10)));
        cboTri2.addItem(bundle.getString(TABLE.concat(FIELD11)));
        cboTri3.addItem("");
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD8)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD9)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD10)));
        cboTri3.addItem(bundle.getString(TABLE.concat(FIELD11)));
        cboTri4.addItem("");
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD1)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD2)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD3)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD4)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD5)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD6)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD7)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD8)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD9)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD10)));
        cboTri4.addItem(bundle.getString(TABLE.concat(FIELD11)));
        cboTri1.setSelectedIndex(0);
        cboTri2.setSelectedIndex(0);
        cboTri3.setSelectedIndex(0);
        cboTri4.setSelectedIndex(0);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpGroup = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        btnReport = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        lblTri = new javax.swing.JLabel();
        cboTri1 = new javax.swing.JComboBox();
        cboTri2 = new javax.swing.JComboBox();
        cboTri3 = new javax.swing.JComboBox();
        cboTri4 = new javax.swing.JComboBox();
        jPanel14 = new javax.swing.JPanel();
        btnGraphs = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        pnlSelect1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblField1 = new javax.swing.JLabel();
        optField1 = new javax.swing.JRadioButton();
        chkField1 = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstField1 = new javax.swing.JList();
        pnlSelect2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        lblField2 = new javax.swing.JLabel();
        optField2 = new javax.swing.JRadioButton();
        chkField2 = new javax.swing.JCheckBox();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstField2 = new javax.swing.JList();
        jPanel8 = new javax.swing.JPanel();
        optGroupNone = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel2.setPreferredSize(new java.awt.Dimension(123, 79));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/rapports2.png"))); // NOI18N
        btnReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportActionPerformed(evt);
            }
        });
        jPanel2.add(btnReport);

        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/printer2.png"))); // NOI18N
        btnPrint.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        jPanel2.add(btnPrint);

        btnSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/save2.png"))); // NOI18N
        btnSave.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel2.add(btnSave);

        jPanel13.setPreferredSize(new java.awt.Dimension(120, 650));

        lblTri.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTri.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(lblTri);

        cboTri1.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri1);

        cboTri2.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri2);

        cboTri3.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri3);

        cboTri4.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel13.add(cboTri4);

        jPanel14.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel13.add(jPanel14);

        btnGraphs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/chart.png"))); // NOI18N
        btnGraphs.setSize(new java.awt.Dimension(120, 36));
        btnGraphs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraphsActionPerformed(evt);
            }
        });
        jPanel13.add(btnGraphs);

        jPanel2.add(jPanel13);

        getContentPane().add(jPanel2, java.awt.BorderLayout.EAST);

        jPanel9.setPreferredSize(new java.awt.Dimension(380, 300));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        pnlSelect1.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel3.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField1.setOpaque(true);
        lblField1.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel3.add(lblField1);

        grpGroup.add(optField1);
        optField1.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel3.add(optField1);
        jPanel3.add(chkField1);

        pnlSelect1.add(jPanel3);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane2.setRequestFocusEnabled(false);
        jScrollPane2.setViewportView(lstField1);

        pnlSelect1.add(jScrollPane2);

        jPanel9.add(pnlSelect1);

        pnlSelect2.setPreferredSize(new java.awt.Dimension(380, 120));
        pnlSelect2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel7.setPreferredSize(new java.awt.Dimension(120, 85));
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblField2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblField2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblField2.setOpaque(true);
        lblField2.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel7.add(lblField2);

        grpGroup.add(optField2);
        optField2.setPreferredSize(new java.awt.Dimension(120, 23));
        jPanel7.add(optField2);
        jPanel7.add(chkField2);

        pnlSelect2.add(jPanel7);

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(255, 120));
        jScrollPane3.setRequestFocusEnabled(false);
        jScrollPane3.setViewportView(lstField2);

        pnlSelect2.add(jScrollPane3);

        jPanel9.add(pnlSelect2);

        jPanel8.setPreferredSize(new java.awt.Dimension(250, 30));
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpGroup.add(optGroupNone);
        optGroupNone.setSelected(true);
        optGroupNone.setPreferredSize(new java.awt.Dimension(250, 23));
        jPanel8.add(optGroupNone);

        jPanel9.add(jPanel8);

        getContentPane().add(jPanel9, java.awt.BorderLayout.WEST);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @SuppressWarnings("unchecked")
    private String getReport(HashMap param)
    {
        critereField1 = "";
        critereField2 = "";
        claircritereField1 = "";
        claircritereField2 = "";
        filtreclair = "";
        filtre = "";
        Object[] selectedField1 = lstField1.getSelectedValues();
        if (selectedField1.length > 0)
        {
            if (selectedField1.length == lstField1.getModel().getSize())
            {
                claircritereField1 = bundle.getString(TABLE.concat(FIELD1)).concat("=").concat(bundle.getString("all"));
                critereField1 = "(1=1)";
            }
            else
            {
                critereField1 = "(";
                claircritereField1 = "(";
                for(int i=0; i < selectedField1.length; i++)
                {
                    String field1 = null2String(selectedField1[i]);
                    if (field1.equals("")||field1.equals(" "))
                        field1 = "-1000";
                    String clairField1 = bundle.getString(TABLE.concat(FIELD1)).concat("=");
                    if (field1.equals("-1000"))
                        FIELD1.concat(" is null ");
                    else
                    {
                        clairField1 = clairField1.concat(field1);
                        double dField1 = Double.valueOf(field1).doubleValue() + 1;
                        String field1b = String.valueOf(dField1);
                        field1 = "(".concat(FIELD1).concat(">=").concat(field1).concat(" and ").concat(FIELD1).concat("<").concat(field1b).concat(")");
                    }
                    if (critereField1.endsWith("("))
                    {
                        critereField1 = critereField1.concat(field1);
                        claircritereField1 = claircritereField1.concat(clairField1);
                    }
                    else
                    {
                        critereField1 = critereField1.concat(" or ").concat(field1);
                        claircritereField1 = claircritereField1.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField1);
                    }
                }
                critereField1 = critereField1.concat(")");
                claircritereField1 = claircritereField1.concat(")");
            }
        }
        else
        {
            critereField1 = "";
        }

        Object[] selectedField2 = lstField2.getSelectedValues();
        if (selectedField2.length > 0)
        {
            if (selectedField2.length == lstField2.getModel().getSize())
            {
                claircritereField2 = bundle.getString(TABLE.concat(FIELD2)).concat("=").concat(bundle.getString("all"));
                critereField2 = "(1=1)";
            }
            else
            {
                critereField2 = "(";
                claircritereField2 = "(";
                for(int i=0; i < selectedField2.length; i++)
                {
                    String field2 = null2String(selectedField2[i]);
                    if (field2.equals("")||field2.equals(" "))
                        field2 = "-1000";
                    String clairField2 = bundle.getString(TABLE.concat(FIELD2)).concat("=").concat(field2);
                    field2 = FIELD2.concat("=").concat(field2);
                    if (critereField2.endsWith("("))
                    {
                        critereField2 = critereField2.concat(field2);
                        claircritereField2 = claircritereField2.concat(clairField2);
                    }
                    else
                    {
                        critereField2 = critereField2.concat(" or ").concat(field2);
                        claircritereField2 = claircritereField2.concat(" ").concat(bundle.getString("ou")).concat(" ").concat(clairField2);
                    }
                }
                critereField2 = critereField2.concat(")");
                claircritereField2 = claircritereField2.concat(")");
            }
        }
        else
        {
            critereField2 = "";
        }
        
        if (!critereField1.equals(""))
        {
            filtre = critereField1;
            filtreclair = claircritereField1;
        }
        
        if (filtre.equals(""))
        {
            if (!critereField2.equals(""))
            {
                filtre = critereField2;
                filtreclair = claircritereField2;
            }
        }
        else
        {
            if (!critereField2.equals(""))
            {
                filtre = filtre.concat(" and ").concat(critereField2);
                filtreclair = filtreclair.concat(" ").concat(bundle.getString("et")).concat(" ").concat(claircritereField2);
            }
        }
        
        filtre = filtre.replace("='null'", " is null");
        filtre = filtre.replace("= 'null'", " is null");
        filtreclair = filtreclair.replace("=null", "=\"\"");
        if (filtre.equals(""))
            filtre = "1=1";
        
        param.put("wherefilter", filtre);
        param.put("filtreclair", filtreclair);
        String tri1 = "";
        String tri2 = "";
        String tri3 = "";
        String tri4 = "";
        String tri = "";
        
        switch (cboTri1.getSelectedIndex())
        {
            case 1: tri1 = FIELD1;break;
            case 2: tri1 = FIELD2;break;
            case 3: tri1 = FIELD3;break;
            case 4: tri1 = FIELD4;break;
            case 5: tri1 = FIELD5;break;
            case 6: tri1 = FIELD6;break;
            case 7: tri1 = FIELD7;break;
            case 8: tri1 = FIELD8;break;
            case 9: tri1 = FIELD9;break;
            case 10: tri1 = FIELD10;break;
            case 11: tri1 = FIELD11;break;
            default: break;
        }
        switch (cboTri2.getSelectedIndex())
        {
            case 1: tri2 = FIELD1;break;
            case 2: tri2 = FIELD2;break;
            case 3: tri2 = FIELD3;break;
            case 4: tri2 = FIELD4;break;
            case 5: tri2 = FIELD5;break;
            case 6: tri2 = FIELD6;break;
            case 7: tri2 = FIELD7;break;
            case 8: tri2 = FIELD8;break;
            case 9: tri2 = FIELD9;break;
            case 10: tri2 = FIELD10;break;
            case 11: tri2 = FIELD11;break;
            default: break;
        }
        switch (cboTri3.getSelectedIndex())
        {
            case 1: tri3 = FIELD1;break;
            case 2: tri3 = FIELD2;break;
            case 3: tri3 = FIELD3;break;
            case 4: tri3 = FIELD4;break;
            case 5: tri3 = FIELD5;break;
            case 6: tri3 = FIELD6;break;
            case 7: tri3 = FIELD7;break;
            case 8: tri3 = FIELD8;break;
            case 9: tri3 = FIELD9;break;
            case 10: tri3 = FIELD10;break;
            case 11: tri3 = FIELD11;break;
            default: break;
        }
        switch (cboTri4.getSelectedIndex())
        {
            case 1: tri4 = FIELD1;break;
            case 2: tri4 = FIELD2;break;
            case 3: tri4 = FIELD3;break;
            case 4: tri4 = FIELD4;break;
            case 5: tri4 = FIELD5;break;
            case 6: tri4 = FIELD6;break;
            case 7: tri4 = FIELD7;break;
            case 8: tri4 = FIELD8;break;
            case 9: tri4 = FIELD9;break;
            case 10: tri4 = FIELD10;break;
            case 11: tri4 = FIELD11;break;
            default: break;
        }
        if (!tri1.equals(""))
            tri = "ORDER BY ".concat(tri1);
        if (!tri2.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri2);
            else
                tri = tri.concat(",").concat(tri2);
        }
        if (!tri3.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri3);
            else
                tri = tri.concat(",").concat(tri3);
        }
        if (!tri4.equals(""))
        {
            if (tri.equals(""))
                tri = "ORDER BY ".concat(tri4);
            else
                tri = tri.concat(",").concat(tri4);
        }
        
        param.put("orderby", tri);
        param.put("REPORT_LOCALE", MainClass.locale);
        param.put("REPORT_RESOURCE_BUNDLE", MainClass.bundle);
        String fileName = "rp_asteroids.jasper";
        if (optField1.isSelected())
            fileName = "rp_asteroids_hmagnitude_grp.jasper";
        else if (optField2.isSelected())
            fileName = "rp_asteroids_epoch_grp.jasper";
        String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
        return file;
    }
    
    private void btnReportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnReportActionPerformed
    {//GEN-HEADEREND:event_btnReportActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param);
        viewer.setVisible(true);
}//GEN-LAST:event_btnReportActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveActionPerformed
    {//GEN-HEADEREND:event_btnSaveActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.saveReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnSaveActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrintActionPerformed
    {//GEN-HEADEREND:event_btnPrintActionPerformed
        HashMap param = new HashMap();
        String file = getReport(param);
        MyReportViewer viewer=new MyReportViewer(file, param, true);
        viewer.printReport();
        //viewer.setVisible(true);
}//GEN-LAST:event_btnPrintActionPerformed

    private void btnGraphsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnGraphsActionPerformed
    {//GEN-HEADEREND:event_btnGraphsActionPerformed
        String fileName;
        HashMap param = new HashMap();
        getReport(param);
        param.remove("orderby");
        //fileName = "rp_events_crosstab.jasper";
        //String file0 = new File(ireportPath.concat(fileName)).getAbsolutePath();
        //MyReportViewer viewer0 = new MyReportViewer(file0, param);
        //viewer0.setVisible(true);
        if (chkField1.isSelected())
        {
            fileName = "rp_asteroids_hmagnitude_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
        if (chkField2.isSelected())
        {
            fileName = "rp_asteroids_epoch_chart.jasper";
            String file = new File(ireportPath.concat(fileName)).getAbsolutePath();
            MyReportViewer viewer=new MyReportViewer(file, param);
            viewer.setVisible(true);
        }
    }//GEN-LAST:event_btnGraphsActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGraphs;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnReport;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox cboTri1;
    private javax.swing.JComboBox cboTri2;
    private javax.swing.JComboBox cboTri3;
    private javax.swing.JComboBox cboTri4;
    private javax.swing.JCheckBox chkField1;
    private javax.swing.JCheckBox chkField2;
    private javax.swing.ButtonGroup grpGroup;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblField1;
    private javax.swing.JLabel lblField2;
    private javax.swing.JLabel lblTri;
    private javax.swing.JList lstField1;
    private javax.swing.JList lstField2;
    private javax.swing.JRadioButton optField1;
    private javax.swing.JRadioButton optField2;
    private javax.swing.JRadioButton optGroupNone;
    private javax.swing.JPanel pnlSelect1;
    private javax.swing.JPanel pnlSelect2;
    // End of variables declaration//GEN-END:variables
}
