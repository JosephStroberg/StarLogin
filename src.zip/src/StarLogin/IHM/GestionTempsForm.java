/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * TimeScale.java
 *
 * Created on 14 sept. 2011, 10:04:14
 */
package StarLogin.IHM;

import StarLogin.IHM.components.Options;
import StarLogin.IHM.components.VisuelCal2;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DayCommisRenderer;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Francois
 */
public class GestionTempsForm extends javax.swing.JFrame
{
    private DrawTimeScale dts;
    private boolean bolDragging = false;
    private int curX = 0;
    private int curY = 0;
    private int TSW = 50;
    private final int SEPW = 10;
    private final int HH = 5;
    private final int lHH = 20;
    private int scrW = 18;
    private final int rowH = 30;
    private String classname = this.getClass().getName();
    private int width;
    private int TSH[];
    private int nbj[];
    private int maxTSH;
    private int rownb;
    private int rdvnb = 1;
    private JLabel lblDay[];
    private JTable tblJC[];
    private boolean bResizeRdv;
    private int commisW = 500;
    private int yinit;
    private int hinit;
    private final StarLoginManager starLoginManager = MainClass.starLoginManager;
    private int days = 1;
    private int ts;
    private final VisuelCal2 vc[] = new VisuelCal2[12];
    private int nbjoursdansmois = 31;
    private final JPanel pnlCalendar[] = new JPanel[12];
    private DefaultTableModel model[];
    private JTextArea txtRdv[];
    private int rdvDay[];
    private int rdvmndebut[];
    private int rdvhdebut[];
    private int rdvduree[];
    private boolean bSetting = true;
    private final java.util.ResourceBundle bundle;
    private Records rdvs;
    private ArrayList ndates;
    private String selectedRdv2Remove = "";
    private int selectedRdvIndex = -1;
    private String selectedRdvDate = "";
    private String selectedRdvHeure = "";
    private final GestionTempsForm current = this;
    private final Window parentForm;
    private boolean bDeleted = false;
    private static boolean bGDP = false;
    private double hdeb;
    private String date;
    private boolean bInit = true;
    private boolean bMois = false;
    private String etatfond = "";
    private int savedelta = 0;
    private boolean bShown = false;
    private boolean bShowing = false;
    private int oldts = 1;

    /**
     * Creates new form GestionTempsForm
     * @param parent
     */
    public GestionTempsForm(JFrame parent)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        parentForm = parent;
        bundle = MainClass.bundle;

        initComponents();
        resetLangue();

        //type d'affichage des heures qui influence l'affichage de l'echelle de temps
        if (MainClass.timeType == MainClass.TIME12)
        {
            TSW += TSW / 2;
        }
        this.setExtendedState(MAXIMIZED_BOTH);

        //jours ouvrables pour set de la scroll bar verticale de droite
        String hopen = starLoginManager.getStringFieldValue("joursouvrables", "MIN(CASE WHEN DEBUT is NULL or DEBUT='00:00:00' THEN '23:59:59' ELSE DEBUT END)", "");
        FTime fto = new FTime(hopen);
        int ho = fto.getHour();
        int mno = fto.getMinute();
        hdeb = ho + mno / 60.0 - 1.0;
        if (hdeb < 0.0)
        {
            hdeb = 0.0;
        }

        //recuperation de paramatres relatifs a la fenetre (split et couleurs)
        String svaleur = Options.getDivider("GestionTempsForm", "splitCalRdv").getValeur();
        if (svaleur == null || svaleur.equals(""))
        {
            svaleur = "0";
        }
        int d = Integer.valueOf(svaleur).intValue();
        splitCalRdv.setDividerLocation(d);
        pnlInScr.setBackground(Options.getColor("TextField.background"));

        //date courante par defaut
        date = FDate.curUsFormDate();

        //recuperation position et dimension sauvegardees de la fenetre
        int pos = classname.lastIndexOf(".");
        if (pos > 0)
        {
            classname = classname.substring(pos + 1);
        }
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        this.setExtendedState(params[4]);

        resetScaleAndCommis();

        //scroll bar de droite
        final JScrollBar vScrollBar = scrPnlTS.getVerticalScrollBar();
        bSetting = true;
        vScrollBar.setUnitIncrement(rowH);
        vScrollBar.setBlockIncrement(rowH);
        vScrollBar.addAdjustmentListener(new java.awt.event.AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt)
            {
                if(bShown && !bSetting)
                    savedelta = scrPnlTS.getVerticalScrollBar().getValue();
            }
        });

        //icone de la fenetre
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/gestiontemps.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        this.setVisible(true);
        bSetting = false;
        bInit = false;
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    private void resetLangue()
    {
        setTitle(bundle.getString("GestionTempsForm"));
        btnRdv.setText(bundle.getString("RendezVouss"));
        mnuEchelle1440.setText(bundle.getString("Echelle1440"));
        mnuEchelle60.setText(bundle.getString("Echelle60"));
        mnuEchelle30.setText(bundle.getString("Echelle30"));
        mnuEchelle15.setText(bundle.getString("Echelle15"));
        mnuEchelle10.setText(bundle.getString("Echelle10"));
        mnuAddRdv.setText(bundle.getString("AddRdv"));
        
        cboPasCalendars.setModel(new javax.swing.DefaultComboBoxModel(new String[]
                {
                    bundle.getString("mois"), bundle.getString("trimestre"), bundle.getString("annee"), bundle.getString("cinqans"), bundle.getString("dixans")
                }));

    }

    public void setRdv2Remove()
    {
        popMenuRdvs.setVisible(false);
        String recurid = starLoginManager.getStringFieldValue("rdv", "RDVRECURID", " WHERE ID=" + selectedRdv2Remove);
        String rdvid = starLoginManager.getStringFieldValue("rdv", "ID", " WHERE ID=" + selectedRdv2Remove);
        if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
        {
            MainClass.removeRdv(recurid, rdvid);
            recurid = "";
            MainClass.removeRdv(recurid, rdvid);
            txtRdv[selectedRdvIndex].setVisible(false);
            selectedRdvIndex = 0;
            recalcRdvs();
        }
    }

    public void setRdvStatus(String status, Color color)
    {
        if (status.equals(bundle.getString("None")) || status.equals(""))
            txtRdv[selectedRdvIndex].setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.MatteBorder(1, 10, 1, 1, color), javax.swing.BorderFactory.createLineBorder(Color.GRAY)));
        else
            txtRdv[selectedRdvIndex].setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, color));
        if (etatfond.equals("1"))
            txtRdv[selectedRdvIndex].setBackground(color);
        String rdvid = starLoginManager.getStringFieldValue("rdv", "ID", " WHERE ID=" + txtRdv[selectedRdvIndex].getName());
        starLoginManager.updateDataBase("UPDATE RDV SET STATUS_='" + status.replace("'", "''") + "' WHERE ID=" + rdvid);
    }

    public void setRdv2Edit()
    {
        DialogRdv dlgRdv = new DialogRdv(this, true, "", "", selectedRdv2Remove, bMois);
    }

    public int getScale()
    {
        return ts;
    }

    private void setCalendars(String sdate)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        pnlCalendars.removeAll();
        String date0 = sdate;
        String frdate = new FDate(sdate).getDate().replace(" ", "");// FDate.curFrFormDate();
        for (int i = 0; i < 12; i++)
        {
            vc[i] = new VisuelCal2(1.0, bMois);
            pnlCalendar[i] = new JPanel();
            pnlCalendar[i].setLayout(new java.awt.BorderLayout());
            pnlCalendars.add(pnlCalendar[i]);
            pnlCalendar[i].add(vc[i], java.awt.BorderLayout.CENTER);

            if (i > 0)
            {
                frdate = addOneMonthToDate(frdate);
                date0 = FDate.fr2us(frdate);
                vc[i].setDate(date0);
                vc[i].deselectAll(true);
            }
            else
            {
                vc[i].setDate(date0);
            }

            final int index = i;

            vc[i].addMouseListener(new java.awt.event.MouseAdapter()
            {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt)
                {
                    bShowing = true;
                    setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
                    if (evt.getButton() == 1)
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            if (i != index)
                            {
                                vc[i].deselectAll(true);
                            }
                            else
                            {
                                if (!bMois)
                                {
                                    vc[i].deselectAll(false);
                                }
                                else
                                {
                                    String sDate = vc[i].getDate();
                                    vc[i].deselectAll(true);
                                    vc[i].setDate(sDate);
                                }
                            }
                        }
                    }
                    recalcRdvs();
                    setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
                }
            });
        }
        getSelectedDays(bMois);
        setDays();
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }

    private void recalcRdvs()
    {
        getSelectedDays(bMois);
        setDays();
        refreshRdvs(false, null);
        setDaysSizes();
    }

    private void getTimeScale()
    {
        String timescale = starLoginManager.getStringFieldValue("option_", "VALEUR", " WHERE WINDOW_='GestionTempsForm' AND PROPERTY='timescale'");
        if (timescale.equals("") || timescale.equals("-1") || timescale.equals("0"))
        {
            timescale = "10";
        }
        if (timescale.equals("10"))
        {
            mnuEchelle10.setSelected(true);
        }
        else if (timescale.equals("15"))
        {
            mnuEchelle15.setSelected(true);
        }
        else if (timescale.equals("30"))
        {
            mnuEchelle30.setSelected(true);
        }
        else if (timescale.equals("60"))
        {
            mnuEchelle60.setSelected(true);
        }
        else if (timescale.equals("1440"))
        {
            mnuEchelle1440.setSelected(true);
        }
        ts = Integer.valueOf(timescale).intValue();
        if (bInit)
            oldts = ts;
        bMois = ts == 1440;
    }

    public void setDeleted(boolean data)
    {
        bDeleted = true;
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    public void refreshRdvs(boolean bResize, String rdvid)
    {
        setRdvs();
        if (bResize)
            resizeRdvs(rdvid);
    }

    public final void refreshCommis(String commisID, boolean bDepRefresh)
    {
        recalcRdvs();
    }

    public void setTblDaysColors(boolean bRefresh)
    {
        TableCellRenderer rend[] = new TableCellRenderer[7];
        for (int i = 0; i < 7; i++)
        {
            rend[i] = new DayCommisRenderer(i);
        }
        for (int j = 0; j < days; j++)
        {
            if (AstronomyMaths.modulo(j, 2) == 0)
                tblJC[j].setBackground(Options.getColor("LigneImpaire.background"));
            else
                tblJC[j].setBackground(Options.getColor("LignePaire.background"));
            for (int k = 0; k < tblJC[j].getColumnCount(); k++)
            {
                String sdate = lblDay[j].getText();
                if (sdate != null && !sdate.equals(""))
                {
                    int js = AstronomyMaths.getWeekDay(sdate);
                    tblJC[j].getColumnModel().getColumn(k).setCellRenderer(rend[js]);
                }
            }
        }
        if (bRefresh)
        {
            for (int j = 0; j < days; j++)
            {
                tblJC[j].paintImmediately(tblJC[j].getBounds());//.paintAll(tblJC[j].getGraphics());
            }
        }
    }
    
    private void setRdv2Remove(String rdvid, int index)
    {
        selectedRdv2Remove = rdvid;
        selectedRdvIndex = index;
    }

    private void setRdv2Add(String sdate, String sheure)
    {
        selectedRdvDate = sdate;
        selectedRdvHeure = sheure;
    }

    private void removeTextAreaComponents(java.awt.Container container)
    {
        Component components[] = container.getComponents();
        final int imax = container.getComponentCount();
        for (int i = 0; i < imax; i++)
        {
            Component component = components[i];
            Container subContainer = (Container) component;
            removeTextAreaComponents(subContainer);
            if (component instanceof JTextArea)
            {
                container.remove(component);
            }
        }
    }

    private void setRdvs()
    {
        removeTextAreaComponents(layPnl);
        String datefilter = " (";
        for (int i = 0; i < ndates.size(); i++)
        {
            String frdatemin = null2String(ndates.get(i));
            String dt = FDate.fr2us(frdatemin);
            if (bMois)
            {
                String frdatemax = addOneMonthToDate(frdatemin);
                String dt2 = FDate.fr2us(frdatemax);
                datefilter = datefilter.concat("(DATE_>='" + dt + "' and DATE_<'" + dt2 + "') or ");
            }
            else
            {
                datefilter = datefilter.concat("DATE_='" + dt + "' or ");
            }
        }
        if (datefilter.equals(" ("))
        {
            datefilter = "1=1";
        }
        else
        {
            datefilter = datefilter.substring(0, datefilter.length() - 4).concat(")");
        }
        rdvs = starLoginManager.getRecords("SELECT ID, CLIENTID, NOM_CLIENT, TEL_CLIENT, DATE_, DUREE, HEURE_DEBUT, HEURE_FIN, DESCRIPTION, STATUS_, RDVRECURID FROM rdv WHERE " + datefilter + " ORDER BY DATE_,HEURE_DEBUT", "rdv");

        ArrayList crows = rdvs.getRecords();
        if (crows != null)
        {
            rdvnb = crows.size();
            txtRdv = new JTextArea[rdvnb];
            etatfond = starLoginManager.getStringFieldValue("option_", "VALEUR", " WHERE WINDOW_='RDV' AND PROPERTY='ETATFOND'");
            rdvDay = new int[rdvnb];
            rdvduree = new int[rdvnb];
            rdvhdebut = new int[rdvnb];
            rdvmndebut = new int[rdvnb];
            for (int i = 0; i < crows.size(); i++)
            {
                Object objr = crows.get(i);
                if (objr != null)
                {
                    rdvDay[i] = -1;
                    ArrayList com = (ArrayList) objr;
                    String sclient = null2String(com.get(2));
                    String clientid = null2String(com.get(1));
                    if (clientid.equals(""))
                        clientid = "-1";
                    String srdvid = null2String(com.get(0));
                    String stel = null2String(com.get(3));
                    if (stel.equals("") || stel.equals("-1"))
                    {
                        stel = starLoginManager.getStringFieldValue("clients", "CASE WHEN PHONE is NULL or PHONE='' THEN (CASE WHEN TELBUREAU is NULL or TELBUREAU='' THEN CELL ELSE TELBUREAU END) ELSE PHONE END", " WHERE ID=" + clientid);
                    }
                    if (stel.equals("-1"))
                    {
                        stel = "";
                    }
                    String sjour = MainClass.getFormatedDate(null2String(com.get(4)));
                    String sdebut = null2String(com.get(6));
                    if (sdebut.length() == 8)
                    {
                        sdebut = sdebut.substring(0, 5);
                    }
                    String sfin = null2String(com.get(7));
                    if (sfin.length() == 8)
                    {
                        sfin = sfin.substring(0, 5);
                    }
                    String status = null2String(com.get(9));
                    String sduree = null2String(com.get(5));
                    //String travail = null2String(com.get(2));
                    String descript = null2String(com.get(8));

                    String heuredebut = sdebut.substring(0, 2);
                    int hdebut = Integer.valueOf(heuredebut);
                    if (bMois && sjour.length() == 10)
                    {
                        String sjm = sjour.substring(0, 2);
                        int jm = (Integer.valueOf(sjm).intValue() - 1) * 24;
                        hdebut += jm;
                    }
                    rdvhdebut[i] = hdebut;
                    String minutesdebut = sdebut.substring(3, 5);
                    int mndebut = Integer.valueOf(minutesdebut);
                    rdvmndebut[i] = mndebut;

                    if (sduree.equals(""))
                    {
                        sduree = "0";
                    }
                    int duree = Integer.valueOf(sduree).intValue();
                    rdvduree[i] = duree;
                    txtRdv[i] = new JTextArea();

                    for (int j = 0; j < days; j++)
                    {
                        if (!bMois && null2String(ndates.get(j)).equals(sjour))
                        {
                            rdvDay[i] = j;
                            break;
                        }
                        else if (bMois && null2String(ndates.get(j)).substring(3).equals(sjour.substring(3)))
                        {
                            rdvDay[i] = j;
                            break;
                        }
                    }

                    //txtRdv[i].setBackground(new java.awt.Color(204, 204, 255));
                    txtRdv[i].setColumns(40);
                    txtRdv[i].setFont(new java.awt.Font("Arial", 0, 12));
                    txtRdv[i].setLineWrap(true);
                    txtRdv[i].setWrapStyleWord(true);
                    txtRdv[i].setRows(5);
                    String texte;
                    if (!bMois)
                    {
                        texte = sclient.concat("\n").concat(stel).concat("\n").concat(FTime.formatAMPMAbrev(sdebut)).concat("-").concat(FTime.formatAMPMAbrev(sfin)).concat("\n").concat(descript);//.concat("\n").concat(travail);
                    }
                    else
                    {
                        FDate fd = new FDate(sjour);
                        long dm = fd.getDay();
                        long month = fd.getMonth();
                        long year = fd.getYear();
                        double jd = AstronomyMaths.gregorianToJulian(dm, month, year); //from january to november
                        FTime tdebut = new FTime(sdebut);
                        int hdeb0 = tdebut.getHour();
                        if (hdeb0 >= 12)
                        {
                            jd += 0.5;
                        }
                        jd += ((double) duree / 720) / 2.0;
                        jd -= 0.5;// pour eliminer la borne sup
                        double ddate = AstronomyMaths.julianToGregorian(jd);
                        fd = new FDate(ddate);
                        String datefin = bundle.getString("arrowright").concat(fd.getFormatedDate().replace(" ", ""));
                        texte = sclient.concat("\n").concat(stel).concat("\n").concat(sjour).concat(datefin).concat("\n").concat(descript);//.concat("\n").concat(travail);
                    }
                    txtRdv[i].setText(texte);
                    txtRdv[i].setToolTipText(texte.replace("\n", " | "));
                    txtRdv[i].setName(srdvid);
                    String couleur = starLoginManager.getStringFieldValue("statutrdv", "COULEUR", " WHERE NOM='" + status.replace("'", "''") + "'");
                    Color rdvColor;
                    if (couleur.equals("-1"))
                        rdvColor = Color.WHITE;
                    else
                        rdvColor = new Color(Integer.valueOf(couleur));
                    if (status.equals(bundle.getString("None")) || status.equals(""))
                        txtRdv[i].setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.MatteBorder(1, 10, 1, 1, rdvColor), javax.swing.BorderFactory.createLineBorder(Color.GRAY)));
                    else
                        txtRdv[i].setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, rdvColor));
                    if (etatfond.equals("1"))
                        txtRdv[i].setBackground(rdvColor);
                    txtRdv[i].setDragEnabled(true);
                    final int index = i;
                    final String sfrdvid = srdvid;
                    txtRdv[i].setEditable(false);
                    final String st = status;
                    txtRdv[i].addMouseListener(new java.awt.event.MouseAdapter()
                    {
                        @Override
                        public void mouseEntered(java.awt.event.MouseEvent evt)
                        {
                            setPopMenuInvisible();
                        }

                        @Override
                        public void mouseReleased(java.awt.event.MouseEvent evt)
                        {
                            if (bolDragging)
                            {
                                txtRdv[index].setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

                                if (bResizeRdv)
                                {
                                    Dimension dim = txtRdv[index].getSize();
                                    rdvduree[index] = (dim.height - 1) * ts / rowH;
                                    //arrondi (10, 15, 30 ou 60 mn, selon le cas)
                                    if (bMois)
                                    {
                                        rdvduree[index] = 2 * rdvduree[index] / ts + 1;
                                        rdvduree[index] = rdvduree[index] * ts / 2;
                                    }
                                    else
                                    {
                                        rdvduree[index] = rdvduree[index] / ts + 1;
                                        rdvduree[index] = rdvduree[index] * ts;
                                    }
                                    int h = 1 + rdvduree[index] * rowH / ts;
                                    int w = dim.width;
                                    dim = new Dimension(w, h);
                                    txtRdv[index].setSize(dim);
                                    txtRdv[index].setPreferredSize(dim);
                                    starLoginManager.updateDataBase("UPDATE rdv SET DUREE='" + rdvduree[index] + "' WHERE ID=" + txtRdv[index].getName());
                                }
                                else
                                {
                                    Point ptPnl = layPnl.getLocationOnScreen();
                                    Point ptRdv = txtRdv[index].getLocationOnScreen();
                                    Point pt = new Point(0, 0);
                                    int left = ptRdv.x - ptPnl.x + 20;
                                    int tblw = tblJC[0].getPreferredSize().width;
                                    pt.setLocation(left, ptRdv.getY() - ptPnl.getY());
                                    int numDay = (int) ((double) (left) / (double) tblw);
                                    if (numDay >= days)
                                    {
                                        numDay = days - 1;
                                    }
                                    if (numDay < 0)
                                    {
                                        numDay = 0;
                                    }

                                    rdvDay[index] = numDay;

                                    int row = tblJC[0].rowAtPoint(pt);
                                    String sdate;
                                    if (bMois)
                                    {
                                        rdvhdebut[index] = row * 24;
                                        rdvmndebut[index] = 0;
                                        sdate = null2String(ndates.get(numDay));
                                        String jmois = String.valueOf(row + 1);
                                        if (jmois.length() == 1)
                                        {
                                            jmois = "0".concat(jmois);
                                        }
                                        sdate = jmois.concat("/").concat(sdate.substring(3));
                                        sdate = FDate.fr2us(sdate);
                                    }
                                    else
                                    {
                                        rdvhdebut[index] = row * ts / 60;
                                        rdvmndebut[index] = row * ts - rdvhdebut[index] * 60;
                                        sdate = FDate.fr2us(null2String(ndates.get(numDay)));
                                    }
                                    FTime heure = new FTime();
                                    String sheure = heure.formatTimeAbrev(rdvhdebut[index], rdvmndebut[index], 0);
                                    if (bMois)
                                    {
                                        sheure = "00:00";
                                    }
                                    starLoginManager.updateDataBase("UPDATE rdv SET HEURE_DEBUT='" + sheure + "',DATE_='" + sdate + "' WHERE ID=" + txtRdv[index].getName());
                                }
                                if (!bMois)
                                {
                                    String secondesfin = starLoginManager.getStringFieldValue("rdv", "SECOND(HEURE_DEBUT)+MINUTE(HEURE_DEBUT)*60+HOUR(HEURE_DEBUT)*3600+" + rdvduree[index] +"*60", " WHERE ID=" + txtRdv[index].getName());
                                    if (secondesfin.equals(""))
                                        secondesfin = "0";
                                    int isf = Integer.valueOf(secondesfin).intValue();
                                    if (isf>=86400)
                                        isf = 86399;
                                    int hour = isf/3600;
                                    int reste = AstronomyMaths.modulo(isf, 3600);
                                    int mn = reste/60;
                                    int sec = AstronomyMaths.modulo(reste, 60);
                                    FTime ft = new FTime(hour, mn, sec);
                                    String heure_fin = ft.formatTimeAbrev(hour, mn, sec);
                                    starLoginManager.updateDataBase("UPDATE rdv SET HEURE_FIN='" + heure_fin + "' WHERE ID=" + txtRdv[index].getName());
                                }
                                resizeRdvs(null);
                                Record rdvrec = starLoginManager.getRecord("SELECT NOM_CLIENT,HEURE_DEBUT,DESCRIPTION,HEURE_FIN,DUREE,DATE_,TEL_CLIENT,CLIENTID,STATUS_ FROM rdv WHERE ID=" + sfrdvid, "rdv", "");
                                String sclient = rdvrec.getData(0);
                                String sdebut = rdvrec.getData(1);
                                if (sdebut.length() == 8)
                                {
                                    sdebut = sdebut.substring(0, 5);
                                }
                                String sfin = rdvrec.getData(3);
                                if (sfin.length() == 8)
                                {
                                    sfin = sfin.substring(0, 5);
                                }
                                String descript = rdvrec.getData(2);
                                //String travail = rdvrec.getData(3);
                                String sduree = rdvrec.getData(4);
                                String sjour = rdvrec.getData(5);
                                String stel = rdvrec.getData(6);
                                String clientid = rdvrec.getData(7);
                                String etat = rdvrec.getData(8);
                                String couleur = starLoginManager.getStringFieldValue("statutrdv", "COULEUR", " WHERE NOM='" + etat.replace("'", "''") + "'");
                                Color rdvColor;
                                if (couleur.equals("-1"))
                                    rdvColor = Color.WHITE;
                                else
                                    rdvColor = new Color(Integer.valueOf(couleur));
                                if (etat.equals(bundle.getString("None")) || etat.equals(""))
                                    txtRdv[index].setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.MatteBorder(1, 10, 1, 1, rdvColor), javax.swing.BorderFactory.createLineBorder(Color.GRAY)));
                                else
                                    txtRdv[index].setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, rdvColor));
                                if (etatfond.equals("1"))
                                    txtRdv[index].setBackground(rdvColor);
                                if (stel.equals("") || stel.equals("-1"))
                                {
                                    stel = starLoginManager.getStringFieldValue("clients", "CASE WHEN PHONE is NULL or PHONE='' THEN (CASE WHEN TELBUREAU is NULL or TELBUREAU='' THEN CELL ELSE TELBUREAU END) ELSE PHONE END", " WHERE ID=" + clientid);
                                }
                                if (stel.equals("-1"))
                                {
                                    stel = "";
                                }
                                if (sduree.equals(""))
                                {
                                    sduree = "0";
                                }
                                String texte;
                                if (!bMois)
                                //texte = bundle.getString("rdvNOM_CLIENT").concat(" : ").concat(sclient).concat("\n").concat(bundle.getString("venteHEURE")).concat(" : ").concat(FTime.formatAMPMAbrev(sdebut)).concat("-").concat(FTime.formatAMPMAbrev(sfin)).concat("\n").concat(descript).concat("\n").concat(travail);
                                {
                                    texte = sclient.concat("\n").concat(stel).concat("\n").concat(FTime.formatAMPMAbrev(sdebut)).concat("-").concat(FTime.formatAMPMAbrev(sfin)).concat("\n").concat(descript).concat("\n");//.concat(travail);
                                }
                                else
                                {
                                    int duree = Integer.valueOf(sduree).intValue();
                                    FDate fd = new FDate(sjour);
                                    long dm = fd.getDay();
                                    long month = fd.getMonth();
                                    long year = fd.getYear();
                                    double jd = AstronomyMaths.gregorianToJulian(dm, month, year); //from january to november
                                    FTime tdebut = new FTime(sdebut);
                                    int hdeb = tdebut.getHour();
                                    if (hdeb >= 12)
                                    {
                                        jd += 0.5;
                                    }
                                    jd += ((double) duree / 720) / 2.0;
                                    jd -= 0.5;// pour eliminer la borne sup
                                    double ddate = AstronomyMaths.julianToGregorian(jd);
                                    fd = new FDate(ddate);
                                    String datefin = bundle.getString("arrowright").concat(fd.getFormatedDate().replace(" ", ""));
                                    texte = sclient.concat("\n").concat(stel).concat("\n").concat(sjour).concat(datefin).concat("\n").concat(descript).concat("\n");//.concat(travail);
                                }
                                txtRdv[index].setText(texte);
                                txtRdv[index].setToolTipText(texte.replace("\n", " | "));
                                bolDragging = false;

                                refreshGrids();
                            }
                        }

                        @Override
                        public void mouseClicked(java.awt.event.MouseEvent evt)
                        {
                            if (evt.getButton() == 3)
                            {
                                setRdv2Remove(sfrdvid, index);
                                DlgMnuRdvPop.ShowInput(current, "", st, evt.getLocationOnScreen());
                            }
                            else if (evt.getClickCount() == 2)
                            {
                                int jour = rdvDay[index];
                                DialogRdv dlgRdv = new DialogRdv(current, true, "", "", sfrdvid, bMois);
                                //repaintRdvs();
                                if (bDeleted)
                                {
                                    tblJC[jour].paintImmediately(tblJC[jour].getBounds());//.paintAll(tblJC[jour].getGraphics());
                                }
                                bDeleted = false;
                            }
                            //else
                            //{
                                //txtRdv[index].paintImmediately(txtRdv[index].getBounds());
                            //}
                        }
                    });
                    txtRdv[i].addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
                    {
                        @Override
                        public void mouseDragged(java.awt.event.MouseEvent evt)
                        {
                            if (bolDragging == false)
                            {
                                txtRdv[index].setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
                                bolDragging = true;
                                curX = evt.getX();
                                curY = evt.getY();
                            }

                            if (bResizeRdv)
                            {
                                Dimension dim = txtRdv[index].getSize();
                                txtRdv[index].setPreferredSize(new Dimension(dim.width, hinit + evt.getLocationOnScreen().y - yinit));
                                txtRdv[index].setSize(new Dimension(dim.width, hinit + evt.getLocationOnScreen().y - yinit));
                            }
                            else
                            {
                                txtRdv[index].setLocation(evt.getX() - curX + txtRdv[index].getX(), evt.getY() - curY + txtRdv[index].getY());
                            }

                        }

                        @Override
                        public void mouseMoved(java.awt.event.MouseEvent evt)
                        {
                            hinit = txtRdv[index].getSize().height;
                            int y = evt.getY();
                            if (y >= hinit - 5 && y <= hinit + 5)
                            {
                                txtRdv[index].setCursor(new java.awt.Cursor(java.awt.Cursor.S_RESIZE_CURSOR));
                                bResizeRdv = true;
                                yinit = evt.getLocationOnScreen().y;
                            }
                            else
                            {
                                txtRdv[index].setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
                                bResizeRdv = false;
                            }
                        }
                    });
                    layPnl.add(txtRdv[i], javax.swing.JLayeredPane.DRAG_LAYER);
                }
            }
        }
    }

    private void refreshGrids()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (Window window : windows)
        {
            if (window instanceof ListeRdvForm)
            {
                ((ListeRdvForm) window).setRow();
                break;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void getSelectedDays(boolean bMois)
    {
        ArrayList ms = new ArrayList();
        for (int i = 0; i < 12; i++)
        {
            String dates[] = vc[i].getSelectedDays(bMois);
            if (dates != null)
            {
                ms.add(dates);
            }
        }
        ndates = new ArrayList();
        for (int i = 0; i < ms.size(); i++)
        {
            String dates[] = (String[]) ms.get(i);
            if (dates != null)
            {
                ndates.addAll(Arrays.asList(dates));
            }
        }
        days = ndates.size();
    }

    private void setTableModel(int j)
    {
        if (ts >= 1440)
        {
            String dte = null2String(ndates.get(j));
            FDate fd = new FDate(dte);
            double jd;
            double ddate;
            long month = fd.getMonth();
            long year = fd.getYear();

            //last day of the month
            if (month < 12)
            {
                jd = AstronomyMaths.gregorianToJulian(1l, month + 1l, year) - 1; //from january to november
            }
            else
            {
                jd = AstronomyMaths.gregorianToJulian(1l, 1l, year + 1l) - 1;   //december
            }
            ddate = AstronomyMaths.julianToGregorian(jd);
            fd = new FDate(ddate);
            nbj[j] = (int) fd.getDay();

            TSH[j] = 2 + 24 * 1800 * nbj[j] / ts;
            rownb = 2 + 24 * 1800 * nbj[j] / ts / rowH;
        }
        else
        {
            TSH[j] = 2 + 24 * 1800 / ts;
            rownb = TSH[j] / rowH;
        }
        model[j] = new DefaultTableModel(rownb, 1);
    }

    private void setTimeScale(int ts)
    {
        bMois = ts >= 1440;

        if (bInit == false)
        {
            int w = pnlRDV.getSize().width;
            pnlInScr.setPreferredSize(new Dimension(w - scrW, maxTSH));
            width = w - scrW - TSW;
            commisW = width;
        }

        pnlTS.removeAll();
        Dimension dim = new Dimension(TSW, maxTSH);
        pnlTS.setPreferredSize(dim);
        pnlTS.setSize(dim);

        dts = new DrawTimeScale(ts, dim, maxTSH, nbjoursdansmois);
        pnlTS.add(dts, java.awt.BorderLayout.CENTER);
        dts.setPreferredSize(dim);
        dts.setSize(dim);
        if (bInit)
            return;
        setDelta();
        bSetting = true;
        scrPnlTS.getVerticalScrollBar().setValue(savedelta);
        bSetting = false;
    }
    
    private void setDelta()
    {
        int delta  = (int)((hdeb*maxTSH)/24.0);
        if (ts == 1440)
        {
            savedelta = 0;
        }
        else
        {
            if (!bShown)
                savedelta = delta;
            else
                savedelta = (savedelta * oldts) / ts;
        }
    }

    private FDate getLastDayOfMonth(long day, long month, long year)
    {
        double jd;
        double ddate;

        //last day of the month
        if (month < 12)
        {
            jd = AstronomyMaths.gregorianToJulian(1l, month + 1l, year) - 1; //from january to november
        }
        else
        {
            jd = AstronomyMaths.gregorianToJulian(1l, 1l, year + 1l) - 1;   //december
        }
        ddate = AstronomyMaths.julianToGregorian(jd);
        FDate max = new FDate(ddate);
        return max;
    }

    private String addOneMonthToDate(String sDate)
    {
        FDate fd = new FDate(sDate);
        sDate = fd.getFormatedDate().replace(" ", "");
        String jour = sDate.substring(0, 2);
        int j = Integer.valueOf(jour).intValue();
        FDate fd2 = getLastDayOfMonth(fd.getDay(), fd.getMonth(), fd.getYear());
        String sDate2;
        if (j < 29)
        {
            sDate2 = MainClass.addDays2DateFR(sDate, 31);
        }
        else
        {
            sDate2 = MainClass.addDays2DateFR(sDate, 3);
        }
        if (fd.getFormatedDate().replace(" ", "").equals(fd2.getFormatedDate().replace(" ", "")))
        {
            long m = fd.getMonth();
            long a = fd.getYear();
            m += 1l;
            if (m == 13)
            {
                m = 1l;
                a += 1l;
            }
            fd2 = getLastDayOfMonth(1l, m, a);
            sDate2 = fd2.getFormatedDate().replace(" ", "");
        }
        else
        {
            sDate2 = jour + sDate2.substring(2);
        }
        return sDate2;
    }

    private String addYearsToDate(String sDate, int nb)
    {
        if (sDate.length() < 10)
        {
            return sDate;
        }
        String year = sDate.substring(6);
        int y = Integer.valueOf(year).intValue();
        y += nb;
        year = String.valueOf(y);
        sDate = sDate.substring(0, 6).concat(year);
        return sDate;
    }

    private String removeOneMonthFromDate(String sDate)
    {
        String sDate2 = MainClass.addDays2DateFR(sDate, -31);
        sDate2 = FDate.us2fr(sDate2);
        String jour = sDate.substring(0, 2);

        sDate2 = jour + sDate2.substring(2);
        return sDate2;
    }

    @SuppressWarnings("unchecked")
    private void setDays()
    {
        lblDay = new JLabel[days];
        model = new DefaultTableModel[days];
        TSH = new int[days];
        nbj = new int[days];

        tblJC = new JTable[days];
        layHeader.removeAll();
        layPnl.removeAll();
        //layHeader.paintImmediately(layHeader.getBounds());
        //layPnl.paintImmediately(layPnl.getBounds());
        
        for (int j = 0; j < days; j++)
        {
            lblDay[j] = new JLabel();
            lblDay[j].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            lblDay[j].setText(null2String(ndates.get(j)));
            lblDay[j].setBorder(javax.swing.BorderFactory.createEtchedBorder());
            lblDay[j].setOpaque(true);
            layHeader.add(lblDay[j], javax.swing.JLayeredPane.DEFAULT_LAYER);

            tblJC[j] = new JTable();
            tblJC[j].setToolTipText(bundle.getString("DoubleClicOrRightClic2AddRdv"));
            tblJC[j].setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(153, 153, 153)));
            tblJC[j].setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
            tblJC[j].setAutoscrolls(false);
            tblJC[j].setDragEnabled(true);
            tblJC[j].setRowHeight(rowH);
            tblJC[j].setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);//.SINGLE_INTERVAL_SELECTION);
            tblJC[j].getTableHeader().setResizingAllowed(false);
            tblJC[j].getTableHeader().setReorderingAllowed(false);
            tblJC[j].setUpdateSelectionOnSort(false);
            setTableModel(j);
            tblJC[j].setModel(model[j]);
            tblJC[j].setShowHorizontalLines(true);
            tblJC[j].setEnabled(false);
            final int iday = j;
            tblJC[j].addMouseListener(new java.awt.event.MouseAdapter()
            {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent evt)
                {
                    setPopMenuInvisible();
                }

                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt)
                {
                    popMenuEchelle.setVisible(false);
                    String sdate = lblDay[iday].getText();

                    Point pt = new Point(0, 0);
                    pt.setLocation(evt.getX(), evt.getY());
                    int row = tblJC[iday].rowAtPoint(pt);

                    String sheure;
                    if (rownb == 24)
                    {
                        sheure = null2String(row);
                        if (row < 10)
                        {
                            sheure = "0".concat(sheure);
                        }
                        sheure = sheure.concat(":00");
                    }
                    else if (rownb == 48)
                    {
                        int parite = AstronomyMaths.modulo(row, 2);
                        int h = row / 2;
                        sheure = null2String(h);
                        if (h < 10)
                        {
                            sheure = "0".concat(sheure);
                        }
                        if (parite == 1)
                        {
                            sheure = sheure.concat(":30");
                        }
                        else
                        {
                            sheure = sheure.concat(":00");
                        }
                    }
                    else if (rownb == 96)
                    {
                        int rang = AstronomyMaths.modulo(row, 4);
                        int h = row / 4;
                        sheure = null2String(h);
                        if (h < 10)
                        {
                            sheure = "0".concat(sheure);
                        }
                        if (rang == 1)
                        {
                            sheure = sheure.concat(":15");
                        }
                        else if (rang == 2)
                        {
                            sheure = sheure.concat(":30");
                        }
                        else if (rang == 3)
                        {
                            sheure = sheure.concat(":45");
                        }
                        else
                        {
                            sheure = sheure.concat(":00");
                        }
                    }
                    else if (rownb == 144)
                    {
                        int rang = AstronomyMaths.modulo(row, 6);
                        int h = row / 6;
                        sheure = null2String(h);
                        if (h < 10)
                        {
                            sheure = "0".concat(sheure);
                        }
                        if (rang == 1)
                        {
                            sheure = sheure.concat(":10");
                        }
                        else if (rang == 2)
                        {
                            sheure = sheure.concat(":20");
                        }
                        else if (rang == 3)
                        {
                            sheure = sheure.concat(":30");
                        }
                        else if (rang == 4)
                        {
                            sheure = sheure.concat(":40");
                        }
                        else if (rang == 5)
                        {
                            sheure = sheure.concat(":50");
                        }
                        else
                        {
                            sheure = sheure.concat(":00");
                        }
                    }
                    else // cas de l'echelle en jours
                    {
                        sheure = "00:00";
                        String sjm = String.valueOf(row + 1);
                        if (sjm.length() == 1)
                        {
                            sjm = "0".concat(sjm);
                        }
                        sdate = sjm.concat("/").concat(sdate.substring(3));
                    }
                    if (evt.getButton() == 3)
                    {
                        setRdv2Add(sdate, sheure);
                        popMenuRdvs.setLocation(evt.getLocationOnScreen());
                        popMenuRdvs.setVisible(true);
                    }
                    else if (evt.getClickCount() == 2)
                    {
                        DialogRdv dlgRdv = new DialogRdv(current, true, sdate, sheure, "-1", bMois);
                    }
                }
            });
            layPnl.add(tblJC[j], javax.swing.JLayeredPane.DEFAULT_LAYER);
        }

        maxTSH = 1;
        for (int j = 0; j < days; j++)
        {
            if (TSH[j] > maxTSH)
            {
                maxTSH = TSH[j];
            }
        }
        bSetting = true;
        JScrollBar vScrollBar = scrPnlTS.getVerticalScrollBar();
        vScrollBar.setMaximum(maxTSH);
        bSetting = false;

        for (int j = 0; j < days; j++)
        {
            tblJC[j].setForeground(Options.getColor("Panel.foreground"));
            tblJC[j].setSelectionBackground(Options.getColor("TextField.selectionBackground"));
        }
        
        setTblDaysColors(false);
    }
    

    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT
     * modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popMenuEchelle = new javax.swing.JPopupMenu();
        mnuEchelle10 = new javax.swing.JRadioButtonMenuItem();
        mnuEchelle15 = new javax.swing.JRadioButtonMenuItem();
        mnuEchelle30 = new javax.swing.JRadioButtonMenuItem();
        mnuEchelle60 = new javax.swing.JRadioButtonMenuItem();
        mnuEchelle1440 = new javax.swing.JRadioButtonMenuItem();
        grpEchelle = new javax.swing.ButtonGroup();
        popMenuRdvs = new javax.swing.JPopupMenu();
        mnuAddRdv = new javax.swing.JMenuItem();
        pnlMain = new javax.swing.JPanel();
        splitCalRdv = new javax.swing.JSplitPane();
        pnlCals = new javax.swing.JPanel();
        pnlBoutons = new javax.swing.JPanel();
        btnRdv = new javax.swing.JButton();
        pnlBtnCalendars = new javax.swing.JPanel();
        btnPreviousCalendars = new javax.swing.JButton();
        cboPasCalendars = new javax.swing.JComboBox();
        btnNextCalendars = new javax.swing.JButton();
        btnCurrentCalendars = new javax.swing.JButton();
        scrlCalendars = new javax.swing.JScrollPane();
        pnlCalendars = new javax.swing.JPanel();
        pnlRDV = new javax.swing.JPanel();
        layHeader = new javax.swing.JLayeredPane();
        scrPnlTS = new javax.swing.JScrollPane();
        pnlInScr = new javax.swing.JPanel();
        pnlTS = new javax.swing.JPanel();
        layPnl = new javax.swing.JLayeredPane();

        grpEchelle.add(mnuEchelle10);
        mnuEchelle10.setSelected(true);
        mnuEchelle10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEchelle10ActionPerformed(evt);
            }
        });
        popMenuEchelle.add(mnuEchelle10);

        grpEchelle.add(mnuEchelle15);
        mnuEchelle15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEchelle15ActionPerformed(evt);
            }
        });
        popMenuEchelle.add(mnuEchelle15);

        grpEchelle.add(mnuEchelle30);
        mnuEchelle30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEchelle30ActionPerformed(evt);
            }
        });
        popMenuEchelle.add(mnuEchelle30);

        grpEchelle.add(mnuEchelle60);
        mnuEchelle60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEchelle60ActionPerformed(evt);
            }
        });
        popMenuEchelle.add(mnuEchelle60);

        grpEchelle.add(mnuEchelle1440);
        mnuEchelle1440.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEchelle1440ActionPerformed(evt);
            }
        });
        popMenuEchelle.add(mnuEchelle1440);

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        mnuAddRdv.setText(bundle.getString("AddRdv")); // NOI18N
        mnuAddRdv.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mnuAddRdv.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        mnuAddRdv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAddRdvActionPerformed(evt);
            }
        });
        popMenuRdvs.add(mnuAddRdv);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        getContentPane().setLayout(new java.awt.BorderLayout(5, 5));

        pnlMain.setLayout(new java.awt.BorderLayout());

        splitCalRdv.setBorder(null);
        splitCalRdv.setDividerLocation(233);

        pnlCals.setLayout(new java.awt.BorderLayout());

        pnlBoutons.setPreferredSize(new java.awt.Dimension(190, 70));
        pnlBoutons.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlBoutonsMouseEntered(evt);
            }
        });
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        btnRdv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/gestiontemps2.png"))); // NOI18N
        btnRdv.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRdv.setPreferredSize(new java.awt.Dimension(190, 40));
        btnRdv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRdvActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRdv);

        pnlBtnCalendars.setPreferredSize(new java.awt.Dimension(192, 30));
        pnlBtnCalendars.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        btnPreviousCalendars.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
        btnPreviousCalendars.setBorder(null);
        btnPreviousCalendars.setPreferredSize(new java.awt.Dimension(28, 30));
        btnPreviousCalendars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousCalendarsActionPerformed(evt);
            }
        });
        pnlBtnCalendars.add(btnPreviousCalendars);

        cboPasCalendars.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "mois", "trimestre", "ann�e", "5 ans", "10 ans" }));
        cboPasCalendars.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlBtnCalendars.add(cboPasCalendars);

        btnNextCalendars.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
        btnNextCalendars.setBorder(null);
        btnNextCalendars.setPreferredSize(new java.awt.Dimension(28, 30));
        btnNextCalendars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextCalendarsActionPerformed(evt);
            }
        });
        pnlBtnCalendars.add(btnNextCalendars);

        btnCurrentCalendars.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCurrentCalendars.setBorder(null);
        btnCurrentCalendars.setPreferredSize(new java.awt.Dimension(28, 30));
        btnCurrentCalendars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCurrentCalendarsActionPerformed(evt);
            }
        });
        pnlBtnCalendars.add(btnCurrentCalendars);

        pnlBoutons.add(pnlBtnCalendars);

        pnlCals.add(pnlBoutons, java.awt.BorderLayout.NORTH);

        scrlCalendars.setBorder(null);

        pnlCalendars.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlCalendarsMouseEntered(evt);
            }
        });
        pnlCalendars.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 1, 1));
        scrlCalendars.setViewportView(pnlCalendars);

        pnlCals.add(scrlCalendars, java.awt.BorderLayout.CENTER);

        splitCalRdv.setLeftComponent(pnlCals);

        pnlRDV.setPreferredSize(new java.awt.Dimension(1024, 768));
        pnlRDV.setLayout(new java.awt.BorderLayout());

        layHeader.setDoubleBuffered(true);
        layHeader.setOpaque(true);
        layHeader.setPreferredSize(new java.awt.Dimension(0, 30));
        layHeader.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                layHeaderMouseEntered(evt);
            }
        });
        pnlRDV.add(layHeader, java.awt.BorderLayout.NORTH);

        scrPnlTS.setBorder(null);
        scrPnlTS.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrPnlTS.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnlInScr.setLayout(new java.awt.BorderLayout());

        pnlTS.setPreferredSize(new java.awt.Dimension(50, 100));
        pnlTS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlTSMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlTSMouseEntered(evt);
            }
        });
        pnlTS.setLayout(new java.awt.BorderLayout());
        pnlInScr.add(pnlTS, java.awt.BorderLayout.WEST);

        layPnl.setDoubleBuffered(true);
        layPnl.setOpaque(true);
        layPnl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                layPnlMouseEntered(evt);
            }
        });
        pnlInScr.add(layPnl, java.awt.BorderLayout.CENTER);

        scrPnlTS.setViewportView(pnlInScr);

        pnlRDV.add(scrPnlTS, java.awt.BorderLayout.CENTER);

        splitCalRdv.setRightComponent(pnlRDV);

        pnlMain.add(splitCalRdv, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlMain, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void setDaysSizes()
    {

        for (int j = 0; j < days; j++)
        {
            if (ts >= 1440)
            {
                TSH[j] = 2 + 24 * 1800 * nbj[j] / ts;
            }
            else
            {
                TSH[j] = 2 + 24 * 1800 / ts;
            }
            lblDay[j].setPreferredSize(new Dimension(commisW / days, lHH));
            lblDay[j].setSize(new Dimension(commisW / days, lHH));
            lblDay[j].setLocation(TSW + commisW / days * j, HH);

            tblJC[j].setPreferredSize(new Dimension(commisW / days, TSH[j]));
            tblJC[j].setSize(new Dimension(commisW / days, TSH[j]));
            tblJC[j].setLocation(commisW / days * j, 2);
        }

        resizeRdvs(null);
    }

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        if (bSetting)
        {
            return;
        }
        int w = pnlRDV.getWidth();
        JScrollBar vScrollBar = scrPnlTS.getVerticalScrollBar();
        scrW = vScrollBar.getWidth();
        pnlInScr.setPreferredSize(new Dimension(w - scrW, maxTSH));
        width = w - scrW - TSW;
        //setTblDaysColors(false);
        commisW = width;
        vScrollBar.setMaximum(maxTSH);
        bSetting = false;
        setDaysSizes();
        Dimension dimCalendars = scrlCalendars.getSize();
        int calendarsw = dimCalendars.width;
        if (calendarsw < 2 * vc[0].getWidth())
        {
            pnlCalendars.setPreferredSize(new Dimension(vc[0].getWidth() + 2, (vc[0].getHeight() + 2) * 12));
        }
        else if (calendarsw < 3 * vc[0].getWidth())
        {
            pnlCalendars.setPreferredSize(new Dimension((vc[0].getWidth() + 2) * 2, (vc[0].getHeight() + 2) * 6));
        }
        else
        {
            pnlCalendars.setPreferredSize(new Dimension((vc[0].getWidth() + 3) * 2, (vc[0].getHeight() + 2) * 4));
        }
        pnlBtnCalendars.setPreferredSize(new Dimension(pnlCalendars.getPreferredSize().width, 25));
    }//GEN-LAST:event_formComponentResized

    @SuppressWarnings("unchecked")
    private ArrayList getAllRdvIds(ArrayList rdvs, String dt)
    {
        boolean bnew = false;
        for (int i = 0; i < rdvs.size(); i++)
        {
            String rdvid = null2String(rdvs.get(i));
            String hdebut = starLoginManager.getStringFieldValue("rdv", "HEURE_DEBUT", " WHERE ID=" + rdvid);
            String hfin = starLoginManager.getStringFieldValue("rdv", "HEURE_FIN", " WHERE ID=" + rdvid);
            Records subrdvs = starLoginManager.getRecords("SELECT ID FROM rdv WHERE (((HEURE_DEBUT<='" + hfin.concat(":00") + "' AND HEURE_FIN>='" + hfin.concat(":00") + "') or (HEURE_FIN>='" + hdebut.concat(":00") + "' AND HEURE_FIN<='" + hfin.concat(":00") + "')) or ID=" + rdvid + ") AND DATE_='" + dt + "'", "rdv");
            if (subrdvs != null)
            {
                ArrayList subs = subrdvs.getRecords();
                for (int j = 0; j < subs.size(); j++)
                {
                    ArrayList row = (ArrayList) subs.get(j);
                    String rdvid2 = null2String(row.get(0));
                    if (!isInList(rdvs, rdvid2))
                    {
                        bnew = true;
                        rdvs.add(rdvid2);
                    }
                }
            }
        }
        if (bnew)
        {
            return getAllRdvIds(rdvs, dt);
        }
        else
        {
            return rdvs;
        }
    }

    private boolean isInList(ArrayList list, String rdvid)
    {
        for (int i = 0; i < list.size(); i++)
        {
            String rdvid2 = null2String(list.get(i));
            if (rdvid2.equals(rdvid))
            {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private void resizeRdvs(String rdvid0)
    {
        if (bSetting || bInit)
            return;
        int top = 0;
        if (tblJC.length > 0)
        {
            for (int i = 0; i < txtRdv.length; i++)
            {
                int ry;

                if (bMois)
                {
                    ry = 1 + (rowH * rdvhdebut[i]) / 24;
                    ry += rowH * rdvmndebut[i] / 60 / 24;
                }
                else
                {
                    ry = 1 + rowH * 60 / ts * rdvhdebut[i];
                    ry += rowH * rdvmndebut[i] / ts;
                }
                int rh = rdvduree[i] * rowH / ts;
                txtRdv[i].setVisible(false);
                int rdvW = tblJC[0].getPreferredSize().width;
                txtRdv[i].setPreferredSize(new Dimension(rdvW, rh + 1));
                txtRdv[i].setSize(new Dimension(rdvW, rh + 1));
                int lp = tblJC[rdvDay[i]].getLocation().x;
                txtRdv[i].setLocation(lp, ry);
                if (txtRdv[i].getName() != null && txtRdv[i].getName().equals(rdvid0))
                {
                    String result = starLoginManager.getStringFieldValue("rdv", "HEURE_DEBUT", " WHERE ID=" + rdvid0);
                    if (result.equals("-1"))
                        result = "00:00";
                    if (result.length() > 5)
                        result = result.substring(0, 5);
                    FTime fto = new FTime(result);
                    int ho = fto.getHour();
                    int mno = fto.getMinute();
                    double vhdeb = ho + mno/60.0 - 1.0;
                    if (vhdeb < 0.0)
                        vhdeb = 0.0;
                    top = (int)((vhdeb * maxTSH) / 24.0);
                }

                String dt = FDate.fr2us(null2String(ndates.get(rdvDay[i])));
                String rdvid = txtRdv[i].getName();
                ArrayList allrdvs = new ArrayList();
                allrdvs.add(rdvid);
                allrdvs = getAllRdvIds(allrdvs, dt);
                int n = allrdvs.size();

                if (n > 1)
                {
                    int trdvs[] = new int[n];

                    for (int j = 0; j < n; j++)
                    {
                        String id = null2String(allrdvs.get(j));
                        if (id.equals(""))
                        {
                            id = "0";
                        }
                        trdvs[j] = Integer.valueOf(id).intValue();
                    }
                    for (int j = 0; j < n; j++)
                    {
                        for (int k = j; k < n; k++)
                        {
                            if (trdvs[k] < trdvs[j])
                            {
                                int x = trdvs[k];
                                trdvs[k] = trdvs[j];
                                trdvs[j] = x;
                            }
                        }
                    }
                    for (int j = 0; j < n; j++)
                    {
                        String id = txtRdv[i].getName();
                        if (id.equals(""))
                        {
                            id = "0";
                        }
                        int k = Integer.valueOf(id).intValue();
                        if (k == trdvs[j])
                        {
                            int w = rdvW / n;
                            txtRdv[i].setPreferredSize(new Dimension(w, rh + 1));
                            txtRdv[i].setSize(new Dimension(w, rh + 1));
                            txtRdv[i].setLocation(lp + j * w, ry);
                            break;
                        }
                    }
                }
                txtRdv[i].setVisible(true);
            }
        }
        else
        {
            for (JTextArea txtRdv1 : txtRdv)
            {
                txtRdv1.setVisible(false);
            }
        }
        
        if (bShowing)
        {
            if (rdvid0 != null)
            {
                if (ts == 1440)
                    top = 0;
                else
                    top = savedelta;
            }
            else
                top = savedelta;
        }
        bSetting = true;
        scrPnlTS.getVerticalScrollBar().setValue(top);
        bSetting = false;
    }
    
    private void formComponentShown(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentShown
    {//GEN-HEADEREND:event_formComponentShown
        dts.paintImmediately(dts.getBounds());
        int delta = (int)((hdeb*maxTSH)/24.0);
        if (ts == 1440)
            delta = 0;
        bShowing = true;
        scrPnlTS.getVerticalScrollBar().setValue(delta);
        bShown = true;
        commisW = width - SEPW;
    }//GEN-LAST:event_formComponentShown

    private void mnuEchelle10ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuEchelle10ActionPerformed
    {//GEN-HEADEREND:event_mnuEchelle10ActionPerformed
        changeEchelle(10);
    }//GEN-LAST:event_mnuEchelle10ActionPerformed

    private void changeEchelle(int echelle)
    {
        oldts = ts;
        boolean bChange = false;
        if ((bMois && echelle < 1440) || (!bMois && echelle >= 1440))
            bChange = true;
        ts = echelle;
        starLoginManager.updateDataBase("update option_ set VALEUR='" + ts + "' WHERE WINDOW_='GestionTempsForm' AND PROPERTY='timescale'");
        if (bChange)
            bMois = !bMois;
        refreshFromScale();
        popMenuEchelle.setVisible(false);
    }
    
    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = this.getExtendedState();
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        
        int div = splitCalRdv.getDividerLocation();
        MainClass.options.setDivider("GestionTempsForm", "splitCalRdv", div);
        
        if (parentForm instanceof OrganizerForm)
            ((OrganizerForm)parentForm).setSchedulerFrame(false);
    }//GEN-LAST:event_formWindowClosing

    private void mnuEchelle15ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuEchelle15ActionPerformed
    {//GEN-HEADEREND:event_mnuEchelle15ActionPerformed
        changeEchelle(15);
    }//GEN-LAST:event_mnuEchelle15ActionPerformed

    private void mnuEchelle30ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuEchelle30ActionPerformed
    {//GEN-HEADEREND:event_mnuEchelle30ActionPerformed
        changeEchelle(30);
    }//GEN-LAST:event_mnuEchelle30ActionPerformed

    private void mnuEchelle60ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuEchelle60ActionPerformed
    {//GEN-HEADEREND:event_mnuEchelle60ActionPerformed
        changeEchelle(60);
    }//GEN-LAST:event_mnuEchelle60ActionPerformed

    private void pnlTSMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_pnlTSMouseClicked
    {//GEN-HEADEREND:event_pnlTSMouseClicked
        if (evt.getButton() == 3)
        {
            popMenuEchelle.setLocation(evt.getLocationOnScreen());
            popMenuEchelle.setVisible(true);
        }
        else
            popMenuEchelle.setVisible(false);
    }//GEN-LAST:event_pnlTSMouseClicked

    private void mnuAddRdvActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuAddRdvActionPerformed
    {//GEN-HEADEREND:event_mnuAddRdvActionPerformed
        popMenuRdvs.setVisible(false);
        DialogRdv dlgRdv = new DialogRdv(current, true, selectedRdvDate, selectedRdvHeure, "-1", bMois);
    }//GEN-LAST:event_mnuAddRdvActionPerformed

    private void btnRdvActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRdvActionPerformed
    {//GEN-HEADEREND:event_btnRdvActionPerformed
        String dmin = null2String(ndates.get(0));
        if (dmin.equals("null"))
            dmin = "";
        if (!dmin.equals(""))
            dmin = FDate.fr2us(dmin);
        String dmax = null2String(ndates.get(ndates.size()-1));
        if (dmax.equals("null"))
            dmax = "";
        if (!dmax.equals(""))
            dmax = FDate.fr2us(dmax);
        ListeRdvForm rf = new ListeRdvForm(dmin, dmax, null, false);
        rf.setVisible(true);
    }//GEN-LAST:event_btnRdvActionPerformed

    public void setPopMenuInvisible()
    {
        popMenuRdvs.setVisible(false);
        popMenuEchelle.setVisible(false);
    }
    
    public final void resetScaleAndCommis()
    {
        //recuperation de l'echelle de temps
        getTimeScale();
        
        //donnees sur les ressources
        refreshFromScale();
    }
    
    private void refreshFromScale()
    {
        //calendriers
        setCalendars(date);
        
        //effets de l'echelle de temps
        setTimeScale(ts);
        
        //refraichissement des ressources
        refreshCommis("-1", false);
        
        //rafraichissement des couleurs 
        //if (!bInit)
        //    setTblDaysColors(false);
    }
    
    private void pnlBoutonsMouseEntered(java.awt.event.MouseEvent evt)//GEN-FIRST:event_pnlBoutonsMouseEntered
    {//GEN-HEADEREND:event_pnlBoutonsMouseEntered
        setPopMenuInvisible();
    }//GEN-LAST:event_pnlBoutonsMouseEntered

    private void pnlCalendarsMouseEntered(java.awt.event.MouseEvent evt)//GEN-FIRST:event_pnlCalendarsMouseEntered
    {//GEN-HEADEREND:event_pnlCalendarsMouseEntered
        setPopMenuInvisible();
    }//GEN-LAST:event_pnlCalendarsMouseEntered

    private void layHeaderMouseEntered(java.awt.event.MouseEvent evt)//GEN-FIRST:event_layHeaderMouseEntered
    {//GEN-HEADEREND:event_layHeaderMouseEntered
        setPopMenuInvisible();
    }//GEN-LAST:event_layHeaderMouseEntered

    private void layPnlMouseEntered(java.awt.event.MouseEvent evt)//GEN-FIRST:event_layPnlMouseEntered
    {//GEN-HEADEREND:event_layPnlMouseEntered
        setPopMenuInvisible();
    }//GEN-LAST:event_layPnlMouseEntered

    private void pnlTSMouseEntered(java.awt.event.MouseEvent evt)//GEN-FIRST:event_pnlTSMouseEntered
    {//GEN-HEADEREND:event_pnlTSMouseEntered
        setPopMenuInvisible();
    }//GEN-LAST:event_pnlTSMouseEntered

    private void btnPreviousCalendarsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousCalendarsActionPerformed
    {//GEN-HEADEREND:event_btnPreviousCalendarsActionPerformed
        String frdate = new FDate(date).getDate().replace(" ", "");
        switch(cboPasCalendars.getSelectedIndex())
        {
            case 0:
                frdate = removeOneMonthFromDate(frdate);
                break;
                
            case 1:
                frdate = removeOneMonthFromDate(frdate);
                frdate = removeOneMonthFromDate(frdate);
                frdate = removeOneMonthFromDate(frdate);
                break;
                
            case 2:
                frdate = addYearsToDate(frdate, -1);
                break;
                
            case 3:
                frdate = addYearsToDate(frdate, -5);
                break;
                
            case 4:
                frdate = addYearsToDate(frdate, -10);
                break;
        }
        date = new FDate(frdate).getDateUS();
        refreshFromScale();
    }//GEN-LAST:event_btnPreviousCalendarsActionPerformed

    private void btnNextCalendarsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextCalendarsActionPerformed
    {//GEN-HEADEREND:event_btnNextCalendarsActionPerformed
        String frdate = new FDate(date).getDate().replace(" ", "");
        switch(cboPasCalendars.getSelectedIndex())
        {
            case 0:
                frdate = addOneMonthToDate(frdate);
                break;
                
            case 1:
                frdate = addOneMonthToDate(frdate);
                frdate = addOneMonthToDate(frdate);
                frdate = addOneMonthToDate(frdate);
                break;
                
            case 2:
                frdate = addYearsToDate(frdate, 1);
                break;
                
            case 3:
                frdate = addYearsToDate(frdate, 5);
                break;
                
            case 4:
                frdate = addYearsToDate(frdate, 10);
                break;
        }
        date = new FDate(frdate).getDateUS();
        refreshFromScale();
    }//GEN-LAST:event_btnNextCalendarsActionPerformed

    private void btnCurrentCalendarsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCurrentCalendarsActionPerformed
    {//GEN-HEADEREND:event_btnCurrentCalendarsActionPerformed
        date = FDate.curUsFormDate();
        refreshFromScale();
    }//GEN-LAST:event_btnCurrentCalendarsActionPerformed

    private void mnuEchelle1440ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuEchelle1440ActionPerformed
    {//GEN-HEADEREND:event_mnuEchelle1440ActionPerformed
        changeEchelle(1440);
    }//GEN-LAST:event_mnuEchelle1440ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCurrentCalendars;
    private javax.swing.JButton btnNextCalendars;
    private javax.swing.JButton btnPreviousCalendars;
    private javax.swing.JButton btnRdv;
    private javax.swing.JComboBox cboPasCalendars;
    private javax.swing.ButtonGroup grpEchelle;
    private javax.swing.JLayeredPane layHeader;
    private javax.swing.JLayeredPane layPnl;
    private javax.swing.JMenuItem mnuAddRdv;
    private javax.swing.JRadioButtonMenuItem mnuEchelle10;
    private javax.swing.JRadioButtonMenuItem mnuEchelle1440;
    private javax.swing.JRadioButtonMenuItem mnuEchelle15;
    private javax.swing.JRadioButtonMenuItem mnuEchelle30;
    private javax.swing.JRadioButtonMenuItem mnuEchelle60;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlBtnCalendars;
    private javax.swing.JPanel pnlCalendars;
    private javax.swing.JPanel pnlCals;
    private javax.swing.JPanel pnlInScr;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlRDV;
    private javax.swing.JPanel pnlTS;
    private javax.swing.JPopupMenu popMenuEchelle;
    private javax.swing.JPopupMenu popMenuRdvs;
    private javax.swing.JScrollPane scrPnlTS;
    private javax.swing.JScrollPane scrlCalendars;
    private javax.swing.JSplitPane splitCalRdv;
    // End of variables declaration//GEN-END:variables
}
