/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.*;
import StarLogin.IHM.components.Options;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.Data.Events;
import StarLogin.Systeme.Enum.Signs;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;
/**
 *
 * @author Francois
 */
public class DialogEvent extends JDialog
{
    private StarLoginManager starLoginManager;
    private StarLogin.Systeme.Data.Event event;
    private Events events;
    private String sQuery = "SELECT SURNAME, OTHERNAMES, ENTITYTYPE, EVENTTYPE, UTDATE, LOCALDATE, UTTIME, LOCAL_TIME, TIMELAG, PLACENAME, PLACELATITUDE, PLACELONGITUDE, SIGN, ASCENDANT, COMMENTS, PICTURE FROM events";
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private java.util.ResourceBundle bundle;
    //private DataBaseRecord dbr;
    private String nom;
    private String otherNames;
    private String eventName;
    private String entityType;
    private String localDate;
    private String localTime;
    private String utDate;
    private String utTime;
    private String tz;
    private String place;
    private String latitude;
    private String longitude;
    private String sign;
    private String ascendant;
    private String comments;
    private String eventID;
    private ImageIcon picture;
    private boolean bSetting = true;
    private Window parentForm;
    private int kc; //key code
    private int cp; //caret position
    private int choixAction = 0;
    private String oldlatitude;
    private String oldlongitude;

    /**
     * Creates new form DialogClient
     */
    public DialogEvent(java.awt.Frame parent, boolean modal, String eventid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        eventID = eventid;
        setDlg();
    }
    
    public DialogEvent(java.awt.Dialog parent, boolean modal, String eventid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        eventID = eventid;
        setDlg();
    }
    
    public DialogEvent(java.awt.Frame parent, boolean modal, String eventid, String nom, String autresnoms, String eventtype)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        eventID = eventid;
        setDlg();
    }
    
    public DialogEvent(java.awt.Dialog parent, boolean modal, String eventid, String nom, String autresnoms, String eventtype)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        eventID = eventid;
        setDlg();
    }
    
    private void changeTime(byte intCall)
    {
        event.setLatitude(txtLatitude.getText());
        event.setLongitude(txtLongitude.getText());
        event.setPlace(txtPlace.getText());
        if ( optLocal.isSelected() == true )
        {
            event.setLocalDate(txtDate.getText());
            event.setLocalTime(txtTime.getText());
            event.utTimeCalculation(intCall);
            utDate = event.getUtDate();
            utTime = event.getUtTime();
        }
        else
        {
            event.setUtDate(txtDate.getText());
            event.setUtTime(txtTime.getText());
            event.localTimeCalculation(intCall);
            localDate = event.getLocalDate();
            localTime = event.getLocalTime();
        }
        tz = event.getTimeLag();
        txtTZ.setText(tz);
        
        if (intCall == TZRules.SecondTime)
        {
            localDate = event.getLocalDate();
            utDate = event.getUtDate();
            localTime = event.getLocalTime();
            utTime = event.getUtTime();
            tz = event.getTimeLag();
            place = event.getPlace();
            latitude = event.getLatitude();
            longitude = event.getLongitude();
            FLatitude l = new FLatitude(latitude);
            latitude = l.getLatitude();
            FLongitude lo = new FLongitude(longitude);
            longitude = lo.getLongitude();
            oldlatitude = latitude;
            oldlongitude = longitude;
        }
        localDate = MainClass.getFormatedDate(localDate);
        localTime = MainClass.getFormatedTime(localTime);
        utDate = MainClass.getFormatedDate(utDate);
        utTime = MainClass.getFormatedTime(utTime);
    }
    
    private void setDlg()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;
        if (eventID.equals("-1"))
            bolAdding = true;

        bundle = MainClass.bundle;
        initComponents();
        for (byte i=0;i<12;i++)
        {
            String sign0 = MainForm.signName[i];
            cboSign.addItem(sign0);
            cboAscendant.addItem(sign0);
        }
        
        setTitle(bundle.getString("Event"));
        
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        
        Color fEO = Options.getColor("EtiquetteObligatoire.background");
        Color pEO = Options.getColor("EtiquetteObligatoire.foreground");
        Color fTO = Options.getColor("SaisieObligatoire.background");
        Color pTO = Options.getColor("SaisieObligatoire.foreground");
        lblNom.setBackground(fEO);
        lblNom.setForeground(pEO);
        txtNom.setBackground(fTO);
        txtNom.setForeground(pTO);
        lblAutresNoms.setBackground(fEO);
        lblAutresNoms.setForeground(pEO);
        txtAutresNoms.setBackground(fTO);
        txtAutresNoms.setForeground(pTO);
        lblDate.setBackground(fEO);
        lblDate.setForeground(pEO);
        txtDate.setBackground(fTO);
        txtDate.setForeground(pTO);
        lblTime.setBackground(fEO);
        lblTime.setForeground(pEO);
        txtTime.setBackground(fTO);
        txtTime.setForeground(pTO);
        txtTZ.setBackground(fTO);
        txtTZ.setForeground(pTO);
        lblEventType.setBackground(fEO);
        lblEventType.setForeground(pEO);
        txtEvent.setBackground(fTO);
        txtEvent.setForeground(pTO);
        lblEntityType.setBackground(fEO);
        lblEntityType.setForeground(pEO);
        txtEntityType.setBackground(fTO);
        txtEntityType.setForeground(pTO);
        lblLatitude.setBackground(fEO);
        lblLatitude.setForeground(pEO);
        txtLatitude.setBackground(fTO);
        txtLatitude.setForeground(pTO);
        lblLongitude.setBackground(fEO);
        lblLongitude.setForeground(pEO);
        txtLongitude.setBackground(fTO);
        txtLongitude.setForeground(pTO);

        //setCombos();
        if (eventID.equals(""))
            eventID = "-1";
        refreshRecord();
        setDataToText();
        if (eventID.equals("-1"))
        {
            /*nom = saveNom;
            otherNames = savePrenom;
            phone = saveTel;
            txtNom.setText(nom);
            txtAutresNoms.setText(otherNames);
            txtTelephone.setText(phone);**/
            bolAdding = true;
            bolEditing = true;
            setEditMode();
        }
        else
            setNormalMode();
        resetLangue();
        
        cboSign.addItem("");
        cboAscendant.addItem("");

        bSetting = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        this.setVisible(true);
    }
    
    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setTextToData();
            
            //verification champs nom ou autresnoms remplis
            boolean bPasNom = true;
            boolean bPasPrenom = true;
            boolean bRempli = true;
            String nomChamp = "";
            
            if (!nom.equals(""))
                bPasNom = false;
            if (!otherNames.equals(""))
                bPasPrenom = false;
            if (bPasNom && bPasPrenom)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("FournirNomOuPrenom"), JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (entityType.equals(""))
            {
                bRempli = false;
                nomChamp = lblEntityType.getText();
            }
            if (eventName.equals(""))
            {
                bRempli = false;
                nomChamp = lblEventType.getText();
            }
            if (place.equals(""))
            {
                bRempli = false;
                nomChamp = lblPlace.getText();
            }
            if (latitude.equals(""))
            {
                bRempli = false;
                nomChamp = lblLatitude.getText();
            }
            if (longitude.equals(""))
            {
                bRempli = false;
                nomChamp = lblLongitude.getText();
            }
            if (localDate.equals("")&&utDate.equals(""))
            {
                bRempli = false;
                nomChamp = lblDate.getText();
            }
            if (localTime.equals("")&&utTime.equals(""))
            {
                bRempli = false;
                nomChamp = lblTime.getText();
            }
            
            if (bRempli == false)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("DataObligatoirePasRemplies").concat("\n").concat(nomChamp), JOptionPane.WARNING_MESSAGE);
                return false;
            }
            
            else
            {
                //update data
                setTextToData();
                event.setAdding(bolAdding);
                event.setSurname(nom);
                event.setOtherNames(otherNames);
                event.setEntityType(entityType);
                event.setEventName(eventName);
                event.setLocalDate(FDate.fr2us(localDate));
                event.setUtDate(FDate.fr2us(utDate));
                event.setLocalTime(FTime.set24(localTime));
                event.setUtTime(FTime.set24(utTime));
                event.setTimeLag(tz);
                event.setPlace(place);
                event.setLatitude(latitude);
                event.setLongitude(longitude);
                event.setComments(comments);
                event.setSign(sign);
                event.setAscendant(ascendant);
                event.setPicture(picture);
                starLoginManager.setEvent(event);
                MainClass.testPlace(txtPlace.getText(), latitude, longitude, this, bolAdding);
                if (bolAdding)
                    eventID = starLoginManager.getStringFieldValue("events", "MAX(ID)", "");
                updateInstances();
                bolEditing = false;
                bolAdding = false;
                setNormalMode();
            }
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    public void showEvent(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        eventID = events.getIDFromRow(row);
        event = starLoginManager.getEvent(eventID, "");
        showEvent(eventID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void showEvent(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        eventID = strID;
        event = starLoginManager.getEvent(eventID, "");
        MainClass.event = event;
        nom = event.getSurname();
        otherNames = event.getOtherNames();
        entityType = event.getEntityType();
        eventName = event.getEventName();
        localDate = event.getLocalDate();
        utDate = event.getUtDate();
        localTime = event.getLocalTime();
        utTime = event.getUtTime();
        tz = event.getTimeLag();
        place = event.getPlace();
        latitude = event.getLatitude();
        longitude = event.getLongitude();
        FLatitude l = new FLatitude(latitude);
        latitude = l.getLatitude();
        FLongitude lo = new FLongitude(longitude);
        longitude = lo.getLongitude();
        oldlatitude = latitude;
        oldlongitude = longitude;
        if (bolAdding)
        {
            localDate = " ".concat(MainClass.no2defaultDate(localDate, MainClass.DATE_2000));
            localTime = MainClass.no2defaultTime(localTime, MainClass.TIME_000000);
            utDate = " ".concat(MainClass.no2defaultDate(utDate, MainClass.DATE_2000));
            utTime = MainClass.no2defaultTime(utTime, MainClass.TIME_000000);
        }
        comments = event.getComments();
        sign = event.getSign();
        if (sign == null)
            sign = "";
        ascendant = event.getAscendant();
        if (ascendant == null)
            ascendant = "";
        picture = event.getPicture();
        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    
    public void setPicture(ImageIcon data)
    {
        picture = data;
        bolEditing = true;
        setEditMode();
    }
    
    private void updateInstances()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof ListeEventForm)
            {
                ((ListeEventForm)windows[i]).setEvent(eventID);
                break;
            }
        }
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }

    private void reloadPicture()
    {
        pnlPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, pnlPhoto.getPreferredSize());
        pnlPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(picture);
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        String nomEvent = nom;
        if (nom.equals(""))
            nomEvent = otherNames;
        else
            nomEvent = nomEvent.concat(" ").concat(otherNames);
        nomEvent = nomEvent.concat(" || ".concat(eventName));
        
        
        if (bolEditing||bolAdding)
        {
            if (!nom.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Event").concat(" : ").concat(nomEvent),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingEvent"),bundle.getString("Event").concat(" : ").concat(nomEvent),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void refreshRecord()
    {
        if (eventID.equals("-1"))
        {
            bolAdding = true;
            setEditMode();
        }
        event = starLoginManager.getEvent(eventID, "");
        events = starLoginManager.getEvents(sQuery + " WHERE ID=" + eventID);
        showEvent(eventID);
    }

    private void addRecord()
    {
        nom = txtNom.getText();
        otherNames = txtAutresNoms.getText();
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        picture = null;
        bolAdding = true;
        bolEditing = true;
        eventID = "-1";
        refreshRecord();
        setEditMode();
        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void removeRec()
    {
        if (!eventID.equals("-1"))
        {
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                starLoginManager.updateDataBase("DELETE FROM event WHERE ID=" + eventID);
                if (parentForm instanceof ListeClientForm)
                {
                    ((ListeClientForm)parentForm).setRow();
                }
                addRecord();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        }
        else
            addRecord();
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private void setTextToData()
    {
        nom = null2String(txtNom.getText());
        otherNames = null2String(txtAutresNoms.getText());
        entityType = null2String(txtEntityType.getText());
        eventName = null2String(txtEvent.getText());
        tz = null2String(txtTZ.getText());
        if (tz.equals(""))
        {
            tz = "0";
        }
        double dblTZ = new Double(tz).doubleValue();
        
        //get the time and date corresponding to the selected option and then calculate the other time and date
        if (optLocal.isSelected())
        {
            localDate = txtDate.getText();
            localTime = txtTime.getText();
            
            FTime ft = new FTime(localTime);
            double heure = ft.getDecimalHour();
            
            if ( (heure + dblTZ) < 0 )
            {
                //minus one day
                utDate = event.addDate(localDate, -1);
            }
            else if ( (dblTZ + heure) > 24 )
            {
                utDate = event.addDate(localDate, 1);
            }
            else
            {
                utDate = localDate;
            }
            heure = AstronomyMaths.modulo(dblTZ + heure, 24.0);
            FTime utT = new FTime(heure);
            utTime = utT.getTime();
        }
        else
        {
            utDate = txtDate.getText();
            utTime = txtTime.getText();
            
            FTime ft = new FTime(utTime);
            double heure = ft.getDecimalHour();
            
            if ( (heure - dblTZ) < 0 )
            {
                //minus one day
                localDate = event.addDate(utDate, -1);
            }
            else if ( (heure - dblTZ) > 24 )
            {
                localDate = event.addDate(utDate, 1);
            }
            else
            {
                localDate = utDate;
            }
            heure = AstronomyMaths.modulo(heure - dblTZ, 24.0);
            FTime localT = new FTime(heure);
            localTime = localT.getTime();
        }
        
        place = null2String(txtPlace.getText());
        latitude = txtLatitude.getText();
        longitude = txtLongitude.getText();
        oldlatitude = latitude;
        oldlongitude = longitude;
        comments = txtComments.getText();
        sign = null2String(cboSign.getSelectedItem());
        ascendant = null2String(cboAscendant.getSelectedItem());
    }
    
    public void setChoix(int choix)
    {
        choixAction = choix;
    }
    
    public int getChoix()
    {
        return choixAction;
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("Events"));
        btnAdd.setText(bundle.getString("Add"));
        btnRemove.setText(bundle.getString("Remove"));
        btnOK.setText(bundle.getString("OK"));
        btnCancel.setText(bundle.getString("Cancel"));
        lblPhoto.setText(bundle.getString("eventsPICTURE"));
        lblNom.setText(bundle.getString("Surname"));
        txtNom.setToolTipText(bundle.getString("PressFirstKeys2SearchDoubleClick4List"));
        lblAutresNoms.setText(bundle.getString("OtherNames"));
        txtAutresNoms.setToolTipText(bundle.getString("PressFirstKeys2SearchDoubleClick4List"));
        lblEntityType.setText(bundle.getString("EntityType"));
        txtEntityType.setToolTipText(bundle.getString("PressFirstKeys2SearchDoubleClick4List"));
        lblPlace.setText(bundle.getString("Place"));
        lblNote.setText(bundle.getString("Comments"));
        txtPlace.setToolTipText(bundle.getString("PressFirstKeys2SearchDoubleClick4List"));
        lblLatitude.setText(bundle.getString("Latitude"));
        lblLongitude.setText(bundle.getString("Longitude"));
        lblLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        lblLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        txtLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        txtLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        lblEventType.setText(bundle.getString("Event"));
        txtEvent.setToolTipText(bundle.getString("PressFirstKeys2SearchDoubleClick4List"));
        lblSign.setText(bundle.getString("Sign"));
        lblAscendant.setText(bundle.getString("Ascendant"));
        lblDate.setText(bundle.getString("Date"));
        lblTime.setText(bundle.getString("Hour"));
        optLocal.setText(bundle.getString("Legal"));
        optUT.setText(bundle.getString("UT"));
        btnCalcTZ.setText(bundle.getString("TimeZoneAndDaylightSavingTime"));
    }

    private void setDataToText()
    {
        bSetting = true;
        cboSign.setSelectedIndex(-1);
        cboAscendant.setSelectedIndex(-1);
        txtEvent.setText(eventName);
        txtNom.setText(nom);
        txtAutresNoms.setText(otherNames);
        txtEntityType.setText(entityType);
        if (optLocal.isSelected())
        {
            txtDate.setText(localDate);
            txtTime.setText(localTime);
        }
        else
        {
            txtDate.setText(utDate);
            txtTime.setText(utTime);
        }
        txtTZ.setText(tz);
        txtPlace.setText(place);
        txtLatitude.setText(latitude);
        txtLongitude.setText(longitude);
        txtComments.setText(comments);
        sign = sign.trim();
        cboSign.setSelectedItem(sign);
        if (cboSign.getSelectedIndex() == -1)
            cboSign.setSelectedIndex(getSignIndex(sign));
        ascendant = ascendant.trim();
        cboAscendant.setSelectedItem(ascendant);
        if (cboAscendant.getSelectedIndex() == -1)
            cboAscendant.setSelectedIndex(getSignIndex(ascendant));
        reloadPicture();
        bSetting = false;
    }
    
    private int getSignIndex(String signe)
    {
        int num = -1;
        for (int i=0; i<12; i++)
        {
            if (signe.equals(Signs.getSignName2(i)))
            {
                num = i;
                break;
            }
        }
        return num;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpUtLocal = new javax.swing.ButtonGroup();
        pnlBoutons = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlData = new javax.swing.JPanel();
        pnlData1 = new javax.swing.JPanel();
        pnlSurname = new javax.swing.JPanel();
        lblNom = new javax.swing.JLabel();
        txtNom = new javax.swing.JTextField();
        pnlOtherNames = new javax.swing.JPanel();
        lblAutresNoms = new javax.swing.JLabel();
        txtAutresNoms = new javax.swing.JTextField();
        pnlEntity = new javax.swing.JPanel();
        lblEntityType = new javax.swing.JLabel();
        txtEntityType = new javax.swing.JTextField();
        pnlPlaceName = new javax.swing.JPanel();
        lblPlace = new javax.swing.JLabel();
        txtPlace = new javax.swing.JTextField();
        pnlPlaceLat = new javax.swing.JPanel();
        lblLatitude = new javax.swing.JLabel();
        txtLatitude = new javax.swing.JTextField();
        pnlPlaceLong = new javax.swing.JPanel();
        lblLongitude = new javax.swing.JLabel();
        txtLongitude = new javax.swing.JTextField();
        pnlEvent = new javax.swing.JPanel();
        lblEventType = new javax.swing.JLabel();
        txtEvent = new javax.swing.JTextField();
        pnlSign = new javax.swing.JPanel();
        lblSign = new javax.swing.JLabel();
        cboSign = new javax.swing.JComboBox();
        pnlAs = new javax.swing.JPanel();
        lblAscendant = new javax.swing.JLabel();
        cboAscendant = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        lblNote = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtComments = new javax.swing.JTextPane();
        plnDateTime = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        lblDate = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        lblTime = new javax.swing.JLabel();
        txtTime = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        optLocal = new javax.swing.JRadioButton();
        optUT = new javax.swing.JRadioButton();
        jPanel21 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        btnCalcTZ = new javax.swing.JButton();
        txtTZ = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        lblPhoto = new javax.swing.JLabel();
        pnlPhoto = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlBoutons.setPreferredSize(new java.awt.Dimension(490, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnAdd.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAdd.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAdd.setMaximumSize(new java.awt.Dimension(31, 31));
        btnAdd.setMinimumSize(new java.awt.Dimension(29, 29));
        btnAdd.setPreferredSize(new java.awt.Dimension(115, 32));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAdd);

        btnRemove.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnRemove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemove.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemove.setMaximumSize(new java.awt.Dimension(31, 31));
        btnRemove.setMinimumSize(new java.awt.Dimension(29, 29));
        btnRemove.setPreferredSize(new java.awt.Dimension(115, 32));
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemove);

        btnOK.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOK.setPreferredSize(new java.awt.Dimension(115, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(115, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        pnlData.setPreferredSize(new java.awt.Dimension(490, 660));
        pnlData.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        pnlData1.setPreferredSize(new java.awt.Dimension(480, 655));
        pnlData1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 1));

        pnlSurname.setMinimumSize(new java.awt.Dimension(375, 30));
        pnlSurname.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlSurname.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblNom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        lblNom.setText(bundle.getString("Surname")); // NOI18N
        lblNom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblNom.setOpaque(true);
        lblNom.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlSurname.add(lblNom);

        txtNom.setPreferredSize(new java.awt.Dimension(255, 22));
        txtNom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtNomMouseClicked(evt);
            }
        });
        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNomKeyPressed(evt);
            }
        });
        pnlSurname.add(txtNom);

        pnlData1.add(pnlSurname);

        pnlOtherNames.setMinimumSize(new java.awt.Dimension(375, 30));
        pnlOtherNames.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlOtherNames.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblAutresNoms.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAutresNoms.setText(bundle.getString("OtherNames")); // NOI18N
        lblAutresNoms.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblAutresNoms.setOpaque(true);
        lblAutresNoms.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlOtherNames.add(lblAutresNoms);

        txtAutresNoms.setPreferredSize(new java.awt.Dimension(255, 22));
        txtAutresNoms.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAutresNomsMouseClicked(evt);
            }
        });
        txtAutresNoms.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAutresNomsKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtAutresNomsKeyPressed(evt);
            }
        });
        pnlOtherNames.add(txtAutresNoms);

        pnlData1.add(pnlOtherNames);

        pnlEntity.setMinimumSize(new java.awt.Dimension(375, 30));
        pnlEntity.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlEntity.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblEntityType.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEntityType.setText(bundle.getString("EntityType")); // NOI18N
        lblEntityType.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblEntityType.setOpaque(true);
        lblEntityType.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlEntity.add(lblEntityType);

        txtEntityType.setPreferredSize(new java.awt.Dimension(255, 22));
        txtEntityType.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEntityTypeMouseClicked(evt);
            }
        });
        txtEntityType.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEntityTypeKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEntityTypeKeyPressed(evt);
            }
        });
        pnlEntity.add(txtEntityType);

        pnlData1.add(pnlEntity);

        pnlPlaceName.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlPlaceName.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblPlace.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPlace.setText(bundle.getString("Place")); // NOI18N
        lblPlace.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPlace.setOpaque(true);
        lblPlace.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlPlaceName.add(lblPlace);

        txtPlace.setPreferredSize(new java.awt.Dimension(255, 22));
        txtPlace.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPlaceMouseClicked(evt);
            }
        });
        txtPlace.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPlaceKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlaceKeyPressed(evt);
            }
        });
        pnlPlaceName.add(txtPlace);

        pnlData1.add(pnlPlaceName);

        pnlPlaceLat.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlPlaceLat.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblLatitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLatitude.setText(bundle.getString("Latitude")); // NOI18N
        lblLatitude.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblLatitude.setOpaque(true);
        lblLatitude.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlPlaceLat.add(lblLatitude);

        txtLatitude.setText(" 00�00'00\"");
        txtLatitude.setPreferredSize(new java.awt.Dimension(110, 22));
        txtLatitude.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLatitudeFocusLost(evt);
            }
        });
        txtLatitude.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLatitudekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLatitudeKeyPressed(evt);
            }
        });
        pnlPlaceLat.add(txtLatitude);

        pnlData1.add(pnlPlaceLat);

        pnlPlaceLong.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlPlaceLong.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblLongitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLongitude.setText(bundle.getString("Longitude")); // NOI18N
        lblLongitude.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblLongitude.setOpaque(true);
        lblLongitude.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlPlaceLong.add(lblLongitude);

        txtLongitude.setText(" 000�00'00\"");
        txtLongitude.setPreferredSize(new java.awt.Dimension(110, 22));
        txtLongitude.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLongitudeFocusLost(evt);
            }
        });
        txtLongitude.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLongitudekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLongitudeKeyPressed(evt);
            }
        });
        pnlPlaceLong.add(txtLongitude);

        pnlData1.add(pnlPlaceLong);

        pnlEvent.setMinimumSize(new java.awt.Dimension(375, 30));
        pnlEvent.setPreferredSize(new java.awt.Dimension(474, 23));
        pnlEvent.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblEventType.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEventType.setText(bundle.getString("Event")); // NOI18N
        lblEventType.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblEventType.setOpaque(true);
        lblEventType.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlEvent.add(lblEventType);

        txtEvent.setPreferredSize(new java.awt.Dimension(255, 22));
        txtEvent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEventMouseClicked(evt);
            }
        });
        txtEvent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEventKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEventKeyPressed(evt);
            }
        });
        pnlEvent.add(txtEvent);

        pnlData1.add(pnlEvent);

        pnlSign.setMaximumSize(new java.awt.Dimension(32767, 34));
        pnlSign.setMinimumSize(new java.awt.Dimension(225, 34));
        pnlSign.setPreferredSize(new java.awt.Dimension(474, 24));
        pnlSign.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblSign.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSign.setText(bundle.getString("Sign")); // NOI18N
        lblSign.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblSign.setOpaque(true);
        lblSign.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlSign.add(lblSign);

        cboSign.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cboSign.setMaximumRowCount(10);
        cboSign.setKeySelectionManager(new MultiKeySelectionManager());
        cboSign.setPreferredSize(new java.awt.Dimension(155, 22));
        cboSign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboSignActionPerformed(evt);
            }
        });
        cboSign.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cboSignKeyTyped(evt);
            }
        });
        pnlSign.add(cboSign);

        pnlData1.add(pnlSign);

        pnlAs.setMinimumSize(new java.awt.Dimension(225, 34));
        pnlAs.setPreferredSize(new java.awt.Dimension(474, 24));
        pnlAs.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblAscendant.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAscendant.setText(bundle.getString("Ascendant")); // NOI18N
        lblAscendant.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblAscendant.setOpaque(true);
        lblAscendant.setPreferredSize(new java.awt.Dimension(120, 22));
        pnlAs.add(lblAscendant);

        cboAscendant.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cboAscendant.setMaximumRowCount(10);
        cboAscendant.setKeySelectionManager(new MultiKeySelectionManager());
        cboAscendant.setPreferredSize(new java.awt.Dimension(155, 22));
        cboAscendant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboAscendantActionPerformed(evt);
            }
        });
        cboAscendant.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cboAscendantKeyTyped(evt);
            }
        });
        pnlAs.add(cboAscendant);

        jPanel2.setPreferredSize(new java.awt.Dimension(198, 24));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        lblNote.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNote.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblNote.setAlignmentY(1.0F);
        lblNote.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblNote.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblNote.setOpaque(true);
        lblNote.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel2.add(lblNote);

        pnlAs.add(jPanel2);

        pnlData1.add(pnlAs);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(474, 100));

        txtComments.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCommentsKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCommentskeyTyped(evt);
            }
        });
        jScrollPane2.setViewportView(txtComments);

        pnlData1.add(jScrollPane2);

        plnDateTime.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 255, 255), null));
        plnDateTime.setMaximumSize(new java.awt.Dimension(32767, 90));
        plnDateTime.setMinimumSize(new java.awt.Dimension(449, 90));
        plnDateTime.setPreferredSize(new java.awt.Dimension(475, 86));
        plnDateTime.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        jPanel32.setAlignmentY(0.0F);
        jPanel32.setMaximumSize(new java.awt.Dimension(32767, 20));
        jPanel32.setMinimumSize(new java.awt.Dimension(101, 20));
        jPanel32.setPreferredSize(new java.awt.Dimension(470, 28));
        jPanel32.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel33.setPreferredSize(new java.awt.Dimension(225, 23));
        jPanel33.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDate.setText(bundle.getString("Date")); // NOI18N
        lblDate.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblDate.setMaximumSize(new java.awt.Dimension(110, 18));
        lblDate.setMinimumSize(new java.awt.Dimension(110, 18));
        lblDate.setOpaque(true);
        lblDate.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel33.add(lblDate);

        txtDate.setPreferredSize(new java.awt.Dimension(100, 22));
        txtDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDateFocusLost(evt);
            }
        });
        txtDate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDatekeyTyped(evt);
            }
        });
        jPanel33.add(txtDate);

        jPanel32.add(jPanel33);

        jPanel6.setPreferredSize(new java.awt.Dimension(234, 23));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 0));

        jPanel34.setPreferredSize(new java.awt.Dimension(4, 10));
        jPanel6.add(jPanel34);

        lblTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTime.setText(bundle.getString("Hour")); // NOI18N
        lblTime.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblTime.setMaximumSize(new java.awt.Dimension(110, 18));
        lblTime.setMinimumSize(new java.awt.Dimension(110, 18));
        lblTime.setOpaque(true);
        lblTime.setPreferredSize(new java.awt.Dimension(120, 22));
        jPanel6.add(lblTime);

        txtTime.setPreferredSize(new java.awt.Dimension(100, 22));
        txtTime.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTimeFocusLost(evt);
            }
        });
        txtTime.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTimeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTimekeyTyped(evt);
            }
        });
        jPanel6.add(txtTime);

        jPanel32.add(jPanel6);

        plnDateTime.add(jPanel32);

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 12));
        jPanel20.setMinimumSize(new java.awt.Dimension(268, 12));
        jPanel20.setPreferredSize(new java.awt.Dimension(470, 28));
        jPanel20.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 3));

        grpUtLocal.add(optLocal);
        optLocal.setSelected(true);
        optLocal.setText(bundle.getString("Legal")); // NOI18N
        optLocal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        optLocal.setPreferredSize(new java.awt.Dimension(225, 22));
        optLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optLocalActionPerformed(evt);
            }
        });
        jPanel20.add(optLocal);

        grpUtLocal.add(optUT);
        optUT.setText(bundle.getString("UT")); // NOI18N
        optUT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        optUT.setPreferredSize(new java.awt.Dimension(225, 22));
        optUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optUTActionPerformed(evt);
            }
        });
        jPanel20.add(optUT);

        plnDateTime.add(jPanel20);

        jPanel21.setMaximumSize(new java.awt.Dimension(32767, 20));
        jPanel21.setMinimumSize(new java.awt.Dimension(220, 20));
        jPanel21.setPreferredSize(new java.awt.Dimension(450, 26));
        jPanel21.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jPanel8.setPreferredSize(new java.awt.Dimension(415, 26));
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnCalcTZ.setFont(new java.awt.Font("Lucida Grande", 0, 12)); // NOI18N
        btnCalcTZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calcr2.png"))); // NOI18N
        btnCalcTZ.setText(bundle.getString("TimeZoneAndDaylightSavingTime")); // NOI18N
        btnCalcTZ.setPreferredSize(new java.awt.Dimension(300, 26));
        btnCalcTZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcTZActionPerformed(evt);
            }
        });
        jPanel8.add(btnCalcTZ);

        txtTZ.setPreferredSize(new java.awt.Dimension(100, 22));
        txtTZ.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTZFocusLost(evt);
            }
        });
        txtTZ.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTZKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTZkeyTyped(evt);
            }
        });
        jPanel8.add(txtTZ);

        jPanel21.add(jPanel8);

        plnDateTime.add(jPanel21);

        pnlData1.add(plnDateTime);

        jPanel1.setPreferredSize(new java.awt.Dimension(474, 255));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblPhoto.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPhoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPhoto.setOpaque(true);
        lblPhoto.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel1.add(lblPhoto);

        pnlPhoto.setPreferredSize(new java.awt.Dimension(324, 246));
        pnlPhoto.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        jPanel1.add(pnlPhoto);

        pnlData1.add(jPanel1);

        pnlData.add(pnlData1);

        getContentPane().add(pnlData, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddActionPerformed
    {//GEN-HEADEREND:event_btnAddActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveActionPerformed
    {//GEN-HEADEREND:event_btnRemoveActionPerformed
        removeRec();
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        nom = txtNom.getText();
        otherNames = txtAutresNoms.getText();
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
        {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        updateInstances();
    }//GEN-LAST:event_formWindowClosing

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        //updateInstances();
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKActionPerformed

    private void txtNomMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtNomMouseClicked
    {//GEN-HEADEREND:event_txtNomMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtNom, "events", "SURNAME", bundle.getString("eventsSURNAME"), false, null, false, null, true);
            txtNom.setText(strText);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtNomMouseClicked

    private void txtNomKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNomKeyPressed
    {//GEN-HEADEREND:event_txtNomKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtNom, "events", "SURNAME", bundle.getString("eventsSURNAME"), true, null, false, null, true);
            if (strText.equals(""))
            {
                txtNom.setText("");
                return;
            }
            String id = starLoginManager.getMainFieldID_S("events", "SURNAME", strText);
            if (id.equals("-1")||id.equals(""))
            {
                if (bolAdding == false)
                    addRecord();
                else
                    txtNom.setText("");
            }
            else
            {
                strText = starLoginManager.getStringFieldValue("events", "SURNAME", " WHERE ID=" + id);
                txtNom.setText(strText);
                //showEvent(id);
            }
            bolEditing = true;
            setEditMode();

        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtNom.setText(nom);
        }
    }//GEN-LAST:event_txtNomKeyPressed

    private void txtAutresNomsMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtAutresNomsMouseClicked
    {//GEN-HEADEREND:event_txtAutresNomsMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtAutresNoms, "events", "otherNames", bundle.getString("eventsOTHERNAMES"), false, null, false, null, true);
            txtAutresNoms.setText(strText);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtAutresNomsMouseClicked

    private void txtAutresNomsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAutresNomsKeyPressed
    {//GEN-HEADEREND:event_txtAutresNomsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtAutresNoms, "events", "OTHERNAMES", bundle.getString("eventsOTHERNAMES"), true, null, false, null, true);
            if (strText.equals(""))
            {
                txtAutresNoms.setText("");
                return;
            }
            String id = starLoginManager.getMainFieldID_S("events", "OTHERNAMES", strText);
            if (id.equals("-1")||id.equals(""))
            {
                if (bolAdding == false)
                    addRecord();
                else
                    txtAutresNoms.setText("");
            }
            else
            {
                strText = starLoginManager.getStringFieldValue("events", "OTHERNAMES", " WHERE ID=" + id);
                txtAutresNoms.setText(strText);
            }
            bolEditing = true;
            setEditMode();
        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAutresNoms.setText(otherNames);
        }
    }//GEN-LAST:event_txtAutresNomsKeyPressed

    private void txtEntityTypeMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtEntityTypeMouseClicked
    {//GEN-HEADEREND:event_txtEntityTypeMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtEntityType, "events", "entitytype", bundle.getString("eventsENTITYTYPE"), false, null, false, null, true);
            txtEntityType.setText(strText);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtEntityTypeMouseClicked

    private void txtEntityTypeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEntityTypeKeyPressed
    {//GEN-HEADEREND:event_txtEntityTypeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtEntityType, "events", "entitytype", bundle.getString("eventsENTITYTYPE"), true, null, false, null, true);
            if (strText.equals(""))
            {
                txtEntityType.setText("");
                return;
            }
            String id = starLoginManager.getMainFieldID_S("events", "entitytype", strText);
            if (id.equals("-1")||id.equals(""))
            {
                if (bolAdding == false)
                    addRecord();
                else
                    txtEntityType.setText("");
            }
            else
            {
                strText = starLoginManager.getStringFieldValue("events", "ENTITYTYPE", " WHERE ID=" + id);
                txtEntityType.setText(strText);
            }
            bolEditing = true;
            setEditMode();
        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtEntityType.setText(entityType);
        }
    }//GEN-LAST:event_txtEntityTypeKeyPressed

    private void txtPlaceMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtPlaceMouseClicked
    {//GEN-HEADEREND:event_txtPlaceMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtPlace, "places", "PLACENAME", bundle.getString("placesPLACENAME"), false, null, false, null, false);
            if (strText.equals(""))
            {
                txtPlace.setText("");
                return;
            }
            String id = starLoginManager.getMainFieldID_S("places", "PLACENAME", strText);
            if (id.equals("-1")||id.equals(""))
            {
                txtPlace.setText("");
            }
            else
            {
                strText = starLoginManager.getStringFieldValue("places", "PLACENAME", " WHERE ID=" + id);
                txtPlace.setText(strText);
                strText = starLoginManager.getStringFieldValue("places", "PLACELATITUDE", " WHERE ID=" + id);
                FLatitude l = new FLatitude(strText);
                latitude = l.getLatitude();
                txtLatitude.setText(latitude);
                strText = starLoginManager.getStringFieldValue("places", "PLACELONGITUDE", " WHERE ID=" + id);
                FLongitude lo = new FLongitude(strText);
                longitude = lo.getLongitude();
                txtLongitude.setText(longitude);
            }
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtPlaceMouseClicked

    private void txtPlaceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceKeyPressed
    {//GEN-HEADEREND:event_txtPlaceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtPlace, "places", "PLACENAME", bundle.getString("placesPLACENAME"), true, null, false, null, false);
            if (strText.equals(""))
            {
                txtPlace.setText("");
                return;
            }
            String id = starLoginManager.getMainFieldID_S("places", "PLACENAME", strText);
            if (id.equals("-1")||id.equals(""))
            {
                txtPlace.setText("");
            }
            else
            {
                strText = starLoginManager.getStringFieldValue("places", "PLACENAME", " WHERE ID=" + id);
                txtPlace.setText(strText);
                strText = starLoginManager.getStringFieldValue("places", "PLACELATITUDE", " WHERE ID=" + id);
                FLatitude l = new FLatitude(strText);
                oldlatitude = latitude;
                latitude = l.getLatitude();
                txtLatitude.setText(latitude);
                strText = starLoginManager.getStringFieldValue("places", "PLACELONGITUDE", " WHERE ID=" + id);
                FLongitude lo = new FLongitude(strText);
                oldlongitude = longitude;
                longitude = lo.getLongitude();
                txtLongitude.setText(longitude);
            }
            bolEditing = true;
            setEditMode();
        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPlace.setText(place);
            txtLatitude.setText(oldlatitude);
            txtLongitude.setText(oldlongitude);
        }
    }//GEN-LAST:event_txtPlaceKeyPressed

    private void txtLatitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudeFocusLost
    {//GEN-HEADEREND:event_txtLatitudeFocusLost
        FLatitude l = new FLatitude(txtLatitude.getText());
        String sText = l.getLatitude();
        txtLatitude.setText(sText);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtLatitudeFocusLost

    private void txtLatitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudekeyTyped
    {//GEN-HEADEREND:event_txtLatitudekeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitude.setCaretPosition(cp-1);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtLatitudekeyTyped

    private void txtLatitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeKeyPressed
    {//GEN-HEADEREND:event_txtLatitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitude.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLatitude.setText(latitude);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLatitude, kc);
        }
    }//GEN-LAST:event_txtLatitudeKeyPressed

    private void txtLongitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeFocusLost
    {//GEN-HEADEREND:event_txtLongitudeFocusLost
        FLongitude l = new FLongitude(txtLongitude.getText());
        String sText = l.getLongitude();
        txtLongitude.setText(sText);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtLongitudeFocusLost

    private void txtLongitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudekeyTyped
    {//GEN-HEADEREND:event_txtLongitudekeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitude.setCaretPosition(cp-1);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtLongitudekeyTyped

    private void txtLongitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitude.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitude.setText(longitude);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTLongitude lng;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lng = new KTLongitude(evt, txtLongitude, kc);
        }
    }//GEN-LAST:event_txtLongitudeKeyPressed

    private void txtEventMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtEventMouseClicked
    {//GEN-HEADEREND:event_txtEventMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtEvent, "events", "EVENTTYPE", bundle.getString("eventsEVENTTYPE"), false, null, false, null, true);
            txtEvent.setText(strText);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtEventMouseClicked

    private void txtEventKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEventKeyPressed
    {//GEN-HEADEREND:event_txtEventKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtEvent, "events", "EVENTTYPE", bundle.getString("eventsEVENTTYPE"), true, null, false, null, true);
            txtEvent.setText(strText);
            bolEditing = true;
            setEditMode();
        }
        else if (kc == KeyEvent.VK_ESCAPE)
        {
            txtEvent.setText(eventName);
        }
    }//GEN-LAST:event_txtEventKeyPressed

    private void cboSignActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboSignActionPerformed
    {//GEN-HEADEREND:event_cboSignActionPerformed
        if (bSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboSignActionPerformed

    private void cboSignKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_cboSignKeyTyped
    {//GEN-HEADEREND:event_cboSignKeyTyped
        if (bSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboSignKeyTyped

    private void cboAscendantActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboAscendantActionPerformed
    {//GEN-HEADEREND:event_cboAscendantActionPerformed
        if (bSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboAscendantActionPerformed

    private void cboAscendantKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_cboAscendantKeyTyped
    {//GEN-HEADEREND:event_cboAscendantKeyTyped
        if (bSetting == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_cboAscendantKeyTyped

    private void txtCommentsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCommentsKeyPressed
    {//GEN-HEADEREND:event_txtCommentsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            bolEditing = true;
            setEditMode();
            txtComments.setText(comments);
        }
    }//GEN-LAST:event_txtCommentsKeyPressed

    private void txtCommentskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCommentskeyTyped
    {//GEN-HEADEREND:event_txtCommentskeyTyped
        bolEditing = true;
        setEditMode();
        int size = 10000;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtComments.getText().length() >= size)
        {
            txtComments.setText(txtComments.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtCommentskeyTyped

    private void txtDateFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateFocusLost
    {//GEN-HEADEREND:event_txtDateFocusLost
        String sText = txtDate.getText();
        sText = MainClass.getFormatedDate(sText);
        txtDate.setText(sText);
        if (optLocal.isSelected())
        {
            localDate = sText;
            event.setLocalDate(sText);
        }
        else
            
        {
            utDate = sText;
            event.setUtDate(sText);
        }
        btnCalcTZActionPerformed(null);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtDateFocusLost

    private void txtDatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDatekeyTyped
    {//GEN-HEADEREND:event_txtDatekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDate, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDate.setCaretPosition(cp-1);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtDatekeyTyped

    private void txtDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateKeyPressed
    {//GEN-HEADEREND:event_txtDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDate.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            if (optLocal.isSelected())
            {
                txtDate.setText(localDate);
            }
            else
            {
                txtDate.setText(utDate);
            }
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDateAstro date;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                date = new KTDateAstro(evt, txtDate, kc);
        }
    }//GEN-LAST:event_txtDateKeyPressed

    private void txtTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTimeFocusLost
    {//GEN-HEADEREND:event_txtTimeFocusLost
        /*FTime t = new FTime(txtTime.getText());
        String sText = t.getTime();
        txtTime.setText(sText);*/
        FTime t = new FTime(txtTime.getText());
        String sText = t.getTime();
        txtTime.setText(sText);
        if (optLocal.isSelected())
        {
            localTime = sText;
            event.setLocalTime(sText);
        }
        else
        {
            utTime = sText;
            event.setUtTime(sText);
        }
        btnCalcTZActionPerformed(null);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtTimeFocusLost

    private void txtTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimekeyTyped
    {//GEN-HEADEREND:event_txtTimekeyTyped
        KTTime ti = new KTTime(evt, txtTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTimekeyTyped

    private void txtTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimeKeyPressed
    {//GEN-HEADEREND:event_txtTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtTime.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            if (optLocal.isSelected())
            {
                txtTime.setText(localTime);
            }
            else
            {
                txtTime.setText(utTime);
            }
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtTime, kc);
        }
    }//GEN-LAST:event_txtTimeKeyPressed

    private void optLocalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optLocalActionPerformed
    {//GEN-HEADEREND:event_optLocalActionPerformed
        txtDate.setText(localDate);
        txtTime.setText(localTime);
    }//GEN-LAST:event_optLocalActionPerformed

    private void optUTActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optUTActionPerformed
    {//GEN-HEADEREND:event_optUTActionPerformed
        txtDate.setText(utDate);
        txtTime.setText(utTime);
    }//GEN-LAST:event_optUTActionPerformed

    private void btnCalcTZActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCalcTZActionPerformed
    {//GEN-HEADEREND:event_btnCalcTZActionPerformed
        changeTime(TZRules.FirstTime);
        changeTime(TZRules.SecondTime);
        if (bolAdding == false && bolEditing == false)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_btnCalcTZActionPerformed

    private void txtTZFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTZFocusLost
    {//GEN-HEADEREND:event_txtTZFocusLost
        if (bolEditing == false)
        {
            return;
        }
        tz = txtTZ.getText();
        if (tz.equals(""))
        {
            return;
        }
        double value = new Double(tz).doubleValue();

        //The value must be between -24 and 24
        if (value < -24.0)
        {
            tz = "-24";
            txtTZ.setText(tz);
        }
        else if (value > 24.0)
        {
            tz = "24";
            txtTZ.setText(tz);
        }
    }//GEN-LAST:event_txtTZFocusLost

    private void txtTZkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZkeyTyped
    {//GEN-HEADEREND:event_txtTZkeyTyped
        KTDecimal d = new KTDecimal(evt, txtTZ, 8, kc);
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtTZkeyTyped

    private void txtTZKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZKeyPressed
    {//GEN-HEADEREND:event_txtTZKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            bolEditing = true;
            setEditMode();
            txtTZ.setText(tz);
        }
    }//GEN-LAST:event_txtTZKeyPressed

    private void txtPlaceKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceKeyTyped
    {//GEN-HEADEREND:event_txtPlaceKeyTyped
        int size = 100;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtPlace.getText().length() >= size)
        {
            txtPlace.setText(txtPlace.getText().substring(0, size - 1));
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtPlaceKeyTyped

    private void txtEntityTypeKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEntityTypeKeyTyped
    {//GEN-HEADEREND:event_txtEntityTypeKeyTyped
        int size = 100;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtEntityType.getText().length() >= size)
        {
            txtEntityType.setText(txtEntityType.getText().substring(0, size - 1));
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtEntityTypeKeyTyped

    private void txtAutresNomsKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAutresNomsKeyTyped
    {//GEN-HEADEREND:event_txtAutresNomsKeyTyped
        int size = 100;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtAutresNoms.getText().length() >= size)
        {
            txtAutresNoms.setText(txtAutresNoms.getText().substring(0, size - 1));
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtAutresNomsKeyTyped

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNomKeyTyped
    {//GEN-HEADEREND:event_txtNomKeyTyped
        int size = 50;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtNom.getText().length() >= size)
        {
            txtNom.setText(txtNom.getText().substring(0, size - 1));
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtEventKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEventKeyTyped
    {//GEN-HEADEREND:event_txtEventKeyTyped
        int size = 100;//new Integer(String.valueOf(events.getSizes().get())).intValue();
        if (txtEvent.getText().length() >= size)
        {
            txtEvent.setText(txtEvent.getText().substring(0, size - 1));
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtEventKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCalcTZ;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnRemove;
    private javax.swing.JComboBox cboAscendant;
    private javax.swing.JComboBox cboSign;
    private javax.swing.ButtonGroup grpUtLocal;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblAscendant;
    private javax.swing.JLabel lblAutresNoms;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblEntityType;
    private javax.swing.JLabel lblEventType;
    private javax.swing.JLabel lblLatitude;
    private javax.swing.JLabel lblLongitude;
    private javax.swing.JLabel lblNom;
    private javax.swing.JLabel lblNote;
    private javax.swing.JLabel lblPhoto;
    private javax.swing.JLabel lblPlace;
    private javax.swing.JLabel lblSign;
    private javax.swing.JLabel lblTime;
    private javax.swing.JRadioButton optLocal;
    private javax.swing.JRadioButton optUT;
    private javax.swing.JPanel plnDateTime;
    private javax.swing.JPanel pnlAs;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlData1;
    private javax.swing.JPanel pnlEntity;
    private javax.swing.JPanel pnlEvent;
    private javax.swing.JPanel pnlOtherNames;
    private javax.swing.JPanel pnlPhoto;
    private javax.swing.JPanel pnlPlaceLat;
    private javax.swing.JPanel pnlPlaceLong;
    private javax.swing.JPanel pnlPlaceName;
    private javax.swing.JPanel pnlSign;
    private javax.swing.JPanel pnlSurname;
    private javax.swing.JTextField txtAutresNoms;
    private javax.swing.JTextPane txtComments;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtEntityType;
    private javax.swing.JTextField txtEvent;
    private javax.swing.JTextField txtLatitude;
    private javax.swing.JTextField txtLongitude;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPlace;
    private javax.swing.JTextField txtTZ;
    private javax.swing.JTextField txtTime;
    // End of variables declaration//GEN-END:variables
}
