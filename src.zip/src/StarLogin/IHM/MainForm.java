package StarLogin.IHM;

//import com.sun.jna.platform.WindowUtils;
import StarLogin.IHM.components.KeyType.*;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FLatitude;
import StarLogin.Systeme.AstroCalc.FLongitude;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.AstroCalc.TZRules;
import StarLogin.Systeme.Data.Event;
import StarLogin.Systeme.Enum.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois Deschamps
 */
public final class MainForm extends javax.swing.JFrame
{
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private java.util.ResourceBundle bundle;
    private static boolean bOrganizer = false;
    private static boolean bCartes = false;
    private static boolean bStats = false;
    private static boolean bConfig = false;
    private static boolean bCalcul = false;
    private String oldlatitude;
    private String oldlongitude;
    private boolean bDataModif = false;
    private int choixAction = 0;
    private int cp = 0;//caret position
    public static final String signName[]=
    {Signs.getSignName(0),Signs.getSignName(1),Signs.getSignName(2),Signs.getSignName(3),Signs.getSignName(4),Signs.getSignName(5),Signs.getSignName(6),Signs.getSignName(7),Signs.getSignName(8),Signs.getSignName(9),Signs.getSignName(10),Signs.getSignName(11)};
    //Name of constellations
    public static final String zodConstelName[]=
    {ZodConstels.getZodConstelName(0),ZodConstels.getZodConstelName(1),ZodConstels.getZodConstelName(2),ZodConstels.getZodConstelName(3),ZodConstels.getZodConstelName(4),ZodConstels.getZodConstelName(5),ZodConstels.getZodConstelName(6),ZodConstels.getZodConstelName(7),ZodConstels.getZodConstelName(8),ZodConstels.getZodConstelName(9),ZodConstels.getZodConstelName(10),ZodConstels.getZodConstelName(11),ZodConstels.getZodConstelName(12),ZodConstels.getZodConstelName(13)};
    //Name of houses
    public static final String houseName[]=
    {Cusp.getCuspName(0),Cusp.getCuspName(1),Cusp.getCuspName(2),Cusp.getCuspName(3),Cusp.getCuspName(4),Cusp.getCuspName(5),Cusp.getCuspName(6),Cusp.getCuspName(7),Cusp.getCuspName(8),Cusp.getCuspName(9),Cusp.getCuspName(10),Cusp.getCuspName(11),Cusp.getCuspName(12),Cusp.getCuspName(13)};
    //Name of house systems
    public static final String houseSysName[]=
    {HouseSystem.getHouseSystemName(0),HouseSystem.getHouseSystemName(1),HouseSystem.getHouseSystemName(2),HouseSystem.getHouseSystemName(3),HouseSystem.getHouseSystemName(4),HouseSystem.getHouseSystemName(5),HouseSystem.getHouseSystemName(6),HouseSystem.getHouseSystemName(7),HouseSystem.getHouseSystemName(8),HouseSystem.getHouseSystemName(9),HouseSystem.getHouseSystemName(10),HouseSystem.getHouseSystemName(11),HouseSystem.getHouseSystemName(12),HouseSystem.getHouseSystemName(13),HouseSystem.getHouseSystemName(14),HouseSystem.getHouseSystemName(15),HouseSystem.getHouseSystemName(16),HouseSystem.getHouseSystemName(17),HouseSystem.getHouseSystemName(18),HouseSystem.getHouseSystemName(19),HouseSystem.getHouseSystemName(20)};
    //Name of planets
    public static final String planetName[]=
    {Planets.getPlanetName(0),Planets.getPlanetName(1),Planets.getPlanetName(2),Planets.getPlanetName(3),Planets.getPlanetName(4),Planets.getPlanetName(5),Planets.getPlanetName(6),Planets.getPlanetName(7),Planets.getPlanetName(8),Planets.getPlanetName(9),Planets.getPlanetName(10),Planets.getPlanetName(11),Planets.getPlanetName(12),Planets.getPlanetName(13),Planets.getPlanetName(14),Planets.getPlanetName(15),Planets.getPlanetName(16),Planets.getPlanetName(17),Planets.getPlanetName(18),Planets.getPlanetName(19),Planets.getPlanetName(20),Planets.getPlanetName(21),Planets.getPlanetName(22),Planets.getPlanetName(23),Planets.getPlanetName(24),Planets.getPlanetName(25),Planets.getPlanetName(26),Planets.getPlanetName(27),Planets.getPlanetName(28),Planets.getPlanetName(29),Planets.getPlanetName(30),Planets.getPlanetName(31),Planets.getPlanetName(32),Planets.getPlanetName(33),Planets.getPlanetName(34),Planets.getPlanetName(35),Planets.getPlanetName(36),Planets.getPlanetName(37)};
    //Name of aspects
    public static final String aspectName[]=
    {AspectType.getAspectName(0),AspectType.getAspectName(1),AspectType.getAspectName(2),AspectType.getAspectName(3),AspectType.getAspectName(4),AspectType.getAspectName(5),AspectType.getAspectName(6),AspectType.getAspectName(7),AspectType.getAspectName(8),AspectType.getAspectName(9),AspectType.getAspectName(10),AspectType.getAspectName(11),AspectType.getAspectName(12),AspectType.getAspectName(13),AspectType.getAspectName(14),AspectType.getAspectName(15),AspectType.getAspectName(16),AspectType.getAspectName(17)};
    //Name of coordinates
    public static final String coordinateName[]=
    {Coordinate.getCoordinateName(0),Coordinate.getCoordinateName(1),Coordinate.getCoordinateName(2),Coordinate.getCoordinateName(3),Coordinate.getCoordinateName(4),Coordinate.getCoordinateName(5)};
    //Name of months
    public static final String monthName[]=
    {Months.getMonthName(0),Months.getMonthName(1),Months.getMonthName(2),Months.getMonthName(3),Months.getMonthName(4),Months.getMonthName(5),Months.getMonthName(6),Months.getMonthName(7),Months.getMonthName(8),Months.getMonthName(9),Months.getMonthName(10),Months.getMonthName(11)};
    //Name of planetary configurations
    public static final String configName[]=
    {Configs.getConfigName(0),Configs.getConfigName(1),Configs.getConfigName(2),Configs.getConfigName(3),Configs.getConfigName(4),Configs.getConfigName(5),Configs.getConfigName(6),Configs.getConfigName(7),Configs.getConfigName(8),Configs.getConfigName(9),Configs.getConfigName(10),Configs.getConfigName(11),Configs.getConfigName(12),Configs.getConfigName(13),Configs.getConfigName(14),Configs.getConfigName(15),Configs.getConfigName(16),Configs.getConfigName(17),Configs.getConfigName(18),Configs.getConfigName(19),Configs.getConfigName(20),Configs.getConfigName(21),Configs.getConfigName(22),Configs.getConfigName(23),Configs.getConfigName(24),Configs.getConfigName(25),Configs.getConfigName(26)};
    //Name of coordinates systems
    public static final String coordSysName[]=
    {CoordSystem.getCoordSystemName(0),CoordSystem.getCoordSystemName(1),CoordSystem.getCoordSystemName(2),CoordSystem.getCoordSystemName(3),CoordSystem.getCoordSystemName(4),CoordSystem.getCoordSystemName(5),CoordSystem.getCoordSystemName(6),CoordSystem.getCoordSystemName(7),CoordSystem.getCoordSystemName(8)};
    
    private String classname = this.getClass().getName();
    /*private Image image;
    private int imageHeight;
    private int imageWidth;
    private int width;
    private int height;*/
    private ImageIcon bkn[] = new ImageIcon[6];
    private ImageIcon bkh[] = new ImageIcon[6];
    private ImageIcon bkc[] = new ImageIcon[6];
    private ImageIcon rbkn[] = new ImageIcon[6];
    private ImageIcon rbkh[] = new ImageIcon[6];
    private ImageIcon rbkc[] = new ImageIcon[6];
    private int kc;
    private String surname;
    private String otherNames;
    private String eventName;
    private String entityType;
    private String localDate;
    private String localTime;
    private String utDate;
    private String utTime;
    private String tz;
    private String place;
    private String latitude;
    private String longitude;
    private String eventID;
    public static Event currentEvent;
    private static Event saveCurrentEvent;

    /** Creates new form MainForm */
    public MainForm()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        bkn[0] = new ImageIcon(getClass().getResource("/StarLogin/images/organizer_n.png"));
        bkn[1] = new ImageIcon(getClass().getResource("/StarLogin/images/events_n.png"));
        bkn[2] = new ImageIcon(getClass().getResource("/StarLogin/images/cartes_n.png"));
        bkn[3] = new ImageIcon(getClass().getResource("/StarLogin/images/stats_n.png"));
        bkn[4] = new ImageIcon(getClass().getResource("/StarLogin/images/config_n.png"));
        bkn[5] = new ImageIcon(getClass().getResource("/StarLogin/images/calc_n.png"));
        bkh[0] = new ImageIcon(getClass().getResource("/StarLogin/images/organizer_h.png"));
        bkh[1] = new ImageIcon(getClass().getResource("/StarLogin/images/events_h.png"));
        bkh[2] = new ImageIcon(getClass().getResource("/StarLogin/images/cartes_h.png"));
        bkh[3] = new ImageIcon(getClass().getResource("/StarLogin/images/stats_h.png"));
        bkh[4] = new ImageIcon(getClass().getResource("/StarLogin/images/config_h.png"));
        bkh[5] = new ImageIcon(getClass().getResource("/StarLogin/images/calc_h.png"));
        bkc[0] = new ImageIcon(getClass().getResource("/StarLogin/images/organizer_c.png"));
        bkc[1] = new ImageIcon(getClass().getResource("/StarLogin/images/events_c.png"));
        bkc[2] = new ImageIcon(getClass().getResource("/StarLogin/images/cartes_c.png"));
        bkc[3] = new ImageIcon(getClass().getResource("/StarLogin/images/stats_c.png"));
        bkc[4] = new ImageIcon(getClass().getResource("/StarLogin/images/config_c.png"));
        bkc[5] = new ImageIcon(getClass().getResource("/StarLogin/images/calc_c.png"));
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/starlog.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        int pos = classname.lastIndexOf(".");
        if (pos > 0)
        {
            classname = classname.substring(pos + 1);
        }
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        this.setExtendedState(params[4]);
        
        /*Window window = (Window) this;
        System.setProperty("sun.java2d.noddraw","true");
        WindowUtils.setWindowAlpha(window,0.95f);
        System.getProperties().remove("sun.java2d.noddraw");*/
        
        currentEvent = starLoginManager.getEvent(MainClass.currentEventID, "");
        resetEvent(currentEvent);
        pnlButtons.setBackground(Color.white);
        resetLangue();
        MainClass.event = currentEvent;
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    public void resetEvent(StarLogin.Systeme.Data.Event event)
    {
        currentEvent = event;
        if (event == null)
            return;
        saveCurrentEvent = event.cloneEvent(event);
        
        surname = currentEvent.getSurname();
        otherNames = currentEvent.getOtherNames();
        entityType = currentEvent.getEntityType();
        eventName = currentEvent.getEventName();
        localDate = currentEvent.getLocalDate();
        //FDate ldate = new FDate(localDate);
        utDate = currentEvent.getUtDate();
        localTime = currentEvent.getLocalTime();
        utTime = currentEvent.getUtTime();
        tz = currentEvent.getTimeLag();
        place = currentEvent.getPlace();
        latitude = currentEvent.getLatitude();
        longitude = currentEvent.getLongitude();
        FLatitude l = new FLatitude(latitude);
        latitude = l.getLatitude();
        FLongitude lo = new FLongitude(longitude);
        longitude = lo.getLongitude();
        oldlatitude = latitude;
        oldlongitude = longitude;
        txtEvent.setText(eventName);
        txtSurname.setText(surname);
        txtOtherNames.setText(otherNames);
        txtEntityType.setText(entityType);
        if (optLocal.isSelected())
        {
            txtDate.setText(localDate);
            txtTime.setText(localTime);
        }
        else
        {
            txtDate.setText(utDate);
            txtTime.setText(utTime);
        }
        txtTZ.setText(tz);
        txtPlace.setText(place);
        txtLatitude.setText(latitude);
        txtLongitude.setText(longitude);
        eventID = currentEvent.getId();
    }
    
    private void runHelp()
    {
        StarLogin.Systeme.Enum.OS.runExplorer("starlogin/".concat(MainClass.langue).concat("/presentation.html"));
    }
    
    public void setOrganizerFrame(boolean value)
    {
        bOrganizer = value;
    }
    
    public void setCartesFrame(boolean value)
    {
        bCartes = value;
    }
    
    public void setStatsFrame(boolean value)
    {
        bStats = value;
    }
    
    public void setConfigFrame(boolean value)
    {
        bConfig = value;
    }
    
    public void setCalculFrame(boolean value)
    {
        bCalcul = value;
    }

    public final void resetLangue()
    {
        bundle = MainClass.bundle;
        setTitle(bundle.getString("StarlogVersion"));
        txtPlace.setToolTipText(bundle.getString("DoubleClick4List"));
        txtEntityType.setToolTipText(bundle.getString("DoubleClick4List"));
        txtEvent.setToolTipText(bundle.getString("DoubleClick4List"));
        txtSurname.setToolTipText(bundle.getString("DoubleClick4List"));
        txtOtherNames.setToolTipText(bundle.getString("DoubleClick4List"));
        lblOrganizer.setToolTipText(bundle.getString("ContactsEtc"));
        lblOrganizer2.setToolTipText(bundle.getString("ContactsEtc"));
        btnHelp.setText(bundle.getString("Help"));
        lblOrganizer2.setText(bundle.getString("Organizer"));
        lblEvents2.setText(bundle.getString("Events"));
        lblCartes2.setText(bundle.getString("Cartes"));
        lblDataStats2.setText(bundle.getString("RapportsStats"));
        lblConfig2.setText(bundle.getString("ToolsConfig"));
        lblCalcul2.setText(bundle.getString("VariousCalculations"));
        jLabel2.setText(bundle.getString("Surname"));
        jLabel3.setText(bundle.getString("OtherNames"));
        jLabel4.setText(bundle.getString("EntityType"));
        jLabel5.setText(bundle.getString("Place"));
        lblLatitude.setText(bundle.getString("Latitude"));
        lblLongitude.setText(bundle.getString("Longitude"));
        lblLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        lblLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        txtLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        txtLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        jLabel6.setText(bundle.getString("Event"));
        jLabel9.setText(bundle.getString("Date"));
        jLabel11.setText(bundle.getString("Hour"));
        optLocal.setText(bundle.getString("Legal"));
        optUT.setText(bundle.getString("UT"));
        btnCalcTZ.setText(bundle.getString("TimeZoneAndDaylightSavingTime"));

    }

    public void sortir()
    {
        Rectangle rct = this.getBounds();
        int state = this.getExtendedState();
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        
        try
        {
            starLoginManager.getConnection().close();
        }
        catch (java.sql.SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        System.exit(0);
    }

    /*public void setStatusText(String text)
    {
        txtStatusBar.setText(text);
    }*/

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    //@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpTimeKind = new javax.swing.ButtonGroup();
        pnlButtons = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lblOrganizer = new javax.swing.JLabel();
        lblOrganizer2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblEvents = new javax.swing.JLabel();
        lblEvents2 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblCartes = new javax.swing.JLabel();
        lblCartes2 = new javax.swing.JLabel();
        pnlEvent1 = new javax.swing.JPanel();
        pnlSurname = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtSurname = new javax.swing.JTextField();
        pnlOtherNames = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtOtherNames = new javax.swing.JTextField();
        pnlEntity = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtEntityType = new javax.swing.JTextField();
        pnlSpace = new javax.swing.JPanel();
        pnlPlaceName = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtPlace = new javax.swing.JTextField();
        pnlPlaceLat = new javax.swing.JPanel();
        lblLatitude = new javax.swing.JLabel();
        txtLatitude = new javax.swing.JTextField();
        pnlPlaceLong = new javax.swing.JPanel();
        lblLongitude = new javax.swing.JLabel();
        txtLongitude = new javax.swing.JTextField();
        pnlEvent = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtEvent = new javax.swing.JTextField();
        pnlEvent2 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtTime = new javax.swing.JTextField();
        optLocal = new javax.swing.JRadioButton();
        optUT = new javax.swing.JRadioButton();
        jPanel9 = new javax.swing.JPanel();
        btnCalcTZ = new javax.swing.JButton();
        txtTZ = new javax.swing.JTextField();
        pnlHelp = new javax.swing.JPanel();
        btnHelp = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        lblDataStats = new javax.swing.JLabel();
        lblDataStats2 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        lblConfig = new javax.swing.JLabel();
        lblConfig2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lblCalcul = new javax.swing.JLabel();
        lblCalcul2 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(888, 670));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        pnlButtons.setBackground(new java.awt.Color(255, 255, 255));
        pnlButtons.setPreferredSize(new java.awt.Dimension(840, 640));
        pnlButtons.setLayout(new java.awt.GridLayout(3, 4));

        jPanel7.setOpaque(false);
        jPanel7.setLayout(new java.awt.BorderLayout());
        pnlButtons.add(jPanel7);

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.BorderLayout());

        lblOrganizer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblOrganizerMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblOrganizerMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblOrganizerMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblOrganizerMouseReleased(evt);
            }
        });
        jPanel1.add(lblOrganizer, java.awt.BorderLayout.CENTER);

        lblOrganizer2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblOrganizer2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOrganizer2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblOrganizer2.setDoubleBuffered(true);
        lblOrganizer2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblOrganizer2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblOrganizer2MouseClicked(evt);
            }
        });
        jPanel1.add(lblOrganizer2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel1);

        jPanel2.setOpaque(false);
        jPanel2.setLayout(new java.awt.BorderLayout());

        lblEvents.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblEventsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblEventsMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEventsMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblEventsMouseReleased(evt);
            }
        });
        jPanel2.add(lblEvents, java.awt.BorderLayout.CENTER);

        lblEvents2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblEvents2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEvents2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblEvents2.setDoubleBuffered(true);
        lblEvents2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblEvents2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEvents2MouseClicked(evt);
            }
        });
        jPanel2.add(lblEvents2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel2);

        jPanel8.setOpaque(false);
        jPanel8.setLayout(new java.awt.BorderLayout());
        pnlButtons.add(jPanel8);

        jPanel3.setOpaque(false);
        jPanel3.setLayout(new java.awt.BorderLayout());

        lblCartes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCartesMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblCartesMouseReleased(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCartesMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCartesMouseEntered(evt);
            }
        });
        jPanel3.add(lblCartes, java.awt.BorderLayout.CENTER);

        lblCartes2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblCartes2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCartes2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblCartes2.setDoubleBuffered(true);
        lblCartes2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblCartes2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCartes2MouseClicked(evt);
            }
        });
        jPanel3.add(lblCartes2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel3);

        pnlEvent1.setOpaque(false);
        pnlEvent1.setPreferredSize(new java.awt.Dimension(210, 200));

        pnlSurname.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel2.setOpaque(true);
        jLabel2.setPreferredSize(new java.awt.Dimension(110, 22));

        txtSurname.setPreferredSize(new java.awt.Dimension(100, 22));
        txtSurname.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSurnameMouseClicked(evt);
            }
        });
        txtSurname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtSurnameFocusLost(evt);
            }
        });
        txtSurname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSurnameKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlSurnameLayout = new org.jdesktop.layout.GroupLayout(pnlSurname);
        pnlSurname.setLayout(pnlSurnameLayout);
        pnlSurnameLayout.setHorizontalGroup(
            pnlSurnameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlSurnameLayout.createSequentialGroup()
                .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtSurname, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE))
        );
        pnlSurnameLayout.setVerticalGroup(
            pnlSurnameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlSurnameLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlSurnameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtSurname, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlOtherNames.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel3.setOpaque(true);
        jLabel3.setPreferredSize(new java.awt.Dimension(110, 22));

        txtOtherNames.setPreferredSize(new java.awt.Dimension(100, 22));
        txtOtherNames.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtOtherNamesMouseClicked(evt);
            }
        });
        txtOtherNames.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtOtherNamesFocusLost(evt);
            }
        });
        txtOtherNames.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOtherNamesKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlOtherNamesLayout = new org.jdesktop.layout.GroupLayout(pnlOtherNames);
        pnlOtherNames.setLayout(pnlOtherNamesLayout);
        pnlOtherNamesLayout.setHorizontalGroup(
            pnlOtherNamesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlOtherNamesLayout.createSequentialGroup()
                .add(jLabel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtOtherNames, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );
        pnlOtherNamesLayout.setVerticalGroup(
            pnlOtherNamesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlOtherNamesLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlOtherNamesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtOtherNames, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlEntity.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel4.setOpaque(true);
        jLabel4.setPreferredSize(new java.awt.Dimension(110, 22));

        txtEntityType.setPreferredSize(new java.awt.Dimension(100, 22));
        txtEntityType.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEntityTypeMouseClicked(evt);
            }
        });
        txtEntityType.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtEntityTypeFocusLost(evt);
            }
        });
        txtEntityType.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEntityTypeKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlEntityLayout = new org.jdesktop.layout.GroupLayout(pnlEntity);
        pnlEntity.setLayout(pnlEntityLayout);
        pnlEntityLayout.setHorizontalGroup(
            pnlEntityLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEntityLayout.createSequentialGroup()
                .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtEntityType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );
        pnlEntityLayout.setVerticalGroup(
            pnlEntityLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEntityLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlEntityLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtEntityType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlSpace.setPreferredSize(new java.awt.Dimension(210, 1));

        org.jdesktop.layout.GroupLayout pnlSpaceLayout = new org.jdesktop.layout.GroupLayout(pnlSpace);
        pnlSpace.setLayout(pnlSpaceLayout);
        pnlSpaceLayout.setHorizontalGroup(
            pnlSpaceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 0, Short.MAX_VALUE)
        );
        pnlSpaceLayout.setVerticalGroup(
            pnlSpaceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 1, Short.MAX_VALUE)
        );

        pnlPlaceName.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel5.setOpaque(true);
        jLabel5.setPreferredSize(new java.awt.Dimension(110, 22));

        txtPlace.setPreferredSize(new java.awt.Dimension(100, 22));
        txtPlace.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPlaceMouseClicked(evt);
            }
        });
        txtPlace.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtPlaceFocusLost(evt);
            }
        });
        txtPlace.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlaceKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlPlaceNameLayout = new org.jdesktop.layout.GroupLayout(pnlPlaceName);
        pnlPlaceName.setLayout(pnlPlaceNameLayout);
        pnlPlaceNameLayout.setHorizontalGroup(
            pnlPlaceNameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceNameLayout.createSequentialGroup()
                .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtPlace, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );
        pnlPlaceNameLayout.setVerticalGroup(
            pnlPlaceNameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceNameLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlPlaceNameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtPlace, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlPlaceLat.setPreferredSize(new java.awt.Dimension(210, 23));

        lblLatitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLatitude.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblLatitude.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblLatitude.setOpaque(true);
        lblLatitude.setPreferredSize(new java.awt.Dimension(110, 22));

        txtLatitude.setText(" 00�00'00\"");
        txtLatitude.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLatitude.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLatitudeFocusLost(evt);
            }
        });
        txtLatitude.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLatitudeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLatitudekeyTyped(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlPlaceLatLayout = new org.jdesktop.layout.GroupLayout(pnlPlaceLat);
        pnlPlaceLat.setLayout(pnlPlaceLatLayout);
        pnlPlaceLatLayout.setHorizontalGroup(
            pnlPlaceLatLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceLatLayout.createSequentialGroup()
                .add(lblLatitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtLatitude, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        pnlPlaceLatLayout.setVerticalGroup(
            pnlPlaceLatLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceLatLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlPlaceLatLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lblLatitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtLatitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlPlaceLong.setPreferredSize(new java.awt.Dimension(210, 23));

        lblLongitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLongitude.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblLongitude.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblLongitude.setOpaque(true);
        lblLongitude.setPreferredSize(new java.awt.Dimension(110, 22));

        txtLongitude.setText(" 000�00'00\"");
        txtLongitude.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLongitude.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLongitudeFocusLost(evt);
            }
        });
        txtLongitude.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLongitudekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLongitudeKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlPlaceLongLayout = new org.jdesktop.layout.GroupLayout(pnlPlaceLong);
        pnlPlaceLong.setLayout(pnlPlaceLongLayout);
        pnlPlaceLongLayout.setHorizontalGroup(
            pnlPlaceLongLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceLongLayout.createSequentialGroup()
                .add(lblLongitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtLongitude, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        pnlPlaceLongLayout.setVerticalGroup(
            pnlPlaceLongLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlPlaceLongLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlPlaceLongLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lblLongitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtLongitude, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pnlEvent.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel6.setOpaque(true);
        jLabel6.setPreferredSize(new java.awt.Dimension(110, 22));

        txtEvent.setPreferredSize(new java.awt.Dimension(100, 22));
        txtEvent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEventMouseClicked(evt);
            }
        });
        txtEvent.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtEventFocusLost(evt);
            }
        });
        txtEvent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEventKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnlEventLayout = new org.jdesktop.layout.GroupLayout(pnlEvent);
        pnlEvent.setLayout(pnlEventLayout);
        pnlEventLayout.setHorizontalGroup(
            pnlEventLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEventLayout.createSequentialGroup()
                .add(jLabel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtEvent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );
        pnlEventLayout.setVerticalGroup(
            pnlEventLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEventLayout.createSequentialGroup()
                .add(1, 1, 1)
                .add(pnlEventLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(txtEvent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        org.jdesktop.layout.GroupLayout pnlEvent1Layout = new org.jdesktop.layout.GroupLayout(pnlEvent1);
        pnlEvent1.setLayout(pnlEvent1Layout);
        pnlEvent1Layout.setHorizontalGroup(
            pnlEvent1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlSurname, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlOtherNames, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlEntity, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlSpace, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlPlaceName, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlPlaceLat, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlPlaceLong, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
            .add(pnlEvent, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
        );
        pnlEvent1Layout.setVerticalGroup(
            pnlEvent1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEvent1Layout.createSequentialGroup()
                .add(pnlSurname, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlOtherNames, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlEntity, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlSpace, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlPlaceName, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlPlaceLat, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlPlaceLong, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(5, 5, 5)
                .add(pnlEvent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 16, Short.MAX_VALUE))
        );

        pnlButtons.add(pnlEvent1);

        pnlEvent2.setOpaque(false);
        pnlEvent2.setPreferredSize(new java.awt.Dimension(210, 108));

        jPanel13.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel9.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel9.setOpaque(true);
        jLabel9.setPreferredSize(new java.awt.Dimension(100, 22));

        txtDate.setPreferredSize(new java.awt.Dimension(100, 22));
        txtDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDateFocusLost(evt);
            }
        });
        txtDate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDatekeyTyped(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel13Layout = new org.jdesktop.layout.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel13Layout.createSequentialGroup()
                .add(jLabel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtDate, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(txtDate, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        jPanel14.setPreferredSize(new java.awt.Dimension(210, 23));

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel11.setOpaque(true);
        jLabel11.setPreferredSize(new java.awt.Dimension(100, 22));

        txtTime.setPreferredSize(new java.awt.Dimension(100, 22));
        txtTime.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTimeFocusLost(evt);
            }
        });
        txtTime.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTimeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTimekeyTyped(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel14Layout = new org.jdesktop.layout.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel14Layout.createSequentialGroup()
                .add(jLabel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, 0)
                .add(txtTime, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(txtTime, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        grpTimeKind.add(optLocal);
        optLocal.setSelected(true);
        optLocal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        optLocal.setPreferredSize(new java.awt.Dimension(210, 21));
        optLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optLocalActionPerformed(evt);
            }
        });
        optLocal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                optLocalKeyPressed(evt);
            }
        });

        grpTimeKind.add(optUT);
        optUT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        optUT.setPreferredSize(new java.awt.Dimension(210, 21));
        optUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optUTActionPerformed(evt);
            }
        });
        optUT.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                optUTKeyPressed(evt);
            }
        });

        jPanel9.setPreferredSize(new java.awt.Dimension(230, 22));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnCalcTZ.setFont(new java.awt.Font("Lucida Grande", 0, 12)); // NOI18N
        btnCalcTZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calcr2.png"))); // NOI18N
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        btnCalcTZ.setText(bundle.getString("TimeZoneAndDaylightSavingTime")); // NOI18N
        btnCalcTZ.setPreferredSize(new java.awt.Dimension(230, 26));
        btnCalcTZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcTZActionPerformed(evt);
            }
        });
        btnCalcTZ.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnCalcTZKeyPressed(evt);
            }
        });
        jPanel9.add(btnCalcTZ);

        txtTZ.setPreferredSize(new java.awt.Dimension(100, 22));
        txtTZ.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTZFocusLost(evt);
            }
        });
        txtTZ.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTZkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTZKeyPressed(evt);
            }
        });
        jPanel9.add(txtTZ);

        pnlHelp.setPreferredSize(new java.awt.Dimension(230, 35));
        pnlHelp.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnHelp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/help2.png"))); // NOI18N
        btnHelp.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnHelp.setPreferredSize(new java.awt.Dimension(100, 35));
        btnHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHelpActionPerformed(evt);
            }
        });
        btnHelp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnHelpKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                btnHelpKeyTyped(evt);
            }
        });
        pnlHelp.add(btnHelp);

        jPanel9.add(pnlHelp);

        org.jdesktop.layout.GroupLayout pnlEvent2Layout = new org.jdesktop.layout.GroupLayout(pnlEvent2);
        pnlEvent2.setLayout(pnlEvent2Layout);
        pnlEvent2Layout.setHorizontalGroup(
            pnlEvent2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEvent2Layout.createSequentialGroup()
                .addContainerGap()
                .add(pnlEvent2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(optLocal, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(optUT, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        pnlEvent2Layout.setVerticalGroup(
            pnlEvent2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnlEvent2Layout.createSequentialGroup()
                .add(jPanel13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(optLocal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(optUT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(jPanel9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE))
        );

        pnlButtons.add(pnlEvent2);

        jPanel4.setOpaque(false);
        jPanel4.setLayout(new java.awt.BorderLayout());

        lblDataStats.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblDataStatsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblDataStatsMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblDataStatsMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblDataStatsMouseReleased(evt);
            }
        });
        jPanel4.add(lblDataStats, java.awt.BorderLayout.CENTER);

        lblDataStats2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblDataStats2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDataStats2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblDataStats2.setDoubleBuffered(true);
        lblDataStats2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblDataStats2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDataStats2MouseClicked(evt);
            }
        });
        jPanel4.add(lblDataStats2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel4);

        jPanel11.setOpaque(false);
        pnlButtons.add(jPanel11);

        jPanel5.setOpaque(false);
        jPanel5.setLayout(new java.awt.BorderLayout());

        lblConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblConfigMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblConfigMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblConfigMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblConfigMouseReleased(evt);
            }
        });
        jPanel5.add(lblConfig, java.awt.BorderLayout.CENTER);

        lblConfig2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblConfig2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblConfig2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblConfig2.setDoubleBuffered(true);
        lblConfig2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblConfig2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConfig2MouseClicked(evt);
            }
        });
        jPanel5.add(lblConfig2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel5);

        jPanel6.setOpaque(false);
        jPanel6.setLayout(new java.awt.BorderLayout());

        lblCalcul.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCalculMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCalculMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCalculMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblCalculMouseReleased(evt);
            }
        });
        jPanel6.add(lblCalcul, java.awt.BorderLayout.CENTER);

        lblCalcul2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblCalcul2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCalcul2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblCalcul2.setDoubleBuffered(true);
        lblCalcul2.setPreferredSize(new java.awt.Dimension(10, 50));
        lblCalcul2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCalcul2MouseClicked(evt);
            }
        });
        jPanel6.add(lblCalcul2, java.awt.BorderLayout.SOUTH);

        pnlButtons.add(jPanel6);

        jPanel12.setOpaque(false);
        jPanel12.setLayout(new java.awt.BorderLayout());
        pnlButtons.add(jPanel12);

        getContentPane().add(pnlButtons, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        sortir();
    }//GEN-LAST:event_formWindowClosing

    private void lblConfigMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseEntered
        lblConfig.setIcon(rbkh[4]);
    }//GEN-LAST:event_lblConfigMouseEntered

    private void lblConfigMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseExited
        lblConfig.setIcon(rbkn[4]);
    }//GEN-LAST:event_lblConfigMouseExited

    private void lblConfigMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMousePressed
        lblConfig.setIcon(rbkc[4]);
        if (bConfig)
        {
            MainClass.checkInstance("ConfigForm");
            return;
        }
        OutilsForm of = new OutilsForm(this);
        of.setVisible(true);
        bConfig = true;
    }//GEN-LAST:event_lblConfigMousePressed

    private void lblConfigMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseReleased
        lblConfig.setIcon(rbkh[4]);
    }//GEN-LAST:event_lblConfigMouseReleased

    private void lblDataStatsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDataStatsMouseEntered
        lblDataStats.setIcon(rbkh[3]);
    }//GEN-LAST:event_lblDataStatsMouseEntered

    private void lblDataStatsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDataStatsMouseExited
        lblDataStats.setIcon(rbkn[3]);
    }//GEN-LAST:event_lblDataStatsMouseExited

    private void lblDataStatsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDataStatsMousePressed
        lblDataStats.setIcon(rbkc[3]);
        if (bStats)
        {
            MainClass.checkInstance("StatsForm");
            return;
        }
        StatsReportsForm sf = new StatsReportsForm(this);
        sf.setVisible(true);
        bStats = true;
    }//GEN-LAST:event_lblDataStatsMousePressed

    private void lblDataStatsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDataStatsMouseReleased
        lblDataStats.setIcon(rbkh[3]);
    }//GEN-LAST:event_lblDataStatsMouseReleased

    private void lblCartesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCartesMouseEntered
        lblCartes.setIcon(rbkh[2]);
    }//GEN-LAST:event_lblCartesMouseEntered

    private void lblCartesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCartesMouseExited
        lblCartes.setIcon(rbkn[2]);
    }//GEN-LAST:event_lblCartesMouseExited

    private void lblCartesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCartesMousePressed
        testDiff();
        lblCartes.setIcon(rbkc[2]);
        if (bCartes)
        {
            MainClass.checkInstance("ChartChoiceForm");
            return;
        }
        ChartChoiceForm ccf = new ChartChoiceForm(this);
        ccf.setVisible(true);
        bCartes = true;
    }//GEN-LAST:event_lblCartesMousePressed

    private void lblCartesMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCartesMouseReleased
        lblCartes.setIcon(rbkh[2]);
    }//GEN-LAST:event_lblCartesMouseReleased

    private void lblEventsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEventsMouseEntered
        lblEvents.setIcon(rbkh[1]);
    }//GEN-LAST:event_lblEventsMouseEntered

    private void lblEventsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEventsMouseExited
        lblEvents.setIcon(rbkn[1]);
    }//GEN-LAST:event_lblEventsMouseExited

    public void setChoix(int choix)
    {
        choixAction = choix;
    }
    
    private void testDiff()
    {
        if (currentEvent == null)
            return;
        txtSurnameFocusLost(null);
        txtOtherNamesFocusLost(null);
        txtEventFocusLost(null);
        txtEntityTypeFocusLost(null);
        txtDateFocusLost(null);
        txtTimeFocusLost(null);
        txtLatitudeFocusLost(null);
        txtLongitudeFocusLost(null);
        txtPlaceFocusLost(null);
        txtTZFocusLost(null);
        if (bDataModif)
        {
            DlgAskToSaveEvent dase = new DlgAskToSaveEvent(this, true);
            switch (choixAction)
            {
                case 1:
                    currentEvent.setAdding(false);
                    starLoginManager.setEvent(currentEvent);
                    saveCurrentEvent = currentEvent.cloneEvent(currentEvent);
                    break;
                    
                case 2:
                    currentEvent.setAdding(true);
                    starLoginManager.setEvent(currentEvent);
                    saveCurrentEvent = currentEvent.cloneEvent(currentEvent);
                    break;
                    
                default:
            }
            bDataModif = false;
        }
    }
    
    private void lblEventsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEventsMousePressed
        testDiff();
        if (currentEvent == null)
            return;
        currentEvent.setLocalDate(localDate);
        currentEvent.setLocalTime(localTime);
        currentEvent.setUtDate(utDate);
        currentEvent.setUtTime(utTime);
        ListeEventForm lef = new ListeEventForm(this, true, eventID);
    }//GEN-LAST:event_lblEventsMousePressed

    private void lblEventsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEventsMouseReleased
        lblEvents.setIcon(rbkh[1]);
    }//GEN-LAST:event_lblEventsMouseReleased

    private void lblOrganizerMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOrganizerMouseEntered
        lblOrganizer.setIcon(rbkh[0]);
    }//GEN-LAST:event_lblOrganizerMouseEntered

    private void lblOrganizerMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOrganizerMouseExited
        lblOrganizer.setIcon(rbkn[0]);
    }//GEN-LAST:event_lblOrganizerMouseExited

    private void lblOrganizerMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOrganizerMousePressed
        lblOrganizer.setIcon(rbkc[0]);
        if (bOrganizer)
        {
            MainClass.checkInstance("OrganizerForm");
            return;
        }
        OrganizerForm of = new OrganizerForm(this);
        bOrganizer = true;
        of.setVisible(true);
    }//GEN-LAST:event_lblOrganizerMousePressed

    private void lblOrganizerMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOrganizerMouseReleased
        lblOrganizer.setIcon(rbkh[0]);
    }//GEN-LAST:event_lblOrganizerMouseReleased

    private void lblCalculMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCalculMouseEntered
        lblCalcul.setIcon(rbkh[5]);
    }//GEN-LAST:event_lblCalculMouseEntered

    private void lblCalculMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCalculMouseExited
        lblCalcul.setIcon(rbkn[5]);
    }//GEN-LAST:event_lblCalculMouseExited

    private void lblCalculMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCalculMousePressed
        testDiff();
        if (currentEvent == null)
            return;
        lblCalcul.setIcon(rbkc[5]);
        if (bCalcul)
        {
            MainClass.checkInstance("VariousCalcForm");
            return;
        }
        currentEvent.setLocalDate(localDate);
        currentEvent.setLocalTime(localTime);
        currentEvent.setUtDate(utDate);
        currentEvent.setUtTime(utTime);
        new VariousCalcForm(this).setVisible(true);
        bCalcul = true;
    }//GEN-LAST:event_lblCalculMousePressed

    private void lblCalculMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCalculMouseReleased
        lblCalcul.setIcon(rbkh[5]);
    }//GEN-LAST:event_lblCalculMouseReleased

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        if (bkh[0] != null)
            rbkh[0] = new ImageIcon(bkh[0].getImage().getScaledInstance(lblOrganizer.getWidth(), lblOrganizer.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[0] != null)
            rbkn[0] = new ImageIcon(bkn[0].getImage().getScaledInstance(lblOrganizer.getWidth(), lblOrganizer.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[0] != null)
            rbkc[0] = new ImageIcon(bkc[0].getImage().getScaledInstance(lblOrganizer.getWidth(), lblOrganizer.getHeight(), Image.SCALE_SMOOTH));
        //lblEvents.paintAll(lblEvents.getGraphics());
        if (bkh[1] != null)
            rbkh[1] = new ImageIcon(bkh[1].getImage().getScaledInstance(lblEvents.getWidth(), lblEvents.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[1] != null)
            rbkn[1] = new ImageIcon(bkn[1].getImage().getScaledInstance(lblEvents.getWidth(), lblEvents.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[1] != null)
            rbkc[1] = new ImageIcon(bkc[1].getImage().getScaledInstance(lblEvents.getWidth(), lblEvents.getHeight(), Image.SCALE_SMOOTH));
        //lblEvents.paintAll(lblEvents.getGraphics());
        if (bkh[2] != null)
            rbkh[2] = new ImageIcon(bkh[2].getImage().getScaledInstance(lblCartes.getWidth(), lblCartes.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[2] != null)
            rbkn[2] = new ImageIcon(bkn[2].getImage().getScaledInstance(lblCartes.getWidth(), lblCartes.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[2] != null)
            rbkc[2] = new ImageIcon(bkc[2].getImage().getScaledInstance(lblCartes.getWidth(), lblCartes.getHeight(), Image.SCALE_SMOOTH));
        //lblCartes.paintAll(lblCartes.getGraphics());
        if (bkh[3] != null)
            rbkh[3] = new ImageIcon(bkh[3].getImage().getScaledInstance(lblDataStats.getWidth(), lblDataStats.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[3] != null)
            rbkn[3] = new ImageIcon(bkn[3].getImage().getScaledInstance(lblDataStats.getWidth(), lblDataStats.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[3] != null)
            rbkc[3] = new ImageIcon(bkc[3].getImage().getScaledInstance(lblDataStats.getWidth(), lblDataStats.getHeight(), Image.SCALE_SMOOTH));
        //lblDataStats.paintAll(lblDataStats.getGraphics());
        if (bkh[4] != null)
            rbkh[4] = new ImageIcon(bkh[4].getImage().getScaledInstance(lblConfig.getWidth(), lblConfig.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[4] != null)
            rbkn[4] = new ImageIcon(bkn[4].getImage().getScaledInstance(lblConfig.getWidth(), lblConfig.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[4] != null)
            rbkc[4] = new ImageIcon(bkc[4].getImage().getScaledInstance(lblConfig.getWidth(), lblConfig.getHeight(), Image.SCALE_SMOOTH));
        //lblConfig.paintAll(lblConfig.getGraphics());
        if (bkh[5] != null)
            rbkh[5] = new ImageIcon(bkh[5].getImage().getScaledInstance(lblCalcul.getWidth(), lblCalcul.getHeight(), Image.SCALE_SMOOTH));
        if (bkn[5] != null)
            rbkn[5] = new ImageIcon(bkn[5].getImage().getScaledInstance(lblCalcul.getWidth(), lblCalcul.getHeight(), Image.SCALE_SMOOTH));
        if (bkc[5] != null)
            rbkc[5] = new ImageIcon(bkc[5].getImage().getScaledInstance(lblCalcul.getWidth(), lblCalcul.getHeight(), Image.SCALE_SMOOTH));
        //lblCalcul.paintAll(lblCalcul.getGraphics());
        lblOrganizer.setIcon(rbkn[0]);
        lblEvents.setIcon(rbkn[1]);
        lblCartes.setIcon(rbkn[2]);
        lblDataStats.setIcon(rbkn[3]);
        lblConfig.setIcon(rbkn[4]);
        lblCalcul.setIcon(rbkn[5]);
    }//GEN-LAST:event_formComponentResized

    private void lblOrganizer2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblOrganizer2MouseClicked
    {//GEN-HEADEREND:event_lblOrganizer2MouseClicked
        lblOrganizerMousePressed(null);
    }//GEN-LAST:event_lblOrganizer2MouseClicked

    private void lblEvents2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblEvents2MouseClicked
    {//GEN-HEADEREND:event_lblEvents2MouseClicked
        lblEventsMousePressed(null);
    }//GEN-LAST:event_lblEvents2MouseClicked

    private void lblCartes2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblCartes2MouseClicked
    {//GEN-HEADEREND:event_lblCartes2MouseClicked
        lblCartesMousePressed(null);
    }//GEN-LAST:event_lblCartes2MouseClicked

    private void lblDataStats2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblDataStats2MouseClicked
    {//GEN-HEADEREND:event_lblDataStats2MouseClicked
        lblDataStatsMousePressed(null);
    }//GEN-LAST:event_lblDataStats2MouseClicked

    private void lblCalcul2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblCalcul2MouseClicked
    {//GEN-HEADEREND:event_lblCalcul2MouseClicked
        lblCalculMousePressed(null);
    }//GEN-LAST:event_lblCalcul2MouseClicked

    private void lblConfig2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblConfig2MouseClicked
    {//GEN-HEADEREND:event_lblConfig2MouseClicked
        lblConfigMousePressed(null);
    }//GEN-LAST:event_lblConfig2MouseClicked

    private void txtLatitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudeFocusLost
    {//GEN-HEADEREND:event_txtLatitudeFocusLost
        FLatitude l = new FLatitude(txtLatitude.getText());
        String sText = l.getLatitude();
        txtLatitude.setText(sText);
        latitude = sText;
        if (currentEvent == null)
            return;
        currentEvent.setLatitude(latitude);
        if (!saveCurrentEvent.getLatitude().equals(latitude))
            bDataModif = true;
    }//GEN-LAST:event_txtLatitudeFocusLost

    private void txtLatitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudekeyTyped
    {//GEN-HEADEREND:event_txtLatitudekeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitude.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudekeyTyped

    private void txtLatitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeKeyPressed
    {//GEN-HEADEREND:event_txtLatitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitude.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLatitude.setText(latitude);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLatitude, kc);
        }
    }//GEN-LAST:event_txtLatitudeKeyPressed

    private void txtLongitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeFocusLost
    {//GEN-HEADEREND:event_txtLongitudeFocusLost
        FLongitude l = new FLongitude(txtLongitude.getText());
        String sText = l.getLongitude();
        txtLongitude.setText(sText);
        longitude = sText;
        if (currentEvent == null)
            return;
        currentEvent.setLongitude(longitude);
        if (!saveCurrentEvent.getLongitude().equals(longitude))
            bDataModif = true;
    }//GEN-LAST:event_txtLongitudeFocusLost

    private void txtLongitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudekeyTyped
    {//GEN-HEADEREND:event_txtLongitudekeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitude.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudekeyTyped

    private void txtLongitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitude.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitude.setText(longitude);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
        else
        {
            KTLongitude lng;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lng = new KTLongitude(evt, txtLongitude, kc);
        }
    }//GEN-LAST:event_txtLongitudeKeyPressed

    private void txtDateFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateFocusLost
    {//GEN-HEADEREND:event_txtDateFocusLost
        String sText = txtDate.getText();
        sText = MainClass.getFormatedDate(sText);
        txtDate.setText(sText);
        if (currentEvent == null)
            return;
        if (optLocal.isSelected())
        {
            localDate = sText;
            currentEvent.setLocalDate(sText);
            if (!saveCurrentEvent.getLocalDate().equals(localDate))
                bDataModif = true;
        }
        else
            
        {
            utDate = sText;
            currentEvent.setUtDate(sText);
            if (!saveCurrentEvent.getUtDate().equals(utDate))
                bDataModif = true;
        }
        if (bDataModif)
            btnCalcTZActionPerformed(null);
    }//GEN-LAST:event_txtDateFocusLost

    private void txtDatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDatekeyTyped
    {//GEN-HEADEREND:event_txtDatekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDate, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDate.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDatekeyTyped

    private void txtDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateKeyPressed
    {//GEN-HEADEREND:event_txtDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDate.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            if (optLocal.isSelected())
            {
                txtDate.setText(localDate);
            }
            else
            {
                txtDate.setText(utDate);
            }
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
        else
        {
            KTDateAstro td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDateAstro(evt, txtDate, kc);
        }
    }//GEN-LAST:event_txtDateKeyPressed

    private void txtTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTimeFocusLost
    {//GEN-HEADEREND:event_txtTimeFocusLost
        FTime t = new FTime(txtTime.getText());
        String sText = t.getTime();
        txtTime.setText(sText);
        if (currentEvent == null)
            return;
        if (optLocal.isSelected())
        {
            localTime = sText;
            currentEvent.setLocalTime(sText);
            if (!saveCurrentEvent.getLocalTime().equals(localTime))
                bDataModif = true;
        }
        else
        {
            utTime = sText;
            currentEvent.setUtTime(sText);
            if (!saveCurrentEvent.getUtTime().equals(utTime))
                bDataModif = true;
        }
        if (bDataModif)
            btnCalcTZActionPerformed(null);
    }//GEN-LAST:event_txtTimeFocusLost

    private void txtTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimekeyTyped
    {//GEN-HEADEREND:event_txtTimekeyTyped
        KTTime ti = new KTTime(evt, txtTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTimekeyTyped

    private void txtTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimeKeyPressed
    {//GEN-HEADEREND:event_txtTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtTime.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            if (optLocal.isSelected())
            {
                txtTime.setText(localTime);
            }
            else
            {
                txtTime.setText(utTime);
            }
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
        else
        {
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtTime, kc);
        }
    }//GEN-LAST:event_txtTimeKeyPressed

    private void txtSurnameMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtSurnameMouseClicked
    {//GEN-HEADEREND:event_txtSurnameMouseClicked
        if (evt.getClickCount() == 2)
        {
            //txtSurname.setText("");
            String strText = MainClass.getLookForField(txtSurname, "events", "SURNAME", bundle.getString("eventsSURNAME"), false, null, false, null, true);
            txtSurname.setText(strText);
        }
    }//GEN-LAST:event_txtSurnameMouseClicked

    private void txtOtherNamesMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtOtherNamesMouseClicked
    {//GEN-HEADEREND:event_txtOtherNamesMouseClicked
        if (evt.getClickCount() == 2)
        {
            //txtOtherNames.setText("");
            String strText = MainClass.getLookForField(txtOtherNames, "events", "OTHERNAMES", bundle.getString("eventsOTHERNAMES"), false, null, false, null, true);
            txtOtherNames.setText(strText);
        }
    }//GEN-LAST:event_txtOtherNamesMouseClicked

    private void txtEntityTypeMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtEntityTypeMouseClicked
    {//GEN-HEADEREND:event_txtEntityTypeMouseClicked
        if (evt.getClickCount() == 2)
        {
            //txtEntityType.setText("");
            String strText = MainClass.getLookForField(txtEntityType, "events", "ENTITYTYPE", bundle.getString("eventsENTITYTYPE"), false, null, false, null, true);
            txtEntityType.setText(strText);
        }
    }//GEN-LAST:event_txtEntityTypeMouseClicked

    private void txtPlaceMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtPlaceMouseClicked
    {//GEN-HEADEREND:event_txtPlaceMouseClicked
        if (evt.getClickCount() == 2)
        {
            //txtPlace.setText("");
            String strText = MainClass.getLookForField(txtPlace, "places", "PLACENAME", bundle.getString("placesPLACENAME"), false, null, false, null, true);
            txtPlace.setText(strText);
            
            if (currentEvent == null)
                return;
            if (!strText.equals(""))
            {
                String id = starLoginManager.getMainFieldID_S("places", "PLACENAME", strText);
                if (!id.equals("-1") && !id.equals(""))
                {
                    strText = starLoginManager.getStringFieldValue("places", "PLACENAME", " WHERE ID=" + id);
                    //place = strText;
                    currentEvent.setPlace(strText);
                    txtPlace.setText(strText);
                    strText = starLoginManager.getStringFieldValue("places", "PLACELATITUDE", " WHERE ID=" + id);
                    FLatitude l = new FLatitude(strText);
                    latitude = l.getLatitude();
                    txtLatitude.setText(latitude);
                    strText = starLoginManager.getStringFieldValue("places", "PLACELONGITUDE", " WHERE ID=" + id);
                    FLongitude lo = new FLongitude(strText);
                    longitude = lo.getLongitude();
                    txtLongitude.setText(longitude);
                    currentEvent.setLatitude(latitude);
                    currentEvent.setLongitude(longitude);
                }
            }
            else
                txtPlace.setText(place);
        }
    }//GEN-LAST:event_txtPlaceMouseClicked

    private void txtEventMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtEventMouseClicked
    {//GEN-HEADEREND:event_txtEventMouseClicked
        if (evt.getClickCount() == 2)
        {
            //txtEvent.setText("");
            String strText = MainClass.getLookForField(txtEvent, "events", "EVENTTYPE", bundle.getString("eventsEVENTTYPE"), false, null, false, null, true);
            txtEvent.setText(strText);
        }
    }//GEN-LAST:event_txtEventMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowActivated
    {//GEN-HEADEREND:event_formWindowActivated
        formComponentResized(null);
    }//GEN-LAST:event_formWindowActivated

    private void btnCalcTZActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCalcTZActionPerformed
    {//GEN-HEADEREND:event_btnCalcTZActionPerformed
        changeTime(TZRules.FirstTime);
        changeTime(TZRules.SecondTime);
    }//GEN-LAST:event_btnCalcTZActionPerformed

    
    private void changeTime(byte intCall)
    {
        if (currentEvent == null)
            return;
        currentEvent.setLatitude(txtLatitude.getText());
        currentEvent.setLongitude(txtLongitude.getText());
        currentEvent.setPlace(txtPlace.getText());
        if ( optLocal.isSelected() == true )
        {
            currentEvent.setLocalDate(txtDate.getText());
            currentEvent.setLocalTime(txtTime.getText());
            currentEvent.utTimeCalculation(intCall);
            utDate = currentEvent.getUtDate();
            utTime = currentEvent.getUtTime();
        }
        else
        {
            currentEvent.setUtDate(txtDate.getText());
            currentEvent.setUtTime(txtTime.getText());
            currentEvent.localTimeCalculation(intCall);
            localDate = currentEvent.getLocalDate();
            localTime = currentEvent.getLocalTime();
        }
        tz = currentEvent.getTimeLag();
        txtTZ.setText(tz);
        currentEvent.setTimeLag(tz);
        
        if (intCall == TZRules.SecondTime)
        {
            localDate = currentEvent.getLocalDate();
            utDate = currentEvent.getUtDate();
            localTime = currentEvent.getLocalTime();
            utTime = currentEvent.getUtTime();
            tz = currentEvent.getTimeLag();
            place = currentEvent.getPlace();
            latitude = currentEvent.getLatitude();
            longitude = currentEvent.getLongitude();
            oldlatitude = latitude;
            oldlongitude = longitude;
        }
        localDate = MainClass.getFormatedDate(localDate);
        localTime = MainClass.getFormatedTime(localTime);
        utDate = MainClass.getFormatedDate(utDate);
        utTime = MainClass.getFormatedTime(utTime);
    }
    
    private void txtTZFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTZFocusLost
    {//GEN-HEADEREND:event_txtTZFocusLost
        tz = txtTZ.getText();
        if (tz.equals(""))
        {
            tz = "0.0";
            txtTZ.setText(tz);
        }
        /*if (tz.equals(""))
        {
            return;
        }*/
        double value = new Double(tz).doubleValue();

        //The value must be between -24 and 24
        if (value < -24.0)
        {
            tz = "-24";
            txtTZ.setText(tz);
        }
        else if (value > 24.0)
        {
            tz = "24";
            txtTZ.setText(tz);
        }
        if (currentEvent == null)
            return;
        currentEvent.setTimeLag(tz);
        if (!saveCurrentEvent.getTimeLag().equals(tz))
            bDataModif = true;
    }//GEN-LAST:event_txtTZFocusLost

    private void txtTZkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZkeyTyped
    {//GEN-HEADEREND:event_txtTZkeyTyped
        KTDecimal d = new KTDecimal(evt, txtTZ, 8, kc);
    }//GEN-LAST:event_txtTZkeyTyped

    private void txtTZKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZKeyPressed
    {//GEN-HEADEREND:event_txtTZKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtTZ.setText(tz);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtTZKeyPressed

    private void txtSurnameKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSurnameKeyPressed
    {//GEN-HEADEREND:event_txtSurnameKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtSurname.setText(surname);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtSurnameKeyPressed

    private void txtOtherNamesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherNamesKeyPressed
    {//GEN-HEADEREND:event_txtOtherNamesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtOtherNames.setText(otherNames);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtOtherNamesKeyPressed

    private void txtEntityTypeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEntityTypeKeyPressed
    {//GEN-HEADEREND:event_txtEntityTypeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtEntityType.setText(entityType);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtEntityTypeKeyPressed

    private void txtPlaceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceKeyPressed
    {//GEN-HEADEREND:event_txtPlaceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPlace.setText(place);
            txtLatitude.setText(oldlatitude);
            txtLongitude.setText(oldlongitude);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtPlaceKeyPressed

    private void txtEventKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEventKeyPressed
    {//GEN-HEADEREND:event_txtEventKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtEvent.setText(eventName);
        }
        else if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_txtEventKeyPressed

    private void txtSurnameFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtSurnameFocusLost
    {//GEN-HEADEREND:event_txtSurnameFocusLost
        surname = txtSurname.getText();
        if (currentEvent == null)
            return;
        currentEvent.setSurname(surname);
        if (saveCurrentEvent.getSurname()!= null && !saveCurrentEvent.getSurname().equals(surname))
            bDataModif = true;
    }//GEN-LAST:event_txtSurnameFocusLost

    private void txtOtherNamesFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtOtherNamesFocusLost
    {//GEN-HEADEREND:event_txtOtherNamesFocusLost
        otherNames = txtOtherNames.getText();
        if (currentEvent == null)
            return;
        currentEvent.setOtherNames(otherNames);
        if (saveCurrentEvent.getOtherNames()!= null && !saveCurrentEvent.getOtherNames().equals(otherNames))
            bDataModif = true;
    }//GEN-LAST:event_txtOtherNamesFocusLost

    private void txtEntityTypeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEntityTypeFocusLost
    {//GEN-HEADEREND:event_txtEntityTypeFocusLost
        entityType = txtEntityType.getText();
        if (currentEvent == null)
            return;
        currentEvent.setEntityType(entityType);
        if (saveCurrentEvent.getEntityType()!= null && !saveCurrentEvent.getEntityType().equals(entityType))
            bDataModif = true;
    }//GEN-LAST:event_txtEntityTypeFocusLost

    private void txtPlaceFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtPlaceFocusLost
    {//GEN-HEADEREND:event_txtPlaceFocusLost
        place = txtPlace.getText();
        if (currentEvent == null)
            return;
        currentEvent.setPlace(place);
        if (saveCurrentEvent.getPlace()!=null && !saveCurrentEvent.getPlace().equals(place))
            bDataModif = true;
    }//GEN-LAST:event_txtPlaceFocusLost

    private void txtEventFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEventFocusLost
    {//GEN-HEADEREND:event_txtEventFocusLost
        eventName = txtEvent.getText();
        if (currentEvent == null)
            return;
        currentEvent.setEventName(eventName);
        if (saveCurrentEvent.getEventName()!=null && !saveCurrentEvent.getEventName().equals(eventName))
            bDataModif = true;
    }//GEN-LAST:event_txtEventFocusLost

    private void optLocalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optLocalActionPerformed
    {//GEN-HEADEREND:event_optLocalActionPerformed
        txtDate.setText(localDate);
        txtTime.setText(localTime);
        //txtTimeFocusLost(null);
        //txtDateFocusLost(null);
    }//GEN-LAST:event_optLocalActionPerformed

    private void optUTActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optUTActionPerformed
    {//GEN-HEADEREND:event_optUTActionPerformed
        txtDate.setText(utDate);
        txtTime.setText(utTime);
        //txtTimeFocusLost(null);
        //txtDateFocusLost(null);
    }//GEN-LAST:event_optUTActionPerformed

    private void optLocalKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_optLocalKeyPressed
    {//GEN-HEADEREND:event_optLocalKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_optLocalKeyPressed

    private void optUTKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_optUTKeyPressed
    {//GEN-HEADEREND:event_optUTKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_optUTKeyPressed

    private void btnCalcTZKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_btnCalcTZKeyPressed
    {//GEN-HEADEREND:event_btnCalcTZKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_F1)
            runHelp();
    }//GEN-LAST:event_btnCalcTZKeyPressed

    private void btnHelpActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnHelpActionPerformed
    {//GEN-HEADEREND:event_btnHelpActionPerformed
        StarLogin.Systeme.Enum.OS.runExplorer("starlogin/".concat(MainClass.langue).concat("/presentation.html"));
    }//GEN-LAST:event_btnHelpActionPerformed

    private void btnHelpKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_btnHelpKeyPressed
    {//GEN-HEADEREND:event_btnHelpKeyPressed
        kc = evt.getKeyCode();
        if ((evt.getModifiersEx() & (KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK)) == (KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK) && kc == KeyEvent.VK_D)
        {
            DlgQuery dlgq = new DlgQuery(this, true);
        }
    }//GEN-LAST:event_btnHelpKeyPressed

    private void btnHelpKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_btnHelpKeyTyped
    {//GEN-HEADEREND:event_btnHelpKeyTyped
        if ((evt.getModifiersEx() & (KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK)) == (KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK) && kc == KeyEvent.VK_D)
        {
            DlgQuery dlgq = new DlgQuery(this, true);
        }
    }//GEN-LAST:event_btnHelpKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcTZ;
    private javax.swing.JButton btnHelp;
    private javax.swing.ButtonGroup grpTimeKind;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblCalcul;
    private javax.swing.JLabel lblCalcul2;
    private javax.swing.JLabel lblCartes;
    private javax.swing.JLabel lblCartes2;
    private javax.swing.JLabel lblConfig;
    private javax.swing.JLabel lblConfig2;
    private javax.swing.JLabel lblDataStats;
    private javax.swing.JLabel lblDataStats2;
    private javax.swing.JLabel lblEvents;
    private javax.swing.JLabel lblEvents2;
    private javax.swing.JLabel lblLatitude;
    private javax.swing.JLabel lblLongitude;
    private javax.swing.JLabel lblOrganizer;
    private javax.swing.JLabel lblOrganizer2;
    private javax.swing.JRadioButton optLocal;
    private javax.swing.JRadioButton optUT;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlEntity;
    private javax.swing.JPanel pnlEvent;
    private javax.swing.JPanel pnlEvent1;
    private javax.swing.JPanel pnlEvent2;
    private javax.swing.JPanel pnlHelp;
    private javax.swing.JPanel pnlOtherNames;
    private javax.swing.JPanel pnlPlaceLat;
    private javax.swing.JPanel pnlPlaceLong;
    private javax.swing.JPanel pnlPlaceName;
    private javax.swing.JPanel pnlSpace;
    private javax.swing.JPanel pnlSurname;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtEntityType;
    private javax.swing.JTextField txtEvent;
    private javax.swing.JTextField txtLatitude;
    private javax.swing.JTextField txtLongitude;
    private javax.swing.JTextField txtOtherNames;
    private javax.swing.JTextField txtPlace;
    private javax.swing.JTextField txtSurname;
    private javax.swing.JTextField txtTZ;
    private javax.swing.JTextField txtTime;
    // End of variables declaration//GEN-END:variables
}
