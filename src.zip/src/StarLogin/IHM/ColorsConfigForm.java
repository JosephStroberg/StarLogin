/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ColorsConfigForm.java
 *
 * Created on 2011-05-09, 09:09:17
 */
package StarLogin.IHM;

import StarLogin.IHM.components.Options;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 *
 * @author Francois
 */
public class ColorsConfigForm extends javax.swing.JFrame
{
    private Color color;
    private final java.util.ResourceBundle bundle = MainClass.bundle;
    private final ColorsConfigForm current = this;
    private final Window parentForm;
    private DataGrid dgrDetails;
    private final Records cdetails;
    private final StarLogin.StarLoginManager starLoginManager = MainClass.starLoginManager;

    /** Creates new form ColorsConfigForm
     * @param parent */
    public ColorsConfigForm(JFrame parent)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        cdetails = starLoginManager.getRecords("SELECT ID, COMPONENT, PROPERTY, VALEUR FROM option_", "option_");
        parentForm = parent;
        resetUI();
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    private void resetUI()
    {
        getContentPane().removeAll();
        initComponents();
        
        dgrDetails = new DataGrid(cdetails.getRecords(), cdetails.getHeaders(), cdetails.getFields(), cdetails.getSizes(), pnlGrid, false, false, false, false, this, true, 40);
        dgrDetails.setSelectedRow(1);
        getColorData();
        resetLangue();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/config_colors.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("ConfigurationCouleurs"));
        lblEtiquette.setText(bundle.getString("Etiquette"));
        lblEtiquetteO.setText(bundle.getString("EtiquetteSaisieObligatoire"));
        txtSaisie.setText(bundle.getString("ZoneSaisie"));
        txtSaisieO.setText(bundle.getString("ZoneSaisieObligatoire"));
        txtSaisieBloque.setText(bundle.getString("ZoneSaisieBloquee"));
        btnBouton.setText(bundle.getString("Bouton"));
        btnBoutonInactif.setText(bundle.getString("BoutonInactif"));
        btnMenu.setText(bundle.getString("Menu"));
        lblDivers.setText(bundle.getString("Divers"));
        lblWarning.setText(bundle.getString("Avertissement"));
        lblSelection.setText(bundle.getString("CaseGrilleSelectionnee"));
        jLabel11.setText(bundle.getString("Colors"));
        lblFondEtiquette.setText(bundle.getString("FondLabel"));
        lblColorFE.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceEtiquette.setText(bundle.getString("TexteLabel"));
        lblColorPE.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondEtiquetteObligatoire.setText(bundle.getString("FondEtiquetteObligatoire"));
        lblColorFEO.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceEtiquetteObligatoire.setText(bundle.getString("TexteEtiquetteObligatoire"));
        lblColorPEO.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondTexte.setText(bundle.getString("FondSaisie"));
        lblColorFT.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceTexte.setText(bundle.getString("PoliceSaisie"));
        lblColorPT.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondTexteObligatoire.setText(bundle.getString("FondSaisieObligatoire"));
        lblColorFTO.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceTexteObligatoire.setText(bundle.getString("TexteSaisieObligatoire"));
        lblColorPTO.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondTexteBloque.setText(bundle.getString("FondSaisieBloque"));
        lblColorFTexteBloque.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceTexteBloque.setText(bundle.getString("PoliceSaisieBloque"));
        lblColorPTexteBloque.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondBoutons.setText(bundle.getString("FondBouton"));
        lblColorFB.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceBoutons.setText(bundle.getString("TexteBouton"));
        lblColorPB.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPBoutonsInactifs.setText(bundle.getString("TexteBoutonInactif"));
        lblColorPBoutonsInactifs.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondTableau.setText(bundle.getString("TitreTableau"));
        lblColorHeaderTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblHeaderTableau.setText(bundle.getString("FondNumerosTableau"));
        lblColorFondTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceHeaderTableau.setText(bundle.getString("TexteNumerosTableau"));
        lblColorPoliceHeaderTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblGrilleTableau.setText(bundle.getString("GrilleTableau"));
        lblColorGrilleTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondLigneImpaireTableau.setText(bundle.getString("FondImpairesTableau"));
        lblColorFondLigneImpaireTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceLigneImpaireTableau.setText(bundle.getString("PoliceImpairesTableau"));
        lblColorPoliceLigneImpaireTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondLignePaireTableau.setText(bundle.getString("FondPairesTableau"));
        lblColorFondLignePaireTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceLignePaireTableau.setText(bundle.getString("PolicePairesTableau"));
        lblColorPoliceLignePaireTableau.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblBKTableauSelect.setText(bundle.getString("FondSelectTableau"));
        lblColorBKTableauSelect.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFGTableauSelect.setText(bundle.getString("PoliceSelectTableau"));
        lblColorFGTableauSelect.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondMenu.setText(bundle.getString("FondMenu"));
        lblColorFondMenu.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceMenu.setText(bundle.getString("TexteMenu"));
        lblColorPoliceMenu.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondAutres.setText(bundle.getString("FondAutres"));
        lblColorFondAutres.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceAutres.setText(bundle.getString("TexteAutres")); // NOI18
        lblColorPoliceAutres.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondEtiquetteWarning.setText(bundle.getString("FondWarning"));
        lblColorFEWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFEWarning.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceEtiquetteWarning.setText(bundle.getString("TexteWarning"));
        lblColorPEWarning.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblCouleurSelection.setText(bundle.getString("FondSelect"));
        lblColorSelection.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblPoliceSelection.setText(bundle.getString("PoliceSelect"));
        lblColorPoliceSelection.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblFondZonePhoto.setText(bundle.getString("FondPhoto"));
        lblColorFondZonePhoto.setToolTipText(bundle.getString("Click2ModifyColor"));
        lblRDVFondEtat.setText(bundle.getString("RDVEtatCouleurFond"));
    }

    private void getColorData()
    {
        lblColorFE.setBackground(Options.getColor("Label.background"));
        lblColorPE.setBackground(Options.getColor("Label.foreground"));
        lblColorFEO.setBackground(Options.getColor("EtiquetteObligatoire.background"));
        lblColorPEO.setBackground(Options.getColor("EtiquetteObligatoire.foreground"));
        lblColorFT.setBackground(Options.getColor("TextField.background"));
        lblColorFTO.setBackground(Options.getColor("SaisieObligatoire.background"));
        lblColorPT.setBackground(Options.getColor("TextField.foreground"));
        lblColorPTO.setBackground(Options.getColor("SaisieObligatoire.foreground"));
        lblColorFB.setBackground(Options.getColor("Button.background"));
        lblColorPB.setBackground(Options.getColor("Button.foreground"));
        lblColorFondAutres.setBackground(Options.getColor("Panel.background"));
        lblColorPoliceAutres.setBackground(Options.getColor("Panel.foreground"));
        lblColorHeaderTableau.setBackground(Options.getColor("TableHeader.background"));
        lblColorPoliceHeaderTableau.setBackground(Options.getColor("TableHeader.foreground"));
        lblColorFondTableau.setBackground(Options.getColor("Table.background"));
        lblColorGrilleTableau.setBackground(Options.getColor("Table.gridColor"));
        lblColorFondLigneImpaireTableau.setBackground(Options.getColor("LigneImpaire.background"));
        lblColorFondLignePaireTableau.setBackground(Options.getColor("LignePaire.background"));
        lblColorPoliceLigneImpaireTableau.setBackground(Options.getColor("LigneImpaire.foreground"));
        lblColorPoliceLignePaireTableau.setBackground(Options.getColor("LignePaire.foreground"));
        lblColorFondMenu.setBackground(Options.getColor("Menu.background"));
        lblColorPoliceMenu.setBackground(Options.getColor("Menu.foreground"));
        lblColorSelection.setBackground(Options.getColor("TextField.selectionBackground"));
        lblColorPoliceSelection.setBackground(Options.getColor("TextField.selectionForeground"));
        lblColorFEWarning.setBackground(Options.getColor("Warning.background"));
        lblColorPEWarning.setBackground(Options.getColor("Warning.foreground"));
        lblColorFondZonePhoto.setBackground(Options.photobackground);
        lblColorFTexteBloque.setBackground(Options.getColor("TextField.inactiveBackground"));
        lblColorPTexteBloque.setBackground(Options.getColor("TextField.inactiveForeground"));
        lblColorPBoutonsInactifs.setBackground(Options.getColor("Button.disabledText"));
        lblColorBKTableauSelect.setBackground(Options.getColor("Table.selectionBackground"));
        lblColorFGTableauSelect.setBackground(Options.getColor("Table.selectionForeground"));
        lblColorPoliceSelection.setBackground(Options.getColor("TextField.selectionForeground"));
        lblColorSelection.setBackground(Options.getColor("TextField.selectionBackground"));
        setOtherElements();
        String etatfond = MainClass.starLoginManager.getStringFieldValue("option_", "VALEUR", " WHERE WINDOW_='RDV' AND PROPERTY='ETATFOND'");
        if (etatfond.equals("1"))
            chkRDVFondEtat.setSelected(true);
        else
            chkRDVFondEtat.setSelected(false);
    }

    private void setOtherElements()
    {
        lblEtiquette.setBackground(lblColorFE.getBackground());
        lblEtiquette.setForeground(lblColorPE.getBackground());
        lblEtiquetteO.setBackground(lblColorFEO.getBackground());
        lblEtiquetteO.setForeground(lblColorPEO.getBackground());
        txtSaisie.setBackground(lblColorFT.getBackground());
        txtSaisie.setForeground(lblColorPT.getBackground());
        txtSaisieO.setBackground(lblColorFTO.getBackground());
        txtSaisieO.setForeground(lblColorPTO.getBackground());
        btnBouton.setBackground(lblColorFB.getBackground());
        btnBouton.setForeground(lblColorPB.getBackground());
        btnMenu.setBackground(lblColorFondMenu.getBackground());
        btnMenu.setForeground(lblColorPoliceMenu.getBackground());
        lblDivers.setForeground(lblColorPoliceAutres.getBackground());
        lblDivers.setBackground(lblColorFondAutres.getBackground());
        lblSelection.setBackground(lblColorSelection.getBackground());
        lblSelection.setForeground(lblColorPoliceSelection.getBackground());
        lblWarning.setBackground(lblColorFEWarning.getBackground());
        lblWarning.setForeground(lblColorPEWarning.getBackground());
        lblPhoto.setBackground(lblColorFondZonePhoto.getBackground());
        btnBoutonInactif.setForeground(lblColorPBoutonsInactifs.getBackground());
        txtSaisieBloque.setBackground(lblColorFTexteBloque.getBackground());
        txtSaisieBloque.setForeground(lblColorPTexteBloque.getBackground());
        dgrDetails.setTableColors();
    }

    /*public boolean isAborted()
    {
        return bAborted;
    }*/

    private void updateColors()
    {
        resetUI();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        pnlTout = new javax.swing.JPanel();
        pnlSample = new javax.swing.JPanel();
        lbl8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblEtiquette = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblEtiquetteO = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtSaisie = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        txtSaisieO = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        txtSaisieBloque = new javax.swing.JTextField();
        jPanel35 = new javax.swing.JPanel();
        btnBouton = new javax.swing.JButton();
        jPanel42 = new javax.swing.JPanel();
        btnBoutonInactif = new javax.swing.JButton();
        jPanel36 = new javax.swing.JPanel();
        pnlGrid = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        btnMenu = new javax.swing.JButton();
        jPanel38 = new javax.swing.JPanel();
        lblDivers = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        lblWarning = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        lblSelection = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        lblPhoto = new javax.swing.JLabel();
        pnlData = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        lblFondEtiquette = new javax.swing.JLabel();
        lblColorFE = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        lblPoliceEtiquette = new javax.swing.JLabel();
        lblColorPE = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        lblFondEtiquetteObligatoire = new javax.swing.JLabel();
        lblColorFEO = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        lblPoliceEtiquetteObligatoire = new javax.swing.JLabel();
        lblColorPEO = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        lblFondTexte = new javax.swing.JLabel();
        lblColorFT = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        lblPoliceTexte = new javax.swing.JLabel();
        lblColorPT = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        lblFondTexteObligatoire = new javax.swing.JLabel();
        lblColorFTO = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        lblPoliceTexteObligatoire = new javax.swing.JLabel();
        lblColorPTO = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        lblFondTexteBloque = new javax.swing.JLabel();
        lblColorFTexteBloque = new javax.swing.JLabel();
        jPanel47 = new javax.swing.JPanel();
        lblPoliceTexteBloque = new javax.swing.JLabel();
        lblColorPTexteBloque = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        lblFondBoutons = new javax.swing.JLabel();
        lblColorFB = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        lblPoliceBoutons = new javax.swing.JLabel();
        lblColorPB = new javax.swing.JLabel();
        jPanel43 = new javax.swing.JPanel();
        lblPBoutonsInactifs = new javax.swing.JLabel();
        lblColorPBoutonsInactifs = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        lblFondTableau = new javax.swing.JLabel();
        lblColorHeaderTableau = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        lblHeaderTableau = new javax.swing.JLabel();
        lblColorFondTableau = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        lblPoliceHeaderTableau = new javax.swing.JLabel();
        lblColorPoliceHeaderTableau = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        lblGrilleTableau = new javax.swing.JLabel();
        lblColorGrilleTableau = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        lblFondLigneImpaireTableau = new javax.swing.JLabel();
        lblColorFondLigneImpaireTableau = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        lblPoliceLigneImpaireTableau = new javax.swing.JLabel();
        lblColorPoliceLigneImpaireTableau = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        lblFondLignePaireTableau = new javax.swing.JLabel();
        lblColorFondLignePaireTableau = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        lblPoliceLignePaireTableau = new javax.swing.JLabel();
        lblColorPoliceLignePaireTableau = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        lblBKTableauSelect = new javax.swing.JLabel();
        lblColorBKTableauSelect = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        lblFGTableauSelect = new javax.swing.JLabel();
        lblColorFGTableauSelect = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        lblFondMenu = new javax.swing.JLabel();
        lblColorFondMenu = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        lblPoliceMenu = new javax.swing.JLabel();
        lblColorPoliceMenu = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        lblFondAutres = new javax.swing.JLabel();
        lblColorFondAutres = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        lblPoliceAutres = new javax.swing.JLabel();
        lblColorPoliceAutres = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        lblFondEtiquetteWarning = new javax.swing.JLabel();
        lblColorFEWarning = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        lblPoliceEtiquetteWarning = new javax.swing.JLabel();
        lblColorPEWarning = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        lblCouleurSelection = new javax.swing.JLabel();
        lblColorSelection = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        lblPoliceSelection = new javax.swing.JLabel();
        lblColorPoliceSelection = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        lblFondZonePhoto = new javax.swing.JLabel();
        lblColorFondZonePhoto = new javax.swing.JLabel();
        jPanel48 = new javax.swing.JPanel();
        lblRDVFondEtat = new javax.swing.JLabel();
        chkRDVFondEtat = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jScrollPane1.setBorder(null);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(800, 700));

        pnlTout.setPreferredSize(new java.awt.Dimension(770, 1200));
        pnlTout.setLayout(new java.awt.BorderLayout());

        pnlSample.setPreferredSize(new java.awt.Dimension(200, 100));
        pnlSample.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lbl8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lbl8.setPreferredSize(new java.awt.Dimension(200, 27));
        pnlSample.add(lbl8);

        jPanel2.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 17));

        lblEtiquette.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        lblEtiquette.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEtiquette.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblEtiquette.setOpaque(true);
        lblEtiquette.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel2.add(lblEtiquette);

        pnlSample.add(jPanel2);

        jPanel3.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 17));

        lblEtiquetteO.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        lblEtiquetteO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEtiquetteO.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblEtiquetteO.setOpaque(true);
        lblEtiquetteO.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel3.add(lblEtiquetteO);

        pnlSample.add(jPanel3);

        jPanel4.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 16));

        txtSaisie.setEditable(false);
        txtSaisie.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtSaisie.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSaisie.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel4.add(txtSaisie);

        pnlSample.add(jPanel4);

        jPanel5.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 16));

        txtSaisieO.setEditable(false);
        txtSaisieO.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtSaisieO.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSaisieO.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel5.add(txtSaisieO);

        pnlSample.add(jPanel5);

        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 16));

        txtSaisieBloque.setEditable(false);
        txtSaisieBloque.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtSaisieBloque.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSaisieBloque.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel6.add(txtSaisieBloque);

        pnlSample.add(jPanel6);

        jPanel35.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel35.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 17));

        btnBouton.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        btnBouton.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel35.add(btnBouton);

        pnlSample.add(jPanel35);

        jPanel42.setPreferredSize(new java.awt.Dimension(200, 27));
        jPanel42.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 4));

        btnBoutonInactif.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        btnBoutonInactif.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel42.add(btnBoutonInactif);

        pnlSample.add(jPanel42);

        jPanel36.setPreferredSize(new java.awt.Dimension(200, 270));
        jPanel36.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 35));

        pnlGrid.setPreferredSize(new java.awt.Dimension(200, 200));
        pnlGrid.setLayout(new java.awt.BorderLayout());
        jPanel36.add(pnlGrid);

        pnlSample.add(jPanel36);

        jPanel37.setPreferredSize(new java.awt.Dimension(200, 54));

        btnMenu.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        btnMenu.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(153, 153, 153)));
        btnMenu.setContentAreaFilled(false);
        btnMenu.setOpaque(true);
        btnMenu.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel37.add(btnMenu);

        pnlSample.add(jPanel37);

        jPanel38.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel38.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 16));

        lblDivers.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        lblDivers.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDivers.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblDivers.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel38.add(lblDivers);

        pnlSample.add(jPanel38);

        jPanel39.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel39.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 17));

        lblWarning.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        lblWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblWarning.setOpaque(true);
        lblWarning.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel39.add(lblWarning);

        pnlSample.add(jPanel39);

        jPanel40.setPreferredSize(new java.awt.Dimension(200, 54));
        jPanel40.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 17));

        lblSelection.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        lblSelection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSelection.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblSelection.setOpaque(true);
        lblSelection.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel40.add(lblSelection);

        pnlSample.add(jPanel40);

        jPanel41.setPreferredSize(new java.awt.Dimension(200, 54));

        lblPhoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPhoto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblPhoto.setOpaque(true);
        lblPhoto.setPreferredSize(new java.awt.Dimension(200, 20));
        jPanel41.add(lblPhoto);

        pnlSample.add(jPanel41);

        pnlTout.add(pnlSample, java.awt.BorderLayout.EAST);

        pnlData.setMinimumSize(new java.awt.Dimension(600, 410));
        pnlData.setPreferredSize(new java.awt.Dimension(560, 850));
        pnlData.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        jPanel21.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel21.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel21.setPreferredSize(new java.awt.Dimension(750, 27));

        jLabel11.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setAlignmentX(0.5F);
        jLabel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel11.setOpaque(true);
        jLabel11.setPreferredSize(new java.awt.Dimension(640, 22));
        jPanel21.add(jLabel11);

        pnlData.add(jPanel21);

        jPanel7.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel7.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel7.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondEtiquette.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondEtiquette.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondEtiquette.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondEtiquette.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondEtiquette.setOpaque(true);
        lblFondEtiquette.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel7.add(lblFondEtiquette);

        lblColorFE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFE.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFE.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFE.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFE.setOpaque(true);
        lblColorFE.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFEMouseClicked(evt);
            }
        });
        jPanel7.add(lblColorFE);

        pnlData.add(jPanel7);

        jPanel9.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel9.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel9.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceEtiquette.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceEtiquette.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceEtiquette.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceEtiquette.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceEtiquette.setOpaque(true);
        lblPoliceEtiquette.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel9.add(lblPoliceEtiquette);

        lblColorPE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPE.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPE.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPE.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPE.setOpaque(true);
        lblColorPE.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPEMouseClicked(evt);
            }
        });
        jPanel9.add(lblColorPE);

        pnlData.add(jPanel9);

        jPanel8.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel8.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel8.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondEtiquetteObligatoire.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondEtiquetteObligatoire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondEtiquetteObligatoire.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondEtiquetteObligatoire.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondEtiquetteObligatoire.setOpaque(true);
        lblFondEtiquetteObligatoire.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel8.add(lblFondEtiquetteObligatoire);

        lblColorFEO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFEO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFEO.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFEO.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFEO.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFEO.setOpaque(true);
        lblColorFEO.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFEO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFEOMouseClicked(evt);
            }
        });
        jPanel8.add(lblColorFEO);

        pnlData.add(jPanel8);

        jPanel10.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel10.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel10.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceEtiquetteObligatoire.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceEtiquetteObligatoire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceEtiquetteObligatoire.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceEtiquetteObligatoire.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceEtiquetteObligatoire.setOpaque(true);
        lblPoliceEtiquetteObligatoire.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel10.add(lblPoliceEtiquetteObligatoire);

        lblColorPEO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPEO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPEO.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPEO.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPEO.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPEO.setOpaque(true);
        lblColorPEO.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPEO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPEOMouseClicked(evt);
            }
        });
        jPanel10.add(lblColorPEO);

        pnlData.add(jPanel10);

        jPanel11.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel11.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel11.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondTexte.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondTexte.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondTexte.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondTexte.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondTexte.setOpaque(true);
        lblFondTexte.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel11.add(lblFondTexte);

        lblColorFT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFT.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFT.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFT.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFT.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFT.setOpaque(true);
        lblColorFT.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFTMouseClicked(evt);
            }
        });
        jPanel11.add(lblColorFT);

        pnlData.add(jPanel11);

        jPanel15.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel15.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel15.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceTexte.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceTexte.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceTexte.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceTexte.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceTexte.setOpaque(true);
        lblPoliceTexte.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel15.add(lblPoliceTexte);

        lblColorPT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPT.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPT.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPT.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPT.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPT.setOpaque(true);
        lblColorPT.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPTMouseClicked(evt);
            }
        });
        jPanel15.add(lblColorPT);

        pnlData.add(jPanel15);

        jPanel14.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel14.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel14.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondTexteObligatoire.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondTexteObligatoire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondTexteObligatoire.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondTexteObligatoire.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondTexteObligatoire.setOpaque(true);
        lblFondTexteObligatoire.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel14.add(lblFondTexteObligatoire);

        lblColorFTO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFTO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFTO.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFTO.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFTO.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFTO.setOpaque(true);
        lblColorFTO.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFTO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFTOMouseClicked(evt);
            }
        });
        jPanel14.add(lblColorFTO);

        pnlData.add(jPanel14);

        jPanel16.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel16.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel16.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceTexteObligatoire.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceTexteObligatoire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceTexteObligatoire.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceTexteObligatoire.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceTexteObligatoire.setOpaque(true);
        lblPoliceTexteObligatoire.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel16.add(lblPoliceTexteObligatoire);

        lblColorPTO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPTO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPTO.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPTO.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPTO.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPTO.setOpaque(true);
        lblColorPTO.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPTO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPTOMouseClicked(evt);
            }
        });
        jPanel16.add(lblColorPTO);

        pnlData.add(jPanel16);

        jPanel46.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel46.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel46.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondTexteBloque.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondTexteBloque.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondTexteBloque.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondTexteBloque.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondTexteBloque.setOpaque(true);
        lblFondTexteBloque.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel46.add(lblFondTexteBloque);

        lblColorFTexteBloque.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFTexteBloque.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFTexteBloque.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFTexteBloque.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFTexteBloque.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFTexteBloque.setOpaque(true);
        lblColorFTexteBloque.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFTexteBloque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFTexteBloqueMouseClicked(evt);
            }
        });
        jPanel46.add(lblColorFTexteBloque);

        pnlData.add(jPanel46);

        jPanel47.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel47.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel47.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceTexteBloque.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceTexteBloque.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceTexteBloque.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceTexteBloque.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceTexteBloque.setOpaque(true);
        lblPoliceTexteBloque.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel47.add(lblPoliceTexteBloque);

        lblColorPTexteBloque.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPTexteBloque.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPTexteBloque.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPTexteBloque.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPTexteBloque.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPTexteBloque.setOpaque(true);
        lblColorPTexteBloque.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPTexteBloque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPTexteBloqueMouseClicked(evt);
            }
        });
        jPanel47.add(lblColorPTexteBloque);

        pnlData.add(jPanel47);

        jPanel17.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel17.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel17.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondBoutons.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondBoutons.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondBoutons.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondBoutons.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondBoutons.setOpaque(true);
        lblFondBoutons.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel17.add(lblFondBoutons);

        lblColorFB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFB.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFB.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFB.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFB.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFB.setOpaque(true);
        lblColorFB.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFBMouseClicked(evt);
            }
        });
        jPanel17.add(lblColorFB);

        pnlData.add(jPanel17);

        jPanel18.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel18.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel18.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceBoutons.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceBoutons.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceBoutons.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceBoutons.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceBoutons.setOpaque(true);
        lblPoliceBoutons.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel18.add(lblPoliceBoutons);

        lblColorPB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPB.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPB.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPB.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPB.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPB.setOpaque(true);
        lblColorPB.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPBMouseClicked(evt);
            }
        });
        jPanel18.add(lblColorPB);

        pnlData.add(jPanel18);

        jPanel43.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel43.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel43.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPBoutonsInactifs.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPBoutonsInactifs.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPBoutonsInactifs.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPBoutonsInactifs.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPBoutonsInactifs.setOpaque(true);
        lblPBoutonsInactifs.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel43.add(lblPBoutonsInactifs);

        lblColorPBoutonsInactifs.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPBoutonsInactifs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPBoutonsInactifs.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPBoutonsInactifs.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPBoutonsInactifs.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPBoutonsInactifs.setOpaque(true);
        lblColorPBoutonsInactifs.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPBoutonsInactifs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPBoutonsInactifsMouseClicked(evt);
            }
        });
        jPanel43.add(lblColorPBoutonsInactifs);

        pnlData.add(jPanel43);

        jPanel13.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondTableau.setOpaque(true);
        lblFondTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel13.add(lblFondTableau);

        lblColorHeaderTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorHeaderTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorHeaderTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorHeaderTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorHeaderTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorHeaderTableau.setOpaque(true);
        lblColorHeaderTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorHeaderTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorHeaderTableauMouseClicked(evt);
            }
        });
        jPanel13.add(lblColorHeaderTableau);

        pnlData.add(jPanel13);

        jPanel34.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel34.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel34.setPreferredSize(new java.awt.Dimension(550, 27));

        lblHeaderTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblHeaderTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeaderTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblHeaderTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblHeaderTableau.setOpaque(true);
        lblHeaderTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel34.add(lblHeaderTableau);

        lblColorFondTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFondTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondTableau.setOpaque(true);
        lblColorFondTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondTableauMouseClicked(evt);
            }
        });
        jPanel34.add(lblColorFondTableau);

        pnlData.add(jPanel34);

        jPanel23.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel23.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel23.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceHeaderTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceHeaderTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceHeaderTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceHeaderTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceHeaderTableau.setOpaque(true);
        lblPoliceHeaderTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel23.add(lblPoliceHeaderTableau);

        lblColorPoliceHeaderTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceHeaderTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPoliceHeaderTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceHeaderTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceHeaderTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceHeaderTableau.setOpaque(true);
        lblColorPoliceHeaderTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceHeaderTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceHeaderTableauMouseClicked(evt);
            }
        });
        jPanel23.add(lblColorPoliceHeaderTableau);

        pnlData.add(jPanel23);

        jPanel25.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel25.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel25.setPreferredSize(new java.awt.Dimension(550, 27));

        lblGrilleTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblGrilleTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGrilleTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblGrilleTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblGrilleTableau.setOpaque(true);
        lblGrilleTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel25.add(lblGrilleTableau);

        lblColorGrilleTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorGrilleTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorGrilleTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorGrilleTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorGrilleTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorGrilleTableau.setOpaque(true);
        lblColorGrilleTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorGrilleTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorGrilleTableauMouseClicked(evt);
            }
        });
        jPanel25.add(lblColorGrilleTableau);

        pnlData.add(jPanel25);

        jPanel26.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel26.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel26.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondLigneImpaireTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondLigneImpaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondLigneImpaireTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondLigneImpaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondLigneImpaireTableau.setOpaque(true);
        lblFondLigneImpaireTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel26.add(lblFondLigneImpaireTableau);

        lblColorFondLigneImpaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondLigneImpaireTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFondLigneImpaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondLigneImpaireTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondLigneImpaireTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondLigneImpaireTableau.setOpaque(true);
        lblColorFondLigneImpaireTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondLigneImpaireTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondLigneImpaireTableauMouseClicked(evt);
            }
        });
        jPanel26.add(lblColorFondLigneImpaireTableau);

        pnlData.add(jPanel26);

        jPanel27.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel27.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel27.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceLigneImpaireTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceLigneImpaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceLigneImpaireTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceLigneImpaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceLigneImpaireTableau.setOpaque(true);
        lblPoliceLigneImpaireTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel27.add(lblPoliceLigneImpaireTableau);

        lblColorPoliceLigneImpaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceLigneImpaireTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPoliceLigneImpaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceLigneImpaireTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceLigneImpaireTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceLigneImpaireTableau.setOpaque(true);
        lblColorPoliceLigneImpaireTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceLigneImpaireTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceLigneImpaireTableauMouseClicked(evt);
            }
        });
        jPanel27.add(lblColorPoliceLigneImpaireTableau);

        pnlData.add(jPanel27);

        jPanel28.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel28.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel28.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondLignePaireTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondLignePaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondLignePaireTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondLignePaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondLignePaireTableau.setOpaque(true);
        lblFondLignePaireTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel28.add(lblFondLignePaireTableau);

        lblColorFondLignePaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondLignePaireTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFondLignePaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondLignePaireTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondLignePaireTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondLignePaireTableau.setOpaque(true);
        lblColorFondLignePaireTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondLignePaireTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondLignePaireTableauMouseClicked(evt);
            }
        });
        jPanel28.add(lblColorFondLignePaireTableau);

        pnlData.add(jPanel28);

        jPanel29.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel29.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel29.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceLignePaireTableau.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceLignePaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceLignePaireTableau.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceLignePaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceLignePaireTableau.setOpaque(true);
        lblPoliceLignePaireTableau.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel29.add(lblPoliceLignePaireTableau);

        lblColorPoliceLignePaireTableau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceLignePaireTableau.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPoliceLignePaireTableau.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceLignePaireTableau.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceLignePaireTableau.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceLignePaireTableau.setOpaque(true);
        lblColorPoliceLignePaireTableau.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceLignePaireTableau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceLignePaireTableauMouseClicked(evt);
            }
        });
        jPanel29.add(lblColorPoliceLignePaireTableau);

        pnlData.add(jPanel29);

        jPanel44.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel44.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel44.setPreferredSize(new java.awt.Dimension(550, 27));

        lblBKTableauSelect.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblBKTableauSelect.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBKTableauSelect.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblBKTableauSelect.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblBKTableauSelect.setOpaque(true);
        lblBKTableauSelect.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel44.add(lblBKTableauSelect);

        lblColorBKTableauSelect.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorBKTableauSelect.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorBKTableauSelect.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorBKTableauSelect.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorBKTableauSelect.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorBKTableauSelect.setOpaque(true);
        lblColorBKTableauSelect.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorBKTableauSelect.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorBKTableauSelectMouseClicked(evt);
            }
        });
        jPanel44.add(lblColorBKTableauSelect);

        pnlData.add(jPanel44);

        jPanel45.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel45.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel45.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFGTableauSelect.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFGTableauSelect.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFGTableauSelect.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFGTableauSelect.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFGTableauSelect.setOpaque(true);
        lblFGTableauSelect.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel45.add(lblFGTableauSelect);

        lblColorFGTableauSelect.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFGTableauSelect.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFGTableauSelect.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFGTableauSelect.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFGTableauSelect.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFGTableauSelect.setOpaque(true);
        lblColorFGTableauSelect.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFGTableauSelect.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFGTableauSelectMouseClicked(evt);
            }
        });
        jPanel45.add(lblColorFGTableauSelect);

        pnlData.add(jPanel45);

        jPanel31.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel31.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel31.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondMenu.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondMenu.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondMenu.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondMenu.setOpaque(true);
        lblFondMenu.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel31.add(lblFondMenu);

        lblColorFondMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondMenu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFondMenu.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondMenu.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondMenu.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondMenu.setOpaque(true);
        lblColorFondMenu.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondMenuMouseClicked(evt);
            }
        });
        jPanel31.add(lblColorFondMenu);

        pnlData.add(jPanel31);

        jPanel30.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel30.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel30.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceMenu.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceMenu.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceMenu.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceMenu.setOpaque(true);
        lblPoliceMenu.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel30.add(lblPoliceMenu);

        lblColorPoliceMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceMenu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPoliceMenu.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceMenu.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceMenu.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceMenu.setOpaque(true);
        lblColorPoliceMenu.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceMenuMouseClicked(evt);
            }
        });
        jPanel30.add(lblColorPoliceMenu);

        pnlData.add(jPanel30);

        jPanel19.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel19.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel19.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondAutres.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondAutres.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondAutres.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondAutres.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondAutres.setOpaque(true);
        lblFondAutres.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel19.add(lblFondAutres);

        lblColorFondAutres.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondAutres.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblColorFondAutres.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondAutres.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondAutres.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondAutres.setOpaque(true);
        lblColorFondAutres.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondAutres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondAutresMouseClicked(evt);
            }
        });
        jPanel19.add(lblColorFondAutres);

        pnlData.add(jPanel19);

        jPanel20.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel20.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel20.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceAutres.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceAutres.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceAutres.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceAutres.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceAutres.setOpaque(true);
        lblPoliceAutres.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel20.add(lblPoliceAutres);

        lblColorPoliceAutres.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceAutres.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblColorPoliceAutres.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceAutres.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceAutres.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceAutres.setOpaque(true);
        lblColorPoliceAutres.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceAutres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceAutresMouseClicked(evt);
            }
        });
        jPanel20.add(lblColorPoliceAutres);

        pnlData.add(jPanel20);

        jPanel32.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel32.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel32.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondEtiquetteWarning.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondEtiquetteWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondEtiquetteWarning.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondEtiquetteWarning.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondEtiquetteWarning.setOpaque(true);
        lblFondEtiquetteWarning.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel32.add(lblFondEtiquetteWarning);

        lblColorFEWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFEWarning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFEWarning.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFEWarning.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFEWarning.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFEWarning.setOpaque(true);
        lblColorFEWarning.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFEWarning.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFEWarningMouseClicked(evt);
            }
        });
        jPanel32.add(lblColorFEWarning);

        pnlData.add(jPanel32);

        jPanel33.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel33.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel33.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceEtiquetteWarning.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceEtiquetteWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceEtiquetteWarning.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceEtiquetteWarning.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceEtiquetteWarning.setOpaque(true);
        lblPoliceEtiquetteWarning.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel33.add(lblPoliceEtiquetteWarning);

        lblColorPEWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPEWarning.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPEWarning.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPEWarning.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPEWarning.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPEWarning.setOpaque(true);
        lblColorPEWarning.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPEWarning.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPEWarningMouseClicked(evt);
            }
        });
        jPanel33.add(lblColorPEWarning);

        pnlData.add(jPanel33);

        jPanel24.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel24.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel24.setPreferredSize(new java.awt.Dimension(550, 27));

        lblCouleurSelection.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblCouleurSelection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCouleurSelection.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblCouleurSelection.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblCouleurSelection.setOpaque(true);
        lblCouleurSelection.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel24.add(lblCouleurSelection);

        lblColorSelection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSelection.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorSelection.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSelection.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorSelection.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorSelection.setOpaque(true);
        lblColorSelection.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorSelection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSelectionMouseClicked(evt);
            }
        });
        jPanel24.add(lblColorSelection);

        pnlData.add(jPanel24);

        jPanel12.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel12.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel12.setPreferredSize(new java.awt.Dimension(550, 27));

        lblPoliceSelection.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblPoliceSelection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPoliceSelection.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblPoliceSelection.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblPoliceSelection.setOpaque(true);
        lblPoliceSelection.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel12.add(lblPoliceSelection);

        lblColorPoliceSelection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPoliceSelection.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorPoliceSelection.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPoliceSelection.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceSelection.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPoliceSelection.setOpaque(true);
        lblColorPoliceSelection.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorPoliceSelection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPoliceSelectionMouseClicked(evt);
            }
        });
        jPanel12.add(lblColorPoliceSelection);

        pnlData.add(jPanel12);

        jPanel22.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel22.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel22.setPreferredSize(new java.awt.Dimension(550, 27));

        lblFondZonePhoto.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblFondZonePhoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFondZonePhoto.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFondZonePhoto.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFondZonePhoto.setOpaque(true);
        lblFondZonePhoto.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel22.add(lblFondZonePhoto);

        lblColorFondZonePhoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFondZonePhoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        lblColorFondZonePhoto.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFondZonePhoto.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFondZonePhoto.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFondZonePhoto.setOpaque(true);
        lblColorFondZonePhoto.setPreferredSize(new java.awt.Dimension(80, 22));
        lblColorFondZonePhoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFondZonePhotoMouseClicked(evt);
            }
        });
        jPanel22.add(lblColorFondZonePhoto);

        pnlData.add(jPanel22);

        jPanel48.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel48.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel48.setPreferredSize(new java.awt.Dimension(550, 27));

        lblRDVFondEtat.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblRDVFondEtat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRDVFondEtat.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblRDVFondEtat.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblRDVFondEtat.setOpaque(true);
        lblRDVFondEtat.setPreferredSize(new java.awt.Dimension(450, 22));
        jPanel48.add(lblRDVFondEtat);

        chkRDVFondEtat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chkRDVFondEtat.setPreferredSize(new java.awt.Dimension(80, 22));
        chkRDVFondEtat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkRDVFondEtatActionPerformed(evt);
            }
        });
        jPanel48.add(chkRDVFondEtat);

        pnlData.add(jPanel48);

        pnlTout.add(pnlData, java.awt.BorderLayout.CENTER);

        jScrollPane1.setViewportView(pnlTout);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void setColor(Color color)
    {
        this.color = color;
    }

    private void lblColorPBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPBMouseClicked
        color = lblColorPB.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPB.setBackground(color);
        MainClass.options.setColor("Button.foreground", color, true);
        MainClass.options.setColor("Checkbox.foreground", color, true);
        MainClass.options.setColor("RadioButton.foreground", color, true);
        updateColors();
}//GEN-LAST:event_lblColorPBMouseClicked

    private void lblColorFBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFBMouseClicked
        color = lblColorFB.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFB.setBackground(color);
        MainClass.options.setColor("Button.background", color, true);
        MainClass.options.setColor("Checkbox.background", color, true);
        MainClass.options.setColor("RadioButton.background", color, true);
        updateColors();
}//GEN-LAST:event_lblColorFBMouseClicked

    private void lblColorPTOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPTOMouseClicked
        color = lblColorPTO.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPTO.setBackground(color);
        Options.fgsaisieobligatoire = color;
        MainClass.options.setColor("SaisieObligatoire.foreground", color, true);
        updateColors();
}//GEN-LAST:event_lblColorPTOMouseClicked

    private void lblColorPTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPTMouseClicked
        color = lblColorPT.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPT.setBackground(color);
        MainClass.options.setColor("TextField.foreground", color, true);
        updateColors();
}//GEN-LAST:event_lblColorPTMouseClicked

    private void lblColorFTOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFTOMouseClicked
        color = lblColorFTO.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFTO.setBackground(color);
        Options.bksaisieobligatoire = color;
        MainClass.options.setColor("SaisieObligatoire.background", color, true);
        updateColors();
}//GEN-LAST:event_lblColorFTOMouseClicked

    private void lblColorFTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFTMouseClicked
        color = lblColorFT.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFT.setBackground(color);
        MainClass.options.setColor("TextField.background", color, true);
        updateColors();
}//GEN-LAST:event_lblColorFTMouseClicked

    private void lblColorPEOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPEOMouseClicked
        color = lblColorPEO.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPEO.setBackground(color);
        Options.fgetiquetteobligatoire = color;
        MainClass.options.setColor("EtiquetteObligatoire.foreground", color, true);
        updateColors();
}//GEN-LAST:event_lblColorPEOMouseClicked

    private void lblColorPEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPEMouseClicked
        color = lblColorPE.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPE.setBackground(color);
        MainClass.options.setColor("Label.foreground", color, true);
        updateColors();
}//GEN-LAST:event_lblColorPEMouseClicked

    private void lblColorFEOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFEOMouseClicked
        color = lblColorFEO.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFEO.setBackground(color);
        Options.bketiquetteobligatoire = color;
        MainClass.options.setColor("EtiquetteObligatoire.background", color, true);
        updateColors();
}//GEN-LAST:event_lblColorFEOMouseClicked

    private void lblColorFEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFEMouseClicked
        color = lblColorFE.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFE.setBackground(color);
        MainClass.options.setColor("Label.background", color, true);
        updateColors();
}//GEN-LAST:event_lblColorFEMouseClicked

    private void lblColorFondAutresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorFondAutresMouseClicked
        color = lblColorFondAutres.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondAutres.setBackground(color);
        MainClass.options.setColor("Panel.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondAutresMouseClicked

    private void lblColorPoliceAutresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblColorPoliceAutresMouseClicked
        color = lblColorPoliceAutres.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceAutres.setBackground(color);
        MainClass.options.setColor("Panel.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceAutresMouseClicked

    private void lblColorPoliceSelectionMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPoliceSelectionMouseClicked
    {//GEN-HEADEREND:event_lblColorPoliceSelectionMouseClicked
        color = lblColorPoliceSelection.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceSelection.setBackground(color);
        MainClass.options.setColor("CheckBoxMenuItem.selectionForeground", color, true);
        MainClass.options.setColor("Menu.selectionForeground", color, true);
        MainClass.options.setColor("PasswordField.selectionForeground", color, true);
        MainClass.options.setColor("ProgressBar.selectionForeground", color, true);
        MainClass.options.setColor("RadioButtonMenuItem.selectionForeground", color, true);
        MainClass.options.setColor("TextField.selectionForeground", color, true);
        MainClass.options.setColor("FormattedTextField.selectionForeground", color, true);
        MainClass.options.setColor("ComboBox.selectionForeground", color, true);
        MainClass.options.setColor("List.selectionForeground", color, true);
        MainClass.options.setColor("MenuItem.selectionForeground", color, true);
        MainClass.options.setColor("Table.selectionForeground", color, true);
        MainClass.options.setColor("TextPane.selectionForeground", color, true);
        MainClass.options.setColor("EditorPane.selectionForeground", color, true);
        MainClass.options.setColor("TextArea.selectionForeground", color, true);
        MainClass.options.setColor("Tree.selectionForeground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceSelectionMouseClicked

    private void lblColorFondTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFondTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorFondTableauMouseClicked
        color = lblColorFondTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondTableau.setBackground(color);
        MainClass.options.setColor("Table.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondTableauMouseClicked

    private void lblColorSelectionMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSelectionMouseClicked
    {//GEN-HEADEREND:event_lblColorSelectionMouseClicked
        color = lblColorSelection.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorSelection.setBackground(color);
        MainClass.options.setColor("Menu.selectionBackground", color, true);
        MainClass.options.setColor("PasswordField.selectionBackground", color, true);
        MainClass.options.setColor("ProgressBar.selectionBackground", color, true);
        MainClass.options.setColor("RadioButtonMenuItem.selectionBackground", color, true);
        MainClass.options.setColor("TextField.selectionBackground", color, true);
        MainClass.options.setColor("FormattedTextField.selectionBackground", color, true);
        MainClass.options.setColor("ComboBox.selectionBackground", color, true);
        MainClass.options.setColor("List.selectionBackground", color, true);
        MainClass.options.setColor("MenuItem.selectionBackground", color, true);
        MainClass.options.setColor("CheckBoxMenuItem.selectionBackground", color, true);
        MainClass.options.setColor("TextPane.selectionBackground", color, true);
        MainClass.options.setColor("EditorPane.selectionBackground", color, true);
        MainClass.options.setColor("TextArea.selectionBackground", color, true);
        MainClass.options.setColor("Tree.selectionBackground", color, true);
        MainClass.options.setColor("Button.select", color, true);
        MainClass.options.setColor("RadioButton.select", color, true);
        MainClass.options.setColor("Checkbox.select", color, true);
        MainClass.options.setColor("ToggleButton.select", color, true);
        MainClass.options.setColor("TabbedPane.selected", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorSelectionMouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        if (parentForm instanceof OutilsForm)
            ((OutilsForm)parentForm).setChartsColorsFrame(false);
        
        
        Window windows[] = java.awt.Frame.getWindows();
        for (Window window : windows)
        {
            window.paintAll(window.getGraphics());
        }
        
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_formWindowClosing

    private void lblColorPoliceHeaderTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPoliceHeaderTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorPoliceHeaderTableauMouseClicked
        color = lblColorPoliceHeaderTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceHeaderTableau.setBackground(color);
        MainClass.options.setColor("TableHeader.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceHeaderTableauMouseClicked

    private void lblColorGrilleTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorGrilleTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorGrilleTableauMouseClicked
        color = lblColorGrilleTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorGrilleTableau.setBackground(color);
        MainClass.options.setColor("Table.gridColor", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorGrilleTableauMouseClicked

    private void lblColorFondLigneImpaireTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFondLigneImpaireTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorFondLigneImpaireTableauMouseClicked
        color = lblColorFondLigneImpaireTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondLigneImpaireTableau.setBackground(color);
        Options.bkligneimpaire = color;
        MainClass.options.setColor("LigneImpaire.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondLigneImpaireTableauMouseClicked

    private void lblColorPoliceLigneImpaireTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPoliceLigneImpaireTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorPoliceLigneImpaireTableauMouseClicked
        color = lblColorPoliceLigneImpaireTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceLigneImpaireTableau.setBackground(color);
        Options.fgligneimpaire = color;
        MainClass.options.setColor("LigneImpaire.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceLigneImpaireTableauMouseClicked

    private void lblColorFondLignePaireTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFondLignePaireTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorFondLignePaireTableauMouseClicked
        color = lblColorFondLignePaireTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondLignePaireTableau.setBackground(color);
        Options.bklignepaire = color;
        MainClass.options.setColor("LignePaire.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondLignePaireTableauMouseClicked

    private void lblColorPoliceLignePaireTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPoliceLignePaireTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorPoliceLignePaireTableauMouseClicked
        color = lblColorPoliceLignePaireTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceLignePaireTableau.setBackground(color);
        Options.fglignepaire = color;
        MainClass.options.setColor("LignePaire.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceLignePaireTableauMouseClicked

    private void lblColorPoliceMenuMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPoliceMenuMouseClicked
    {//GEN-HEADEREND:event_lblColorPoliceMenuMouseClicked
        color = lblColorPoliceMenu.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPoliceMenu.setBackground(color);
        MainClass.options.setColor("Menu.foreground", color, true);
        MainClass.options.setColor("MenuItem.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPoliceMenuMouseClicked

    private void lblColorFondMenuMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFondMenuMouseClicked
    {//GEN-HEADEREND:event_lblColorFondMenuMouseClicked
        color = lblColorFondMenu.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondMenu.setBackground(color);
        MainClass.options.setColor("Menu.background", color, true);
        MainClass.options.setColor("MenuItem.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondMenuMouseClicked

    private void lblColorFEWarningMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFEWarningMouseClicked
    {//GEN-HEADEREND:event_lblColorFEWarningMouseClicked
        color = lblColorFEWarning.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFEWarning.setBackground(color);
        Options.bkwarning = color;
        MainClass.options.setColor("Warning.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFEWarningMouseClicked

    private void lblColorPEWarningMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPEWarningMouseClicked
    {//GEN-HEADEREND:event_lblColorPEWarningMouseClicked
        color = lblColorPEWarning.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPEWarning.setBackground(color);
        Options.fgwarning = color;
        MainClass.options.setColor("Warning.foreground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPEWarningMouseClicked

    private void lblColorFondZonePhotoMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFondZonePhotoMouseClicked
    {//GEN-HEADEREND:event_lblColorFondZonePhotoMouseClicked
        color = lblColorFondZonePhoto.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFondZonePhoto.setBackground(color);
        Options.photobackground = color;
        MainClass.options.setColor("Photo.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFondZonePhotoMouseClicked

    private void lblColorHeaderTableauMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorHeaderTableauMouseClicked
    {//GEN-HEADEREND:event_lblColorHeaderTableauMouseClicked
        color = lblColorHeaderTableau.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorHeaderTableau.setBackground(color);
        MainClass.options.setColor("TableHeader.background", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorHeaderTableauMouseClicked

    private void lblColorPBoutonsInactifsMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPBoutonsInactifsMouseClicked
    {//GEN-HEADEREND:event_lblColorPBoutonsInactifsMouseClicked
        color = lblColorPBoutonsInactifs.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPBoutonsInactifs.setBackground(color);
        MainClass.options.setColor("Button.disabledText", color, true);
        MainClass.options.setColor("Menu.disabledForeground", color, true);
        MainClass.options.setColor("CheckBox.disabledText", color, true);
        MainClass.options.setColor("MenuItem.disabledForeground", color, true);
        MainClass.options.setColor("CheckBoxMenuItem.disabledForeground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPBoutonsInactifsMouseClicked

    private void lblColorBKTableauSelectMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorBKTableauSelectMouseClicked
    {//GEN-HEADEREND:event_lblColorBKTableauSelectMouseClicked
        color = lblColorBKTableauSelect.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorBKTableauSelect.setBackground(color);
        MainClass.options.setColor("Table.selectionBackground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorBKTableauSelectMouseClicked

    private void lblColorFGTableauSelectMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFGTableauSelectMouseClicked
    {//GEN-HEADEREND:event_lblColorFGTableauSelectMouseClicked
        color = lblColorFGTableauSelect.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFGTableauSelect.setBackground(color);
        MainClass.options.setColor("Table.selectionForeground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFGTableauSelectMouseClicked

    private void lblColorFTexteBloqueMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFTexteBloqueMouseClicked
    {//GEN-HEADEREND:event_lblColorFTexteBloqueMouseClicked
        color = lblColorFTexteBloque.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorFTexteBloque.setBackground(color);
        MainClass.options.setColor("PasswordField.inactiveBackground", color, true);
        MainClass.options.setColor("TextField.inactiveBackground", color, true);
        MainClass.options.setColor("FormattedTextField.inactiveBackground", color, true);
        MainClass.options.setColor("ComboBox.disabledBackground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorFTexteBloqueMouseClicked

    private void lblColorPTexteBloqueMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPTexteBloqueMouseClicked
    {//GEN-HEADEREND:event_lblColorPTexteBloqueMouseClicked
        color = lblColorPTexteBloque.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
        {
            return;
        }
        lblColorPTexteBloque.setBackground(color);
        MainClass.options.setColor("PasswordField.inactiveForeground", color, true);
        MainClass.options.setColor("TextField.inactiveForeground", color, true);
        MainClass.options.setColor("FormattedTextField.inactiveForeground", color, true);
        MainClass.options.setColor("TextPane.inactiveForeground", color, true);
        MainClass.options.setColor("EditorPane.inactiveForeground", color, true);
        MainClass.options.setColor("TextArea.inactiveForeground", color, true);
        MainClass.options.setColor("ComboBox.disabledForeground", color, true);
        updateColors();
    }//GEN-LAST:event_lblColorPTexteBloqueMouseClicked

    private void chkRDVFondEtatActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkRDVFondEtatActionPerformed
    {//GEN-HEADEREND:event_chkRDVFondEtatActionPerformed
        if (chkRDVFondEtat.isSelected())
            MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='1' WHERE WINDOW_='RDV' AND PROPERTY='ETATFOND'");
        else
            MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='0' WHERE WINDOW_='RDV' AND PROPERTY='ETATFOND'");
        Window windows[] = java.awt.Frame.getWindows();
        for (Window window : windows)
        {
            if (window instanceof GestionTempsForm)
            {
                ((GestionTempsForm) window).refreshRdvs(false, null);
                break;
            }
        }
    }//GEN-LAST:event_chkRDVFondEtatActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBouton;
    private javax.swing.JButton btnBoutonInactif;
    private javax.swing.JButton btnMenu;
    private javax.swing.JCheckBox chkRDVFondEtat;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl8;
    private javax.swing.JLabel lblBKTableauSelect;
    private javax.swing.JLabel lblColorBKTableauSelect;
    private javax.swing.JLabel lblColorFB;
    private javax.swing.JLabel lblColorFE;
    private javax.swing.JLabel lblColorFEO;
    private javax.swing.JLabel lblColorFEWarning;
    private javax.swing.JLabel lblColorFGTableauSelect;
    private javax.swing.JLabel lblColorFT;
    private javax.swing.JLabel lblColorFTO;
    private javax.swing.JLabel lblColorFTexteBloque;
    private javax.swing.JLabel lblColorFondAutres;
    private javax.swing.JLabel lblColorFondLigneImpaireTableau;
    private javax.swing.JLabel lblColorFondLignePaireTableau;
    private javax.swing.JLabel lblColorFondMenu;
    private javax.swing.JLabel lblColorFondTableau;
    private javax.swing.JLabel lblColorFondZonePhoto;
    private javax.swing.JLabel lblColorGrilleTableau;
    private javax.swing.JLabel lblColorHeaderTableau;
    private javax.swing.JLabel lblColorPB;
    private javax.swing.JLabel lblColorPBoutonsInactifs;
    private javax.swing.JLabel lblColorPE;
    private javax.swing.JLabel lblColorPEO;
    private javax.swing.JLabel lblColorPEWarning;
    private javax.swing.JLabel lblColorPT;
    private javax.swing.JLabel lblColorPTO;
    private javax.swing.JLabel lblColorPTexteBloque;
    private javax.swing.JLabel lblColorPoliceAutres;
    private javax.swing.JLabel lblColorPoliceHeaderTableau;
    private javax.swing.JLabel lblColorPoliceLigneImpaireTableau;
    private javax.swing.JLabel lblColorPoliceLignePaireTableau;
    private javax.swing.JLabel lblColorPoliceMenu;
    private javax.swing.JLabel lblColorPoliceSelection;
    private javax.swing.JLabel lblColorSelection;
    private javax.swing.JLabel lblCouleurSelection;
    private javax.swing.JLabel lblDivers;
    private javax.swing.JLabel lblEtiquette;
    private javax.swing.JLabel lblEtiquetteO;
    private javax.swing.JLabel lblFGTableauSelect;
    private javax.swing.JLabel lblFondAutres;
    private javax.swing.JLabel lblFondBoutons;
    private javax.swing.JLabel lblFondEtiquette;
    private javax.swing.JLabel lblFondEtiquetteObligatoire;
    private javax.swing.JLabel lblFondEtiquetteWarning;
    private javax.swing.JLabel lblFondLigneImpaireTableau;
    private javax.swing.JLabel lblFondLignePaireTableau;
    private javax.swing.JLabel lblFondMenu;
    private javax.swing.JLabel lblFondTableau;
    private javax.swing.JLabel lblFondTexte;
    private javax.swing.JLabel lblFondTexteBloque;
    private javax.swing.JLabel lblFondTexteObligatoire;
    private javax.swing.JLabel lblFondZonePhoto;
    private javax.swing.JLabel lblGrilleTableau;
    private javax.swing.JLabel lblHeaderTableau;
    private javax.swing.JLabel lblPBoutonsInactifs;
    private javax.swing.JLabel lblPhoto;
    private javax.swing.JLabel lblPoliceAutres;
    private javax.swing.JLabel lblPoliceBoutons;
    private javax.swing.JLabel lblPoliceEtiquette;
    private javax.swing.JLabel lblPoliceEtiquetteObligatoire;
    private javax.swing.JLabel lblPoliceEtiquetteWarning;
    private javax.swing.JLabel lblPoliceHeaderTableau;
    private javax.swing.JLabel lblPoliceLigneImpaireTableau;
    private javax.swing.JLabel lblPoliceLignePaireTableau;
    private javax.swing.JLabel lblPoliceMenu;
    private javax.swing.JLabel lblPoliceSelection;
    private javax.swing.JLabel lblPoliceTexte;
    private javax.swing.JLabel lblPoliceTexteBloque;
    private javax.swing.JLabel lblPoliceTexteObligatoire;
    private javax.swing.JLabel lblRDVFondEtat;
    private javax.swing.JLabel lblSelection;
    private javax.swing.JLabel lblWarning;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlGrid;
    private javax.swing.JPanel pnlSample;
    private javax.swing.JPanel pnlTout;
    private javax.swing.JTextField txtSaisie;
    private javax.swing.JTextField txtSaisieBloque;
    private javax.swing.JTextField txtSaisieO;
    // End of variables declaration//GEN-END:variables
}
