package StarLogin.IHM;

import StarLogin.IHM.components.Options;
import java.awt.*;
import javax.swing.JPanel;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DrawTimeScale extends JPanel
{
    private final int topMargin = 1;
    private final int leftMargin = 5;
    private int xVal = 0;
    private int yVal = 0;
    private int timeScale;
    public static final int ts10 = 10;
    public static final int ts15 = 15;
    public static final int ts30 = 30;
    public static final int ts60 = 60;
    private int vh;
    private int nbjoursdansmois;

    /** Creates a new instance of DrawEphemeris */
    public DrawTimeScale(int ts, Dimension dim, int vh, int nbjoursdansmois)
    {
        timeScale = ts;
        this.setOpaque(true);
        this.vh = vh;
        this.nbjoursdansmois = nbjoursdansmois;
    }

    public void reFresh(int xVal, int yVal)
    {
        this.xVal = xVal;
        this.yVal = yVal;
        this.paintAll(this.getGraphics());
    }

    @Override
    public void paint(Graphics g)
    {
        Dimension d = getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.clearRect(0, 0, d.width, d.height);
        render(d.width, d.height, g2, xVal, yVal);
        g2.dispose();
    }

    public void render(int w, int h, Graphics2D g2, int x, int y)
    {
        y = y * (int)((double)(vh - h) / (double)h);
        int yy = topMargin + y;
        int xx = leftMargin + x;
        int curX;
        int curY;
        Color traits = Options.getColor("Panel.background");
        Color tmp = traits.brighter();
        tmp = tmp.brighter();
        int r1 = traits.getRed();
        int r2 = tmp.getRed();
        int gr1 = traits.getGreen();
        int gr2 = tmp.getGreen();
        int b1 = traits.getBlue();
        int b2 = tmp.getBlue();
        if ((r2 == 255 && gr2 == 255 && b2 == 255)||(r2+gr2+b2-r1-gr1-b1<30))
        {
            tmp = traits.darker();
            tmp = tmp.darker();
        }
        traits = tmp;
        Color police = Options.getColor("Panel.foreground");

        int sizeFont = 18;
        String space = "";
        if (MainClass.timeType == MainClass.TIME12 && timeScale<1440)
        {
            sizeFont = 12;
            space = "  ";
            g2.setFont(new Font("arial", Font.BOLD, sizeFont));
        }
        else
            g2.setFont(new Font("arial", Font.PLAIN, sizeFont));
        g2.setStroke(new BasicStroke(1.0f));

        if (timeScale<1440)
        {
            for (int i = 0; i < 24; i++)
            {
                curX = xx;
                curY = yy + i * 1800 / timeScale;
                g2.setColor(traits);
                g2.drawLine(curX, curY, w - leftMargin, curY);
                String time = "" + i;
                if (i < 10)
                {
                    time = "0" + time;
                }
                if (MainClass.timeType == MainClass.TIME12)
                {
                    if (Integer.valueOf(time).intValue()<12)
                    {
                        if (time.equals("00"))
                            time = "12";
                        time = time.concat("AM");
                    }
                    else
                    {
                        if (i > 12)
                        {
                            time = "" + (i-12);
                            if (i-12 < 10)
                            {
                                time = "0" + time;
                            }
                        }
                        time = time.concat("PM");
                    }
                }
                g2.setColor(police);
                g2.drawString(time, curX, curY + 22);
            }
            curX = xx;
            curY = yy + 24 * 1800 / timeScale;
            g2.setColor(traits);
            g2.drawLine(curX, curY, w - leftMargin, curY);

            //g2.setFont(new Font("arial", Font.BOLD, 12));
            if (timeScale == ts30)
            {
                for (int i = 0; i < 24; i++)
                {
                    curX = xx + w / 2 + 5;
                    curY = yy + i * 1800 / timeScale;
                    g2.setColor(police);
                    g2.drawString(space + "00", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 30;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "30", curX - leftMargin, curY + 22);
                }
            }
            else if (timeScale == ts15)
            {
                for (int i = 0; i < 24; i++)
                {
                    curX = xx + w / 2 + 5;
                    curY = yy + i * 1800 / timeScale;
                    g2.setColor(police);
                    g2.drawString(space + "00", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 30;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "15", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 60;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "30", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 90;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "45", curX - leftMargin, curY + 22);
                }
            }
            else if (timeScale == ts10)
            {
                for (int i = 0; i < 24; i++)
                {
                    curX = xx + w / 2 + 5;
                    curY = yy + i * 1800 / timeScale;
                    g2.setColor(police);
                    g2.drawString(space + "00", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 30;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "10", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 60;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "20", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 90;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "30", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 120;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "40", curX - leftMargin, curY + 22);
                    curY = yy + i * 1800 / timeScale + 150;
                    g2.setColor(traits);
                    g2.drawLine(curX - leftMargin, curY, w - leftMargin, curY);
                    g2.setColor(police);
                    g2.drawString(space + "50", curX - leftMargin, curY + 22);
                }
            }
        }
        else
        {
            for (int i = 0; i < nbjoursdansmois; i++)
            {
                curX = xx;
                curY = yy + i * 1800 * 24 / timeScale;
                g2.setColor(traits);
                g2.drawLine(curX, curY, w - leftMargin, curY);
                String jmois = "" + (i+1);
                g2.setColor(police);
                g2.drawString(jmois, curX, curY + 22);
            }
            curX = xx;
            curY = yy + nbjoursdansmois * 1800 * 24 / timeScale;
            g2.setColor(traits);
            g2.drawLine(curX, curY, w - leftMargin, curY);
        }
    }
}
