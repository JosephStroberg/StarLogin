package StarLogin.IHM;

import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.IHM.components.Options;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Groups;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.tree.*;

/**
 *
 * @author Francois DESCHAMPS
 */
public class ListeClientForm extends JFrame
{
    private final StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Record client;
    private Records clients;
    private Records vClients;//champs visibles seulement
    private DataGrid dgrClients;
    private String clientID;
    private final String sFRQ = ",GROUPEID,NOTE,PICTURE";
    private final String sFRQv = ",GROUPEID";
    String listeChampsVisibles;
    String listeTousChamps;
    private String sQuery;
    private String sQueryV;
    private boolean bFilter = false;
    private String filter;
    private final int HAUTEUR_CHAMP = 22;
    private final int LARGEUR_CHAMP = 200;
    private ImageIcon picture;
    private String classname = this.getClass().getName();
    public String currentDirectory = null;
    private DefaultComboBoxModel cmGroupes; //liste des identifiants de groupes
    private DefaultComboBoxModel cmLookFor; //liste des champs
    private int clientRow = 0;
    private int nbOfClientRows = 0;
    private int saveClientRow = 0;
    /*private boolean bolClientAdding = false;
    private boolean bolClientEditing = false;
    private boolean bolClientDeleting = false;*/
    private final java.util.ResourceBundle bundle = MainClass.bundle;
    private javax.swing.JLabel lblChamp[];
    private javax.swing.JTextField txtChamp[];
    private javax.swing.JPanel pnlChamp[];
    private String value[];
    private String note;
    private String groupeid;
    private TreePath selectedPath;
    private DefaultMutableTreeNode top;
    private ArrayList treeNodes;
    private boolean bolDragging = false;
    private TreePath PathSource;
    private boolean bolChangingGroupName = false;
    private Groups treeGroup;        
    private javax.swing.JTree arbreContacts;
    ArrayList champs;
    ArrayList sizes;
    ArrayList alias;
    ArrayList vchamps;
    ArrayList vsizes;
    ArrayList valias;
    private JLabel lblGroupe;
    private JComboBox cboGroupes;
    private String strGroup;
    public boolean bolClickFromGrid = false;
    private String orderby = " ORDER BY FIRSTNAME,OTHERNAMES";
    private final Window parentForm;
    private boolean bdelete = false;
    
    public String getCurrentClientID()
    {
        return clients.getIDFromRow(clientRow);
    }
    
    public void saveColOrder()
    {
        if (dgrClients == null)
            return;
        JTable tbl = dgrClients.getTable();
        String listeChamps = "";
        for (int i=1; i<tbl.getColumnCount()-3; i++)
        {
            String colName = tbl.getColumnName(i);
            for (int j=1; j<vchamps.size(); j++)
            {
                if (String.valueOf(valias.get(j)).equals(colName))
                {
                    colName = String.valueOf(vchamps.get(j));
                }
            }
            if (!colName.equals("ID"))
                listeChamps = listeChamps.concat(colName).concat(",");
        }
        listeChamps = listeChamps.substring(0, listeChamps.length() - 1);
        listeChampsVisibles = listeChamps;
        starLoginManager.updateDataBase("UPDATE ordrechamps SET LISTECHAMPSVISIBLES='" + listeChamps + "' WHERE NOMTABLE='clients'");
    }
    
    public void setPicture(ImageIcon data)
    {
        picture = data;
    }
    
    private void setCombos()
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        DefaultComboBoxModel comboModel2;
        cmLookFor = new DefaultComboBoxModel();
   
        for (int i=1; i<alias.size()-3; i++)
        {
            comboModel.addElement(alias.get(i));
            cmLookFor.addElement(champs.get(i));
        }
        comboModel.addElement("");
        cboLookFor.setModel(comboModel);
        cboLookFor.setSelectedIndex(-1);
        cmGroupes = starLoginManager.getListe("SELECT ID,GROUPE FROM groupes ORDER BY parentid,GROUPE");
        comboModel2 = starLoginManager.getListe("SELECT GROUPE,ID FROM groupes ORDER BY parentid,GROUPE");
        cboGroupes.setModel(comboModel2);
    }
    
    public void setRow()
    {
        refreshRecord();
        saveClientRow = MainClass.getCurrentRow(clients, saveClientRow);
        showClient(saveClientRow);
    }

    public void removeFromGrid(int grdRow)
    {
        String id = clients.getIDFromRow(grdRow);
        starLoginManager.removeRecord(id, "clients");
        bdelete = true;
    }

    private void reloadPicture()
    {
        pnlPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, pnlPhoto.getPreferredSize());
        imageSurface.setToolTipText(null);
        pnlPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(picture);
        imageSurface.setMenuEnabled(false);
    }
    
    public ListeClientForm getForm()
    {
        return this;
    }

    /** Creates new form MainForm
     * @param parent */
    public ListeClientForm(JFrame parent)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        parentForm = parent;
        //btnLookFor1.setVisible(false);
        //bolClientSetting = true;
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/contacts.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        int pos = classname.lastIndexOf(".");
        if (pos>0)
            classname = classname.substring(pos+1);
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0],params[1],params[2],params[3]);
        this.setExtendedState(params[4]);
        
        String svaleur = Options.getDivider(classname, "jSplitPane2").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        int d = Integer.valueOf(svaleur).intValue();
        jSplitPane2.setDividerLocation(d);
        
        svaleur = Options.getDivider(classname, "pnlData").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        d = Integer.valueOf(svaleur).intValue();
        pnlData.setDividerLocation(d);
        
        svaleur = Options.getDivider(classname, "jSplitPane1").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        d = Integer.valueOf(svaleur).intValue();
        jSplitPane1.setDividerLocation(d);

        //initialize data
        treeGroup = starLoginManager.getGroups();

        top = treeGroup.getTopNode();

        BuildTree();
        SetTree();
        ExpandTree();
        
        //Add tree event listeners
        arbreContacts.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener()
        {
            @Override
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt)
            {
                arbreContactsValueChanged(evt);
            }
        });

        arbreContacts.addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
        {
            @Override
            public void mouseDragged(java.awt.event.MouseEvent evt)
            {
                arbreContactsMouseDragged(evt);
            }
        });

        arbreContacts.addMouseListener(new java.awt.event.MouseAdapter()
        {
            @Override
            public void mouseReleased(java.awt.event.MouseEvent evt)
            {
                arbreContactsMouseReleased(evt);
            }
        });
        mnuRemoveGroup.setVisible(true);

        arbreContacts.setSelectionRow(1);
        arbreContacts.setRootVisible(false);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void addMouseListenerToTree(JTree tree)
    {
        final JTree treeView = tree;

        MouseAdapter mouseListener = new MouseAdapter()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                if (e.getButton() == 3)
                {
                    TreePath path = treeView.getSelectionPath();
                    if (path != null)
                    {
                        selectedPath = path;
                        mnuPop1.show(treeView, e.getX(), e.getY());
                    }
                }
            }
        };
        treeView.addMouseListener(mouseListener);
        
        treeView.addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
        {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent evt)
            {
                TreePath path = treeView.getPathForLocation(evt.getX(), evt.getY());
                if (path != null)
                {
                    String groupe = String.valueOf(path.getLastPathComponent());
                    treeView.setToolTipText(starLoginManager.getStringFieldValue("GROUPES", "DESCRIPT", " WHERE GROUPE='" + groupe + "'"));
                }
            }
        });
    }

    private void arbreContactsValueChanged(javax.swing.event.TreeSelectionEvent evt)
    {
        TreePath path = evt.getPath();
        strGroup = path.getLastPathComponent().toString();
        groupeid = starLoginManager.getMainFieldID_S("groupes", "GROUPE", strGroup);
        //if (!bSelectKind)
        refreshRecord();
        showClient(clientID);
    }

    private void arbreContactsMouseDragged(java.awt.event.MouseEvent evt)
    {
        if (bolDragging == false)
        {
            PathSource = arbreContacts.getClosestPathForLocation(evt.getX(), evt.getY());
            arbreContacts.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
            bolDragging = true;
        }
    }

    private void arbreContactsMouseReleased(java.awt.event.MouseEvent evt)
    {
        if (bolDragging == true)
        {
            bolDragging = false;
            arbreContacts.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            TreePath path = arbreContacts.getClosestPathForLocation(evt.getX(), evt.getY());
            String strDragDestination = path.getLastPathComponent().toString();
            String strDragSource = PathSource.getLastPathComponent().toString();
            if (!strDragDestination.equals(strDragSource))
            {
                String strDestinationID = treeGroup.getGroupID(strDragDestination);
                String strSourceID = treeGroup.getGroupID(strDragSource);
                boolean bolFound = false;
                String strParent = strDestinationID;

                while ((!strParent.equals("0")) && (bolFound == false))
                {
                    strParent = treeGroup.getParentID(strParent);
                    if (strParent.equals(strSourceID))
                    {
                        bolFound = true;
                    }
                }
                if (bolFound == true)
                {
                    JOptionPane.showMessageDialog(this, bundle.getString("MovingAGroup"), bundle.getString("CantMoveHere"), JOptionPane.INFORMATION_MESSAGE);
                }
                else
                {
                    starLoginManager.changeGroups(treeGroup, strDragSource, strDragDestination);
                    RebuildTree();
                }
            }
        }
    }
    private void ExpandTree()
    {
        for (int i = 0; i < arbreContacts.getRowCount(); i++)
        {
            arbreContacts.expandRow(i);
        }
        //arbreContacts.expandRow(0);
    }
    
    @SuppressWarnings("unchecked")
    private void saveExpand()
    {
        treeNodes = new ArrayList();
        for (int i = 0; i < arbreContacts.getRowCount(); i++)
        {
            treeNodes.add(arbreContacts.isExpanded(i));
        }
    }
    
    private void setExpand()
    {
        for (int i = 0; i < treeNodes.size(); i++)
        {
            /*Object obj = treeNodes.get(i);
            String sobj;
            boolean b = false;
            if (obj != null)
            {
                sobj = String.valueOf(obj);
                b = Boolean.valueOf(sobj);
            }
            if (b)
            {
                if(i < arbreContacts.getRowCount())
                    arbreContacts.expandRow(i);
            }*/
            arbreContacts.expandRow(i);
        }
    }

    private void BuildTree()
    {
        starLoginManager.recoverGroupsLostParents();
        treeGroup = starLoginManager.getGroups();
        top = treeGroup.getTopNode();
    }

    private void RemoveGroupAndChildren(String strSource)
    {
        String strID = treeGroup.getGroupID(strSource);

        int answer = JOptionPane.OK_OPTION;
        if (starLoginManager.getClientsInGroup(strID) == true)
        {
            String strGrp = treeGroup.getGroupName(strID);
            answer = JOptionPane.showConfirmDialog(this, bundle.getString("GroupOrSubGroup") + " " + strGrp + "\n" + bundle.getString("containingOneClient") + "\n" + bundle.getString("RemovingGroup?") + "\n" + bundle.getString("IfYesRemoveGroup"), bundle.getString("RemovingGroup"), JOptionPane.YES_NO_OPTION);
        }
        if (answer == JOptionPane.OK_OPTION)
        {
            if (starLoginManager.removeGroup(treeGroup, strID) == false)
            {
                JOptionPane.showMessageDialog(this, bundle.getString("FailRemoveGroup"));
            }
            RebuildTree();
        }
    }

    public void RebuildTree()
    {
        saveExpand();
        BuildTree();
        TreeModel treeModel = new DefaultTreeModel(top);
        arbreContacts.setModel(treeModel);
        //ExpandTree();
        setExpand();
    }

    private void SetTree()
    {
        arbreContacts = new JTree(top);
        arbreContacts.setDragEnabled(true);
        arbreContacts.setEditable(true);
        arbreContacts.setInvokesStopCellEditing(true);
        arbreContacts.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        arbreContacts.setAutoscrolls(true);
        arbreContacts.setRootVisible(true);
        arbreContacts.setShowsRootHandles(false);

        arbreContacts.setTransferHandler(new TransferHandler()
        {
            final JTree tree = arbreContacts;
            final DefaultTreeModel model = (DefaultTreeModel) tree.getModel();

            @Override
            public boolean canImport(TransferHandler.TransferSupport support)
            {
                if (!support.isDataFlavorSupported(DataFlavor.stringFlavor) || !support.isDrop())
                {
                    return false;
                }
                JTree.DropLocation dropLocation = (JTree.DropLocation) support.getDropLocation();
                return dropLocation.getPath() != null;
            }

            @Override
            public boolean importData(TransferHandler.TransferSupport support)
            {
                if (!canImport(support))
                {
                    return false;
                }
                JTree.DropLocation dropLocation = (JTree.DropLocation) support.getDropLocation();
                TreePath path = dropLocation.getPath();
                Transferable transferable = support.getTransferable();

                String transferData;
                try
                {
                    transferData = (String) transferable.getTransferData(DataFlavor.stringFlavor);
                }
                catch (IOException e)
                {
                    return false;
                }
                catch (UnsupportedFlavorException e)
                {
                    return false;
                }

                int childIndex = dropLocation.getChildIndex();
                if (childIndex == -1)
                {
                    childIndex = model.getChildCount(path.getLastPathComponent());
                }

                DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(transferData);
                DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) path.getLastPathComponent();
                model.insertNodeInto(newNode, parentNode, childIndex);

                TreePath newPath = path.pathByAddingChild(newNode);
                tree.makeVisible(newPath);
                tree.scrollRectToVisible(tree.getPathBounds(newPath));
                return true;
            }
        });

        addMouseListenerToTree(arbreContacts);
        final TreeCellEditor treeCellEditor = arbreContacts.getCellEditor();
        treeCellEditor.addCellEditorListener(new CellEditorListener()
        {
            final JTree tree = arbreContacts;

            @Override
            public void editingStopped(ChangeEvent e)
            {
                if (bolChangingGroupName == false)
                {
                    Object value = treeCellEditor.getCellEditorValue();
                    String strGrp = value.toString();
                    TreePath path = tree.getSelectionPath();
                    if (path != null && path.getLastPathComponent() != null)
                    {
                        String strOldGroup = path.getLastPathComponent().toString();
                        bolChangingGroupName = true;

                        if (treeGroup.isExistingGroupName(strGrp) == true)
                        {
                            JOptionPane.showMessageDialog(null, bundle.getString("GroupNameModification"),
                                                          bundle.getString("ExistingGroupName") + bundle.getString("SelectNewName"), JOptionPane.INFORMATION_MESSAGE);
                        }
                        else
                        {
                            if (strGrp.equals(""))
                            {
                                JOptionPane.showMessageDialog(null, bundle.getString("NoEmptyGroupName"));
                            }
                            else
                            {
                                if (starLoginManager.changeGroupName(strOldGroup, strGrp) == true)
                                {
                                    treeCellEditor.cancelCellEditing();
                                    RebuildTree();
                                }
                                bolChangingGroupName = false;
                            }
                        }
                    }
                }
            }

            @Override
            public void editingCanceled(ChangeEvent e)
            {
            }

            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    treeCellEditor.stopCellEditing();
                }
            }
        });
        pnlGroupesContacts.getViewport().setView(arbreContacts);
    }
    
    public void setOrder(String order)
    {
        orderby = order;
        refreshRecord();
        showClient(clientID);
    }
    
    public void setClient(boolean bAdding, String clientid)
    {
        //bolClientAdding = bAdding;
        clientID = clientid;
        groupeid = starLoginManager.getStringFieldValue("clients", "GROUPEID", " WHERE ID=" + clientID);
        if (groupeid.equals("-1")||groupeid.equals(""))
            groupeid = starLoginManager.getMainFieldID_S("groupes", "GROUPE", strGroup);
        else
        {
            strGroup = starLoginManager.getStringFieldValue("groupes", "GROUPE", " WHERE ID=" + groupeid);
            TreePath clientPath = new TreePath(strGroup);
            arbreContacts.scrollPathToVisible(clientPath);
        }
        refreshRecord();
        showClient(clientID);
    }

    public void refreshRecord()
    {
        listeChampsVisibles = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPSVISIBLES", " WHERE NOMTABLE='Clients'");
        listeTousChamps = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPS", " WHERE NOMTABLE='Clients'");
        sQueryV = "SELECT clients.ID,".concat(listeChampsVisibles).concat(sFRQv).concat(" FROM clients");
        sQuery = "SELECT clients.ID,".concat(listeTousChamps).concat(sFRQ).concat(" FROM clients");
        if (filter == null||filter.equals(""))
            filter = "1=1";
            
        if (groupeid.equals(""))
            groupeid = starLoginManager.getMainFieldID_S("groupes", "GROUPE", strGroup);
            
        clients = starLoginManager.getRecords(sQuery.concat(" left join groupes on clients.groupeid=groupes.id WHERE " + filter + " AND (groupeid=" + groupeid + " or groupeid in (select groupes.id from groupes where parentid=" + groupeid + ") or parentid in (select groupes.id from groupes where parentid=" + groupeid + ") or parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid=" + groupeid + ")) or parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid=" + groupeid + "))))" + orderby), "clients");
        vClients = starLoginManager.getRecords(sQueryV.concat(" left join groupes on clients.groupeid=groupes.id WHERE " + filter + " AND (groupeid=" + groupeid + " or groupeid in (select groupes.id from groupes where parentid=" + groupeid + ") or parentid in (select groupes.id from groupes where parentid=" + groupeid + ") or parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid=" + groupeid + ")) or parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid in (select groupes.id from groupes where parentid=" + groupeid + "))))" + orderby), "clients");
        champs = clients.getFields();
        sizes = clients.getSizes();
        alias = clients.getHeaders();
        vchamps = vClients.getFields();
        vsizes = vClients.getSizes();
        valias = vClients.getHeaders();
        value = new String[sizes.size()];
        pnlChamp = new JPanel[champs.size()];//+1];
        lblChamp = new JLabel[champs.size()];
        txtChamp = new JTextField[champs.size()];
        pnlChamps.removeAll();

        lblGroupe = new JLabel();
        cboGroupes = new JComboBox();
        cboGroupes.setEnabled(false);

        lblGroupe.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGroupe.setAlignmentX(1.0F);
        lblGroupe.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblGroupe.setIconTextGap(0);
        lblGroupe.setOpaque(true);
        lblGroupe.setPreferredSize(new java.awt.Dimension(LARGEUR_CHAMP, HAUTEUR_CHAMP));

        cboGroupes.setMaximumRowCount(20);
        cboGroupes.setAutoscrolls(true);
        cboGroupes.setKeySelectionManager(new MultiKeySelectionManager());
        cboGroupes.setName("");
        int div = pnlData.getDividerLocation();
        cboGroupes.setPreferredSize(new java.awt.Dimension(div - 219, HAUTEUR_CHAMP));
        cboGroupes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        scrChamps.getVerticalScrollBar().setUnitIncrement(HAUTEUR_CHAMP);
        scrChamps.getVerticalScrollBar().setBlockIncrement(scrChamps.getHeight() / 5);
        for (int i = 1; i < champs.size() - 3; i++)
        {
            pnlChamp[i] = new JPanel();
            lblChamp[i] = new JLabel();
            txtChamp[i] = new JTextField();
            txtChamp[i].setEditable(false);

            pnlChamp[i].setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
            pnlChamp[i].setPreferredSize(new java.awt.Dimension(div - 19, HAUTEUR_CHAMP));

            lblChamp[i].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            lblChamp[i].setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
            lblChamp[i].setOpaque(true);
            lblChamp[i].setPreferredSize(new java.awt.Dimension(LARGEUR_CHAMP, HAUTEUR_CHAMP));
            pnlChamp[i].add(lblChamp[i]);

            txtChamp[i].setPreferredSize(new java.awt.Dimension(div - 219, HAUTEUR_CHAMP));
            pnlChamp[i].add(txtChamp[i]);

            pnlChamps.add(pnlChamp[i]);
        }
        pnlChamp[champs.size() - 3] = new JPanel();
        pnlChamp[champs.size() - 3].setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        pnlChamp[champs.size() - 3].setPreferredSize(new java.awt.Dimension(div - 19, HAUTEUR_CHAMP));
        pnlChamp[champs.size() - 3].add(lblGroupe);
        pnlChamp[champs.size() - 3].add(cboGroupes);
        pnlChamps.add(pnlChamp[champs.size() - 3]);
        pnlChamps.setPreferredSize(new Dimension(div, (HAUTEUR_CHAMP - 1) * (champs.size() - 3)));
        dgrClients = new DataGrid(vClients.getRecords(), valias, vchamps, vsizes, pnlGrid, false, true, false, false, this, true, 0);
        dgrClients.getTable().setToolTipText(bundle.getString("DoubleClic2Modify"));
        setCombos();
        //showClient(clientID);
        resetLangue();
        
        if (bdelete)
            pnlGrid.paintAll(pnlGrid.getGraphics());
        bdelete = false;
    }
    
    public String getGroupID()
    {
        return groupeid;
    }
    
    public String getClientID()
    {
        return clientID;
    }
    
    private void removeRec()
    {
        //if ((bolClientAdding == false) && (bolClientEditing == false) && (bolClientDeleting == false))
        //{
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                JTable tbl = dgrClients.getTable();
                int row[] = tbl.getSelectedRows();
                for (int i = 0; i < tbl.getSelectedRowCount(); i++)
                {
                    clientID = null2String(tbl.getValueAt(row[i], 0));
                    if (!clientID.equals("-1"))
                    {
                        starLoginManager.updateDataBase("DELETE FROM clients WHERE ID=" + clientID);
                    }
                }
                bdelete = true;
                setRow();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        //}
    }
/*
    public boolean isClientEditing()
    {
        return bolClientEditing;
    }

    public void setClientEditing(boolean data)
    {
        bolClientEditing = data;
    }*/

    public void showClient(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        //bolClientSetting = true;
        clientID = clients.getIDFromRow(row);
        showClient(clientID);
        clientRow = row;
        //bolClientSetting = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    public void showClient(String strID)
    {
        //bolClientSetting = true;
        clientID = strID;
        if (clientID == null || clientID.equals(""))
            clientID = "-1";
        if (filter == null)
            filter = "";
        if (filter.equals(""))
            filter = "1=1";
        String sql = "SELECT ID,".concat(listeTousChamps).concat(sFRQ).concat(" FROM clients");
        if (clientID == null||clientID.equals(""))
            clientID = "-1";
        client = starLoginManager.getRecord(sql + " WHERE " + filter + " AND ID=" + clientID + orderby, "clients", " WHERE " + filter);
        
        //dbr = starLoginManager.getDBRecord();
        clientRow = client.getRow();
        saveClientRow = clientRow;
        
        if (bolClickFromGrid == false)
            dgrClients.setSelectedRow(saveClientRow);
        else
            bolClickFromGrid = false;
        
        nbOfClientRows = client.getRowNB();

        for (int i = 1; i < champs.size() - 3; i++)
        {
            value[i] = client.getData(i);
        }
        note = client.getData(champs.size() - 2);
        picture = client.getPicture();
        groupeid = client.getData(champs.size() - 3);
        reloadPicture();

        //bolClientSetting = true;
        setDataToText();
        //bolClientSetting = false;
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("ListeClientForm"));
        lblGroupe.setText(bundle.getString("Groupe"));
        btnLookFor.setText(bundle.getString("LookFor"));
        btnLookFor1.setText(bundle.getString("TraitementDonnees"));
        for (int i=1; i< champs.size()-3; i++)
        {
            lblChamp[i].setText(String.valueOf(alias.get(i)));
        }
        btnAddClient.setText(bundle.getString("Add"));
        btnRemoveClient.setText(bundle.getString("Remove"));
        btnSelectFields.setText(bundle.getString("SelectFields"));
        btnModify.setText(bundle.getString("Modifier"));
        btnFilter.setText(bundle.getString("Filter"));
        mnuAddGroup.setText(bundle.getString("AddAGroup"));
        mnuRemoveGroup.setText(bundle.getString("RemoveTheGroup"));
        mnuRenameGroup.setText(bundle.getString("RenameTheGroup"));
    }

    private void setDataToText()
    {
        //bolClientSetting = true;
        
        if (clientRow > nbOfClientRows)
        {
            clientRow = nbOfClientRows;
        }

        for (int i=1; i<champs.size() - 3; i++)
        {
            txtChamp[i].setText(value[i]);
        }
        txtNote.setText(note);
        cboGroupes.setSelectedIndex(cmGroupes.getIndexOf(groupeid));
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mnuPop1 = new javax.swing.JPopupMenu();
        mnuAddGroup = new javax.swing.JMenuItem();
        mnuRemoveGroup = new javax.swing.JMenuItem();
        mnuRenameGroup = new javax.swing.JMenuItem();
        pnlBoutons = new javax.swing.JPanel();
        btnAddClient = new javax.swing.JButton();
        btnRemoveClient = new javax.swing.JButton();
        btnModify = new javax.swing.JButton();
        btnLookFor1 = new javax.swing.JButton();
        btnSelectFields = new javax.swing.JButton();
        pnlLookFor = new javax.swing.JPanel();
        cboLookFor = new javax.swing.JComboBox();
        txtLookFor = new javax.swing.JTextField();
        btnLookFor = new javax.swing.JButton();
        btnFilter = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        pnlInfos = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        pnlPhoto = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        pnlData = new javax.swing.JSplitPane();
        scrChamps = new javax.swing.JScrollPane();
        pnlChamps = new javax.swing.JPanel();
        scrNote = new javax.swing.JScrollPane();
        txtNote = new javax.swing.JTextArea();
        pnlGridContacts = new javax.swing.JPanel();
        jSplitPane2 = new javax.swing.JSplitPane();
        pnlContacts = new javax.swing.JPanel();
        pnlGroupesContacts = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        pnlGrid0 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        pnlGrid = new javax.swing.JPanel();

        mnuAddGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAddGroupActionPerformed(evt);
            }
        });
        mnuPop1.add(mnuAddGroup);

        mnuRemoveGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuRemoveGroupActionPerformed(evt);
            }
        });
        mnuPop1.add(mnuRemoveGroup);

        mnuRenameGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuRenameGroupActionPerformed(evt);
            }
        });
        mnuPop1.add(mnuRenameGroup);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        setTitle(bundle.getString("Contacts")); // NOI18N
        setExtendedState(4);
        setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        setMinimumSize(new java.awt.Dimension(1010, 680));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        pnlBoutons.setPreferredSize(new java.awt.Dimension(1000, 72));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        btnAddClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddClient.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddClient.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAddClient.setMaximumSize(new java.awt.Dimension(31, 31));
        btnAddClient.setMinimumSize(new java.awt.Dimension(29, 29));
        btnAddClient.setPreferredSize(new java.awt.Dimension(150, 32));
        btnAddClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddClientActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddClient);

        btnRemoveClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveClient.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemoveClient.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemoveClient.setMaximumSize(new java.awt.Dimension(31, 31));
        btnRemoveClient.setMinimumSize(new java.awt.Dimension(29, 29));
        btnRemoveClient.setPreferredSize(new java.awt.Dimension(150, 32));
        btnRemoveClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveClientActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveClient);

        btnModify.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png"))); // NOI18N
        btnModify.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnModify.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnModify.setMaximumSize(new java.awt.Dimension(31, 31));
        btnModify.setMinimumSize(new java.awt.Dimension(29, 29));
        btnModify.setPreferredSize(new java.awt.Dimension(150, 32));
        btnModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModifyActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnModify);

        btnLookFor1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
        btnLookFor1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor1.setPreferredSize(new java.awt.Dimension(220, 32));
        btnLookFor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookFor1ActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnLookFor1);

        btnSelectFields.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/selected.png"))); // NOI18N
        btnSelectFields.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSelectFields.setPreferredSize(new java.awt.Dimension(220, 32));
        btnSelectFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectFieldsActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnSelectFields);

        pnlLookFor.setPreferredSize(new java.awt.Dimension(560, 32));
        pnlLookFor.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        cboLookFor.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlLookFor.add(cboLookFor);

        txtLookFor.setPreferredSize(new java.awt.Dimension(140, 30));
        pnlLookFor.add(txtLookFor);

        btnLookFor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/lookfor.png"))); // NOI18N
        btnLookFor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor.setPreferredSize(new java.awt.Dimension(200, 32));
        btnLookFor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookForActionPerformed(evt);
            }
        });
        pnlLookFor.add(btnLookFor);

        pnlBoutons.add(pnlLookFor);

        btnFilter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/filtrer.png"))); // NOI18N
        btnFilter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFilter.setPreferredSize(new java.awt.Dimension(150, 32));
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnFilter);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        jSplitPane1.setBorder(null);
        jSplitPane1.setDividerLocation(300);
        jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        pnlInfos.setMinimumSize(new java.awt.Dimension(945, 220));
        pnlInfos.setPreferredSize(new java.awt.Dimension(945, 256));
        pnlInfos.setLayout(new java.awt.BorderLayout());

        jPanel9.setLayout(new java.awt.BorderLayout());

        jPanel10.setPreferredSize(new java.awt.Dimension(100, 5));
        jPanel9.add(jPanel10, java.awt.BorderLayout.SOUTH);

        jPanel11.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel9.add(jPanel11, java.awt.BorderLayout.WEST);

        pnlPhoto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlPhoto.setPreferredSize(new java.awt.Dimension(324, 246));
        pnlPhoto.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        jPanel9.add(pnlPhoto, java.awt.BorderLayout.CENTER);

        jPanel12.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel9.add(jPanel12, java.awt.BorderLayout.EAST);

        pnlInfos.add(jPanel9, java.awt.BorderLayout.WEST);

        jPanel13.setLayout(new java.awt.BorderLayout());

        jPanel1.setPreferredSize(new java.awt.Dimension(100, 5));
        jPanel13.add(jPanel1, java.awt.BorderLayout.SOUTH);

        jPanel2.setPreferredSize(new java.awt.Dimension(5, 100));
        jPanel13.add(jPanel2, java.awt.BorderLayout.EAST);

        pnlData.setBorder(null);
        pnlData.setDividerLocation(425);
        pnlData.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                pnlDataPropertyChange(evt);
            }
        });

        scrChamps.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        scrChamps.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrChamps.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrChamps.setPreferredSize(new java.awt.Dimension(418, 246));

        pnlChamps.setOpaque(false);
        pnlChamps.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, -1));
        scrChamps.setViewportView(pnlChamps);

        pnlData.setLeftComponent(scrChamps);

        scrNote.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        scrNote.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrNote.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        txtNote.setColumns(20);
        txtNote.setEditable(false);
        txtNote.setLineWrap(true);
        scrNote.setViewportView(txtNote);

        pnlData.setRightComponent(scrNote);
        scrNote.getAccessibleContext().setAccessibleParent(pnlData);

        jPanel13.add(pnlData, java.awt.BorderLayout.CENTER);

        pnlInfos.add(jPanel13, java.awt.BorderLayout.CENTER);

        jSplitPane1.setRightComponent(pnlInfos);

        pnlGridContacts.setLayout(new java.awt.BorderLayout());

        jSplitPane2.setBorder(null);
        jSplitPane2.setDividerLocation(250);

        pnlContacts.setPreferredSize(new java.awt.Dimension(250, 100));
        pnlContacts.setLayout(new java.awt.BorderLayout());

        pnlGroupesContacts.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlContacts.add(pnlGroupesContacts, java.awt.BorderLayout.CENTER);

        jPanel4.setPreferredSize(new java.awt.Dimension(5, 100));
        pnlContacts.add(jPanel4, java.awt.BorderLayout.WEST);

        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));
        pnlContacts.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        jSplitPane2.setLeftComponent(pnlContacts);

        pnlGrid0.setLayout(new java.awt.BorderLayout());

        jPanel3.setPreferredSize(new java.awt.Dimension(5, 100));
        pnlGrid0.add(jPanel3, java.awt.BorderLayout.EAST);

        pnlGrid.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlGrid.setLayout(new java.awt.BorderLayout());
        pnlGrid0.add(pnlGrid, java.awt.BorderLayout.CENTER);

        jSplitPane2.setRightComponent(pnlGrid0);

        pnlGridContacts.add(jSplitPane2, java.awt.BorderLayout.CENTER);

        jSplitPane1.setLeftComponent(pnlGridContacts);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = this.getExtendedState();
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        
        int div = jSplitPane1.getDividerLocation();
        MainClass.options.setDivider(classname, "jSplitPane1", div);
        div = jSplitPane2.getDividerLocation();
        MainClass.options.setDivider(classname, "jSplitPane2", div);
        div = pnlData.getDividerLocation();
        MainClass.options.setDivider(classname, "pnlData", div);
        
        if (parentForm instanceof OrganizerForm)
        {
            ((OrganizerForm)parentForm).setContactsFrame(false);
        }
    }//GEN-LAST:event_formWindowClosing

    private void btnAddClientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddClientActionPerformed
    {//GEN-HEADEREND:event_btnAddClientActionPerformed
        //bolClientAdding = true;
        groupeid = starLoginManager.getMainFieldID_S("groupes", "GROUPE", strGroup);
        DialogClient dlgCl = new DialogClient(this, true, "-1", groupeid);
        //refreshRecord();
        //showClient(clientID);
    }//GEN-LAST:event_btnAddClientActionPerformed

    private void btnRemoveClientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveClientActionPerformed
    {//GEN-HEADEREND:event_btnRemoveClientActionPerformed
        removeRec();
    }//GEN-LAST:event_btnRemoveClientActionPerformed

    private void btnLookForActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookForActionPerformed
    {//GEN-HEADEREND:event_btnLookForActionPerformed
        Object ofield = cmLookFor.getElementAt(cboLookFor.getSelectedIndex());
        if (ofield == null)
            return;
        if (txtLookFor.getText().equals(""))
            return;
        String sText = txtLookFor.getText().replace("'", "''").toUpperCase();
        String sfield = String.valueOf(ofield);
        sfield = "UCASE(".concat(sfield).concat(")");
        String search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
        String search2 = sfield.concat(" Like '").concat(sText).concat("%'");
        String search3 = sfield.concat(" Like '%").concat(sText).concat("'");
        String search4 = sfield.concat(" ='").concat(sText).concat("'");
        String id = starLoginManager.getStringFieldValue("clients", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID>" + clientID + " AND " + filter));
        if (id.equals("-1"))
            id = starLoginManager.getStringFieldValue("clients", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID<" + clientID + " AND " + filter));
        showClient(id);
        int row = clients.getRowFromID(id);
        dgrClients.setSelectedRow(row);
    }//GEN-LAST:event_btnLookForActionPerformed

    private void btnLookFor1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookFor1ActionPerformed
    {//GEN-HEADEREND:event_btnLookFor1ActionPerformed
        DialogQueryTool gf;
        if (groupeid.equals("1"))
            gf = new DialogQueryTool(1, this, true);
        else if (groupeid.equals("2"))
            gf = new DialogQueryTool(2, this, true);
        else
            gf = new DialogQueryTool(0, this, true);
    }//GEN-LAST:event_btnLookFor1ActionPerformed

    private void mnuAddGroupActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuAddGroupActionPerformed
    {//GEN-HEADEREND:event_mnuAddGroupActionPerformed
        String strSource = selectedPath.getLastPathComponent().toString();
        String strNewGroup = "";
        while (strNewGroup.equals(""))
        {
            strNewGroup = JOptionPane.showInputDialog(this, bundle.getString("EnterNewGroup"), bundle.getString("NewGroup"));
            if (strNewGroup == null)
                return;
        }
        //strNewGroup = strNewGroup.toUpperCase();
        if (!strNewGroup.equals(""))
        {
            if (treeGroup.isExistingGroupName(strNewGroup))
            {
                JOptionPane.showMessageDialog(this, bundle.getString("AddingGroup"),
                                                    bundle.getString("ExistingGroupName") + bundle.getString("SelectNewName") + bundle.getString("CancelAddingGroup"), JOptionPane.INFORMATION_MESSAGE);
            }
            else
            {
                if (strNewGroup.equals(""))
                {
                    JOptionPane.showMessageDialog(this, bundle.getString("NoEmptyGroupName"));
                }
                else
                {
                    String strNewDescript = JOptionPane.showInputDialog(this, bundle.getString("EnterDescription"), bundle.getString("NewGroup"));
                    //strNewDescript = strNewDescript.toUpperCase();
                    if (starLoginManager.addGroup(treeGroup, strSource, strNewGroup, strNewDescript) == true)
                    {
                        RebuildTree();
                        groupeid = starLoginManager.getMainFieldID_S("groupes", "GROUPE", strNewGroup);
                    }
                }
            }
        }
    }//GEN-LAST:event_mnuAddGroupActionPerformed

    private void pnlDataPropertyChange(java.beans.PropertyChangeEvent evt)//GEN-FIRST:event_pnlDataPropertyChange
    {//GEN-HEADEREND:event_pnlDataPropertyChange
        if (champs == null)
            return;
        String propriete = evt.getPropertyName();
        if (propriete.equals("dividerLocation"))
        {
            int div = pnlData.getDividerLocation();
            for (int i = 1; i < champs.size() - 3; i++)
            {
                txtChamp[i].setPreferredSize(new Dimension(div - 219, HAUTEUR_CHAMP));
                pnlChamp[i].setPreferredSize(new Dimension(div, HAUTEUR_CHAMP));
            }
            cboGroupes.setPreferredSize(new Dimension(div - 219, HAUTEUR_CHAMP));
            pnlChamp[champs.size() - 3].setPreferredSize(new Dimension(div-19, HAUTEUR_CHAMP));
            pnlChamps.setPreferredSize(new Dimension(div, (HAUTEUR_CHAMP-1) * champs.size() - 4));
        }
    }//GEN-LAST:event_pnlDataPropertyChange

    private void btnSelectFieldsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSelectFieldsActionPerformed
    {//GEN-HEADEREND:event_btnSelectFieldsActionPerformed
        DlgSelectClientFields.ShowDialog();
        refreshRecord();
        showClient(clientID);
        //pnlChamps.paintAll(pnlChamps.getGraphics());
        //pnlGrid.paintImmediately(pnlGrid.getBounds());
        //Rectangle rec = this.getBounds();
        //this.setBounds(rec.x, rec.y, rec.width, rec.height-1);
        //this.setBounds(rec.x, rec.y, rec.width, rec.height+1);
    }//GEN-LAST:event_btnSelectFieldsActionPerformed

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFilterActionPerformed
    {//GEN-HEADEREND:event_btnFilterActionPerformed
        bFilter = !bFilter;
        if (!bFilter)
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            filter = "";
            cboLookFor.setSelectedIndex(-1);
            txtLookFor.setText("");
            refreshRecord();
            setDataToText();
        }
        else
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
            Object ofield = cmLookFor.getElementAt(cboLookFor.getSelectedIndex());
            if (ofield == null)
            {
                filter = "";
                refreshRecord();
                return;
            }
            if (txtLookFor.getText().equals(""))
            {
                filter = "";
                refreshRecord();
                return;
            }
            String sText = txtLookFor.getText().replace("'", "''").toUpperCase();
            String sfield = String.valueOf(ofield);
            String search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
            String search2 = sfield.concat(" Like '").concat(sText).concat("%'");
            String search3 = sfield.concat(" Like '%").concat(sText).concat("'");
            String search4 = sfield.concat(" ='").concat(sText).concat("'");
            filter = " (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") ");
            refreshRecord();
        }
        showClient(clientID);
    }//GEN-LAST:event_btnFilterActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowOpened
    {//GEN-HEADEREND:event_formWindowOpened
        String svaleur = Options.getDivider("ListeClientForm", "jSplitPane1").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        int d = Integer.valueOf(svaleur).intValue();
        jSplitPane1.setDividerLocation(d);
    }//GEN-LAST:event_formWindowOpened

    private void mnuRemoveGroupActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuRemoveGroupActionPerformed
    {//GEN-HEADEREND:event_mnuRemoveGroupActionPerformed
        String strSource = selectedPath.getLastPathComponent().toString();
        RemoveGroupAndChildren(strSource); 
    }//GEN-LAST:event_mnuRemoveGroupActionPerformed

    private void mnuRenameGroupActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuRenameGroupActionPerformed
    {//GEN-HEADEREND:event_mnuRenameGroupActionPerformed
        String strSource = selectedPath.getLastPathComponent().toString();
        String newName = JOptionPane.showInputDialog(bundle.getString("EnterNewGroupName"));
        if (starLoginManager.changeGroupName(strSource, newName) == true)
        {
            RebuildTree();
        }
        bolChangingGroupName = false;
    }//GEN-LAST:event_mnuRenameGroupActionPerformed

    private void btnModifyActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnModifyActionPerformed
    {//GEN-HEADEREND:event_btnModifyActionPerformed
        DialogClient dlgcli = new DialogClient(this, true, clientID);
        //refreshRecord();
        //showClient(clientID);
    }//GEN-LAST:event_btnModifyActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        int w = this.getBounds().width;
        if (w < 1600)
        {
            pnlBoutons.setPreferredSize(new Dimension(10,72));
            pnlBoutons.setSize(new Dimension(w,72));
        }
        else
        {
            pnlBoutons.setPreferredSize(new Dimension(10,36));
            pnlBoutons.setSize(new Dimension(w,36));
        }
        
        pnlBoutons.paintImmediately(pnlBoutons.getBounds());
        jSplitPane1.paintImmediately(jSplitPane1.getBounds());
        this.paintAll(this.getGraphics());
    }//GEN-LAST:event_formComponentResized

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddClient;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnLookFor;
    private javax.swing.JButton btnLookFor1;
    private javax.swing.JButton btnModify;
    private javax.swing.JButton btnRemoveClient;
    private javax.swing.JButton btnSelectFields;
    private javax.swing.JComboBox cboLookFor;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JMenuItem mnuAddGroup;
    private javax.swing.JPopupMenu mnuPop1;
    private javax.swing.JMenuItem mnuRemoveGroup;
    private javax.swing.JMenuItem mnuRenameGroup;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlChamps;
    private javax.swing.JPanel pnlContacts;
    private javax.swing.JSplitPane pnlData;
    private javax.swing.JPanel pnlGrid;
    private javax.swing.JPanel pnlGrid0;
    private javax.swing.JPanel pnlGridContacts;
    private javax.swing.JScrollPane pnlGroupesContacts;
    private javax.swing.JPanel pnlInfos;
    private javax.swing.JPanel pnlLookFor;
    private javax.swing.JPanel pnlPhoto;
    private javax.swing.JScrollPane scrChamps;
    private javax.swing.JScrollPane scrNote;
    private javax.swing.JTextField txtLookFor;
    private javax.swing.JTextArea txtNote;
    // End of variables declaration//GEN-END:variables
}
