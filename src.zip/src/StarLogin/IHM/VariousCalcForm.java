package StarLogin.IHM;


import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.*;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.*;
import com.wildcrest.j2printerworks.J2PanelPrinter;
import com.wildcrest.j2printerworks.J2Printer;
import com.wildcrest.j2printerworks.J2TextPrinter;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
import javax.swing.text.JTextComponent;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class VariousCalcForm extends JFrame
{
    private int choixAction = 0;
    private StarLogin.Systeme.Data.Event event;
    private String classname = this.getClass().getName();
    private int kc; //key code
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private ResourceBundle bundle = MainClass.bundle;
    private int riseSetPlanet;
    private Option defaultOption;
    private int moon;
    private int cp = 0;//caret position
    private Stars stars;
    private Asteroids asteroids;
    private Comets comets;
    private int saveAsteroidRow;
    private int saveCometRow;
    private int saveStarRow;
    private final int calendarsNumber = CalendarsKinds.getLast() + 1;
    private JPanel pnlCalendar[] = new JPanel[calendarsNumber];
    private JLabel lblCalendars[] = new JLabel[calendarsNumber];
    private JTextField txtCalendars[] = new JTextField[calendarsNumber];
    private String utDate = "";
    private String utTime = "";
    private String localDate = "";
    private String localTime = "";
    private String tz = "";
    private int currentUnit = 0;
    private int currentCalendar = 0;
    private int currentPlanetForEclipse;
    private JTextField txtUnit[] = new JTextField[Units.getLast() + 1];
    private JLabel lblUnit[] = new JLabel[Units.getLast() + 1];
    private JPanel pnlUnit[] = new JPanel[Units.getLast() + 1];
    private Asteroid asteroid;
    private Comet comet;
    private Star star;
    private String asteroidID;
    private String cometID;
    private String starID;
    private String asteroidName;
    private double starMagnitude;
    private int asteroidNumber;
    private double asteroidMeanAnomaly;
    private double asteroidMagnitude;
    private double asteroidEccentricity;
    private double asteroidPerihelionLongitude;
    private double asteroidNorthNodeLongitude;
    private double asteroidInclination;
    private double asteroidSemiMajorAxis;
    private double asteroidEpoch;
    private String cometName;
    private String cometPerihelionDate;
    private double cometPerihelionDistance;
    private double cometEccentricity;
    private double cometPerihelionLongitude;
    private double cometNorthNodeLongitude;
    private double cometInclination;
    private double cometSemiMajorAxis;
    private double cometPeriod;
    private String starIdentity;
    private String starName;
    private String starLuminosity;
    private double starRA;
    private double starD;
    private double starMotionRA;
    private double starMotionD;
    private double starVelocity;
    private double starDistance;
    private double starErrDist;
    private int starHR;
    private int asteroidRow;
    private int cometRow;
    private int starRow;
    private int asteroidNbOfRows;
    private int cometNbOfRows;
    private int starNbOfRows;
    private Color bgEdit = MainClass.options.getEditColor();
    private Color bgNormal = MainClass.options.getNormalColor();
    private boolean bolAsteroidAdding = false;
    private boolean bolAsteroidEditing = false;
    private boolean bolSetting = true;
    private boolean bolDeleting = false;
    private boolean bolCometAdding = false;
    private boolean bolCometEditing = false;
    private boolean bolStarAdding = false;
    private boolean bolStarEditing = false;
    private ImageIcon cometPhoto;
    private ImageIcon asteroidPhoto;
    private ImageIcon starPhoto;

    //initialization des parametres et du moyen mouvement pour calculs perihelie
    private static final double a[] =
    {
        2414995.007, 2415112.001, 2415021.546, 2415197.249, 2416640.769, 2409775.884
    };
    private static final double b[] =
    {
        87.96934997, 224.7008454, 365.2596415, 686.9958109, 4332.894244, 10764.18032
    };
    private static final double c[] =
    {
        0.0, -0.0000000304, 0.0000000152, 0.000000122, 0.0001267, 0.001342
    };
    private static final double n[] =
    {
        4.09233881, 1.60230472, 0.985609114, 0.524032833, 0.083091194, 0.033459639
    };
    //parameters for eccentricity calculation
    private static final double a0[] =
    {
        0.20561421, 0.00682069, 0.01675104, 0.0933129, 0.04833475, 0.05589232
    };
    private static final double a1[] =
    {
        0.00002046, -0.00004774, -0.0000418, 0.000092064, 0.00016418, -0.0003455
    };
    private static final double a2[] =
    {
        -0.0000003, 0.000000091, -0.000000126, -0.000000077, -0.0000004676, -0.000000728
    };
    private static final double a3[] =
    {
        0.0, 0.0, 0.0, 0.0, -0.0000000017, 0.00000000074
    };
    //mean anomaly and perihelion longitude for crossing nodes calculation
    private static final double ma0[] =
    {
        MainClass.astrobj[Planets.Mercury].getMeanAnomal0(), MainClass.astrobj[Planets.Venus].getMeanAnomal0(), MainClass.astrobj[Planets.Gaia].getMeanAnomal0(), MainClass.astrobj[Planets.Mars].getMeanAnomal0(), MainClass.astrobj[Planets.Jupiter].getMeanAnomal0(), MainClass.astrobj[Planets.Saturn].getMeanAnomal0()
    };
    private static final double ma1[] =
    {
        MainClass.astrobj[Planets.Mercury].getMeanAnomal1(), MainClass.astrobj[Planets.Venus].getMeanAnomal1(), MainClass.astrobj[Planets.Gaia].getMeanAnomal1(), MainClass.astrobj[Planets.Mars].getMeanAnomal1(), MainClass.astrobj[Planets.Jupiter].getMeanAnomal1(), MainClass.astrobj[Planets.Saturn].getMeanAnomal1()
    };
    private static final double al0[] =
    {
        MainClass.astrobj[Planets.Mercury].getArgLat0(), MainClass.astrobj[Planets.Venus].getArgLat0(), MainClass.astrobj[Planets.Gaia].getArgLat0(), MainClass.astrobj[Planets.Mars].getArgLat0(), MainClass.astrobj[Planets.Jupiter].getArgLat0(), MainClass.astrobj[Planets.Saturn].getArgLat0()
    };
    private static final double al1[] =
    {
        MainClass.astrobj[Planets.Mercury].getArgLat1(), MainClass.astrobj[Planets.Venus].getArgLat1(), MainClass.astrobj[Planets.Gaia].getArgLat1(), MainClass.astrobj[Planets.Mars].getArgLat1(), MainClass.astrobj[Planets.Jupiter].getArgLat1(), MainClass.astrobj[Planets.Saturn].getArgLat1()
    };
    private DrawRiseSet drawRiseSet;
    private RiseSetMeridian riseSetMeridian;
    private DrawEphemeris drawEphemeris;
    private JFrame parentForm;

    /** Creates new form VariousCalcForm */
    public VariousCalcForm(JFrame parent)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        event = MainForm.currentEvent;
        parentForm = parent;
        if (event == null)
        {
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            return;
        }
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        resetLangue();
        
        int pos = classname.lastIndexOf(".");
        if (pos>0)
            classname = classname.substring(pos+1);
        
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0],params[1],params[2],params[3]);
        this.setExtendedState(params[4]);
        
        drawEphemeris = new DrawEphemeris();
        drawEphemeris.setPreferredSize(new Dimension(750, 2550));
        scrollPanelGraphicsEphemeris.setViewportView(drawEphemeris);
        
        String svaleur = StarLogin.IHM.components.Options.getDivider(classname, "jSplitPane1").getValeur();
        if (svaleur == null||svaleur.equals(""))
            svaleur = "0";
        int d = Integer.valueOf(svaleur).intValue();
        jSplitPane1.setDividerLocation(d);

        //add scroll bars listener
        scrollPanelGraphicsEphemeris.getVerticalScrollBar().addAdjustmentListener(new java.awt.event.AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt)
            {
                if (bolSetting)
                {
                    return;
                }
                if (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum() == 0 || scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum() == 0)
                {
                    drawEphemeris.reFresh(0, 0);
                }
                else
                {
                    drawEphemeris.reFresh(scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getVisibleAmount() - drawEphemeris.getWidth()) / scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum(), scrollPanelGraphicsEphemeris.getVerticalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getVerticalScrollBar().getVisibleAmount() - drawEphemeris.getHeight()) / scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum());
                }
            }
        });

        scrollPanelGraphicsEphemeris.getHorizontalScrollBar().addAdjustmentListener(new java.awt.event.AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt)
            {
                if (bolSetting)
                {
                    return;
                }
                if (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum() == 0 || scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum() == 0)
                {
                    drawEphemeris.reFresh(0, 0);
                }
                else
                {
                    drawEphemeris.reFresh(scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getVisibleAmount() - drawEphemeris.getWidth()) / scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum(), scrollPanelGraphicsEphemeris.getVerticalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getVerticalScrollBar().getVisibleAmount() - drawEphemeris.getHeight()) / scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum());
                }
            }
        });

        defaultOption = MainClass.getCurrentOption();

        //add the components to panel for rise and set
        drawRiseSet = new DrawRiseSet();
        drawRiseSet.setLayout(new java.awt.BorderLayout());
        pnlRiseSet.add(drawRiseSet, java.awt.BorderLayout.CENTER);

        //set text area components for asteroids, comets, stars and eclipses
        btnNextEclipse.setVisible(false);
        txtResultAsteroid.setLineWrap(false);
        txtResultAsteroid.setMargin(new Insets(10, 10, 10, 10));
        txtResultAsteroid.setTabSize(25);
        txtResultComet.setLineWrap(false);
        txtResultComet.setMargin(new Insets(10, 10, 10, 10));
        txtResultComet.setTabSize(25);
        txtResultStar.setLineWrap(false);
        txtResultStar.setMargin(new Insets(10, 10, 10, 10));
        txtResultStar.setTabSize(25);
        txtResultEphemeris.setLineWrap(false);
        txtResultEphemeris.setMargin(new Insets(10, 10, 10, 10));
        txtResultEclipses.setLineWrap(false);
        txtResultEclipses.setMargin(new Insets(10, 10, 10, 10));
        txtResultEclipses.setTabSize(25);

        //set up the distances units
        for (int i = 0; i <= Units.getLast(); i++)
        {
            txtUnit[i] = new JTextField();
            lblUnit[i] = new JLabel();

            lblUnit[i].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            lblUnit[i].setText(Units.getName(i));
            lblUnit[i].setBorder(new javax.swing.border.LineBorder(java.awt.Color.gray));
            lblUnit[i].setPreferredSize(new java.awt.Dimension(190, 20));
            pnlUnits.add(lblUnit[i]);

            txtUnit[i].setHorizontalAlignment(javax.swing.JTextField.CENTER);
            txtUnit[i].setBorder(new javax.swing.border.LineBorder(java.awt.Color.gray));
            txtUnit[i].setPreferredSize(new java.awt.Dimension(190, 20));

            final int curUnit = i;
            txtUnit[i].addFocusListener(new java.awt.event.FocusAdapter()
            {
                @Override
                public void focusGained(java.awt.event.FocusEvent evt)
                {
                    currentUnit = curUnit;
                    for (int i = 0; i <= Units.getLast(); i++)
                    {
                        txtUnit[i].setBackground(txtDate.getBackground());
                        txtUnit[i].setForeground(txtDate.getForeground());
                    }
                    txtUnit[currentUnit].setBackground(txtDate.getSelectionColor());
                    txtUnit[currentUnit].setForeground(txtDate.getSelectedTextColor());
                }
            });

            txtUnit[i].addKeyListener(new java.awt.event.KeyAdapter()
            {
                @Override
                public void keyTyped(java.awt.event.KeyEvent evt)
                {
                    if (kc == KeyEvent.VK_ENTER)
                    {
                        String sVal = txtUnit[currentUnit].getText();
                        int pos = sVal.indexOf("E");
                        if (pos>0)
                        {
                            pos += 3;
                            int pos2 = sVal.indexOf("-");
                            if (pos2 > 0) pos += 1;
                            if (sVal.length() < pos) pos = sVal.length();
                            sVal = sVal.substring(0, pos);
                            txtUnit[currentUnit].setText(sVal);
                        }
                        calculateDistance();
                    }
                    else
                    {
                        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtUnit[curUnit], 16, kc);
                    }
                }

                @Override
                public void keyPressed(java.awt.event.KeyEvent evt)
                {
                    if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
                    if (kc == KeyEvent.VK_ESCAPE)
                    {
                        txtUnit[currentUnit].setText("");
                    }
                }
            });

            pnlUnits.add(txtUnit[i]);
        }

        //set up the calendars
        for (int i = 0; i < calendarsNumber; i++)
        {
            pnlCalendar[i] = new JPanel();
            lblCalendars[i] = new JLabel();
            txtCalendars[i] = new JTextField();

            lblCalendars[i].setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            lblCalendars[i].setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(0, 7, 0, 0)));
            lblCalendars[i].setPreferredSize(new java.awt.Dimension(165, 18));
            lblCalendars[i].setHorizontalTextPosition(javax.swing.SwingConstants.TRAILING);
            lblCalendars[i].setOpaque(true);
            lblCalendars[i].setText(CalendarsKinds.getName(i));

            pnlCalendar[i].add(lblCalendars[i]);

            txtCalendars[i].setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(204, 255, 255), new java.awt.Color(204, 255, 255), java.awt.Color.gray, java.awt.Color.gray));
            txtCalendars[i].setPreferredSize(new java.awt.Dimension(235, 21));
            
            final int curCalendar = i;
            txtCalendars[i].addFocusListener(new java.awt.event.FocusAdapter()
            {
                @Override
                public void focusGained(java.awt.event.FocusEvent evt)
                {
                    currentCalendar = curCalendar;
                    for (int i = 0; i <= CalendarsKinds.getLast(); i++)
                    {
                        //txtCalendars[i].setCaretColor(defaultOption.getColorTextZonesForeground());
                        txtCalendars[i].setBackground(txtDate.getBackground());
                        txtCalendars[i].setForeground(txtDate.getForeground());
                        txtCalendars[i].setText("");
                    }
                    //txtCalendars[curCalendar].setCaretColor(defaultOption.getColorTextZonesBackground());
                    txtCalendars[curCalendar].setBackground(txtDate.getSelectionColor());
                    txtCalendars[curCalendar].setForeground(txtDate.getSelectedTextColor());
                    String sdate = event.getLocalDate();
                    if (curCalendar == CalendarsKinds.ISRAELITE)
                    {
                        FDate fd = new FDate(sdate);
                        long day = fd.getDay();
                        if (day>30)
                            day = 30;
                        fd = new FDate(day, fd.getMonth(), fd.getYear(), " ");
                        sdate = fd.getFormatedDate();
                        if (!sdate.startsWith("-") && !sdate.startsWith(" "))
                            sdate = " ".concat(sdate);
                    }
                    if (curCalendar != CalendarsKinds.MAYA_LONG && curCalendar != CalendarsKinds.MAYA_TH)
                        txtCalendars[curCalendar].setText(sdate);
                }
            });

            txtCalendars[i].addKeyListener(new java.awt.event.KeyAdapter()
            {
                @Override
                public void keyTyped(java.awt.event.KeyEvent evt)
                {
                    char ch = evt.getKeyChar();

                    if (curCalendar != CalendarsKinds.MAYA_LONG && curCalendar != CalendarsKinds.MAYA_TH)
                    {
                        KTDateAstro d = new KTDateAstro(evt, txtCalendars[curCalendar], true, kc);
                        //int pos = txtCalendars[curCalendar].getCaretPosition();
                        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
                            txtCalendars[curCalendar].setCaretPosition(cp-1);
                    }
                    else if ((kc != KeyEvent.VK_SHIFT) && (kc != KeyEvent.VK_DELETE) && (kc != KeyEvent.VK_UP) && (kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_RIGHT) && (kc != KeyEvent.VK_LEFT) && (kc != KeyEvent.VK_TAB) && (kc != KeyEvent.VK_ENTER) && (kc != KeyEvent.VK_BACK_SPACE) && (!Character.isDigit(ch)) && (ch != '/') && (ch != '-'))
                    {
                        evt.consume();
                    }
                }

                @Override
                public void keyPressed(java.awt.event.KeyEvent evt)
                {
                    if (evt.getKeyCode() != KeyEvent.VK_ALT)
                    {
                        kc = evt.getKeyCode();
                        cp = txtCalendars[curCalendar].getCaretPosition();
                    }
                    if (curCalendar != CalendarsKinds.MAYA_LONG && curCalendar != CalendarsKinds.MAYA_TH)
                    {
                        KTDateAstro td;
                        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                            td = new KTDateAstro(evt, txtCalendars[curCalendar], true, kc);
                    }
                }
            });

            pnlCalendar[i].add(txtCalendars[i]);
            pnlCalendars.add(pnlCalendar[i]);
        }
        txtCalendars[CalendarsKinds.MAYA_TH].setEditable(false);

        //Add the icon
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/calc.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        //fill in the planets combo boxes
        String planet;
        for (byte i = 0; i <= Planets.Pluto; i++)
        {
            planet = MainForm.planetName[i];
            cboPlanet1Dist.addItem(planet);
            cboPlanet2Dist.addItem(planet);
            cboPlanetRiseSet.addItem(planet);
        }
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Mercury]);
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Venus]);
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Gaia]);
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Mars]);
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Jupiter]);
        cboPlanetPeri.addItem(MainForm.planetName[Planets.Saturn]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Mercury]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Venus]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Gaia]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Mars]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Jupiter]);
        cboPlanetNodes.addItem(MainForm.planetName[Planets.Saturn]);

        //fill in the coordinate combo box
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.TropicGeoLong));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.TropicHelioLong));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.SiderGeoLong));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.SiderHelioLong));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.GeoLat));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.HelioLat));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.RightAscension));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.Declination));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.Azimuth));
        cboCoordinate.addItem(Coordinate.getCoordinateName(Coordinate.Altitude));

        //init data (stars, asteroids, comets)
        initData();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        cboAsteroid.setMaximumRowCount(20);
        cboComet.setMaximumRowCount(20);
        cboStar.setMaximumRowCount(20);

        //update components from event data
        updateComponentsFromEvent();

        //change colors
        changeColors();

        bolSetting = false;
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    public void setChoix(int choix)
    {
        choixAction = choix;
    }
    
    public int getChoix()
    {
        return choixAction;
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        if (bolStarEditing)
        {
            starName = null2String(cboStar.getSelectedItem());
            if (!starName.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Star").concat(" ").concat(starName),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingStar"),bundle.getString("Star").concat(" ").concat(starName),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        else if (bolCometEditing)
        {
            cometName = null2String(cboComet.getSelectedItem());
            if (!cometName.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Comet").concat(" ").concat(cometName),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingComet"),bundle.getString("Comet").concat(" ").concat(cometName),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        else if (bolAsteroidEditing)
        {
            asteroidName = null2String(cboAsteroid.getSelectedItem());
            if (!asteroidName.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Asteroid").concat(" ").concat(asteroidName),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingAsteroid"),bundle.getString("Asteroid").concat(" ").concat(asteroidName),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void resetLangue()
    {
        mnuDelete.setText(bundle.getString("SUPPRIMER_L'ENREGISTREMENT_SELECTIONNE"));
        btnQueriesAsteroid.setToolTipText(bundle.getString("DataGrids"));
        btnQueriesComet.setToolTipText(bundle.getString("DataGrids"));
        btnQueriesStar.setToolTipText(bundle.getString("DataGrids"));
        setTitle(bundle.getString("VariousCalculations"));
        txtPlace.setToolTipText(bundle.getString("DoubleClick4List"));
        jLabel18.setText(bundle.getString("Place"));
        lblLatitude.setText(bundle.getString("Latitude"));
        lblLongitude.setText(bundle.getString("Longitude"));
        lblLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        lblLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        txtLatitude.setToolTipText(bundle.getString("LatitudeSudNeg"));
        txtLongitude.setToolTipText(bundle.getString("LongitudeEstNeg"));
        jLabel9.setText(bundle.getString("Date"));
        jLabel11.setText(bundle.getString("Hour"));
        optLocal.setText(bundle.getString("Local"));
        optUT.setText(bundle.getString("UT"));
        btnCalcTZ.setText(bundle.getString("TimeZoneAndDaylightSavingTime"));
        btnHinduCycles.setToolTipText(bundle.getString("HinduCycles"));
        btnProgressedMoon.setToolTipText(bundle.getString("ProgressedMoon"));
        btnCalculate.setText(bundle.getString("Calculate"));
        lblEphemeris.setText(bundle.getString("Coordinate"));
        jLabel26.setText(bundle.getString("Planet1"));
        jLabel27.setText(bundle.getString("Planet2"));
        jLabel28.setText(bundle.getString("ApparentAngle"));
        jLabel29.setText(bundle.getString("DistanceAU"));
        jLabel30.setText(bundle.getString("Planet"));
        jLabel31.setText(bundle.getString("RiseTime"));
        jLabel32.setText(bundle.getString("SetTime"));
        jLabel33.setText(bundle.getString("MeridianTime"));
        jLabel34.setText(bundle.getString("RisePosition"));
        jLabel35.setText(bundle.getString("SetPosition"));
        jLabel21.setText(bundle.getString("Place1"));
        jLabel24.setText(bundle.getString("Latitude"));
        jLabel25.setText(bundle.getString("Longitude"));
        jLabel40.setText(bundle.getString("Angle"));
        jLabel36.setText(bundle.getString("Latitude"));
        jLabel37.setText(bundle.getString("Longitude"));
        jLabel41.setText(bundle.getString("Angle"));
        jLabel43.setText(bundle.getString("DifferenceWithAlignment"));
        jLabel22.setText(bundle.getString("Place2"));
        jLabel23.setText(bundle.getString("Place3"));
        jLabel38.setText(bundle.getString("Latitude"));
        jLabel39.setText(bundle.getString("Longitude"));
        jLabel42.setText(bundle.getString("Angle"));
        jLabel13.setText(bundle.getString("Date"));
        jLabel62.setText(bundle.getString("GST0"));
        lblGST0.setToolTipText(bundle.getString("GreenwichSiderealTimeatMidnight"));
        tabCalc.setTitleAt(0, bundle.getString("GST0"));
        jLabel14.setText(bundle.getString("GregorianDate"));
        jLabel16.setText(bundle.getString("JulianDay"));
        tabCalc.setTitleAt(1, bundle.getString("JulianDay"));
        jLabel15.setText(bundle.getString("Sexagesimal"));
        jLabel17.setText(bundle.getString("Decimal"));
        tabCalc.setTitleAt(2, bundle.getString("Degrees"));
        jLabel76.setText(bundle.getString("AltitudeMeters"));
        jLabel77.setText(bundle.getString("GeographicalLatitude"));
        jLabel78.setText(bundle.getString("AstronomicalLatitude"));
        tabCalc.setTitleAt(3, bundle.getString("Latitudes"));
        jLabel79.setText(bundle.getString("Date"));
        jLabel80.setText(bundle.getString("WeekDayName"));
        lblWeekDayName.setToolTipText(bundle.getString("GreenwichSiderealTimeatMidnight"));
        tabCalc.setTitleAt(4, bundle.getString("WeekDay"));
        jLabel81.setText(bundle.getString("Year324"));
        jLabel82.setText(bundle.getString("EasterDate"));
        lblEasterDate.setToolTipText(bundle.getString("GreenwichSiderealTimeatMidnight"));
        tabCalc.setTitleAt(5, bundle.getString("Easter"));
        jLabel83.setText(bundle.getString("Longitude"));
        jLabel84.setText(bundle.getString("UTDate"));
        jLabel85.setText(bundle.getString("UTTime"));
        jLabel86.setText(bundle.getString("LocalSiderealTime"));
        tabCalc.setTitleAt(6, bundle.getString("Time"));
        jLabel2.setText(bundle.getString("Unit"));
        jLabel92.setText(bundle.getString("Distance"));
        tabCalc.setTitleAt(7, bundle.getString("Distance"));
        jLabel93.setText(bundle.getString("Date1"));
        jLabel95.setText(bundle.getString("Date2"));
        jLabel94.setText(bundle.getString("NomberOfDays"));
        lblNumberOfDays.setToolTipText(bundle.getString("GreenwichSiderealTimeatMidnight"));
        tabCalc.setTitleAt(8, bundle.getString("DaysBetweenDates"));
        jLabel54.setText(bundle.getString("Planet"));
        jLabel55.setText(bundle.getString("Year2"));
        jLabel56.setText(bundle.getString("Aphelion"));
        jLabel57.setText(bundle.getString("Perihelion"));
        jLabel58.setText(bundle.getString("Planet"));
        jLabel59.setText(bundle.getString("Year2"));
        jLabel60.setText(bundle.getString("NorthNode"));
        jLabel61.setText(bundle.getString("SouthNode"));
        jLabel10.setText(bundle.getString("Date"));
        jLabel12.setText(bundle.getString("Hour"));
        jLabel64.setText(bundle.getString("Phase"));
        jLabel65.setText(bundle.getString("Age"));
        lblMoonPhase.setToolTipText(bundle.getString("GreenwichSiderealTimeatMidnight"));
        jLabel63.setText(bundle.getString("Year2"));
        jLabel66.setText(bundle.getString("Date"));
        jLabel119.setText(bundle.getString("Eclipse"));
        jLabel118.setText(bundle.getString("Type"));
        lblHemi.setText(bundle.getString("Hemisphere"));
        lblHalfLight.setText(bundle.getString("HalfLightDuration"));
        lblShadow.setText(bundle.getString("ShadowDuration"));
        lblDim.setText(bundle.getString("Dimension"));
        jLabel71.setText(bundle.getString("Year2"));
        jLabel72.setText(bundle.getString("Spring"));
        jLabel73.setText(bundle.getString("Summer"));
        jLabel74.setText(bundle.getString("FallSeason"));
        jLabel75.setText(bundle.getString("Winter"));
        jLabelAsteroid.setText(bundle.getString("Asteroid"));
        //jSliderAsteroid.setToolTipText(bundle.getString("QuickMoving"));
        btnFirstAsteroid.setToolTipText(bundle.getString("FirstRecord"));
        btnPreviousAsteroid.setToolTipText(bundle.getString("PreviousRecord"));
        txtCounterAsteroid.setText(bundle.getString("NewAsteroid"));
        btnNextAsteroid.setToolTipText(bundle.getString("NextRecord"));
        btnLastAsteroid.setToolTipText(bundle.getString("LastRecord"));
        btnRemoveAsteroid.setToolTipText(bundle.getString("RemoveRecord"));
        btnAddAsteroid.setToolTipText(bundle.getString("AddRecord"));
        btnOKAsteroid.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS"));
        btnCancelAsteroid.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS"));
        jLabel87.setText(bundle.getString("Number"));
        jLabel99.setText(bundle.getString("MeanAnomaly"));
        jLabel88.setText(bundle.getString("HMagnitude"));
        jLabel89.setText(bundle.getString("Eccentricity"));
        jLabel90.setText(bundle.getString("PerihelionLongitude"));
        jLabel91.setText(bundle.getString("NorthNodeLongitude"));
        jLabel96.setText(bundle.getString("Inclination"));
        jLabel97.setText(bundle.getString("SemiMajorAxis"));
        jLabel98.setText(bundle.getString("Epoch"));
        jLabelComet.setText(bundle.getString("Comet"));
        //jSliderComet.setToolTipText(bundle.getString("QuickMoving"));
        btnFirstComet.setToolTipText(bundle.getString("FirstRecord"));
        btnPreviousComet.setToolTipText(bundle.getString("PreviousRecord"));
        txtCounterComet.setText(bundle.getString("NewComet"));
        btnNextComet.setToolTipText(bundle.getString("NextRecord"));
        btnLastComet.setToolTipText(bundle.getString("LastRecord"));
        btnRemoveComet.setToolTipText(bundle.getString("RemoveRecord"));
        btnAddComet.setToolTipText(bundle.getString("AddRecord"));
        btnOKComet.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS"));
        btnCancelComet.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS"));
        jLabel101.setText(bundle.getString("PerihelionDate"));
        jLabel103.setText(bundle.getString("PerihelionUA"));
        jLabel100.setText(bundle.getString("Eccentricity"));
        jLabel102.setText(bundle.getString("PerihelionLongitude"));
        jLabel105.setText(bundle.getString("NorthNodeLongitude"));
        jLabel106.setText(bundle.getString("Inclination"));
        jLabel107.setText(bundle.getString("SemiMajorAxis"));
        jLabel108.setText(bundle.getString("Period"));
        jLabelStar.setText(bundle.getString("Star"));
        //jSliderStar.setToolTipText(bundle.getString("QuickMoving"));
        btnFirstStar.setToolTipText(bundle.getString("FirstRecord"));
        btnPreviousStar.setToolTipText(bundle.getString("PreviousRecord"));
        txtCounterStar.setText(bundle.getString("NewStar"));
        btnNextStar.setToolTipText(bundle.getString("NextRecord"));
        btnLastStar.setToolTipText(bundle.getString("LastRecord"));
        btnRemoveStar.setToolTipText(bundle.getString("RemoveRecord"));
        btnAddStar.setToolTipText(bundle.getString("AddRecord"));
        btnOKStar.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS"));
        btnCancelStar.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS"));
        jLabel104.setText(bundle.getString("Name"));
        lblStarMagnitude.setText(bundle.getString("SpectralClassLuminosity"));
        jLabel110.setText(bundle.getString("RightAscension"));
        jLabel111.setText(bundle.getString("Declination"));
        jLabel112.setText(bundle.getString("ProperMotionRA"));
        jLabel113.setText(bundle.getString("ProperMotionD"));
        jLabel114.setText(bundle.getString("RadialVelocity"));
        jLabel115.setText(bundle.getString("DistanceAL"));
        jLabel116.setText(bundle.getString("DistError"));
        jLabel117.setText(bundle.getString("IdentifyingNumberHR"));
        jLabel120.setText(bundle.getString("Magnitude"));
        jLabel44.setText(bundle.getString("Place1"));
        jLabel45.setText(bundle.getString("Latitude"));
        jLabel46.setText(bundle.getString("Longitude"));
        jLabel48.setText(bundle.getString("Place2"));
        jLabel49.setText(bundle.getString("Latitude"));
        jLabel50.setText(bundle.getString("Longitude"));
        jLabel47.setText(bundle.getString("AngleBetweenAB"));
        JLabel1.setText(bundle.getString("DistanceBetweenAB"));
        jLabel67.setText(bundle.getString("SupposedYear"));
        jLabel6.setText(bundle.getString("PositionDegres"));
        jLabel6.getAccessibleContext().setAccessibleName(bundle.getString("PositionDegres"));
        jTextArea1.setText(bundle.getString("PlanetsToTake"));
        btnClear.setText(bundle.getString("Clear"));
    }

    private void changeColors()
    {
        //jPnlAsteroidPhoto.setBackground(defaultOption.getColorTextZonesBackground());
        setAsteroidNormalMode();
        //jPnlCometPhoto.setBackground(defaultOption.getColorTextZonesBackground());
        setCometNormalMode();
        //jPnlStarPhoto.setBackground(defaultOption.getColorTextZonesBackground());
        setStarNormalMode();
    }

    private void updateComponentsFromEvent()
    {
        utTime = event.getUtTime();
        tz = event.getTimeLag();
        txtTZ.setText(tz);
        utDate = event.getUtDate();
        localDate = event.getLocalDate();
        localTime = event.getLocalTime();
        optUT.setSelected(true);
        String latitude = event.getLatitude();
        String longitude = event.getLongitude();
        FLatitude l = new FLatitude(latitude);
        latitude = l.getLatitude();
        FLongitude lo = new FLongitude(longitude);
        longitude = lo.getLongitude();

        //update the place name
        txtPlace.setText(event.getPlace());

        //update latitude fields
        txtLatitude.setText(latitude);
        txtLatitudePlace1.setText(latitude);
        txtLatitudePlace2.setText(latitude);
        txtLatitudePlace3.setText(latitude);
        txtLatitudePlaceA.setText(latitude);
        txtLatitudePlaceB.setText(latitude);
        txtGeographical.setText(latitude);

        //update longitude fields
        txtLongitude.setText(longitude);
        txtSexagesimal.setText(longitude);
        txtLongitudeTime.setText(longitude);
        txtLongitudePlace1.setText(longitude);
        txtLongitudePlace2.setText(longitude);
        txtLongitudePlace3.setText(longitude);
        txtLongitudePlaceA.setText(longitude);
        txtLongitudePlaceB.setText(longitude);

        //update time fields
        txtTime.setText(utTime);
        txtTimePhases.setText(utTime);
        txtTimeTime.setText(utTime);

        //update date fields
        txtDate.setText(utDate);
        txtDate1.setText(utDate);
        txtDate2.setText(utDate);
        txtDateDayName.setText(utDate);
        txtDateGST0.setText(utDate);
        txtDatePhases.setText(utDate);
        txtDateTime.setText(utDate);
        txtGregorianDate.setText(utDate);

        //update year fields
        FDate fd = new FDate(utDate);
        long y = fd.getYear();
        String year = new Long(y).toString();
        txtEasterYear.setText(year);
        txtYearEclipses.setText(year);
        txtYearNodes.setText(year);
        txtYearPeri.setText(year);
        txtYearSeasons.setText(year);
    }

    public ChartEvent getChartEvent()
    {

        return new ChartEvent(event);
    }

    private Color getPlanetColor(int planet)
    {
        return defaultOption.getPlanetColor(planet);
    }

    public void getRiseSetData(int astre)
    {
        //Maximum number of calculations
        final int COMPTEUR_MAX = 20;
        //secular date
        double ct;
        //declination of the planet
        double declinaison;
        //Right ascension of the planet
        double ascension_droite;
        //UT hour of the rise or the set
        double heure;
        //hour in the previous loop
        double old_heure;
        //auxiliary variables
        double aux = 0.0;
        double aux2;
        //1 for evening ou -1 for morning
        int lc;
        //sidereal time
        double TS;
        //crossing meridian hour
        double TM;
        //UT hour in a string
        String strS;
        //flag for crossing meridian hour calculation
        boolean flag_calcul_meridien;
        //Moon paralax correction (0.61�) for the refraction
        double parallaxe_lune;
        //hour correction for the Moon
        double heure_lune_ini;
        //counter to avoid alternating and non-convergent values during
        //the calculation of the Moon crossing meridian hour
        int compteur;
        //coordinates in the current system
        double coord1;
        //time-lag
        double dblTimeLag = 0.0;
        //planetary position
        Planet p;
        Coord coord = new Coord();
        //result about rise set and meridian times
        RiseSetMeridian rsm = new RiseSetMeridian();
        //=============================================

        //INITIALIZATIONS
        //parallaxe_lune = 0.0;
        if (astre == Planets.Moon)
        {
            heure_lune_ini = -12.0;
        }
        else
        {
            heure_lune_ini = 0.0;
        }
        flag_calcul_meridien = false;

        StarLogin.Systeme.Data.Event ev = event.cloneEvent(event);

        //get the planetary position
        ChartEvent chartEvent = new ChartEvent(ev);

        //CALCULATION of the longitude of the planet for the rise and the set hours
        for (lc = -1; lc <= 1; lc++) //morning, { evening
        {
            if (lc == 0 && astre != Planets.Moon)
            {
                lc++;
            }
            compteur = 0;
            old_heure = -1;

            //initial hour for the calculation
            heure = 12.0 + heure_lune_ini;
            chartEvent.deduceValues(ev.getPlace(), ev.getPlaceLat(), ev.getPlaceLong(), heure, ev.getUtDate());

            //while the difference between the calculated position of the planet
            //for the estimate hour and the Right position (for the real hour) is too large,
            //and while the counter is lower than COMPTEUR_MAX
            while ((Math.abs(old_heure - heure) > 0.000001) && (compteur <= COMPTEUR_MAX))
            {
                //secular time
                ct = chartEvent.getCTimeH();
                old_heure = heure;

                //calculation of the position of the planet for the searched hour
                p = new Planet(chartEvent, false);
                coord = p.getObjPosition(astre);
                declinaison = coord.getDecl();
                ascension_droite = coord.getRA();
                parallaxe_lune = AstronomyMaths.asinD(Astronomy.EARTH_RADIUS / coord.getGeoDist());

                //calculation of the crossing meridian hour (for all planets but the Moon)
                if ((flag_calcul_meridien == false) && (astre != Planets.Moon))
                {
                    flag_calcul_meridien = true;
                    TS = chartEvent.getTSG0() + heure * AstronomyMaths.ST_ON_UT;
                    TM = TS - (chartEvent.getPlaceLong() + ascension_droite) / 15.0;
                    TM = AstronomyMaths.modulo(36.0 - TM, 24.0);

                    //local or legal hour from UT one
                    dblTimeLag = chartEvent.getTimeLag();
                    rsm.setMeridianTime(new FTime(AstronomyMaths.modulo(TM - dblTimeLag, 24.0)).getTime());
                }

                //CALCULATION of the hour
                if (lc == 0)
                {
                    //crossing meridian
                    aux = 0;
                }
                else
                {
                    //rise and set
                    aux = (AstronomyMaths.sinD(-0.61 + parallaxe_lune) - AstronomyMaths.sinD(chartEvent.getPlaceLat()) * AstronomyMaths.sinD(declinaison)) / AstronomyMaths.cosD(chartEvent.getPlaceLat()) / AstronomyMaths.cosD(declinaison);
                }

                //the calculation is not possible
                if (Math.abs(aux) > 1)
                {
                    if (lc == -1)
                    {
                        //rise
                        rsm.setRiseTime("");
                        rsm.setRisePosition("");
                    }
                    else
                    {
                        //set
                        rsm.setSetTime("");
                        rsm.setSetPosition("");
                    }
                    //to exit the loop
                    heure = old_heure;
                }
                //the calculation is possible
                else
                {
                    if (lc == 0)
                    {
                        aux2 = aux;
                    }
                    else
                    {
                        aux2 = 90.0 - AstronomyMaths.atnD(aux / Math.sqrt(1 - aux * aux));
                    }

                    if (astre == Planets.Moon)
                    {
                        if (lc == -1)
                        {
                            //rise
                            aux2 = 360.0 - aux2;
                        }
                        TS = (aux2 + ascension_droite + chartEvent.getPlaceLong()) / 15.0;
                    }
                    else
                    {
                        TS = (aux2 * lc + ascension_droite + chartEvent.getPlaceLong()) / 15.0;
                    }

                    while (TS < chartEvent.getTSG0())
                    {
                        TS += 24.0;
                    }
                    heure = AstronomyMaths.modulo((TS - chartEvent.getTSG0()) / AstronomyMaths.ST_ON_UT, 24.0);
                    chartEvent.deduceValues(ev.getPlace(), ev.getPlaceLat(), ev.getPlaceLong(), heure, ev.getUtDate());
                }
                compteur += 1;
            }

            //display results
            strS = new FTime(AstronomyMaths.modulo(heure - dblTimeLag, 24.0)).getTime();

            if (lc == -1)
            {
                rsm.setRiseTime(strS);
            }
            else
            {
                if (lc == 0)
                {
                    rsm.setMeridianTime(strS);
                    if ((compteur >= COMPTEUR_MAX) && (aux == 0))
                    {
                        rsm.setMeridianTime("");
                    }
                }
                else
                {
                    rsm.setSetTime(strS);
                }
            }

            //coordinate in the current system
            coord1 = coord.getCoord1(defaultOption.getCoordSys());
            strS = new FDegree(coord1).getSDegree();

            if (lc == -1)
            {
                rsm.setRisePosition(strS);
            }
            else
            {
                rsm.setSetPosition(strS);
            }
        }
        riseSetMeridian = rsm;
    }

    private void initData()
    {
        //get the data
        initAsteroidData("1");
        initCometData("1");
        initStarData("1");
    }

    public void showComet(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        cometID = comets.getIDFromRow(row);
        if (cometID.equals("-1"))
        {
            initCometData("-1");
            return;
        }
        showComet(cometID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void showComet(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        cometID = strID;
        comet = starLoginManager.getComet(cometID, "");
        cometRow = comet.getRow();
        cometNbOfRows = comet.getRowNB();
        if (strID.equals("-1"))
            txtCounterComet.setText(bundle.getString("NewComet"));
        else
        {
            saveCometRow = cometRow;
            txtCounterComet.setText(String.valueOf(cometRow) + " / " + String.valueOf(cometNbOfRows));
            //cometNbOfRows += 1;
        }
        cometPhoto = comet.getPicture();
        cometName = comet.getCometName();
        cometPerihelionDate = comet.getPerihelionDate();
        cometPerihelionDistance = comet.getPerihelionUA();
        cometEccentricity = comet.getEccentricity();
        cometPerihelionLongitude = comet.getPerihelionLongitude();
        cometNorthNodeLongitude = comet.getNorthNodeLongitude();
        cometInclination = comet.getInclination();
        cometSemiMajorAxis = comet.getSemiMajorAxis();
        cometPeriod = comet.getPeriod();

        setCometDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    public void showStar(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        starID = stars.getIDFromRow(row);
        if (starID.equals("-1"))
        {
            initStarData("-1");
            return;
        }
        showStar(starID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void showStar(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        starID = strID;
        star = starLoginManager.getStar(starID, "");
        starRow = star.getRow();
        starNbOfRows = star.getRowNB();
        if (strID.equals("-1"))
            txtCounterStar.setText(bundle.getString("NewStar"));
        else
        {
            saveStarRow = starRow;
            txtCounterStar.setText(String.valueOf(starRow) + " / " + String.valueOf(starNbOfRows));
            //starNbOfRows += 1;
        }
        starIdentity = star.getIdentity();
        starName = star.getStarName();
        starLuminosity = star.getLight();
        starRA = star.getRA();
        starD = star.getD();
        starMotionRA = star.getProperMotionRA();
        starMotionD = star.getProperMotionD();
        starVelocity = star.getRadialVelocity();
        starDistance = star.getDistance();
        starErrDist = star.getDistError();
        starHR = star.getHR();
        starMagnitude = star.getMagnitude();
        starPhoto = star.getPicture();

        setStarDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void initAsteroidData(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        setAsteroidCombos();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        if (strID.equals("-1"))
        {
            addAsteroidRecord();
            //bolAsteroidAdding = true;
        }
        else
        {
            showAsteroid(1);
        }
    }

    private void setAsteroidCombos()
    {
        bolSetting = true;
        asteroids = starLoginManager.getAsteroids();

        ArrayList getFields = asteroids.fieldsValues();
        DefaultComboBoxModel comboModel;

        comboModel = (DefaultComboBoxModel) getFields.get(1);
        cboAsteroid.setModel(comboModel);
        bolSetting = false;
    }

    private void refreshAsteroidRecord()
    {
        if ((bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            //show the asteroid data
            setAsteroidCombos();
            showAsteroid(saveAsteroidRow);
        }
    }

    private void initCometData(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        setCometCombos();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        if (strID.equals("-1"))
        {
            addCometRecord();//(strID);
            //cometNbOfRows += 1;
            //bolCometAdding = true;
            //cometRow += 1;
        }
        else
        {
            showComet(1);
        }
    }

    private void setCometCombos()
    {
        bolSetting = true;
        comets = starLoginManager.getComets();

        ArrayList getFields = comets.fieldsValues();
        DefaultComboBoxModel comboModel;

        comboModel = (DefaultComboBoxModel) getFields.get(1);
        cboComet.setModel(comboModel);
        bolSetting = false;
    }

    private void refreshCometRecord()
    {
        if ((bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            //show the comet data
            setCometCombos();
            showComet(saveCometRow);
        }
    }

    private void initStarData(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        setStarCombos();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        if (strID.equals("-1"))
        {
            addStarRecord();
            //starNbOfRows += 1;
            //bolStarAdding = true;
        }
        else
        {
            showStar(1);
        }
    }

    private void setStarCombos()
    {
        bolSetting = true;
        stars = starLoginManager.getStars();

        ArrayList getFields = stars.fieldsValues();
        DefaultComboBoxModel comboModel;

        comboModel = (DefaultComboBoxModel) getFields.get(3);
        cboStar.setModel(comboModel);
        bolSetting = false;
    }

    private void refreshStarRecord()
    {
        if ((bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            //show the star data
            setStarCombos();
            showStar(saveStarRow);
        }
    }

    public void setPicture(ImageIcon data)
    {
        int iMain = tabMain.getSelectedIndex();
        if (iMain == 11)
        {
            asteroidPhoto = data;
            bolAsteroidEditing = true;
            setAsteroidEditMode();
        }
        else if (iMain == 12)
        {
            cometPhoto = data;
            bolCometEditing = true;
            setCometEditMode();
        }
        else if (iMain == 13)
        {
            starPhoto = data;
            bolStarEditing = true;
            setStarEditMode();
        }
    }

    private void setRectrict(Container container, boolean enabled)
    {
        Component components[] = container.getComponents();
        for (int i = 0; i < container.getComponentCount(); i++)
        {
            Component component = components[i];
            if (component instanceof JComboBox || component instanceof JFormattedTextField || component instanceof JCheckBox || component instanceof JTextArea || component instanceof JTextPane || component instanceof JTextField || component instanceof JList)
            {
                if (component instanceof JComboBox)
                {
                    ((JComboBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JFormattedTextField)
                {
                    ((JFormattedTextField) (JComponent) (Container) component).setEditable(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JCheckBox)
                {
                    ((JCheckBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JTextArea)
                {
                    ((JTextArea) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextArea) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextArea) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextPane)
                {
                    ((JTextPane) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextPane) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextPane) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextField)
                {
                    ((JTextField) (JComponent) (Container) component).setEditable(enabled);
                    ((JTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JList)
                {
                    ((JList) (JComponent) (Container) component).setEnabled(enabled);
                }
            }
            Container subContainer = (Container) component;
            setRectrict(subContainer, enabled);
        }
    }

    private void setAsteroidFieldsLocked(boolean enabled)
    {
        setRectrict(pnlDetailAsteroid, enabled);
        /*if (enabled == true)
        {
            lblSaveAsteroid.setComponentPopupMenu(jPMenuDelete);
        }
        else
        {
            lblSaveAsteroid.setComponentPopupMenu(null);
        }*/
    }

    private void addAsteroidRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (saveAsteroid()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveAsteroidRow = asteroidRow;
        showAsteroid("-1");
        asteroidRow += 1;
        setAsteroidFieldsLocked(true);
        bolAsteroidEditing = false;
        bolAsteroidAdding = true;
        setAsteroidEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void removeAsteroidRec()
    {
        if ((bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            if (asteroidNbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeAsteroid(asteroid);
                    asteroids = starLoginManager.getAsteroids();

                    setAsteroidCombos();
                    if (asteroidRow > 1)
                    {
                        showAsteroid(asteroidRow - 1);
                    }
                    else
                    {
                        showAsteroid(asteroidRow + 1);
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private void setCometFieldsLocked(boolean enabled)
    {
        setRectrict(pnlDetailComet, enabled);
        /*if (enabled == true)
        {
            lblSaveComet.setComponentPopupMenu(jPMenuDelete);
        }
        else
        {
            lblSaveComet.setComponentPopupMenu(null);
        }*/
    }

    private void addCometRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (saveComet()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveCometRow = cometRow;
        showComet("-1");
        setCometFieldsLocked(true);
        bolCometEditing = false;
        bolCometAdding = true;
        setCometEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void removeCometRec()
    {
        if ((bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            if (cometNbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, " tes-vous s�r de vouloir supprimer l'enregistrement en cours?", "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeComet(comet);
                    comets = starLoginManager.getComets();

                    setCometCombos();
                    if (cometRow > 1)
                    {
                        showComet(cometRow - 1);
                    }
                    else
                    {
                        showComet(cometRow + 1);
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private void setStarFieldsLocked(boolean enabled)
    {
        setRectrict(pnlDetailStar, enabled);
        /*if (enabled == true)
        {
            lblSaveStar.setComponentPopupMenu(jPMenuDelete);
        }
        else
        {
            lblSaveStar.setComponentPopupMenu(null);
        }*/
    }

    private void addStarRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (saveStar()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        saveStarRow = starRow;
        showStar("-1");
        starRow += 1;
        setStarFieldsLocked(true);
        bolStarEditing = false;
        bolStarAdding = true;
        setStarEditMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void removeStarRec()
    {
        if ((bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            if (starNbOfRows > 0)
            {
                if (javax.swing.JOptionPane.showConfirmDialog(this, " tes-vous s�r de vouloir supprimer l'enregistrement en cours?", "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    starLoginManager.removeStar(star);
                    stars = starLoginManager.getStars();

                    setStarCombos();
                    if (starRow > 1)
                    {
                        showStar(starRow - 1);
                    }
                    else
                    {
                        showStar(starRow + 1);
                    }
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
    }

    private void reloadAsteroidPhoto()
    {
        jPnlAsteroidPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, jPnlAsteroidPhoto.getSize());
        jPnlAsteroidPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(asteroidPhoto);
    }

    private void reloadCometPhoto()
    {
        jPnlCometPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, jPnlCometPhoto.getSize());
        jPnlCometPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(cometPhoto);
    }

    private void reloadStarPhoto()
    {
        jPnlStarPhoto.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, jPnlStarPhoto.getSize());
        jPnlStarPhoto.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(starPhoto);
    }

    private boolean saveAsteroid()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolAsteroidEditing == true) || (bolAsteroidAdding == true))
        {
            //update data
            setAsteroidTextToData();
            asteroid.setAdding(bolAsteroidAdding);
            asteroid.setPicture(asteroidPhoto);
            asteroid.setAsteroidName(asteroidName);
            asteroid.setAsteroidNumber(asteroidNumber);
            asteroid.setMeanAnomaly(asteroidMeanAnomaly);
            asteroid.setHMagnitude(asteroidMagnitude);
            asteroid.setEccentricity(asteroidEccentricity);
            asteroid.setPerihelionLongitude(asteroidPerihelionLongitude);
            asteroid.setNorthNodeLongitude(asteroidNorthNodeLongitude);
            asteroid.setInclination(asteroidInclination);
            asteroid.setSemiMajorAxis(asteroidSemiMajorAxis);
            asteroid.setEpoch(asteroidEpoch);
            starLoginManager.setAsteroid(asteroid);

            if (bolAsteroidAdding == true)
            {
                saveAsteroidRow = asteroid.getRow();
            }
            bolAsteroidEditing = false;
            bolAsteroidAdding = false;
            bolDeleting = false;
            refreshAsteroidRecord();
            setAsteroidNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    private boolean saveComet()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolCometEditing == true) || (bolCometAdding == true))
        {
            //update data
            setCometTextToData();
            comet.setAdding(bolCometAdding);
            comet.setPicture(cometPhoto);
            comet.setCometName(cometName);
            comet.setPerihelionDate(cometPerihelionDate);
            comet.setPerihelionUA(cometPerihelionDistance);
            comet.setEccentricity(cometEccentricity);
            comet.setPerihelionLongitude(cometPerihelionLongitude);
            comet.setNorthNodeLongitude(cometNorthNodeLongitude);
            comet.setInclination(cometInclination);
            comet.setSemiMajorAxis(cometSemiMajorAxis);
            comet.setPeriod(cometPeriod);
            starLoginManager.setComet(comet);

            if (bolCometAdding == true)
            {
                saveCometRow = comet.getRow();
            }
            bolCometEditing = false;
            bolCometAdding = false;
            bolDeleting = false;
            refreshCometRecord();
            setCometNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    private boolean saveStar()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolStarEditing == true) || (bolStarAdding == true))
        {
            //update data
            setStarTextToData();
            star.setAdding(bolStarAdding);
            star.setPicture(starPhoto);
            star.setStarName(starName);
            star.setIdentity(starIdentity);
            star.setLight(starLuminosity);
            star.setRA(starRA);
            star.setD(starD);
            star.setProperMotionRA(starMotionRA);
            star.setProperMotionD(starMotionD);
            star.setRadialVelocity(starVelocity);
            star.setDistance(starDistance);
            star.setDistError(starErrDist);
            star.setHR(starHR);
            starLoginManager.setStar(star);

            if (bolStarAdding == true)
            {
                saveStarRow = star.getRow();
            }
            bolStarEditing = false;
            bolStarAdding = false;
            bolDeleting = false;
            refreshStarRecord();
            setStarNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    private void setAsteroidEditMode()
    {
        pnlControlBarAsteroid.setBackground(bgEdit);
        //lblSaveAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png")));
        cboAsteroid.setEnabled(false);
        txtCounterAsteroid.setEditable(false);
        cboAsteroid.setEnabled(true);
        cboAsteroid.setEditable(true);
    }

    private void setAsteroidNormalMode()
    {
        pnlControlBarAsteroid.setBackground(bgNormal);
        //lblSaveAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/normal.png")));
        cboAsteroid.setEnabled(true);
        txtCounterAsteroid.setEditable(true);
        //cboVille.setEditable(false);
        //mnuVilleEdit.setSelected(false);
        cboAsteroid.setEnabled(true);
        cboAsteroid.setEditable(false);
    }

    private void setCometEditMode()
    {
        pnlControlBarComet.setBackground(bgEdit);
        //lblSaveComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png")));
        cboComet.setEnabled(false);
        txtCounterComet.setEditable(false);
        cboComet.setEnabled(true);
        cboComet.setEditable(true);
    }

    private void setCometNormalMode()
    {
        pnlControlBarComet.setBackground(bgNormal);
        //lblSaveComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/normal.png")));
        cboComet.setEnabled(true);
        txtCounterComet.setEditable(true);
        cboComet.setEnabled(true);
        cboComet.setEditable(false);
    }

    private void setStarEditMode()
    {
        pnlControlBarStar.setBackground(bgEdit);
        //lblSaveStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png")));
        cboStar.setEnabled(false);
        txtCounterStar.setEditable(false);
        cboStar.setEnabled(true);
        cboStar.setEditable(true);
    }

    private void setStarNormalMode()
    {
        pnlControlBarStar.setBackground(bgNormal);
        //lblSaveStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/normal.png")));
        cboStar.setEnabled(true);
        txtCounterStar.setEditable(true);
        cboStar.setEnabled(true);
        cboStar.setEditable(false);
    }

    private void setAsteroidDataToText()
    {
        bolSetting = true;
        if (asteroidRow == 0)
        {
            setAsteroidFieldsLocked(false);
        }
        else
        {
            setAsteroidFieldsLocked(true);
        }
        cboAsteroid.setSelectedItem(-1);
        cboAsteroid.setSelectedItem(asteroidName);
        txtAsteroidNumber.setText(new Integer(asteroidNumber).toString());
        txtAsteroidAM.setText(new Double(asteroidMeanAnomaly).toString());
        txtAsteroidM.setText(new Double(asteroidMagnitude).toString());
        txtAsteroidE.setText(new Double(asteroidEccentricity).toString());
        txtAsteroidAP.setText(new Double(asteroidPerihelionLongitude).toString());
        txtAsteroidLNA.setText(new Double(asteroidNorthNodeLongitude).toString());
        txtAsteroidI.setText(new Double(asteroidInclination).toString());
        txtAsteroid12A.setText(new Double(asteroidSemiMajorAxis).toString());
        txtAsteroidEpoch.setText(new Double(asteroidEpoch).toString());
        int carretPos = txtCounterAsteroid.getCaretPosition();
        if (bolAsteroidAdding == true)
        {
            txtCounterAsteroid.setText(bundle.getString("NewAsteroid"));
        }
        else
        {
            txtCounterAsteroid.setText(String.valueOf(asteroidRow) + " / " + String.valueOf(asteroidNbOfRows));
        }
        int len = txtCounterAsteroid.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounterAsteroid.setCaretPosition(carretPos);
        //setSliderAsteroidMinMax();
        cboAsteroid.setSelectedIndex(asteroidRow - 1);
        reloadAsteroidPhoto();
        bolSetting = false;
        bolAsteroidAdding = false;
        bolAsteroidEditing = false;
        bolDeleting = false;
    }

    private void setCometDataToText()
    {
        bolSetting = true;
        if (cometRow == 0)
        {
            setCometFieldsLocked(false);
        }
        else
        {
            setCometFieldsLocked(true);
        }
        cboComet.setSelectedItem(-1);
        cboComet.setSelectedItem(cometName);
        txtCometDateP.setText(cometPerihelionDate);
        txtCometDP.setText(new Double(cometPerihelionDistance).toString());
        txtCometE.setText(new Double(cometEccentricity).toString());
        txtCometAP.setText(new Double(cometPerihelionLongitude).toString());
        txtCometNA.setText(new Double(cometNorthNodeLongitude).toString());
        txtCometI.setText(new Double(cometInclination).toString());
        txtComet12A.setText(new Double(cometSemiMajorAxis).toString());
        txtCometPeriod.setText(new Double(cometPeriod).toString());
        int carretPos = txtCounterComet.getCaretPosition();
        if (bolCometAdding == true)
        {
            txtCounterComet.setText(bundle.getString("NewComet"));
        }
        else
        {
            txtCounterComet.setText(String.valueOf(cometRow) + " / " + String.valueOf(cometNbOfRows));
        }
        int len = txtCounterComet.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounterComet.setCaretPosition(carretPos);
        //setSliderCometMinMax();
        cboComet.setSelectedIndex(cometRow - 1);

        reloadCometPhoto();
        bolSetting = false;
        bolCometAdding = false;
        bolCometEditing = false;
        bolDeleting = false;
    }

    private void setStarDataToText()
    {
        bolSetting = true;
        if (starRow == 0)
        {
            setStarFieldsLocked(false);
        }
        else
        {
            setStarFieldsLocked(true);
        }
        txtStarName.setText(starName);
        txtStarHR.setText(new Integer(starHR).toString());
        cboStar.setSelectedItem(-1);
        cboStar.setSelectedItem(starIdentity);
        txtStarSCI.setText(starLuminosity);
        txtStarRA.setText(new Double(starRA).toString());
        txtStarMagnitude.setText(new Double(starMagnitude).toString());
        txtStarD.setText(new Double(starD).toString());
        txtStarMotionRA.setText(new Double(starMotionRA).toString());
        txtStarMotionD.setText(new Double(starMotionD).toString());
        txtStarRV.setText(new Double(starVelocity).toString());
        txtStarDistance.setText(new Double(starDistance).toString());
        txtStarErrDist.setText(new Double(starErrDist).toString());
        int carretPos = txtCounterStar.getCaretPosition();
        if (bolStarAdding == true)
        {
            txtCounterStar.setText(bundle.getString("NewStar"));
        }
        else
        {
            txtCounterStar.setText(String.valueOf(starRow) + " / " + String.valueOf(starNbOfRows));
        }
        int len = txtCounterStar.getText().length();
        if (carretPos > len)
        {
            carretPos = len;
        }
        txtCounterStar.setCaretPosition(carretPos);
        //setSliderStarMinMax();
        cboStar.setSelectedIndex(starRow - 1);

        reloadStarPhoto();
        bolSetting = false;
        bolStarAdding = false;
        bolStarEditing = false;
        bolDeleting = false;
    }

    private void setAsteroidTextToData()
    {
        asteroidName = null2String(cboAsteroid.getSelectedItem());
        asteroidNumber = new Integer(txtAsteroidNumber.getText()).intValue();
        asteroidMeanAnomaly = new Double(txtAsteroidAM.getText()).doubleValue();
        asteroidMagnitude = new Double(txtAsteroidM.getText()).doubleValue();
        asteroidEccentricity = new Double(txtAsteroidE.getText()).doubleValue();
        asteroidPerihelionLongitude = new Double(txtAsteroidAP.getText()).doubleValue();
        asteroidNorthNodeLongitude = new Double(txtAsteroidLNA.getText()).doubleValue();
        asteroidInclination = new Double(txtAsteroidI.getText()).doubleValue();
        asteroidSemiMajorAxis = new Double(txtAsteroid12A.getText()).doubleValue();
        asteroidEpoch = new Double(txtAsteroidEpoch.getText()).doubleValue();
        asteroid.setAsteroidName(asteroidName);
        asteroid.setAsteroidNumber(asteroidNumber);
        asteroid.setMeanAnomaly(asteroidMeanAnomaly);
        asteroid.setHMagnitude(asteroidMagnitude);
        asteroid.setEccentricity(asteroidEccentricity);
        asteroid.setPerihelionLongitude(asteroidPerihelionLongitude);
        asteroid.setNorthNodeLongitude(asteroidNorthNodeLongitude);
        asteroid.setInclination(asteroidInclination);
        asteroid.setSemiMajorAxis(asteroidSemiMajorAxis);
        asteroid.setEpoch(asteroidEpoch);
    }

    private void setCometTextToData()
    {
        cometName = null2String(cboComet.getSelectedItem());
        cometPerihelionDate = txtCometDateP.getText();
        cometPerihelionDistance = new Double(txtCometDP.getText()).doubleValue();
        cometEccentricity = new Double(txtCometE.getText()).doubleValue();
        cometPerihelionLongitude = new Double(txtCometAP.getText()).doubleValue();
        cometNorthNodeLongitude = new Double(txtCometNA.getText()).doubleValue();
        cometInclination = new Double(txtCometI.getText()).doubleValue();
        cometSemiMajorAxis = new Double(txtComet12A.getText()).doubleValue();
        cometPeriod = new Double(txtCometPeriod.getText()).doubleValue();
        comet.setCometName(cometName);
        comet.setPerihelionDate(cometPerihelionDate);
        comet.setPerihelionUA(cometPerihelionDistance);
        comet.setEccentricity(cometEccentricity);
        comet.setPerihelionLongitude(cometPerihelionLongitude);
        comet.setNorthNodeLongitude(cometNorthNodeLongitude);
        comet.setInclination(cometInclination);
        comet.setSemiMajorAxis(cometSemiMajorAxis);
        comet.setPeriod(cometPeriod);
    }

    private void setStarTextToData()
    {
        starName = txtStarName.getText();
        txtStarHR.setText(new Integer(starHR).toString());
        starIdentity = null2String(cboStar.getSelectedItem());
        starLuminosity = txtStarSCI.getText();
        starRA = new Double(txtStarRA.getText()).doubleValue();
        starMagnitude = new Double(txtStarMagnitude.getText()).doubleValue();
        starD = new Double(txtStarD.getText()).doubleValue();
        starMotionRA = new Double(txtStarMotionRA.getText()).doubleValue();
        starMotionD = new Double(txtStarMotionD.getText()).doubleValue();
        starVelocity = new Double(txtStarRV.getText()).doubleValue();
        starDistance = new Double(txtStarDistance.getText()).doubleValue();
        starErrDist = new Double(txtStarErrDist.getText()).doubleValue();
        star.setStarName(starName);
        star.setIdentity(starIdentity);
        star.setLight(starLuminosity);
        star.setRA(starRA);
        star.setRA(starMagnitude);
        star.setD(starD);
        star.setProperMotionRA(starMotionRA);
        star.setProperMotionD(starMotionD);
        star.setRadialVelocity(starVelocity);
        star.setDistance(starDistance);
        star.setDistError(starErrDist);
        star.setHR(starHR);
    }

    public void showAsteroid(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        asteroidID = asteroids.getIDFromRow(row);
        if (asteroidID.equals("-1"))
        {
            initAsteroidData("-1");
            return;
        }
        showAsteroid(asteroidID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void showAsteroid(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        asteroidID = strID;
        asteroid = starLoginManager.getAsteroid(asteroidID, "");
        asteroidRow = asteroid.getRow();
        asteroidNbOfRows = asteroid.getRowNB();
        if (strID.equals("-1"))
            txtCounterAsteroid.setText(bundle.getString("NewAsteroid"));
        else
        {
            saveAsteroidRow = asteroidRow;
            txtCounterAsteroid.setText(String.valueOf(asteroidRow) + " / " + String.valueOf(asteroidNbOfRows));
            //asteroidNbOfRows += 1;
        }
        asteroidPhoto = asteroid.getPicture();
        asteroidName = asteroid.getAsteroidName();
        asteroidNumber = asteroid.getAsteroidNumber();
        asteroidMeanAnomaly = asteroid.getMeanAnomaly();
        asteroidMagnitude = asteroid.getHMagnitude();
        asteroidEccentricity = asteroid.getEccentricity();
        asteroidPerihelionLongitude = asteroid.getPerihelionLongitude();
        asteroidNorthNodeLongitude = asteroid.getNorthNodeLongitude();
        asteroidInclination = asteroid.getInclination();
        asteroidSemiMajorAxis = asteroid.getSemiMajorAxis();
        asteroidEpoch = asteroid.getEpoch();

        setAsteroidDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
/*
    private void setSliderAsteroidMinMax()
    {
        btnRemoveAsteroid.setVisible(false);
        if (asteroidNbOfRows == 0)
        {
            jSliderAsteroid.setMinimum(0);
            jSliderAsteroid.setMaximum(0);
            jSliderAsteroid.setValue(0);
        }
        else
        {
            jSliderAsteroid.setMinimum(1);
            jSliderAsteroid.setMaximum(asteroidNbOfRows);
            jSliderAsteroid.setValue(asteroidRow);
            if (asteroidRow != 0)
            {
                btnRemoveAsteroid.setVisible(!bolAsteroidAdding);
            }
        }
        btnAddAsteroid.setVisible(!bolAsteroidAdding);
    }

    private void setSliderCometMinMax()
    {
        btnRemoveComet.setVisible(false);
        if (cometNbOfRows == 0)
        {
            jSliderComet.setMinimum(0);
            jSliderComet.setMaximum(0);
            jSliderComet.setValue(0);
        }
        else
        {
            jSliderComet.setMinimum(1);
            jSliderComet.setMaximum(cometNbOfRows);
            jSliderComet.setValue(cometRow);
            if (cometRow != 0)
            {
                btnRemoveComet.setVisible(!bolCometAdding);
            }
        }
        btnAddComet.setVisible(!bolCometAdding);
    }

    private void setSliderStarMinMax()
    {
        btnRemoveStar.setVisible(false);
        if (starNbOfRows == 0)
        {
            jSliderStar.setMinimum(0);
            jSliderStar.setMaximum(0);
            jSliderStar.setValue(0);
        }
        else
        {
            jSliderStar.setMinimum(1);
            jSliderStar.setMaximum(starNbOfRows);
            jSliderStar.setValue(starRow);
            if (starRow != 0)
            {
                btnRemoveStar.setVisible(!bolStarAdding);
            }
        }
        btnAddStar.setVisible(!bolStarAdding);
    }*/

    private Color getBrighterColor(Color color)
    {
        int r = color.getRed();
        int g = color.getGreen();
        int bl = color.getBlue();
        r = (255 - r) / 2 + r;
        g = (255 - g) / 2 + g;
        bl = (255 - bl) / 2 + bl;
        return new Color(r, g, bl);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        btnGroupTimeKind = new javax.swing.ButtonGroup();
        btnGroupLatitudes = new javax.swing.ButtonGroup();
        btnGroupDegrees = new javax.swing.ButtonGroup();
        btnGroupJulian = new javax.swing.ButtonGroup();
        btnGroupTimes = new javax.swing.ButtonGroup();
        jPMenuDelete = new javax.swing.JPopupMenu();
        mnuDelete = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        pnlRevolution = new javax.swing.JPanel();
        pnlSpace = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        txtPlace = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        lblLatitude = new javax.swing.JLabel();
        txtLatitude = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        lblLongitude = new javax.swing.JLabel();
        txtLongitude = new javax.swing.JTextField();
        pnlTime = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtTime = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        optLocal = new javax.swing.JRadioButton();
        optUT = new javax.swing.JRadioButton();
        jPanel21 = new javax.swing.JPanel();
        btnCalcTZ = new javax.swing.JButton();
        txtTZ = new javax.swing.JTextField();
        pnlButtons = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        btnHinduCycles = new javax.swing.JButton();
        btnProgressedMoon = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        btnCalculate = new javax.swing.JButton();
        tabMain = new javax.swing.JTabbedPane();
        pnlEphemeris = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        pnlEphemeris1 = new javax.swing.JPanel();
        pnlCoordEphemeris = new javax.swing.JPanel();
        lblEphemeris = new javax.swing.JLabel();
        cboCoordinate = new javax.swing.JComboBox();
        scrollPanelGraphicsEphemeris = new javax.swing.JScrollPane();
        pnlEphemeris2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtResultEphemeris = new javax.swing.JTextArea();
        pnlPlanetaryDistances = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        cboPlanet1Dist = new javax.swing.JComboBox();
        jLabel27 = new javax.swing.JLabel();
        cboPlanet2Dist = new javax.swing.JComboBox();
        jLabel28 = new javax.swing.JLabel();
        lblApparentAngle = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        lblDistancePlanets = new javax.swing.JLabel();
        pnlRiseSet = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        cboPlanetRiseSet = new javax.swing.JComboBox();
        jLabel31 = new javax.swing.JLabel();
        lblRiseTime = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        lblSetTime = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        lblMeridianTime = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        lblRisePosition = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        lblSetPosition = new javax.swing.JLabel();
        pnlAlign = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtLatitudePlace1 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txtLongitudePlace1 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        lblAngleA = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        txtLatitudePlace2 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        txtLongitudePlace2 = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        lblAngleB = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        lblAngleDiffAlign = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        txtLatitudePlace3 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        txtLongitudePlace3 = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        lblAngleC = new javax.swing.JLabel();
        pnlCalendars = new javax.swing.JPanel();
        pnlConversions = new javax.swing.JPanel();
        tabCalc = new javax.swing.JTabbedPane();
        pnlGST0 = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtDateGST0 = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        lblGST0 = new javax.swing.JLabel();
        pnlJulianDay = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        txtGregorianDate = new javax.swing.JTextField();
        optGreg2JD = new javax.swing.JRadioButton();
        jLabel16 = new javax.swing.JLabel();
        txtJulianDay = new javax.swing.JTextField();
        optJD2Greg = new javax.swing.JRadioButton();
        pnlDegrees = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        txtSexagesimal = new javax.swing.JTextField();
        optSexa2Deci = new javax.swing.JRadioButton();
        jLabel17 = new javax.swing.JLabel();
        txtDecimal = new javax.swing.JTextField();
        optDeci2Sexa = new javax.swing.JRadioButton();
        jPanel57 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jLabel76 = new javax.swing.JLabel();
        txtAltitude = new javax.swing.JTextField();
        jLabel77 = new javax.swing.JLabel();
        txtGeographical = new javax.swing.JTextField();
        optGeo2Astro = new javax.swing.JRadioButton();
        jLabel78 = new javax.swing.JLabel();
        txtAstronomical = new javax.swing.JTextField();
        optAstro2Geo = new javax.swing.JRadioButton();
        jPanel58 = new javax.swing.JPanel();
        jPanel71 = new javax.swing.JPanel();
        jLabel79 = new javax.swing.JLabel();
        txtDateDayName = new javax.swing.JTextField();
        jLabel80 = new javax.swing.JLabel();
        lblWeekDayName = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        jPanel72 = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        txtEasterYear = new javax.swing.JTextField();
        jLabel82 = new javax.swing.JLabel();
        lblEasterDate = new javax.swing.JLabel();
        jPanel56 = new javax.swing.JPanel();
        jPanel73 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        txtLongitudeTime = new javax.swing.JTextField();
        jLabel84 = new javax.swing.JLabel();
        txtDateTime = new javax.swing.JTextField();
        jLabel85 = new javax.swing.JLabel();
        txtTimeTime = new javax.swing.JTextField();
        optUT2Local = new javax.swing.JRadioButton();
        jLabel86 = new javax.swing.JLabel();
        txtLSTTime = new javax.swing.JTextField();
        optLocal2UT = new javax.swing.JRadioButton();
        jPanel68 = new javax.swing.JPanel();
        pnlUnits = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jPanel69 = new javax.swing.JPanel();
        jPanel84 = new javax.swing.JPanel();
        jLabel93 = new javax.swing.JLabel();
        txtDate1 = new javax.swing.JTextField();
        jLabel95 = new javax.swing.JLabel();
        txtDate2 = new javax.swing.JTextField();
        jLabel94 = new javax.swing.JLabel();
        lblNumberOfDays = new javax.swing.JLabel();
        pnlPerihelionAphelion = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        cboPlanetPeri = new javax.swing.JComboBox();
        jLabel55 = new javax.swing.JLabel();
        txtYearPeri = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        lblPerihelion = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        lblAphelion = new javax.swing.JLabel();
        pnlNodesCrossing = new javax.swing.JPanel();
        jPanel61 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        cboPlanetNodes = new javax.swing.JComboBox();
        jLabel59 = new javax.swing.JLabel();
        txtYearNodes = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        lblNorthNode = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        lblSouthNode = new javax.swing.JLabel();
        pnlMoonPhases = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txtDatePhases = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtTimePhases = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        lblPhase = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        lblAge = new javax.swing.JLabel();
        lblMoonPhase = new javax.swing.JLabel();
        pnlEclipses = new javax.swing.JPanel();
        jPanel63 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        txtYearEclipses = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        lblDateEclipse = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        lblEclipse = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        lblType = new javax.swing.JLabel();
        lblHemi = new javax.swing.JLabel();
        lblHemisphere = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblHalfLight = new javax.swing.JLabel();
        lblHalfLightDuration = new javax.swing.JLabel();
        lblShadow = new javax.swing.JLabel();
        lblShadowDuration = new javax.swing.JLabel();
        lblDim = new javax.swing.JLabel();
        lblDimension = new javax.swing.JLabel();
        btnNextEclipse = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtResultEclipses = new javax.swing.JTextArea();
        pnlSeasons = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        txtYearSeasons = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        lblSpring = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        lblSummer = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        lblFall = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        lblWinter = new javax.swing.JLabel();
        pnlAsteroids = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        pnlControlBarAsteroid = new javax.swing.JPanel();
        jLabelAsteroid = new javax.swing.JLabel();
        cboAsteroid = new javax.swing.JComboBox();
        btnFirstAsteroid = new javax.swing.JButton();
        btnPreviousAsteroid = new javax.swing.JButton();
        txtCounterAsteroid = new javax.swing.JTextField();
        btnNextAsteroid = new javax.swing.JButton();
        btnLastAsteroid = new javax.swing.JButton();
        btnRemoveAsteroid = new javax.swing.JButton();
        btnAddAsteroid = new javax.swing.JButton();
        btnOKAsteroid = new javax.swing.JButton();
        btnCancelAsteroid = new javax.swing.JButton();
        btnQueriesAsteroid = new javax.swing.JButton();
        pnlDetailAsteroid = new javax.swing.JPanel();
        jLabel87 = new javax.swing.JLabel();
        txtAsteroidNumber = new javax.swing.JTextField();
        jLabel99 = new javax.swing.JLabel();
        txtAsteroidAM = new javax.swing.JTextField();
        jLabel88 = new javax.swing.JLabel();
        txtAsteroidM = new javax.swing.JTextField();
        jLabel89 = new javax.swing.JLabel();
        txtAsteroidE = new javax.swing.JTextField();
        jLabel90 = new javax.swing.JLabel();
        txtAsteroidAP = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        txtAsteroidLNA = new javax.swing.JTextField();
        jLabel96 = new javax.swing.JLabel();
        txtAsteroidI = new javax.swing.JTextField();
        jLabel97 = new javax.swing.JLabel();
        txtAsteroid12A = new javax.swing.JTextField();
        jLabel98 = new javax.swing.JLabel();
        txtAsteroidEpoch = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        jPnlAsteroidPhoto = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        pnlDataAsteroid = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResultAsteroid = new javax.swing.JTextArea();
        pnlComets = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        pnlControlBarComet = new javax.swing.JPanel();
        jLabelComet = new javax.swing.JLabel();
        cboComet = new javax.swing.JComboBox();
        btnFirstComet = new javax.swing.JButton();
        btnPreviousComet = new javax.swing.JButton();
        txtCounterComet = new javax.swing.JTextField();
        btnNextComet = new javax.swing.JButton();
        btnLastComet = new javax.swing.JButton();
        btnRemoveComet = new javax.swing.JButton();
        btnAddComet = new javax.swing.JButton();
        btnOKComet = new javax.swing.JButton();
        btnCancelComet = new javax.swing.JButton();
        btnQueriesComet = new javax.swing.JButton();
        pnlDetailComet = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        txtCometDateP = new javax.swing.JTextField();
        jLabel103 = new javax.swing.JLabel();
        txtCometDP = new javax.swing.JTextField();
        jLabel100 = new javax.swing.JLabel();
        txtCometE = new javax.swing.JTextField();
        jLabel102 = new javax.swing.JLabel();
        txtCometAP = new javax.swing.JTextField();
        jLabel105 = new javax.swing.JLabel();
        txtCometNA = new javax.swing.JTextField();
        jLabel106 = new javax.swing.JLabel();
        txtCometI = new javax.swing.JTextField();
        jLabel107 = new javax.swing.JLabel();
        txtComet12A = new javax.swing.JTextField();
        jLabel108 = new javax.swing.JLabel();
        txtCometPeriod = new javax.swing.JTextField();
        jPanel22 = new javax.swing.JPanel();
        jPnlCometPhoto = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        pnlDataComet = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtResultComet = new javax.swing.JTextArea();
        pnlStars = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        pnlControlBarStar = new javax.swing.JPanel();
        jLabelStar = new javax.swing.JLabel();
        cboStar = new javax.swing.JComboBox();
        btnFirstStar = new javax.swing.JButton();
        btnPreviousStar = new javax.swing.JButton();
        txtCounterStar = new javax.swing.JTextField();
        btnNextStar = new javax.swing.JButton();
        btnLastStar = new javax.swing.JButton();
        btnRemoveStar = new javax.swing.JButton();
        btnAddStar = new javax.swing.JButton();
        btnOKStar = new javax.swing.JButton();
        btnCancelStar = new javax.swing.JButton();
        btnQueriesStar = new javax.swing.JButton();
        pnlDetailStar = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        txtStarName = new javax.swing.JTextField();
        lblStarMagnitude = new javax.swing.JLabel();
        txtStarSCI = new javax.swing.JTextField();
        jLabel110 = new javax.swing.JLabel();
        txtStarRA = new javax.swing.JTextField();
        jLabel111 = new javax.swing.JLabel();
        txtStarD = new javax.swing.JTextField();
        jLabel112 = new javax.swing.JLabel();
        txtStarMotionRA = new javax.swing.JTextField();
        jLabel113 = new javax.swing.JLabel();
        txtStarMotionD = new javax.swing.JTextField();
        jLabel114 = new javax.swing.JLabel();
        txtStarRV = new javax.swing.JTextField();
        jLabel115 = new javax.swing.JLabel();
        txtStarDistance = new javax.swing.JTextField();
        jLabel116 = new javax.swing.JLabel();
        txtStarErrDist = new javax.swing.JTextField();
        jLabel117 = new javax.swing.JLabel();
        txtStarHR = new javax.swing.JTextField();
        jLabel120 = new javax.swing.JLabel();
        txtStarMagnitude = new javax.swing.JTextField();
        jPanel18 = new javax.swing.JPanel();
        jPnlStarPhoto = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        pnlDataStar = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtResultStar = new javax.swing.JTextArea();
        pnlDistances = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        txtLatitudePlaceA = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtLongitudePlaceA = new javax.swing.JTextField();
        jPanel44 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        txtLatitudePlaceB = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        txtLongitudePlaceB = new javax.swing.JTextField();
        jPanel43 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        lblAngleAB = new javax.swing.JLabel();
        JLabel1 = new javax.swing.JLabel();
        lblDistanceAB = new javax.swing.JLabel();
        pnlFindDate = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        txtSupposedYear = new javax.swing.JTextField();
        jPanel46 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        lblSun = new javax.swing.JLabel();
        txtLongitudeSun = new javax.swing.JTextField();
        cboLongitudeSun = new javax.swing.JComboBox();
        jPanel25 = new javax.swing.JPanel();
        lblMoon = new javax.swing.JLabel();
        txtLongitudeMoon = new javax.swing.JTextField();
        cboLongitudeMoon = new javax.swing.JComboBox();
        jPanel28 = new javax.swing.JPanel();
        lblMercury = new javax.swing.JLabel();
        txtLongitudeMercury = new javax.swing.JTextField();
        cboLongitudeMercury = new javax.swing.JComboBox();
        jPanel29 = new javax.swing.JPanel();
        lblVenus = new javax.swing.JLabel();
        txtLongitudeVenus = new javax.swing.JTextField();
        cboLongitudeVenus = new javax.swing.JComboBox();
        jPanel30 = new javax.swing.JPanel();
        lblMars = new javax.swing.JLabel();
        txtLongitudeMars = new javax.swing.JTextField();
        cboLongitudeMars = new javax.swing.JComboBox();
        jPanel45 = new javax.swing.JPanel();
        lblJupiter = new javax.swing.JLabel();
        txtLongitudeJupiter = new javax.swing.JTextField();
        cboLongitudeJupiter = new javax.swing.JComboBox();
        jPanel34 = new javax.swing.JPanel();
        lblSaturn = new javax.swing.JLabel();
        txtLongitudeSaturn = new javax.swing.JTextField();
        cboLongitudeSaturn = new javax.swing.JComboBox();
        jPanel33 = new javax.swing.JPanel();
        lblUranus = new javax.swing.JLabel();
        txtLongitudeUranus = new javax.swing.JTextField();
        cboLongitudeUranus = new javax.swing.JComboBox();
        jPanel32 = new javax.swing.JPanel();
        lblNeptune = new javax.swing.JLabel();
        txtLongitudeNeptune = new javax.swing.JTextField();
        cboLongitudeNeptune = new javax.swing.JComboBox();
        jPanel31 = new javax.swing.JPanel();
        lblPluto = new javax.swing.JLabel();
        txtLongitudePluto = new javax.swing.JTextField();
        cboLongitudePluto = new javax.swing.JComboBox();
        jPanel27 = new javax.swing.JPanel();
        lblAS = new javax.swing.JLabel();
        txtLongitudeAS = new javax.swing.JTextField();
        cboLongitudeAS = new javax.swing.JComboBox();
        jPanel26 = new javax.swing.JPanel();
        lblMC = new javax.swing.JLabel();
        txtLongitudeMC = new javax.swing.JTextField();
        cboLongitudeMC = new javax.swing.JComboBox();
        jPanel48 = new javax.swing.JPanel();
        jTextArea1 = new javax.swing.JTextArea();
        btnClear = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtResultFindDate = new javax.swing.JTextArea();

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        mnuDelete.setText(bundle.getString("SUPPRIMER_L'ENREGISTREMENT_SELECTIONNE")); // NOI18N
        mnuDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                mnuDeleteActionPerformed(evt);
            }
        });
        jPMenuDelete.add(mnuDelete);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(915, 730));
        addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
                exitForm(evt);
            }
        });
        getContentPane().setLayout(new java.awt.BorderLayout());

        jPanel1.setMinimumSize(new java.awt.Dimension(664, 73));
        jPanel1.setPreferredSize(new java.awt.Dimension(310, 163));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(0));
        jPanel2.setPreferredSize(new java.awt.Dimension(910, 113));

        pnlRevolution.setMinimumSize(new java.awt.Dimension(654, 31));
        pnlRevolution.setPreferredSize(new java.awt.Dimension(900, 103));

        pnlSpace.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnlSpace.setMinimumSize(new java.awt.Dimension(409, 106));
        pnlSpace.setPreferredSize(new java.awt.Dimension(429, 90));
        pnlSpace.setLayout(new java.awt.FlowLayout(0, 6, 6));

        jPanel4.setLayout(new java.awt.FlowLayout(0, 0, 0));

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel18.setOpaque(true);
        jLabel18.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel4.add(jLabel18);

        txtPlace.setPreferredSize(new java.awt.Dimension(305, 22));
        txtPlace.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                txtPlaceMouseClicked(evt);
            }
        });
        txtPlace.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtPlaceFocusLost(evt);
            }
        });
        txtPlace.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtPlaceKeyPressed(evt);
            }
        });
        jPanel4.add(txtPlace);

        pnlSpace.add(jPanel4);

        jPanel5.setLayout(new java.awt.FlowLayout(0, 0, 0));

        lblLatitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLatitude.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblLatitude.setOpaque(true);
        lblLatitude.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel5.add(lblLatitude);

        txtLatitude.setText(" 00�00'00\"");
        txtLatitude.setPreferredSize(new java.awt.Dimension(105, 22));
        txtLatitude.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLatitudeFocusLost(evt);
            }
        });
        txtLatitude.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLatitudekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLatitudeKeyPressed(evt);
            }
        });
        jPanel5.add(txtLatitude);

        pnlSpace.add(jPanel5);

        jPanel6.setLayout(new java.awt.FlowLayout(0, 0, 0));

        lblLongitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLongitude.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblLongitude.setOpaque(true);
        lblLongitude.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel6.add(lblLongitude);

        txtLongitude.setText(" 000�00'00\"");
        txtLongitude.setPreferredSize(new java.awt.Dimension(105, 22));
        txtLongitude.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLongitudeFocusLost(evt);
            }
        });
        txtLongitude.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLongitudekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLongitudeKeyPressed(evt);
            }
        });
        jPanel6.add(txtLongitude);

        pnlSpace.add(jPanel6);

        pnlRevolution.add(pnlSpace);

        pnlTime.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnlTime.setMaximumSize(new java.awt.Dimension(32767, 90));
        pnlTime.setMinimumSize(new java.awt.Dimension(449, 90));
        pnlTime.setPreferredSize(new java.awt.Dimension(449, 90));
        pnlTime.setLayout(new java.awt.FlowLayout(1, 5, 0));

        jPanel19.setAlignmentY(0.0F);
        jPanel19.setMaximumSize(new java.awt.Dimension(32767, 20));
        jPanel19.setMinimumSize(new java.awt.Dimension(101, 20));
        jPanel19.setPreferredSize(new java.awt.Dimension(445, 26));
        jPanel19.setLayout(new java.awt.FlowLayout(0, 6, 5));

        jPanel13.setLayout(new java.awt.FlowLayout(1, 0, 0));

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel9.setOpaque(true);
        jLabel9.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel13.add(jLabel9);

        txtDate.setPreferredSize(new java.awt.Dimension(105, 21));
        txtDate.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDateFocusLost(evt);
            }
        });
        txtDate.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDatekeyTyped(evt);
            }
        });
        jPanel13.add(txtDate);

        jPanel19.add(jPanel13);

        jPanel15.setLayout(new java.awt.FlowLayout(1, 0, 0));

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel11.setOpaque(true);
        jLabel11.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel15.add(jLabel11);

        txtTime.setPreferredSize(new java.awt.Dimension(105, 21));
        txtTime.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtTimeFocusLost(evt);
            }
        });
        txtTime.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtTimeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtTimekeyTyped(evt);
            }
        });
        jPanel15.add(txtTime);

        jPanel19.add(jPanel15);

        pnlTime.add(jPanel19);

        jPanel20.setMaximumSize(new java.awt.Dimension(32767, 12));
        jPanel20.setMinimumSize(new java.awt.Dimension(268, 12));
        jPanel20.setPreferredSize(new java.awt.Dimension(445, 30));
        jPanel20.setLayout(new java.awt.FlowLayout(1, 5, 3));

        btnGroupTimeKind.add(optLocal);
        optLocal.setSelected(true);
        optLocal.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        optLocal.setMargin(new java.awt.Insets(0, 0, 0, 0));
        optLocal.setMaximumSize(new java.awt.Dimension(150, 12));
        optLocal.setMinimumSize(new java.awt.Dimension(150, 12));
        optLocal.setPreferredSize(new java.awt.Dimension(190, 20));
        optLocal.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optLocalActionPerformed(evt);
            }
        });
        jPanel20.add(optLocal);

        btnGroupTimeKind.add(optUT);
        optUT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        optUT.setMargin(new java.awt.Insets(0, 0, 0, 0));
        optUT.setMaximumSize(new java.awt.Dimension(250, 12));
        optUT.setMinimumSize(new java.awt.Dimension(150, 12));
        optUT.setPreferredSize(new java.awt.Dimension(200, 20));
        optUT.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                optUTActionPerformed(evt);
            }
        });
        jPanel20.add(optUT);

        pnlTime.add(jPanel20);

        jPanel21.setMaximumSize(new java.awt.Dimension(32767, 20));
        jPanel21.setMinimumSize(new java.awt.Dimension(220, 20));
        jPanel21.setPreferredSize(new java.awt.Dimension(445, 30));
        jPanel21.setLayout(new java.awt.FlowLayout(0, 5, 0));

        btnCalcTZ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calcr2.png"))); // NOI18N
        btnCalcTZ.setPreferredSize(new java.awt.Dimension(330, 26));
        btnCalcTZ.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCalcTZActionPerformed(evt);
            }
        });
        jPanel21.add(btnCalcTZ);

        txtTZ.setPreferredSize(new java.awt.Dimension(100, 21));
        txtTZ.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtTZFocusLost(evt);
            }
        });
        txtTZ.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtTZkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtTZKeyPressed(evt);
            }
        });
        jPanel21.add(txtTZ);

        pnlTime.add(jPanel21);

        pnlRevolution.add(pnlTime);

        jPanel2.add(pnlRevolution);

        jPanel1.add(jPanel2, java.awt.BorderLayout.SOUTH);

        pnlButtons.setPreferredSize(new java.awt.Dimension(950, 50));
        pnlButtons.setLayout(new java.awt.FlowLayout(1, 100, 5));

        jPanel9.setLayout(new java.awt.FlowLayout(1, 5, 0));

        btnHinduCycles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/hindu.png"))); // NOI18N
        btnHinduCycles.setBorderPainted(false);
        btnHinduCycles.setContentAreaFilled(false);
        btnHinduCycles.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnHinduCycles.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnHinduCyclesActionPerformed(evt);
            }
        });
        jPanel9.add(btnHinduCycles);

        btnProgressedMoon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/progressmoon.png"))); // NOI18N
        btnProgressedMoon.setBorderPainted(false);
        btnProgressedMoon.setContentAreaFilled(false);
        btnProgressedMoon.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnProgressedMoon.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnProgressedMoonActionPerformed(evt);
            }
        });
        jPanel9.add(btnProgressedMoon);

        pnlButtons.add(jPanel9);

        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/printer2.png"))); // NOI18N
        btnPrint.setBorderPainted(false);
        btnPrint.setContentAreaFilled(false);
        btnPrint.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnPrint.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPrintActionPerformed(evt);
            }
        });
        pnlButtons.add(btnPrint);

        btnCalculate.setPreferredSize(new java.awt.Dimension(120, 26));
        btnCalculate.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCalculateActionPerformed(evt);
            }
        });
        pnlButtons.add(btnCalculate);

        jPanel1.add(pnlButtons, java.awt.BorderLayout.NORTH);

        getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);

        tabMain.setBorder(javax.swing.BorderFactory.createBevelBorder(0));
        tabMain.setPreferredSize(new java.awt.Dimension(915, 540));
        tabMain.addChangeListener(new javax.swing.event.ChangeListener()
        {
            public void stateChanged(javax.swing.event.ChangeEvent evt)
            {
                tabMainStateChanged(evt);
            }
        });

        pnlEphemeris.setLayout(new java.awt.BorderLayout());

        jSplitPane1.setDividerLocation(500);

        pnlEphemeris1.setLayout(new java.awt.BorderLayout());

        pnlCoordEphemeris.setMinimumSize(new java.awt.Dimension(175, 26));
        pnlCoordEphemeris.setPreferredSize(new java.awt.Dimension(435, 26));
        pnlCoordEphemeris.setLayout(new java.awt.FlowLayout(1, 5, 1));

        lblEphemeris.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEphemeris.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblEphemeris.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblEphemeris.setMaximumSize(new java.awt.Dimension(110, 18));
        lblEphemeris.setMinimumSize(new java.awt.Dimension(110, 18));
        lblEphemeris.setOpaque(true);
        lblEphemeris.setPreferredSize(new java.awt.Dimension(110, 19));
        pnlCoordEphemeris.add(lblEphemeris);

        cboCoordinate.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        cboCoordinate.setMaximumRowCount(10);
        cboCoordinate.setToolTipText("");
        cboCoordinate.setKeySelectionManager(new MultiKeySelectionManager());
        cboCoordinate.setMaximumSize(new java.awt.Dimension(32767, 24));
        cboCoordinate.setMinimumSize(new java.awt.Dimension(250, 24));
        cboCoordinate.setPreferredSize(new java.awt.Dimension(310, 24));
        pnlCoordEphemeris.add(cboCoordinate);

        pnlEphemeris1.add(pnlCoordEphemeris, java.awt.BorderLayout.NORTH);

        scrollPanelGraphicsEphemeris.setMaximumSize(new java.awt.Dimension(32767, 304));
        scrollPanelGraphicsEphemeris.setPreferredSize(new java.awt.Dimension(18, 304));
        pnlEphemeris1.add(scrollPanelGraphicsEphemeris, java.awt.BorderLayout.CENTER);

        jSplitPane1.setLeftComponent(pnlEphemeris1);

        pnlEphemeris2.setPreferredSize(new java.awt.Dimension(1204, 10));
        pnlEphemeris2.setLayout(new java.awt.BorderLayout());

        jScrollPane5.setPreferredSize(new java.awt.Dimension(10, 10));

        txtResultEphemeris.setPreferredSize(new java.awt.Dimension(1200, 6000));
        jScrollPane5.setViewportView(txtResultEphemeris);

        pnlEphemeris2.add(jScrollPane5, java.awt.BorderLayout.CENTER);

        jSplitPane1.setRightComponent(pnlEphemeris2);

        pnlEphemeris.add(jSplitPane1, java.awt.BorderLayout.CENTER);

        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ephemeris.gif")), pnlEphemeris, bundle.getString("Ephemeris")); // NOI18N

        pnlPlanetaryDistances.setLayout(new java.awt.BorderLayout());

        jPanel8.setMinimumSize(new java.awt.Dimension(200, 320));
        jPanel8.setPreferredSize(new java.awt.Dimension(250, 320));

        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setOpaque(true);
        jLabel26.setPreferredSize(new java.awt.Dimension(80, 19));
        jPanel8.add(jLabel26);

        cboPlanet1Dist.setKeySelectionManager(new MultiKeySelectionManager());
        cboPlanet1Dist.setPreferredSize(new java.awt.Dimension(150, 25));
        jPanel8.add(cboPlanet1Dist);

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setOpaque(true);
        jLabel27.setPreferredSize(new java.awt.Dimension(80, 19));
        jPanel8.add(jLabel27);

        cboPlanet2Dist.setKeySelectionManager(new MultiKeySelectionManager());
        cboPlanet2Dist.setPreferredSize(new java.awt.Dimension(150, 25));
        jPanel8.add(cboPlanet2Dist);

        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setOpaque(true);
        jLabel28.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel8.add(jLabel28);

        lblApparentAngle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblApparentAngle.setAlignmentX(0.5F);
        lblApparentAngle.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel8.add(lblApparentAngle);

        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setOpaque(true);
        jLabel29.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel8.add(jLabel29);

        lblDistancePlanets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDistancePlanets.setAlignmentX(0.5F);
        lblDistancePlanets.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel8.add(lblDistancePlanets);

        pnlPlanetaryDistances.add(jPanel8, java.awt.BorderLayout.WEST);

        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/distances.gif")), pnlPlanetaryDistances, bundle.getString("DistancesBetweenPlanets")); // NOI18N

        pnlRiseSet.setLayout(new java.awt.BorderLayout());

        jPanel7.setPreferredSize(new java.awt.Dimension(250, 320));

        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setOpaque(true);
        jLabel30.setPreferredSize(new java.awt.Dimension(80, 19));
        jPanel7.add(jLabel30);

        cboPlanetRiseSet.setKeySelectionManager(new MultiKeySelectionManager());
        cboPlanetRiseSet.setPreferredSize(new java.awt.Dimension(150, 25));
        jPanel7.add(cboPlanetRiseSet);

        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setOpaque(true);
        jLabel31.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel7.add(jLabel31);

        lblRiseTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRiseTime.setAlignmentX(0.5F);
        lblRiseTime.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel7.add(lblRiseTime);

        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setOpaque(true);
        jLabel32.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel7.add(jLabel32);

        lblSetTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSetTime.setAlignmentX(0.5F);
        lblSetTime.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel7.add(lblSetTime);

        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setOpaque(true);
        jLabel33.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel7.add(jLabel33);

        lblMeridianTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMeridianTime.setAlignmentX(0.5F);
        lblMeridianTime.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel7.add(lblMeridianTime);

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setOpaque(true);
        jLabel34.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel7.add(jLabel34);

        lblRisePosition.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRisePosition.setAlignmentX(0.5F);
        lblRisePosition.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel7.add(lblRisePosition);

        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setOpaque(true);
        jLabel35.setPreferredSize(new java.awt.Dimension(185, 19));
        jPanel7.add(jLabel35);

        lblSetPosition.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSetPosition.setAlignmentX(0.5F);
        lblSetPosition.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel7.add(lblSetPosition);

        pnlRiseSet.add(jPanel7, java.awt.BorderLayout.WEST);

        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/riseset.gif")), pnlRiseSet, bundle.getString("RiseSet")); // NOI18N

        pnlAlign.setLayout(new java.awt.GridLayout(1, 3));

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setOpaque(true);
        jLabel21.setPreferredSize(new java.awt.Dimension(280, 19));
        jPanel35.add(jLabel21);

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setOpaque(true);
        jLabel24.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel35.add(jLabel24);

        txtLatitudePlace1.setText(" 00�00'00\"");
        txtLatitudePlace1.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLatitudePlace1.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLatitudePlace1FocusLost(evt);
            }
        });
        txtLatitudePlace1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace1keyTyped(evt);
            }
        });
        jPanel35.add(txtLatitudePlace1);

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setOpaque(true);
        jLabel25.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel35.add(jLabel25);

        txtLongitudePlace1.setText(" 000�00'00\"");
        txtLongitudePlace1.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLongitudePlace1.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLongitudePlace1FocusLost(evt);
            }
        });
        txtLongitudePlace1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace1keyTyped(evt);
            }
        });
        jPanel35.add(txtLongitudePlace1);

        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setOpaque(true);
        jLabel40.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel35.add(jLabel40);

        lblAngleA.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAngleA.setAlignmentX(0.5F);
        lblAngleA.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel35.add(lblAngleA);

        pnlAlign.add(jPanel35);

        jPanel36.setLayout(new java.awt.BorderLayout());

        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setOpaque(true);
        jLabel36.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel38.add(jLabel36);

        txtLatitudePlace2.setText(" 00�00'00\"");
        txtLatitudePlace2.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLatitudePlace2.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLatitudePlace2FocusLost(evt);
            }
        });
        txtLatitudePlace2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace2keyTyped(evt);
            }
        });
        jPanel38.add(txtLatitudePlace2);

        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setOpaque(true);
        jLabel37.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel38.add(jLabel37);

        txtLongitudePlace2.setText(" 000�00'00\"");
        txtLongitudePlace2.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLongitudePlace2.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLongitudePlace2FocusLost(evt);
            }
        });
        txtLongitudePlace2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace2keyTyped(evt);
            }
        });
        jPanel38.add(txtLongitudePlace2);

        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setOpaque(true);
        jLabel41.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel38.add(jLabel41);

        lblAngleB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAngleB.setAlignmentX(0.5F);
        lblAngleB.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel38.add(lblAngleB);

        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setOpaque(true);
        jLabel43.setPreferredSize(new java.awt.Dimension(215, 19));
        jPanel38.add(jLabel43);

        lblAngleDiffAlign.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAngleDiffAlign.setAlignmentX(0.5F);
        lblAngleDiffAlign.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel38.add(lblAngleDiffAlign);

        jPanel36.add(jPanel38, java.awt.BorderLayout.CENTER);

        jPanel39.setLayout(new java.awt.BorderLayout());

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setOpaque(true);
        jLabel22.setPreferredSize(new java.awt.Dimension(280, 19));
        jPanel39.add(jLabel22, java.awt.BorderLayout.CENTER);

        jPanel41.setPreferredSize(new java.awt.Dimension(10, 5));
        jPanel39.add(jPanel41, java.awt.BorderLayout.NORTH);

        jPanel36.add(jPanel39, java.awt.BorderLayout.NORTH);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/align3places.gif"))); // NOI18N
        jPanel40.add(jLabel1);

        jPanel36.add(jPanel40, java.awt.BorderLayout.SOUTH);

        pnlAlign.add(jPanel36);

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setOpaque(true);
        jLabel23.setPreferredSize(new java.awt.Dimension(280, 19));
        jPanel37.add(jLabel23);

        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setOpaque(true);
        jLabel38.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel37.add(jLabel38);

        txtLatitudePlace3.setText(" 00�00'00\"");
        txtLatitudePlace3.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLatitudePlace3.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLatitudePlace3FocusLost(evt);
            }
        });
        txtLatitudePlace3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace3keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLatitudePlace3KeyPressed(evt);
            }
        });
        jPanel37.add(txtLatitudePlace3);

        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setOpaque(true);
        jLabel39.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel37.add(jLabel39);

        txtLongitudePlace3.setText(" 000�00'00\"");
        txtLongitudePlace3.setPreferredSize(new java.awt.Dimension(140, 21));
        txtLongitudePlace3.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtLongitudePlace3FocusLost(evt);
            }
        });
        txtLongitudePlace3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace3keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtLongitudePlace3KeyPressed(evt);
            }
        });
        jPanel37.add(txtLongitudePlace3);

        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setOpaque(true);
        jLabel42.setPreferredSize(new java.awt.Dimension(110, 19));
        jPanel37.add(jLabel42);

        lblAngleC.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAngleC.setAlignmentX(0.5F);
        lblAngleC.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel37.add(lblAngleC);

        pnlAlign.add(jPanel37);

        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/align.gif")), pnlAlign, bundle.getString("DistancesBetweenPlaces")); // NOI18N

        pnlCalendars.setPreferredSize(new java.awt.Dimension(0, 0));
        pnlCalendars.setLayout(new java.awt.GridLayout(11, 2));
        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calendar.png")), pnlCalendars, bundle.getString("Calendars")); // NOI18N

        pnlConversions.setLayout(new java.awt.BorderLayout());

        tabCalc.setMinimumSize(new java.awt.Dimension(900, 500));
        tabCalc.setPreferredSize(new java.awt.Dimension(900, 500));

        pnlGST0.setLayout(new java.awt.BorderLayout());

        jPanel65.setPreferredSize(new java.awt.Dimension(260, 10));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setOpaque(true);
        jLabel13.setPreferredSize(new java.awt.Dimension(100, 19));
        jPanel65.add(jLabel13);

        txtDateGST0.setPreferredSize(new java.awt.Dimension(140, 21));
        txtDateGST0.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtDateGST0FocusLost(evt);
            }
        });
        txtDateGST0.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDateGST0KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDateGST0keyTyped(evt);
            }
        });
        jPanel65.add(txtDateGST0);

        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setOpaque(true);
        jLabel62.setPreferredSize(new java.awt.Dimension(100, 19));
        jPanel65.add(jLabel62);

        lblGST0.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGST0.setAlignmentX(0.5F);
        lblGST0.setPreferredSize(new java.awt.Dimension(140, 21));
        jPanel65.add(lblGST0);

        pnlGST0.add(jPanel65, java.awt.BorderLayout.WEST);

        tabCalc.addTab(bundle.getString("GST0"), pnlGST0); // NOI18N

        pnlJulianDay.setLayout(new java.awt.BorderLayout());

        jPanel66.setPreferredSize(new java.awt.Dimension(320, 10));

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setOpaque(true);
        jLabel14.setPreferredSize(new java.awt.Dimension(120, 19));
        jPanel66.add(jLabel14);

        txtGregorianDate.setPreferredSize(new java.awt.Dimension(140, 21));
        txtGregorianDate.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtGregorianDateFocusLost(evt);
            }
        });
        txtGregorianDate.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtGregorianDateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtGregorianDatekeyTyped(evt);
            }
        });
        jPanel66.add(txtGregorianDate);

        btnGroupJulian.add(optGreg2JD);
        optGreg2JD.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        optGreg2JD.setSelected(true);
        optGreg2JD.setText("^");
        optGreg2JD.setPreferredSize(new java.awt.Dimension(42, 21));
        jPanel66.add(optGreg2JD);

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setOpaque(true);
        jLabel16.setPreferredSize(new java.awt.Dimension(120, 19));
        jPanel66.add(jLabel16);

        txtJulianDay.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtJulianDay.setPreferredSize(new java.awt.Dimension(140, 21));
        txtJulianDay.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtJulianDayKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtJulianDaykeyTyped(evt);
            }
        });
        jPanel66.add(txtJulianDay);

        btnGroupJulian.add(optJD2Greg);
        optJD2Greg.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        optJD2Greg.setText("\\");
            optJD2Greg.setPreferredSize(new java.awt.Dimension(42, 21));
            jPanel66.add(optJD2Greg);

            pnlJulianDay.add(jPanel66, java.awt.BorderLayout.WEST);

            tabCalc.addTab(bundle.getString("JulianDay"), pnlJulianDay); // NOI18N

            pnlDegrees.setLayout(new java.awt.BorderLayout());

            jPanel67.setPreferredSize(new java.awt.Dimension(320, 10));

            jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            jLabel15.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
            jLabel15.setOpaque(true);
            jLabel15.setPreferredSize(new java.awt.Dimension(120, 19));
            jPanel67.add(jLabel15);

            txtSexagesimal.setPreferredSize(new java.awt.Dimension(140, 21));
            txtSexagesimal.addFocusListener(new java.awt.event.FocusAdapter()
            {
                public void focusLost(java.awt.event.FocusEvent evt)
                {
                    txtSexagesimalFocusLost(evt);
                }
            });
            txtSexagesimal.addKeyListener(new java.awt.event.KeyAdapter()
            {
                public void keyPressed(java.awt.event.KeyEvent evt)
                {
                    txtSexagesimalKeyPressed(evt);
                }
                public void keyTyped(java.awt.event.KeyEvent evt)
                {
                    txtSexagesimalkeyTyped(evt);
                }
            });
            jPanel67.add(txtSexagesimal);

            btnGroupDegrees.add(optSexa2Deci);
            optSexa2Deci.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
            optSexa2Deci.setSelected(true);
            optSexa2Deci.setText("^");
            optSexa2Deci.setPreferredSize(new java.awt.Dimension(42, 21));
            jPanel67.add(optSexa2Deci);

            jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            jLabel17.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
            jLabel17.setOpaque(true);
            jLabel17.setPreferredSize(new java.awt.Dimension(120, 19));
            jPanel67.add(jLabel17);

            txtDecimal.setHorizontalAlignment(javax.swing.JTextField.LEFT);
            txtDecimal.setPreferredSize(new java.awt.Dimension(140, 21));
            txtDecimal.addKeyListener(new java.awt.event.KeyAdapter()
            {
                public void keyTyped(java.awt.event.KeyEvent evt)
                {
                    txtDecimalkeyTyped(evt);
                }
                public void keyPressed(java.awt.event.KeyEvent evt)
                {
                    txtDecimalKeyPressed(evt);
                }
            });
            jPanel67.add(txtDecimal);

            btnGroupDegrees.add(optDeci2Sexa);
            optDeci2Sexa.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
            optDeci2Sexa.setText("\\");
                optDeci2Sexa.setPreferredSize(new java.awt.Dimension(42, 21));
                jPanel67.add(optDeci2Sexa);

                pnlDegrees.add(jPanel67, java.awt.BorderLayout.WEST);

                tabCalc.addTab(bundle.getString("Degrees"), pnlDegrees); // NOI18N

                jPanel57.setLayout(new java.awt.BorderLayout());

                jPanel70.setPreferredSize(new java.awt.Dimension(275, 10));

                jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                jLabel76.setOpaque(true);
                jLabel76.setPreferredSize(new java.awt.Dimension(120, 19));
                jPanel70.add(jLabel76);

                txtAltitude.setPreferredSize(new java.awt.Dimension(140, 21));
                txtAltitude.addKeyListener(new java.awt.event.KeyAdapter()
                {
                    public void keyTyped(java.awt.event.KeyEvent evt)
                    {
                        txtAltitudekeyTyped(evt);
                    }
                    public void keyPressed(java.awt.event.KeyEvent evt)
                    {
                        txtAltitudeKeyPressed(evt);
                    }
                });
                jPanel70.add(txtAltitude);

                jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                jLabel77.setOpaque(true);
                jLabel77.setPreferredSize(new java.awt.Dimension(225, 19));
                jPanel70.add(jLabel77);

                txtGeographical.setText(" 00�00'00\"");
                txtGeographical.setPreferredSize(new java.awt.Dimension(140, 21));
                txtGeographical.addFocusListener(new java.awt.event.FocusAdapter()
                {
                    public void focusLost(java.awt.event.FocusEvent evt)
                    {
                        txtGeographicalFocusLost(evt);
                    }
                });
                txtGeographical.addKeyListener(new java.awt.event.KeyAdapter()
                {
                    public void keyPressed(java.awt.event.KeyEvent evt)
                    {
                        txtGeographicalKeyPressed(evt);
                    }
                    public void keyTyped(java.awt.event.KeyEvent evt)
                    {
                        txtGeographicalkeyTyped(evt);
                    }
                });
                jPanel70.add(txtGeographical);

                btnGroupLatitudes.add(optGeo2Astro);
                optGeo2Astro.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
                optGeo2Astro.setSelected(true);
                optGeo2Astro.setText("^");
                optGeo2Astro.setPreferredSize(new java.awt.Dimension(42, 21));
                jPanel70.add(optGeo2Astro);

                jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                jLabel78.setOpaque(true);
                jLabel78.setPreferredSize(new java.awt.Dimension(225, 19));
                jPanel70.add(jLabel78);

                txtAstronomical.setText(" 00�00'00\"");
                txtAstronomical.setPreferredSize(new java.awt.Dimension(140, 21));
                txtAstronomical.addFocusListener(new java.awt.event.FocusAdapter()
                {
                    public void focusLost(java.awt.event.FocusEvent evt)
                    {
                        txtAstronomicalFocusLost(evt);
                    }
                });
                txtAstronomical.addKeyListener(new java.awt.event.KeyAdapter()
                {
                    public void keyPressed(java.awt.event.KeyEvent evt)
                    {
                        txtAstronomicalKeyPressed(evt);
                    }
                    public void keyTyped(java.awt.event.KeyEvent evt)
                    {
                        txtAstronomicalkeyTyped(evt);
                    }
                });
                jPanel70.add(txtAstronomical);

                btnGroupLatitudes.add(optAstro2Geo);
                optAstro2Geo.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
                optAstro2Geo.setText("\\");
                    optAstro2Geo.setPreferredSize(new java.awt.Dimension(42, 21));
                    jPanel70.add(optAstro2Geo);

                    jPanel57.add(jPanel70, java.awt.BorderLayout.WEST);

                    tabCalc.addTab(bundle.getString("Latitudes"), jPanel57); // NOI18N

                    jPanel58.setLayout(new java.awt.BorderLayout());

                    jPanel71.setPreferredSize(new java.awt.Dimension(260, 10));

                    jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel79.setOpaque(true);
                    jLabel79.setPreferredSize(new java.awt.Dimension(100, 19));
                    jPanel71.add(jLabel79);

                    txtDateDayName.setPreferredSize(new java.awt.Dimension(140, 21));
                    txtDateDayName.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtDateDayNameFocusLost(evt);
                        }
                    });
                    txtDateDayName.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtDateDayNameKeyPressed(evt);
                        }
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtDateDayNamekeyTyped(evt);
                        }
                    });
                    jPanel71.add(txtDateDayName);

                    jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel80.setOpaque(true);
                    jLabel80.setPreferredSize(new java.awt.Dimension(205, 19));
                    jPanel71.add(jLabel80);

                    lblWeekDayName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    lblWeekDayName.setAlignmentX(0.5F);
                    lblWeekDayName.setPreferredSize(new java.awt.Dimension(140, 21));
                    jPanel71.add(lblWeekDayName);

                    jPanel58.add(jPanel71, java.awt.BorderLayout.WEST);

                    tabCalc.addTab(bundle.getString("WeekDay"), jPanel58); // NOI18N

                    jPanel59.setLayout(new java.awt.BorderLayout());

                    jPanel72.setPreferredSize(new java.awt.Dimension(220, 10));

                    jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel81.setOpaque(true);
                    jLabel81.setPreferredSize(new java.awt.Dimension(100, 19));
                    jPanel72.add(jLabel81);

                    txtEasterYear.setPreferredSize(new java.awt.Dimension(100, 21));
                    txtEasterYear.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtEasterYearFocusLost(evt);
                        }
                    });
                    txtEasterYear.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtEasterYearkeyTyped(evt);
                        }
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtEasterYearKeyPressed(evt);
                        }
                    });
                    jPanel72.add(txtEasterYear);

                    jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel82.setOpaque(true);
                    jLabel82.setPreferredSize(new java.awt.Dimension(205, 19));
                    jPanel72.add(jLabel82);

                    lblEasterDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    lblEasterDate.setAlignmentX(0.5F);
                    lblEasterDate.setPreferredSize(new java.awt.Dimension(205, 21));
                    jPanel72.add(lblEasterDate);

                    jPanel59.add(jPanel72, java.awt.BorderLayout.WEST);

                    tabCalc.addTab(bundle.getString("Easter"), jPanel59); // NOI18N

                    jPanel56.setLayout(new java.awt.BorderLayout());

                    jPanel73.setPreferredSize(new java.awt.Dimension(376, 10));

                    jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel83.setOpaque(true);
                    jLabel83.setPreferredSize(new java.awt.Dimension(130, 19));
                    jPanel73.add(jLabel83);

                    txtLongitudeTime.setPreferredSize(new java.awt.Dimension(140, 21));
                    txtLongitudeTime.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtLongitudeTimeFocusLost(evt);
                        }
                    });
                    txtLongitudeTime.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtLongitudeTimekeyTyped(evt);
                        }
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtLongitudeTimeKeyPressed(evt);
                        }
                    });
                    jPanel73.add(txtLongitudeTime);

                    jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel84.setOpaque(true);
                    jLabel84.setPreferredSize(new java.awt.Dimension(130, 19));
                    jPanel73.add(jLabel84);

                    txtDateTime.setPreferredSize(new java.awt.Dimension(140, 21));
                    txtDateTime.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtDateTimeFocusLost(evt);
                        }
                    });
                    txtDateTime.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtDateTimeKeyPressed(evt);
                        }
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtDateTimekeyTyped(evt);
                        }
                    });
                    jPanel73.add(txtDateTime);

                    jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel85.setOpaque(true);
                    jLabel85.setPreferredSize(new java.awt.Dimension(175, 19));
                    jPanel73.add(jLabel85);

                    txtTimeTime.setPreferredSize(new java.awt.Dimension(140, 21));
                    txtTimeTime.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtTimeTimeFocusLost(evt);
                        }
                    });
                    txtTimeTime.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtTimeTimeKeyPressed(evt);
                        }
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtTimeTimekeyTyped(evt);
                        }
                    });
                    jPanel73.add(txtTimeTime);

                    btnGroupTimes.add(optUT2Local);
                    optUT2Local.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
                    optUT2Local.setSelected(true);
                    optUT2Local.setText("^");
                    optUT2Local.setPreferredSize(new java.awt.Dimension(42, 21));
                    jPanel73.add(optUT2Local);

                    jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    jLabel86.setOpaque(true);
                    jLabel86.setPreferredSize(new java.awt.Dimension(175, 19));
                    jPanel73.add(jLabel86);

                    txtLSTTime.setPreferredSize(new java.awt.Dimension(140, 21));
                    txtLSTTime.addFocusListener(new java.awt.event.FocusAdapter()
                    {
                        public void focusLost(java.awt.event.FocusEvent evt)
                        {
                            txtLSTTimeFocusLost(evt);
                        }
                    });
                    txtLSTTime.addKeyListener(new java.awt.event.KeyAdapter()
                    {
                        public void keyPressed(java.awt.event.KeyEvent evt)
                        {
                            txtLSTTimeKeyPressed(evt);
                        }
                        public void keyTyped(java.awt.event.KeyEvent evt)
                        {
                            txtLSTTimekeyTyped(evt);
                        }
                    });
                    jPanel73.add(txtLSTTime);

                    btnGroupTimes.add(optLocal2UT);
                    optLocal2UT.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
                    optLocal2UT.setText("\\");
                        optLocal2UT.setPreferredSize(new java.awt.Dimension(42, 21));
                        jPanel73.add(optLocal2UT);

                        jPanel56.add(jPanel73, java.awt.BorderLayout.WEST);

                        tabCalc.addTab(bundle.getString("Time"), jPanel56); // NOI18N

                        jPanel68.setLayout(new java.awt.FlowLayout(1, 5, 1));

                        pnlUnits.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
                        pnlUnits.setPreferredSize(new java.awt.Dimension(382, 458));
                        pnlUnits.setLayout(new java.awt.FlowLayout(1, 0, -1));

                        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel2.setText(bundle.getString("Unit")); // NOI18N
                        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray));
                        jLabel2.setOpaque(true);
                        jLabel2.setPreferredSize(new java.awt.Dimension(190, 20));
                        pnlUnits.add(jLabel2);

                        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel92.setText(bundle.getString("Distance")); // NOI18N
                        jLabel92.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray));
                        jLabel92.setOpaque(true);
                        jLabel92.setPreferredSize(new java.awt.Dimension(190, 20));
                        pnlUnits.add(jLabel92);

                        jPanel68.add(pnlUnits);

                        tabCalc.addTab(bundle.getString("Distance"), jPanel68); // NOI18N

                        jPanel69.setLayout(new java.awt.BorderLayout());

                        jPanel84.setPreferredSize(new java.awt.Dimension(260, 10));

                        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel93.setOpaque(true);
                        jLabel93.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel84.add(jLabel93);

                        txtDate1.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtDate1.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtDate1FocusLost(evt);
                            }
                        });
                        txtDate1.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtDate1KeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtDate1keyTyped(evt);
                            }
                        });
                        jPanel84.add(txtDate1);

                        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel95.setOpaque(true);
                        jLabel95.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel84.add(jLabel95);

                        txtDate2.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtDate2.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtDate2FocusLost(evt);
                            }
                        });
                        txtDate2.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtDate2KeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtDate2keyTyped(evt);
                            }
                        });
                        jPanel84.add(txtDate2);

                        jLabel94.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel94.setOpaque(true);
                        jLabel94.setPreferredSize(new java.awt.Dimension(205, 19));
                        jPanel84.add(jLabel94);

                        lblNumberOfDays.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblNumberOfDays.setAlignmentX(0.5F);
                        lblNumberOfDays.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel84.add(lblNumberOfDays);

                        jPanel69.add(jPanel84, java.awt.BorderLayout.WEST);

                        tabCalc.addTab(bundle.getString("DaysBetweenDates"), jPanel69); // NOI18N

                        pnlConversions.add(tabCalc, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calcr.png")), pnlConversions, bundle.getString("Conversions")); // NOI18N

                        pnlPerihelionAphelion.setLayout(new java.awt.BorderLayout());

                        jPanel60.setPreferredSize(new java.awt.Dimension(250, 35));

                        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel54.setOpaque(true);
                        jLabel54.setPreferredSize(new java.awt.Dimension(80, 19));
                        jPanel60.add(jLabel54);

                        cboPlanetPeri.setKeySelectionManager(new MultiKeySelectionManager());
                        cboPlanetPeri.setPreferredSize(new java.awt.Dimension(150, 25));
                        jPanel60.add(cboPlanetPeri);

                        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel55.setOpaque(true);
                        jLabel55.setPreferredSize(new java.awt.Dimension(80, 19));
                        jPanel60.add(jLabel55);

                        txtYearPeri.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtYearPeri.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtYearPerikeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtYearPeriKeyPressed(evt);
                            }
                        });
                        jPanel60.add(txtYearPeri);

                        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel56.setOpaque(true);
                        jLabel56.setPreferredSize(new java.awt.Dimension(185, 19));
                        jPanel60.add(jLabel56);

                        lblPerihelion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblPerihelion.setAlignmentX(0.5F);
                        lblPerihelion.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel60.add(lblPerihelion);

                        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel57.setOpaque(true);
                        jLabel57.setPreferredSize(new java.awt.Dimension(185, 19));
                        jPanel60.add(jLabel57);

                        lblAphelion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblAphelion.setAlignmentX(0.5F);
                        lblAphelion.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel60.add(lblAphelion);

                        pnlPerihelionAphelion.add(jPanel60, java.awt.BorderLayout.WEST);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/peri.gif")), pnlPerihelionAphelion, bundle.getString("PerihelionAphelion")); // NOI18N

                        pnlNodesCrossing.setLayout(new java.awt.BorderLayout());

                        jPanel61.setPreferredSize(new java.awt.Dimension(250, 35));

                        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel58.setOpaque(true);
                        jLabel58.setPreferredSize(new java.awt.Dimension(80, 19));
                        jPanel61.add(jLabel58);

                        cboPlanetNodes.setKeySelectionManager(new MultiKeySelectionManager());
                        cboPlanetNodes.setPreferredSize(new java.awt.Dimension(150, 25));
                        jPanel61.add(cboPlanetNodes);

                        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel59.setOpaque(true);
                        jLabel59.setPreferredSize(new java.awt.Dimension(80, 19));
                        jPanel61.add(jLabel59);

                        txtYearNodes.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtYearNodes.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtYearNodeskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtYearNodesKeyPressed(evt);
                            }
                        });
                        jPanel61.add(txtYearNodes);

                        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel60.setOpaque(true);
                        jLabel60.setPreferredSize(new java.awt.Dimension(185, 19));
                        jPanel61.add(jLabel60);

                        lblNorthNode.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblNorthNode.setAlignmentX(0.5F);
                        lblNorthNode.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel61.add(lblNorthNode);

                        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel61.setOpaque(true);
                        jLabel61.setPreferredSize(new java.awt.Dimension(185, 19));
                        jPanel61.add(jLabel61);

                        lblSouthNode.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblSouthNode.setAlignmentX(0.5F);
                        lblSouthNode.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel61.add(lblSouthNode);

                        pnlNodesCrossing.add(jPanel61, java.awt.BorderLayout.WEST);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/nodescross.gif")), pnlNodesCrossing, bundle.getString("NodesCrossing")); // NOI18N

                        pnlMoonPhases.setLayout(new java.awt.BorderLayout());

                        jPanel62.setPreferredSize(new java.awt.Dimension(260, 35));

                        jLabel10.setOpaque(true);
                        jLabel10.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel62.add(jLabel10);

                        txtDatePhases.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtDatePhases.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtDatePhasesFocusLost(evt);
                            }
                        });
                        txtDatePhases.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtDatePhasesKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtDatePhaseskeyTyped(evt);
                            }
                        });
                        jPanel62.add(txtDatePhases);

                        jLabel12.setOpaque(true);
                        jLabel12.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel62.add(jLabel12);

                        txtTimePhases.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtTimePhases.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtTimePhasesFocusLost(evt);
                            }
                        });
                        txtTimePhases.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtTimePhasesKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtTimePhaseskeyTyped(evt);
                            }
                        });
                        jPanel62.add(txtTimePhases);

                        jLabel64.setOpaque(true);
                        jLabel64.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel62.add(jLabel64);

                        lblPhase.setAlignmentX(0.5F);
                        lblPhase.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel62.add(lblPhase);

                        jLabel65.setOpaque(true);
                        jLabel65.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel62.add(jLabel65);

                        lblAge.setAlignmentX(0.5F);
                        lblAge.setPreferredSize(new java.awt.Dimension(140, 21));
                        jPanel62.add(lblAge);

                        lblMoonPhase.setAlignmentX(0.5F);
                        lblMoonPhase.setPreferredSize(new java.awt.Dimension(245, 21));
                        jPanel62.add(lblMoonPhase);

                        pnlMoonPhases.add(jPanel62, java.awt.BorderLayout.WEST);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/phases.gif")), pnlMoonPhases, bundle.getString("MoonPhases")); // NOI18N

                        pnlEclipses.setLayout(new java.awt.BorderLayout());

                        jPanel63.setPreferredSize(new java.awt.Dimension(320, 35));

                        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel63.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel63.setOpaque(true);
                        jLabel63.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(jLabel63);

                        txtYearEclipses.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtYearEclipses.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtYearEclipseskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtYearEclipsesKeyPressed(evt);
                            }
                        });
                        jPanel63.add(txtYearEclipses);

                        jLabel3.setPreferredSize(new java.awt.Dimension(95, 16));
                        jPanel63.add(jLabel3);

                        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel66.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel66.setOpaque(true);
                        jLabel66.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(jLabel66);

                        lblDateEclipse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblDateEclipse.setAlignmentX(0.5F);
                        lblDateEclipse.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblDateEclipse.setPreferredSize(new java.awt.Dimension(200, 21));
                        jPanel63.add(lblDateEclipse);

                        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel119.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel119.setOpaque(true);
                        jLabel119.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(jLabel119);

                        lblEclipse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblEclipse.setAlignmentX(0.5F);
                        lblEclipse.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblEclipse.setPreferredSize(new java.awt.Dimension(100, 21));
                        jPanel63.add(lblEclipse);

                        jLabel5.setPreferredSize(new java.awt.Dimension(95, 16));
                        jPanel63.add(jLabel5);

                        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel118.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel118.setOpaque(true);
                        jLabel118.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(jLabel118);

                        lblType.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblType.setAlignmentX(0.5F);
                        lblType.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblType.setPreferredSize(new java.awt.Dimension(200, 21));
                        jPanel63.add(lblType);

                        lblHemi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblHemi.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblHemi.setOpaque(true);
                        lblHemi.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(lblHemi);

                        lblHemisphere.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblHemisphere.setAlignmentX(0.5F);
                        lblHemisphere.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblHemisphere.setPreferredSize(new java.awt.Dimension(100, 21));
                        jPanel63.add(lblHemisphere);

                        jLabel4.setPreferredSize(new java.awt.Dimension(95, 16));
                        jPanel63.add(jLabel4);

                        lblHalfLight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblHalfLight.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblHalfLight.setOpaque(true);
                        lblHalfLight.setPreferredSize(new java.awt.Dimension(200, 19));
                        jPanel63.add(lblHalfLight);

                        lblHalfLightDuration.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblHalfLightDuration.setAlignmentX(0.5F);
                        lblHalfLightDuration.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblHalfLightDuration.setPreferredSize(new java.awt.Dimension(100, 21));
                        jPanel63.add(lblHalfLightDuration);

                        lblShadow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblShadow.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblShadow.setOpaque(true);
                        lblShadow.setPreferredSize(new java.awt.Dimension(200, 19));
                        jPanel63.add(lblShadow);

                        lblShadowDuration.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblShadowDuration.setAlignmentX(0.5F);
                        lblShadowDuration.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblShadowDuration.setPreferredSize(new java.awt.Dimension(100, 21));
                        jPanel63.add(lblShadowDuration);

                        lblDim.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblDim.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblDim.setOpaque(true);
                        lblDim.setPreferredSize(new java.awt.Dimension(100, 19));
                        jPanel63.add(lblDim);

                        lblDimension.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblDimension.setAlignmentX(0.5F);
                        lblDimension.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblDimension.setPreferredSize(new java.awt.Dimension(200, 21));
                        jPanel63.add(lblDimension);

                        btnNextEclipse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
                        btnNextEclipse.setBorder(null);
                        btnNextEclipse.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnNextEclipse.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnNextEclipseActionPerformed(evt);
                            }
                        });
                        jPanel63.add(btnNextEclipse);

                        pnlEclipses.add(jPanel63, java.awt.BorderLayout.WEST);

                        jScrollPane4.setBorder(null);
                        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                        txtResultEclipses.setLineWrap(true);
                        txtResultEclipses.setWrapStyleWord(true);
                        jScrollPane4.setViewportView(txtResultEclipses);

                        pnlEclipses.add(jScrollPane4, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/eclipse.png")), pnlEclipses, bundle.getString("Eclipses")); // NOI18N

                        pnlSeasons.setLayout(new java.awt.BorderLayout());

                        jPanel64.setPreferredSize(new java.awt.Dimension(250, 31));

                        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel71.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel71.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel71.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel71.setOpaque(true);
                        jLabel71.setPreferredSize(new java.awt.Dimension(85, 19));
                        jPanel64.add(jLabel71);

                        txtYearSeasons.setPreferredSize(new java.awt.Dimension(95, 21));
                        txtYearSeasons.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtYearSeasonskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtYearSeasonsKeyPressed(evt);
                            }
                        });
                        jPanel64.add(txtYearSeasons);

                        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel72.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel72.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel72.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel72.setOpaque(true);
                        jLabel72.setPreferredSize(new java.awt.Dimension(235, 19));
                        jPanel64.add(jLabel72);

                        lblSpring.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblSpring.setAlignmentX(0.5F);
                        lblSpring.setPreferredSize(new java.awt.Dimension(235, 21));
                        jPanel64.add(lblSpring);

                        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel73.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel73.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel73.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel73.setOpaque(true);
                        jLabel73.setPreferredSize(new java.awt.Dimension(235, 19));
                        jPanel64.add(jLabel73);

                        lblSummer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblSummer.setAlignmentX(0.5F);
                        lblSummer.setPreferredSize(new java.awt.Dimension(235, 21));
                        jPanel64.add(lblSummer);

                        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel74.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel74.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel74.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel74.setOpaque(true);
                        jLabel74.setPreferredSize(new java.awt.Dimension(235, 19));
                        jPanel64.add(jLabel74);

                        lblFall.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblFall.setAlignmentX(0.5F);
                        lblFall.setPreferredSize(new java.awt.Dimension(235, 21));
                        jPanel64.add(lblFall);

                        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel75.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel75.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel75.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel75.setOpaque(true);
                        jLabel75.setPreferredSize(new java.awt.Dimension(235, 19));
                        jPanel64.add(jLabel75);

                        lblWinter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblWinter.setAlignmentX(0.5F);
                        lblWinter.setPreferredSize(new java.awt.Dimension(235, 21));
                        jPanel64.add(lblWinter);

                        pnlSeasons.add(jPanel64, java.awt.BorderLayout.WEST);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/seasons.gif")), pnlSeasons, bundle.getString("Seasons")); // NOI18N

                        pnlAsteroids.setLayout(new java.awt.BorderLayout());

                        jPanel3.setLayout(new java.awt.FlowLayout(1, 0, 1));

                        pnlControlBarAsteroid.setMaximumSize(new java.awt.Dimension(32767, 20));
                        pnlControlBarAsteroid.setMinimumSize(new java.awt.Dimension(623, 18));
                        pnlControlBarAsteroid.setName(""); // NOI18N
                        pnlControlBarAsteroid.setPreferredSize(new java.awt.Dimension(888, 33));
                        pnlControlBarAsteroid.setLayout(new java.awt.FlowLayout(0, 1, 0));

                        jLabelAsteroid.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
                        jLabelAsteroid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabelAsteroid.setText(bundle.getString("Asteroid")); // NOI18N
                        jLabelAsteroid.setAlignmentX(1.0F);
                        jLabelAsteroid.setName(""); // NOI18N
                        jLabelAsteroid.setPreferredSize(new java.awt.Dimension(70, 18));
                        pnlControlBarAsteroid.add(jLabelAsteroid);

                        cboAsteroid.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
                        cboAsteroid.setMaximumRowCount(15);
                        cboAsteroid.setAutoscrolls(true);
                        cboAsteroid.setKeySelectionManager(new MultiKeySelectionManager());
                        cboAsteroid.setPreferredSize(new java.awt.Dimension(280, 20));
                        cboAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                cboAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(cboAsteroid);

                        btnFirstAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png"))); // NOI18N
                        btnFirstAsteroid.setToolTipText(bundle.getString("FirstRecord")); // NOI18N
                        btnFirstAsteroid.setBorderPainted(false);
                        btnFirstAsteroid.setContentAreaFilled(false);
                        btnFirstAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnFirstAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnFirstAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnFirstAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnFirstAsteroid);

                        btnPreviousAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
                        btnPreviousAsteroid.setToolTipText(bundle.getString("PreviousRecord")); // NOI18N
                        btnPreviousAsteroid.setBorderPainted(false);
                        btnPreviousAsteroid.setContentAreaFilled(false);
                        btnPreviousAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnPreviousAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnPreviousAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnPreviousAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnPreviousAsteroid);

                        txtCounterAsteroid.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                        txtCounterAsteroid.setText(bundle.getString("NewAsteroid")); // NOI18N
                        txtCounterAsteroid.setPreferredSize(new java.awt.Dimension(200, 22));
                        txtCounterAsteroid.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyReleased(java.awt.event.KeyEvent evt)
                            {
                                txtCounterAsteroidKeyReleased(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(txtCounterAsteroid);

                        btnNextAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
                        btnNextAsteroid.setToolTipText(bundle.getString("NextRecord")); // NOI18N
                        btnNextAsteroid.setBorderPainted(false);
                        btnNextAsteroid.setContentAreaFilled(false);
                        btnNextAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnNextAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnNextAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnNextAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnNextAsteroid);

                        btnLastAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png"))); // NOI18N
                        btnLastAsteroid.setToolTipText(bundle.getString("LastRecord")); // NOI18N
                        btnLastAsteroid.setBorderPainted(false);
                        btnLastAsteroid.setContentAreaFilled(false);
                        btnLastAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnLastAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnLastAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnLastAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnLastAsteroid);

                        btnRemoveAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
                        btnRemoveAsteroid.setToolTipText(bundle.getString("RemoveRecord")); // NOI18N
                        btnRemoveAsteroid.setBorderPainted(false);
                        btnRemoveAsteroid.setContentAreaFilled(false);
                        btnRemoveAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnRemoveAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnRemoveAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnRemoveAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnRemoveAsteroid);

                        btnAddAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
                        btnAddAsteroid.setToolTipText(bundle.getString("AddRecord")); // NOI18N
                        btnAddAsteroid.setBorderPainted(false);
                        btnAddAsteroid.setContentAreaFilled(false);
                        btnAddAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnAddAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnAddAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnAddAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnAddAsteroid);

                        btnOKAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
                        btnOKAsteroid.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS")); // NOI18N
                        btnOKAsteroid.setBorderPainted(false);
                        btnOKAsteroid.setContentAreaFilled(false);
                        btnOKAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnOKAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnOKAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnOKAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnOKAsteroid);

                        btnCancelAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
                        btnCancelAsteroid.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS")); // NOI18N
                        btnCancelAsteroid.setBorderPainted(false);
                        btnCancelAsteroid.setContentAreaFilled(false);
                        btnCancelAsteroid.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnCancelAsteroid.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnCancelAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnCancelAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnCancelAsteroid);

                        btnQueriesAsteroid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
                        btnQueriesAsteroid.setBorder(null);
                        btnQueriesAsteroid.setContentAreaFilled(false);
                        btnQueriesAsteroid.setOpaque(true);
                        btnQueriesAsteroid.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnQueriesAsteroidActionPerformed(evt);
                            }
                        });
                        pnlControlBarAsteroid.add(btnQueriesAsteroid);

                        jPanel3.add(pnlControlBarAsteroid);

                        pnlAsteroids.add(jPanel3, java.awt.BorderLayout.NORTH);

                        pnlDetailAsteroid.setPreferredSize(new java.awt.Dimension(315, 28));
                        pnlDetailAsteroid.setLayout(new java.awt.FlowLayout(0, 0, 0));

                        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel87.setText(bundle.getString("Number")); // NOI18N
                        jLabel87.setOpaque(true);
                        jLabel87.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel87);

                        txtAsteroidNumber.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidNumber.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidNumberkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidNumberKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidNumber);

                        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel99.setText(bundle.getString("MeanAnomaly")); // NOI18N
                        jLabel99.setOpaque(true);
                        jLabel99.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel99);

                        txtAsteroidAM.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidAM.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidAMkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidAMKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidAM);

                        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel88.setText(bundle.getString("HMagnitude")); // NOI18N
                        jLabel88.setOpaque(true);
                        jLabel88.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel88);

                        txtAsteroidM.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidM.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidMkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidMKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidM);

                        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel89.setText(bundle.getString("Eccentricity")); // NOI18N
                        jLabel89.setOpaque(true);
                        jLabel89.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel89);

                        txtAsteroidE.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidE.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidEkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidEKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidE);

                        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel90.setText(bundle.getString("PerihelionLongitude")); // NOI18N
                        jLabel90.setOpaque(true);
                        jLabel90.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel90);

                        txtAsteroidAP.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidAP.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidAPkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidAPKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidAP);

                        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel91.setText(bundle.getString("NorthNodeLongitude")); // NOI18N
                        jLabel91.setOpaque(true);
                        jLabel91.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel91);

                        txtAsteroidLNA.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidLNA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidLNAkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidLNAKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidLNA);

                        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel96.setText(bundle.getString("Inclination")); // NOI18N
                        jLabel96.setOpaque(true);
                        jLabel96.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel96);

                        txtAsteroidI.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidI.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidIkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidIKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidI);

                        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel97.setText(bundle.getString("SemiMajorAxis")); // NOI18N
                        jLabel97.setOpaque(true);
                        jLabel97.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel97);

                        txtAsteroid12A.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroid12A.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroid12AkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroid12AKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroid12A);

                        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel98.setText(bundle.getString("Epoch")); // NOI18N
                        jLabel98.setOpaque(true);
                        jLabel98.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailAsteroid.add(jLabel98);

                        txtAsteroidEpoch.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtAsteroidEpoch.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidEpochkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtAsteroidEpochKeyPressed(evt);
                            }
                        });
                        pnlDetailAsteroid.add(txtAsteroidEpoch);

                        jPanel23.setPreferredSize(new java.awt.Dimension(100, 1));
                        pnlDetailAsteroid.add(jPanel23);

                        jPnlAsteroidPhoto.setPreferredSize(new java.awt.Dimension(310, 215));
                        jPnlAsteroidPhoto.setRequestFocusEnabled(false);
                        jPnlAsteroidPhoto.setLayout(new java.awt.BorderLayout());
                        pnlDetailAsteroid.add(jPnlAsteroidPhoto);

                        pnlAsteroids.add(pnlDetailAsteroid, java.awt.BorderLayout.WEST);

                        jPanel12.setLayout(new java.awt.BorderLayout());

                        pnlDataAsteroid.setLayout(new java.awt.BorderLayout());

                        jScrollPane1.setBorder(null);
                        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                        txtResultAsteroid.setLineWrap(true);
                        txtResultAsteroid.setWrapStyleWord(true);
                        jScrollPane1.setViewportView(txtResultAsteroid);

                        pnlDataAsteroid.add(jScrollPane1, java.awt.BorderLayout.CENTER);

                        jPanel12.add(pnlDataAsteroid, java.awt.BorderLayout.CENTER);

                        pnlAsteroids.add(jPanel12, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/asteroid.png")), pnlAsteroids, bundle.getString("Asteroids")); // NOI18N

                        pnlComets.setLayout(new java.awt.BorderLayout());

                        jPanel16.setLayout(new java.awt.FlowLayout(1, 0, 1));

                        pnlControlBarComet.setMaximumSize(new java.awt.Dimension(32767, 20));
                        pnlControlBarComet.setMinimumSize(new java.awt.Dimension(623, 18));
                        pnlControlBarComet.setName(""); // NOI18N
                        pnlControlBarComet.setPreferredSize(new java.awt.Dimension(888, 33));
                        pnlControlBarComet.setLayout(new java.awt.FlowLayout(0, 1, 0));

                        jLabelComet.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
                        jLabelComet.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabelComet.setText(bundle.getString("Comet")); // NOI18N
                        jLabelComet.setAlignmentX(1.0F);
                        jLabelComet.setName(""); // NOI18N
                        jLabelComet.setPreferredSize(new java.awt.Dimension(70, 18));
                        pnlControlBarComet.add(jLabelComet);

                        cboComet.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
                        cboComet.setMaximumRowCount(15);
                        cboComet.setAutoscrolls(true);
                        cboComet.setKeySelectionManager(new MultiKeySelectionManager());
                        cboComet.setPreferredSize(new java.awt.Dimension(280, 20));
                        cboComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                cboCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(cboComet);

                        btnFirstComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png"))); // NOI18N
                        btnFirstComet.setToolTipText(bundle.getString("FirstRecord")); // NOI18N
                        btnFirstComet.setBorderPainted(false);
                        btnFirstComet.setContentAreaFilled(false);
                        btnFirstComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnFirstComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnFirstComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnFirstCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnFirstComet);

                        btnPreviousComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
                        btnPreviousComet.setToolTipText(bundle.getString("PreviousRecord")); // NOI18N
                        btnPreviousComet.setBorderPainted(false);
                        btnPreviousComet.setContentAreaFilled(false);
                        btnPreviousComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnPreviousComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnPreviousComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnPreviousCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnPreviousComet);

                        txtCounterComet.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                        txtCounterComet.setText(bundle.getString("NewComet")); // NOI18N
                        txtCounterComet.setMaximumSize(null);
                        txtCounterComet.setPreferredSize(new java.awt.Dimension(200, 22));
                        txtCounterComet.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyReleased(java.awt.event.KeyEvent evt)
                            {
                                txtCounterCometKeyReleased(evt);
                            }
                        });
                        pnlControlBarComet.add(txtCounterComet);

                        btnNextComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
                        btnNextComet.setToolTipText(bundle.getString("NextRecord")); // NOI18N
                        btnNextComet.setBorderPainted(false);
                        btnNextComet.setContentAreaFilled(false);
                        btnNextComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnNextComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnNextComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnNextCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnNextComet);

                        btnLastComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png"))); // NOI18N
                        btnLastComet.setToolTipText(bundle.getString("LastRecord")); // NOI18N
                        btnLastComet.setBorderPainted(false);
                        btnLastComet.setContentAreaFilled(false);
                        btnLastComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnLastComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnLastComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnLastCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnLastComet);

                        btnRemoveComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
                        btnRemoveComet.setToolTipText(bundle.getString("RemoveRecord")); // NOI18N
                        btnRemoveComet.setBorderPainted(false);
                        btnRemoveComet.setContentAreaFilled(false);
                        btnRemoveComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnRemoveComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnRemoveComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnRemoveCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnRemoveComet);

                        btnAddComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
                        btnAddComet.setToolTipText(bundle.getString("AddRecord")); // NOI18N
                        btnAddComet.setBorderPainted(false);
                        btnAddComet.setContentAreaFilled(false);
                        btnAddComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnAddComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnAddComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnAddCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnAddComet);

                        btnOKComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
                        btnOKComet.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS")); // NOI18N
                        btnOKComet.setBorderPainted(false);
                        btnOKComet.setContentAreaFilled(false);
                        btnOKComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnOKComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnOKComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnOKCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnOKComet);

                        btnCancelComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
                        btnCancelComet.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS")); // NOI18N
                        btnCancelComet.setBorderPainted(false);
                        btnCancelComet.setContentAreaFilled(false);
                        btnCancelComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnCancelComet.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnCancelComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnCancelCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnCancelComet);

                        btnQueriesComet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
                        btnQueriesComet.setToolTipText(bundle.getString("DataGrids")); // NOI18N
                        btnQueriesComet.setBorder(null);
                        btnQueriesComet.setContentAreaFilled(false);
                        btnQueriesComet.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnQueriesComet.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnQueriesCometActionPerformed(evt);
                            }
                        });
                        pnlControlBarComet.add(btnQueriesComet);

                        jPanel16.add(pnlControlBarComet);

                        pnlComets.add(jPanel16, java.awt.BorderLayout.NORTH);

                        pnlDetailComet.setPreferredSize(new java.awt.Dimension(315, 28));
                        pnlDetailComet.setLayout(new java.awt.FlowLayout(0, 0, 0));

                        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel101.setText(bundle.getString("PerihelionDate")); // NOI18N
                        jLabel101.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel101.setOpaque(true);
                        jLabel101.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel101);

                        txtCometDateP.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometDateP.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometDatePKeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometDatePKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometDateP);

                        jLabel103.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel103.setText(bundle.getString("PerihelionUA")); // NOI18N
                        jLabel103.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel103.setOpaque(true);
                        jLabel103.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel103);

                        txtCometDP.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometDP.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometDPkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometDPKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometDP);

                        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel100.setText(bundle.getString("Eccentricity")); // NOI18N
                        jLabel100.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel100.setOpaque(true);
                        jLabel100.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel100);

                        txtCometE.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometE.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometEkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometEKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometE);

                        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel102.setText(bundle.getString("PerihelionLongitude")); // NOI18N
                        jLabel102.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel102.setOpaque(true);
                        jLabel102.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel102);

                        txtCometAP.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometAP.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometAPkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometAPKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometAP);

                        jLabel105.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel105.setText(bundle.getString("NorthNodeLongitude")); // NOI18N
                        jLabel105.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel105.setOpaque(true);
                        jLabel105.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel105);

                        txtCometNA.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometNA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometNAkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometNAKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometNA);

                        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel106.setText(bundle.getString("Inclination")); // NOI18N
                        jLabel106.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel106.setOpaque(true);
                        jLabel106.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel106);

                        txtCometI.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometI.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometIkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometIKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometI);

                        jLabel107.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel107.setText(bundle.getString("SemiMajorAxis")); // NOI18N
                        jLabel107.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel107.setOpaque(true);
                        jLabel107.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel107);

                        txtComet12A.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtComet12A.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtComet12AkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtComet12AKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtComet12A);

                        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel108.setText(bundle.getString("Period")); // NOI18N
                        jLabel108.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel108.setOpaque(true);
                        jLabel108.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailComet.add(jLabel108);

                        txtCometPeriod.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtCometPeriod.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtCometPeriodkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtCometPeriodKeyPressed(evt);
                            }
                        });
                        pnlDetailComet.add(txtCometPeriod);

                        jPanel22.setPreferredSize(new java.awt.Dimension(100, 1));
                        pnlDetailComet.add(jPanel22);

                        jPnlCometPhoto.setPreferredSize(new java.awt.Dimension(310, 236));
                        jPnlCometPhoto.setRequestFocusEnabled(false);
                        jPnlCometPhoto.setLayout(new java.awt.BorderLayout());
                        pnlDetailComet.add(jPnlCometPhoto);

                        pnlComets.add(pnlDetailComet, java.awt.BorderLayout.WEST);

                        jPanel11.setLayout(new java.awt.BorderLayout());

                        pnlDataComet.setLayout(new java.awt.BorderLayout());

                        jScrollPane2.setBorder(null);
                        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                        txtResultComet.setLineWrap(true);
                        txtResultComet.setWrapStyleWord(true);
                        jScrollPane2.setViewportView(txtResultComet);

                        pnlDataComet.add(jScrollPane2, java.awt.BorderLayout.CENTER);

                        jPanel11.add(pnlDataComet, java.awt.BorderLayout.CENTER);

                        pnlComets.add(jPanel11, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/comets.png")), pnlComets, bundle.getString("Comets")); // NOI18N

                        pnlStars.setLayout(new java.awt.BorderLayout());

                        jPanel17.setLayout(new java.awt.FlowLayout(1, 0, 1));

                        pnlControlBarStar.setMaximumSize(new java.awt.Dimension(32767, 20));
                        pnlControlBarStar.setMinimumSize(new java.awt.Dimension(623, 18));
                        pnlControlBarStar.setName(""); // NOI18N
                        pnlControlBarStar.setPreferredSize(new java.awt.Dimension(888, 33));
                        pnlControlBarStar.setLayout(new java.awt.FlowLayout(0, 1, 0));

                        jLabelStar.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
                        jLabelStar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabelStar.setText(bundle.getString("Star")); // NOI18N
                        jLabelStar.setAlignmentX(1.0F);
                        jLabelStar.setName(""); // NOI18N
                        jLabelStar.setPreferredSize(new java.awt.Dimension(70, 18));
                        pnlControlBarStar.add(jLabelStar);

                        cboStar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
                        cboStar.setMaximumRowCount(15);
                        cboStar.setAutoscrolls(true);
                        cboStar.setKeySelectionManager(new MultiKeySelectionManager());
                        cboStar.setPreferredSize(new java.awt.Dimension(280, 20));
                        cboStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                cboStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(cboStar);

                        btnFirstStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/first.png"))); // NOI18N
                        btnFirstStar.setToolTipText(bundle.getString("FirstRecord")); // NOI18N
                        btnFirstStar.setBorderPainted(false);
                        btnFirstStar.setContentAreaFilled(false);
                        btnFirstStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnFirstStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnFirstStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnFirstStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnFirstStar);

                        btnPreviousStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/left.png"))); // NOI18N
                        btnPreviousStar.setToolTipText(bundle.getString("PreviousRecord")); // NOI18N
                        btnPreviousStar.setBorderPainted(false);
                        btnPreviousStar.setContentAreaFilled(false);
                        btnPreviousStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnPreviousStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnPreviousStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnPreviousStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnPreviousStar);

                        txtCounterStar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                        txtCounterStar.setText(bundle.getString("NewStar")); // NOI18N
                        txtCounterStar.setMaximumSize(null);
                        txtCounterStar.setPreferredSize(new java.awt.Dimension(200, 22));
                        txtCounterStar.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyReleased(java.awt.event.KeyEvent evt)
                            {
                                txtCounterStarKeyReleased(evt);
                            }
                        });
                        pnlControlBarStar.add(txtCounterStar);

                        btnNextStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
                        btnNextStar.setToolTipText(bundle.getString("NextRecord")); // NOI18N
                        btnNextStar.setBorderPainted(false);
                        btnNextStar.setContentAreaFilled(false);
                        btnNextStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnNextStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnNextStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnNextStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnNextStar);

                        btnLastStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/last.png"))); // NOI18N
                        btnLastStar.setToolTipText(bundle.getString("LastRecord")); // NOI18N
                        btnLastStar.setBorderPainted(false);
                        btnLastStar.setContentAreaFilled(false);
                        btnLastStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnLastStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnLastStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnLastStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnLastStar);

                        btnRemoveStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
                        btnRemoveStar.setToolTipText(bundle.getString("RemoveRecord")); // NOI18N
                        btnRemoveStar.setBorderPainted(false);
                        btnRemoveStar.setContentAreaFilled(false);
                        btnRemoveStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnRemoveStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnRemoveStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnRemoveStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnRemoveStar);

                        btnAddStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
                        btnAddStar.setToolTipText(bundle.getString("AddRecord")); // NOI18N
                        btnAddStar.setBorderPainted(false);
                        btnAddStar.setContentAreaFilled(false);
                        btnAddStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnAddStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnAddStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnAddStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnAddStar);

                        btnOKStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
                        btnOKStar.setToolTipText(bundle.getString("VALIDER_LES_MODIFICATIONS")); // NOI18N
                        btnOKStar.setBorderPainted(false);
                        btnOKStar.setContentAreaFilled(false);
                        btnOKStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnOKStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnOKStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnOKStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnOKStar);

                        btnCancelStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
                        btnCancelStar.setToolTipText(bundle.getString("ANNULER_LES_MODIFICATIONS")); // NOI18N
                        btnCancelStar.setBorderPainted(false);
                        btnCancelStar.setContentAreaFilled(false);
                        btnCancelStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnCancelStar.setPreferredSize(new java.awt.Dimension(32, 32));
                        btnCancelStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnCancelStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnCancelStar);

                        btnQueriesStar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
                        btnQueriesStar.setToolTipText(bundle.getString("DataGrids")); // NOI18N
                        btnQueriesStar.setBorder(null);
                        btnQueriesStar.setContentAreaFilled(false);
                        btnQueriesStar.setMargin(new java.awt.Insets(0, 0, 0, 0));
                        btnQueriesStar.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnQueriesStarActionPerformed(evt);
                            }
                        });
                        pnlControlBarStar.add(btnQueriesStar);

                        jPanel17.add(pnlControlBarStar);

                        pnlStars.add(jPanel17, java.awt.BorderLayout.NORTH);

                        pnlDetailStar.setMinimumSize(new java.awt.Dimension(320, 320));
                        pnlDetailStar.setPreferredSize(new java.awt.Dimension(315, 320));
                        pnlDetailStar.setLayout(new java.awt.FlowLayout(0, 0, 0));

                        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel104.setText(bundle.getString("Name")); // NOI18N
                        jLabel104.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel104.setOpaque(true);
                        jLabel104.setPreferredSize(new java.awt.Dimension(120, 19));
                        pnlDetailStar.add(jLabel104);

                        txtStarName.setPreferredSize(new java.awt.Dimension(190, 21));
                        txtStarName.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarNameKeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarNameKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarName);

                        lblStarMagnitude.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblStarMagnitude.setText(bundle.getString("SpectralClassLuminosity")); // NOI18N
                        lblStarMagnitude.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblStarMagnitude.setOpaque(true);
                        lblStarMagnitude.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(lblStarMagnitude);

                        txtStarSCI.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarSCI.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarSCIKeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarSCIKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarSCI);

                        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel110.setText(bundle.getString("RightAscension")); // NOI18N
                        jLabel110.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel110.setOpaque(true);
                        jLabel110.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel110);

                        txtStarRA.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarRA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarRAkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarRAKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarRA);

                        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel111.setText(bundle.getString("Declination")); // NOI18N
                        jLabel111.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel111.setOpaque(true);
                        jLabel111.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel111);

                        txtStarD.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarD.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarDkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarDKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarD);

                        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel112.setText(bundle.getString("ProperMotionRA")); // NOI18N
                        jLabel112.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel112.setOpaque(true);
                        jLabel112.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel112);

                        txtStarMotionRA.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarMotionRA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarMotionRAkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarMotionRAKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarMotionRA);

                        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel113.setText(bundle.getString("ProperMotionD")); // NOI18N
                        jLabel113.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel113.setOpaque(true);
                        jLabel113.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel113);

                        txtStarMotionD.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarMotionD.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarMotionDkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarMotionDKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarMotionD);

                        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel114.setText(bundle.getString("RadialVelocity")); // NOI18N
                        jLabel114.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel114.setOpaque(true);
                        jLabel114.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel114);

                        txtStarRV.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarRV.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarRVkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarRVKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarRV);

                        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel115.setText(bundle.getString("DistanceAL")); // NOI18N
                        jLabel115.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel115.setOpaque(true);
                        jLabel115.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel115);

                        txtStarDistance.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarDistance.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarDistancekeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarDistanceKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarDistance);

                        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel116.setText(bundle.getString("DistError")); // NOI18N
                        jLabel116.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel116.setOpaque(true);
                        jLabel116.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel116);

                        txtStarErrDist.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarErrDist.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarErrDistkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarErrDistKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarErrDist);

                        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel117.setText(bundle.getString("IdentifyingNumberHR")); // NOI18N
                        jLabel117.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel117.setOpaque(true);
                        jLabel117.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel117);

                        txtStarHR.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarHR.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarHRkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarHRKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarHR);

                        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel120.setText(bundle.getString("Magnitude")); // NOI18N
                        jLabel120.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel120.setOpaque(true);
                        jLabel120.setPreferredSize(new java.awt.Dimension(185, 19));
                        pnlDetailStar.add(jLabel120);

                        txtStarMagnitude.setPreferredSize(new java.awt.Dimension(125, 21));
                        txtStarMagnitude.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtStarMagnitudekeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtStarMagnitudeKeyPressed(evt);
                            }
                        });
                        pnlDetailStar.add(txtStarMagnitude);

                        jPanel18.setPreferredSize(new java.awt.Dimension(100, 1));
                        pnlDetailStar.add(jPanel18);

                        jPnlStarPhoto.setPreferredSize(new java.awt.Dimension(310, 173));
                        jPnlStarPhoto.setRequestFocusEnabled(false);
                        jPnlStarPhoto.setLayout(new java.awt.BorderLayout());
                        pnlDetailStar.add(jPnlStarPhoto);

                        pnlStars.add(pnlDetailStar, java.awt.BorderLayout.WEST);

                        jPanel10.setLayout(new java.awt.BorderLayout());

                        pnlDataStar.setLayout(new java.awt.BorderLayout());

                        jScrollPane3.setBorder(null);
                        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                        txtResultStar.setLineWrap(true);
                        txtResultStar.setWrapStyleWord(true);
                        jScrollPane3.setViewportView(txtResultStar);

                        pnlDataStar.add(jScrollPane3, java.awt.BorderLayout.CENTER);

                        jPanel10.add(pnlDataStar, java.awt.BorderLayout.CENTER);

                        pnlStars.add(jPanel10, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/stars.png")), pnlStars, bundle.getString("Stars")); // NOI18N

                        pnlDistances.setMinimumSize(new java.awt.Dimension(910, 10));
                        pnlDistances.setLayout(new java.awt.GridLayout(1, 3));

                        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel44.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel44.setOpaque(true);
                        jLabel44.setPreferredSize(new java.awt.Dimension(280, 19));
                        jPanel42.add(jLabel44);

                        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel45.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel45.setOpaque(true);
                        jLabel45.setPreferredSize(new java.awt.Dimension(110, 19));
                        jPanel42.add(jLabel45);

                        txtLatitudePlaceA.setText(" 00�00'00\"");
                        txtLatitudePlaceA.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtLatitudePlaceA.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLatitudePlaceAFocusLost(evt);
                            }
                        });
                        txtLatitudePlaceA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLatitudePlaceAKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLatitudePlaceAkeyTyped(evt);
                            }
                        });
                        jPanel42.add(txtLatitudePlaceA);

                        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel46.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel46.setOpaque(true);
                        jLabel46.setPreferredSize(new java.awt.Dimension(110, 19));
                        jPanel42.add(jLabel46);

                        txtLongitudePlaceA.setText(" 000�00'00\"");
                        txtLongitudePlaceA.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtLongitudePlaceA.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudePlaceAFocusLost(evt);
                            }
                        });
                        txtLongitudePlaceA.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlaceAKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlaceAkeyTyped(evt);
                            }
                        });
                        jPanel42.add(txtLongitudePlaceA);

                        pnlDistances.add(jPanel42);

                        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel48.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel48.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
                        jLabel48.setOpaque(true);
                        jLabel48.setPreferredSize(new java.awt.Dimension(280, 19));
                        jPanel44.add(jLabel48);

                        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel49.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel49.setOpaque(true);
                        jLabel49.setPreferredSize(new java.awt.Dimension(110, 19));
                        jPanel44.add(jLabel49);

                        txtLatitudePlaceB.setText(" 00�00'00\"");
                        txtLatitudePlaceB.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtLatitudePlaceB.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLatitudePlaceBFocusLost(evt);
                            }
                        });
                        txtLatitudePlaceB.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLatitudePlaceBKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLatitudePlaceBkeyTyped(evt);
                            }
                        });
                        jPanel44.add(txtLatitudePlaceB);

                        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel50.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel50.setOpaque(true);
                        jLabel50.setPreferredSize(new java.awt.Dimension(110, 19));
                        jPanel44.add(jLabel50);

                        txtLongitudePlaceB.setText(" 000�00'00\"");
                        txtLongitudePlaceB.setPreferredSize(new java.awt.Dimension(140, 21));
                        txtLongitudePlaceB.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudePlaceBFocusLost(evt);
                            }
                        });
                        txtLongitudePlaceB.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlaceBKeyPressed(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlaceBkeyTyped(evt);
                            }
                        });
                        jPanel44.add(txtLongitudePlaceB);

                        pnlDistances.add(jPanel44);

                        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel47.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel47.setOpaque(true);
                        jLabel47.setPreferredSize(new java.awt.Dimension(215, 19));
                        jPanel43.add(jLabel47);

                        lblAngleAB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblAngleAB.setAlignmentX(0.5F);
                        lblAngleAB.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblAngleAB.setIconTextGap(0);
                        lblAngleAB.setPreferredSize(new java.awt.Dimension(200, 22));
                        jPanel43.add(lblAngleAB);

                        JLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        JLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        JLabel1.setOpaque(true);
                        JLabel1.setPreferredSize(new java.awt.Dimension(215, 19));
                        jPanel43.add(JLabel1);

                        lblDistanceAB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        lblDistanceAB.setAlignmentX(0.5F);
                        lblDistanceAB.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                        lblDistanceAB.setIconTextGap(0);
                        lblDistanceAB.setPreferredSize(new java.awt.Dimension(200, 22));
                        jPanel43.add(lblDistanceAB);

                        pnlDistances.add(jPanel43);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/placesdist.gif")), pnlDistances, bundle.getString("DistancesBetweenPlaces")); // NOI18N

                        pnlFindDate.setLayout(new java.awt.BorderLayout());

                        jPanel75.setPreferredSize(new java.awt.Dimension(550, 35));
                        jPanel75.setLayout(new java.awt.FlowLayout(1, 5, 0));

                        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                        jLabel67.setText(bundle.getString("SupposedYear")); // NOI18N
                        jLabel67.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        jLabel67.setMaximumSize(new java.awt.Dimension(110, 18));
                        jLabel67.setMinimumSize(new java.awt.Dimension(110, 18));
                        jLabel67.setOpaque(true);
                        jLabel67.setPreferredSize(new java.awt.Dimension(200, 19));
                        jPanel75.add(jLabel67);

                        txtSupposedYear.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtSupposedYear.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtSupposedYearkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtSupposedYearKeyPressed(evt);
                            }
                        });
                        jPanel75.add(txtSupposedYear);

                        jLabel6.setText(bundle.getString("PositionDegres")); // NOI18N
                        jPanel46.add(jLabel6);
                        jLabel6.getAccessibleContext().setAccessibleName(bundle.getString("PositionDegres")); // NOI18N

                        jPanel75.add(jPanel46);

                        jPanel24.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblSun.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblSun.setText("A");
                        lblSun.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblSun.setOpaque(true);
                        lblSun.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel24.add(lblSun);

                        txtLongitudeSun.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeSun.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeSunMousePressed(evt);
                            }
                        });
                        txtLongitudeSun.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeSunFocusLost(evt);
                            }
                        });
                        txtLongitudeSun.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeSunkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeSunKeyPressed(evt);
                            }
                        });
                        jPanel24.add(txtLongitudeSun);

                        cboLongitudeSun.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeSun.setMaximumRowCount(12);
                        cboLongitudeSun.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeSun.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel24.add(cboLongitudeSun);

                        jPanel75.add(jPanel24);

                        jPanel25.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblMoon.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblMoon.setText("B");
                        lblMoon.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblMoon.setOpaque(true);
                        lblMoon.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel25.add(lblMoon);

                        txtLongitudeMoon.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeMoon.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeMoonMousePressed(evt);
                            }
                        });
                        txtLongitudeMoon.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeMoonFocusLost(evt);
                            }
                        });
                        txtLongitudeMoon.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMoonkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMoonKeyPressed(evt);
                            }
                        });
                        jPanel25.add(txtLongitudeMoon);

                        cboLongitudeMoon.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeMoon.setMaximumRowCount(12);
                        cboLongitudeMoon.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeMoon.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel25.add(cboLongitudeMoon);

                        jPanel75.add(jPanel25);

                        jPanel28.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblMercury.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblMercury.setText("C");
                        lblMercury.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblMercury.setOpaque(true);
                        lblMercury.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel28.add(lblMercury);

                        txtLongitudeMercury.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeMercury.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeMercuryMousePressed(evt);
                            }
                        });
                        txtLongitudeMercury.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeMercuryFocusLost(evt);
                            }
                        });
                        txtLongitudeMercury.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMercurykeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMercuryKeyPressed(evt);
                            }
                        });
                        jPanel28.add(txtLongitudeMercury);

                        cboLongitudeMercury.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeMercury.setMaximumRowCount(12);
                        cboLongitudeMercury.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeMercury.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel28.add(cboLongitudeMercury);

                        jPanel75.add(jPanel28);

                        jPanel29.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblVenus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblVenus.setText("D");
                        lblVenus.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblVenus.setOpaque(true);
                        lblVenus.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel29.add(lblVenus);

                        txtLongitudeVenus.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeVenus.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeVenusMousePressed(evt);
                            }
                        });
                        txtLongitudeVenus.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeVenusFocusLost(evt);
                            }
                        });
                        txtLongitudeVenus.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeVenuskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeVenusKeyPressed(evt);
                            }
                        });
                        jPanel29.add(txtLongitudeVenus);

                        cboLongitudeVenus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeVenus.setMaximumRowCount(12);
                        cboLongitudeVenus.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeVenus.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel29.add(cboLongitudeVenus);

                        jPanel75.add(jPanel29);

                        jPanel30.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblMars.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblMars.setText("E");
                        lblMars.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblMars.setOpaque(true);
                        lblMars.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel30.add(lblMars);

                        txtLongitudeMars.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeMars.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeMarsMousePressed(evt);
                            }
                        });
                        txtLongitudeMars.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeMarsFocusLost(evt);
                            }
                        });
                        txtLongitudeMars.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMarskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMarsKeyPressed(evt);
                            }
                        });
                        jPanel30.add(txtLongitudeMars);

                        cboLongitudeMars.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeMars.setMaximumRowCount(12);
                        cboLongitudeMars.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeMars.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel30.add(cboLongitudeMars);

                        jPanel75.add(jPanel30);

                        jPanel45.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblJupiter.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblJupiter.setText("F");
                        lblJupiter.setToolTipText(bundle.getString("Click2ModifyColor")); // NOI18N
                        lblJupiter.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblJupiter.setOpaque(true);
                        lblJupiter.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel45.add(lblJupiter);

                        txtLongitudeJupiter.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeJupiter.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeJupiterMousePressed(evt);
                            }
                        });
                        txtLongitudeJupiter.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeJupiterFocusLost(evt);
                            }
                        });
                        txtLongitudeJupiter.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeJupiterkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeJupiterKeyPressed(evt);
                            }
                        });
                        jPanel45.add(txtLongitudeJupiter);

                        cboLongitudeJupiter.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeJupiter.setMaximumRowCount(12);
                        cboLongitudeJupiter.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeJupiter.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel45.add(cboLongitudeJupiter);

                        jPanel75.add(jPanel45);

                        jPanel34.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblSaturn.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblSaturn.setText("G");
                        lblSaturn.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblSaturn.setOpaque(true);
                        lblSaturn.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel34.add(lblSaturn);

                        txtLongitudeSaturn.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeSaturn.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeSaturnMousePressed(evt);
                            }
                        });
                        txtLongitudeSaturn.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeSaturnFocusLost(evt);
                            }
                        });
                        txtLongitudeSaturn.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeSaturnkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeSaturnKeyPressed(evt);
                            }
                        });
                        jPanel34.add(txtLongitudeSaturn);

                        cboLongitudeSaturn.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeSaturn.setMaximumRowCount(12);
                        cboLongitudeSaturn.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeSaturn.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel34.add(cboLongitudeSaturn);

                        jPanel75.add(jPanel34);

                        jPanel33.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblUranus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblUranus.setText("H");
                        lblUranus.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblUranus.setOpaque(true);
                        lblUranus.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel33.add(lblUranus);

                        txtLongitudeUranus.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeUranus.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeUranusMousePressed(evt);
                            }
                        });
                        txtLongitudeUranus.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeUranusFocusLost(evt);
                            }
                        });
                        txtLongitudeUranus.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeUranuskeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeUranusKeyPressed(evt);
                            }
                        });
                        jPanel33.add(txtLongitudeUranus);

                        cboLongitudeUranus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeUranus.setMaximumRowCount(12);
                        cboLongitudeUranus.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeUranus.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel33.add(cboLongitudeUranus);

                        jPanel75.add(jPanel33);

                        jPanel32.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblNeptune.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblNeptune.setText("I");
                        lblNeptune.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblNeptune.setOpaque(true);
                        lblNeptune.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel32.add(lblNeptune);

                        txtLongitudeNeptune.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeNeptune.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeNeptuneMousePressed(evt);
                            }
                        });
                        txtLongitudeNeptune.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeNeptuneFocusLost(evt);
                            }
                        });
                        txtLongitudeNeptune.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeNeptunekeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeNeptuneKeyPressed(evt);
                            }
                        });
                        jPanel32.add(txtLongitudeNeptune);

                        cboLongitudeNeptune.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeNeptune.setMaximumRowCount(12);
                        cboLongitudeNeptune.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeNeptune.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel32.add(cboLongitudeNeptune);

                        jPanel75.add(jPanel32);

                        jPanel31.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblPluto.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblPluto.setText("J");
                        lblPluto.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblPluto.setOpaque(true);
                        lblPluto.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel31.add(lblPluto);

                        txtLongitudePluto.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudePluto.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudePlutoMousePressed(evt);
                            }
                        });
                        txtLongitudePluto.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudePlutoFocusLost(evt);
                            }
                        });
                        txtLongitudePluto.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlutokeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudePlutoKeyPressed(evt);
                            }
                        });
                        jPanel31.add(txtLongitudePluto);

                        cboLongitudePluto.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudePluto.setMaximumRowCount(12);
                        cboLongitudePluto.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudePluto.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel31.add(cboLongitudePluto);

                        jPanel75.add(jPanel31);

                        jPanel27.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblAS.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblAS.setText("X");
                        lblAS.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblAS.setOpaque(true);
                        lblAS.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel27.add(lblAS);

                        txtLongitudeAS.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeAS.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeASMousePressed(evt);
                            }
                        });
                        txtLongitudeAS.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeASFocusLost(evt);
                            }
                        });
                        txtLongitudeAS.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeASkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeASKeyPressed(evt);
                            }
                        });
                        jPanel27.add(txtLongitudeAS);

                        cboLongitudeAS.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeAS.setMaximumRowCount(12);
                        cboLongitudeAS.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeAS.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel27.add(cboLongitudeAS);

                        jPanel75.add(jPanel27);

                        jPanel26.setPreferredSize(new java.awt.Dimension(250, 33));

                        lblMC.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        lblMC.setText("Y");
                        lblMC.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
                        lblMC.setOpaque(true);
                        lblMC.setPreferredSize(new java.awt.Dimension(30, 18));
                        jPanel26.add(lblMC);

                        txtLongitudeMC.setPreferredSize(new java.awt.Dimension(100, 21));
                        txtLongitudeMC.addMouseListener(new java.awt.event.MouseAdapter()
                        {
                            public void mousePressed(java.awt.event.MouseEvent evt)
                            {
                                txtLongitudeMCMousePressed(evt);
                            }
                        });
                        txtLongitudeMC.addFocusListener(new java.awt.event.FocusAdapter()
                        {
                            public void focusLost(java.awt.event.FocusEvent evt)
                            {
                                txtLongitudeMCFocusLost(evt);
                            }
                        });
                        txtLongitudeMC.addKeyListener(new java.awt.event.KeyAdapter()
                        {
                            public void keyTyped(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMCkeyTyped(evt);
                            }
                            public void keyPressed(java.awt.event.KeyEvent evt)
                            {
                                txtLongitudeMCKeyPressed(evt);
                            }
                        });
                        jPanel26.add(txtLongitudeMC);

                        cboLongitudeMC.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
                        cboLongitudeMC.setMaximumRowCount(12);
                        cboLongitudeMC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~" }));
                        cboLongitudeMC.setPreferredSize(new java.awt.Dimension(70, 24));
                        jPanel26.add(cboLongitudeMC);

                        jPanel75.add(jPanel26);

                        jPanel48.setPreferredSize(new java.awt.Dimension(500, 20));
                        jPanel75.add(jPanel48);

                        jTextArea1.setColumns(20);
                        jTextArea1.setEditable(false);
                        jTextArea1.setLineWrap(true);
                        jTextArea1.setRows(5);
                        jTextArea1.setText(bundle.getString("PlanetsToTake")); // NOI18N
                        jTextArea1.setWrapStyleWord(true);
                        jTextArea1.setAutoscrolls(false);
                        jTextArea1.setFocusable(false);
                        jTextArea1.setOpaque(false);
                        jTextArea1.setPreferredSize(new java.awt.Dimension(526, 80));
                        jPanel75.add(jTextArea1);

                        btnClear.setPreferredSize(new java.awt.Dimension(120, 26));
                        btnClear.addActionListener(new java.awt.event.ActionListener()
                        {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                            {
                                btnClearActionPerformed(evt);
                            }
                        });
                        jPanel75.add(btnClear);

                        pnlFindDate.add(jPanel75, java.awt.BorderLayout.WEST);

                        jScrollPane6.setBorder(null);
                        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                        txtResultFindDate.setLineWrap(true);
                        txtResultFindDate.setWrapStyleWord(true);
                        jScrollPane6.setViewportView(txtResultFindDate);

                        pnlFindDate.add(jScrollPane6, java.awt.BorderLayout.CENTER);

                        tabMain.addTab("", new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/calendar2.png")), pnlFindDate, bundle.getString("FindDate")); // NOI18N

                        tabMain.setSelectedComponent(pnlEphemeris);

                        getContentPane().add(tabMain, java.awt.BorderLayout.CENTER);

                        pack();
                    }// </editor-fold>//GEN-END:initComponents

    private void txtDate2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDate2KeyPressed
    {//GEN-HEADEREND:event_txtDate2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDate2.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDate2, kc);
    }//GEN-LAST:event_txtDate2KeyPressed

    private void txtDate1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDate1KeyPressed
    {//GEN-HEADEREND:event_txtDate1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDate1.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDate1, kc);
    }//GEN-LAST:event_txtDate1KeyPressed

    private void txtLSTTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLSTTimeKeyPressed
    {//GEN-HEADEREND:event_txtLSTTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLSTTime.getCaretPosition();
        }
        KTTime t;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            t = new KTTime(evt, txtLSTTime, kc);
    }//GEN-LAST:event_txtLSTTimeKeyPressed

    private void txtTimeTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimeTimeKeyPressed
    {//GEN-HEADEREND:event_txtTimeTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtTimeTime.getCaretPosition();
        }
        KTTime t;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            t = new KTTime(evt, txtTimeTime, kc);
    }//GEN-LAST:event_txtTimeTimeKeyPressed

    private void txtDateTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateTimeKeyPressed
    {//GEN-HEADEREND:event_txtDateTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateTime.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDateTime, kc);
    }//GEN-LAST:event_txtDateTimeKeyPressed

    private void txtLongitudeTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeTimeKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtLongitudeTimeKeyPressed

    private void txtEasterYearKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEasterYearKeyPressed
    {//GEN-HEADEREND:event_txtEasterYearKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtEasterYearKeyPressed

    private void txtDateDayNameKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateDayNameKeyPressed
    {//GEN-HEADEREND:event_txtDateDayNameKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateDayName.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDateDayName, kc);
    }//GEN-LAST:event_txtDateDayNameKeyPressed

    private void txtAstronomicalKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAstronomicalKeyPressed
    {//GEN-HEADEREND:event_txtAstronomicalKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtAstronomical.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtAstronomical, kc);
    }//GEN-LAST:event_txtAstronomicalKeyPressed

    private void txtGeographicalKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtGeographicalKeyPressed
    {//GEN-HEADEREND:event_txtGeographicalKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtGeographical.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtGeographical, kc);
    }//GEN-LAST:event_txtGeographicalKeyPressed

    private void txtAltitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAltitudeKeyPressed
    {//GEN-HEADEREND:event_txtAltitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtAltitudeKeyPressed

    private void txtDecimalKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDecimalKeyPressed
    {//GEN-HEADEREND:event_txtDecimalKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtDecimalKeyPressed

    private void txtSexagesimalKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSexagesimalKeyPressed
    {//GEN-HEADEREND:event_txtSexagesimalKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtSexagesimal.getCaretPosition();
        }
        KTLongitude deg;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            deg = new KTLongitude(evt, txtSexagesimal, kc);
    }//GEN-LAST:event_txtSexagesimalKeyPressed

    private void txtJulianDayKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJulianDayKeyPressed
    {//GEN-HEADEREND:event_txtJulianDayKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtJulianDayKeyPressed

    private void txtGregorianDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtGregorianDateKeyPressed
    {//GEN-HEADEREND:event_txtGregorianDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtGregorianDate.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtGregorianDate, kc);
    }//GEN-LAST:event_txtGregorianDateKeyPressed

    private void txtLongitudePlaceBKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlaceBKeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlaceBKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePlaceB.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudePlaceB, kc);
    }//GEN-LAST:event_txtLongitudePlaceBKeyPressed

    private void txtLatitudePlaceBKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlaceBKeyPressed
    {//GEN-HEADEREND:event_txtLatitudePlaceBKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudePlaceB.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudePlaceB, kc);
    }//GEN-LAST:event_txtLatitudePlaceBKeyPressed

    private void txtLongitudePlaceAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlaceAKeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlaceAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePlaceA.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudePlaceA, kc);
    }//GEN-LAST:event_txtLongitudePlaceAKeyPressed

    private void txtLatitudePlaceAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlaceAKeyPressed
    {//GEN-HEADEREND:event_txtLatitudePlaceAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudePlaceA.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudePlaceA, kc);
    }//GEN-LAST:event_txtLatitudePlaceAKeyPressed

    private void txtStarMagnitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMagnitudeKeyPressed
    {//GEN-HEADEREND:event_txtStarMagnitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarMagnitude.setText(new Double(starMagnitude).toString());
        }
    }//GEN-LAST:event_txtStarMagnitudeKeyPressed

    private void txtStarHRKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarHRKeyPressed
    {//GEN-HEADEREND:event_txtStarHRKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarHR.setText(new Double(starHR).toString());
        }
    }//GEN-LAST:event_txtStarHRKeyPressed

    private void txtStarErrDistKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarErrDistKeyPressed
    {//GEN-HEADEREND:event_txtStarErrDistKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarErrDist.setText(new Double(starErrDist).toString());
        }
    }//GEN-LAST:event_txtStarErrDistKeyPressed

    private void txtStarDistanceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarDistanceKeyPressed
    {//GEN-HEADEREND:event_txtStarDistanceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarDistance.setText(new Double(starDistance).toString());
        }
    }//GEN-LAST:event_txtStarDistanceKeyPressed

    private void txtStarRVKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarRVKeyPressed
    {//GEN-HEADEREND:event_txtStarRVKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarRV.setText(new Double(starVelocity).toString());
        }
    }//GEN-LAST:event_txtStarRVKeyPressed

    private void txtStarMotionDKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMotionDKeyPressed
    {//GEN-HEADEREND:event_txtStarMotionDKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarMotionD.setText(new Double(starMotionD).toString());
        }
    }//GEN-LAST:event_txtStarMotionDKeyPressed

    private void txtStarMotionRAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMotionRAKeyPressed
    {//GEN-HEADEREND:event_txtStarMotionRAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarMotionRA.setText(new Double(starMotionRA).toString());
        }
    }//GEN-LAST:event_txtStarMotionRAKeyPressed

    private void txtStarDKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarDKeyPressed
    {//GEN-HEADEREND:event_txtStarDKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarD.setText(new Double(starD).toString());
        }
    }//GEN-LAST:event_txtStarDKeyPressed

    private void txtStarRAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarRAKeyPressed
    {//GEN-HEADEREND:event_txtStarRAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarRA.setText(new Double(starRA).toString());
        }
    }//GEN-LAST:event_txtStarRAKeyPressed

    private void txtStarSCIKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarSCIKeyTyped
    {//GEN-HEADEREND:event_txtStarSCIKeyTyped
        bolStarEditing = true;
        setStarEditMode();
        if (txtStarSCI.getText().length() >= 20 && (kc != KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
        }
    }//GEN-LAST:event_txtStarSCIKeyTyped

    private void txtStarSCIKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarSCIKeyPressed
    {//GEN-HEADEREND:event_txtStarSCIKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarSCI.setText(starLuminosity);
        }
    }//GEN-LAST:event_txtStarSCIKeyPressed

    private void txtStarNameKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarNameKeyTyped
    {//GEN-HEADEREND:event_txtStarNameKeyTyped
        bolStarEditing = true;
        setStarEditMode();
        if (txtStarName.getText().length() >= 50 && (kc != KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
        }
    }//GEN-LAST:event_txtStarNameKeyTyped

    private void txtStarNameKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarNameKeyPressed
    {//GEN-HEADEREND:event_txtStarNameKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStarName.setText(starName);
        }
    }//GEN-LAST:event_txtStarNameKeyPressed

    private void txtCometPeriodKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometPeriodKeyPressed
    {//GEN-HEADEREND:event_txtCometPeriodKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometPeriod.setText(new Double(cometPeriod).toString());
        }
    }//GEN-LAST:event_txtCometPeriodKeyPressed

    private void txtComet12AKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtComet12AKeyPressed
    {//GEN-HEADEREND:event_txtComet12AKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtComet12A.setText(new Double(cometSemiMajorAxis).toString());
        }
    }//GEN-LAST:event_txtComet12AKeyPressed

    private void txtCometIKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometIKeyPressed
    {//GEN-HEADEREND:event_txtCometIKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometI.setText(new Double(cometInclination).toString());
        }
    }//GEN-LAST:event_txtCometIKeyPressed

    private void txtCometNAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometNAKeyPressed
    {//GEN-HEADEREND:event_txtCometNAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometNA.setText(new Double(cometNorthNodeLongitude).toString());
        }
    }//GEN-LAST:event_txtCometNAKeyPressed

    private void txtCometAPKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometAPKeyPressed
    {//GEN-HEADEREND:event_txtCometAPKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometAP.setText(new Double(cometPerihelionLongitude).toString());
        }
    }//GEN-LAST:event_txtCometAPKeyPressed

    private void txtCometEKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometEKeyPressed
    {//GEN-HEADEREND:event_txtCometEKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometE.setText(new Double(cometEccentricity).toString());
        }
    }//GEN-LAST:event_txtCometEKeyPressed

    private void txtCometDPKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometDPKeyPressed
    {//GEN-HEADEREND:event_txtCometDPKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometDP.setText(new Double(cometPerihelionDistance).toString());
        }
    }//GEN-LAST:event_txtCometDPKeyPressed

    private void txtCometDatePKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometDatePKeyTyped
    {//GEN-HEADEREND:event_txtCometDatePKeyTyped
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometDateP.setText(new Double(cometPerihelionDistance).toString());
        }
    }//GEN-LAST:event_txtCometDatePKeyTyped

    private void txtCometDatePKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometDatePKeyPressed
    {//GEN-HEADEREND:event_txtCometDatePKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtCometDateP.setText(new Double(cometPerihelionDate).toString());
        }
    }//GEN-LAST:event_txtCometDatePKeyPressed

    private void txtAsteroidEpochKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidEpochKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidEpochKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidEpoch.setText(new Double(asteroidEpoch).toString());
        }
    }//GEN-LAST:event_txtAsteroidEpochKeyPressed

    private void txtAsteroid12AKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroid12AKeyPressed
    {//GEN-HEADEREND:event_txtAsteroid12AKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroid12A.setText(new Double(asteroidSemiMajorAxis).toString());
        }
    }//GEN-LAST:event_txtAsteroid12AKeyPressed

    private void txtAsteroidIKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidIKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidIKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidI.setText(new Double(asteroidInclination).toString());
        }
    }//GEN-LAST:event_txtAsteroidIKeyPressed

    private void txtAsteroidLNAKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidLNAKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidLNAKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidLNA.setText(new Double(asteroidNorthNodeLongitude).toString());
        }
    }//GEN-LAST:event_txtAsteroidLNAKeyPressed

    private void txtAsteroidAPKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidAPKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidAPKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidAP.setText(new Double(asteroidPerihelionLongitude).toString());
        }
    }//GEN-LAST:event_txtAsteroidAPKeyPressed

    private void txtAsteroidEKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidEKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidEKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidE.setText(new Double(asteroidEccentricity).toString());
        }
    }//GEN-LAST:event_txtAsteroidEKeyPressed

    private void txtAsteroidMKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidMKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidMKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidM.setText(new Double(asteroidMagnitude).toString());
        }
    }//GEN-LAST:event_txtAsteroidMKeyPressed

    private void txtAsteroidAMKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidAMKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidAMKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidAM.setText(new Double(asteroidMeanAnomaly).toString());
        }
    }//GEN-LAST:event_txtAsteroidAMKeyPressed

    private void txtAsteroidNumberKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidNumberKeyPressed
    {//GEN-HEADEREND:event_txtAsteroidNumberKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtAsteroidNumber.setText(new Double(asteroidNumber).toString());
        }
    }//GEN-LAST:event_txtAsteroidNumberKeyPressed

    private void txtYearSeasonsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearSeasonsKeyPressed
    {//GEN-HEADEREND:event_txtYearSeasonsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtYearSeasonsKeyPressed

    private void txtYearEclipsesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearEclipsesKeyPressed
    {//GEN-HEADEREND:event_txtYearEclipsesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtYearEclipsesKeyPressed

    private void txtTimePhasesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimePhasesKeyPressed
    {//GEN-HEADEREND:event_txtTimePhasesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtTimePhases.getCaretPosition();
        }
        KTTime t;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            t = new KTTime(evt, txtTimePhases, kc);
    }//GEN-LAST:event_txtTimePhasesKeyPressed

    private void txtDatePhasesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDatePhasesKeyPressed
    {//GEN-HEADEREND:event_txtDatePhasesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDatePhases.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDatePhases, kc);
    }//GEN-LAST:event_txtDatePhasesKeyPressed

    private void txtYearNodesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearNodesKeyPressed
    {//GEN-HEADEREND:event_txtYearNodesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtYearNodesKeyPressed

    private void txtYearPeriKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearPeriKeyPressed
    {//GEN-HEADEREND:event_txtYearPeriKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtYearPeriKeyPressed

    private void txtDateGST0KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateGST0KeyPressed
    {//GEN-HEADEREND:event_txtDateGST0KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateGST0.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDateGST0, kc);
    }//GEN-LAST:event_txtDateGST0KeyPressed

    private void txtLongitudePlace3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace3KeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlace3KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePlace3.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudePlace3, kc);
    }//GEN-LAST:event_txtLongitudePlace3KeyPressed

    private void txtLatitudePlace3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace3KeyPressed
    {//GEN-HEADEREND:event_txtLatitudePlace3KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudePlace3.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudePlace3, kc);
    }//GEN-LAST:event_txtLatitudePlace3KeyPressed

    private void txtLongitudePlace2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace2KeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlace2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePlace2.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudePlace2, kc);
    }//GEN-LAST:event_txtLongitudePlace2KeyPressed

    private void txtLatitudePlace2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace2KeyPressed
    {//GEN-HEADEREND:event_txtLatitudePlace2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudePlace2.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudePlace2, kc);
    }//GEN-LAST:event_txtLatitudePlace2KeyPressed

    private void txtLongitudePlace1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace1KeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlace1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePlace1.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudePlace1, kc);
    }//GEN-LAST:event_txtLongitudePlace1KeyPressed

    private void txtLatitudePlace1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace1KeyPressed
    {//GEN-HEADEREND:event_txtLatitudePlace1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudePlace1.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudePlace1, kc);
    }//GEN-LAST:event_txtLatitudePlace1KeyPressed

    private void txtTZKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZKeyPressed
    {//GEN-HEADEREND:event_txtTZKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtTZKeyPressed

    private void txtTimeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimeKeyPressed
    {//GEN-HEADEREND:event_txtTimeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtTime.getCaretPosition();
        }
        KTTime t;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            t = new KTTime(evt, txtTime, kc);
    }//GEN-LAST:event_txtTimeKeyPressed

    private void txtDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateKeyPressed
    {//GEN-HEADEREND:event_txtDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDate.getCaretPosition();
        }
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtDate, kc);
    }//GEN-LAST:event_txtDateKeyPressed

    private void txtLongitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitude.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitude, kc);
    }//GEN-LAST:event_txtLongitudeKeyPressed

    private void txtLatitudeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeKeyPressed
    {//GEN-HEADEREND:event_txtLatitudeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitude.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitude, kc);
    }//GEN-LAST:event_txtLatitudeKeyPressed

    private void btnProgressedMoonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnProgressedMoonActionPerformed
    {//GEN-HEADEREND:event_btnProgressedMoonActionPerformed
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        ProgressedMoon progressedMoon = new ProgressedMoon(new ChartEvent(event), defaultOption.getCoordSys());
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnProgressedMoonActionPerformed

    private void btnHinduCyclesActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnHinduCyclesActionPerformed
    {//GEN-HEADEREND:event_btnHinduCyclesActionPerformed
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Dasa.hinduCycles(new ChartEvent(event));
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnHinduCyclesActionPerformed

    private void tabMainStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_tabMainStateChanged
    {//GEN-HEADEREND:event_tabMainStateChanged
        int iMain = tabMain.getSelectedIndex();
        if (iMain == 0 || iMain == 2 || iMain == 4 || iMain == 9 || iMain == 11 || iMain == 12 || iMain == 13 || iMain == 15)
        {
            btnPrint.setVisible(true);
        }
        else
        {
            btnPrint.setVisible(false);
        }
    }//GEN-LAST:event_tabMainStateChanged

    

    private void printFindDate()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultFindDate);
        textPrinter.setCenterHeader(bundle.getString("ChartDate"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
    }

    private void printEphemeris()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultEphemeris);
        textPrinter.setCenterHeader(bundle.getString("Ephemeris"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
        J2PanelPrinter panelPrinter = new J2PanelPrinter((Component) drawEphemeris);
        panelPrinter.setCenterHeader(bundle.getString("Calendars"));
        panelPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        panelPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(panelPrinter);
        printer.print();
    }

    private void printAsteroid()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultAsteroid);
        textPrinter.setCenterHeader(bundle.getString("Asteroids"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
    }

    private void printComet()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultComet);
        textPrinter.setCenterHeader(bundle.getString("Comets"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
    }

    private void printStar()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultStar);
        textPrinter.setCenterHeader(bundle.getString("Stars"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
    }

    private void printEclipses()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2TextPrinter textPrinter = new J2TextPrinter();
        textPrinter.setTextComponent((JTextComponent) txtResultEclipses);
        textPrinter.setCenterHeader(bundle.getString("Eclipses"));
        textPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        textPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(textPrinter);
        printer.print();
    }

    private void printCalendars()
    {
        J2Printer printer = new J2Printer(bundle.getString("PWKEY"));
        J2PanelPrinter panelPrinter = new J2PanelPrinter((Component) pnlCalendars);
        panelPrinter.setCenterHeader(bundle.getString("Calendars"));
        panelPrinter.setLeftHeader(bundle.getString("STARLOGIN_VERSION"));
        panelPrinter.setRightHeader(bundle.getString("JSTROBERG@YAHOO.COM"));
        printer.setPageable(panelPrinter);
        printer.print();
    }

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrintActionPerformed
    {//GEN-HEADEREND:event_btnPrintActionPerformed
        int iMain = tabMain.getSelectedIndex();
        switch (iMain)
        {
            case 0:
                printEphemeris();
                return;
            case 2:
                drawRiseSet.print();
                return;
            case 4:
                printCalendars();
                return;
            case 9:
                printEclipses();
                return;
            case 11:
                printAsteroid();
                return;
            case 12:
                printComet();
                return;
            case 13:
                printStar();
                return;
            case 15:
                printFindDate();
            default:
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void txtStarMagnitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMagnitudekeyTyped
    {//GEN-HEADEREND:event_txtStarMagnitudekeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarMagnitude, 12, kc);
    }//GEN-LAST:event_txtStarMagnitudekeyTyped

    private void txtAsteroidEpochkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidEpochkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidEpochkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidEpoch, 12, kc);
    }//GEN-LAST:event_txtAsteroidEpochkeyTyped

    private void txtAsteroid12AkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroid12AkeyTyped
    {//GEN-HEADEREND:event_txtAsteroid12AkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroid12A, 12, kc);
    }//GEN-LAST:event_txtAsteroid12AkeyTyped

    private void txtAsteroidIkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidIkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidIkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidI, 12, kc);
    }//GEN-LAST:event_txtAsteroidIkeyTyped

    private void txtAsteroidLNAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidLNAkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidLNAkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidLNA, 12, kc);
    }//GEN-LAST:event_txtAsteroidLNAkeyTyped

    private void txtAsteroidAPkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidAPkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidAPkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidAP, 12, kc);
    }//GEN-LAST:event_txtAsteroidAPkeyTyped

    private void txtAsteroidEkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidEkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidEkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidE, 12, kc);
    }//GEN-LAST:event_txtAsteroidEkeyTyped

    private void txtAsteroidMkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidMkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidMkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidM, 12, kc);
    }//GEN-LAST:event_txtAsteroidMkeyTyped

    private void txtAsteroidAMkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidAMkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidAMkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTDecimal d = new KTDecimal(evt, txtAsteroidAM, 12, kc);
    }//GEN-LAST:event_txtAsteroidAMkeyTyped

    private void txtAsteroidNumberkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAsteroidNumberkeyTyped
    {//GEN-HEADEREND:event_txtAsteroidNumberkeyTyped
        bolAsteroidEditing = true;
        setAsteroidEditMode();
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtAsteroidNumber, 8, kc);
    }//GEN-LAST:event_txtAsteroidNumberkeyTyped

    private void txtCometPeriodkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometPeriodkeyTyped
    {//GEN-HEADEREND:event_txtCometPeriodkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometPeriod, 12, kc);
    }//GEN-LAST:event_txtCometPeriodkeyTyped

    private void txtComet12AkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtComet12AkeyTyped
    {//GEN-HEADEREND:event_txtComet12AkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtComet12A, 12, kc);
    }//GEN-LAST:event_txtComet12AkeyTyped

    private void txtCometIkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometIkeyTyped
    {//GEN-HEADEREND:event_txtCometIkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometI, 12, kc);
    }//GEN-LAST:event_txtCometIkeyTyped

    private void txtCometNAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometNAkeyTyped
    {//GEN-HEADEREND:event_txtCometNAkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometNA, 12, kc);
    }//GEN-LAST:event_txtCometNAkeyTyped

    private void txtCometAPkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometAPkeyTyped
    {//GEN-HEADEREND:event_txtCometAPkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometAP, 12, kc);
    }//GEN-LAST:event_txtCometAPkeyTyped

    private void txtCometEkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometEkeyTyped
    {//GEN-HEADEREND:event_txtCometEkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometE, 12, kc);
    }//GEN-LAST:event_txtCometEkeyTyped

    private void txtCometDPkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCometDPkeyTyped
    {//GEN-HEADEREND:event_txtCometDPkeyTyped
        bolCometEditing = true;
        setCometEditMode();
        KTDecimal d = new KTDecimal(evt, txtCometDP, 12, kc);
    }//GEN-LAST:event_txtCometDPkeyTyped

    private void txtStarHRkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarHRkeyTyped
    {//GEN-HEADEREND:event_txtStarHRkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtStarHR, 8, kc);
    }//GEN-LAST:event_txtStarHRkeyTyped

    private void txtStarErrDistkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarErrDistkeyTyped
    {//GEN-HEADEREND:event_txtStarErrDistkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarErrDist, 12, kc);
    }//GEN-LAST:event_txtStarErrDistkeyTyped

    private void txtStarDistancekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarDistancekeyTyped
    {//GEN-HEADEREND:event_txtStarDistancekeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarDistance, 12, kc);
    }//GEN-LAST:event_txtStarDistancekeyTyped

    private void txtStarRVkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarRVkeyTyped
    {//GEN-HEADEREND:event_txtStarRVkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarRV, 12, kc);
    }//GEN-LAST:event_txtStarRVkeyTyped

    private void txtStarMotionDkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMotionDkeyTyped
    {//GEN-HEADEREND:event_txtStarMotionDkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarMotionD, 12, kc);
    }//GEN-LAST:event_txtStarMotionDkeyTyped

    private void txtStarMotionRAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarMotionRAkeyTyped
    {//GEN-HEADEREND:event_txtStarMotionRAkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarMotionRA, 12, kc);
    }//GEN-LAST:event_txtStarMotionRAkeyTyped

    private void txtStarDkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarDkeyTyped
    {//GEN-HEADEREND:event_txtStarDkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarD, 12, kc);
    }//GEN-LAST:event_txtStarDkeyTyped

    private void txtStarRAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStarRAkeyTyped
    {//GEN-HEADEREND:event_txtStarRAkeyTyped
        bolStarEditing = true;
        setStarEditMode();
        KTDecimal d = new KTDecimal(evt, txtStarRA, 12, kc);
    }//GEN-LAST:event_txtStarRAkeyTyped

    private void calculatePlanetaryDistance()
    {
        //get the planetary positions
        ChartEvent chartEvent = new ChartEvent(event);
        Planet p = new Planet(chartEvent, false);
        Coord coord1 = p.getObjPosition(cboPlanet1Dist.getSelectedIndex());
        Coord coord2 = p.getObjPosition(cboPlanet2Dist.getSelectedIndex());

        double longitude1 = coord1.getTropicGeoLong();
        double latitude1 = coord1.getGeoLat();
        double r1 = coord1.getGeoDist();
        double longitude2 = coord2.getTropicGeoLong();
        double latitude2 = coord2.getGeoLat();
        double r2 = coord2.getGeoDist();

        //calculate the distance and angle
        double angle = AstronomyMaths.getAngleDist(latitude1, latitude2, longitude1, longitude2);
        double distance = Math.sqrt(r1 * r1 + r2 * r2 - 2.0 * r1 * r2 * AstronomyMaths.cosD(angle));

        //show the result
        lblApparentAngle.setText(new Double(angle).toString());
        lblDistancePlanets.setText(new Double(distance).toString());
    }

    public RiseSetMeridian getRiseSetMeridian()
    {
        return riseSetMeridian;
    }

    public int getPlanetRiseSet()
    {
        return riseSetPlanet;
    }

    private void calculateRiseSet()
    {
        riseSetPlanet = cboPlanetRiseSet.getSelectedIndex();
        getRiseSetData(riseSetPlanet);
        lblRiseTime.setText(riseSetMeridian.getRiseTime());
        lblSetTime.setText(riseSetMeridian.getSetTime());
        lblMeridianTime.setText(riseSetMeridian.getMeridianTime());
        lblRisePosition.setText(riseSetMeridian.getRisePosition());
        lblSetPosition.setText(riseSetMeridian.getSetPosition());
        drawRiseSet.setEvent(new ChartEvent(event));
        drawRiseSet.setPlanet(riseSetPlanet);
        drawRiseSet.setRSM(riseSetMeridian);
        drawRiseSet.setColor(getPlanetColor(riseSetPlanet));
        drawRiseSet.reFresh();
    }

    private void calculateAlignment()
    {
        String sLat1 = txtLatitudePlace1.getText();
        String sLat2 = txtLatitudePlace2.getText();
        String sLat3 = txtLatitudePlace3.getText();
        String sLong1 = txtLongitudePlace1.getText();
        String sLong2 = txtLongitudePlace2.getText();
        String sLong3 = txtLongitudePlace3.getText();
        if (sLat1 == null || sLat1.equals("") || sLat2 == null || sLat2.equals("") || sLat3 == null || sLat3.equals("") || sLong1 == null || sLong1.equals("") || sLong2 == null || sLong2.equals("") || sLong3 == null || sLong3.equals(""))
        {
            lblAngleDiffAlign.setText("");
            lblAngleA.setText("");
            lblAngleB.setText("");
            lblAngleC.setText("");
        }
        else
        {
            double angle1;
            double angle2;
            double angle3;
            double latitude1;
            double latitude2;
            double latitude3;
            double longitude1;
            double longitude2;
            double longitude3;

            //conversion in decimal degrees
            FLatitude fLat = new FLatitude(sLat1);
            latitude1 = fLat.getDecimalDegree();
            fLat = new FLatitude(sLat2);
            latitude2 = fLat.getDecimalDegree();
            fLat = new FLatitude(sLat3);
            latitude3 = fLat.getDecimalDegree();
            FLongitude fLong = new FLongitude(sLong1);
            longitude1 = fLong.getDecimalDegree();
            fLong = new FLongitude(sLong2);
            longitude2 = fLong.getDecimalDegree();
            fLong = new FLongitude(sLong3);
            longitude3 = fLong.getDecimalDegree();

            //angles
            angle3 = AstronomyMaths.placeAngle(latitude3, latitude1, latitude2, longitude3, longitude1, longitude2);
            angle1 = AstronomyMaths.placeAngle(latitude1, latitude2, latitude3, longitude1, longitude2, longitude3);
            angle2 = AstronomyMaths.placeAngle(latitude2, latitude3, latitude1, longitude2, longitude3, longitude1);
            double delta = Math.abs(angle2 - 180.0 * (int) (angle2 / 90.0));
            FDegree fAngle = new FDegree(delta);
            lblAngleDiffAlign.setText(fAngle.getSDegree());
            fAngle = new FDegree(angle1);
            lblAngleA.setText(fAngle.getSDegree());
            fAngle = new FDegree(angle2);
            lblAngleB.setText(fAngle.getSDegree());
            fAngle = new FDegree(angle3);
            lblAngleC.setText(fAngle.getSDegree());
        }
    }

    private void calculateCalendars()
    {
        String sCalendar = txtCalendars[currentCalendar].getText();
        double jj;

        if (sCalendar == null || sCalendar.equals(""))
        {
            for (int j = 0; j <= CalendarsKinds.getLast(); j++)
            {
                txtCalendars[j].setText("");
            }
        }
        else
        {
            //conversion from current calendar to julian day
            Calendars calendars = new Calendars();
            if (currentCalendar == CalendarsKinds.MAYA_LONG)
            {
                //case of the mayan calendar
                int baktun;
                int katun;
                int tun;
                int uinal;
                int kin;

                int pos = sCalendar.indexOf('/');
                if (pos < 1)
                {
                    return;
                }
                String str = sCalendar.substring(0, pos);
                sCalendar = sCalendar.substring(pos + 1);
                baktun = new Integer(str).intValue();

                pos = sCalendar.indexOf('/');
                if (pos < 1)
                {
                    return;
                }
                str = sCalendar.substring(0, pos);
                sCalendar = sCalendar.substring(pos + 1);
                katun = new Integer(str).intValue();

                pos = sCalendar.indexOf('/');
                if (pos < 1)
                {
                    return;
                }
                str = sCalendar.substring(0, pos);
                sCalendar = sCalendar.substring(pos + 1);
                tun = new Integer(str).intValue();

                pos = sCalendar.indexOf('/');
                if (pos < 1)
                {
                    return;
                }
                str = sCalendar.substring(0, pos);
                sCalendar = sCalendar.substring(pos + 1);
                uinal = new Integer(str).intValue();

                kin = new Integer(sCalendar).intValue();
                jj = calendars.mayaLongToJulian(baktun, katun, tun, uinal, kin);
            }
            else
            {
                //other calendar
                FDate fDate = new FDate(sCalendar);
                long d = fDate.getDay();
                long m = fDate.getMonth();
                long y = fDate.getYear();
                jj = calendars.calendrier1VersJulien(currentCalendar, (int) d, (int) m, (int) y);
            }

            //conversion from julian day for the current calendar to others calendar
            for (int j = 0; j <= CalendarsKinds.getLast(); j++)
            {
                if (j == currentCalendar || j == CalendarsKinds.MAYA_TH)
                {
                    j += 1;
                }
                if (j > CalendarsKinds.getLast())
                {
                    break;
                }
                String value = calendars.julienVersCalendrier2(j, jj);
                if (j == CalendarsKinds.MAYA_LONG)
                {
                    //case of mayan calendar
                    int pos = value.indexOf("\r\n");
                    if (pos < 1)
                    {
                        return;
                    }
                    String str = value.substring(0, pos);
                    txtCalendars[CalendarsKinds.MAYA_TH].setText(str);
                    str = value.substring(pos + 2);
                    txtCalendars[j].setText(str);
                }
                else
                {
                    txtCalendars[j].setText(value);
                }
                txtCalendars[j].setToolTipText(txtCalendars[j].getText());
            }
        }
    }

    //=====================================================================
    //Conversion de l'indice k en jours juliens
    //input : k     : nombre de revolutions siderales accomplies depuis 1900,0
    //        a     : facteur pour la determination du Julian Day d'apres k
    //        b     : idem
    //        c     : idem
    //        index : numero de l'astre considere
    //return        : Julian Day
    //=====================================================================
    private double kVersJJ(double k, double a, double b, double c, int index)
    {
        return a + b * k + c * k * k;
    }

    private void calculatePeriAph()
    {
        if (txtYearPeri.getText() == null || txtYearPeri.getText().equals(""))
        {
            return;
        }

        //nombre de revolutions siderales accomplies depuis 1900,0
        double k;
        //Julian Day de passage au perihelie ou � l'aphelie
        double jj;

        //perihelie
        double annee = new Double(txtYearPeri.getText()).doubleValue();
        int index = cboPlanetPeri.getSelectedIndex();
        k = (double) (int) (n[index] * (annee - 1900) * 365.25 / 360.0);
        jj = kVersJJ(k, a[index], b[index], c[index], 0);
        double date = AstronomyMaths.julianToGregorian((double) (int) (jj - 0.5) + 0.5);
        FDate fDate = new FDate(date);
        String sDate = fDate.getFormatedDate();
        lblPerihelion.setText(sDate);

        //aphelie
        k += 0.5;
        jj = kVersJJ(k, a[index], b[index], c[index], 1);
        date = AstronomyMaths.julianToGregorian((double) (int) (jj - 0.5) + 0.5);
        fDate = new FDate(date);
        sDate = fDate.getFormatedDate();
        lblAphelion.setText(sDate);
    }

    private void calculateNodesCrossing()
    {
        if (txtYearNodes.getText() == null || txtYearNodes.getText().equals(""))
        {
            return;
        }

        final int NOEUD_ASCENDANT = 1;
        final int NOEUD_DESCENDANT = 2;
        //indice
        int i;
        //nombre de revolutions siderales accomplies depuis 1900,0
        double k;
        //anomalie moyenne
        double m[] = new double[7];
        //argument de la latitude
        double u[] = new double[7];
        //Julian Day
        double jj;
        //Julian Day de passage au perihelie
        double jj_perihelie;
        //date gregorienne
        double jg;
        //temps seculaire
        double tps_seculaire;
        //auxiliary variable
        double aux;
        //excentricite
        double exc;
        //sinus de l'anomalie excentrique
        double sin_E;
        //cosinus de l'anomalie excentrique
        double cos_E;
        //anomalie excentrique
        double E_;
        //variable de type astre pour le calcul preliminaire des positions planetaires
        //=============================================

        //calcul de la date de passage au perihelie la plus proche de l'annee entree
        //perihelie
        double annee = new Double(txtYearNodes.getText()).doubleValue();
        int index = cboPlanetNodes.getSelectedIndex();
        k = (double) (int) (n[index] * (annee - 1900) * 365.25 / 360.0);
        jj = kVersJJ(k, a[index], b[index], c[index], 0);
        jj_perihelie = jj;

        //aphelie
        k += 0.5;
        jj = kVersJJ(k, a[index], b[index], c[index], 1);

        //temps seculaire
        tps_seculaire = (jj_perihelie - 2415020.0) / AstronomyMaths.DAY_PER_CENTURY;

        //calcul de l'anomalie moyenne et de l'argument de la latitude
        //calcul des positions planetaires
        m[index] = AstronomyMaths.modulo(ma0[index] + tps_seculaire * ma1[index], 360.0);
        u[index] = AstronomyMaths.modulo(al0[index] + tps_seculaire * al1[index], 360.0);

        //calcul de l'excentricite
        exc = a0[index] + a1[index] * tps_seculaire + a1[index] * tps_seculaire * tps_seculaire + a1[index] * tps_seculaire * tps_seculaire * tps_seculaire;

        //calcul de l'anomalie excentrique
        aux = u[index] - m[index];

        for (i = NOEUD_ASCENDANT; i <= NOEUD_DESCENDANT; i++)
        {
            if (i == NOEUD_DESCENDANT)
            {
                aux += 180.0;
            }

            //sinus et cosinus de l'anomalie excentrique
            sin_E = (Math.sqrt(1 - exc * exc) * AstronomyMaths.sinD(aux)) / (1 + exc * AstronomyMaths.cosD(aux));
            cos_E = (AstronomyMaths.cosD(aux) + exc) / (1 + exc * AstronomyMaths.cosD(aux));
            //anomalie excentrique
            E_ = Math.asin(sin_E);

            if (AstronomyMaths.sgn(cos_E) != AstronomyMaths.sgn(Math.cos(E_)))
            {
                E_ = AstronomyMaths.PI - E_;
            }

            //calcul de l'anomalie moyenne
            m[index] = E_ - exc * sin_E;
            //conversion de M(astre1.ListIndex) en degres
            m[index] = m[index] * AstronomyMaths.CENT80_SUR_PI;

            //Calculation of the Julian Day du passage au noeud pour le jour le plus proche du passage au perihelie
            jj = jj_perihelie - m[index] / n[index];
            double date = AstronomyMaths.julianToGregorian((double) (int) (jj - 0.5) + 0.5);
            FDate fDate = new FDate(date);
            String sDate = fDate.getFormatedDate();

            //date gregorienne
            if (i == NOEUD_DESCENDANT)
            {
                lblSouthNode.setText(sDate);
            }
            else
            {
                lblNorthNode.setText(sDate);
            }
        }
    }

    private void calculateMoonPhases()
    {
        //longitude du Soleil
        double longitude_soleil;
        //longitude de la Lune
        double longitude_lune;
        //longitude de la Lune
        double latitude_lune;
        //distance de la Terre au Soleil
        double terre_soleil;
        //distance de la Terre � la Lune
        double terre_lune;
        //auxiliary variable
        double aux;
        //rapport entre la distance Terre-Soleil et la distance Terre-Lune
        double R_sur_r;
        //periode de la Lune exprimee en annees dans le fichier astre.don
        double periode_lune;
        //orbe admise pour l'attribution du nom de la phase
        double orbe = 5.0;
        //=============================================

        StarLogin.Systeme.Data.Event ev = event.cloneEvent(event);
        ev.setUtDate(txtDatePhases.getText());
        ev.setUtTime(txtTimePhases.getText());

        //get the sun and moon positions
        ChartEvent chartEvent = new ChartEvent(ev);
        Planet p = new Planet(chartEvent, false);
        Coord coordSun = p.getObjPosition(Planets.Sun);
        Coord coordMoon = p.getObjPosition(Planets.Moon);
        longitude_soleil = coordSun.getTropicGeoLong();
        terre_soleil = coordSun.getGeoDist();
        longitude_lune = coordMoon.getTropicGeoLong();
        latitude_lune = coordMoon.getGeoLat();
        terre_lune = coordMoon.getGeoDist();

        R_sur_r = terre_soleil / terre_lune;

        aux = AstronomyMaths.cosD(longitude_lune - longitude_soleil) * AstronomyMaths.cosD(latitude_lune);
        aux = 100.0 * (1 - aux * R_sur_r) / Math.sqrt(1 + R_sur_r * R_sur_r - 2 * R_sur_r * aux);
        aux = Math.abs(AstronomyMaths.getRnd(aux, 3));

        //phase de la Lune en % de sa face eclairee
        lblPhase.setText(new Double(aux).toString() + " %");

        //age
        periode_lune = 29.53;
        double age = AstronomyMaths.modulo(180.0 - AstronomyMaths.acosD(aux), 360.0) * periode_lune / 360.0;
        lblAge.setText(new Double(age).toString());

        aux = AstronomyMaths.modulo(longitude_lune - longitude_soleil, 360);

        if (aux < orbe || aux > 360.0 - orbe)
        {
            lblMoonPhase.setText(bundle.getString("NewMoon"));
        }
        else if (Math.abs(aux - 90.0) < orbe)
        {
            lblMoonPhase.setText(bundle.getString("FirstQuarter"));
        }
        else if (Math.abs(aux - 180.0) < orbe)
        {
            lblMoonPhase.setText(bundle.getString("FullMoon"));
        }
        else if (Math.abs(aux - 270.0) < orbe)
        {
            lblMoonPhase.setText(bundle.getString("LastQuarter"));
        }
    }

    private void calculateEclipses(int lunaison)
    {
        btnNextEclipse.setVisible(true);

        //anomalie moyenne
        double m[] = new double[Planets.Moon + 1];
        //indice de la derniere lunaison
        final byte DERNIERE_LUNAISON = 13;
        //nombre de lunaisons depuis 1900
        double nl;
        //lunaison initiale de 1900
        double nl0;
        //temps seculaire
        double t;
        //angle de phase
        double angle_phase;
        //varables diverses (u est le rayon du cercle d'ombre/rayon terrestre)
        //                  (0.545+u est le rayon de la penombre)
        double s;
        double cx;
        double gamma;
        double u;
        double grandeur_;
        //Julian Day pour les dates considerees
        double jjnl;
        //UT hour
        double heure;
        //premier contact pour une eclipse de Lune
        double pc;
        //contact interieur pour une eclipse de Lune
        double ci;
        //eclipse de penombre pour la Lune
        double penombre_;
        //eclipse of shadow for the moon
        double ombre_;
        //Eclipse duration
        double vitesse;
        //duree du premier contact pour une eclipse de Lune
        double premier_contact;
        //duree du contact interieur pour une eclipse de Lune
        double contact_interieur;
        //duree de l'eclipse de Lune
        int duree;
        //duree de l'eclipse totale de Lune
        int duree_ombre;

        //Initialize
        lblDimension.setText("");
        lblHemisphere.setText("");
        lblEclipse.setText("");
        lblType.setText("");
        lblDateEclipse.setText("");
        lblShadowDuration.setText("");
        lblHalfLightDuration.setText("");
        //this.repaint();
        //this.paintAll(this.getGraphics());
        pnlEclipses.paintImmediately(pnlEclipses.getBounds());

        //indice de nouvelle lune
        int year = new Integer(txtYearEclipses.getText()).intValue();
        nl = (double) (year - 1900) * AstronomyMaths.DAY_PER_CENTURY / AstronomyMaths.LUNE_SYNODIQUE / 100.0;
        nl0 = (double) (int) nl;

        //tant que le calcul n'est pas acheve ou interrompu
        while (btnNextEclipse.isVisible())
        {
            //14 lunaisons pour encadrer l'annee
            lunaison += 1;

            //lors de la derniere lunaison pour la Lune
            if ((lunaison >= DERNIERE_LUNAISON))
            {
                if (currentPlanetForEclipse == Planets.Sun)
                {
                    lunaison = 0;
                    currentPlanetForEclipse = Planets.Moon;
                }
                else
                {
                    btnNextEclipse.setVisible(false);
                    moon = -1;
                    return;
                }
            }

            //re-initialize
            lblDimension.setText("");
            lblHemisphere.setText("");
            lblEclipse.setText("");
            lblType.setText("");
            lblDateEclipse.setText("");
            lblShadowDuration.setText("");
            lblHalfLightDuration.setText("");

            //CALCULS
            nl = nl0 + lunaison + (double) currentPlanetForEclipse / 2.0;
            //temps seculaire
            t = nl / AstronomyMaths.DAY_PER_CENTURY / AstronomyMaths.LUNE_SYNODIQUE;
            //Julian Day pour l'epoque de nouvelle lune moyenne
            jjnl = 2415020.75933 + AstronomyMaths.LUNE_SYNODIQUE * nl + 0.0001178 * t * t - 0.000000155 * t * t * t + 0.00033 * AstronomyMaths.sinD(166.56 + 132.87 * t - 0.009173 * t * t);
            //calcul des anomalies moyennes et de l'angle de phase de la Lune
            m[Planets.Sun] = 359.2242 + 29.10535608 * nl - 0.0000333 * t * t - 0.00000347 * t * t * t;
            m[Planets.Moon] = 306.0253 + 385.816918 * nl + 0.0107306 * t * t + 0.00001236 * t * t * t;
            angle_phase = 21.2964 + 390.670506 * nl - 0.0016528 * t * t - 0.00000239 * t * t * t;
            //calcul de s, cx, gamma et u
            s = 5.19595 - 0.0048 * AstronomyMaths.cosD(m[Planets.Sun]) + 0.002 * AstronomyMaths.cosD(2 * m[Planets.Sun]) - 0.3283 * AstronomyMaths.cosD(m[Planets.Moon]) - 0.006 * AstronomyMaths.cosD(m[Planets.Sun] + m[Planets.Moon]) + 0.0041 * AstronomyMaths.cosD(m[Planets.Sun] - m[Planets.Moon]);
            cx = 0.207 * AstronomyMaths.sinD(m[Planets.Sun]) + 0.0024 * AstronomyMaths.sinD(2 * m[Planets.Sun]) - 0.039 * AstronomyMaths.sinD(m[Planets.Moon]) + 0.0115 * AstronomyMaths.sinD(2 * m[Planets.Moon]) - 0.0073 * AstronomyMaths.sinD(m[Planets.Sun] + m[Planets.Moon]) - 0.0067 * AstronomyMaths.sinD(m[Planets.Sun] - m[Planets.Moon]) + 0.0117 * AstronomyMaths.sinD(angle_phase);
            gamma = s * AstronomyMaths.sinD(angle_phase) + cx * AstronomyMaths.cosD(angle_phase);
            u = 0.0059 + 0.0046 * AstronomyMaths.cosD(m[Planets.Sun]) - 0.0182 * AstronomyMaths.cosD(m[Planets.Moon]) + 0.0004 * AstronomyMaths.cosD(2 * m[Planets.Moon]) - 0.0005 * AstronomyMaths.cosD(m[Planets.Sun] + m[Planets.Moon]);

            //les differents types d'eclipses
            //SOLEIL
            if (currentPlanetForEclipse == Planets.Sun)
            {
                if (Math.abs(gamma) <= 1.5432 + u)
                {
                    lblEclipse.setText(bundle.getString("Solar"));
                    if (Math.abs(gamma) < 0.9972)
                    {
                        lblType.setText(bundle.getString("Central"));
                        if (u < 0)
                        {
                            lblType.setText(bundle.getString("Full"));
                        }
                        else
                        {
                            if (u > 0.00464 * Math.sqrt(1.0 - gamma * gamma))
                            {
                                lblType.setText(bundle.getString("Annular"));
                            }
                            else
                            {
                                lblType.setText(bundle.getString("Mixed"));
                            }
                        }
                    }
                    else
                    {
                        lblType.setText(bundle.getString("NonCentral"));
                        if (Math.abs(gamma) < 0.9972 + Math.abs(u))
                        {
                            lblType.setText(bundle.getString("Mixed"));
                        }
                        else
                        {
                            lblType.setText(bundle.getString("Partial"));
                            grandeur_ = (1.5432 + u - Math.abs(gamma)) / (0.546 + 2 * u);
                            int grandeur = (int) (grandeur_ * 100.0);

                            //affichage grandeur
                            lblDimension.setText(new Integer(grandeur).toString() + " %");
                        }
                    }

                    if (gamma > 0)
                    {
                        lblHemisphere.setText(bundle.getString("North"));
                    }
                    else
                    {
                        lblHemisphere.setText(bundle.getString("South"));
                    }
                }
            }
            //LUNE
            else
            {
                penombre_ = (1.5572 + u - Math.abs(gamma)) / 0.545;
                ombre_ = (1.0129 - u - Math.abs(gamma)) / 0.545;

                if (penombre_ >= 0)
                {
                    lblEclipse.setText(bundle.getString("Lunar"));
                    if (ombre_ < 0)
                    {
                        lblType.setText(bundle.getString("HalfLighted"));
                    }
                    else
                    {
                        pc = 1.1029 - u;
                        ci = 0.4679 - u;
                        vitesse = 0.5458 + 0.04 * AstronomyMaths.cosD(m[Planets.Moon]);
                        premier_contact = 60 * Math.sqrt(pc * pc - gamma * gamma) / vitesse;

                        if (ombre_ < 1)
                        {
                            lblType.setText(bundle.getString("Partial"));
                            duree = (int) (2 * premier_contact);
                        }
                        else
                        {
                            contact_interieur = 60 * Math.sqrt(ci * ci - gamma * gamma) / vitesse;
                            lblType.setText(bundle.getString("Full"));
                            duree = (int) (2 * premier_contact);
                            duree_ombre = (int) (2 * contact_interieur);

                            //affichage ombre
                            lblShadowDuration.setText(new Integer(duree_ombre).toString() + " mn");
                        }

                        //affichage penombre
                        lblHalfLightDuration.setText(new Integer(duree).toString() + " mn");
                    }
                }
            }

            //autres RESULTATS affiches
            if (lblEclipse.getText() != null && !lblEclipse.getText().equals(""))
            {
                //terme correctif sur la date
                jjnl = jjnl + (0.1734 - 0.000393 * t) * AstronomyMaths.sinD(m[Planets.Sun]) + 0.0021 * AstronomyMaths.sinD(2 * m[Planets.Sun]) - 0.4068 * AstronomyMaths.sinD(m[Planets.Moon]);
                jjnl = jjnl - 0.0051 * AstronomyMaths.sinD(m[Planets.Sun] + m[Planets.Moon]) - 0.0074 * AstronomyMaths.sinD(m[Planets.Sun] - m[Planets.Moon]) - 0.0104 * AstronomyMaths.sinD(2 * angle_phase);

                //date et heure de l'eclipse
                heure = AstronomyMaths.frac(jjnl + 0.5) * 24.0;

                if (Math.abs(AstronomyMaths.frac(heure) - 0.6) < 0.000000000001)
                {
                    heure += 0.4;
                }
                double date = AstronomyMaths.julianToGregorian((double) (int) (jjnl - 0.5) + 0.5);
                FDate fDate = new FDate(date);
                String sDate = fDate.getFormatedDate();
                FTime fTime = new FTime(heure);
                sDate = sDate + " - " + fTime.getTime() + " (" + bundle.getString("UT)");
                lblDateEclipse.setText(sDate);
                moon = lunaison;

                //result added to the text area
                String strResult = "";
                if (txtResultEclipses.getText() != null && !txtResultEclipses.getText().equals(""))
                {
                    strResult = "\r\n\r\n";
                }
                else
                {
                    txtResultEclipses.setText("");
                }
                strResult = strResult + lblEclipse.getText() + "\r\n" + lblDateEclipse.getText() + "\r\n" + lblType.getText();
                if (lblDimension.getText() != null && !lblDimension.getText().equals(""))
                {
                    strResult = strResult + "\r\n" + lblDim.getText() + " :  " + lblDimension.getText();
                }
                if (lblHemisphere.getText() != null && !lblHemisphere.getText().equals(""))
                {
                    strResult = strResult + "\r\n" + lblHemi.getText() + " :  " + lblHemisphere.getText();
                }
                if (lblShadowDuration.getText() != null && !lblShadowDuration.getText().equals(""))
                {
                    strResult = strResult + "\r\n" + lblShadow.getText() + " :  " + lblShadowDuration.getText();
                }
                if (lblHalfLightDuration.getText() != null && !lblHalfLightDuration.getText().equals(""))
                {
                    strResult = strResult + "\r\n" + lblHalfLight.getText() + " :  " + lblHalfLightDuration.getText();
                }
                txtResultEclipses.setText(txtResultEclipses.getText() + strResult);
                return;
            }
        }
        moon = -1;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void findDate()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        String sResult = "";
        String sDate = txtSupposedYear.getText();
        if (sDate == null || sDate.equals("")) return;
        Integer year = new Integer(sDate).intValue();
        double date_cherchee = AstronomyMaths.gregorianToJulian(1, 1, (long) year - 100);
        double date_limite = AstronomyMaths.gregorianToJulian(1, 1, (long) year + 100);
        int nP[] =
        {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        double date_trouvee[] =
        {
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        };
        boolean givenPlanets[] =
        {
            false, false, false, false, false, false, false, false, false, false, false, false
        };
        double periode[] =
        {
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        };
        double incertitude[] =
        {
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        };
        double l[] =
        {
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        };


        //DETERMINATION DE LA PRESENCE OU NON DE LA POSITION DES ASTRES
        //=========================================================================

        //r�cup�ration de la p�riode des astres
        for (int i = 0; i < 10; i++)
        {
            periode[i] = MainClass.astrobj[i].getPeriod();
        }

        int astre_max;
        int astre_min = -1;

        //r�cup�ration de la position des astres et points, en longitude de 0 ? 360
        int i = 0;
        String value = txtLongitudeSun.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeSun.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Sun] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Sun;
            i += 1;
        }

        value = txtLongitudeMoon.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeMoon.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Moon] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Moon;
            i += 1;
        }

        value = txtLongitudeMercury.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeMercury.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Mercury] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Mercury;
            i += 1;
        }

        value = txtLongitudeVenus.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeVenus.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Venus] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Venus;
            i += 1;
        }

        value = txtLongitudeMars.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeMars.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Mars] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Mars;
            i += 1;
        }

        value = txtLongitudeJupiter.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeJupiter.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Jupiter] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Jupiter;
            i += 1;
        }

        value = txtLongitudeSaturn.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeSaturn.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Saturn] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Saturn;
            i += 1;
        }

        value = txtLongitudeUranus.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeUranus.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Uranus] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Uranus;
            i += 1;
        }

        value = txtLongitudeNeptune.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudeNeptune.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Neptune] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Neptune;
            i += 1;
        }

        value = txtLongitudePluto.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[i] = true;
            l[i] = new FLatitude(value).getDecimalDegree();
            l[i] = AstronomyMaths.mod(l[i], 30.0);
            l[i] = l[i] + 30.0 * cboLongitudePluto.getSelectedIndex();
            incertitude[i] = 360.0 / periode[Planets.Pluto] / 365.25 / 2.0;
            if (astre_min == -1)
            {
                astre_min = i;
            }
            nP[i] = Planets.Pluto;
            i += 1;
        }
        astre_max = i-1;

        value = txtLongitudeAS.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[10] = true;
            l[10] = new FLatitude(value).getDecimalDegree();
            l[10] = AstronomyMaths.mod(l[10], 30.0);
            l[10] = l[10] + 30.0 * cboLongitudeAS.getSelectedIndex();
            incertitude[10] = 5.0;
        }

        value = txtLongitudeMC.getText();
        if (value != null && !value.equals(""))
        {
            givenPlanets[11] = true;
            l[11] = new FLatitude(value).getDecimalDegree();
            l[11] = AstronomyMaths.mod(l[11], 30.0);
            l[11] = l[11] + 30.0 * cboLongitudeMC.getSelectedIndex();
            incertitude[11] = 5.0;
        }



        //rectification des astres de plus faible et de plus grande p�riodicit�, si
        //l'incertitude pour ces derniers est trop forte (i.e. egale ? 15�)
        //------------------------------------------------------------------
        if ((incertitude[astre_min] >= 15.0) && (astre_min < astre_max))
        {
            for (int j = astre_min + 1; j <= astre_max; j++)
            {
                if ((givenPlanets[j] == true) && (incertitude[j] == 1))
                {
                    astre_min = j;
                    break;
                }
            }
        }

        if ((incertitude[astre_max] >= 15.0) && (astre_min < astre_max))
        {
            for (int j = astre_max - 1; j >= astre_min; j--)
            {
                if ((givenPlanets[j] == true) && (incertitude[j] == 1))
                {
                    astre_max = j;
                    break;
                }
            }
        }


        //RECHERCHE D'UNE DATE COMPATIBLE AVEC TOUTES LES POSITIONS
        //=========================================================================
        if (astre_max == astre_min)
        {
            return;
        }

        if (astre_max != -1)
        {
            //initializations
            //---------------
            boolean bonne_date;
            double old_longitude = l[astre_max];
            double longitude = l[astre_max];
            double nbPeriod = 1.0;
            double old_nbPeriod;
            double heure_trouvee = 0.0;
            double jj;

            //donn�es astronomiques
            double ct = AstronomyMaths.getCTime(date_cherchee);
            double ayanamsa;
            StarLogin.Systeme.Data.Event evt = new StarLogin.Systeme.Data.Event();
            ChartEvent chartEvt = new ChartEvent(evt);
            Planet p;

            //recherche de la premi�re date pour laquelle la longitude de astre_max
            //est celle donn�e dans la grille
            while ((Math.abs(nbPeriod) > 0.000001) && (date_trouvee[astre_max] <= date_limite))
            {
                old_nbPeriod = nbPeriod;
                //calcul de la longitude de l'astre 'astre_max' pour la date 'date_cherch�e'
                chartEvt.setCTimeH(ct);
                ayanamsa = AstronomyMaths.getAyanamsa(ct);
                chartEvt.setAyanamsa(ayanamsa);
                p = new Planet(chartEvt, false);
                Coord pCoord = p.getObjPosition(nP[astre_max]);
                if ((longitude != 0.0) && (nbPeriod != 1.0))
                {
                    old_longitude = AstronomyMaths.modulo(longitude, 360.0);
                }

                longitude = pCoord.getTropicGeoLong();

                //si la longitude passe de 0� � 360� dans un sens ou dans l'autre,
                //par rapport � sa position pr�c�demment calcul�e
                if (Math.abs(old_longitude - longitude) > 180.0)
                {
                    longitude = longitude + (double) ((int) (old_longitude / 180.0) - (int) (longitude / 180.0)) * 360.0;
                }

                //nbPeriod = (AstronomyMaths.modulo(l[astre_max] - longitude, 360.0)) / 360.0;
                nbPeriod = (l[astre_max] - longitude) / 360.0;

                //si le nombre de p�riode est plus grand qu'au tour pr�c�dent
                if (Math.abs(nbPeriod) > Math.abs(old_nbPeriod))
                {
                    nbPeriod = nbPeriod / (2.0 + Math.pow(1.0 + ((double)nP[astre_max]) / 9.0, 3.0) * ((1.0 - AstronomyMaths.sgn(periode[nP[astre_max]])) * 0.75 + 1.0));
                }

                //date approximative correspondant � la pr�c�dente augment�e
                //d'une p�riode ou fraction de p�riode
                ct = ct + nbPeriod * periode[nP[astre_max]] / 100.0;
                jj = AstronomyMaths.getJD(ct);
                date_trouvee[astre_max] = (double) ((int) (jj - 0.5)) + 0.5;
            }
            date_cherchee = date_trouvee[astre_max];

            if (date_trouvee[astre_max] < date_limite)
            {
                bonne_date = true;
            }

            //calcul des positions plan�taires pour la date et l'heure trouv�es
            //afin de pouvoir v�rifier les autres positions plan�taires que celle d'astre max
            ayanamsa = AstronomyMaths.getAyanamsa(ct);
            chartEvt.setCTimeH(ct);
            chartEvt.setAyanamsa(ayanamsa);
            chartEvt.addTime2CTimeH(0.0);//pour obtenir la date et l'heure
            p = new Planet(chartEvt, false);


            //initialization ? Vrai de l'indicateur de date trouv��e
            bonne_date = true;

            //reprise de la longitude calcul�e et comparaison avec l[k]
            for (int k = astre_max - 1; k >= 0; k--)
            {
                double geoLong = p.getObjPosition(nP[k]).getTropicGeoLong();
                if ((Math.abs(Math.abs(geoLong - l[k]) - 360.0 * (int) (Math.abs(geoLong - l[k]) / 180.0)) > incertitude[k]))
                {
                    bonne_date = false;
                    break;
                }
            }


            //Tant que la date cherch�e suppos�e est inf�rieure � la date limite,
            //et que la date trouv�e est mauvaise
            //----------------------------------------------------------
            Astrology astrology = new Astrology(starLoginManager);
            ChartElements chartElements = new ChartElements();
            ArrayList chartEvents = new ArrayList();
            chartEvents.add(chartEvt);
            chartElements.setChartEvents(chartEvents);
            chartElements.setChartKind(ChartKind.revolution);
            chartElements.setCoordSys(CoordSystem.Tropical);
            chartElements.setHouseSys(HouseSystem.Campanus);
            chartElements.setOtherPointName("");
            chartElements.setOtherPointType(OtherPt.none);
            chartElements.setChartReturnNB(-1.0);
            chartElements.setPlanetaryConfigurations("");
            AllCoord pos = new AllCoord();
            ArrayList positions = new ArrayList();
            for (int nn = Planets.Sun; nn <= Planets.Pluto; nn++)
            {
                pos.set(p.getObjPosition(nn), nn);
            }
            positions.add(pos);
            chartElements.setChartCoords(positions);

            while ((date_cherchee <= date_limite) && (bonne_date == false))
            {
                //recherche des positions plan�taires pour la r�volution de astre_max suivante
                astrology.planetaryRevolution(nP[astre_max], Planets.None, true, chartElements);
                chartElements.setChartReturnNB(1.0);

                //date correspondante
                if (chartElements == null)
                {
                    return;
                }
                ChartEvent chartEvent = (ChartEvent)(chartElements.getChartEvents().get(1));
                date_trouvee[astre_max] = chartEvent.getJD();
                date_cherchee = date_trouvee[astre_max];

                //heure
                heure_trouvee = chartEvent.getTime();

                //initialization ? Vrai de l'indicateur de date trouv�e
                bonne_date = true;

                //reprise de la longitude calcul�e et comparaison avec l[k]
                positions = chartElements.getChartCoords();
                AllCoord pos2 = (AllCoord)(positions.get(1));
                for (int k = astre_max - 1; k >= 0; k--)
                {
                    double geoLong = pos2.get(nP[k]).getTropicGeoLong();
                    if ((Math.abs(Math.abs(geoLong - l[k]) - 360.0 * (int) (Math.abs(geoLong - l[k]) / 180.0)) > incertitude[k]))
                    {
                        bonne_date = false;
                        break;
                    }
                }
                ArrayList events = new ArrayList();
                chartEvent.addTime2CTimeH(0.0);//pour obtenir la date et l'heure
                events.add(chartEvent);
                chartElements.setChartEvents(events);
                positions = new ArrayList();
                positions.add(pos2);
                chartElements.setChartCoords(positions);
            }

            //Affinement des r�sultats, si la date est trouv�e
            //afin de pouvoir d�terminer l'heure et le lieu avec pr�cision
            //=========================================================================
            if (bonne_date == true)
            {
                double heure_TU = heure_trouvee;
                ct = ((ChartEvent)(chartElements.getChartEvents().get(0))).getCTime();
                chartEvt.setCTimeH(ct);
                chartEvt.addTime2CTimeH(heure_TU);//new
                old_longitude = l[astre_min];
                longitude = l[astre_min];
                //old_nbPeriod = 0.0;
                nbPeriod = 1.0;

                //recherche de l'heure pour laquelle la longitude de astre_min
                //est celle donn�e dans la grille
                while (Math.abs(nbPeriod) > 0.000001)
                {
                    old_nbPeriod = nbPeriod;
                    //calcul de la longitude de l'astre 'astre_max' pour la date 'date_cherch�e'
                    p = new Planet(chartEvt, false);
                    Coord pCoord = p.getObjPosition(nP[astre_min]);
                    if ((longitude != 0.0) && (nbPeriod != 1.0))
                    {
                        old_longitude = AstronomyMaths.modulo(longitude, 360.0);
                    }

                    longitude = pCoord.getTropicGeoLong();

                    //si la longitude passe de 0� � 360� dans un sens ou dans l'autre,
                    //par rapport � sa position pr�c�demment calcul�e
                    if (Math.abs(old_longitude - longitude) > 180.0)
                    {
                        longitude = longitude + (double) ((int) (old_longitude / 180.0) - (int) (longitude / 180.0)) * 360.0;
                    }

                    nbPeriod = (l[astre_min] - longitude) / 360.0;

                    //si le nombre de p�riode est plus grand qu'au tour pr�c�dent
                    if (Math.abs(nbPeriod) > Math.abs(old_nbPeriod))
                    {
                        nbPeriod = nbPeriod / (2.0 + Math.pow(1.0 + ((double)nP[astre_max]) / 9.0, 3.0) * ((1.0 - AstronomyMaths.sgn(periode[nP[astre_max]])) * 0.75 + 1.0));
                    }

                    //date approximative correspondant � la pr�c�dente augment�e
                    //d'une p�riode ou fraction de p�riode
                    chartEvt.addTime2CTimeH(nbPeriod * periode[nP[astre_min]] / 100.0 * AstronomyMaths.HOUR_PER_CENTURY);
                    
                }

                //positions plan�taires � la date finalement trouv�e
                //p = new Planet(chartEvt, false);


                //pr�paration des r�sultats
                //=========================================================================
                String datetime = chartEvt.getDateTime();
                String sdate = datetime;
                String stime = "";
                int ipos = datetime.indexOf(" ");
                if (ipos>0)
                {
                    stime = sdate.substring(ipos+1);
                    sdate = sdate.substring(0, ipos);
                }
                sResult = bundle.getString("eventsLOCALDATE").concat(" = ").concat(sdate).concat("\r\n");
                if (!stime.equals(""))
                    sResult = sResult.concat(bundle.getString("eventsLOCAL_TIME")).concat(" = ").concat(stime).concat("\r\n");

                //si la position de l'ascendant et celle du milieu du ciel sont donn�es,
                //Get the longitude et de la latitude of the place
                if ((givenPlanets[10] == true) && (givenPlanets[11] == true))
                {
                    double obliquity = chartEvt.getObliquity();
                    double lat_lieu;
                    double tsg0 = AstronomyMaths.getGMT0(ct);
                    double tsl = AstronomyMaths.atnD(AstronomyMaths.cosD(obliquity) * AstronomyMaths.tanD(l[11]));
                    heure_TU = chartEvt.getTime();
                    double long_lieu = AstronomyMaths.modulo(15.0 * (tsg0 + heure_TU * AstronomyMaths.ST_ON_UT) - tsl, 360.0);
                    if (long_lieu > 180.0)
                    {
                        long_lieu -= 360.0;
                    }
                    if (AstronomyMaths.tanD(l[10]) == 0.0)
                    {
                        lat_lieu = -90.0 * AstronomyMaths.sgn(AstronomyMaths.cosD(tsl));
                    }
                    else
                    {
                        lat_lieu = AstronomyMaths.atnD(-AstronomyMaths.cosD(tsl) / AstronomyMaths.tanD(l[10]) / AstronomyMaths.sinD(obliquity) - AstronomyMaths.sinD(tsl) / AstronomyMaths.tanD(obliquity));
                    }
                    FLatitude fLat = new FLatitude(lat_lieu);
                    FLongitude fLong = new FLongitude(long_lieu);
                    sResult = sResult.concat(bundle.getString("eventsPLACELATITUDE")).concat(" = ").concat(fLat.getLatitude()).concat("\r\n");
                    sResult = sResult.concat(bundle.getString("eventsPLACELONGITUDE")).concat(" = ").concat(fLong.getLongitude()).concat("\r\n");
                }
            }
            else
            {
                date_cherchee = date_trouvee[astre_min];
                if ((date_cherchee > date_limite) || (date_cherchee == 0))
                {
                    sResult = bundle.getString("StartAgain");
                }
            }
        }
        //si aucune position d'astre n'est donn�e
        else
        {
            sResult = bundle.getString("StartAgain2");
        }


        //affichage des r�sultats
        txtResultFindDate.setText(sResult);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void calculateSeasons()
    {
        //numero d'ordre de la saison
        int numero_saison;
        //Julian Day correspondant � l//annee
        double jj;
        //temps seculaire
        double tps;
        //longitude du Soleil
        double longitude;
        //longitude precedente du Soleil
        double old_longitude;
        //anomalie moyenne du Soleil
        double m;
        //heure
        double heure;

        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        for (numero_saison = 0; numero_saison <= 3; numero_saison++)
        {
            old_longitude = 777.0;
            longitude = 0.0;
            //Julian Date � laquelle la longitude du Soleil est annulee durant l'an 1
            //les saisons etant definies pour Longitude_Soleil=90�*numero_saison
            double year = new Double(txtYearSeasons.getText()).doubleValue();
            jj = (year + (double) numero_saison / 4.0) * 365.2422 + 1721141.3;

            while (Math.abs(longitude - old_longitude) > 0.00001)
            {
                //sauvegarde de la valeur de longitude � l'iteration precedente
                old_longitude = longitude;
                //nouvelle longitude calculee
                tps = (jj - 2415020.0) / 36525.0;
                longitude = 279.69688 + 36000.76892 * tps + 0.0003025 * tps * tps;
                m = 358.47583 + 35999.04975 * tps - 0.00015 * tps * tps - 0.0000033 * tps * tps;
                longitude = longitude + (1.91946 - 0.004789 * tps - 0.000014 * tps * tps) * AstronomyMaths.sinD(m) + (0.020094 - 0.0001 * tps) * AstronomyMaths.sinD(2.0 * m) + 0.000293 * AstronomyMaths.sinD(3.0 * m);
                longitude = AstronomyMaths.modulo(longitude - 0.00569 - 0.00479 * AstronomyMaths.sinD(259.18 - 1934.142 * tps), 360.0);

                //test sur la longitude pour choisir la bonne determination de l'equinoxe de printemps (la bonne annee)
                if (longitude > 350.0)
                {
                    longitude = longitude - 360.0;
                }
                //correction du Julian Day en tenant compte du temps mis par le Soleil pour que sa longitude varie de 90�*numero_saison
                jj = jj + 1.014 * (90.0 * (double) numero_saison - longitude);
            }

            //conversion du Julian Day trouve en date gregorienne
            //et calcul de l'heure � 5 minutes pres
            heure = AstronomyMaths.frac(jj - 0.5) * 24.0;
            heure = (double) ((int) (heure) + (int) (AstronomyMaths.frac(heure) * 12.0) / 20.0);

            if (Math.abs(AstronomyMaths.frac(heure) - 0.6) < 0.000000000001)
            {
                heure += 0.4;
            }

            double date = AstronomyMaths.julianToGregorian((double) (int) (jj - 0.5) + 0.5);
            FDate fDate = new FDate(date);
            String sDate = fDate.getFormatedDate();
            FTime fTime = new FTime(heure);
            sDate = sDate + " - " + fTime.getTime() + " (" + bundle.getString("UT)");
            if (numero_saison == 3)
            {
                lblWinter.setText(sDate);
            }
            else if (numero_saison == 2)
            {
                lblFall.setText(sDate);
            }
            else if (numero_saison == 1)
            {
                lblSummer.setText(sDate);
            }
            else if (numero_saison == 0)
            {
                lblSpring.setText(sDate);
            }
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void calculateAsteroid()
    {
        if (asteroidID == null || asteroidID.equals("") || asteroidID.equals("-1"))
        {
            return;
        }

        //get the asteroid position
        ChartEvent chartEvent = new ChartEvent(event);
        ChartElements chartElements = new ChartElements();
        ArrayList chartEvents = new ArrayList();
        chartEvents.add(chartEvent);
        chartElements.setChartEvents(chartEvents);
        CometAsteroid asteroid0 = new CometAsteroid(chartElements);
        Coord coord = asteroid0.calculateAsteroid(starLoginManager.getAsteroid(asteroidID, ""));
        txtResultAsteroid.append(event.getPlace() + "\r\n" + bundle.getString("Longitude") + " " + event.getLongitude() + "\r\n" + bundle.getString("Latitude") + " " + event.getLatitude() + "\r\n" + event.getLocalDate() + " - " + event.getLocalTime() + "\r\n\r\n");
        String sCoord = asteroidName;
        txtResultAsteroid.append(sCoord + "\r\n\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoLat) + " :\t" + new FLatitude(coord.getGeoLat()).getLatitude();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioLat) + " :\t" + new FLatitude(coord.getHelioLat()).getLatitude();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicGeoLong) + " :\t" + new FDegree(coord.getTropicGeoLong()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderGeoLong) + " :\t" + new FDegree(coord.getSiderGeoLong()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicHelioLong) + " :\t" + new FDegree(coord.getTropicHelioLong()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderHelioLong) + " :\t" + new FDegree(coord.getSiderHelioLong()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.RightAscension) + " :\t" + new FDegree(coord.getRA()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Declination) + " :\t" + new FLatitude(coord.getDecl()).getLatitude();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Azimuth) + " :\t" + new FDegree(coord.getAz()).getSDegree();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Altitude) + " :\t" + new FLatitude(coord.getAlt()).getLatitude();
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoDistance) + " :\t" + coord.getGeoDist() + " " + bundle.getString("AU");
        txtResultAsteroid.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioDistance) + " :\t" + coord.getHelioDist() + " " + bundle.getString("AU");
        txtResultAsteroid.append(sCoord + "\r\n\r\n\r\n");
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void calculateComet()
    {
        if (cometID == null || cometID.equals("") || cometID.equals("-1"))
        {
            return;
        }

        //get the comet position
        ChartEvent chartEvent = new ChartEvent(event);
        ChartElements chartElements = new ChartElements();
        ArrayList chartEvents = new ArrayList();
        chartEvents.add(chartEvent);
        chartElements.setChartEvents(chartEvents);
        CometAsteroid comet0 = new CometAsteroid(chartElements);
        Coord coord = comet0.calculateComet(starLoginManager.getComet(cometID, ""));
        String sCoord = cometName;
        txtResultComet.append(event.getPlace() + "\r\n" + bundle.getString("Longitude") + " " + event.getLongitude() + "\r\n" + bundle.getString("Latitude") + " " + event.getLatitude() + "\r\n" + event.getLocalDate() + " - " + event.getLocalTime() + "\r\n\r\n");
        txtResultComet.append(sCoord + "\r\n\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoLat) + " :\t" + new FLatitude(coord.getGeoLat()).getLatitude();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioLat) + " :\t" + new FLatitude(coord.getHelioLat()).getLatitude();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicGeoLong) + " :\t" + new FDegree(coord.getTropicGeoLong()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderGeoLong) + " :\t" + new FDegree(coord.getSiderGeoLong()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicHelioLong) + " :\t" + new FDegree(coord.getTropicHelioLong()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderHelioLong) + " :\t" + new FDegree(coord.getSiderHelioLong()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.RightAscension) + " :\t" + new FDegree(coord.getRA()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Declination) + " :\t" + new FLatitude(coord.getDecl()).getLatitude();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Azimuth) + " :\t" + new FDegree(coord.getAz()).getSDegree();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Altitude) + " :\t" + new FLatitude(coord.getAlt()).getLatitude();
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoDistance) + " :\t" + coord.getGeoDist() + " " + bundle.getString("AU");
        txtResultComet.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioDistance) + " :\t" + coord.getHelioDist() + " " + bundle.getString("AU");
        txtResultComet.append(sCoord + "\r\n\r\n\r\n");
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void calculateEphemeris()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        txtResultEphemeris.setText("");
        StarLogin.Systeme.Data.Event ev = event.cloneEvent(event);
        ev.setUtDate(utDate);
        ev.setUtTime(MainClass.STIME_000000);
        int curCoord;
        switch (cboCoordinate.getSelectedIndex())
        {
            case 0:
                curCoord = Coordinate.TropicGeoLong;
                break;
            case 1:
                curCoord = Coordinate.TropicHelioLong;
                break;
            case 2:
                curCoord = Coordinate.SiderGeoLong;
                break;
            case 3:
                curCoord = Coordinate.SiderHelioLong;
                break;
            case 4:
                curCoord = Coordinate.GeoLat;
                break;
            case 5:
                curCoord = Coordinate.HelioLat;
                break;
            case 6:
                curCoord = Coordinate.RightAscension;
                break;
            case 7:
                curCoord = Coordinate.Declination;
                break;
            case 8:
                curCoord = Coordinate.Azimuth;
                break;
            case 9:
                curCoord = Coordinate.Altitude;
                break;
            default:
                curCoord = Coordinate.Longitude;
        }
        String sPartialHeader = bundle.getString("Ephemeris");
        drawEphemeris.setHeader1(sPartialHeader);
        String sHeader = sPartialHeader + "\r\n";
        sPartialHeader = bundle.getString("From") + " " + utDate + " - 00:00:00 (" + bundle.getString("UT)");
        drawEphemeris.setHeader2(sPartialHeader);
        sHeader = sHeader + sPartialHeader + "\r\n";
        sPartialHeader = bundle.getString("Coordinate") + " :  " + Coordinate.getCoordinateName(curCoord);
        drawEphemeris.setHeader3(sPartialHeader);
        sHeader = sHeader + sPartialHeader + "\r\n\r\n\t";
        drawEphemeris.setCurCoord(curCoord);
        txtResultEphemeris.append(sHeader);

        ArrayList allCoords = new ArrayList();
        ChartEvent chartEvent = new ChartEvent(ev);

        //Planets names
        ArrayList colors = new ArrayList();
        for (int j = 0; j <= Planets.NorthNode; j++)
        {
            if (j == Planets.NorthNode)
            {
                txtResultEphemeris.append(MainForm.planetName[Planets.Chiron] + "\t");
            }
            else
            {
                txtResultEphemeris.append(MainForm.planetName[j] + "\t");
            }
            colors.add(new Integer(defaultOption.getPlanetColor(j).getRGB()));
        }
        txtResultEphemeris.append("\r\n");
        drawEphemeris.setColors(colors);
        ArrayList dates = new ArrayList();

        for (int i = 0; i < 366; i++)
        {
            //get the sun and moon positions
            Planet p = new Planet(chartEvent, false);
            ArrayList coords = new ArrayList();
            txtResultEphemeris.append(chartEvent.getDate() + "\t");
            dates.add(chartEvent.getDate());

            for (int j = 0; j <= Planets.NorthNode; j++)
            {
                Coord coord;
                if (j == Planets.NorthNode) //in fact calculation of Chiron
                {
                    ChartElements chartElements = new ChartElements();
                    ArrayList chartEvents = new ArrayList();
                    chartEvents.add(chartEvent);
                    chartElements.setChartEvents(chartEvents);
                    CometAsteroid asteroid0 = new CometAsteroid(chartElements);
                    coord = asteroid0.calculateAsteroid(starLoginManager.getAsteroid(asteroid0.getAsteroidID(Planets.Chiron), ""));
                }
                else
                {
                    coord = p.getObjPosition(j);
                }
                double value;
                switch (curCoord)
                {
                    case Coordinate.TropicGeoLong:
                        value = coord.getTropicGeoLong();
                        break;
                    case Coordinate.TropicHelioLong:
                        value = coord.getTropicHelioLong();
                        break;
                    case Coordinate.SiderGeoLong:
                        value = coord.getSiderGeoLong();
                        break;
                    case Coordinate.SiderHelioLong:
                        value = coord.getSiderHelioLong();
                        break;
                    case Coordinate.GeoLat:
                        value = coord.getGeoLat();
                        break;
                    case Coordinate.HelioLat:
                        value = coord.getHelioLat();
                        break;
                    case Coordinate.RightAscension:
                        value = coord.getRA();
                        break;
                    case Coordinate.Declination:
                        value = coord.getDecl();
                        break;
                    case Coordinate.Azimuth:
                        value = coord.getAz();
                        break;
                    case Coordinate.Altitude:
                        value = coord.getAlt();
                        break;
                    default:
                        value = coord.getTropicGeoLong();
                }
                FDegree val = new FDegree(value);
                String sVal = val.getShortDegree();
                txtResultEphemeris.append(sVal + "\t");
                coords.add(sVal);
            }
            allCoords.add(coords);
            chartEvent.addTime2CTimeH(24.0);
            txtResultEphemeris.append("\r\n");
        }
        drawEphemeris.setCoords(allCoords);
        drawEphemeris.setDates(dates);
        if (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum() == 0 || scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum() == 0)
        {
            drawEphemeris.reFresh(0, 0);
        }
        else
        {
            drawEphemeris.reFresh(scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getVisibleAmount() - drawEphemeris.getWidth()) / scrollPanelGraphicsEphemeris.getHorizontalScrollBar().getMaximum(), scrollPanelGraphicsEphemeris.getVerticalScrollBar().getValue() * (scrollPanelGraphicsEphemeris.getVerticalScrollBar().getVisibleAmount() - drawEphemeris.getHeight()) / scrollPanelGraphicsEphemeris.getVerticalScrollBar().getMaximum());
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    //get the current record
    @SuppressWarnings("unchecked")
    private void calculateStar()
    {
        if (starID == null || starID.equals("") || starID.equals("-1"))
        {
            return;
        }

        //get the star position
        ChartEvent chartEvent = new ChartEvent(event);
        ChartElements chartElements = new ChartElements();
        ArrayList chartEvents = new ArrayList();
        chartEvents.add(chartEvent);
        chartElements.setChartEvents(chartEvents);
        Astronomy.starPosition(chartElements, starLoginManager.getStars().getRecords());
        Coord coord = Astronomy.starCoordinates(starRA, starD, Astronomy.CALCUL_COMPLET, starMotionRA, starMotionD, starDistance, chartElements);
        String sCoord;
        if (starName != null && !starName.equals(""))
        {
            sCoord = starIdentity + " (" + starName + ")";
        }
        else
        {
            sCoord = starIdentity;
        }
        txtResultStar.append(event.getPlace() + "\r\n" + bundle.getString("Longitude") + " " + event.getLongitude() + "\r\n" + bundle.getString("Latitude") + " " + event.getLatitude() + "\r\n" + event.getLocalDate() + " - " + event.getLocalTime() + "\r\n\r\n");
        txtResultStar.append(sCoord + "\r\n\r\n");
        txtResultStar.append(bundle.getString("SpectralClassLuminosity") + " :\t" + starLuminosity + "\r\n");
        txtResultStar.append(bundle.getString("Magnitude") + " :\t" + starMagnitude + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoLat) + " :\t" + new FLatitude(coord.getGeoLat()).getLatitude();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioLat) + " :\t" + new FLatitude(coord.getHelioLat()).getLatitude();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicGeoLong) + " :\t" + new FDegree(coord.getTropicGeoLong()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderGeoLong) + " :\t" + new FDegree(coord.getSiderGeoLong()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.TropicHelioLong) + " :\t" + new FDegree(coord.getTropicHelioLong()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.SiderHelioLong) + " :\t" + new FDegree(coord.getSiderHelioLong()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.RightAscension) + " :\t" + new FDegree(coord.getRA()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Declination) + " :\t" + new FLatitude(coord.getDecl()).getLatitude();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Azimuth) + " :\t" + new FDegree(coord.getAz()).getSDegree();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.Altitude) + " :\t" + new FLatitude(coord.getAlt()).getLatitude();
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.GeoDistance) + " :\t" + coord.getGeoDist() + " " + bundle.getString("LY");
        txtResultStar.append(sCoord + "\r\n");
        sCoord = Coordinate.getCoordinateName(Coordinate.HelioDistance) + " :\t" + coord.getHelioDist() + " " + bundle.getString("LY");
        txtResultStar.append(sCoord + "\r\n\r\n\r\n");
    }

    private void calculatePlacesDistance()
    {
        String sLat1 = txtLatitudePlaceA.getText();
        String sLat2 = txtLatitudePlaceB.getText();
        String sLong1 = txtLongitudePlaceA.getText();
        String sLong2 = txtLongitudePlaceB.getText();
        if (sLat1 == null || sLat1.equals("") || sLat2 == null || sLat2.equals("") || sLong1 == null || sLong1.equals("") || sLong2 == null || sLong2.equals(""))
        {
            lblDistanceAB.setText("");
            lblAngleAB.setText("");
        }
        else
        {
            double angle;
            double distance;
            double latitude1;
            double latitude2;
            double longitude1;
            double longitude2;

            //conversion in decimal degrees
            FLatitude fLat = new FLatitude(sLat1);
            latitude1 = fLat.getDecimalDegree();
            fLat = new FLatitude(sLat2);
            latitude2 = fLat.getDecimalDegree();
            FLongitude fLong = new FLongitude(sLong1);
            longitude1 = fLong.getDecimalDegree();
            fLong = new FLongitude(sLong2);
            longitude2 = fLong.getDecimalDegree();

            //angle
            angle = AstronomyMaths.getAngleDist(latitude1, latitude2, longitude1, longitude2);
            FDegree fAngle = new FDegree(angle);
            lblAngleAB.setText(fAngle.getSDegree());

            //distance
            distance = angle * AstronomyMaths.PI / 360.0 * (AstronomyMaths.getGeoidRadius(latitude1) + AstronomyMaths.getGeoidRadius(latitude2));
            distance = AstronomyMaths.getRnd(distance, 3);
            lblDistanceAB.setText(new Double(distance).toString());
        }
    }

    private void calculateGST0()
    {
        String sDate = txtDateGST0.getText();
        if (sDate == null || sDate.equals(""))
        {
            lblGST0.setText("");
        }
        else
        {
            FDate fDate = new FDate(sDate);
            long y = fDate.getYear();
            long m = fDate.getMonth();
            long d = fDate.getDay();
            double jd = AstronomyMaths.gregorianToJulian(d, m, y);
            double ct = AstronomyMaths.getCTime(jd);
            double gmt0 = AstronomyMaths.getGMT0(ct);
            gmt0 = AstronomyMaths.getRnd(gmt0, 12);
            lblGST0.setText(new Double(gmt0).toString());
        }
    }

    private void calculateJulianDay()
    {
        if (optJD2Greg.isSelected())
        {
            String sDate = txtJulianDay.getText();
            if (sDate == null || sDate.equals(""))
            {
                txtGregorianDate.setText("");
            }
            else
            {
                double jd = new Double(sDate).doubleValue();
                double date = AstronomyMaths.julianToGregorian(jd);
                FDate fDate = new FDate(date);
                txtGregorianDate.setText(fDate.getFormatedDate());
            }
        }
        else
        {
            String sDate = txtGregorianDate.getText();
            if (sDate == null || sDate.equals(""))
            {
                txtJulianDay.setText("");
            }
            else
            {
                FDate fDate = new FDate(sDate);
                long y = fDate.getYear();
                long m = fDate.getMonth();
                long d = fDate.getDay();
                double jd = AstronomyMaths.gregorianToJulian(d, m, y);
                jd = AstronomyMaths.getRnd(jd, 4);
                txtJulianDay.setText(new Double(jd).toString());
            }
        }
    }

    private void calculateDegrees()
    {
        if (optSexa2Deci.isSelected())
        {
            String sDegree = txtSexagesimal.getText();
            if (sDegree == null || sDegree.equals(""))
            {
                txtDecimal.setText("");
            }
            else
            {
                //FDegree fDegree = new FDegree(sDegree);
                //double degree = fDegree.getDecimalDegree();
                FLongitude fDegree = new FLongitude(sDegree);
                double degree = fDegree.getDecimalDegree();
                degree = AstronomyMaths.getRnd(degree, 12);
                txtDecimal.setText(new Double(degree).toString());
            }
        }
        else
        {
            String sDegree = txtDecimal.getText();
            if (sDegree == null || sDegree.equals(""))
            {
                txtSexagesimal.setText("");
            }
            else
            {
                double degree = new Double(sDegree).doubleValue();
                FDegree fDegree = new FDegree(degree);
                String sdegree = fDegree.getSDegree();
                sdegree = new FLongitude(sdegree).getLongitude();
                txtSexagesimal.setText(sdegree);
            }
        }
    }

    //conversion de la latitude astro en latitude geo (en degres)
    private double astroLat2GeoLat(double latitude, double hauteur)
    {
        //auxiliary variables
        double aux1;
        double aux2;
        //rapport entre les petit et grand rayon terrestre
        double BsurA = 0.996647187;
        //grand rayon terrestre
        double demiGrandAxeTerrestre = 6378140.0;
        //=============================================

        if (Math.abs(latitude) > 90.0)
        {
            latitude = AstronomyMaths.sgn(latitude) * (180.0 - Math.abs(latitude));
        }

        if ((Math.abs(latitude) != 90.0) && (latitude != 0.0))
        {
            aux1 = BsurA * AstronomyMaths.tanD(latitude);
            aux2 = hauteur / demiGrandAxeTerrestre * Math.sqrt(1.0 + aux1 * aux1);
            aux2 = (BsurA * aux1 + AstronomyMaths.sinD(latitude) * aux2) / (1.0 + AstronomyMaths.cosD(latitude) * aux2);
            latitude = AstronomyMaths.atnD(aux2);
        }

        return latitude;
    }

    //conversion de la latitude geo en latitude astro (en degres)
    private double geoLat2AstroLat(double latitude, double hauteur)
    {
        double aux1;
        double aux2;
        double old_x;
        double x;
        //rapport entre les petit et grand rayon terrestre
        double BsurA = 0.996647187;
        //grand rayon terrestre
        double demiGrandAxeTerrestre = 6378140.0;
        //=============================================

        if (Math.abs(latitude) > 90.0)
        {
            latitude = AstronomyMaths.sgn(latitude) * (180.0 - Math.abs(latitude));
        }

        if (Math.abs(latitude) < 90.0 - 0.0000000001)
        {
            aux1 = AstronomyMaths.tanD(latitude);
            old_x = 0;
            x = aux1;

            while (Math.abs(x - old_x) > 0.000000000001)
            {
                old_x = x;
                aux2 = hauteur / demiGrandAxeTerrestre * Math.sqrt((1 + (BsurA * x) * (BsurA * x)) / (1 + x * x));
                x = aux1 * (1 + aux2) / (aux2 + BsurA * BsurA);
            }
            latitude = AstronomyMaths.atnD(x);
        }

        return latitude;
    }

    private void calculateLatitudes()
    {
        String sAlt = txtAltitude.getText();
        if (sAlt == null || sAlt.equals(""))
        {
            return;
        }
        double altitude = new Double(sAlt).doubleValue();

        if (optAstro2Geo.isSelected())
        {
            String sLat = txtAstronomical.getText();
            if (sLat == null || sLat.equals(""))
            {
                txtGeographical.setText("");
            }
            else
            {
                FLatitude fLat = new FLatitude(sLat);
                double lat = fLat.getDecimalDegree();
                double geoLat = astroLat2GeoLat(lat, altitude);
                FLatitude fGeoLat = new FLatitude(geoLat);
                txtGeographical.setText(fGeoLat.getLatitude());
            }
        }
        else
        {
            String sLat = txtGeographical.getText();
            if (sLat == null || sLat.equals(""))
            {
                txtAstronomical.setText("");
            }
            else
            {
                FLatitude fLat = new FLatitude(sLat);
                double lat = fLat.getDecimalDegree();
                double astroLat = geoLat2AstroLat(lat, altitude);
                FLatitude fAstroLat = new FLatitude(astroLat);
                txtAstronomical.setText(fAstroLat.getLatitude());
            }
        }
    }

    private void calculateWeekDayName()
    {
        String sDate = txtDateDayName.getText();
        if (sDate == null || sDate.equals(""))
        {
            lblWeekDayName.setText("");
        }
        else
        {
            FDate fDate = new FDate(sDate);
            long y = fDate.getYear();
            long m = fDate.getMonth();
            long d = fDate.getDay();
            double jd = AstronomyMaths.gregorianToJulian(d, m, y);
            int weekDay = (int) AstronomyMaths.modulo(jd + 1.5, 7);
            lblWeekDayName.setText(USWeekDays.getName(weekDay));
        }
    }

    private void calculateEaster()
    {
        //considered year
        int an;
        //auxiliary variables
        int ax;
        int bx;
        int cx;
        int d;
        int e;
        int f;
        int g;
        int h;
        int i;
        int k;
        int l;
        int m;
        int nx;
        int p;

        an = new Integer(txtEasterYear.getText()).intValue();

        if (an < 1582)
        {
            //calendrier julien
            ax = AstronomyMaths.modulo(an, 4);
            bx = AstronomyMaths.modulo(an, 7);
            cx = AstronomyMaths.modulo(an, 19);
            d = AstronomyMaths.modulo(19 * cx + 15, 30);
            e = AstronomyMaths.modulo(2 * ax + 4 * bx - d + 34, 7);
            nx = (int) ((d + e + 114) / 31);
            p = d + e + 114 - 31 * nx;
        }
        else
        {
            //calendrier gregorien
            ax = AstronomyMaths.modulo(an, 19);
            bx = (int) (an / 100);
            cx = an - 100 * bx;
            d = (int) (bx / 4);
            e = bx - 4 * d;
            f = (int) ((bx + 8) / 25);
            g = (int) ((bx - f + 1) / 3);
            h = AstronomyMaths.modulo(19 * ax + bx - d - g + 15, 30);
            i = (int) (cx / 4);
            k = cx - 4 * i;
            l = AstronomyMaths.modulo(32 + 2 * e + 2 * i - h - k, 7);
            m = (int) ((ax + 11 * h + 22 * l) / 451);
            nx = (int) ((h + l - 7 * m + 114) / 31);
            p = h + l - 7 * m + 114 - 31 * nx;
        }

        if (MainClass.locale != Locale.FRENCH)
        {
            lblEasterDate.setText("Sunday " + MainForm.monthName[nx - 1] + " - " + (p + 1));
        }
        else
        {
            lblEasterDate.setText("Dimanche " + (p + 1) + " " + MainForm.monthName[nx - 1]);
        }
    }

    private void calculateTime()
    {
        String sLong = txtLongitudeTime.getText();
        if (sLong == null || sLong.equals(""))
        {
            return;
        }
        String sDate = txtDateTime.getText();
        if (sDate == null || sDate.equals(""))
        {
            return;
        }

        if (optLocal2UT.isSelected())
        {
            String sTime = txtLSTTime.getText();
            if (sTime == null || sTime.equals(""))
            {
                txtTimeTime.setText("");
            }
            else
            {
                //conversion of the longitude
                double longitude = new FLongitude(sLong).getDecimalDegree();

                //Calculation of the Julian Day
                FDate fDate = new FDate(sDate);
                long d = fDate.getDay();
                long m = fDate.getMonth();
                long y = fDate.getYear();
                double jj = AstronomyMaths.gregorianToJulian(d, m, y);

                //Calculation of the Greenwich sidereal time at midnight
                double temps_seculaire = AstronomyMaths.getCTime(jj);
                double tsg0 = AstronomyMaths.getGMT0(temps_seculaire);

                //Calculation of the universal time
                FTime fTime = new FTime(sTime);
                double time = fTime.getDecimalHour();
                double ut = AstronomyMaths.LSTToUT(time, longitude, tsg0);
                FTime fUt = new FTime(ut);
                txtTimeTime.setText(fUt.getTime());
            }
        }
        else
        {
            String sTime = txtTimeTime.getText();
            if (sTime == null || sTime.equals(""))
            {
                txtLSTTime.setText("");
            }
            else
            {
                //conversion of the longitude
                double longitude = new FLongitude(sLong).getDecimalDegree();

                //Calculation of the Julian Day
                FDate fDate = new FDate(sDate);
                long d = fDate.getDay();
                long m = fDate.getMonth();
                long y = fDate.getYear();
                double jj = AstronomyMaths.gregorianToJulian(d, m, y);

                //Calculation of the Greenwich sidereal time at midnight
                double temps_seculaire = AstronomyMaths.getCTime(jj);
                double tsg0 = AstronomyMaths.getGMT0(temps_seculaire);

                //Calculation of the local sidereal time
                FTime fTime = new FTime(sTime);
                double time = fTime.getDecimalHour();
                double lst = AstronomyMaths.UTToLST(time, tsg0, longitude);
                FTime fLst = new FTime(lst);
                txtLSTTime.setText(fLst.getTime());
            }
        }
    }

    private void calculateDistance()
    {
        String sUnit = txtUnit[currentUnit].getText();
        if (sUnit == null || sUnit.equals(""))
        {
            return;
        }
        double value = new Double(sUnit).doubleValue();
        for (int j = 0; j <= Units.getLast(); j++)
        {
            if (j == currentUnit)
            {
                j += 1;
            }
            if (j > Units.getLast())
            {
                break;
            }
            double retValue = Units.getValue(currentUnit) / Units.getValue(j) * value;
            txtUnit[j].setText(new Double(retValue).toString());
        }
    }

    private void calculate2Days()
    {
        String sDate1 = txtDate1.getText();
        String sDate2 = txtDate2.getText();
        if (sDate1 == null || sDate2 == null || sDate1.equals("") || sDate2.equals(""))
        {
            lblNumberOfDays.setText("");
        }
        else
        {
            FDate fDate1 = new FDate(sDate1);
            FDate fDate2 = new FDate(sDate2);
            long y = fDate1.getYear();
            long m = fDate1.getMonth();
            long d = fDate1.getDay();
            double jd1 = AstronomyMaths.gregorianToJulian(d, m, y);
            y = fDate2.getYear();
            m = fDate2.getMonth();
            d = fDate2.getDay();
            double jd2 = AstronomyMaths.gregorianToJulian(d, m, y);
            int delta = (int) (jd2 - jd1);
            lblNumberOfDays.setText(new Integer(delta).toString());
        }
    }

    private void btnCalculateActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCalculateActionPerformed
    {//GEN-HEADEREND:event_btnCalculateActionPerformed
        int iMain = tabMain.getSelectedIndex();
        switch (iMain)
        {
            case 1:
                calculatePlanetaryDistance();
                return;
            case 2:
                calculateRiseSet();
                return;
            case 3:
                calculateAlignment();
                return;
            case 4:
                calculateCalendars();
                return;
            case 6:
                calculatePeriAph();
                return;
            case 7:
                calculateNodesCrossing();
                return;
            case 8:
                calculateMoonPhases();
                return;
            case 9:
                currentPlanetForEclipse = Planets.Sun;
                calculateEclipses(-1);
                return;
            case 10:
                calculateSeasons();
                return;
            case 11:
                calculateAsteroid();
                return;
            case 12:
                calculateComet();
                return;
            case 13:
                calculateStar();
                return;
            case 14:
                calculatePlacesDistance();
                return;
            case 0:
                calculateEphemeris();
                return;
            case 15:
                findDate();
                return;
            case 5:
                int iCalc = tabCalc.getSelectedIndex();
                switch (iCalc)
                {
                    case 0:
                        calculateGST0();
                        return;
                    case 1:
                        calculateJulianDay();
                        return;
                    case 2:
                        calculateDegrees();
                        return;
                    case 3:
                        calculateLatitudes();
                        return;
                    case 4:
                        calculateWeekDayName();
                        return;
                    case 5:
                        calculateEaster();
                        return;
                    case 6:
                        calculateTime();
                        return;
                    case 7:
                        calculateDistance();
                        return;
                    case 8:
                        calculate2Days();
                    default:
                }
        }
    }//GEN-LAST:event_btnCalculateActionPerformed

    private void txtLongitudePlaceBFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlaceBFocusLost
    {//GEN-HEADEREND:event_txtLongitudePlaceBFocusLost
        FLongitude l = new FLongitude(txtLongitudePlaceB.getText());
        String longitude = l.getLongitude();
        txtLongitudePlaceB.setText(longitude);
    }//GEN-LAST:event_txtLongitudePlaceBFocusLost

    private void txtLatitudePlaceBFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudePlaceBFocusLost
    {//GEN-HEADEREND:event_txtLatitudePlaceBFocusLost
        FLatitude l = new FLatitude(txtLatitudePlaceB.getText());
        String latitude = l.getLatitude();
        txtLatitudePlaceB.setText(latitude);
    }//GEN-LAST:event_txtLatitudePlaceBFocusLost

    private void txtLongitudePlaceAFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlaceAFocusLost
    {//GEN-HEADEREND:event_txtLongitudePlaceAFocusLost
        FLongitude l = new FLongitude(txtLongitudePlaceA.getText());
        String longitude = l.getLongitude();
        txtLongitudePlaceA.setText(longitude);
    }//GEN-LAST:event_txtLongitudePlaceAFocusLost

    private void txtLatitudePlaceAFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudePlaceAFocusLost
    {//GEN-HEADEREND:event_txtLatitudePlaceAFocusLost
        FLatitude l = new FLatitude(txtLatitudePlaceA.getText());
        String latitude = l.getLatitude();
        txtLatitudePlaceA.setText(latitude);
    }//GEN-LAST:event_txtLatitudePlaceAFocusLost

    private void txtTimePhasesFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTimePhasesFocusLost
    {//GEN-HEADEREND:event_txtTimePhasesFocusLost
        FTime t = new FTime(txtTimePhases.getText());
        String utDate0 = t.getTime();
        txtTimePhases.setText(utDate0);
    }//GEN-LAST:event_txtTimePhasesFocusLost

    private void txtDatePhasesFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDatePhasesFocusLost
    {//GEN-HEADEREND:event_txtDatePhasesFocusLost
        String utDate0 = txtDatePhases.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDatePhases.setText(utDate0);
    }//GEN-LAST:event_txtDatePhasesFocusLost

    private void txtDate2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDate2FocusLost
    {//GEN-HEADEREND:event_txtDate2FocusLost
        String utDate0 = txtDate2.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDate2.setText(utDate0);
    }//GEN-LAST:event_txtDate2FocusLost

    private void txtDate1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDate1FocusLost
    {//GEN-HEADEREND:event_txtDate1FocusLost
        String utDate0 = txtDate1.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDate1.setText(utDate0);
    }//GEN-LAST:event_txtDate1FocusLost

    private void txtLSTTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLSTTimeFocusLost
    {//GEN-HEADEREND:event_txtLSTTimeFocusLost
        /*String strTime = txtLSTTime.getText();
        if (strTime == null || strTime.equals(""))
        {
            return;
        }

        double time = new Double(strTime).doubleValue();
        if (time < 0.0)
        {
            time = 0.0;
            txtLSTTime.setText(new Double(time).toString());
        }
        else if (time > 24.0)
        {
            time = 24.0;
            txtLSTTime.setText(new Double(time).toString());
        }*/
        FTime t = new FTime(txtLSTTime.getText());
        String strTime = t.getTime();
        txtLSTTime.setText(strTime);
    }//GEN-LAST:event_txtLSTTimeFocusLost

    private void txtTimeTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTimeTimeFocusLost
    {//GEN-HEADEREND:event_txtTimeTimeFocusLost
        FTime t = new FTime(txtTimeTime.getText());
        String utDate0 = t.getTime();
        txtTimeTime.setText(utDate0);
    }//GEN-LAST:event_txtTimeTimeFocusLost

    private void txtDateTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateTimeFocusLost
    {//GEN-HEADEREND:event_txtDateTimeFocusLost
        String utDate0 = txtDateTime.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDateTime.setText(utDate0);
    }//GEN-LAST:event_txtDateTimeFocusLost

    private void txtLongitudeTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeTimeFocusLost
    {//GEN-HEADEREND:event_txtLongitudeTimeFocusLost
        FLongitude l = new FLongitude(txtLongitudeTime.getText());
        String longitude = l.getLongitude();
        txtLongitudeTime.setText(longitude);
    }//GEN-LAST:event_txtLongitudeTimeFocusLost

    private void txtEasterYearFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEasterYearFocusLost
    {//GEN-HEADEREND:event_txtEasterYearFocusLost
        String strYear = txtEasterYear.getText();
        if (strYear == null || strYear.equals(""))
        {
            return;
        }

        int easterYear = new Integer(strYear).intValue();
        if (easterYear < 324)
        {
            txtEasterYear.setText("324");
        }
    }//GEN-LAST:event_txtEasterYearFocusLost

    private void txtDateDayNameFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateDayNameFocusLost
    {//GEN-HEADEREND:event_txtDateDayNameFocusLost
        String utDate0 = txtDateDayName.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDateDayName.setText(utDate0);
    }//GEN-LAST:event_txtDateDayNameFocusLost

    private void txtAstronomicalFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtAstronomicalFocusLost
    {//GEN-HEADEREND:event_txtAstronomicalFocusLost
        FLatitude l = new FLatitude(txtAstronomical.getText());
        String latitude = l.getLatitude();
        txtAstronomical.setText(latitude);
    }//GEN-LAST:event_txtAstronomicalFocusLost

    private void txtGeographicalFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtGeographicalFocusLost
    {//GEN-HEADEREND:event_txtGeographicalFocusLost
        FLatitude l = new FLatitude(txtGeographical.getText());
        String latitude = l.getLatitude();
        txtGeographical.setText(latitude);
    }//GEN-LAST:event_txtGeographicalFocusLost

    private void txtSexagesimalFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtSexagesimalFocusLost
    {//GEN-HEADEREND:event_txtSexagesimalFocusLost
        //FDegree d = new FDegree(txtSexagesimal.getText());
        //String degree = d.getSDegree();
        String degree = txtSexagesimal.getText();
        degree = new FLongitude(degree).getLongitude();
        txtSexagesimal.setText(degree);
    }//GEN-LAST:event_txtSexagesimalFocusLost

    private void txtGregorianDateFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtGregorianDateFocusLost
    {//GEN-HEADEREND:event_txtGregorianDateFocusLost
        String utDate0 = txtGregorianDate.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtGregorianDate.setText(utDate0);
    }//GEN-LAST:event_txtGregorianDateFocusLost

    private void txtDateGST0FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateGST0FocusLost
    {//GEN-HEADEREND:event_txtDateGST0FocusLost
        String utDate0 = txtDateGST0.getText();
        utDate0 = MainClass.getFormatedDate(utDate0);
        txtDateGST0.setText(utDate0);
    }//GEN-LAST:event_txtDateGST0FocusLost

    private void txtTimeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTimeFocusLost
    {//GEN-HEADEREND:event_txtTimeFocusLost
        FTime t = new FTime(txtTime.getText());
        String sTime = t.getTime();
        txtTime.setText(sTime);

        if (optLocal2UT.isSelected())
        {
            localTime = sTime;
            event.setLocalTime(sTime);
            /*event.utTimeCalculation(TZRules.FirstTime);
            utDate = event.getUtDate();
            utTime = event.getUtTime();*/
        }
        else
        {
            utTime = sTime;
            event.setUtTime(sTime);
            /*event.localTimeCalculation(TZRules.FirstTime);
            localDate = event.getLocalDate();
            localTime = event.getLocalTime();*/
        }
        btnCalcTZActionPerformed(null);

        //update other time fields
        txtTimePhases.setText(utTime);
        txtTimeTime.setText(utTime);
    }//GEN-LAST:event_txtTimeFocusLost

    private void txtDateFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDateFocusLost
    {//GEN-HEADEREND:event_txtDateFocusLost
        String sDate = txtDate.getText();
        sDate = MainClass.getFormatedDate(sDate);
        txtDate.setText(sDate);

        if (optLocal2UT.isSelected())
        {
            localDate = sDate;
            event.setLocalDate(sDate);
            /*event.utTimeCalculation(TZRules.FirstTime);
            utDate = event.getUtDate();
            utTime = event.getUtTime();*/
        }
        else
        {
            utDate = sDate;
            event.setUtDate(sDate);
            /*event.localTimeCalculation(TZRules.FirstTime);
            localDate = event.getLocalDate();
            localTime = event.getLocalTime();*/
        }
        btnCalcTZActionPerformed(null);

        //update other date fields
        txtDate1.setText(utDate);
        txtDate2.setText(utDate);
        txtDateDayName.setText(utDate);
        txtDateGST0.setText(utDate);
        txtDatePhases.setText(utDate);
        txtDateTime.setText(utDate);
        txtGregorianDate.setText(utDate);

        //update year fields
        FDate fd = new FDate(utDate);
        long y = fd.getYear();
        String year = new Long(y).toString();
        txtEasterYear.setText(year);
        txtYearEclipses.setText(year);
        txtYearNodes.setText(year);
        txtYearPeri.setText(year);
        txtYearSeasons.setText(year);
    }//GEN-LAST:event_txtDateFocusLost

    private void txtLongitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeFocusLost
    {//GEN-HEADEREND:event_txtLongitudeFocusLost
        FLongitude l = new FLongitude(txtLongitude.getText());
        String longitude = l.getLongitude();
        txtLongitude.setText(longitude);

        //update other longitude fields
        txtLongitude.setText(longitude);
        txtLongitudeTime.setText(longitude);
        txtLongitudePlace1.setText(longitude);
        txtLongitudePlace2.setText(longitude);
        txtLongitudePlace3.setText(longitude);
        txtLongitudePlaceA.setText(longitude);
        txtLongitudePlaceB.setText(longitude);
        txtSexagesimal.setText(longitude);
        event.setLongitude(longitude);
    }//GEN-LAST:event_txtLongitudeFocusLost

    private void txtLatitudeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudeFocusLost
    {//GEN-HEADEREND:event_txtLatitudeFocusLost
        FLatitude l = new FLatitude(txtLatitude.getText());
        String latitude = l.getLatitude();
        txtLatitude.setText(latitude);

        //update other latitude fields
        txtLatitudePlace1.setText(latitude);
        txtLatitudePlace2.setText(latitude);
        txtLatitudePlace3.setText(latitude);
        txtLatitudePlaceA.setText(latitude);
        txtLatitudePlaceB.setText(latitude);
        txtGeographical.setText(latitude);
        event.setLatitude(latitude);
    }//GEN-LAST:event_txtLatitudeFocusLost

    private void txtLongitudePlace3FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlace3FocusLost
    {//GEN-HEADEREND:event_txtLongitudePlace3FocusLost
        FLongitude l = new FLongitude(txtLongitudePlace3.getText());
        String longitude = l.getLongitude();
        txtLongitudePlace3.setText(longitude);
    }//GEN-LAST:event_txtLongitudePlace3FocusLost

    private void txtLatitudePlace3FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudePlace3FocusLost
    {//GEN-HEADEREND:event_txtLatitudePlace3FocusLost
        FLatitude l = new FLatitude(txtLatitudePlace3.getText());
        String latitude = l.getLatitude();
        txtLatitudePlace3.setText(latitude);
    }//GEN-LAST:event_txtLatitudePlace3FocusLost

    private void txtLatitudePlace2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudePlace2FocusLost
    {//GEN-HEADEREND:event_txtLatitudePlace2FocusLost
        FLatitude l = new FLatitude(txtLatitudePlace2.getText());
        String latitude = l.getLatitude();
        txtLatitudePlace2.setText(latitude);
    }//GEN-LAST:event_txtLatitudePlace2FocusLost

    private void txtLongitudePlace1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlace1FocusLost
    {//GEN-HEADEREND:event_txtLongitudePlace1FocusLost
        FLongitude l = new FLongitude(txtLongitudePlace1.getText());
        String longitude = l.getLongitude();
        txtLongitudePlace1.setText(longitude);
    }//GEN-LAST:event_txtLongitudePlace1FocusLost

    private void txtLatitudePlace1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudePlace1FocusLost
    {//GEN-HEADEREND:event_txtLatitudePlace1FocusLost
        FLatitude l = new FLatitude(txtLatitudePlace1.getText());
        String latitude = l.getLatitude();
        txtLatitudePlace1.setText(latitude);
    }//GEN-LAST:event_txtLatitudePlace1FocusLost

    private void txtDate2keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDate2keyTyped
    {//GEN-HEADEREND:event_txtDate2keyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDate2, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDate2.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDate2keyTyped

    private void txtDate1keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDate1keyTyped
    {//GEN-HEADEREND:event_txtDate1keyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDate1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDate1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDate1keyTyped

    private void txtLSTTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLSTTimekeyTyped
    {//GEN-HEADEREND:event_txtLSTTimekeyTyped
        //KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtLSTTime, 12, kc);
        KTTime ti = new KTTime(evt, txtLSTTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLSTTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLSTTimekeyTyped

    private void txtTimeTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimeTimekeyTyped
    {//GEN-HEADEREND:event_txtTimeTimekeyTyped
        KTTime ti = new KTTime(evt, txtTimeTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTimeTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTimeTimekeyTyped

    private void txtDateTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateTimekeyTyped
    {//GEN-HEADEREND:event_txtDateTimekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDateTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateTimekeyTyped

    private void txtLongitudeTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeTimekeyTyped
    {//GEN-HEADEREND:event_txtLongitudeTimekeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudeTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeTimekeyTyped

    private void txtEasterYearkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEasterYearkeyTyped
    {//GEN-HEADEREND:event_txtEasterYearkeyTyped
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtEasterYear, 4, kc);
    }//GEN-LAST:event_txtEasterYearkeyTyped

    private void txtDateDayNamekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateDayNamekeyTyped
    {//GEN-HEADEREND:event_txtDateDayNamekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDateDayName, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateDayName.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateDayNamekeyTyped

    private void txtAstronomicalkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAstronomicalkeyTyped
    {//GEN-HEADEREND:event_txtAstronomicalkeyTyped
        KTLatitude lng = new KTLatitude(evt, txtAstronomical, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtAstronomical.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtAstronomicalkeyTyped

    private void txtGeographicalkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtGeographicalkeyTyped
    {//GEN-HEADEREND:event_txtGeographicalkeyTyped
        KTLatitude lng = new KTLatitude(evt, txtGeographical, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtGeographical.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtGeographicalkeyTyped

    private void txtAltitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtAltitudekeyTyped
    {//GEN-HEADEREND:event_txtAltitudekeyTyped
        KTDecimal d = new KTDecimal(evt, txtAltitude, 12, kc);
    }//GEN-LAST:event_txtAltitudekeyTyped

    private void txtDecimalkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDecimalkeyTyped
    {//GEN-HEADEREND:event_txtDecimalkeyTyped
        KTDecimal d = new KTDecimal(evt, txtDecimal, 12, kc);
    }//GEN-LAST:event_txtDecimalkeyTyped

    private void txtSexagesimalkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSexagesimalkeyTyped
    {//GEN-HEADEREND:event_txtSexagesimalkeyTyped
        KTLongitude lng = new KTLongitude(evt, txtSexagesimal, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtSexagesimal.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtSexagesimalkeyTyped

    private void txtJulianDaykeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJulianDaykeyTyped
    {//GEN-HEADEREND:event_txtJulianDaykeyTyped
        KTDecimal d = new KTDecimal(evt, txtJulianDay, 12, kc);
    }//GEN-LAST:event_txtJulianDaykeyTyped

    private void txtGregorianDatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtGregorianDatekeyTyped
    {//GEN-HEADEREND:event_txtGregorianDatekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtGregorianDate, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtGregorianDate.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtGregorianDatekeyTyped

    private void txtYearSeasonskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearSeasonskeyTyped
    {//GEN-HEADEREND:event_txtYearSeasonskeyTyped
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtYearSeasons, 4, kc);
    }//GEN-LAST:event_txtYearSeasonskeyTyped

    private void txtYearEclipseskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearEclipseskeyTyped
    {//GEN-HEADEREND:event_txtYearEclipseskeyTyped
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtYearEclipses, 4, kc);
    }//GEN-LAST:event_txtYearEclipseskeyTyped

    private void txtTimePhaseskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimePhaseskeyTyped
    {//GEN-HEADEREND:event_txtTimePhaseskeyTyped
        KTTime ti = new KTTime(evt, txtTimePhases, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTimePhases.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTimePhaseskeyTyped

    private void txtDatePhaseskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDatePhaseskeyTyped
    {//GEN-HEADEREND:event_txtDatePhaseskeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDatePhases, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDatePhases.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDatePhaseskeyTyped

    private void txtYearNodeskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearNodeskeyTyped
    {//GEN-HEADEREND:event_txtYearNodeskeyTyped
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtYearNodes, 4, kc);
    }//GEN-LAST:event_txtYearNodeskeyTyped

    private void txtYearPerikeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtYearPerikeyTyped
    {//GEN-HEADEREND:event_txtYearPerikeyTyped
        KTUnsignedInteger d = new KTUnsignedInteger(evt, txtYearPeri, 4, kc);
    }//GEN-LAST:event_txtYearPerikeyTyped

    private void txtDateGST0keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateGST0keyTyped
    {//GEN-HEADEREND:event_txtDateGST0keyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDateGST0, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateGST0.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateGST0keyTyped

    private void btnNextEclipseActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextEclipseActionPerformed
    {//GEN-HEADEREND:event_btnNextEclipseActionPerformed
        calculateEclipses(moon);
    }//GEN-LAST:event_btnNextEclipseActionPerformed

    private void txtLongitudePlace2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlace2FocusLost
    {//GEN-HEADEREND:event_txtLongitudePlace2FocusLost
        FLongitude l = new FLongitude(txtLongitudePlace2.getText());
        String sText = l.getLongitude();
        txtLongitudePlace2.setText(sText);
    }//GEN-LAST:event_txtLongitudePlace2FocusLost

    private void txtTZFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTZFocusLost
    {//GEN-HEADEREND:event_txtTZFocusLost
        String sText = txtTZ.getText();
        if (sText == null || sText.equals(""))
        {
            return;
        }
        txtTZ.setText(new Double(txtTZ.getText()).toString());

        String tz0 = txtTZ.getText();
        if (tz0.equals(""))
        {
            return;
        }
        double value = new Double(tz0).doubleValue();

        //The value must be between -24 and 24
        if (value < -24.0)
        {
            tz0 = "-24";
            txtTZ.setText(tz0);
        }
        else if (value > 24.0)
        {
            tz0 = "24";
            txtTZ.setText(tz0);
        }
        event.setTimeLag(tz0);
    }//GEN-LAST:event_txtTZFocusLost

    private void txtTZkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTZkeyTyped
    {//GEN-HEADEREND:event_txtTZkeyTyped
        KTDecimal d = new KTDecimal(evt, txtTZ, 8, kc);
    }//GEN-LAST:event_txtTZkeyTyped

    private void txtTimekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTimekeyTyped
    {//GEN-HEADEREND:event_txtTimekeyTyped
        KTTime ti = new KTTime(evt, txtTime, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTime.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTimekeyTyped

    private void txtDatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDatekeyTyped
    {//GEN-HEADEREND:event_txtDatekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtDate, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDate.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDatekeyTyped

    private void txtLatitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudekeyTyped
    {//GEN-HEADEREND:event_txtLatitudekeyTyped
        KTLatitude lng = new KTLatitude(evt, txtLatitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitude.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudekeyTyped

    private void txtLongitudekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudekeyTyped
    {//GEN-HEADEREND:event_txtLongitudekeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitude, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitude.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudekeyTyped

    private void txtLongitudePlaceBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlaceBkeyTyped
    {//GEN-HEADEREND:event_txtLongitudePlaceBkeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudePlaceB, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePlaceB.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlaceBkeyTyped

    private void txtLongitudePlaceAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlaceAkeyTyped
    {//GEN-HEADEREND:event_txtLongitudePlaceAkeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudePlaceA, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePlaceA.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlaceAkeyTyped

    private void txtLongitudePlace3keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace3keyTyped
    {//GEN-HEADEREND:event_txtLongitudePlace3keyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudePlace3, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePlace3.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlace3keyTyped

    private void txtLongitudePlace2keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace2keyTyped
    {//GEN-HEADEREND:event_txtLongitudePlace2keyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudePlace2, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePlace2.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlace2keyTyped

    private void txtLongitudePlace1keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlace1keyTyped
    {//GEN-HEADEREND:event_txtLongitudePlace1keyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudePlace1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePlace1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlace1keyTyped

    private void txtLatitudePlaceBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlaceBkeyTyped
    {//GEN-HEADEREND:event_txtLatitudePlaceBkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudePlaceB, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudePlaceB.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudePlaceBkeyTyped

    private void txtLatitudePlaceAkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlaceAkeyTyped
    {//GEN-HEADEREND:event_txtLatitudePlaceAkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudePlaceA, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudePlaceA.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudePlaceAkeyTyped

    private void txtLatitudePlace3keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace3keyTyped
    {//GEN-HEADEREND:event_txtLatitudePlace3keyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudePlace3, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudePlace3.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudePlace3keyTyped

    private void txtLatitudePlace2keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace2keyTyped
    {//GEN-HEADEREND:event_txtLatitudePlace2keyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudePlace2, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudePlace2.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudePlace2keyTyped

    private void txtLatitudePlace1keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudePlace1keyTyped
    {//GEN-HEADEREND:event_txtLatitudePlace1keyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudePlace1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudePlace1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudePlace1keyTyped

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void btnCalcTZActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCalcTZActionPerformed
    {//GEN-HEADEREND:event_btnCalcTZActionPerformed
        changeTime(TZRules.FirstTime);
        changeTime(TZRules.SecondTime);
    }//GEN-LAST:event_btnCalcTZActionPerformed

    private void changeTime(byte intCall)
    {
        event.setLatitude(txtLatitude.getText());
        event.setLongitude(txtLongitude.getText());
        event.setPlace(txtPlace.getText());
        if ( optLocal.isSelected() == true )
        {
            event.setLocalDate(txtDate.getText());
            event.setLocalTime(txtTime.getText());
            event.utTimeCalculation(intCall);
            utDate = event.getUtDate();
            utTime = event.getUtTime();
        }
        else
        {
            event.setUtDate(txtDate.getText());
            event.setUtTime(txtTime.getText());
            event.localTimeCalculation(intCall);
            localDate = event.getLocalDate();
            localTime = event.getLocalTime();
        }
        tz = event.getTimeLag();
        txtTZ.setText(tz);
        event.setTimeLag(tz);
        
        if (intCall == TZRules.SecondTime)
        {
            localDate = event.getLocalDate();
            utDate = event.getUtDate();
            localTime = event.getLocalTime();
            utTime = event.getUtTime();
            tz = event.getTimeLag();
        }
        localDate = MainClass.getFormatedDate(localDate);
        localTime = MainClass.getFormatedTime(localTime);
        utDate = MainClass.getFormatedDate(utDate);
        utTime = MainClass.getFormatedTime(utTime);
    }

    /** Exit the Form **/
    private void exitForm(java.awt.event.WindowEvent evt)//GEN-FIRST:event_exitForm
    {
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (saveStar()==false||saveComet()==false||saveAsteroid()==false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        if (parentForm instanceof MainForm)
            ((MainForm)parentForm).setCalculFrame(false);
        
        Rectangle rct = this.getBounds();
        int state = this.getExtendedState();
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        int div = jSplitPane1.getDividerLocation();
        MainClass.options.setDivider(classname, "jSplitPane1", div);
        setEnabled(false);
        dispose();
    }//GEN-LAST:event_exitForm

    private void cboAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboAsteroidActionPerformed
    {//GEN-HEADEREND:event_cboAsteroidActionPerformed
        if ((bolSetting == false) && (bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            int index = cboAsteroid.getSelectedIndex();
            showAsteroid(index + 1);
        }
}//GEN-LAST:event_cboAsteroidActionPerformed

    private void btnFirstAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnFirstAsteroidActionPerformed
        if ((bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            showAsteroid(1);
        }
}//GEN-LAST:event_btnFirstAsteroidActionPerformed

    private void btnPreviousAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnPreviousAsteroidActionPerformed
        if ((asteroidRow > 1) && (bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            showAsteroid(asteroidRow - 1);
        }
}//GEN-LAST:event_btnPreviousAsteroidActionPerformed

    private void txtCounterAsteroidKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCounterAsteroidKeyReleased
    {//GEN-HEADEREND:event_txtCounterAsteroidKeyReleased
        if ((bolSetting == false) && (bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            String value = txtCounterAsteroid.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            asteroidRow = new Integer(value).intValue();
            if (asteroidRow > asteroidNbOfRows)
            {
                asteroidRow = asteroidNbOfRows;
            }
            showAsteroid(asteroidRow);
        }
}//GEN-LAST:event_txtCounterAsteroidKeyReleased

    private void btnNextAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnNextAsteroidActionPerformed
        if ((asteroidRow < asteroidNbOfRows) && (bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            showAsteroid(asteroidRow + 1);
        }
}//GEN-LAST:event_btnNextAsteroidActionPerformed

    private void btnLastAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnLastAsteroidActionPerformed
        if ((bolAsteroidAdding == false) && (bolAsteroidEditing == false) && (bolDeleting == false))
        {
            showAsteroid(asteroidNbOfRows);
        }
}//GEN-LAST:event_btnLastAsteroidActionPerformed

    private void btnRemoveAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnRemoveAsteroidActionPerformed
        removeAsteroidRec();
}//GEN-LAST:event_btnRemoveAsteroidActionPerformed

    private void btnAddAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnAddAsteroidActionPerformed
        addAsteroidRecord();
}//GEN-LAST:event_btnAddAsteroidActionPerformed

    private void btnOKAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnOKAsteroidActionPerformed
        saveAsteroid();
}//GEN-LAST:event_btnOKAsteroidActionPerformed

    private void btnCancelAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnCancelAsteroidActionPerformed
        if (bolAsteroidAdding == true)
        {
            asteroidRow = saveAsteroidRow;
        }
        bolAsteroidEditing = false;
        bolAsteroidAdding = false;
        bolDeleting = false;
        setAsteroidNormalMode();
        refreshAsteroidRecord();
}//GEN-LAST:event_btnCancelAsteroidActionPerformed

    private void cboStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboStarActionPerformed
    {//GEN-HEADEREND:event_cboStarActionPerformed
        if ((bolSetting == false) && (bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            int index = cboStar.getSelectedIndex();
            showStar(index + 1);
        }
    }//GEN-LAST:event_cboStarActionPerformed

    private void btnFirstStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstStarActionPerformed
    {//GEN-HEADEREND:event_btnFirstStarActionPerformed
        if ((bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            showStar(1);
        }
    }//GEN-LAST:event_btnFirstStarActionPerformed

    private void btnPreviousStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousStarActionPerformed
    {//GEN-HEADEREND:event_btnPreviousStarActionPerformed
        if ((starRow > 1) && (bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            showStar(starRow - 1);
        }
    }//GEN-LAST:event_btnPreviousStarActionPerformed

    private void txtCounterStarKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCounterStarKeyReleased
    {//GEN-HEADEREND:event_txtCounterStarKeyReleased
        if ((bolSetting == false) && (bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            String value = txtCounterStar.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            starRow = new Integer(value).intValue();
            if (starRow > starNbOfRows)
            {
                starRow = starNbOfRows;
            }
            showStar(starRow);
        }
    }//GEN-LAST:event_txtCounterStarKeyReleased

    private void btnNextStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextStarActionPerformed
    {//GEN-HEADEREND:event_btnNextStarActionPerformed
        if ((starRow < starNbOfRows) && (bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            showStar(starRow + 1);
        }
    }//GEN-LAST:event_btnNextStarActionPerformed

    private void btnLastStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastStarActionPerformed
    {//GEN-HEADEREND:event_btnLastStarActionPerformed
        if ((bolStarAdding == false) && (bolStarEditing == false) && (bolDeleting == false))
        {
            showStar(starNbOfRows);
        }
    }//GEN-LAST:event_btnLastStarActionPerformed

    private void btnRemoveStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveStarActionPerformed
    {//GEN-HEADEREND:event_btnRemoveStarActionPerformed
        removeStarRec();
    }//GEN-LAST:event_btnRemoveStarActionPerformed

    private void btnAddStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddStarActionPerformed
    {//GEN-HEADEREND:event_btnAddStarActionPerformed
        addStarRecord();
    }//GEN-LAST:event_btnAddStarActionPerformed

    private void btnOKStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKStarActionPerformed
    {//GEN-HEADEREND:event_btnOKStarActionPerformed
        saveStar();
    }//GEN-LAST:event_btnOKStarActionPerformed

    private void btnCancelStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelStarActionPerformed
    {//GEN-HEADEREND:event_btnCancelStarActionPerformed
        if (bolStarAdding == true)
        {
            starRow = saveStarRow;
        }
        bolStarEditing = false;
        bolStarAdding = false;
        bolDeleting = false;
        setStarNormalMode();
        refreshStarRecord();
    }//GEN-LAST:event_btnCancelStarActionPerformed

    private void cboCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboCometActionPerformed
    {//GEN-HEADEREND:event_cboCometActionPerformed
        if ((bolSetting == false) && (bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            int index = cboComet.getSelectedIndex();
            showComet(index + 1);
        }
    }//GEN-LAST:event_cboCometActionPerformed

    private void btnFirstCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstCometActionPerformed
    {//GEN-HEADEREND:event_btnFirstCometActionPerformed
        if ((bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            showComet(1);
        }
    }//GEN-LAST:event_btnFirstCometActionPerformed

    private void btnPreviousCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousCometActionPerformed
    {//GEN-HEADEREND:event_btnPreviousCometActionPerformed
        if ((cometRow > 1) && (bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            showComet(cometRow - 1);
        }
    }//GEN-LAST:event_btnPreviousCometActionPerformed

    private void txtCounterCometKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCounterCometKeyReleased
    {//GEN-HEADEREND:event_txtCounterCometKeyReleased
        if ((bolSetting == false) && (bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            String value = txtCounterComet.getText();
            int pos = value.indexOf(" /");
            if (pos <= 0)
            {
                pos = 1;
            }
            value = value.substring(0, pos);
            cometRow = new Integer(value).intValue();
            if (cometRow > cometNbOfRows)
            {
                cometRow = cometNbOfRows;
            }
            showComet(cometRow);
        }
    }//GEN-LAST:event_txtCounterCometKeyReleased

    private void btnNextCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextCometActionPerformed
    {//GEN-HEADEREND:event_btnNextCometActionPerformed
        if ((cometRow < cometNbOfRows) && (bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            showComet(cometRow + 1);
        }
    }//GEN-LAST:event_btnNextCometActionPerformed

    private void btnLastCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastCometActionPerformed
    {//GEN-HEADEREND:event_btnLastCometActionPerformed
        if ((bolCometAdding == false) && (bolCometEditing == false) && (bolDeleting == false))
        {
            showComet(cometNbOfRows);
        }
    }//GEN-LAST:event_btnLastCometActionPerformed

    private void btnRemoveCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveCometActionPerformed
    {//GEN-HEADEREND:event_btnRemoveCometActionPerformed
        removeCometRec();
    }//GEN-LAST:event_btnRemoveCometActionPerformed

    private void btnAddCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddCometActionPerformed
    {//GEN-HEADEREND:event_btnAddCometActionPerformed
        addCometRecord();
    }//GEN-LAST:event_btnAddCometActionPerformed

    private void btnOKCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKCometActionPerformed
    {//GEN-HEADEREND:event_btnOKCometActionPerformed
        saveComet();
    }//GEN-LAST:event_btnOKCometActionPerformed

    private void btnCancelCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelCometActionPerformed
    {//GEN-HEADEREND:event_btnCancelCometActionPerformed
        if (bolCometAdding == true)
        {
            cometRow = saveCometRow;
        }
        bolCometEditing = false;
        bolCometAdding = false;
        bolDeleting = false;
        setCometNormalMode();
        refreshCometRecord();
    }//GEN-LAST:event_btnCancelCometActionPerformed

    private void mnuDeleteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuDeleteActionPerformed
    {//GEN-HEADEREND:event_mnuDeleteActionPerformed
        Component invoker = jPMenuDelete.getInvoker();
        if (invoker != null && invoker.getName() != null && invoker.getName().equals(bundle.getString("LBLASTEROIDSAVE")))
        {
            removeAsteroidRec();
        }
        else
        {
            if ((bolAsteroidEditing == false) && (bolAsteroidAdding == false))
            {
                showAsteroid(asteroidID);
            }
        }
}//GEN-LAST:event_mnuDeleteActionPerformed

    private void txtSupposedYearKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSupposedYearKeyPressed
    {//GEN-HEADEREND:event_txtSupposedYearKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
    }//GEN-LAST:event_txtSupposedYearKeyPressed

    private void txtSupposedYearkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSupposedYearkeyTyped
    {//GEN-HEADEREND:event_txtSupposedYearkeyTyped
        KTInteger d = new KTInteger(evt, txtSupposedYear, 4, kc);
    }//GEN-LAST:event_txtSupposedYearkeyTyped

    private void txtLongitudeSunkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeSunkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeSunkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeSun, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeSun.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeSunkeyTyped

    private void txtLongitudeSunKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeSunKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeSunKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeSun.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeSun.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeSun, kc);
        }
    }//GEN-LAST:event_txtLongitudeSunKeyPressed

    private void txtLongitudeMoonkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMoonkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeMoonkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeMoon, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeMoon.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeMoonkeyTyped

    private void txtLongitudeMoonKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMoonKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeMoonKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeMoon.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeMoon.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeMoon, kc);
        }
    }//GEN-LAST:event_txtLongitudeMoonKeyPressed

    private void txtLongitudeMercurykeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMercurykeyTyped
    {//GEN-HEADEREND:event_txtLongitudeMercurykeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeMercury, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeMercury.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeMercurykeyTyped

    private void txtLongitudeMercuryKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMercuryKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeMercuryKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeMercury.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeMercury.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeMercury, kc);
        }
    }//GEN-LAST:event_txtLongitudeMercuryKeyPressed

    private void txtLongitudeVenuskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeVenuskeyTyped
    {//GEN-HEADEREND:event_txtLongitudeVenuskeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeVenus, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeVenus.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeVenuskeyTyped

    private void txtLongitudeVenusKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeVenusKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeVenusKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeVenus.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeVenus.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeVenus, kc);
        }
    }//GEN-LAST:event_txtLongitudeVenusKeyPressed

    private void txtLongitudeMarskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMarskeyTyped
    {//GEN-HEADEREND:event_txtLongitudeMarskeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeMars, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeMars.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeMarskeyTyped

    private void txtLongitudeMarsKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMarsKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeMarsKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeMars.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeMars.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeMars, kc);
        }
    }//GEN-LAST:event_txtLongitudeMarsKeyPressed

    private void txtLongitudeJupiterkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeJupiterkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeJupiterkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeJupiter, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeJupiter.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeJupiterkeyTyped

    private void txtLongitudeJupiterKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeJupiterKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeJupiterKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeJupiter.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeJupiter.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeJupiter, kc);
        }
    }//GEN-LAST:event_txtLongitudeJupiterKeyPressed

    private void txtLongitudeSaturnkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeSaturnkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeSaturnkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeSaturn, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeSaturn.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeSaturnkeyTyped

    private void txtLongitudeSaturnKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeSaturnKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeSaturnKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeSaturn.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeSaturn.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeSaturn, kc);
        }
    }//GEN-LAST:event_txtLongitudeSaturnKeyPressed

    private void txtLongitudeUranuskeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeUranuskeyTyped
    {//GEN-HEADEREND:event_txtLongitudeUranuskeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeUranus, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeUranus.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeUranuskeyTyped

    private void txtLongitudeUranusKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeUranusKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeUranusKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeUranus.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeUranus.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeUranus, kc);
        }
    }//GEN-LAST:event_txtLongitudeUranusKeyPressed

    private void txtLongitudeNeptunekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeNeptunekeyTyped
    {//GEN-HEADEREND:event_txtLongitudeNeptunekeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeNeptune, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeNeptune.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeNeptunekeyTyped

    private void txtLongitudeNeptuneKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeNeptuneKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeNeptuneKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeNeptune.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeNeptune.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeNeptune, kc);
        }
    }//GEN-LAST:event_txtLongitudeNeptuneKeyPressed

    private void txtLongitudePlutokeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlutokeyTyped
    {//GEN-HEADEREND:event_txtLongitudePlutokeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudePluto, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudePluto.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudePlutokeyTyped

    private void txtLongitudePlutoKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudePlutoKeyPressed
    {//GEN-HEADEREND:event_txtLongitudePlutoKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudePluto.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudePluto.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudePluto, kc);
        }
    }//GEN-LAST:event_txtLongitudePlutoKeyPressed

    private void txtLongitudeASkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeASkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeASkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeAS, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeAS.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeASkeyTyped

    private void txtLongitudeASKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeASKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeASKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeAS.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeAS.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeAS, kc);
        }
    }//GEN-LAST:event_txtLongitudeASKeyPressed

    private void txtLongitudeMCkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMCkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeMCkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLongitudeMC, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeMC.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeMCkeyTyped

    private void txtLongitudeMCKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeMCKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeMCKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeMC.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtLongitudeMC.setText("");
        }
        else
        {
            KTLatitude lat;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                lat = new KTLatitude(evt, txtLongitudeMC, kc);
        }
    }//GEN-LAST:event_txtLongitudeMCKeyPressed

    private void txtLongitudeSunFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeSunFocusLost
    {//GEN-HEADEREND:event_txtLongitudeSunFocusLost
        //FLatitude l = new FLatitude(txtLongitudeSun.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeSun.getText().replace("-", " ");
        txtLongitudeSun.setText(sText);
    }//GEN-LAST:event_txtLongitudeSunFocusLost

    private void txtLongitudeMercuryFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeMercuryFocusLost
    {//GEN-HEADEREND:event_txtLongitudeMercuryFocusLost
        //FLatitude l = new FLatitude(txtLongitudeMercury.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeMercury.getText().replace("-", " ");
        txtLongitudeMercury.setText(sText);
    }//GEN-LAST:event_txtLongitudeMercuryFocusLost

    private void txtLongitudeMoonFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeMoonFocusLost
    {//GEN-HEADEREND:event_txtLongitudeMoonFocusLost
        //FLatitude l = new FLatitude(txtLongitudeMoon.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeMoon.getText().replace("-", " ");
        txtLongitudeMoon.setText(sText);
    }//GEN-LAST:event_txtLongitudeMoonFocusLost

    private void txtLongitudeVenusFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeVenusFocusLost
    {//GEN-HEADEREND:event_txtLongitudeVenusFocusLost
        //FLatitude l = new FLatitude(txtLongitudeVenus.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeVenus.getText().replace("-", " ");
        txtLongitudeVenus.setText(sText);
    }//GEN-LAST:event_txtLongitudeVenusFocusLost

    private void txtLongitudeMarsFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeMarsFocusLost
    {//GEN-HEADEREND:event_txtLongitudeMarsFocusLost
        //FLatitude l = new FLatitude(txtLongitudeMars.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeMars.getText().replace("-", " ");
        txtLongitudeMars.setText(sText);
    }//GEN-LAST:event_txtLongitudeMarsFocusLost

    private void txtLongitudeJupiterFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeJupiterFocusLost
    {//GEN-HEADEREND:event_txtLongitudeJupiterFocusLost
        //FLatitude l = new FLatitude(txtLongitudeJupiter.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeJupiter.getText().replace("-", " ");
        txtLongitudeJupiter.setText(sText);
    }//GEN-LAST:event_txtLongitudeJupiterFocusLost

    private void txtLongitudeSaturnFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeSaturnFocusLost
    {//GEN-HEADEREND:event_txtLongitudeSaturnFocusLost
        //FLatitude l = new FLatitude(txtLongitudeSaturn.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeSaturn.getText().replace("-", " ");
        txtLongitudeSaturn.setText(sText);
    }//GEN-LAST:event_txtLongitudeSaturnFocusLost

    private void txtLongitudeUranusFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeUranusFocusLost
    {//GEN-HEADEREND:event_txtLongitudeUranusFocusLost
        //FLatitude l = new FLatitude(txtLongitudeUranus.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeUranus.getText().replace("-", " ");
        txtLongitudeUranus.setText(sText);
    }//GEN-LAST:event_txtLongitudeUranusFocusLost

    private void txtLongitudeNeptuneFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeNeptuneFocusLost
    {//GEN-HEADEREND:event_txtLongitudeNeptuneFocusLost
        //FLatitude l = new FLatitude(txtLongitudeNeptune.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeNeptune.getText().replace("-", " ");
        txtLongitudeNeptune.setText(sText);
    }//GEN-LAST:event_txtLongitudeNeptuneFocusLost

    private void txtLongitudePlutoFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudePlutoFocusLost
    {//GEN-HEADEREND:event_txtLongitudePlutoFocusLost
        //FLatitude l = new FLatitude(txtLongitudePluto.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudePluto.getText().replace("-", " ");
        txtLongitudePluto.setText(sText);
    }//GEN-LAST:event_txtLongitudePlutoFocusLost

    private void txtLongitudeASFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeASFocusLost
    {//GEN-HEADEREND:event_txtLongitudeASFocusLost
        //FLatitude l = new FLatitude(txtLongitudeAS.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeAS.getText().replace("-", " ");
        txtLongitudeAS.setText(sText);
    }//GEN-LAST:event_txtLongitudeASFocusLost

    private void txtLongitudeMCFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeMCFocusLost
    {//GEN-HEADEREND:event_txtLongitudeMCFocusLost
        //FLatitude l = new FLatitude(txtLongitudeMC.getText());
        //String sText = l.getLatitude();
        String sText = txtLongitudeMC.getText().replace("-", " ");
        txtLongitudeMC.setText(sText);
    }//GEN-LAST:event_txtLongitudeMCFocusLost

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearActionPerformed
    {//GEN-HEADEREND:event_btnClearActionPerformed
        txtLongitudeSun.setText("");
        txtLongitudeMoon.setText("");
        txtLongitudeMercury.setText("");
        txtLongitudeVenus.setText("");
        txtLongitudeMars.setText("");
        txtLongitudeJupiter.setText("");
        txtLongitudeSaturn.setText("");
        txtLongitudeUranus.setText("");
        txtLongitudeNeptune.setText("");
        txtLongitudePluto.setText("");
        txtLongitudeAS.setText("");
        txtLongitudeMC.setText("");
        txtResultFindDate.setText("");
        txtSupposedYear.setText("");
        cboLongitudeSun.setSelectedIndex(0);
        cboLongitudeMoon.setSelectedIndex(0);
        cboLongitudeMercury.setSelectedIndex(0);
        cboLongitudeVenus.setSelectedIndex(0);
        cboLongitudeMars.setSelectedIndex(0);
        cboLongitudeJupiter.setSelectedIndex(0);
        cboLongitudeSaturn.setSelectedIndex(0);
        cboLongitudeUranus.setSelectedIndex(0);
        cboLongitudeNeptune.setSelectedIndex(0);
        cboLongitudePluto.setSelectedIndex(0);
        cboLongitudeAS.setSelectedIndex(0);
        cboLongitudeMC.setSelectedIndex(0);
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtPlaceMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtPlaceMouseClicked
    {//GEN-HEADEREND:event_txtPlaceMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtPlace, "places", "PLACENAME", bundle.getString("placesPLACENAME"), false, null, false, null, false);
            txtPlace.setText(strText);
            
            String latitude = "";
            String longitude = "";

            if (!strText.equals(""))
            {
                
                Places places = starLoginManager.getPlaces();
                ArrayList p = places.getRecords();

                for (int i = 0; i < p.size(); i++)
                {
                    ArrayList v = (ArrayList) p.get(i);
                    String strID = String.valueOf(v.get(0));
                    String strName = String.valueOf(v.get(1));
                    if (strName.equals(strText))
                    {
                        Place place = starLoginManager.getPlace(strID);
                        latitude = place.getPlaceLatitude();
                        longitude = place.getPlaceLongitude();
                        break;
                    }
                }
            }

            //update latitude and longitude fields
            FLongitude longi = new FLongitude(longitude);
            longitude = longi.getLongitude();
            FLatitude lati = new FLatitude(latitude);
            latitude = lati.getLatitude();
            txtLatitude.setText(latitude);
            txtLatitudePlace1.setText(latitude);
            txtLatitudePlace2.setText(latitude);
            txtLatitudePlace3.setText(latitude);
            txtLatitudePlaceA.setText(latitude);
            txtLatitudePlaceB.setText(latitude);
            txtGeographical.setText(latitude);
            txtLongitude.setText(longitude);
            txtLongitudeTime.setText(longitude);
            txtLongitudePlace1.setText(longitude);
            txtLongitudePlace2.setText(longitude);
            txtLongitudePlace3.setText(longitude);
            txtLongitudePlaceA.setText(longitude);
            txtLongitudePlaceB.setText(longitude);
            txtSexagesimal.setText(longitude);

            event.setLatitude(latitude);
            event.setLongitude(longitude);
            event.setPlace(strText);
            MainClass.testPlace(strText, latitude, longitude, this);
        }
    }//GEN-LAST:event_txtPlaceMouseClicked

    private void txtPlaceFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtPlaceFocusLost
    {//GEN-HEADEREND:event_txtPlaceFocusLost
        String place = txtPlace.getText();
        event.setPlace(place);
    }//GEN-LAST:event_txtPlaceFocusLost

    private void txtPlaceKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceKeyPressed
    {//GEN-HEADEREND:event_txtPlaceKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPlace.setText(event.getPlace());
            String latitude = event.getLatitude();
            String longitude = event.getLongitude();
            FLatitude l = new FLatitude(latitude);
            latitude = l.getLatitude();
            FLongitude lo = new FLongitude(longitude);
            longitude = lo.getLongitude();
            txtLatitude.setText(latitude);
            txtLongitude.setText(longitude);
        }
    }//GEN-LAST:event_txtPlaceKeyPressed

    private void btnQueriesAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnQueriesAsteroidActionPerformed
    {//GEN-HEADEREND:event_btnQueriesAsteroidActionPerformed
        DialogQueryTool gf = new DialogQueryTool(5, this, true);
    }//GEN-LAST:event_btnQueriesAsteroidActionPerformed

    private void btnQueriesCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnQueriesCometActionPerformed
    {//GEN-HEADEREND:event_btnQueriesCometActionPerformed
        DialogQueryTool gf = new DialogQueryTool(7, this, true);
    }//GEN-LAST:event_btnQueriesCometActionPerformed

    private void btnQueriesStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnQueriesStarActionPerformed
    {//GEN-HEADEREND:event_btnQueriesStarActionPerformed
        DialogQueryTool gf = new DialogQueryTool(8, this, true);
    }//GEN-LAST:event_btnQueriesStarActionPerformed

    private void optLocalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optLocalActionPerformed
    {//GEN-HEADEREND:event_optLocalActionPerformed
        txtDate.setText(localDate);
        txtTime.setText(localTime);
    }//GEN-LAST:event_optLocalActionPerformed

    private void optUTActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optUTActionPerformed
    {//GEN-HEADEREND:event_optUTActionPerformed
        txtDate.setText(utDate);
        txtTime.setText(utTime);
    }//GEN-LAST:event_optUTActionPerformed

    private void txtLongitudeSunMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeSunMousePressed
    {//GEN-HEADEREND:event_txtLongitudeSunMousePressed
        if (txtLongitudeSun.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeSun.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeSunMousePressed

    private void txtLongitudeMercuryMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeMercuryMousePressed
    {//GEN-HEADEREND:event_txtLongitudeMercuryMousePressed
        if (txtLongitudeMercury.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeMercury.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeMercuryMousePressed

    private void txtLongitudeMarsMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeMarsMousePressed
    {//GEN-HEADEREND:event_txtLongitudeMarsMousePressed
        if (txtLongitudeMars.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeMars.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeMarsMousePressed

    private void txtLongitudeSaturnMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeSaturnMousePressed
    {//GEN-HEADEREND:event_txtLongitudeSaturnMousePressed
        if (txtLongitudeSaturn.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeSaturn.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeSaturnMousePressed

    private void txtLongitudeNeptuneMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeNeptuneMousePressed
    {//GEN-HEADEREND:event_txtLongitudeNeptuneMousePressed
        if (txtLongitudeNeptune.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeNeptune.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeNeptuneMousePressed

    private void txtLongitudeASMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeASMousePressed
    {//GEN-HEADEREND:event_txtLongitudeASMousePressed
        if (txtLongitudeAS.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeAS.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeASMousePressed

    private void txtLongitudeMoonMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeMoonMousePressed
    {//GEN-HEADEREND:event_txtLongitudeMoonMousePressed
        if (txtLongitudeMoon.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeMoon.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeMoonMousePressed

    private void txtLongitudeVenusMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeVenusMousePressed
    {//GEN-HEADEREND:event_txtLongitudeVenusMousePressed
        if (txtLongitudeVenus.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeVenus.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeVenusMousePressed

    private void txtLongitudeJupiterMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeJupiterMousePressed
    {//GEN-HEADEREND:event_txtLongitudeJupiterMousePressed
        if (txtLongitudeJupiter.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeJupiter.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeJupiterMousePressed

    private void txtLongitudeUranusMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeUranusMousePressed
    {//GEN-HEADEREND:event_txtLongitudeUranusMousePressed
        if (txtLongitudeUranus.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeUranus.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeUranusMousePressed

    private void txtLongitudePlutoMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudePlutoMousePressed
    {//GEN-HEADEREND:event_txtLongitudePlutoMousePressed
        if (txtLongitudePluto.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudePluto.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudePlutoMousePressed

    private void txtLongitudeMCMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtLongitudeMCMousePressed
    {//GEN-HEADEREND:event_txtLongitudeMCMousePressed
        if (txtLongitudeMC.getText().equals(""))
        {
            FLatitude flat = new FLatitude(0.0);
            txtLongitudeMC.setText(flat.getLatitude());
        }
    }//GEN-LAST:event_txtLongitudeMCMousePressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel1;
    private javax.swing.JButton btnAddAsteroid;
    private javax.swing.JButton btnAddComet;
    private javax.swing.JButton btnAddStar;
    private javax.swing.JButton btnCalcTZ;
    private javax.swing.JButton btnCalculate;
    private javax.swing.JButton btnCancelAsteroid;
    private javax.swing.JButton btnCancelComet;
    private javax.swing.JButton btnCancelStar;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnFirstAsteroid;
    private javax.swing.JButton btnFirstComet;
    private javax.swing.JButton btnFirstStar;
    private javax.swing.ButtonGroup btnGroupDegrees;
    private javax.swing.ButtonGroup btnGroupJulian;
    private javax.swing.ButtonGroup btnGroupLatitudes;
    private javax.swing.ButtonGroup btnGroupTimeKind;
    private javax.swing.ButtonGroup btnGroupTimes;
    private javax.swing.JButton btnHinduCycles;
    private javax.swing.JButton btnLastAsteroid;
    private javax.swing.JButton btnLastComet;
    private javax.swing.JButton btnLastStar;
    private javax.swing.JButton btnNextAsteroid;
    private javax.swing.JButton btnNextComet;
    private javax.swing.JButton btnNextEclipse;
    private javax.swing.JButton btnNextStar;
    private javax.swing.JButton btnOKAsteroid;
    private javax.swing.JButton btnOKComet;
    private javax.swing.JButton btnOKStar;
    private javax.swing.JButton btnPreviousAsteroid;
    private javax.swing.JButton btnPreviousComet;
    private javax.swing.JButton btnPreviousStar;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnProgressedMoon;
    private javax.swing.JButton btnQueriesAsteroid;
    private javax.swing.JButton btnQueriesComet;
    private javax.swing.JButton btnQueriesStar;
    private javax.swing.JButton btnRemoveAsteroid;
    private javax.swing.JButton btnRemoveComet;
    private javax.swing.JButton btnRemoveStar;
    private javax.swing.JComboBox cboAsteroid;
    private javax.swing.JComboBox cboComet;
    private javax.swing.JComboBox cboCoordinate;
    private javax.swing.JComboBox cboLongitudeAS;
    private javax.swing.JComboBox cboLongitudeJupiter;
    private javax.swing.JComboBox cboLongitudeMC;
    private javax.swing.JComboBox cboLongitudeMars;
    private javax.swing.JComboBox cboLongitudeMercury;
    private javax.swing.JComboBox cboLongitudeMoon;
    private javax.swing.JComboBox cboLongitudeNeptune;
    private javax.swing.JComboBox cboLongitudePluto;
    private javax.swing.JComboBox cboLongitudeSaturn;
    private javax.swing.JComboBox cboLongitudeSun;
    private javax.swing.JComboBox cboLongitudeUranus;
    private javax.swing.JComboBox cboLongitudeVenus;
    private javax.swing.JComboBox cboPlanet1Dist;
    private javax.swing.JComboBox cboPlanet2Dist;
    private javax.swing.JComboBox cboPlanetNodes;
    private javax.swing.JComboBox cboPlanetPeri;
    private javax.swing.JComboBox cboPlanetRiseSet;
    private javax.swing.JComboBox cboStar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JLabel jLabelAsteroid;
    private javax.swing.JLabel jLabelComet;
    private javax.swing.JLabel jLabelStar;
    private javax.swing.JPopupMenu jPMenuDelete;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPnlAsteroidPhoto;
    private javax.swing.JPanel jPnlCometPhoto;
    private javax.swing.JPanel jPnlStarPhoto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblAS;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblAngleA;
    private javax.swing.JLabel lblAngleAB;
    private javax.swing.JLabel lblAngleB;
    private javax.swing.JLabel lblAngleC;
    private javax.swing.JLabel lblAngleDiffAlign;
    private javax.swing.JLabel lblAphelion;
    private javax.swing.JLabel lblApparentAngle;
    private javax.swing.JLabel lblDateEclipse;
    private javax.swing.JLabel lblDim;
    private javax.swing.JLabel lblDimension;
    private javax.swing.JLabel lblDistanceAB;
    private javax.swing.JLabel lblDistancePlanets;
    private javax.swing.JLabel lblEasterDate;
    private javax.swing.JLabel lblEclipse;
    private javax.swing.JLabel lblEphemeris;
    private javax.swing.JLabel lblFall;
    private javax.swing.JLabel lblGST0;
    private javax.swing.JLabel lblHalfLight;
    private javax.swing.JLabel lblHalfLightDuration;
    private javax.swing.JLabel lblHemi;
    private javax.swing.JLabel lblHemisphere;
    private javax.swing.JLabel lblJupiter;
    private javax.swing.JLabel lblLatitude;
    private javax.swing.JLabel lblLongitude;
    private javax.swing.JLabel lblMC;
    private javax.swing.JLabel lblMars;
    private javax.swing.JLabel lblMercury;
    private javax.swing.JLabel lblMeridianTime;
    private javax.swing.JLabel lblMoon;
    private javax.swing.JLabel lblMoonPhase;
    private javax.swing.JLabel lblNeptune;
    private javax.swing.JLabel lblNorthNode;
    private javax.swing.JLabel lblNumberOfDays;
    private javax.swing.JLabel lblPerihelion;
    private javax.swing.JLabel lblPhase;
    private javax.swing.JLabel lblPluto;
    private javax.swing.JLabel lblRisePosition;
    private javax.swing.JLabel lblRiseTime;
    private javax.swing.JLabel lblSaturn;
    private javax.swing.JLabel lblSetPosition;
    private javax.swing.JLabel lblSetTime;
    private javax.swing.JLabel lblShadow;
    private javax.swing.JLabel lblShadowDuration;
    private javax.swing.JLabel lblSouthNode;
    private javax.swing.JLabel lblSpring;
    private javax.swing.JLabel lblStarMagnitude;
    private javax.swing.JLabel lblSummer;
    private javax.swing.JLabel lblSun;
    private javax.swing.JLabel lblType;
    private javax.swing.JLabel lblUranus;
    private javax.swing.JLabel lblVenus;
    private javax.swing.JLabel lblWeekDayName;
    private javax.swing.JLabel lblWinter;
    private javax.swing.JMenuItem mnuDelete;
    private javax.swing.JRadioButton optAstro2Geo;
    private javax.swing.JRadioButton optDeci2Sexa;
    private javax.swing.JRadioButton optGeo2Astro;
    private javax.swing.JRadioButton optGreg2JD;
    private javax.swing.JRadioButton optJD2Greg;
    private javax.swing.JRadioButton optLocal;
    private javax.swing.JRadioButton optLocal2UT;
    private javax.swing.JRadioButton optSexa2Deci;
    private javax.swing.JRadioButton optUT;
    private javax.swing.JRadioButton optUT2Local;
    private javax.swing.JPanel pnlAlign;
    private javax.swing.JPanel pnlAsteroids;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlCalendars;
    private javax.swing.JPanel pnlComets;
    private javax.swing.JPanel pnlControlBarAsteroid;
    private javax.swing.JPanel pnlControlBarComet;
    private javax.swing.JPanel pnlControlBarStar;
    private javax.swing.JPanel pnlConversions;
    private javax.swing.JPanel pnlCoordEphemeris;
    private javax.swing.JPanel pnlDataAsteroid;
    private javax.swing.JPanel pnlDataComet;
    private javax.swing.JPanel pnlDataStar;
    private javax.swing.JPanel pnlDegrees;
    private javax.swing.JPanel pnlDetailAsteroid;
    private javax.swing.JPanel pnlDetailComet;
    private javax.swing.JPanel pnlDetailStar;
    private javax.swing.JPanel pnlDistances;
    private javax.swing.JPanel pnlEclipses;
    private javax.swing.JPanel pnlEphemeris;
    private javax.swing.JPanel pnlEphemeris1;
    private javax.swing.JPanel pnlEphemeris2;
    private javax.swing.JPanel pnlFindDate;
    private javax.swing.JPanel pnlGST0;
    private javax.swing.JPanel pnlJulianDay;
    private javax.swing.JPanel pnlMoonPhases;
    private javax.swing.JPanel pnlNodesCrossing;
    private javax.swing.JPanel pnlPerihelionAphelion;
    private javax.swing.JPanel pnlPlanetaryDistances;
    private javax.swing.JPanel pnlRevolution;
    private javax.swing.JPanel pnlRiseSet;
    private javax.swing.JPanel pnlSeasons;
    private javax.swing.JPanel pnlSpace;
    private javax.swing.JPanel pnlStars;
    private javax.swing.JPanel pnlTime;
    private javax.swing.JPanel pnlUnits;
    private javax.swing.JScrollPane scrollPanelGraphicsEphemeris;
    private javax.swing.JTabbedPane tabCalc;
    private javax.swing.JTabbedPane tabMain;
    private javax.swing.JTextField txtAltitude;
    private javax.swing.JTextField txtAsteroid12A;
    private javax.swing.JTextField txtAsteroidAM;
    private javax.swing.JTextField txtAsteroidAP;
    private javax.swing.JTextField txtAsteroidE;
    private javax.swing.JTextField txtAsteroidEpoch;
    private javax.swing.JTextField txtAsteroidI;
    private javax.swing.JTextField txtAsteroidLNA;
    private javax.swing.JTextField txtAsteroidM;
    private javax.swing.JTextField txtAsteroidNumber;
    private javax.swing.JTextField txtAstronomical;
    private javax.swing.JTextField txtComet12A;
    private javax.swing.JTextField txtCometAP;
    private javax.swing.JTextField txtCometDP;
    private javax.swing.JTextField txtCometDateP;
    private javax.swing.JTextField txtCometE;
    private javax.swing.JTextField txtCometI;
    private javax.swing.JTextField txtCometNA;
    private javax.swing.JTextField txtCometPeriod;
    private javax.swing.JTextField txtCounterAsteroid;
    private javax.swing.JTextField txtCounterComet;
    private javax.swing.JTextField txtCounterStar;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtDate1;
    private javax.swing.JTextField txtDate2;
    private javax.swing.JTextField txtDateDayName;
    private javax.swing.JTextField txtDateGST0;
    private javax.swing.JTextField txtDatePhases;
    private javax.swing.JTextField txtDateTime;
    private javax.swing.JTextField txtDecimal;
    private javax.swing.JTextField txtEasterYear;
    private javax.swing.JTextField txtGeographical;
    private javax.swing.JTextField txtGregorianDate;
    private javax.swing.JTextField txtJulianDay;
    private javax.swing.JTextField txtLSTTime;
    private javax.swing.JTextField txtLatitude;
    private javax.swing.JTextField txtLatitudePlace1;
    private javax.swing.JTextField txtLatitudePlace2;
    private javax.swing.JTextField txtLatitudePlace3;
    private javax.swing.JTextField txtLatitudePlaceA;
    private javax.swing.JTextField txtLatitudePlaceB;
    private javax.swing.JTextField txtLongitude;
    private javax.swing.JTextField txtLongitudeAS;
    private javax.swing.JTextField txtLongitudeJupiter;
    private javax.swing.JTextField txtLongitudeMC;
    private javax.swing.JTextField txtLongitudeMars;
    private javax.swing.JTextField txtLongitudeMercury;
    private javax.swing.JTextField txtLongitudeMoon;
    private javax.swing.JTextField txtLongitudeNeptune;
    private javax.swing.JTextField txtLongitudePlace1;
    private javax.swing.JTextField txtLongitudePlace2;
    private javax.swing.JTextField txtLongitudePlace3;
    private javax.swing.JTextField txtLongitudePlaceA;
    private javax.swing.JTextField txtLongitudePlaceB;
    private javax.swing.JTextField txtLongitudePluto;
    private javax.swing.JTextField txtLongitudeSaturn;
    private javax.swing.JTextField txtLongitudeSun;
    private javax.swing.JTextField txtLongitudeTime;
    private javax.swing.JTextField txtLongitudeUranus;
    private javax.swing.JTextField txtLongitudeVenus;
    private javax.swing.JTextField txtPlace;
    private javax.swing.JTextArea txtResultAsteroid;
    private javax.swing.JTextArea txtResultComet;
    private javax.swing.JTextArea txtResultEclipses;
    private javax.swing.JTextArea txtResultEphemeris;
    private javax.swing.JTextArea txtResultFindDate;
    private javax.swing.JTextArea txtResultStar;
    private javax.swing.JTextField txtSexagesimal;
    private javax.swing.JTextField txtStarD;
    private javax.swing.JTextField txtStarDistance;
    private javax.swing.JTextField txtStarErrDist;
    private javax.swing.JTextField txtStarHR;
    private javax.swing.JTextField txtStarMagnitude;
    private javax.swing.JTextField txtStarMotionD;
    private javax.swing.JTextField txtStarMotionRA;
    private javax.swing.JTextField txtStarName;
    private javax.swing.JTextField txtStarRA;
    private javax.swing.JTextField txtStarRV;
    private javax.swing.JTextField txtStarSCI;
    private javax.swing.JTextField txtSupposedYear;
    private javax.swing.JTextField txtTZ;
    private javax.swing.JTextField txtTime;
    private javax.swing.JTextField txtTimePhases;
    private javax.swing.JTextField txtTimeTime;
    private javax.swing.JTextField txtYearEclipses;
    private javax.swing.JTextField txtYearNodes;
    private javax.swing.JTextField txtYearPeri;
    private javax.swing.JTextField txtYearSeasons;
    // End of variables declaration//GEN-END:variables
}
