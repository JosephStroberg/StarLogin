/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTDate;
import StarLogin.IHM.components.KeyType.KTUnsignedInteger;
import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.Data.Record;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author Francois
 */
public class DialogRecur extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager;
    private Window parentForm;
    private java.util.ResourceBundle bundle;
    private String sQuery = "SELECT ID,DEBUT,FIN,TYPE_RECUR,NB_RECUR,WEEKDAY_RECUR,MONTHDAY_RECUR,MONTH_RECUR,NUMWEEKINMONTH_RECUR,NBMAXRECUR,RDVID FROM rdvrecur";
    private String rdvid;
    private String rdvrecurid;
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private String datefin = FDate.curUsFormDate();
    private String datedebut = datefin;
    private DataBaseRecord dbr;
    private Record recur;
    private String type_recur;
    private String nb_recur;
    private String weekday_recur;
    private String monthday_recur;
    private String month_recur;
    private String numweekinmonth_recur;
    private String nbmaxrecur;
    private boolean bSetting = true;
    private int kc; //key code
    private int cp; //caret position;
    
    
    /**
     * Creates new form RecurForm
     */
    public DialogRecur(java.awt.Frame parent, boolean modal, String rdvid, String rdvrecurid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        this.rdvid = rdvid;
        this.rdvrecurid = rdvrecurid;
        setDlg();
    }
    
    public DialogRecur(java.awt.Dialog parent, boolean modal, String rdvid, String rdvrecurid)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        this.rdvid = rdvid;
        this.rdvrecurid = rdvrecurid;
        setDlg();
    }
    
    private void setDlg()
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;
        bundle = MainClass.bundle;
        initComponents();
        optFin1.setVisible(false);
        pnlFin1.setVisible(false);
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        bolAdding = false;
        if (rdvrecurid.equals("")||rdvrecurid.equals("0")||rdvrecurid.equals("-1"))
            bolAdding = true;
        bolEditing = false;
        refreshRecord();
        resetLangue();
        bSetting = false;
        setDataToText();
        Color fEO = Options.getColor("EtiquetteObligatoire.background");
        Color pEO = Options.getColor("EtiquetteObligatoire.foreground");
        Color fTO = Options.getColor("SaisieObligatoire.background");
        Color pTO = Options.getColor("SaisieObligatoire.foreground");
        lblDateDebut.setBackground(fEO);
        lblDateDebut.setForeground(pEO);
        txtDateDebut.setBackground(fTO);
        txtDateDebut.setForeground(pTO);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setVisible(true);
        //bSetting = false;
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }
    
    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setTextToData();
            if (datedebut.equals(""))
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("DataObligatoirePasRemplies").concat("\n").concat(lblDateDebut.getText()), JOptionPane.WARNING_MESSAGE);
                return false;
            }
            //ID,DEBUT,FIN,TYPE_RECUR,NB_RECUR,WEEKDAY_RECUR,MONTHDAY_RECUR,MONTH_RECUR,NUMWEEKINMONTH_RECUR,NBMAXRECUR,RDVID
            //update data
            recur.setAdding(bolAdding);
            recur.setData(1, FDate.fr2us(datedebut));
            recur.setData(2, FDate.fr2us(datefin));
            recur.setData(3, type_recur);
            recur.setData(4, nb_recur);
            recur.setData(5, weekday_recur);
            recur.setData(6, monthday_recur);
            recur.setData(7, month_recur);
            recur.setData(8, numweekinmonth_recur);
            recur.setData(9, nbmaxrecur);
            recur.setData(10, rdvid);
            starLoginManager.setRecord(recur, dbr);
            // recurid = "-1";
            if (bolAdding)
            {
                String recurid = starLoginManager.getStringFieldValue("rdvrecur", "MAX(ID)", "");
                starLoginManager.updateDataBase("UPDATE rdv SET RDVRECURID=" + recurid + " WHERE ID=" + rdvid);
            }
            
            bolEditing = false;
            MainClass.buildRecursRdv(datedebut, rdvid, chkKeepState.isSelected());
            /*if (parentForm instanceof DialogRdv)
            {
                //fonction utile que si plusieurs commis (pas de commis dans cette version)
                ((DialogRdv)parentForm).setDialogRecurID(recurid, true);
            }*/
            if (parentForm instanceof ListeRdvForm)
            {
                ((ListeRdvForm)parentForm).setRow();
            }
            bolAdding = false;
            setNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    private void setDataToText()
    {
        //bSetting = true;
        if (bolAdding)
        {
            datedebut = MainClass.no2defaultDate("", MainClass.DATE_CURRENT);
            datefin = MainClass.addDays2Date(FDate.curUsFormDate(), 365);
            datefin = MainClass.getFormatedDate(datefin);
        }
        txtDateDebut.setText(datedebut);
        txtDateFin.setText(datefin);
        if (type_recur.equals("1"))
        {
            optSchema1.setSelected(true);
            optSchema1ActionPerformed(null);
            txtJours.setText(nb_recur);
        }
        else if (type_recur.equals("2"))
        {
            optSchema2.setSelected(true);
            optSchema2ActionPerformed(null);
            txtSemaines.setText(nb_recur);
            chkSem1.setSelected(weekday_recur.contains("1"));
            chkSem2.setSelected(weekday_recur.contains("2"));
            chkSem3.setSelected(weekday_recur.contains("3"));
            chkSem4.setSelected(weekday_recur.contains("4"));
            chkSem5.setSelected(weekday_recur.contains("5"));
            chkSem6.setSelected(weekday_recur.contains("6"));
            chkSem7.setSelected(weekday_recur.contains("0"));
        }
        else if (type_recur.equals("3"))
        {
            optSchema3.setSelected(true);
            optSchema3ActionPerformed(null);
            if (nb_recur.equals("0"))
                txtMois.setText("");
            else
                txtMois.setText(nb_recur);
            if (monthday_recur.equals("0"))
                txtJourMois.setText("");
            else
                txtJourMois.setText(monthday_recur);
            bSetting = true;
            if (numweekinmonth_recur.equals("1"))
                cboWeekMNo.setSelectedIndex(0);
            else if (numweekinmonth_recur.equals("2"))
                cboWeekMNo.setSelectedIndex(1);
            else if (numweekinmonth_recur.equals("3"))
                cboWeekMNo.setSelectedIndex(2);
            else if (numweekinmonth_recur.equals("4"))
                cboWeekMNo.setSelectedIndex(3);
            else if (numweekinmonth_recur.equals("5"))
                cboWeekMNo.setSelectedIndex(4);
            if (weekday_recur.equals(""))
                weekday_recur = "0";
            int wd = Integer.valueOf(weekday_recur).intValue();
            cboWeekDay.setSelectedIndex(wd - 1);
            if (monthday_recur.equals("")||monthday_recur.equals("0"))
            {
                optMois2.setSelected(true);
            }
            else
            {
                optMois1.setSelected(true);
            }
            bSetting = false;
        }
        else if (type_recur.equals("4"))
        {
            optSchema4.setSelected(true);
            optSchema4ActionPerformed(null);
            txtJourMois1.setText(monthday_recur);
            cboWeekMNo1.setSelectedIndex(Integer.valueOf(numweekinmonth_recur).intValue() - 1);
            bSetting = true;
            if (monthday_recur.equals(""))
            {
                optAnnuel2.setSelected(true);
                cboMois2.setSelectedIndex(Integer.valueOf(monthday_recur).intValue() - 1);
            }
            else
            {
                optAnnuel1.setSelected(true);
                cboMois1.setSelectedIndex(Integer.valueOf(monthday_recur).intValue() - 1);
            }
            bSetting = false;
        }
        txtNbOccurrences.setText(nbmaxrecur);
        if (nbmaxrecur.equals("")||nbmaxrecur.equals("0"))
        {
            optFin3.setSelected(true);
            optFin3ActionPerformed(null);
        }
        else
        {
            optFin2.setSelected(true);
            optFin2ActionPerformed(null);
        }
        bSetting = false;
        if (!bolAdding)
        {
            setNormalMode();
        }
        bolEditing = false;
    }
    
    private void setTextToData()
    {
        datedebut = txtDateDebut.getText();
        datefin = txtDateFin.getText();
        if (optSchema1.isSelected())
        {
            type_recur = "1";
            nb_recur = txtJours.getText();
            if (nb_recur.equals(""))
                nb_recur = "1";
        }
        else if (optSchema2.isSelected())
        {
            type_recur = "2";
            nb_recur = txtSemaines.getText();
            if (nb_recur.equals(""))
                nb_recur = "1";
            weekday_recur = "";
            if (chkSem1.isSelected())
                weekday_recur = weekday_recur.concat("1");
            if (chkSem2.isSelected())
                weekday_recur = weekday_recur.concat("2");
            if (chkSem3.isSelected())
                weekday_recur = weekday_recur.concat("3");
            if (chkSem4.isSelected())
                weekday_recur = weekday_recur.concat("4");
            if (chkSem5.isSelected())
                weekday_recur = weekday_recur.concat("5");
            if (chkSem6.isSelected())
                weekday_recur = weekday_recur.concat("6");
            if (chkSem7.isSelected())
                weekday_recur = weekday_recur.concat("0");
        }
        else if (optSchema3.isSelected())
        {
            type_recur = "3";
            nb_recur = txtMois.getText();
            if (nb_recur.equals(""))
                nb_recur = "1";
            if (optMois1.isSelected())
            {
                monthday_recur = txtJourMois.getText();
            }
            else
            {
                numweekinmonth_recur = String.valueOf(cboWeekMNo.getSelectedIndex()+1);
                weekday_recur = String.valueOf(cboWeekDay.getSelectedIndex()+1);
            }
        }
        else if (optSchema4.isSelected())
        {
            type_recur = "4";
            monthday_recur = txtJourMois1.getText();
            if (monthday_recur.equals(""))
                monthday_recur = "1";
            numweekinmonth_recur = String.valueOf(cboWeekMNo1.getSelectedIndex()+1);
            if (optAnnuel1.isSelected())
            {
                month_recur = String.valueOf(cboMois1.getSelectedIndex()+1);
            }
            else
            {
                month_recur = String.valueOf(cboMois2.getSelectedIndex()+1);
            }
        }
        nbmaxrecur = txtNbOccurrences.getText();
    }
    
    private int askToSave()
    {
        int result = JOptionPane.NO_OPTION;
        if (bolEditing)
        {
            if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Recurrence"),JOptionPane.YES_NO_OPTION);
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void refreshRecord()
    {
        if (rdvrecurid.equals(""))
            rdvrecurid = "-1";
        //ID,DEBUT,FIN,TYPE_RECUR,NB_RECUR,WEEKDAY_RECUR,MONTHDAY_RECUR,MONTH_RECUR,NUMWEEKINMONTH_RECUR,NBMAXRECUR,RDVID
            
        recur = starLoginManager.getRecord(sQuery + " WHERE ID=" + rdvrecurid, "rdvrecur", "");
        dbr = starLoginManager.getDBRecord();
        datedebut = MainClass.getFormatedDate(recur.getData(1));
        datefin = MainClass.getFormatedDate(recur.getData(2));
        type_recur = recur.getData(3);
        nb_recur = recur.getData(4);
        weekday_recur = recur.getData(5);
        monthday_recur = recur.getData(6);
        month_recur = recur.getData(7);
        numweekinmonth_recur = recur.getData(8);
        nbmaxrecur = recur.getData(9);
    }
    
    private void resetLangue()
    {
        this.setTitle(bundle.getString("Recurrence"));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(bundle.getString("SchemaRecurrence")));
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(bundle.getString("RangeRecur")));
        chkKeepState.setText(bundle.getString("KeepStateRdv"));
        chkKeepState.setToolTipText(bundle.getString("KeepStateRdv2"));
        optSchema1.setText(bundle.getString("Journalier"));
        optSchema2.setText(bundle.getString("Hebdomadaire"));
        optSchema3.setText(bundle.getString("Mensuel"));
        optSchema4.setText(bundle.getString("Annuel"));
        lblTousLes.setText(bundle.getString("TousLes"));
        lblJours.setText(bundle.getString("jours"));
        lblToutesLes.setText(bundle.getString("ToutesLes"));
        lblSemaine.setText(bundle.getString("semaines"));
        lblJoursSuivants.setText(bundle.getString("LesJoursSuivants"));
        chkSem1.setText(bundle.getString("WeekDay1"));
        chkSem2.setText(bundle.getString("WeekDay2"));
        chkSem3.setText(bundle.getString("WeekDay3"));
        chkSem4.setText(bundle.getString("WeekDay4"));
        chkSem5.setText(bundle.getString("WeekDay5"));
        chkSem6.setText(bundle.getString("WeekDay6"));
        chkSem7.setText(bundle.getString("WeekDay7"));
        lblTousLes1.setText(bundle.getString("TousLes"));
        lblMois.setText(bundle.getString("mois"));
        optMois1.setText(bundle.getString("Jour"));
        optMois2.setText(bundle.getString("Le"));
        cboWeekMNo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("premier"), bundle.getString("deuxieme"), bundle.getString("troisieme"), bundle.getString("quatrieme"), bundle.getString("dernier") }));
        cboWeekDay.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("WeekDay1"), bundle.getString("WeekDay2"), bundle.getString("WeekDay3"), bundle.getString("WeekDay4"), bundle.getString("WeekDay5"), bundle.getString("WeekDay6"), bundle.getString("WeekDay7") }));
        optAnnuel1.setText(bundle.getString("Le"));
        cboMois1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("Month1"), bundle.getString("Month2"), bundle.getString("Month3"), bundle.getString("Month4"), bundle.getString("Month5"), bundle.getString("Month6"), bundle.getString("Month7"), bundle.getString("Month8"), bundle.getString("Month9"), bundle.getString("Month10"), bundle.getString("Month11"), bundle.getString("Month12") }));
        optAnnuel2.setText(bundle.getString("Le"));
        cboWeekMNo1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("premier"), bundle.getString("deuxieme"), bundle.getString("troisieme"), bundle.getString("quatrieme"), bundle.getString("dernier") }));
        cboWeekDay1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("WeekDay1"), bundle.getString("WeekDay2"), bundle.getString("WeekDay3"), bundle.getString("WeekDay4"), bundle.getString("WeekDay5"), bundle.getString("WeekDay6"), bundle.getString("WeekDay7") }));
        lblSemaine1.setText(bundle.getString("de"));
        cboMois2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("Month1"), bundle.getString("Month2"), bundle.getString("Month3"), bundle.getString("Month4"), bundle.getString("Month5"), bundle.getString("Month6"), bundle.getString("Month7"), bundle.getString("Month8"), bundle.getString("Month9"), bundle.getString("Month10"), bundle.getString("Month11"), bundle.getString("Month12") }));
        cboWeekMNo.setSelectedIndex(-1);
        cboWeekMNo1.setSelectedIndex(-1);
        cboWeekDay.setSelectedIndex(-1);
        cboWeekDay1.setSelectedIndex(-1);
        cboMois1.setSelectedIndex(-1);
        cboMois2.setSelectedIndex(-1);
        optFin1.setText(bundle.getString("NoEndDate"));
        optFin3.setText(bundle.getString("FinLe"));
        optFin2.setText(bundle.getString("FinApres"));
        txtNbOccurrences.setText("10");
        lblNbOccurrences.setText(bundle.getString("occurrences"));
        lblDateDebut.setText(bundle.getString("DateDebut"));
        txtDateDebut.setToolTipText(bundle.getString("DateFormat"));
        btnOK.setText(bundle.getString("Valider"));
        btnCancel.setText(bundle.getString("Cancel"));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpMensuel = new javax.swing.ButtonGroup();
        grpAnnuel = new javax.swing.ButtonGroup();
        grpSchema = new javax.swing.ButtonGroup();
        grpFin = new javax.swing.ButtonGroup();
        jPanel14 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        optSchema1 = new javax.swing.JRadioButton();
        optSchema2 = new javax.swing.JRadioButton();
        optSchema3 = new javax.swing.JRadioButton();
        optSchema4 = new javax.swing.JRadioButton();
        jPanel6 = new javax.swing.JPanel();
        pnlJournalier = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblTousLes = new javax.swing.JLabel();
        txtJours = new javax.swing.JTextField();
        lblJours = new javax.swing.JLabel();
        pnlHebdo = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        lblToutesLes = new javax.swing.JLabel();
        txtSemaines = new javax.swing.JTextField();
        lblSemaine = new javax.swing.JLabel();
        lblJoursSuivants = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        chkSem1 = new javax.swing.JCheckBox();
        chkSem2 = new javax.swing.JCheckBox();
        chkSem3 = new javax.swing.JCheckBox();
        chkSem4 = new javax.swing.JCheckBox();
        chkSem5 = new javax.swing.JCheckBox();
        chkSem6 = new javax.swing.JCheckBox();
        chkSem7 = new javax.swing.JCheckBox();
        pnlMensuel = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        lblTousLes1 = new javax.swing.JLabel();
        txtMois = new javax.swing.JTextField();
        lblMois = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        optMois1 = new javax.swing.JRadioButton();
        txtJourMois = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        optMois2 = new javax.swing.JRadioButton();
        cboWeekMNo = new javax.swing.JComboBox();
        cboWeekDay = new javax.swing.JComboBox();
        pnlAnnuel = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        optAnnuel1 = new javax.swing.JRadioButton();
        txtJourMois1 = new javax.swing.JTextField();
        cboMois1 = new javax.swing.JComboBox();
        jPanel11 = new javax.swing.JPanel();
        optAnnuel2 = new javax.swing.JRadioButton();
        cboWeekMNo1 = new javax.swing.JComboBox();
        cboWeekDay1 = new javax.swing.JComboBox();
        lblSemaine1 = new javax.swing.JLabel();
        cboMois2 = new javax.swing.JComboBox();
        jPanel13 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        optFin1 = new javax.swing.JRadioButton();
        optFin3 = new javax.swing.JRadioButton();
        optFin2 = new javax.swing.JRadioButton();
        jPanel15 = new javax.swing.JPanel();
        pnlFin1 = new javax.swing.JPanel();
        pnlFin3 = new javax.swing.JPanel();
        txtDateFin = new javax.swing.JTextField();
        pnlFin2 = new javax.swing.JPanel();
        txtNbOccurrences = new javax.swing.JTextField();
        lblNbOccurrences = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        lblDateDebut = new javax.swing.JLabel();
        txtDateDebut = new javax.swing.JTextField();
        pnlBoutons = new javax.swing.JPanel();
        chkKeepState = new javax.swing.JCheckBox();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel14.setPreferredSize(new java.awt.Dimension(550, 457));

        jPanel1.setPreferredSize(new java.awt.Dimension(540, 240));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(130, 200));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpSchema.add(optSchema1);
        optSchema1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optSchema1.setSelected(true);
        optSchema1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSchema1ActionPerformed(evt);
            }
        });
        jPanel2.add(optSchema1);

        grpSchema.add(optSchema2);
        optSchema2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optSchema2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSchema2ActionPerformed(evt);
            }
        });
        jPanel2.add(optSchema2);

        grpSchema.add(optSchema3);
        optSchema3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optSchema3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSchema3ActionPerformed(evt);
            }
        });
        jPanel2.add(optSchema3);

        grpSchema.add(optSchema4);
        optSchema4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optSchema4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSchema4ActionPerformed(evt);
            }
        });
        jPanel2.add(optSchema4);

        jPanel1.add(jPanel2, java.awt.BorderLayout.WEST);

        jPanel6.setPreferredSize(new java.awt.Dimension(400, 200));

        pnlJournalier.setPreferredSize(new java.awt.Dimension(400, 200));

        jPanel3.setPreferredSize(new java.awt.Dimension(400, 50));

        lblTousLes.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblTousLes.setOpaque(true);
        jPanel3.add(lblTousLes);

        txtJours.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtJours.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtJours.setPreferredSize(new java.awt.Dimension(60, 22));
        txtJours.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtJoursKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtJoursKeyPressed(evt);
            }
        });
        jPanel3.add(txtJours);

        lblJours.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblJours.setOpaque(true);
        jPanel3.add(lblJours);

        pnlJournalier.add(jPanel3);

        jPanel6.add(pnlJournalier);

        pnlHebdo.setPreferredSize(new java.awt.Dimension(400, 200));

        jPanel7.setPreferredSize(new java.awt.Dimension(400, 50));

        lblToutesLes.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblToutesLes.setOpaque(true);
        jPanel7.add(lblToutesLes);

        txtSemaines.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtSemaines.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSemaines.setPreferredSize(new java.awt.Dimension(60, 22));
        txtSemaines.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSemainesKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSemainesKeyPressed(evt);
            }
        });
        jPanel7.add(txtSemaines);

        lblSemaine.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblSemaine.setOpaque(true);
        jPanel7.add(lblSemaine);

        pnlHebdo.add(jPanel7);

        lblJoursSuivants.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblJoursSuivants.setOpaque(true);
        pnlHebdo.add(lblJoursSuivants);

        jPanel4.setPreferredSize(new java.awt.Dimension(320, 60));

        chkSem1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem1MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem1);

        chkSem2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem2MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem2);

        chkSem3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem3MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem3);

        chkSem4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem4MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem4);

        chkSem5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem5MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem5);

        chkSem6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem6MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem6);

        chkSem7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkSem7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chkSem7MouseClicked(evt);
            }
        });
        jPanel4.add(chkSem7);

        pnlHebdo.add(jPanel4);

        jPanel6.add(pnlHebdo);

        pnlMensuel.setPreferredSize(new java.awt.Dimension(400, 200));

        jPanel9.setPreferredSize(new java.awt.Dimension(400, 50));

        lblTousLes1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblTousLes1.setOpaque(true);
        jPanel9.add(lblTousLes1);

        txtMois.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtMois.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMois.setPreferredSize(new java.awt.Dimension(60, 22));
        txtMois.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtMoisKeyPressed(evt);
            }
        });
        jPanel9.add(txtMois);

        lblMois.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblMois.setOpaque(true);
        jPanel9.add(lblMois);

        pnlMensuel.add(jPanel9);

        jPanel5.setPreferredSize(new java.awt.Dimension(400, 30));
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpMensuel.add(optMois1);
        optMois1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optMois1.setSelected(true);
        optMois1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMois1ActionPerformed(evt);
            }
        });
        jPanel5.add(optMois1);

        txtJourMois.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtJourMois.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtJourMois.setPreferredSize(new java.awt.Dimension(60, 22));
        txtJourMois.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtJourMoisKeyPressed(evt);
            }
        });
        jPanel5.add(txtJourMois);

        pnlMensuel.add(jPanel5);

        jPanel8.setPreferredSize(new java.awt.Dimension(400, 50));
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpMensuel.add(optMois2);
        optMois2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optMois2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMois2ActionPerformed(evt);
            }
        });
        jPanel8.add(optMois2);

        cboWeekMNo.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboWeekMNo.setPreferredSize(new java.awt.Dimension(120, 22));
        cboWeekMNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboWeekMNoActionPerformed(evt);
            }
        });
        cboWeekMNo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboWeekMNoKeyPressed(evt);
            }
        });
        jPanel8.add(cboWeekMNo);

        cboWeekDay.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboWeekDay.setPreferredSize(new java.awt.Dimension(120, 22));
        cboWeekDay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboWeekDayActionPerformed(evt);
            }
        });
        cboWeekDay.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboWeekDayKeyPressed(evt);
            }
        });
        jPanel8.add(cboWeekDay);

        pnlMensuel.add(jPanel8);

        jPanel6.add(pnlMensuel);

        pnlAnnuel.setPreferredSize(new java.awt.Dimension(400, 200));

        jPanel10.setPreferredSize(new java.awt.Dimension(400, 30));
        jPanel10.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpAnnuel.add(optAnnuel1);
        optAnnuel1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optAnnuel1.setSelected(true);
        optAnnuel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAnnuel1ActionPerformed(evt);
            }
        });
        jPanel10.add(optAnnuel1);

        txtJourMois1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtJourMois1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtJourMois1.setPreferredSize(new java.awt.Dimension(60, 22));
        txtJourMois1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtJourMois1KeyPressed(evt);
            }
        });
        jPanel10.add(txtJourMois1);

        cboMois1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboMois1.setMaximumRowCount(15);
        cboMois1.setPreferredSize(new java.awt.Dimension(90, 22));
        cboMois1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboMois1ActionPerformed(evt);
            }
        });
        cboMois1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboMois1KeyPressed(evt);
            }
        });
        jPanel10.add(cboMois1);

        pnlAnnuel.add(jPanel10);

        jPanel11.setPreferredSize(new java.awt.Dimension(400, 50));
        jPanel11.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        grpAnnuel.add(optAnnuel2);
        optAnnuel2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optAnnuel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAnnuel2ActionPerformed(evt);
            }
        });
        jPanel11.add(optAnnuel2);

        cboWeekMNo1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboWeekMNo1.setPreferredSize(new java.awt.Dimension(90, 22));
        cboWeekMNo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboWeekMNo1ActionPerformed(evt);
            }
        });
        jPanel11.add(cboWeekMNo1);

        cboWeekDay1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboWeekDay1.setPreferredSize(new java.awt.Dimension(90, 22));
        cboWeekDay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboWeekDay1ActionPerformed(evt);
            }
        });
        jPanel11.add(cboWeekDay1);

        lblSemaine1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblSemaine1.setOpaque(true);
        jPanel11.add(lblSemaine1);

        cboMois2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboMois2.setMaximumRowCount(15);
        cboMois2.setPreferredSize(new java.awt.Dimension(90, 22));
        cboMois2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboMois2ActionPerformed(evt);
            }
        });
        jPanel11.add(cboMois2);

        pnlAnnuel.add(jPanel11);

        jPanel6.add(pnlAnnuel);

        jPanel1.add(jPanel6, java.awt.BorderLayout.EAST);

        jPanel14.add(jPanel1);

        jPanel13.setPreferredSize(new java.awt.Dimension(540, 160));
        jPanel13.setLayout(new java.awt.BorderLayout());

        jPanel12.setPreferredSize(new java.awt.Dimension(150, 80));

        grpFin.add(optFin1);
        optFin1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optFin1.setPreferredSize(new java.awt.Dimension(140, 23));
        optFin1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optFin1ActionPerformed(evt);
            }
        });
        jPanel12.add(optFin1);

        grpFin.add(optFin3);
        optFin3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optFin3.setSelected(true);
        optFin3.setPreferredSize(new java.awt.Dimension(140, 23));
        optFin3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optFin3ActionPerformed(evt);
            }
        });
        jPanel12.add(optFin3);

        grpFin.add(optFin2);
        optFin2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        optFin2.setPreferredSize(new java.awt.Dimension(140, 23));
        optFin2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optFin2ActionPerformed(evt);
            }
        });
        jPanel12.add(optFin2);

        jPanel13.add(jPanel12, java.awt.BorderLayout.WEST);

        pnlFin1.setPreferredSize(new java.awt.Dimension(358, 143));

        javax.swing.GroupLayout pnlFin1Layout = new javax.swing.GroupLayout(pnlFin1);
        pnlFin1.setLayout(pnlFin1Layout);
        pnlFin1Layout.setHorizontalGroup(
            pnlFin1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 358, Short.MAX_VALUE)
        );
        pnlFin1Layout.setVerticalGroup(
            pnlFin1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 143, Short.MAX_VALUE)
        );

        jPanel15.add(pnlFin1);

        pnlFin3.setPreferredSize(new java.awt.Dimension(358, 143));
        pnlFin3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        txtDateFin.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDateFin.setName(""); // NOI18N
        txtDateFin.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateFin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateFinMousePressed(evt);
            }
        });
        txtDateFin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateFinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateFinKeyTyped(evt);
            }
        });
        pnlFin3.add(txtDateFin);

        jPanel15.add(pnlFin3);

        pnlFin2.setPreferredSize(new java.awt.Dimension(358, 143));
        pnlFin2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        txtNbOccurrences.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtNbOccurrences.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNbOccurrences.setText("10");
        txtNbOccurrences.setPreferredSize(new java.awt.Dimension(60, 22));
        txtNbOccurrences.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNbOccurrencesKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNbOccurrencesKeyPressed(evt);
            }
        });
        pnlFin2.add(txtNbOccurrences);

        lblNbOccurrences.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblNbOccurrences.setOpaque(true);
        pnlFin2.add(lblNbOccurrences);

        jPanel15.add(pnlFin2);

        jPanel13.add(jPanel15, java.awt.BorderLayout.CENTER);

        jPanel16.setPreferredSize(new java.awt.Dimension(528, 40));
        jPanel16.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        lblDateDebut.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateDebut.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateDebut.setOpaque(true);
        lblDateDebut.setPreferredSize(new java.awt.Dimension(100, 22));
        jPanel16.add(lblDateDebut);

        txtDateDebut.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDateDebut.setName(""); // NOI18N
        txtDateDebut.setPreferredSize(new java.awt.Dimension(90, 22));
        txtDateDebut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDateDebutMousePressed(evt);
            }
        });
        txtDateDebut.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDateDebutKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDateDebutKeyTyped(evt);
            }
        });
        jPanel16.add(txtDateDebut);

        jPanel13.add(jPanel16, java.awt.BorderLayout.NORTH);

        jPanel14.add(jPanel13);

        pnlBoutons.setPreferredSize(new java.awt.Dimension(540, 42));

        chkKeepState.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        pnlBoutons.add(chkKeepState);

        btnOK.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOK.setPreferredSize(new java.awt.Dimension(160, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(160, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        jPanel14.add(pnlBoutons);

        getContentPane().add(jPanel14, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void optSchema1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSchema1ActionPerformed
    {//GEN-HEADEREND:event_optSchema1ActionPerformed
        if (bSetting)
            return;
        if (optSchema1.isSelected())
        {
            pnlJournalier.setVisible(true);
            pnlHebdo.setVisible(false);
            pnlMensuel.setVisible(false);
            pnlAnnuel.setVisible(false);
            
            txtSemaines.setText("");
            txtMois.setText("");
            txtJourMois.setText("");
            cboWeekMNo.setSelectedIndex(-1);
            cboWeekDay.setSelectedIndex(-1);
            cboWeekMNo1.setSelectedIndex(-1);
            cboWeekDay1.setSelectedIndex(-1);
            cboMois2.setSelectedIndex(-1);
            txtJourMois1.setText("");
            cboMois1.setSelectedIndex(-1);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optSchema1ActionPerformed

    private void optSchema2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSchema2ActionPerformed
    {//GEN-HEADEREND:event_optSchema2ActionPerformed
        if (bSetting)
            return;
        if (optSchema2.isSelected())
        {
            pnlJournalier.setVisible(false);
            pnlHebdo.setVisible(true);
            pnlMensuel.setVisible(false);
            pnlAnnuel.setVisible(false);
            
            txtJours.setText("");
            txtMois.setText("");
            txtJourMois.setText("");
            cboWeekMNo.setSelectedIndex(-1);
            cboWeekDay.setSelectedIndex(-1);
            cboWeekMNo1.setSelectedIndex(-1);
            cboWeekDay1.setSelectedIndex(-1);
            cboMois2.setSelectedIndex(-1);
            txtJourMois1.setText("");
            cboMois1.setSelectedIndex(-1);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optSchema2ActionPerformed

    private void optSchema3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSchema3ActionPerformed
    {//GEN-HEADEREND:event_optSchema3ActionPerformed
        if (bSetting)
            return;
        if (optSchema3.isSelected())
        {
            pnlJournalier.setVisible(false);
            pnlHebdo.setVisible(false);
            pnlMensuel.setVisible(true);
            pnlAnnuel.setVisible(false);
            cboWeekMNo1.setSelectedIndex(-1);
            
            txtJours.setText("");
            txtSemaines.setText("");
            cboWeekMNo1.setSelectedIndex(-1);
            cboWeekDay1.setSelectedIndex(-1);
            cboMois2.setSelectedIndex(-1);
            txtJourMois1.setText("");
            cboMois1.setSelectedIndex(-1);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optSchema3ActionPerformed

    private void optSchema4ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSchema4ActionPerformed
    {//GEN-HEADEREND:event_optSchema4ActionPerformed
        if (bSetting)
            return;
        if (optSchema4.isSelected())
        {
            pnlJournalier.setVisible(false);
            pnlHebdo.setVisible(false);
            pnlMensuel.setVisible(false);
            pnlAnnuel.setVisible(true);
            
            txtJours.setText("");
            txtSemaines.setText("");
            txtMois.setText("");
            txtJourMois.setText("");
            cboWeekMNo.setSelectedIndex(-1);
            cboWeekDay.setSelectedIndex(-1);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optSchema4ActionPerformed

    private void txtDateFinMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateFinMousePressed
    {//GEN-HEADEREND:event_txtDateFinMousePressed
        if (evt.getButton() == 1)
        {
            String sdate = txtDateFin.getText();
            datefin = DlgCalendar.ShowCalendar(sdate);
            datefin = MainClass.getFormatedDate(datefin);
            txtDateFin.setText(datefin);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateFinMousePressed

    private void txtDateFinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateFinKeyPressed
    {//GEN-HEADEREND:event_txtDateFinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateFin.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateFin.setText(datefin);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDate(evt, txtDateFin, kc);
        }
    }//GEN-LAST:event_txtDateFinKeyPressed

    private void txtDateFinKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateFinKeyTyped
    {//GEN-HEADEREND:event_txtDateFinKeyTyped
        KTDate d = new KTDate(evt, txtDateFin, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateFin.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateFinKeyTyped

    private void optFin1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optFin1ActionPerformed
    {//GEN-HEADEREND:event_optFin1ActionPerformed
        if (bSetting)
            return;
        if (optFin1.isSelected())
        {
            pnlFin1.setVisible(true);
            pnlFin2.setVisible(false);
            pnlFin3.setVisible(false);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optFin1ActionPerformed

    private void optFin2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optFin2ActionPerformed
    {//GEN-HEADEREND:event_optFin2ActionPerformed
        if (bSetting)
            return;
        if (optFin2.isSelected())
        {
            pnlFin1.setVisible(false);
            pnlFin2.setVisible(true);
            pnlFin3.setVisible(false);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optFin2ActionPerformed

    private void optFin3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optFin3ActionPerformed
    {//GEN-HEADEREND:event_optFin3ActionPerformed
        if (bSetting)
            return;
        if (optFin3.isSelected())
        {
            pnlFin1.setVisible(false);
            pnlFin2.setVisible(false);
            pnlFin3.setVisible(true);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_optFin3ActionPerformed

    private void txtDateDebutMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateDebutMousePressed
    {//GEN-HEADEREND:event_txtDateDebutMousePressed
        if (evt.getButton() == 1)
        {
            String sdate = txtDateDebut.getText();
            datedebut = DlgCalendar.ShowCalendar(sdate);
            datedebut = MainClass.getFormatedDate(datedebut);
            txtDateDebut.setText(datedebut);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateDebutMousePressed

    private void txtDateDebutKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateDebutKeyPressed
    {//GEN-HEADEREND:event_txtDateDebutKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateDebut.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateDebut.setText(datedebut);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDate(evt, txtDateDebut, kc);
        }
    }//GEN-LAST:event_txtDateDebutKeyPressed

    private void txtDateDebutKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateDebutKeyTyped
    {//GEN-HEADEREND:event_txtDateDebutKeyTyped
        KTDate d = new KTDate(evt, txtDateDebut, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateDebut.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateDebutKeyTyped

    private void optMois1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMois1ActionPerformed
    {//GEN-HEADEREND:event_optMois1ActionPerformed
        if (bSetting)
            return;
        bSetting = true;
        cboWeekMNo.setSelectedIndex(-1);
        cboWeekDay.setSelectedIndex(-1);
        bSetting = false;
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_optMois1ActionPerformed

    private void optMois2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMois2ActionPerformed
    {//GEN-HEADEREND:event_optMois2ActionPerformed
        if (bSetting)
            return;
        txtJourMois.setText("");
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_optMois2ActionPerformed

    private void optAnnuel1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAnnuel1ActionPerformed
    {//GEN-HEADEREND:event_optAnnuel1ActionPerformed
        if (bSetting)
            return;
        bSetting = true;
        cboWeekMNo1.setSelectedIndex(-1);
        cboWeekDay1.setSelectedIndex(-1);
        cboMois2.setSelectedIndex(-1);
        bSetting = false;
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_optAnnuel1ActionPerformed

    private void optAnnuel2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAnnuel2ActionPerformed
    {//GEN-HEADEREND:event_optAnnuel2ActionPerformed
        if (bSetting)
            return;
        txtJourMois1.setText("");
        bSetting = true;
        cboMois1.setSelectedIndex(-1);
        bSetting = false;
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_optAnnuel2ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave() == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_formWindowClosing

    private void txtNbOccurrencesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNbOccurrencesKeyPressed
    {//GEN-HEADEREND:event_txtNbOccurrencesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtNbOccurrences.setText(nbmaxrecur);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtNbOccurrencesKeyPressed

    private void txtNbOccurrencesKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNbOccurrencesKeyTyped
    {//GEN-HEADEREND:event_txtNbOccurrencesKeyTyped
        KTUnsignedInteger kti = new KTUnsignedInteger(evt, txtNbOccurrences, 3, kc);
    }//GEN-LAST:event_txtNbOccurrencesKeyTyped

    private void txtJoursKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJoursKeyPressed
    {//GEN-HEADEREND:event_txtJoursKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtJours.setText(nb_recur);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtJoursKeyPressed

    private void txtJoursKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJoursKeyTyped
    {//GEN-HEADEREND:event_txtJoursKeyTyped
        KTUnsignedInteger kti = new KTUnsignedInteger(evt, txtJours, 1, kc);
    }//GEN-LAST:event_txtJoursKeyTyped

    private void txtSemainesKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemainesKeyPressed
    {//GEN-HEADEREND:event_txtSemainesKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtSemaines.setText(nb_recur);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtSemainesKeyPressed

    private void txtSemainesKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemainesKeyTyped
    {//GEN-HEADEREND:event_txtSemainesKeyTyped
        KTUnsignedInteger kti = new KTUnsignedInteger(evt, txtSemaines, 1, kc);
    }//GEN-LAST:event_txtSemainesKeyTyped

    private void chkSem1MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem1MouseClicked
    {//GEN-HEADEREND:event_chkSem1MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem1MouseClicked

    private void chkSem2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem2MouseClicked
    {//GEN-HEADEREND:event_chkSem2MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem2MouseClicked

    private void chkSem3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem3MouseClicked
    {//GEN-HEADEREND:event_chkSem3MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem3MouseClicked

    private void chkSem4MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem4MouseClicked
    {//GEN-HEADEREND:event_chkSem4MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem4MouseClicked

    private void chkSem5MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem5MouseClicked
    {//GEN-HEADEREND:event_chkSem5MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem5MouseClicked

    private void chkSem6MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem6MouseClicked
    {//GEN-HEADEREND:event_chkSem6MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem6MouseClicked

    private void chkSem7MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_chkSem7MouseClicked
    {//GEN-HEADEREND:event_chkSem7MouseClicked
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_chkSem7MouseClicked

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKActionPerformed

    private void txtJourMoisKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJourMoisKeyPressed
    {//GEN-HEADEREND:event_txtJourMoisKeyPressed
        bolEditing = true;
        setEditMode();
        bSetting = true;
        optMois1.setSelected(true);
        bSetting = false;
    }//GEN-LAST:event_txtJourMoisKeyPressed

    private void cboWeekMNoKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_cboWeekMNoKeyPressed
    {//GEN-HEADEREND:event_cboWeekMNoKeyPressed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optMois2.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboWeekMNoKeyPressed

    private void cboWeekDayKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_cboWeekDayKeyPressed
    {//GEN-HEADEREND:event_cboWeekDayKeyPressed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optMois2.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboWeekDayKeyPressed

    private void txtJourMois1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtJourMois1KeyPressed
    {//GEN-HEADEREND:event_txtJourMois1KeyPressed
        bolEditing = true;
        setEditMode();
        bSetting = true;
        optAnnuel1.setSelected(true);
        bSetting = false;
    }//GEN-LAST:event_txtJourMois1KeyPressed

    private void cboMois1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_cboMois1KeyPressed
    {//GEN-HEADEREND:event_cboMois1KeyPressed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optAnnuel1.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboMois1KeyPressed

    private void cboMois1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboMois1ActionPerformed
    {//GEN-HEADEREND:event_cboMois1ActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optAnnuel1.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboMois1ActionPerformed

    private void cboWeekMNo1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboWeekMNo1ActionPerformed
    {//GEN-HEADEREND:event_cboWeekMNo1ActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optAnnuel2.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboWeekMNo1ActionPerformed

    private void cboWeekDay1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboWeekDay1ActionPerformed
    {//GEN-HEADEREND:event_cboWeekDay1ActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optAnnuel2.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboWeekDay1ActionPerformed

    private void cboMois2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboMois2ActionPerformed
    {//GEN-HEADEREND:event_cboMois2ActionPerformed
        if (!bSetting)
        {
            bolEditing = true;
            setEditMode();
            bSetting = true;
            optAnnuel2.setSelected(true);
            bSetting = false;
        }
    }//GEN-LAST:event_cboMois2ActionPerformed

    private void txtMoisKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtMoisKeyPressed
    {//GEN-HEADEREND:event_txtMoisKeyPressed
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtMoisKeyPressed

    private void cboWeekMNoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboWeekMNoActionPerformed
    {//GEN-HEADEREND:event_cboWeekMNoActionPerformed
        if (bSetting)
            return;
        optMois2.setSelected(true);
    }//GEN-LAST:event_cboWeekMNoActionPerformed

    private void cboWeekDayActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboWeekDayActionPerformed
    {//GEN-HEADEREND:event_cboWeekDayActionPerformed
        if (bSetting)
            return;
        optMois2.setSelected(true);
    }//GEN-LAST:event_cboWeekDayActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JComboBox cboMois1;
    private javax.swing.JComboBox cboMois2;
    private javax.swing.JComboBox cboWeekDay;
    private javax.swing.JComboBox cboWeekDay1;
    private javax.swing.JComboBox cboWeekMNo;
    private javax.swing.JComboBox cboWeekMNo1;
    private javax.swing.JCheckBox chkKeepState;
    private javax.swing.JCheckBox chkSem1;
    private javax.swing.JCheckBox chkSem2;
    private javax.swing.JCheckBox chkSem3;
    private javax.swing.JCheckBox chkSem4;
    private javax.swing.JCheckBox chkSem5;
    private javax.swing.JCheckBox chkSem6;
    private javax.swing.JCheckBox chkSem7;
    private javax.swing.ButtonGroup grpAnnuel;
    private javax.swing.ButtonGroup grpFin;
    private javax.swing.ButtonGroup grpMensuel;
    private javax.swing.ButtonGroup grpSchema;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblDateDebut;
    private javax.swing.JLabel lblJours;
    private javax.swing.JLabel lblJoursSuivants;
    private javax.swing.JLabel lblMois;
    private javax.swing.JLabel lblNbOccurrences;
    private javax.swing.JLabel lblSemaine;
    private javax.swing.JLabel lblSemaine1;
    private javax.swing.JLabel lblTousLes;
    private javax.swing.JLabel lblTousLes1;
    private javax.swing.JLabel lblToutesLes;
    private javax.swing.JRadioButton optAnnuel1;
    private javax.swing.JRadioButton optAnnuel2;
    private javax.swing.JRadioButton optFin1;
    private javax.swing.JRadioButton optFin2;
    private javax.swing.JRadioButton optFin3;
    private javax.swing.JRadioButton optMois1;
    private javax.swing.JRadioButton optMois2;
    private javax.swing.JRadioButton optSchema1;
    private javax.swing.JRadioButton optSchema2;
    private javax.swing.JRadioButton optSchema3;
    private javax.swing.JRadioButton optSchema4;
    private javax.swing.JPanel pnlAnnuel;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlFin1;
    private javax.swing.JPanel pnlFin2;
    private javax.swing.JPanel pnlFin3;
    private javax.swing.JPanel pnlHebdo;
    private javax.swing.JPanel pnlJournalier;
    private javax.swing.JPanel pnlMensuel;
    private javax.swing.JTextField txtDateDebut;
    private javax.swing.JTextField txtDateFin;
    private javax.swing.JTextField txtJourMois;
    private javax.swing.JTextField txtJourMois1;
    private javax.swing.JTextField txtJours;
    private javax.swing.JTextField txtMois;
    private javax.swing.JTextField txtNbOccurrences;
    private javax.swing.JTextField txtSemaines;
    // End of variables declaration//GEN-END:variables
}
