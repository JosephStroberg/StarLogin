package StarLogin.IHM;

import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import javax.swing.JScrollPane;


/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public abstract class ChartSurface extends JScrollPane implements Printable
{
    public Object antiAlias = RenderingHints.VALUE_ANTIALIAS_ON;
    public Object rendering = RenderingHints.VALUE_RENDER_QUALITY;
    public Paint texture;
    private double zoom;
    private int vCenterValue;
    private int hCenterValue;
    private int vScrollValue;
    private int hScrollValue;
    private ChartSurface surface;
    private boolean bSettingZoom = false;
    private boolean bScrolling = false;
    private boolean bResizing = false;
    private boolean bResetting = false;
    private double oldWidth=0.0;
    private double oldHeight=0.0;
    private double hRatio = 0.5;
    private double wRatio = 0.5;
    private ChartSurface current = this;
    
    public ChartSurface()
    {
        setAutoscrolls(false);
        setDoubleBuffered(true);
        setBorder(null);
        surface = current;
        setPreferredSize(new Dimension(1024,768));
        setBackground(Color.white);
        setVerticalScrollBar(createVerticalScrollBar());
        setHorizontalScrollBar(createHorizontalScrollBar());
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        getVerticalScrollBar().setMinimum(0);
        getHorizontalScrollBar().setMinimum(0);
        setWheelScrollingEnabled(true);

        getVerticalScrollBar().addAdjustmentListener(new java.awt.event.AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt)
            {
                bScrolling = true;
                Dimension d = getSize();
                double h = d.getHeight();
                setScrolls();
                if ((h == oldHeight) && (bSettingZoom == false) && (bResizing == false) && (bResetting == false))
                {
                    surface.repaint();
                }
                bScrolling = false;
            }
        });
        
        getHorizontalScrollBar().addAdjustmentListener(new java.awt.event.AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt)
            {
                bScrolling = true;
                Dimension d = getSize();
                double w = d.getWidth();
                setScrolls();
                if ((w == oldWidth) && (bSettingZoom == false) && (bResizing == false) && (bResetting == false))
                {
                    surface.repaint();
                }
                bScrolling = false;
            }
        });
        
        addComponentListener(new java.awt.event.ComponentAdapter()
        {
            @Override
            public void componentResized(java.awt.event.ComponentEvent evt)
            {
                bResizing = true;
                setScrolls();
            }
        });
        
        getVerticalScrollBar().setVisible(false);
        getHorizontalScrollBar().setVisible(false);
    }
    
    public void setZoom(double data)
    {
        zoom = data;
        bSettingZoom = true;
        setScrolls();
        bSettingZoom = false;
    }
    
    private void setScrolls()
    {
        Dimension d = getSize();
        double w = d.getWidth();
        double h = d.getHeight();
        if (zoom > 1.0)
        {
            vCenterValue = (int)(h*(zoom-1.0)/2.0);
            hCenterValue = (int)(w*(zoom-1.0)/2.0);
            if (bScrolling == false)
            {
                getVerticalScrollBar().setMaximum((int)(h*zoom));
                getVerticalScrollBar().setVisibleAmount((int)h);
                getHorizontalScrollBar().setMaximum((int)(w*zoom));
                getHorizontalScrollBar().setVisibleAmount((int)w);
            }
            if (bSettingZoom == true)
            {
                getVerticalScrollBar().setValue(vCenterValue);
                getHorizontalScrollBar().setValue(hCenterValue);
            }
            else if (bResizing == true)
            {
                getVerticalScrollBar().setValue((int)((double)getVerticalScrollBar().getMaximum() * wRatio));
                getHorizontalScrollBar().setValue((int)((double)getHorizontalScrollBar().getMaximum() * hRatio));
                bResizing = false;
            }
            vScrollValue = getVerticalScrollBar().getValue();
            hScrollValue = getHorizontalScrollBar().getValue();
            getVerticalScrollBar().setVisible(true);
            getHorizontalScrollBar().setVisible(true);
            hRatio = (double)vScrollValue/(double)getVerticalScrollBar().getMaximum();
            wRatio = (double)hScrollValue/(double)getHorizontalScrollBar().getMaximum();
        }
        else
        {
            vCenterValue = 0;
            hCenterValue = 0;
            vScrollValue = 0;
            hScrollValue = 0;
            bResetting = true;
            getVerticalScrollBar().setVisible(false);
            getHorizontalScrollBar().setVisible(false);
            bResetting = false;
        }
        oldHeight = h;
        oldWidth = w;
    }
    
    public void setAntiAlias(boolean data)
    {
        if (data == true)
        {
            antiAlias = RenderingHints.VALUE_ANTIALIAS_ON;
        }
        else
        {
            antiAlias = RenderingHints.VALUE_ANTIALIAS_OFF;
        }
    }
    
    public void setRendering(boolean data)
    {
        if (data == true)
        {
            rendering = RenderingHints.VALUE_RENDER_QUALITY;
        }
        else
        {
            rendering = RenderingHints.VALUE_RENDER_SPEED;
        }
    }
    
    public void setTexture(Object obj)
    {
        if (obj instanceof GradientPaint)
        {
            texture = new GradientPaint(0, 0, Color.white,
            getSize().width*2, 0, Color.green);
        } else
        {
            texture = (Paint) obj;
        }
    }
    
    public Graphics2D createGraphics2D(int width, int height, Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAlias);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, rendering);
        g2.clearRect(0, 0, width, height);
        
        if (texture != null)
        {
            // set composite to opaque for texture fills
            g2.setComposite(AlphaComposite.SrcOver);
            g2.setPaint(texture);
            g2.fillRect(0, 0, width, height);
        }
        
        return g2;
    }
    
    // classes that extend Surface must implement this routine
    public abstract void render(int w, int h, Graphics2D g2, int x, int y);
    
    public void reFresh()
    {
        this.repaint();
    }
    
    @Override
    public void paint(Graphics g)
    {
        Dimension d = getSize();
        Graphics2D g2 = createGraphics2D(d.width, d.height, g);
        render((int)d.getWidth(), (int)d.getHeight(), g2, hScrollValue - hCenterValue, vScrollValue - vCenterValue);
        g2.dispose();
        if (getVerticalScrollBar().isVisible())
        {
            getVerticalScrollBar().paintImmediately(getVerticalScrollBar().getBounds());
            getVerticalScrollBar().paintAll(getVerticalScrollBar().getGraphics());
        }
        if (getHorizontalScrollBar().isVisible())
        {
            getHorizontalScrollBar().paintImmediately(getHorizontalScrollBar().getBounds());
            getHorizontalScrollBar().paintAll(getHorizontalScrollBar().getGraphics());
        }
        bSettingZoom = false;
    }
    
    @Override
    public int print(Graphics g, PageFormat pf, int pi) throws PrinterException
    {
        if (pi >= 1)
        {
            return Printable.NO_SUCH_PAGE;
        }
        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pf.getImageableX(), pf.getImageableY());
        g2d.translate(pf.getImageableWidth() / 2, pf.getImageableHeight() / 2);
        
        Dimension d = getSize();
        
        double scale = Math.min(pf.getImageableWidth() / d.width, pf.getImageableHeight() / d.height);
        if (scale < 1.01)
        {
            g2d.scale(scale, scale);
        }
        g2d.translate(-d.width / 2.0, -d.height / 2.0);
        
        Graphics2D g2 = createGraphics2D(d.width, d.height, g2d);
        render((int)d.getWidth(), (int)d.getHeight(), g2, hScrollValue - hCenterValue, vScrollValue - vCenterValue);
        g2.dispose();
        
        return Printable.PAGE_EXISTS;
    }
}
