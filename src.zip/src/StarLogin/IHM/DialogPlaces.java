/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FLatitude;
import StarLogin.Systeme.AstroCalc.FLongitude;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.Cursor;
import java.awt.Rectangle;
import java.awt.Window;
import javax.swing.JTable;

/**
 *
 * @author Francois
 */
public class DialogPlaces extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager;
    private Window parentForm;
    private java.util.ResourceBundle bundle;
    private String sQuery = "SELECT ID,PLACENAME,PLACELATITUDE,PLACELONGITUDE FROM places ";
    private String recordID;
    
    private Record record;
    private DataBaseRecord dbr;
    private boolean bolRecordAdding = false;
    public boolean bolClickFromGrid = false;
    private DataGrid drgGrid;
    private String classname = this.getClass().getName();
    private Records records;
    private int selectedRow;
    private boolean bdelete = false;
    
    /**
     * Creates new form DialogTaxes
     */
    public DialogPlaces(java.awt.Frame parent, boolean modal, String placeid)
    {
        super(parent, modal);
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;
        bundle = MainClass.bundle;
        initComponents();
        parentForm = (Window) parent;
        
        int pos = classname.lastIndexOf(".");
        if (pos > 0)
        {
            classname = classname.substring(pos + 1);
        }
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        recordID = placeid;// starLoginManager.getStringFieldValue("places", "MIN(ID)", "");
        refreshRecord();
        selectedRow = records.getRowFromID(recordID);
        showRecord(selectedRow);
        resetLangue();
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setVisible(true);
    }
    
    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    public boolean save(int row, int col, String value)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        //update data
        recordID = records.getIDFromRow(row);
        if (Integer.valueOf(recordID) < 0)
            bolRecordAdding = true;
        
        if (bolRecordAdding)
        {
            addRecord();
        }
        else
        {
            record.setAdding(bolRecordAdding);
            record.setId(recordID);
            record.setData(col, value);
            starLoginManager.setRecord(record, dbr);
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }

    public void addRecord()
    {
        FLatitude flat = new FLatitude(" 00�00'00\"");
        String lat = flat.getLatitude();
        lat = MainClass.replaceQuotes(lat);
        FLongitude flong = new FLongitude(" 000�00'00\"");
        String lng = flong.getLongitude();
        lng = MainClass.replaceQuotes(lng);
        starLoginManager.updateDataBase("INSERT INTO places(PLACENAME,PLACELATITUDE,PLACELONGITUDE) VALUES(' ','" + lat + "','" + lng + "')");
        refreshRecord();
        pnlGrid.paintAll(pnlGrid.getGraphics());
        recordID = starLoginManager.getStringFieldValue("places", "MAX(ID)", "");
        selectedRow = records.getRowFromID(recordID);
        showRecord(selectedRow);
        bolRecordAdding = false;
    }
    
    public void removeFromGrid(int grdRow)
    {
        String id = records.getIDFromRow(grdRow);
        starLoginManager.removeRecord(id, "places");
        bdelete = true;
    }
    
    public void setRow()
    {
        refreshRecord();
        selectedRow = MainClass.getCurrentRow(records, selectedRow);
        showRecord(selectedRow);
    }
    
    private void refreshRecord()
    {
        records = starLoginManager.getRecords(sQuery + " ORDER BY PLACENAME", "places");
        drgGrid = new DataGrid(records.getRecords(), records.getHeaders(), records.getFields(), records.getSizes(), pnlGrid, false, false, true, true, this, true, 40);
        //pnlGrid.paintImmediately(pnlGrid.getBounds());
        if (bdelete)
            pnlGrid.paintAll(pnlGrid.getGraphics());
        bdelete = false;
    }
    
    public final void showRecord(int row)
    {
        selectedRow = row;
        if (bolClickFromGrid == false)
            drgGrid.setSelectedRow(selectedRow);
        else
            bolClickFromGrid = false;
        recordID = records.getIDFromRow(selectedRow);
        record = starLoginManager.getRecord(sQuery + " WHERE ID=" + recordID, "places", "");
        dbr = starLoginManager.getDBRecord();
    }
    
    private void resetLangue()
    {
        setTitle(bundle.getString("Places"));
        btnRemove.setText(bundle.getString("Remove"));
        btnRemove.setToolTipText(bundle.getString("RemoveSelection"));
        btnAdd.setText(bundle.getString("Add"));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnRemove = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        pnlGrid = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(160, 100));

        btnRemove.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnRemove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemove.setPreferredSize(new java.awt.Dimension(150, 32));
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        jPanel2.add(btnRemove);

        btnAdd.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAdd.setPreferredSize(new java.awt.Dimension(150, 32));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel2.add(btnAdd);

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(jPanel1, java.awt.BorderLayout.EAST);

        pnlGrid.setPreferredSize(new java.awt.Dimension(709, 506));

        javax.swing.GroupLayout pnlGridLayout = new javax.swing.GroupLayout(pnlGrid);
        pnlGrid.setLayout(pnlGridLayout);
        pnlGridLayout.setHorizontalGroup(
            pnlGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 609, Short.MAX_VALUE)
        );
        pnlGridLayout.setVerticalGroup(
            pnlGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 506, Short.MAX_VALUE)
        );

        getContentPane().add(pnlGrid, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveActionPerformed
    {//GEN-HEADEREND:event_btnRemoveActionPerformed
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        JTable tbl = drgGrid.getTable();
        int row[] = tbl.getSelectedRows();
        {
            for (int i = 0; i < tbl.getSelectedRowCount(); i++)
            {
                //removeFromGrid(row[i] + 1);
                recordID = null2String(tbl.getValueAt(row[i], 0));
                if (!recordID.equals("-1"))
                {
                    starLoginManager.updateDataBase("DELETE FROM places WHERE ID=" + recordID);                    
                }
            }
        }
        bdelete = true;
        setRow();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = 0;
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");    
    }//GEN-LAST:event_formWindowClosing

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddActionPerformed
    {//GEN-HEADEREND:event_btnAddActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnRemove;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel pnlGrid;
    // End of variables declaration//GEN-END:variables
}
