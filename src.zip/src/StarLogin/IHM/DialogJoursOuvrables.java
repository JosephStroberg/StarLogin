/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTTime;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Records;
import java.awt.Cursor;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author Francois
 */
public class DialogJoursOuvrables extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager;
    private Records joursouvrables;
    private String sQuery = "SELECT ID,DEBUT,FIN FROM joursouvrables";
    private boolean bolEditing = false;
    private java.util.ResourceBundle bundle;
    private String hdebut1;
    private String hfin1;
    private String hdebut2;
    private String hfin2;
    private String hdebut3;
    private String hfin3;
    private String hdebut4;
    private String hfin4;
    private String hdebut5;
    private String hfin5;
    private String hdebut6;
    private String hfin6;
    private String hdebut7;
    private String hfin7;
    private int kc; //key code
    private int cp; //caret position


    /**
     * Creates new form DialogRdv
     */
    public DialogJoursOuvrables(java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;

        bundle = MainClass.bundle;
        initComponents();
        resetLangue();

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        refreshRecord();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        this.setVisible(true);
    }
    
    private boolean save()
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        if (bolEditing == true)
        {
            setTextToData();
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut1 + "',FIN='" + hfin1 + "' WHERE ID=1");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut2 + "',FIN='" + hfin2 + "' WHERE ID=2");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut3 + "',FIN='" + hfin3 + "' WHERE ID=3");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut4 + "',FIN='" + hfin4 + "' WHERE ID=4");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut5 + "',FIN='" + hfin5 + "' WHERE ID=5");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut6 + "',FIN='" + hfin6 + "' WHERE ID=6");
            starLoginManager.updateDataBase("UPDATE JOURSOUVRABLES SET DEBUT='" + hdebut7 + "',FIN='" + hfin7 + "' WHERE ID=7");
            bolEditing = false;
            refreshGrids();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    private void refreshGrids()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof GestionTempsForm)
            {
                ((GestionTempsForm)windows[i]).setTblDaysColors(true);
            }
        }
    }
    
    private int askToSave()
    {
        int result = JOptionPane.NO_OPTION;
        if (bolEditing)
        {
            if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),this.getTitle(),JOptionPane.YES_NO_OPTION);
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void refreshRecord()
    {
        joursouvrables = starLoginManager.getRecords(sQuery + "", "joursouvrables");
        ArrayList jo = joursouvrables.getRecords();
        ArrayList jour = (ArrayList)jo.get(0);
        hdebut1 = null2String(jour.get(1));
        hfin1 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(1);
        hdebut2 = null2String(jour.get(1));
        hfin2 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(2);
        hdebut3 = null2String(jour.get(1));
        hfin3 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(3);
        hdebut4 = null2String(jour.get(1));
        hfin4 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(4);
        hdebut5 = null2String(jour.get(1));
        hfin5 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(4);
        hdebut6 = null2String(jour.get(1));
        hfin6 = null2String(jour.get(2));
        jour = (ArrayList)jo.get(6);
        hdebut7 = null2String(jour.get(1));
        hfin7 = null2String(jour.get(2));
        setDataToText();
    }

    private String null2String(Object object)
    {
        String result;
        if (object == null)
        {
            result = MainClass.STIME_000000;
        }
        else
        {
            result = object.toString();
            if (result.equals(""))
                result = MainClass.STIME_000000;
        }
        return result;
    }

    private void setTextToData()
    {
        hdebut1 = txtHeureMin1.getText();
        hfin1 = txtHeureMax1.getText();
        hdebut1 = FTime.set24(hdebut1);
        hfin1 = FTime.set24(hfin1);
        hdebut2 = txtHeureMin2.getText();
        hfin2 = txtHeureMax2.getText();
        hdebut2 = FTime.set24(hdebut2);
        hfin2 = FTime.set24(hfin2);
        hdebut3 = txtHeureMin3.getText();
        hfin3 = txtHeureMax3.getText();
        hdebut3 = FTime.set24(hdebut3);
        hfin3 = FTime.set24(hfin3);
        hdebut4 = txtHeureMin4.getText();
        hfin4 = txtHeureMax4.getText();
        hdebut4 = FTime.set24(hdebut4);
        hfin4 = FTime.set24(hfin4);
        hdebut5 = txtHeureMin5.getText();
        hfin5 = txtHeureMax5.getText();
        hdebut5 = FTime.set24(hdebut5);
        hfin5 = FTime.set24(hfin5);
        hdebut6 = txtHeureMin6.getText();
        hfin6 = txtHeureMax6.getText();
        hdebut6 = FTime.set24(hdebut6);
        hfin6 = FTime.set24(hfin6);
        hdebut7 = txtHeureMin7.getText();
        hfin7 = txtHeureMax7.getText();
        hdebut7 = FTime.set24(hdebut7);
        hfin7 = FTime.set24(hfin7);
    }
    
    private void resetLangue()
    {
        setTitle(bundle.getString("JoursOuvrables"));
        btnOK.setText(bundle.getString("Valider"));
        btnCancel.setText(bundle.getString("Cancel"));
        lblDateMin1.setText(bundle.getString("De"));
        lblDateMax1.setText(bundle.getString("to"));
        chkDay1.setText(bundle.getString("Sunday"));
        lblDateMin2.setText(bundle.getString("De"));
        lblDateMax2.setText(bundle.getString("to"));
        chkDay2.setText(bundle.getString("Monday"));
        lblDateMin3.setText(bundle.getString("De"));
        lblDateMax3.setText(bundle.getString("to"));
        chkDay3.setText(bundle.getString("Tuesday"));
        lblDateMin4.setText(bundle.getString("De"));
        lblDateMax4.setText(bundle.getString("to"));
        chkDay4.setText(bundle.getString("Wednesday"));
        lblDateMin5.setText(bundle.getString("De"));
        lblDateMax5.setText(bundle.getString("to"));
        chkDay5.setText(bundle.getString("Thursday"));
        lblDateMin6.setText(bundle.getString("De"));
        lblDateMax6.setText(bundle.getString("to"));
        chkDay6.setText(bundle.getString("Friday"));
        lblDateMin7.setText(bundle.getString("De"));
        lblDateMax7.setText(bundle.getString("to"));
        chkDay7.setText(bundle.getString("Saturday"));
    }

    private void setDataToText()
    {
        if (hdebut1.equals(MainClass.STIME_000000) && hfin1.equals(MainClass.STIME_000000))
        {
            txtHeureMin1.setVisible(false);
            txtHeureMax1.setVisible(false);
            chkDay1.setSelected(false);
        }
        else
            chkDay1.setSelected(true);
        if (hdebut2.equals(MainClass.STIME_000000) && hfin2.equals(MainClass.STIME_000000))
        {
            txtHeureMin2.setVisible(false);
            txtHeureMax2.setVisible(false);
            chkDay2.setSelected(false);
        }
        else
            chkDay2.setSelected(true);
        if (hdebut3.equals(MainClass.STIME_000000) && hfin3.equals(MainClass.STIME_000000))
        {
            txtHeureMin3.setVisible(false);
            txtHeureMax3.setVisible(false);
            chkDay3.setSelected(false);
        }
        else
            chkDay3.setSelected(true);
        if (hdebut4.equals(MainClass.STIME_000000) && hfin4.equals(MainClass.STIME_000000))
        {
            txtHeureMin4.setVisible(false);
            txtHeureMax4.setVisible(false);
            chkDay4.setSelected(false);
        }
        else
            chkDay4.setSelected(true);
        if (hdebut5.equals(MainClass.STIME_000000) && hfin5.equals(MainClass.STIME_000000))
        {
            txtHeureMin5.setVisible(false);
            txtHeureMax5.setVisible(false);
            chkDay5.setSelected(false);
        }
        else
            chkDay5.setSelected(true);
        if (hdebut6.equals(MainClass.STIME_000000) && hfin6.equals(MainClass.STIME_000000))
        {
            txtHeureMin6.setVisible(false);
            txtHeureMax6.setVisible(false);
            chkDay6.setSelected(false);
        }
        else
            chkDay6.setSelected(true);
        if (hdebut7.equals(MainClass.STIME_000000) && hfin7.equals(MainClass.STIME_000000))
        {
            txtHeureMin7.setVisible(false);
            txtHeureMax7.setVisible(false);
            chkDay7.setSelected(false);
        }
        else
            chkDay7.setSelected(true);
        hdebut1 = FTime.formatAMPM(hdebut1);
        hfin1 = FTime.formatAMPM(hfin1);
        txtHeureMin1.setText(hdebut1);
        txtHeureMax1.setText(hfin1);
        hdebut2 = FTime.formatAMPM(hdebut2);
        hfin2 = FTime.formatAMPM(hfin2);
        txtHeureMin2.setText(hdebut2);
        txtHeureMax2.setText(hfin2);
        hdebut3 = FTime.formatAMPM(hdebut3);
        hfin3 = FTime.formatAMPM(hfin3);
        txtHeureMin3.setText(hdebut3);
        txtHeureMax3.setText(hfin3);
        hdebut4 = FTime.formatAMPM(hdebut4);
        hfin4 = FTime.formatAMPM(hfin4);
        txtHeureMin4.setText(hdebut4);
        txtHeureMax4.setText(hfin4);
        hdebut5 = FTime.formatAMPM(hdebut5);
        hfin5 = FTime.formatAMPM(hfin5);
        txtHeureMin5.setText(hdebut5);
        txtHeureMax5.setText(hfin5);
        hdebut6 = FTime.formatAMPM(hdebut6);
        hfin6 = FTime.formatAMPM(hfin6);
        txtHeureMin6.setText(hdebut6);
        txtHeureMax6.setText(hfin6);
        hdebut7 = FTime.formatAMPM(hdebut7);
        hfin7 = FTime.formatAMPM(hfin7);
        txtHeureMin7.setText(hdebut7);
        txtHeureMax7.setText(hfin7);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpTimeFormat = new javax.swing.ButtonGroup();
        pnlHeader = new javax.swing.JPanel();
        pnlBoutons = new javax.swing.JPanel();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlData = new javax.swing.JPanel();
        pnlDuree1 = new javax.swing.JPanel();
        chkDay1 = new javax.swing.JCheckBox();
        pnlDebut1 = new javax.swing.JPanel();
        lblDateMin1 = new javax.swing.JLabel();
        txtHeureMin1 = new javax.swing.JTextField();
        pnlFin1 = new javax.swing.JPanel();
        lblDateMax1 = new javax.swing.JLabel();
        txtHeureMax1 = new javax.swing.JTextField();
        pnlDuree2 = new javax.swing.JPanel();
        chkDay2 = new javax.swing.JCheckBox();
        pnlDebut2 = new javax.swing.JPanel();
        lblDateMin2 = new javax.swing.JLabel();
        txtHeureMin2 = new javax.swing.JTextField();
        pnlFin2 = new javax.swing.JPanel();
        lblDateMax2 = new javax.swing.JLabel();
        txtHeureMax2 = new javax.swing.JTextField();
        pnlDuree3 = new javax.swing.JPanel();
        chkDay3 = new javax.swing.JCheckBox();
        pnlDebut3 = new javax.swing.JPanel();
        lblDateMin3 = new javax.swing.JLabel();
        txtHeureMin3 = new javax.swing.JTextField();
        pnlFin3 = new javax.swing.JPanel();
        lblDateMax3 = new javax.swing.JLabel();
        txtHeureMax3 = new javax.swing.JTextField();
        pnlDuree4 = new javax.swing.JPanel();
        chkDay4 = new javax.swing.JCheckBox();
        pnlDebut4 = new javax.swing.JPanel();
        lblDateMin4 = new javax.swing.JLabel();
        txtHeureMin4 = new javax.swing.JTextField();
        pnlFin4 = new javax.swing.JPanel();
        lblDateMax4 = new javax.swing.JLabel();
        txtHeureMax4 = new javax.swing.JTextField();
        pnlDuree5 = new javax.swing.JPanel();
        chkDay5 = new javax.swing.JCheckBox();
        pnlDebut5 = new javax.swing.JPanel();
        lblDateMin5 = new javax.swing.JLabel();
        txtHeureMin5 = new javax.swing.JTextField();
        pnlFin5 = new javax.swing.JPanel();
        lblDateMax5 = new javax.swing.JLabel();
        txtHeureMax5 = new javax.swing.JTextField();
        pnlDuree6 = new javax.swing.JPanel();
        chkDay6 = new javax.swing.JCheckBox();
        pnlDebut6 = new javax.swing.JPanel();
        lblDateMin6 = new javax.swing.JLabel();
        txtHeureMin6 = new javax.swing.JTextField();
        pnlFin6 = new javax.swing.JPanel();
        lblDateMax6 = new javax.swing.JLabel();
        txtHeureMax6 = new javax.swing.JTextField();
        pnlDuree7 = new javax.swing.JPanel();
        chkDay7 = new javax.swing.JCheckBox();
        pnlDebut7 = new javax.swing.JPanel();
        lblDateMin7 = new javax.swing.JLabel();
        txtHeureMin7 = new javax.swing.JTextField();
        pnlFin7 = new javax.swing.JPanel();
        lblDateMax7 = new javax.swing.JLabel();
        txtHeureMax7 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlHeader.setBackground(new java.awt.Color(255, 225, 220));
        pnlHeader.setLayout(new java.awt.BorderLayout());

        pnlBoutons.setPreferredSize(new java.awt.Dimension(370, 42));

        btnOK.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOK.setPreferredSize(new java.awt.Dimension(160, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(160, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        pnlHeader.add(pnlBoutons, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pnlHeader, java.awt.BorderLayout.NORTH);

        pnlData.setPreferredSize(new java.awt.Dimension(370, 200));
        pnlData.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        pnlDuree1.setPreferredSize(new java.awt.Dimension(360, 23));
        pnlDuree1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay1.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay1ActionPerformed(evt);
            }
        });
        pnlDuree1.add(chkDay1);

        pnlDebut1.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin1.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut1.add(lblDateMin1);

        txtHeureMin1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin1.setName(""); // NOI18N
        txtHeureMin1.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin1FocusLost(evt);
            }
        });
        txtHeureMin1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin1KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin1KeyPressed(evt);
            }
        });
        pnlDebut1.add(txtHeureMin1);

        pnlDuree1.add(pnlDebut1);

        pnlFin1.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax1.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin1.add(lblDateMax1);

        txtHeureMax1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax1.setName(""); // NOI18N
        txtHeureMax1.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax1FocusLost(evt);
            }
        });
        txtHeureMax1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax1KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax1KeyPressed(evt);
            }
        });
        pnlFin1.add(txtHeureMax1);

        pnlDuree1.add(pnlFin1);

        pnlData.add(pnlDuree1);

        pnlDuree2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay2.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay2ActionPerformed(evt);
            }
        });
        pnlDuree2.add(chkDay2);

        pnlDebut2.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin2.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut2.add(lblDateMin2);

        txtHeureMin2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin2.setName(""); // NOI18N
        txtHeureMin2.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin2FocusLost(evt);
            }
        });
        txtHeureMin2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin2KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin2KeyPressed(evt);
            }
        });
        pnlDebut2.add(txtHeureMin2);

        pnlDuree2.add(pnlDebut2);

        pnlFin2.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax2.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin2.add(lblDateMax2);

        txtHeureMax2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax2.setName(""); // NOI18N
        txtHeureMax2.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax2FocusLost(evt);
            }
        });
        txtHeureMax2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax2KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax2KeyPressed(evt);
            }
        });
        pnlFin2.add(txtHeureMax2);

        pnlDuree2.add(pnlFin2);

        pnlData.add(pnlDuree2);

        pnlDuree3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay3.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay3ActionPerformed(evt);
            }
        });
        pnlDuree3.add(chkDay3);

        pnlDebut3.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin3.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut3.add(lblDateMin3);

        txtHeureMin3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin3.setName(""); // NOI18N
        txtHeureMin3.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin3FocusLost(evt);
            }
        });
        txtHeureMin3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin3KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin3KeyPressed(evt);
            }
        });
        pnlDebut3.add(txtHeureMin3);

        pnlDuree3.add(pnlDebut3);

        pnlFin3.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax3.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin3.add(lblDateMax3);

        txtHeureMax3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax3.setName(""); // NOI18N
        txtHeureMax3.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax3FocusLost(evt);
            }
        });
        txtHeureMax3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax3KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax3KeyPressed(evt);
            }
        });
        pnlFin3.add(txtHeureMax3);

        pnlDuree3.add(pnlFin3);

        pnlData.add(pnlDuree3);

        pnlDuree4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay4.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay4ActionPerformed(evt);
            }
        });
        pnlDuree4.add(chkDay4);

        pnlDebut4.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin4.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut4.add(lblDateMin4);

        txtHeureMin4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin4.setName(""); // NOI18N
        txtHeureMin4.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin4FocusLost(evt);
            }
        });
        txtHeureMin4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin4KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin4KeyPressed(evt);
            }
        });
        pnlDebut4.add(txtHeureMin4);

        pnlDuree4.add(pnlDebut4);

        pnlFin4.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax4.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin4.add(lblDateMax4);

        txtHeureMax4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax4.setName(""); // NOI18N
        txtHeureMax4.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax4FocusLost(evt);
            }
        });
        txtHeureMax4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax4KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax4KeyPressed(evt);
            }
        });
        pnlFin4.add(txtHeureMax4);

        pnlDuree4.add(pnlFin4);

        pnlData.add(pnlDuree4);

        pnlDuree5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay5.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay5ActionPerformed(evt);
            }
        });
        pnlDuree5.add(chkDay5);

        pnlDebut5.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin5.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut5.add(lblDateMin5);

        txtHeureMin5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin5.setName(""); // NOI18N
        txtHeureMin5.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin5FocusLost(evt);
            }
        });
        txtHeureMin5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin5KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin5KeyPressed(evt);
            }
        });
        pnlDebut5.add(txtHeureMin5);

        pnlDuree5.add(pnlDebut5);

        pnlFin5.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax5.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin5.add(lblDateMax5);

        txtHeureMax5.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax5.setName(""); // NOI18N
        txtHeureMax5.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax5FocusLost(evt);
            }
        });
        txtHeureMax5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax5KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax5KeyPressed(evt);
            }
        });
        pnlFin5.add(txtHeureMax5);

        pnlDuree5.add(pnlFin5);

        pnlData.add(pnlDuree5);

        pnlDuree6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay6.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay6ActionPerformed(evt);
            }
        });
        pnlDuree6.add(chkDay6);

        pnlDebut6.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin6.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut6.add(lblDateMin6);

        txtHeureMin6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin6.setName(""); // NOI18N
        txtHeureMin6.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin6.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin6FocusLost(evt);
            }
        });
        txtHeureMin6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin6KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin6KeyPressed(evt);
            }
        });
        pnlDebut6.add(txtHeureMin6);

        pnlDuree6.add(pnlDebut6);

        pnlFin6.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax6.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin6.add(lblDateMax6);

        txtHeureMax6.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax6.setName(""); // NOI18N
        txtHeureMax6.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax6.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax6FocusLost(evt);
            }
        });
        txtHeureMax6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax6KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax6KeyPressed(evt);
            }
        });
        pnlFin6.add(txtHeureMax6);

        pnlDuree6.add(pnlFin6);

        pnlData.add(pnlDuree6);

        pnlDuree7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkDay7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkDay7.setPreferredSize(new java.awt.Dimension(120, 22));
        chkDay7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDay7ActionPerformed(evt);
            }
        });
        pnlDuree7.add(chkDay7);

        pnlDebut7.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlDebut7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin7.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlDebut7.add(lblDateMin7);

        txtHeureMin7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin7.setName(""); // NOI18N
        txtHeureMin7.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMin7FocusLost(evt);
            }
        });
        txtHeureMin7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMin7KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMin7KeyPressed(evt);
            }
        });
        pnlDebut7.add(txtHeureMin7);

        pnlDuree7.add(pnlDebut7);

        pnlFin7.setPreferredSize(new java.awt.Dimension(120, 23));
        pnlFin7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax7.setPreferredSize(new java.awt.Dimension(50, 22));
        pnlFin7.add(lblDateMax7);

        txtHeureMax7.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax7.setName(""); // NOI18N
        txtHeureMax7.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHeureMax7FocusLost(evt);
            }
        });
        txtHeureMax7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHeureMax7KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHeureMax7KeyPressed(evt);
            }
        });
        pnlFin7.add(txtHeureMax7);

        pnlDuree7.add(pnlFin7);

        pnlData.add(pnlDuree7);

        getContentPane().add(pnlData, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtHeureMin1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin1FocusLost
    {//GEN-HEADEREND:event_txtHeureMin1FocusLost
        hdebut1 = txtHeureMin1.getText();
        hdebut1 = MainClass.no2defaultTime(hdebut1, MainClass.TIME_000000);
        txtHeureMin1.setText(hdebut1);
    }//GEN-LAST:event_txtHeureMin1FocusLost

    private void txtHeureMin1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin1KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin1.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin1.setText(hdebut1);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin1, kc);
        }
    }//GEN-LAST:event_txtHeureMin1KeyPressed

    private void txtHeureMin1KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin1KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin1KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin1KeyTyped

    private void txtHeureMax1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax1FocusLost
    {//GEN-HEADEREND:event_txtHeureMax1FocusLost
        hfin1 = txtHeureMax1.getText();
        hfin1 = MainClass.no2defaultTime(hfin1, MainClass.TIME_000000);
        txtHeureMax1.setText(hfin1);
    }//GEN-LAST:event_txtHeureMax1FocusLost

    private void txtHeureMax1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax1KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax1.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax1.setText(hfin1);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax1, kc);
        }
    }//GEN-LAST:event_txtHeureMax1KeyPressed

    private void txtHeureMax1KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax1KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax1KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax1KeyTyped

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave() == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_formWindowClosing

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        if (save())
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKActionPerformed

    private void chkDay1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay1ActionPerformed
    {//GEN-HEADEREND:event_chkDay1ActionPerformed
        if(chkDay1.isSelected())
        {
            txtHeureMin1.setVisible(true);
            txtHeureMax1.setVisible(true);
        }
        else
        {
            hdebut1 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin1 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin1.setText(hdebut1);
            txtHeureMax1.setText(hfin1);
            txtHeureMin1.setVisible(false);
            txtHeureMax1.setVisible(false);
        }
        pnlDuree1.paintAll(pnlDuree1.getGraphics());
        bolEditing = true;
    }//GEN-LAST:event_chkDay1ActionPerformed

    private void chkDay2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay2ActionPerformed
    {//GEN-HEADEREND:event_chkDay2ActionPerformed
        if(chkDay2.isSelected())
        {
            txtHeureMin2.setVisible(true);
            txtHeureMax2.setVisible(true);
        }
        else
        {
            hdebut2 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin2 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin2.setText(hdebut2);
            txtHeureMax2.setText(hfin2);
            txtHeureMin2.setVisible(false);
            txtHeureMax2.setVisible(false);
        }
        pnlDuree2.paintAll(pnlDuree2.getGraphics());
        bolEditing = true;
    }//GEN-LAST:event_chkDay2ActionPerformed

    private void txtHeureMin2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin2FocusLost
    {//GEN-HEADEREND:event_txtHeureMin2FocusLost
        hdebut2 = txtHeureMin2.getText();
        hdebut2 = MainClass.no2defaultTime(hdebut2, MainClass.TIME_000000);
        txtHeureMin2.setText(hdebut2);
    }//GEN-LAST:event_txtHeureMin2FocusLost

    private void txtHeureMin2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin2KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin2.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin2.setText(hdebut2);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin2, kc);
        }
    }//GEN-LAST:event_txtHeureMin2KeyPressed

    private void txtHeureMin2KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin2KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin2KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin2, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin2.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin2KeyTyped

    private void txtHeureMax2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax2FocusLost
    {//GEN-HEADEREND:event_txtHeureMax2FocusLost
        hfin2 = txtHeureMax2.getText();
        hfin2 = MainClass.no2defaultTime(hfin2, MainClass.TIME_000000);
        txtHeureMax2.setText(hfin2);
    }//GEN-LAST:event_txtHeureMax2FocusLost

    private void txtHeureMax2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax2KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax2.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax2.setText(hfin2);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax2, kc);
        }
    }//GEN-LAST:event_txtHeureMax2KeyPressed

    private void txtHeureMax2KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax2KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax2KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax2, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax2.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax2KeyTyped

    private void chkDay3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay3ActionPerformed
    {//GEN-HEADEREND:event_chkDay3ActionPerformed
        if(chkDay3.isSelected())
        {
            txtHeureMin3.setVisible(true);
            txtHeureMax3.setVisible(true);
        }
        else
        {
            hdebut3 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin3 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin3.setText(hdebut3);
            txtHeureMax3.setText(hfin3);
            txtHeureMin3.setVisible(false);
            txtHeureMax3.setVisible(false);
        }
        pnlDuree3.paintAll(pnlDuree3.getGraphics());
        bolEditing = true;

    }//GEN-LAST:event_chkDay3ActionPerformed

    private void txtHeureMin3FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin3FocusLost
    {//GEN-HEADEREND:event_txtHeureMin3FocusLost
        hdebut3 = txtHeureMin3.getText();
        hdebut3 = MainClass.no2defaultTime(hdebut3, MainClass.TIME_000000);
        txtHeureMin3.setText(hdebut3);
    }//GEN-LAST:event_txtHeureMin3FocusLost

    private void txtHeureMin3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin3KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin3KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin3.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin3.setText(hdebut3);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin3, kc);
        }
    }//GEN-LAST:event_txtHeureMin3KeyPressed

    private void txtHeureMin3KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin3KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin3KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin3, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin3.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin3KeyTyped

    private void txtHeureMax3FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax3FocusLost
    {//GEN-HEADEREND:event_txtHeureMax3FocusLost
        hfin3 = txtHeureMax3.getText();
        hfin3 = MainClass.no2defaultTime("", MainClass.TIME_000000);
        txtHeureMax3.setText(hfin3);
    }//GEN-LAST:event_txtHeureMax3FocusLost

    private void txtHeureMax3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax3KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax3KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax3.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax3.setText(hfin3);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax3, kc);
        }
    }//GEN-LAST:event_txtHeureMax3KeyPressed

    private void txtHeureMax3KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax3KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax3KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax3, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax3.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax3KeyTyped

    private void chkDay4ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay4ActionPerformed
    {//GEN-HEADEREND:event_chkDay4ActionPerformed
        if(chkDay4.isSelected())
        {
            txtHeureMin4.setVisible(true);
            txtHeureMax4.setVisible(true);
        }
        else
        {
            hdebut4 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin4 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin4.setText(hdebut4);
            txtHeureMax4.setText(hfin4);
            txtHeureMin4.setVisible(false);
            txtHeureMax4.setVisible(false);
        }
        pnlDuree4.paintAll(pnlDuree4.getGraphics());
        bolEditing = true;

    }//GEN-LAST:event_chkDay4ActionPerformed

    private void txtHeureMin4FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin4FocusLost
    {//GEN-HEADEREND:event_txtHeureMin4FocusLost
        hdebut4 = txtHeureMin4.getText();
        hdebut4 = MainClass.no2defaultTime(hdebut4, MainClass.TIME_000000);
        txtHeureMin4.setText(hdebut4);
    }//GEN-LAST:event_txtHeureMin4FocusLost

    private void txtHeureMin4KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin4KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin4KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin4.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin4.setText(hdebut4);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin4, kc);
        }
    }//GEN-LAST:event_txtHeureMin4KeyPressed

    private void txtHeureMin4KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin4KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin4KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin4, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin4.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin4KeyTyped

    private void txtHeureMax4FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax4FocusLost
    {//GEN-HEADEREND:event_txtHeureMax4FocusLost
        hfin4 = txtHeureMax4.getText();
        hfin4 = MainClass.no2defaultTime(hfin4, MainClass.TIME_000000);
        txtHeureMax4.setText(hfin4);
    }//GEN-LAST:event_txtHeureMax4FocusLost

    private void txtHeureMax4KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax4KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax4KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax4.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax4.setText(hfin4);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax4, kc);
        }
    }//GEN-LAST:event_txtHeureMax4KeyPressed

    private void txtHeureMax4KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax4KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax4KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax4, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax4.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax4KeyTyped

    private void chkDay5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay5ActionPerformed
    {//GEN-HEADEREND:event_chkDay5ActionPerformed
        if(chkDay5.isSelected())
        {
            txtHeureMin5.setVisible(true);
            txtHeureMax5.setVisible(true);
        }
        else
        {
            hdebut5 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin5 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin5.setText(hdebut5);
            txtHeureMax5.setText(hfin5);
            txtHeureMin5.setVisible(false);
            txtHeureMax5.setVisible(false);
        }
        pnlDuree5.paintAll(pnlDuree5.getGraphics());
        bolEditing = true;

    }//GEN-LAST:event_chkDay5ActionPerformed

    private void txtHeureMin5FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin5FocusLost
    {//GEN-HEADEREND:event_txtHeureMin5FocusLost
        hdebut5 = txtHeureMin5.getText();
        hdebut5 = MainClass.no2defaultTime(hdebut5, MainClass.TIME_000000);
        txtHeureMin5.setText(hdebut5);
    }//GEN-LAST:event_txtHeureMin5FocusLost

    private void txtHeureMin5KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin5KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin5KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin5.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin5.setText(hdebut5);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin5, kc);
        }
    }//GEN-LAST:event_txtHeureMin5KeyPressed

    private void txtHeureMin5KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin5KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin5KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin5, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin5.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin5KeyTyped

    private void txtHeureMax5FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax5FocusLost
    {//GEN-HEADEREND:event_txtHeureMax5FocusLost
        hfin5 = txtHeureMax5.getText();
        hfin5 = MainClass.no2defaultTime(hfin5, MainClass.TIME_000000);
        txtHeureMax5.setText(hfin5);
    }//GEN-LAST:event_txtHeureMax5FocusLost

    private void txtHeureMax5KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax5KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax5KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax5.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax5.setText(hfin5);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax5, kc);
        }
    }//GEN-LAST:event_txtHeureMax5KeyPressed

    private void txtHeureMax5KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax5KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax5KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax5, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax5.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax5KeyTyped

    private void chkDay6ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay6ActionPerformed
    {//GEN-HEADEREND:event_chkDay6ActionPerformed
        if(chkDay6.isSelected())
        {
            txtHeureMin6.setVisible(true);
            txtHeureMax6.setVisible(true);
        }
        else
        {
            hdebut6 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin6 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin6.setText(hdebut6);
            txtHeureMax6.setText(hfin6);
            txtHeureMin6.setVisible(false);
            txtHeureMax6.setVisible(false);
        }
        pnlDuree6.paintAll(pnlDuree6.getGraphics());
        bolEditing = true;

    }//GEN-LAST:event_chkDay6ActionPerformed

    private void txtHeureMin6FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin6FocusLost
    {//GEN-HEADEREND:event_txtHeureMin6FocusLost
        hdebut6 = txtHeureMin6.getText();
        hdebut6 = MainClass.no2defaultTime(hdebut6, MainClass.TIME_000000);
        txtHeureMin6.setText(hdebut6);
    }//GEN-LAST:event_txtHeureMin6FocusLost

    private void txtHeureMin6KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin6KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin6KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin6.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin6.setText(hdebut6);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin6, kc);
        }
    }//GEN-LAST:event_txtHeureMin6KeyPressed

    private void txtHeureMin6KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin6KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin6KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin6, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin6.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin6KeyTyped

    private void txtHeureMax6FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax6FocusLost
    {//GEN-HEADEREND:event_txtHeureMax6FocusLost
        hfin6 = txtHeureMax6.getText();
        hfin6 = MainClass.no2defaultTime(hfin6, MainClass.TIME_000000);
        txtHeureMax6.setText(hfin6);
    }//GEN-LAST:event_txtHeureMax6FocusLost

    private void txtHeureMax6KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax6KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax6KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax6.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax6.setText(hfin6);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax6, kc);
        }
    }//GEN-LAST:event_txtHeureMax6KeyPressed

    private void txtHeureMax6KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax6KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax6KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax6, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax6.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax6KeyTyped

    private void chkDay7ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkDay7ActionPerformed
    {//GEN-HEADEREND:event_chkDay7ActionPerformed
        if(chkDay7.isSelected())
        {
            txtHeureMin7.setVisible(true);
            txtHeureMax7.setVisible(true);
        }
        else
        {
            hdebut7 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            hfin7 = MainClass.no2defaultTime("", MainClass.TIME_000000);
            txtHeureMin7.setText(hdebut7);
            txtHeureMax7.setText(hfin7);
            txtHeureMin7.setVisible(false);
            txtHeureMax7.setVisible(false);
        }
        pnlDuree7.paintAll(pnlDuree7.getGraphics());
        bolEditing = true;

    }//GEN-LAST:event_chkDay7ActionPerformed

    private void txtHeureMin7FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin7FocusLost
    {//GEN-HEADEREND:event_txtHeureMin7FocusLost
        hdebut7 = txtHeureMin7.getText();
        hdebut7 = MainClass.no2defaultTime(hdebut7, MainClass.TIME_000000);
        txtHeureMin7.setText(hdebut7);
    }//GEN-LAST:event_txtHeureMin7FocusLost

    private void txtHeureMin7KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin7KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin7KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin7.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin7.setText(hdebut7);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMin7, kc);
        }
    }//GEN-LAST:event_txtHeureMin7KeyPressed

    private void txtHeureMin7KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin7KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin7KeyTyped
        KTTime t = new KTTime(evt, txtHeureMin7, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin7.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin7KeyTyped

    private void txtHeureMax7FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMax7FocusLost
    {//GEN-HEADEREND:event_txtHeureMax7FocusLost
        hfin7 = txtHeureMax7.getText();
        hfin7 = MainClass.no2defaultTime(hfin7, MainClass.TIME_000000);
        txtHeureMax7.setText(hfin7);
    }//GEN-LAST:event_txtHeureMax7FocusLost

    private void txtHeureMax7KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax7KeyPressed
    {//GEN-HEADEREND:event_txtHeureMax7KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax7.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax7.setText(hfin7);
        }
        else
        {
            bolEditing = true;
            KTTime t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTime(evt, txtHeureMax7, kc);
        }
    }//GEN-LAST:event_txtHeureMax7KeyPressed

    private void txtHeureMax7KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMax7KeyTyped
    {//GEN-HEADEREND:event_txtHeureMax7KeyTyped
        KTTime t = new KTTime(evt, txtHeureMax7, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax7.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMax7KeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JCheckBox chkDay1;
    private javax.swing.JCheckBox chkDay2;
    private javax.swing.JCheckBox chkDay3;
    private javax.swing.JCheckBox chkDay4;
    private javax.swing.JCheckBox chkDay5;
    private javax.swing.JCheckBox chkDay6;
    private javax.swing.JCheckBox chkDay7;
    private javax.swing.ButtonGroup grpTimeFormat;
    private javax.swing.JLabel lblDateMax1;
    private javax.swing.JLabel lblDateMax2;
    private javax.swing.JLabel lblDateMax3;
    private javax.swing.JLabel lblDateMax4;
    private javax.swing.JLabel lblDateMax5;
    private javax.swing.JLabel lblDateMax6;
    private javax.swing.JLabel lblDateMax7;
    private javax.swing.JLabel lblDateMin1;
    private javax.swing.JLabel lblDateMin2;
    private javax.swing.JLabel lblDateMin3;
    private javax.swing.JLabel lblDateMin4;
    private javax.swing.JLabel lblDateMin5;
    private javax.swing.JLabel lblDateMin6;
    private javax.swing.JLabel lblDateMin7;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlDebut1;
    private javax.swing.JPanel pnlDebut2;
    private javax.swing.JPanel pnlDebut3;
    private javax.swing.JPanel pnlDebut4;
    private javax.swing.JPanel pnlDebut5;
    private javax.swing.JPanel pnlDebut6;
    private javax.swing.JPanel pnlDebut7;
    private javax.swing.JPanel pnlDuree1;
    private javax.swing.JPanel pnlDuree2;
    private javax.swing.JPanel pnlDuree3;
    private javax.swing.JPanel pnlDuree4;
    private javax.swing.JPanel pnlDuree5;
    private javax.swing.JPanel pnlDuree6;
    private javax.swing.JPanel pnlDuree7;
    private javax.swing.JPanel pnlFin1;
    private javax.swing.JPanel pnlFin2;
    private javax.swing.JPanel pnlFin3;
    private javax.swing.JPanel pnlFin4;
    private javax.swing.JPanel pnlFin5;
    private javax.swing.JPanel pnlFin6;
    private javax.swing.JPanel pnlFin7;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JTextField txtHeureMax1;
    private javax.swing.JTextField txtHeureMax2;
    private javax.swing.JTextField txtHeureMax3;
    private javax.swing.JTextField txtHeureMax4;
    private javax.swing.JTextField txtHeureMax5;
    private javax.swing.JTextField txtHeureMax6;
    private javax.swing.JTextField txtHeureMax7;
    private javax.swing.JTextField txtHeureMin1;
    private javax.swing.JTextField txtHeureMin2;
    private javax.swing.JTextField txtHeureMin3;
    private javax.swing.JTextField txtHeureMin4;
    private javax.swing.JTextField txtHeureMin5;
    private javax.swing.JTextField txtHeureMin6;
    private javax.swing.JTextField txtHeureMin7;
    // End of variables declaration//GEN-END:variables
}
