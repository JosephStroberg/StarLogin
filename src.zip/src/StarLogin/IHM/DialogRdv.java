/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTDate;
import StarLogin.IHM.components.KeyType.KTInteger;
import StarLogin.IHM.components.KeyType.KTTimeAbrev;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author Francois
 */
public class DialogRdv extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager;
    private Record rdv;
    private Records rdvs;
    private String sQuery = "SELECT ID,CLIENTID,TEL_CLIENT,DATE_,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,STATUS_,RDVRECURID,NOM_CLIENT,DUREE FROM rdv";
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private java.util.ResourceBundle bundle;
    private DataBaseRecord dbr;
    private String daterdv;
    private String hdebut;
    private String hdebut24;
    private String hfin;
    private String duree = "";
    private String telclient;
    private String description;
    private String etat;
    private String recurid;
    private String rdvid;
    private String nomclient;
    private String clientid;
    private boolean bSetting = true;
    private Window parentForm;
    private String prenom = "";
    private String nom = "";
    private boolean bDeleted = false;
    private Color color;
    private String saveMin = "";
    private String saveMax = "";
    private boolean bMois = false;
    private int index;
    private int scale = 15;
    private int kc; //key code
    private int cp; //caret position
    private boolean bInit = true;


    /**
     * Creates new form DialogRdv
     */
    public DialogRdv(java.awt.Frame parent, boolean modal, String daterdv, String heuredebut, String rdvid, boolean bMois)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        if (parentForm instanceof GestionTempsForm)
        {
            ((GestionTempsForm)parentForm).setPopMenuInvisible();
            scale = ((GestionTempsForm)parentForm).getScale();
        }
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;
        this.rdvid = rdvid;
        this.bMois = bMois;
        if (rdvid != null && !rdvid.equals("-1"))
        {
            hdebut = starLoginManager.getStringFieldValue("rdv", "HEURE_DEBUT", " WHERE ID=" + rdvid);
            this.daterdv = MainClass.getFormatedDate(starLoginManager.getStringFieldValue("rdv", "DATE_", " WHERE ID=" + rdvid + ""));
        }
        else
        {
            hdebut = heuredebut;
            this.daterdv = daterdv;
        }
        if (hdebut.length() == 8)
            hdebut = hdebut.substring(0,5);
        hdebut24 = hdebut;
        hdebut = FTime.formatAMPMAbrev(hdebut);
        if (rdvid.equals("-1"))
            bolAdding = true;

        bundle = MainClass.bundle;
        initComponents();
        pnlDelais.setVisible(false);
        if (bMois)
        {
            pnlDuree1.setVisible(true);
            pnlDuree.setVisible(false);
        }
        else
        {
            pnlDuree.setVisible(true);
            pnlDuree1.setVisible(false);
        }
        resetLangue();

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setPreferredSize(new Dimension(this.getWidth(), this.getHeight()-55));
        this.setSize(new Dimension(this.getWidth(), this.getHeight()-55));
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));

        Color fEO = Options.getColor("EtiquetteObligatoire.background");
        Color pEO = Options.getColor("EtiquetteObligatoire.foreground");
        Color fTO = Options.getColor("SaisieObligatoire.background");
        Color pTO = Options.getColor("SaisieObligatoire.foreground");
        lblContact.setBackground(fEO);
        lblContact.setForeground(pEO);
        txtClient.setBackground(fTO);
        txtClient.setForeground(pTO);
        lblDateMin.setBackground(fEO);
        lblDateMin.setForeground(pEO);
        txtDateMin.setBackground(fTO);
        txtDateMin.setForeground(pTO);
        txtHeureMin.setBackground(fTO);
        txtHeureMin.setForeground(pTO);
        lblDateMax.setBackground(fEO);
        lblDateMax.setForeground(pEO);
        txtHeureMax.setBackground(fTO);
        txtHeureMax.setForeground(pTO);
        lblDateMin1.setBackground(fEO);
        lblDateMin1.setForeground(pEO);
        txtDateMin1.setBackground(fTO);
        txtDateMin1.setForeground(pTO);
        txtHeureMin1.setBackground(fTO);
        txtHeureMin1.setForeground(pTO);
        lblDemiJours.setBackground(fEO);
        lblDemiJours.setForeground(pEO);
        txtDemiJours.setBackground(fTO);
        txtDemiJours.setForeground(pTO);
        lblDateMax1.setBackground(fEO);
        lblDateMax1.setForeground(pEO);
        txtDateMax1.setBackground(fTO);
        txtDateMax1.setForeground(pTO);
        index = -1;
        setCombos(index);
        refreshRecord();
        rdvs = starLoginManager.getRecords(sQuery + " WHERE ID=" + rdvid, "rdv");
        bSetting = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        bInit = false;
        this.setVisible(true);
    }

    private void setChkRecur()
    {
        recurid = starLoginManager.getStringFieldValue("rdv", "RDVRECURID", " WHERE ID=" + rdvid);
        if (recurid == null || recurid.equals("") || recurid.equals("0") || recurid.equals("-1"))
        {
            chkRecur.setSelected(false);
        }
        else
        {
            chkRecur.setSelected(true);
        }
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }
    
    private void setCombos(int index)
    {
        setStatus(false);
        cboStatus.setSelectedIndex(-1);
    }   
    
    private boolean save(boolean bRefresh)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setTextToData();
            
            String nomChamp = "";
            boolean bRempli = true;
            if (hfin.equals("") && !bMois)
            {
                bRempli = false;
                nomChamp = lblDateMax.getText();
            }
            if (daterdv.equals("") || hdebut.equals(""))
            {
                bRempli = false;
                if (bMois)
                    nomChamp = lblDateMin1.getText();
                else
                    nomChamp = lblDateMin.getText();
            }
            if (duree.equals("") && bMois)
            {
                bRempli = false;
                nomChamp = lblDemiJours.getText();
            }
            if (nomclient.equals("") && cboStatus.getSelectedIndex()!=4)
            {
                bRempli = false;
                nomChamp = lblContact.getText();
            }
            
            if (bRempli == false)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                MainClass.setMessage(bundle.getString("DataObligatoirePasRemplies").concat("\n").concat(nomChamp), JOptionPane.WARNING_MESSAGE);
                bSetting = true;
                chkRecur.setSelected(false);
                bSetting = false;
                return false;
            }
            
            //check if the client doesn't exist
            String clid;
            String sdate = FDate.fr2us(daterdv);

            int pos = nomclient.indexOf(" ");
            nom = nomclient;
            if (pos > 0)
            {
                nom = nomclient.substring(0, pos);
                prenom = nomclient.substring(pos + 1);
            }
            
            if (clientid.equals("-1"))
            {
                if (nomclient.equals(bundle.getString("NewClient")))
                    clid = "-1";
                else
                {
                    String search = nom;
                    if (prenom.length() > 0)
                        search = search.concat(" ").concat(prenom);
                    if (telclient.length() > 0)
                        search = search.concat(" ").concat(telclient);
                    if (search.startsWith(" "))
                        search = search.substring(1);
                    search = search.replace("'", "''");
                    clid = starLoginManager.getStringFieldValue("clients", "ID", " WHERE CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' '||CASE WHEN PHONE IS NULL THEN''ELSE PHONE END Like '%" + search + "%' or CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' '||CASE WHEN TELBUREAU IS NULL THEN''ELSE TELBUREAU END Like '%" + search + "%' or CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' '||CASE WHEN CELL IS NULL THEN''ELSE CELL END Like '%" + search + "%'");
                    if (clid.equals("-1") && !clientid.equals("-1"))
                    {
                        starLoginManager.updateDataBase("UPDATE clients SET FIRSTNAME='" + nom.replace("'", "''") + "',OTHERNAMES='" + prenom.replace("'", "''") + "',PHONE='" + telclient.replace("'", "''") + "' WHERE ID=" + clientid);
                    }
                }
                if (!clid.equals("-1"))
                    clientid = clid;
                else
                {
                    newClient();
                    if (clientid.equals("-1"))
                    {
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        nomChamp = lblContact.getText();
                        MainClass.setMessage(bundle.getString("DataObligatoirePasRemplies").concat("\n").concat(nomChamp), JOptionPane.WARNING_MESSAGE);
                        bSetting = true;
                        chkRecur.setSelected(false);
                        bSetting = false;
                        return false;
                    }
                }
            }
            else
            {
                starLoginManager.updateDataBase("update rdv set TEL_CLIENT='" + telclient.replace("'", "''") + "' WHERE CLIENTID=" + clientid + " AND DATE_>='" + sdate + "'");
                starLoginManager.updateDataBase("UPDATE clients SET FIRSTNAME='" + nom.replace("'", "''") + "',OTHERNAMES='" + prenom.replace("'", "''") + "',PHONE='" + telclient.replace("'", "''") + "' WHERE ID=" + clientid);
            }
            //ID,CLIENTID,TEL_CLIENT,DATE_,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,STATUS_,RDVRECURID,NOM_CLIENT,DUREE
            //update data
            rdv.setAdding(bolAdding);
            rdv.setData(1, clientid);
            rdv.setData(2, telclient);
            rdv.setData(3, sdate);
            rdv.setData(4, FTime.set24Abrev(hdebut));
            if (!bMois)
                rdv.setData(5, FTime.set24Abrev(hfin));
            rdv.setData(6, description);
            //rdv.setData(7, travail);
            rdv.setData(7, etat);
            //rdv.setData(9, montant);
            rdv.setData(8, recurid);
            rdv.setData(9, nomclient);
            if (duree.equals("0"))
            {
                if(bMois)
                    duree = "720";
                else
                    duree = String.valueOf(scale);
            }
            if (duree.startsWith("-"))
                duree = duree.replace("-", "");
            rdv.setData(10, duree);
            starLoginManager.setRecord(rdv, dbr);
            
            if (bolAdding)
                rdvid = starLoginManager.getStringFieldValue("rdv", "max(id)", " WHERE CLIENTID=" + clientid);
            
            bolEditing = false;
            if (bRefresh)
                refreshGrids();
            bolAdding = false;
            refreshRecord();
            setNormalMode();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        return true;
    }
    
    private void refreshGrids()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof ListeRdvForm)
                ((ListeRdvForm)windows[i]).setRdv(rdvid);
            else if (windows[i] instanceof GestionTempsForm)
            {
                ((GestionTempsForm)windows[i]).setDeleted(bDeleted);
                ((GestionTempsForm)windows[i]).refreshRdvs(true, rdvid);
            }
        }
        setChkRecur();
    }
    
    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        nomclient = txtClient.getText();
        if (bolEditing)
        {
            if (!nomclient.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("Client").concat(" ").concat(nomclient),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingRdv"),bundle.getString("Client").concat(" ").concat(nomclient),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
                result = JOptionPane.YES_OPTION;
        }
        return result;
    }
    
    private void refreshRecord()
    {
        if (rdvid.equals("-1"))
        {
            bolAdding = true;
            setEditMode();
        }
        rdv = starLoginManager.getRecord(sQuery + " WHERE ID=" + rdvid, "rdv", "");
        dbr = starLoginManager.getDBRecord();
        //ID,CLIENTID,TEL_CLIENT,DATE_,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,STATUS_,RDVRECURID,NOM_CLIENT,DUREE
        clientid = rdv.getData(1);
        telclient = rdv.getData(2);
        if (telclient.equals("-1"))
            telclient = "";
        if (daterdv.equals("-1") || daterdv.equals(""))
        {
            daterdv = MainClass.getFormatedDate(rdv.getData(3));
        }
        if (hdebut.equals("-1") || hdebut.equals(""))
        {
            hdebut24 = rdv.getData(4);
            if (hdebut24.length() == 8)
                hdebut24 = hdebut24.substring(0,5);
            hdebut = FTime.formatAMPMAbrev(hdebut24);
        }
        if (bMois)
            hfin = rdv.getData(5);
        else
        {
            hfin = rdv.getData(5);
            if (hfin.length() == 8)
                hfin = hfin.substring(0,5);
            hfin = FTime.formatAMPMAbrev(hfin);
        }
        description = rdv.getData(6);
        //travail = rdv.getData(8);
        etat = rdv.getData(7);
        //montant = rdv.getData(10);
        //montant = MainClass.formatDouble(montant);
        recurid = rdv.getData(8);
        nomclient = rdv.getData(9);
        duree = rdv.getData(10);
        if (duree.equals("") || duree.equals("0"))
        {
            if (bMois)
                duree = "720";
            else
                setDuree();
        }
        //String srdv = rdv.getData(11);
        /*if (srdv.equals(""))
            delais = 0;
        else
            delais = Integer.valueOf(srdv).intValue();*/
        setDataToText();
    }
    
    private void setDuree()
    {
        if(!hdebut.equals("") && !hfin.equals(""))
        {
            FTime fd = new FTime(FTime.set24Abrev(hdebut));
            FTime ff = new FTime(FTime.set24Abrev(hfin));
            int mnd = fd.getHour() * 60 + fd.getMinute();
            int mnf = ff.getHour() * 60 + ff.getMinute();
            if (mnf < mnd)
                mnf = mnd + scale;
            duree = String.valueOf(mnf - mnd);
            int hf = mnf / 60;
            mnf = AstronomyMaths.modulo(mnf, 60);
            String shf = String.valueOf(hf);
            if (hf < 10)
                shf = "0".concat(shf);
            String smf = String.valueOf(mnf);
            if (mnf < 10)
                smf = "0".concat(smf);
            hfin = shf.concat(":").concat(smf);
            hfin = FTime.formatAMPMAbrev(hfin);
            hfin = FTime.formatTimeAbrev(hfin);
        }
    }

    private void addRecord()
    {
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save(true)== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        bolAdding = true;
        bolEditing = false;
        rdvid = "-1";
        refreshRecord();
        setNormalMode();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void removeRec()
    {
        if (!rdvid.equals("-1"))
        {
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                MainClass.removeRdv(recurid, rdvid);
                recurid = "";
                MainClass.removeRdv(recurid, rdvid);
                bDeleted = true;
                refreshGrids();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        }
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }

    private void setTextToData()
    {
        telclient = txtTelephone.getText();
        if (bMois)
        {
            daterdv = txtDateMin1.getText();
            hdebut = txtHeureMin1.getText();
        }
        else
        {
            daterdv = txtDateMin.getText();
            hdebut = txtHeureMin.getText();
        }
        hdebut24 = FTime.set24Abrev(hdebut);
        if (!bMois)
        {
            hfin = txtHeureMax.getText();
            String hfin24 = FTime.set24Abrev(hfin);
            FTime fhd = new FTime(hdebut24);
            FTime fhf = new FTime(hfin24);
            int mnd = fhd.getHour() * 60 + fhd.getMinute();
            int mnf = fhf.getHour() * 60 + fhf.getMinute();
            duree = String.valueOf(mnf - mnd);
        }
        description = txtDescription.getText();
        etat = null2String(cboStatus.getSelectedItem());
        nomclient = txtClient.getText();
    }
    
    private void newClient()
    {
        nom = txtClient.getText();
        telclient = txtTelephone.getText();
        int pos = nom.indexOf(" ");
        if (pos>0)
        {
            prenom = nom.substring(pos+1);
            nom = nom.substring(0, pos);
        }
        telclient = txtTelephone.getText();
        DialogClient dlgCl = new DialogClient(this, true, "-1", nom, prenom, telclient);
    }
    
    public void setClient(String clid)
    {
        clientid = clid;
        nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
        telclient = starLoginManager.getStringFieldValue("clients", "PHONE", " WHERE ID=" + clientid);
        if (nomclient.equals("-1"))
            nomclient = "";
        if (telclient.equals("-1"))
            telclient = "";
        txtClient.setText(nomclient);
        txtTelephone.setText(telclient);
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("RendezVous"));
        cboDelais.setModel(new javax.swing.DefaultComboBoxModel(new String[] { bundle.getString("None"), "1 ".concat(bundle.getString("jour")), "2 ".concat(bundle.getString("jours")), "3 ".concat(bundle.getString("jours")), "4 ".concat(bundle.getString("jours")), "5 ".concat(bundle.getString("jours")), "6 ".concat(bundle.getString("jours")), "7 ".concat(bundle.getString("jours")) }));
        btnAddCommis.setText(bundle.getString("AddRecord"));
        btnRemoveCommis.setText(bundle.getString("RemoveRecord"));
        lblContact.setText(bundle.getString("Contact"));
        lblTelephone.setFont(new java.awt.Font("Arial", 1, 11));
        lblTelephone.setText(bundle.getString("Phone"));
        lblEtat.setText(bundle.getString("rdvSTATUS_"));
        lblDateMin.setText(bundle.getString("From"));
        txtDateMin.setToolTipText(bundle.getString("DateFormat"));
        lblDateMax.setText(bundle.getString("to"));
        btnRecur.setText(bundle.getString("Recurrence"));
        chkRecur.setToolTipText(bundle.getString("Recurrence"));
        btnRecur.setToolTipText(bundle.getString("Recurrence"));
        lblDescription.setText(bundle.getString("rdvDESCRIPTION"));
        lblDelais.setText(bundle.getString("DelaisRappel"));
        chkAllDay.setText(bundle.getString("AllDay"));
        btnOK.setText(bundle.getString("Valider"));
        btnCancel.setText(bundle.getString("Cancel"));
    }

    private void setDataToText()
    {
        bSetting = true;
        /*if (recurid == null || recurid.equals("") || recurid.equals("0") || recurid.equals("-1"))
            chkRecur.setSelected(false);
        else
            chkRecur.setSelected(true);*/
        setChkRecur();
        if (clientid.equals(""))
            clientid = "-1";
        nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
        if (nomclient.equals("-1"))
            nomclient = "";
        txtClient.setText(nomclient);
        txtTelephone.setText(telclient);
        if (etat == null || etat.equals("null") || etat.equals("") || etat.equals("-1"))
            cboStatus.setSelectedIndex(-1);
        else
            cboStatus.setSelectedItem(etat);
        String couleur = starLoginManager.getStringFieldValue("statutrdv", "COULEUR", " WHERE NOM='" + etat.replace("'", "''") + "'");
        cboStatus.setForeground(new Color(Integer.valueOf(couleur)));
        
        if (bolAdding && !bInit)
        {
            daterdv = MainClass.no2defaultDate("", MainClass.DATE_CURRENT);
            FTime ft = new FTime(FTime.curTime());
            hdebut = ft.getTime();
            double dfin = ft.getDecimalHour() + 1.0;
            if (dfin>=24.0)
                ft = new FTime(MainClass.STIME_235959);
            else
                ft = new FTime(dfin);
            hfin = ft.getTime();
            
            if (hdebut.length() == 8)
                hdebut = hdebut.substring(0,5);
            hdebut24 = hdebut;
            hdebut = FTime.formatAMPMAbrev(hdebut);
            if (hfin.length() == 8)
                hfin = hfin.substring(0,5);
            hfin = FTime.formatAMPMAbrev(hfin);
        }
        txtDateMin.setText(daterdv);
        txtHeureMin.setText(hdebut);
        txtDateMin1.setText(daterdv);
        txtHeureMin1.setText(hdebut);
        txtHeureMax.setText(hfin);
        int d = Integer.valueOf(duree).intValue();
        int dj = d/720;
        txtDemiJours.setText(String.valueOf(dj));
        setDateMax(dj);
        saveMin = hdebut;
        saveMax = hfin;
        txtDescription.setText(description);
        //txtMontant.setText(montant);
        if (hdebut.equals("00:00") && hfin.equals("23:59"))
        {
            txtHeureMin.setVisible(false);
            txtHeureMax.setVisible(false);
            chkAllDay.setSelected(true);
        }
        //cboDelais.setSelectedIndex(delais);
        bSetting = false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        grpTimeFormat = new javax.swing.ButtonGroup();
        jCheckBox1 = new javax.swing.JCheckBox();
        pnlHeader = new javax.swing.JPanel();
        pnlBoutons = new javax.swing.JPanel();
        btnAddCommis = new javax.swing.JButton();
        btnRemoveCommis = new javax.swing.JButton();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlData = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        lblContact = new javax.swing.JLabel();
        txtClient = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lblTelephone = new javax.swing.JLabel();
        txtTelephone = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        lblEtat = new javax.swing.JLabel();
        cboStatus = new javax.swing.JComboBox();
        jSeparator1 = new javax.swing.JSeparator();
        pnlDuree = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        lblDateMin = new javax.swing.JLabel();
        txtDateMin = new javax.swing.JTextField();
        txtHeureMin = new javax.swing.JTextField();
        pnlFin = new javax.swing.JPanel();
        lblDateMax = new javax.swing.JLabel();
        txtHeureMax = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        chkAllDay = new javax.swing.JCheckBox();
        chkRecur = new javax.swing.JCheckBox();
        btnRecur = new javax.swing.JButton();
        pnlDuree1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        lblDateMin1 = new javax.swing.JLabel();
        txtDateMin1 = new javax.swing.JTextField();
        txtHeureMin1 = new javax.swing.JTextField();
        pnlFin1 = new javax.swing.JPanel();
        lblDemiJours = new javax.swing.JLabel();
        txtDemiJours = new javax.swing.JTextField();
        lblDateMax1 = new javax.swing.JLabel();
        txtDateMax1 = new javax.swing.JTextField();
        pnlDelais = new javax.swing.JPanel();
        lblDelais = new javax.swing.JLabel();
        cboDelais = new javax.swing.JComboBox();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel6 = new javax.swing.JPanel();
        lblDescription = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescription = new javax.swing.JTextArea();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(530, 410));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
                formWindowClosing(evt);
            }
        });

        pnlHeader.setBackground(new java.awt.Color(255, 225, 220));
        pnlHeader.setLayout(new java.awt.BorderLayout());

        pnlBoutons.setPreferredSize(new java.awt.Dimension(520, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnAddCommis.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnAddCommis.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAddCommis.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddCommis.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAddCommis.setPreferredSize(new java.awt.Dimension(125, 32));
        btnAddCommis.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnAddCommisActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAddCommis);

        btnRemoveCommis.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnRemoveCommis.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemoveCommis.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemoveCommis.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemoveCommis.setPreferredSize(new java.awt.Dimension(125, 32));
        btnRemoveCommis.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnRemoveCommisActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemoveCommis);

        btnOK.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOK.setPreferredSize(new java.awt.Dimension(125, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(125, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        pnlHeader.add(pnlBoutons, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pnlHeader, java.awt.BorderLayout.NORTH);

        pnlData.setPreferredSize(new java.awt.Dimension(520, 360));
        pnlData.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblContact.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblContact.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblContact.setOpaque(true);
        lblContact.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel4.add(lblContact);

        txtClient.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtClient.setPreferredSize(new java.awt.Dimension(360, 22));
        txtClient.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                txtClientMouseClicked(evt);
            }
        });
        txtClient.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtClientKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtClientKeyPressed(evt);
            }
        });
        jPanel4.add(txtClient);

        pnlData.add(jPanel4);

        jPanel7.setPreferredSize(new java.awt.Dimension(470, 22));
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblTelephone.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblTelephone.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTelephone.setOpaque(true);
        lblTelephone.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel7.add(lblTelephone);

        txtTelephone.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtTelephone.setPreferredSize(new java.awt.Dimension(160, 22));
        txtTelephone.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                txtTelephoneMouseClicked(evt);
            }
        });
        txtTelephone.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtTelephoneKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtTelephoneKeyPressed(evt);
            }
        });
        jPanel7.add(txtTelephone);

        pnlData.add(jPanel7);

        jPanel9.setPreferredSize(new java.awt.Dimension(510, 23));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblEtat.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblEtat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEtat.setOpaque(true);
        lblEtat.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel9.add(lblEtat);

        cboStatus.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboStatus.setMaximumRowCount(20);
        cboStatus.setPreferredSize(new java.awt.Dimension(360, 22));
        cboStatus.setRenderer(new StarLogin.IHM.components.ComboStatusRenderer());
        cboStatus.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboStatusActionPerformed(evt);
            }
        });
        jPanel9.add(cboStatus);

        pnlData.add(jPanel9);

        jSeparator1.setPreferredSize(new java.awt.Dimension(510, 2));
        pnlData.add(jSeparator1);

        pnlDuree.setPreferredSize(new java.awt.Dimension(515, 23));
        pnlDuree.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel14.setPreferredSize(new java.awt.Dimension(170, 23));
        jPanel14.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin.setOpaque(true);
        lblDateMin.setPreferredSize(new java.awt.Dimension(30, 22));
        jPanel14.add(lblDateMin);

        txtDateMin.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDateMin.setName(""); // NOI18N
        txtDateMin.setPreferredSize(new java.awt.Dimension(70, 22));
        txtDateMin.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mousePressed(java.awt.event.MouseEvent evt)
            {
                txtDateMinMousePressed(evt);
            }
        });
        txtDateMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDateMinKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDateMinKeyPressed(evt);
            }
        });
        jPanel14.add(txtDateMin);

        txtHeureMin.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin.setName(""); // NOI18N
        txtHeureMin.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtHeureMinFocusLost(evt);
            }
        });
        txtHeureMin.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtHeureMinKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtHeureMinKeyPressed(evt);
            }
        });
        jPanel14.add(txtHeureMin);

        pnlDuree.add(jPanel14);

        pnlFin.setPreferredSize(new java.awt.Dimension(90, 23));
        pnlFin.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMax.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDateMax.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDateMax.setOpaque(true);
        lblDateMax.setPreferredSize(new java.awt.Dimension(20, 22));
        pnlFin.add(lblDateMax);

        txtHeureMax.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMax.setName(""); // NOI18N
        txtHeureMax.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMax.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtHeureMaxFocusLost(evt);
            }
        });
        txtHeureMax.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtHeureMaxKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtHeureMaxKeyTyped(evt);
            }
        });
        pnlFin.add(txtHeureMax);

        pnlDuree.add(pnlFin);

        jPanel2.setPreferredSize(new java.awt.Dimension(5, 10));
        pnlDuree.add(jPanel2);

        chkAllDay.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        chkAllDay.setPreferredSize(new java.awt.Dimension(125, 22));
        chkAllDay.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkAllDayActionPerformed(evt);
            }
        });
        pnlDuree.add(chkAllDay);

        chkRecur.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chkRecur.setPreferredSize(new java.awt.Dimension(24, 22));
        chkRecur.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                chkRecurActionPerformed(evt);
            }
        });
        pnlDuree.add(chkRecur);

        btnRecur.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnRecur.setPreferredSize(new java.awt.Dimension(100, 22));
        btnRecur.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnRecurActionPerformed(evt);
            }
        });
        pnlDuree.add(btnRecur);

        pnlData.add(pnlDuree);

        pnlDuree1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel15.setPreferredSize(new java.awt.Dimension(190, 23));
        jPanel15.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDateMin1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMin1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/flechedroite.png"))); // NOI18N
        lblDateMin1.setOpaque(true);
        lblDateMin1.setPreferredSize(new java.awt.Dimension(50, 22));
        jPanel15.add(lblDateMin1);

        txtDateMin1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDateMin1.setName(""); // NOI18N
        txtDateMin1.setPreferredSize(new java.awt.Dimension(70, 22));
        txtDateMin1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mousePressed(java.awt.event.MouseEvent evt)
            {
                txtDateMin1MousePressed(evt);
            }
        });
        txtDateMin1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDateMin1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDateMin1KeyTyped(evt);
            }
        });
        jPanel15.add(txtDateMin1);

        txtHeureMin1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtHeureMin1.setName(""); // NOI18N
        txtHeureMin1.setPreferredSize(new java.awt.Dimension(70, 22));
        txtHeureMin1.addFocusListener(new java.awt.event.FocusAdapter()
        {
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                txtHeureMin1FocusLost(evt);
            }
        });
        txtHeureMin1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtHeureMin1KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtHeureMin1KeyPressed(evt);
            }
        });
        jPanel15.add(txtHeureMin1);

        pnlDuree1.add(jPanel15);

        pnlFin1.setPreferredSize(new java.awt.Dimension(320, 23));
        pnlFin1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblDemiJours.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDemiJours.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDemiJours.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDemiJours.setOpaque(true);
        lblDemiJours.setPreferredSize(new java.awt.Dimension(130, 22));
        pnlFin1.add(lblDemiJours);

        txtDemiJours.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDemiJours.setName(""); // NOI18N
        txtDemiJours.setPreferredSize(new java.awt.Dimension(40, 22));
        txtDemiJours.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDemiJoursKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDemiJoursKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt)
            {
                txtDemiJoursKeyReleased(evt);
            }
        });
        pnlFin1.add(txtDemiJours);

        lblDateMax1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateMax1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/flechedroite.png"))); // NOI18N
        lblDateMax1.setOpaque(true);
        lblDateMax1.setPreferredSize(new java.awt.Dimension(40, 22));
        pnlFin1.add(lblDateMax1);

        txtDateMax1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDateMax1.setName(""); // NOI18N
        txtDateMax1.setPreferredSize(new java.awt.Dimension(70, 22));
        txtDateMax1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mousePressed(java.awt.event.MouseEvent evt)
            {
                txtDateMax1MousePressed(evt);
            }
        });
        txtDateMax1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDateMax1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDateMax1KeyTyped(evt);
            }
        });
        pnlFin1.add(txtDateMax1);

        pnlDuree1.add(pnlFin1);

        pnlData.add(pnlDuree1);

        pnlDelais.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblDelais.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDelais.setPreferredSize(new java.awt.Dimension(270, 22));
        pnlDelais.add(lblDelais);

        cboDelais.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        cboDelais.setKeySelectionManager(new MultiKeySelectionManager());
        cboDelais.setPreferredSize(new java.awt.Dimension(240, 22));
        cboDelais.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cboDelaisActionPerformed(evt);
            }
        });
        pnlDelais.add(cboDelais);

        pnlData.add(pnlDelais);

        jSeparator2.setPreferredSize(new java.awt.Dimension(510, 2));
        pnlData.add(jSeparator2);

        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblDescription.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblDescription.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDescription.setOpaque(true);
        lblDescription.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel6.add(lblDescription);

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(360, 150));

        txtDescription.setColumns(20);
        txtDescription.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        txtDescription.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                txtDescriptionKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                txtDescriptionKeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(txtDescription);

        jPanel6.add(jScrollPane1);

        pnlData.add(jPanel6);

        getContentPane().add(pnlData, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddCommisActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddCommisActionPerformed
    {//GEN-HEADEREND:event_btnAddCommisActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddCommisActionPerformed

    private void btnRemoveCommisActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveCommisActionPerformed
    {//GEN-HEADEREND:event_btnRemoveCommisActionPerformed
        removeRec();
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnRemoveCommisActionPerformed

    private void txtClientKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtClientKeyPressed
    {//GEN-HEADEREND:event_txtClientKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtClient.setText(nomclient);
        }
        else if (evt.getKeyCode() == KeyEvent.VK_ENTER)
        {
            String strText = MainClass.getLookForField(txtClient, "clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END", bundle.getString("rdvNOM_CLIENT"), true, bundle.getString("NewClient"), false, null, false);
            if (strText.equals(""))
                return;
            String id = MainClass.starLoginManager.getMainFieldID_S("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END", strText);
            if (!id.equals("-1"))
            {
                strText = strText.replace("  ", " ");
                int pos = strText.indexOf(" || ");
                if (pos>0)
                    strText = strText.substring(0, pos);
                txtClient.setText(strText);
                nomclient = strText;
                clientid = id;
                telclient = MainClass.starLoginManager.getStringFieldValue("clients", "PHONE", " WHERE ID=" + clientid);
                if (telclient.equals("")||telclient.equals("-1"))
                {
                    telclient = MainClass.starLoginManager.getStringFieldValue("clients", "TELBUREAU", " WHERE ID=" + clientid);
                    if (telclient.equals("")||telclient.equals("-1"))
                    {
                        telclient = MainClass.starLoginManager.getStringFieldValue("clients", "CELL", " WHERE ID=" + clientid);
                        if (telclient.equals("-1"))
                            telclient = "";
                    }
                }
                txtTelephone.setText(telclient);
            }
            else
            {
                //txtClient.setText(bundle.getString("NewClient"));
                clientid = "-1";
                newClient();
                //clientid = "-1";
            }
            bolEditing = true;
            setEditMode();
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtClientKeyPressed

    private void cboStatusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboStatusActionPerformed
    {//GEN-HEADEREND:event_cboStatusActionPerformed
        if (bSetting)
            return;
        if (null2String(cboStatus.getSelectedItem()).equals(bundle.getString("NewRdvStatus")))
        {
            String result = "";
            while (result == null || result.equals(""))
            {
                result = JOptionPane.showInputDialog(bundle.getString("EnterNewRdvStatus"));
                if (result == null)
                {
                    bSetting = true;
                    cboStatus.setSelectedIndex(-1);
                    bSetting = false;
                    return;
                }
            }
            starLoginManager.updateDataBase("INSERT INTO statutrdv(NOM) VALUES('" + result.replace("'", "''") + "')");
            DialogColor dlgColor = new DialogColor(this, true, color);
            if (color == null)
                return;
            String couleur = Integer.toString(color.getRGB());
            starLoginManager.updateDataBase("UPDATE statutrdv set COULEUR = " + couleur + " WHERE NOM='" + result.replace("'", "''") + "'");
            cboStatus.setForeground(color);
            setStatus(true);
            cboStatus.setSelectedItem(result);
        }
        else
        {
            etat = null2String(cboStatus.getSelectedItem());
            String couleur = starLoginManager.getStringFieldValue("statutrdv", "COULEUR", " WHERE NOM='" + etat.replace("'", "''") + "'");
            color = new Color(Integer.valueOf(couleur));
            cboStatus.setForeground(color);
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_cboStatusActionPerformed

    public void setColor(Color color)
    {
        this.color = color;
    }
    
    public void setStatus(boolean reset)
    {
        if (reset)
        {
            cboStatus.removeAllItems();
        }
        DefaultComboBoxModel comboModel = starLoginManager.getListe("SELECT NOM FROM statutrdv WHERE NOM is not null");
        comboModel.addElement(bundle.getString("NewRdvStatus"));
        cboStatus.setModel(comboModel);
    }
    
    private void txtDateMinMousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMinMousePressed
    {//GEN-HEADEREND:event_txtDateMinMousePressed
        if (evt.getButton() == 1)
        {
            String sdate = txtDateMin.getText();
            daterdv = DlgCalendar.ShowCalendar(sdate);
            daterdv = MainClass.getFormatedDate(daterdv);
            txtDateMin.setText(daterdv);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateMinMousePressed

    private void txtDateMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyPressed
    {//GEN-HEADEREND:event_txtDateMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMin.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateMin.setText(daterdv);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDate(evt, txtDateMin, kc);
        }
    }//GEN-LAST:event_txtDateMinKeyPressed

    private void txtDateMinKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMinKeyTyped
    {//GEN-HEADEREND:event_txtDateMinKeyTyped
        KTDate d = new KTDate(evt, txtDateMin, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMin.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMinKeyTyped

    private void txtHeureMinFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMinFocusLost
    {//GEN-HEADEREND:event_txtHeureMinFocusLost
        hdebut = txtHeureMin.getText();
        hdebut = FTime.formatTimeAbrev(hdebut);
        txtHeureMin.setText(hdebut);
        saveMin = hdebut;
        hdebut24 = FTime.set24Abrev(hdebut);
    }//GEN-LAST:event_txtHeureMinFocusLost

    private void txtHeureMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMinKeyPressed
    {//GEN-HEADEREND:event_txtHeureMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin.setText(hdebut);
        }
        else
        {
            bolEditing = true;
            KTTimeAbrev t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTimeAbrev(evt, txtHeureMin, kc);
            setEditMode();
        }
    }//GEN-LAST:event_txtHeureMinKeyPressed

    private void txtHeureMinKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMinKeyTyped
    {//GEN-HEADEREND:event_txtHeureMinKeyTyped
        KTTimeAbrev t = new KTTimeAbrev(evt, txtHeureMin, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMinKeyTyped

    private void txtHeureMaxFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMaxFocusLost
    {//GEN-HEADEREND:event_txtHeureMaxFocusLost
        hfin = txtHeureMax.getText();
        hfin = FTime.formatTimeAbrev(hfin);
        setDuree();
        saveMax = hfin;
        txtHeureMax.setText(hfin);
    }//GEN-LAST:event_txtHeureMaxFocusLost

    private void txtHeureMaxKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMaxKeyPressed
    {//GEN-HEADEREND:event_txtHeureMaxKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMax.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMax.setText(hfin);
        }
        else
        {
            bolEditing = true;
            KTTimeAbrev t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTimeAbrev(evt, txtHeureMax, kc);
            setEditMode();
        }
    }//GEN-LAST:event_txtHeureMaxKeyPressed

    private void txtHeureMaxKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMaxKeyTyped
    {//GEN-HEADEREND:event_txtHeureMaxKeyTyped
        KTTimeAbrev t = new KTTimeAbrev(evt, txtHeureMax, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMax.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMaxKeyTyped

    private void chkRecurActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkRecurActionPerformed
    {//GEN-HEADEREND:event_chkRecurActionPerformed
        if (bSetting)
        {
            return;
        }
        bolEditing = true;
        setEditMode();
        if (chkRecur.isSelected())
        {
            if (rdvid.equals("-1"))
            {
                int result = JOptionPane.YES_OPTION;
                if (cboStatus.getSelectedIndex()<0)
                    result = JOptionPane.showConfirmDialog(this, bundle.getString("SurDeRecurSansEtat"), bundle.getString("RecurSansEtat"), JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (result == JOptionPane.YES_OPTION && save(false))
                {
                    DialogRecur dlgRecur = new DialogRecur(this, true, rdvid, recurid);
                    refreshGrids();
                }
            }
            else
            {
                DialogRecur dlgRecur = new DialogRecur(this, true, rdvid, recurid);
                refreshGrids();
            }
        }
        else
        {
            MainClass.removeRdv(recurid, rdvid);
            refreshGrids();
        }
    }//GEN-LAST:event_chkRecurActionPerformed

    private void txtDescriptionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDescriptionKeyPressed
    {//GEN-HEADEREND:event_txtDescriptionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDescription.setText(description);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDescriptionKeyPressed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save(true)== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        refreshGrids();
    }//GEN-LAST:event_formWindowClosing

    private void txtClientKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtClientKeyTyped
    {//GEN-HEADEREND:event_txtClientKeyTyped
        int size = new Integer(String.valueOf(rdvs.getSizes().get(9))).intValue();
        if (txtClient.getText().length() >= size)
        {
            txtClient.setText(txtClient.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtClientKeyTyped

    private void txtDescriptionKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDescriptionKeyTyped
    {//GEN-HEADEREND:event_txtDescriptionKeyTyped
        int size = new Integer(String.valueOf(rdvs.getSizes().get(6))).intValue();
        if (txtDescription.getText().length() >= size)
        {
            txtDescription.setText(txtDescription.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtDescriptionKeyTyped

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        if (parentForm instanceof GestionTempsForm)
            ((GestionTempsForm)parentForm).setPopMenuInvisible();
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        if (parentForm instanceof GestionTempsForm)
            ((GestionTempsForm)parentForm).setPopMenuInvisible();
        if (save(true))
        {
            setVisible(false);
            dispose();
        }
    }//GEN-LAST:event_btnOKActionPerformed

    private void chkAllDayActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkAllDayActionPerformed
    {//GEN-HEADEREND:event_chkAllDayActionPerformed
        if(chkAllDay.isSelected())
        {
            txtHeureMin.setText("00:00");
            txtHeureMax.setText("23:59");
            txtHeureMin.setVisible(false);
            txtHeureMax.setVisible(false);
        }
        else
        {
            txtHeureMin.setText(saveMin);
            txtHeureMax.setText(saveMax);
            txtHeureMin.setVisible(true);
            txtHeureMax.setVisible(true);
        }
        pnlDuree.paintAll(pnlDuree.getGraphics());
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_chkAllDayActionPerformed

    private void cboDelaisActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboDelaisActionPerformed
    {//GEN-HEADEREND:event_cboDelaisActionPerformed
        if (bSetting)
        {
            return;
        }
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_cboDelaisActionPerformed

    private void btnRecurActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRecurActionPerformed
    {//GEN-HEADEREND:event_btnRecurActionPerformed
        if (bSetting)
        {
            return;
        }
        if (rdvid.equals("-1"))
        {
            int result = JOptionPane.YES_OPTION;
            if (cboStatus.getSelectedIndex()<0)
                result = JOptionPane.showConfirmDialog(this, bundle.getString("SurDeRecurSansEtat"), bundle.getString("RecurSansEtat"), JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (result == JOptionPane.YES_OPTION && save(true))
            {
                DialogRecur dlgRecur = new DialogRecur(this, true, rdvid, recurid);
                refreshGrids();
                /*if (!chkRecur.isSelected())
                {
                    bSetting = true;
                    chkRecur.setSelected(true);
                    bSetting = false;
                }*/
                
            }
        }
        else
        {
            DialogRecur dlgRecur = new DialogRecur(this, true, rdvid, recurid);
            refreshGrids();
            //setChkRecur();
        }
    }//GEN-LAST:event_btnRecurActionPerformed

    private void txtDateMin1MousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMin1MousePressed
    {//GEN-HEADEREND:event_txtDateMin1MousePressed
        if (evt.getButton() == 1)
        {
            String sdate = txtDateMin1.getText();
            daterdv = DlgCalendar.ShowCalendar(sdate);
            daterdv = MainClass.getFormatedDate(daterdv);
            txtDateMin1.setText(daterdv);
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateMin1MousePressed

    private void txtDateMin1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMin1KeyPressed
    {//GEN-HEADEREND:event_txtDateMin1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMin1.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateMin1.setText(daterdv);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDate(evt, txtDateMin1, kc);
        }
    }//GEN-LAST:event_txtDateMin1KeyPressed

    private void txtDateMin1KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMin1KeyTyped
    {//GEN-HEADEREND:event_txtDateMin1KeyTyped
        KTDate d = new KTDate(evt, txtDateMin1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMin1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMin1KeyTyped

    private void txtHeureMin1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHeureMin1FocusLost
    {//GEN-HEADEREND:event_txtHeureMin1FocusLost
        hdebut = txtHeureMin1.getText();
        hdebut = FTime.formatTimeAbrev(hdebut);
        if (!bMois)
        {
            txtHeureMin1.setText(hdebut);
            saveMin = hdebut;
            hdebut24 = FTime.set24Abrev(hdebut);
        }
        else
        {
            hdebut24 = FTime.set24Abrev(hdebut);
            FTime tdebut = new FTime(hdebut24);
            int heure = tdebut.getHour();
            if (heure<12)
                hdebut24 = "00:00";
            else
                hdebut24 = "12:00";
            hdebut = FTime.formatAMPMAbrev(hdebut24);
            txtHeureMin1.setText(hdebut);
            saveMin = hdebut;
        }
        String demijours = txtDemiJours.getText();
        if (demijours.equals(""))
            demijours = "0";
        int dj = Integer.valueOf(demijours).intValue();
        setDateMax(dj);
    }//GEN-LAST:event_txtHeureMin1FocusLost

    private void txtHeureMin1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin1KeyPressed
    {//GEN-HEADEREND:event_txtHeureMin1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtHeureMin1.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtHeureMin1.setText(hdebut);
        }
        else
        {
            bolEditing = true;
            KTTimeAbrev t;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                t = new KTTimeAbrev(evt, txtHeureMin1, kc);
            setEditMode();
        }
    }//GEN-LAST:event_txtHeureMin1KeyPressed

    private void txtHeureMin1KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHeureMin1KeyTyped
    {//GEN-HEADEREND:event_txtHeureMin1KeyTyped
        KTTimeAbrev t = new KTTimeAbrev(evt, txtHeureMin1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtHeureMin1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtHeureMin1KeyTyped

    private void txtDemiJoursKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDemiJoursKeyPressed
    {//GEN-HEADEREND:event_txtDemiJoursKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            if (duree.equals(""))
                duree = "0";
            int d = Integer.valueOf(duree).intValue();
            txtDemiJours.setText(String.valueOf(d/720));
            txtDateMax1.setText(daterdv);
        }
        else
        {
            bolEditing = true;
            if (evt.getKeyCode() == KeyEvent.VK_DOWN || evt.getKeyCode() == KeyEvent.VK_UP)
            {
                int dj = getDemiJours();
                int nbjoursdansmois = getNbJoursDansMois();
                if (evt.getKeyCode() == KeyEvent.VK_DOWN)
                {
                    dj += 1;
                    if (dj>nbjoursdansmois)
                        dj = nbjoursdansmois;
                }
                else if (evt.getKeyCode() == KeyEvent.VK_UP)
                {
                    dj -= 1;
                    if (dj < 0)
                        dj = 0;
                }
                
                String value = String.valueOf(dj);
                txtDemiJours.setText(value);
                duree = String.valueOf(dj * 720);
                setDateMax(dj);
                setEditMode();
            }
        }
    }//GEN-LAST:event_txtDemiJoursKeyPressed

    private int getDemiJours()
    {
        String demijours = txtDemiJours.getText();
        if (demijours.equals(""))
        {
            demijours = "0";
        }
        int dj = Integer.valueOf(demijours).intValue();
        return dj;
    }
    private int getNbJoursDansMois()
    {
        FDate fd = new FDate(daterdv);
        double jd;
        double ddate;
        long month = fd.getMonth();
        long year = fd.getYear();

        //last day of the month
        if (month < 12)
        {
            jd = AstronomyMaths.gregorianToJulian(1l, month + 1l, year) - 1; //from january to november
        }
        else
        {
            jd = AstronomyMaths.gregorianToJulian(1l, 1l, year + 1l) - 1;   //december
        }
        ddate = AstronomyMaths.julianToGregorian(jd);
        fd = new FDate(ddate);
        int nbjoursdansmois = (int) fd.getDay();
        return nbjoursdansmois;
    }
    private void setDateMax(int dj)
    {
        FDate fd = new FDate(daterdv);
        long dm = fd.getDay();
        long month = fd.getMonth();
        long year = fd.getYear();
        double jd = AstronomyMaths.gregorianToJulian(dm, month, year); //from january to november
        FTime tdebut = new FTime(hdebut24);
        int hdeb = tdebut.getHour();
        if (hdeb >= 12)
            jd += 0.5;
        jd += ((double) dj) / 2.0;
        jd -= 0.5;// pour eliminer la borne sup
        double ddate = AstronomyMaths.julianToGregorian(jd);
        fd = new FDate(ddate);
        txtDateMax1.setText(fd.getFormatedDate());
    }
    private void txtDemiJoursKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDemiJoursKeyTyped
    {//GEN-HEADEREND:event_txtDemiJoursKeyTyped
        KTInteger t = new KTInteger(evt, txtDemiJours, 3, kc);
    }//GEN-LAST:event_txtDemiJoursKeyTyped

    private void txtDateMax1MousePressed(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtDateMax1MousePressed
    {//GEN-HEADEREND:event_txtDateMax1MousePressed
        if (evt.getButton() == 1)
        {
            String sdate = txtDateMax1.getText();
            String datemax = DlgCalendar.ShowCalendar(sdate);
            datemax = MainClass.getFormatedDate(datemax);
            txtDateMax1.setText(datemax);
            String snbj = MainClass.diffDates(daterdv, datemax);
            if (snbj.equals(""))
                snbj = "0";
            int nbj = Integer.valueOf(snbj).intValue() + 1;
            int dj = nbj * 2;
            FTime tdebut = new FTime(hdebut24);
            int hdeb = tdebut.getHour();
            if (hdeb>=12)
                dj -= 1;
            duree = String.valueOf(dj*720);
            txtDemiJours.setText(String.valueOf(dj));
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtDateMax1MousePressed

    private void txtDateMax1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMax1KeyPressed
    {//GEN-HEADEREND:event_txtDateMax1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtDateMax1.getCaretPosition();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtDateMax1.setText(daterdv);
        }
        else
        {
            bolEditing = true;
            setEditMode();
            KTDate td;
            if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                td = new KTDate(evt, txtDateMax1, kc);
        }
    }//GEN-LAST:event_txtDateMax1KeyPressed

    private void txtDateMax1KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDateMax1KeyTyped
    {//GEN-HEADEREND:event_txtDateMax1KeyTyped
        KTDate d = new KTDate(evt, txtDateMax1, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtDateMax1.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtDateMax1KeyTyped

    private void txtDemiJoursKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDemiJoursKeyReleased
    {//GEN-HEADEREND:event_txtDemiJoursKeyReleased
        int dj = getDemiJours();
        String value = String.valueOf(dj);
        txtDemiJours.setText(value);
        duree = String.valueOf(dj * 720);
        setDateMax(dj);
        setEditMode();
    }//GEN-LAST:event_txtDemiJoursKeyReleased

    private void txtTelephoneKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelephoneKeyPressed
    {//GEN-HEADEREND:event_txtTelephoneKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtTelephone.setText(telclient);
        }
        else if (evt.getKeyCode() == KeyEvent.VK_ENTER)
        {
            String defautval = txtTelephone.getText();
            DefaultComboBoxModel model = starLoginManager.getListe("SELECT PHONE||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients WHERE PHONE Like '" + defautval + "%'  UNION SELECT TELBUREAU||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients WHERE TELBUREAU Like '" + defautval + "%'  UNION SELECT CELL||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients WHERE CELL Like '" + defautval + "%'");
            String strText = MainClass.getLookForField2(txtTelephone, model, "clients", "PHONE");
            if (strText.equals(""))
            {
                return;
            }
            String id = starLoginManager.getMainFieldID_S("clients", "PHONE||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
            if (!id.equals("-1"))
            {
                int pos = strText.indexOf(" || ");
                if (pos > 0)
                {
                    strText = strText.substring(0, pos);
                }
                txtTelephone.setText(strText);
                telclient = strText;
                clientid = id;
                nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                if (nomclient.equals("-1"))
                {
                    nomclient = "";
                }
                txtClient.setText(nomclient);
            }
            else
            {
                id = starLoginManager.getMainFieldID_S("clients", "TELBUREAU||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
                if (!id.equals("-1"))
                {
                    int pos = strText.indexOf(" || ");
                    if (pos > 0)
                    {
                        strText = strText.substring(0, pos);
                    }
                    txtTelephone.setText(strText);
                    telclient = strText;
                    clientid = id;
                    nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                    if (nomclient.equals("-1"))
                    {
                        nomclient = "";
                    }
                    txtClient.setText(nomclient);
                }
                else
                {
                    id = starLoginManager.getMainFieldID_S("clients", "CELL||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
                    if (!id.equals("-1"))
                    {
                        int pos = strText.indexOf(" || ");
                        if (pos > 0)
                        {
                            strText = strText.substring(0, pos);
                        }
                        txtTelephone.setText(strText);
                        telclient = strText;
                        clientid = id;
                        nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                        if (nomclient.equals("-1"))
                        {
                            nomclient = "";
                        }
                        txtClient.setText(nomclient);
                    }
                    else
                    {
                        clientid = "-1";
                        newClient();
                    }
                }
            }
            bolEditing = true;
            setEditMode();
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtTelephoneKeyPressed

    private void txtTelephoneKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTelephoneKeyTyped
    {//GEN-HEADEREND:event_txtTelephoneKeyTyped
        int size = new Integer(String.valueOf(rdvs.getSizes().get(2))).intValue();
        if (txtTelephone.getText().length() >= size)
        {
            txtTelephone.setText(txtTelephone.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtTelephoneKeyTyped

    private void txtTelephoneMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtTelephoneMouseClicked
    {//GEN-HEADEREND:event_txtTelephoneMouseClicked
        if (evt.getClickCount() == 2)
        {
            String defautval = txtTelephone.getText();
            DefaultComboBoxModel model = starLoginManager.getListe("SELECT PHONE||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients UNION SELECT TELBUREAU||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients UNION SELECT CELL||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END AS TEL FROM clients");
            String strText = MainClass.getLookForField2(txtTelephone, model, "clients", "PHONE");
            if (strText.equals(""))
            {
                return;
            }
            String id = starLoginManager.getMainFieldID_S("clients", "PHONE||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
            if (!id.equals("-1"))
            {
                int pos = strText.indexOf(" || ");
                if (pos > 0)
                {
                    strText = strText.substring(0, pos);
                }
                txtTelephone.setText(strText);
                telclient = strText;
                clientid = id;
                nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                if (nomclient.equals("-1"))
                {
                    nomclient = "";
                }
                txtClient.setText(nomclient);
            }
            else
            {
                id = starLoginManager.getMainFieldID_S("clients", "TELBUREAU||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
                if (!id.equals("-1"))
                {
                    int pos = strText.indexOf(" || ");
                    if (pos > 0)
                    {
                        strText = strText.substring(0, pos);
                    }
                    txtTelephone.setText(strText);
                    telclient = strText;
                    clientid = id;
                    nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                    if (nomclient.equals("-1"))
                    {
                        nomclient = "";
                    }
                    txtClient.setText(nomclient);
                }
                else
                {
                    id = starLoginManager.getMainFieldID_S("clients", "CELL||' || '||CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", strText);
                    if (!id.equals("-1"))
                    {
                        int pos = strText.indexOf(" || ");
                        if (pos > 0)
                        {
                            strText = strText.substring(0, pos);
                        }
                        txtTelephone.setText(strText);
                        telclient = strText;
                        clientid = id;
                        nomclient = starLoginManager.getStringFieldValue("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END", " WHERE ID=" + clientid);
                        if (nomclient.equals("-1"))
                        {
                            nomclient = "";
                        }
                        txtClient.setText(nomclient);
                    }
                    else
                    {
                        clientid = "-1";
                        newClient();
                    }
                }
            }
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtTelephoneMouseClicked

    private void txtClientMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtClientMouseClicked
    {//GEN-HEADEREND:event_txtClientMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtClient, "clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END", bundle.getString("rdvNOM_CLIENT"), false, bundle.getString("NewClient"), false, null, false);
            if (strText.equals(""))
                return;
            String id = MainClass.starLoginManager.getMainFieldID_S("clients", "CASE WHEN FIRSTNAME IS NULL THEN''ELSE FIRSTNAME END||' '||CASE WHEN OTHERNAMES IS NULL THEN''ELSE OTHERNAMES END||' || '||CASE WHEN BIRTHDATE IS NULL THEN''ELSE BIRTHDATE END", strText);
            if (!id.equals("-1"))
            {
                strText = strText.replace("  ", " ");
                int pos = strText.indexOf(" || ");
                if (pos>0)
                    strText = strText.substring(0, pos);
                txtClient.setText(strText);
                nomclient = strText;
                clientid = id;
                telclient = MainClass.starLoginManager.getStringFieldValue("clients", "PHONE", " WHERE ID=" + clientid);
                if (telclient.equals("")||telclient.equals("-1"))
                {
                    telclient = MainClass.starLoginManager.getStringFieldValue("clients", "TELBUREAU", " WHERE ID=" + clientid);
                    if (telclient.equals("")||telclient.equals("-1"))
                    {
                        telclient = MainClass.starLoginManager.getStringFieldValue("clients", "CELL", " WHERE ID=" + clientid);
                        if (telclient.equals("-1"))
                            telclient = "";
                    }
                }
                txtTelephone.setText(telclient);
            }
            else
            {
                //txtClient.setText(bundle.getString("NewClient"));
                clientid = "-1";
                newClient();
                //clientid = "-1";
            }
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtClientMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddCommis;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnRecur;
    private javax.swing.JButton btnRemoveCommis;
    private javax.swing.JComboBox cboDelais;
    private javax.swing.JComboBox cboStatus;
    private javax.swing.JCheckBox chkAllDay;
    private javax.swing.JCheckBox chkRecur;
    private javax.swing.ButtonGroup grpTimeFormat;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblContact;
    private javax.swing.JLabel lblDateMax;
    private javax.swing.JLabel lblDateMax1;
    private javax.swing.JLabel lblDateMin;
    private javax.swing.JLabel lblDateMin1;
    private javax.swing.JLabel lblDelais;
    private javax.swing.JLabel lblDemiJours;
    private javax.swing.JLabel lblDescription;
    private javax.swing.JLabel lblEtat;
    private javax.swing.JLabel lblTelephone;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlDelais;
    private javax.swing.JPanel pnlDuree;
    private javax.swing.JPanel pnlDuree1;
    private javax.swing.JPanel pnlFin;
    private javax.swing.JPanel pnlFin1;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JTextField txtClient;
    private javax.swing.JTextField txtDateMax1;
    private javax.swing.JTextField txtDateMin;
    private javax.swing.JTextField txtDateMin1;
    private javax.swing.JTextField txtDemiJours;
    private javax.swing.JTextArea txtDescription;
    private javax.swing.JTextField txtHeureMax;
    private javax.swing.JTextField txtHeureMin;
    private javax.swing.JTextField txtHeureMin1;
    private javax.swing.JTextField txtTelephone;
    // End of variables declaration//GEN-END:variables
}
