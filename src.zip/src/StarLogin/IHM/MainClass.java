package StarLogin.IHM;

import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.Astrobj;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Option;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.Enum.OS;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.Systeme.iofiles.FileAccess;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class MainClass extends Applet
{
    private static final java.util.Timer timer = new java.util.Timer();
    public static Locale spainLocale = new Locale("es");
    public static Font starlogfont;
    public static StarLoginManager starLoginManager;
    public static final int RDVNOWARNING = 0;
    public static final int RDVGLOBALWARNING = 1;
    public static final int RDVEVERYWARNING = 2;
    public static int rdvwarning = RDVNOWARNING;
    public static int rdvdelai = 5;
    private static int choixAction = 0;
    private static boolean bfirstlaunch = false;
    private static Option currentOption;
    public static MainForm mainForm;
    public static String currentEventID = "1";
    private static DataBaseRecord dbrOptions;
    public static StarLogin.Systeme.Data.Event event;
    public static Options options;
    public static Locale locale = Locale.ENGLISH;
    public static java.util.ResourceBundle bundle;
    public String currentDirectory = null;
    public static final int TIME12 = 1;
    public static final int TIME24 = 0;
    public static final int DATE_1950 = 0;
    public static final int DATE_CURRENT = 1;
    public static final int DATE_1900 = 2;
    public static final int DATE_2000 = 3;
    public static final String SDATE_1900 = "1900-01-01";
    public static final String SDATE_1950 = "1950-01-01";
    public static final String SDATE_2000 = "2000-01-01";
    public static final int TIME_000000 = 0;
    public static final int TIME_CURRENT = 1;
    public static final int TIME_235959 = 2;
    public static final int TIME_120000 = 3;
    public static final int TIME_240000 = 4;
    public static final String STIME_235959 = "23:59:59";
    public static final String STIME_120000 = "12:00:00";
    public static final String STIME_000000 = "00:00:00";
    public static final String STIME_240000 = "24:00:00";
    public static int timeType = TIME24;
    public static final int DATEFR = 1;
    public static final int DATEUS = 0;
    public static int dateType = DATEUS;
    private static Date firstTime;
    private static boolean bWarningDone = false;
    private static GregorianCalendar gc;
    private static String sfirstDate;
    public static String langue = "en";
    public static final int SAVEDATA_ASK = 0;
    public static final int SAVEDATA_AUTO = 1;
    public static int askToSave = SAVEDATA_ASK;

    //Name of signes//data for planetary calculations
    public static Astrobj[] astrobj = new Astrobj[Planets.Chiron+1];
    
    public static Option getCurrentOption()
    {
        return currentOption;
    }
    
    public static void setCurrentOption(Option option)
    {
        currentOption = option;
    }
    
    public static void setChoix(int choix)
    {
        choixAction = choix;
    }
    
    /** Creates new MainClass */
    public void MainClass()
    {
    }
    
    private static void setAstrobj()
    {
        astrobj[Planets.Sun] = new Astrobj(279.6964027, 358.4758635, 0, 36000.7695173, 35999.0494965, 0, 1);
        astrobj[Planets.Moon] = new Astrobj(270.435377, 0, 0, 481267.880863, 0, 0, 0.0748);
        astrobj[Planets.Mercury] = new Astrobj(178.178814, 102.279426, 131.032888, 149474.071386, 149472.515334, 149472.885872, 0.24084);
        astrobj[Planets.Venus] = new Astrobj(342.766738, 212.6018923, 266.987445, 58519.212542, 58517.8063877, 58518.311835, 0.61515);
        astrobj[Planets.Mars] = new Astrobj(293.747201, 319.5292728, 244.960887, 19141.699879, 19139.8588872, 19140.928953, 1.8808);
        astrobj[Planets.Jupiter] = new Astrobj(237.352259, 225.44453943, 138.419219, 3034.9066206, 3034.90662057, 3034.9066206, 11.862);
        astrobj[Planets.Saturn] = new Astrobj(265.869357, 175.758477, 153.521637, 1222.116843, 1222.116843, 1222.116843, 29.456);
        astrobj[Planets.Uranus] = new Astrobj(243.362437, 74.313637, 169.872293, 429.898403, 429.898403, 429.388747, 84.07);
        astrobj[Planets.Neptune] = new Astrobj(85.024943, 41.269103, 314.346275, 219.863377, 219.863377, 218.761885, 164.81);
        astrobj[Planets.Pluto] = new Astrobj(92.312712, 229.488633, 343.369233, 146.674728, 145.278567, 145.278567, 248.53);
        astrobj[Planets.Gaia] = new Astrobj(0, 0, 0, 0, 0, 0, 1);
        astrobj[Planets.NorthNode] = new Astrobj(0, 0, 0, 0, 0, 0, -18.614);
        astrobj[Planets.Lilith] = new Astrobj(0, 0, 0, 0, 0, 0, 8.8464);
        astrobj[Planets.East] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Zenith] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Vertex] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Vulcan] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.OtherPoint] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Ceres] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Pallas] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Juno] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Vesta] = new Astrobj(0, 0, 0, 0, 0, 0, 0);
        astrobj[Planets.Chiron] = new Astrobj(0, 0, 0, 0, 0, 0, 52);
    }
    
    @SuppressWarnings("unchecked")
    public static void main(String args[])
    {
        String vers = System.getProperty("java.version");
        String languefilename = new File("langue.txt").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
        
        File langueFile = new File(languefilename);
        if (!langueFile.exists())
        {
            bfirstlaunch = true;
            locale = Locale.getDefault();
            if (locale.getLanguage().equals(Locale.FRENCH.getLanguage()))
            {
                locale = Locale.FRENCH;
                langue = "fr";
            }
            /*else if (locale.getLanguage().equals(spainLocale.getLanguage()))
            {
                langue = "es";
                locale = spainLocale;
            }*/
            else
            {
                locale = Locale.ENGLISH;
                langue = "en";
            }
            FileAccess.writeFile(languefilename, MainClass.langue);
        }
        else
        {
            langue = FileAccess.readFile(languefilename, 1000);
            if (langue.length()>1)
                langue = langue.substring(0, 2);
            if (langue.equals("fr"))
                locale = Locale.FRENCH;
            //else if (langue.equals("es"))
            //    locale = spainLocale;
            else
                locale = Locale.ENGLISH;
        }

        bundle = ResourceBundle.getBundle("StarLogin/internationalization/Resources", locale);
        
        if (bfirstlaunch)
        {
            DlgParams dlgParams = new DlgParams(new JFrame(), true);
        }
        else
        {
            starLoginManager = new StarLogin.StarLoginManager();
        }
        
        if (starLoginManager == null)
            System.exit(0);
        
        if (bfirstlaunch)
        {
            starLoginManager.updateDataBase("UPDATE fenetre SET GAUCHE=" + dateType + ",HAUT=" + timeType + ", LARGEUR=" + askToSave + " WHERE NOM='PARAMS'");
        }
        else
        {
            String datetype = starLoginManager.getStringFieldValue("fenetre", "GAUCHE", " WHERE NOM='PARAMS'");
            String timetype = starLoginManager.getStringFieldValue("fenetre", "HAUT", " WHERE NOM='PARAMS'");
            String asktosave = starLoginManager.getStringFieldValue("fenetre", "LARGEUR", " WHERE NOM='PARAMS'");
            if (datetype.equals(""))
                datetype = "0";
            if (timetype.equals(""))
                timetype = "0";
            if (asktosave.equals(""))
                asktosave = "0";
            dateType = Integer.valueOf(datetype).intValue();
            timeType = Integer.valueOf(timetype).intValue();
            askToSave = Integer.valueOf(asktosave).intValue();
        }
        
        String srdvwarning = starLoginManager.getStringFieldValue("fenetre", "ETAT", " WHERE NOM='RDVWARNING'");
        if (!srdvwarning.equals("-1") && !srdvwarning.equals(""))
        {
            rdvwarning = Integer.valueOf(srdvwarning).intValue();
            String sdelai = starLoginManager.getStringFieldValue("fenetre", "GAUCHE", " WHERE NOM='RDVWARNING'");
            if(sdelai.equals("-1") || sdelai.equals(""))
                sdelai = "5";
            rdvdelai = Integer.valueOf(sdelai).intValue();
        }
        
        int interval0 = 300000;//1 minute
        TimeZone timeZone = TimeZone.getDefault();
        gc = new GregorianCalendar(timeZone);
        firstTime = gc.getTime();
        sfirstDate = FDate.curUsFormDate();

        //avertissement des rdvs
        timer.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                if (rdvwarning == 1)
                {
                    if (bWarningDone == false)
                    {
                        bWarningDone = true;
                        String rdvs = starLoginManager.getStringFieldValue("rdv", "COUNT(ID)", " WHERE DATE_='" + FDate.curUsFormDate() + "'");
                        if (rdvs.equals(""))
                            rdvs = "0";
                        int irdvs = Integer.valueOf(rdvs).intValue();
                        if (irdvs > 0)
                            setMessage(bundle.getString("NewRdvs"), JOptionPane.INFORMATION_MESSAGE);
                    }
                    else
                    {
                        String scurdate = FDate.curUsFormDate();
                        String diff = diffDates(scurdate, sfirstDate);
                        if (diff.equals(""))
                            diff = "0";
                        int idiff = Integer.valueOf(diff).intValue();
                        if (idiff>=1)
                            bWarningDone = false;
                    }
                }
                else if (rdvwarning ==2)
                {
                    String curDate = FDate.curUsFormDate();
                    String curTime = FTime.curTime();
                    FDate fcurdate = new FDate(curDate);
                    double jj = AstronomyMaths.gregorianToJulian(fcurdate.getDay(), fcurdate.getMonth(), fcurdate.getYear());
                    FTime fcurtime = new FTime(curTime);
                    int mn = fcurtime.getMinute();
                    mn = (mn/5) * 5 + 1;
                    if (mn >= 60)
                        fcurtime = new FTime(fcurtime.getHour(), 59, 59);
                    else
                        fcurtime = new FTime(fcurtime.getHour(), mn, 00);
                    jj += fcurtime.getDecimalHour()/24.0;
                    jj += ((double)MainClass.rdvdelai)/60.0/24.0;
                    double drdvdate = AstronomyMaths.julianToGregorian(jj);
                    FDate frdvdate = new FDate(drdvdate);
                    String srdvdate = frdvdate.getDateUS();
                    double rdvtime = AstronomyMaths.frac(drdvdate * 10000) + 0.000000001;
                    rdvtime *= 24.0;
                    int h = (int)rdvtime;
                    rdvtime -= h;
                    rdvtime *= 60;
                    mn = (int)rdvtime;
                    rdvtime -= mn;
                    rdvtime *= 60;
                    int s = (int)rdvtime;
                    if (s >= 60)
                    {
                        s = 0;
                        mn += 1;
                        if (mn >= 60)
                        {
                            mn = 0;
                            h += 1;
                            if (h >= 24)
                            {
                                h = 0;
                                srdvdate = addDays2Date(srdvdate, 1);
                            }
                        }
                    }
                    String srdvdate2 = srdvdate;
                    FTime frdvtime = new FTime(h, mn, s);
                    String srdvtime = frdvtime.getTime();
                    String srdvtime2;// = srdvtime;
                    if (h>0 || (h == 0 && mn >=5))
                    {
                        double val = frdvtime.getDecimalHour();
                        val -= 5.0/60.0;
                        frdvtime = new FTime(val);
                        srdvtime2 = frdvtime.getTime();
                    }
                    else
                    {
                        srdvtime2 = "23:55:00";
                        srdvdate2 = addDays2Date(srdvdate, -1);
                    }
                    String nb = starLoginManager.getStringFieldValue("rdv", "COUNT(ID)", " WHERE DATE_>='" + srdvdate2 + "' AND HEURE_DEBUT>='" + srdvtime2 + "' AND DATE_<='" + srdvdate + "' AND HEURE_DEBUT<='" + srdvtime + "'");
                    if (nb.equals(""))
                        nb = "0";
                    int inb = Integer.valueOf(nb).intValue();
                    if (inb >0)
                    {
                        String sql = "SELECT ID, NOM_CLIENT, TEL_CLIENT, DATE_, HEURE_DEBUT, HEURE_FIN, DESCRIPTION, STATUS_ FROM rdv WHERE DATE_>='" + srdvdate2 + "' AND HEURE_DEBUT>='" + srdvtime2 + "' AND DATE_<='" + srdvdate + "' AND HEURE_DEBUT<='" + srdvtime + "'";
                        DialogWarnRdvs wrdvs = new DialogWarnRdvs(new JFrame(), true, sql);
                    }
                }
            }
        }, firstTime, interval0);
        
        if (bfirstlaunch)
        {
            writelog("Starlogin font not yet set in database");
            GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Font[] fonts = e.getAllFonts(); // Get the fonts
            boolean bfound = false;
            for (Font f : fonts)
            {
                if (f.getFontName().startsWith("StarLogin"))
                    bfound = true;
            }
            if (!bfound)
            {
                writelog("Starlog font not found on the system");
                File starlogttf = new File("Starlog.ttf");
                writelog("Preparing to copy starlog.ttf file");
                if (starlogttf != null)
                {
                    String filename = starlogttf.getAbsolutePath();
                    //JOptionPane.showMessageDialog(new JFrame(), filename);
                    filename = filename.replace("/starlogin8.app/Contents/Resources/Java", "");
                    writelog("Source file = " + filename);
                    String destination = "";
                    boolean bcopied = false;
                    
                    if (OS.getOS() == OS.apple)
                    {
                        destination = OS.getSeparator().concat("Library").concat(OS.getSeparator()).concat("Fonts").concat(OS.getSeparator()).concat("Starlog.ttf");
                        writelog("Destination file = " + destination);
                        bcopied = copy(filename, destination);
                    }
                    else if (OS.getOS() == OS.windows)
                    {
                        destination = "c:".concat(OS.getSeparator()).concat("Windows").concat(OS.getSeparator()).concat("Fonts").concat(OS.getSeparator());
                        File dir = new File(destination);
                        dir.setWritable(true);
                        destination = destination.concat("Starlog.ttf");
                        writelog("Destination file = " + destination);
                        bcopied = copy(filename, destination);
                    }
                    if (bcopied)
                    {
                        starlogttf = new File(destination);
                        writelog("Copied file = " + starlogttf.getAbsolutePath());
                        starlogfont = null;
                        writelog("Try to register the font");
                        try
                        {
                            starlogfont = Font.createFont(Font.TRUETYPE_FONT, starlogttf);
                        }
                        catch (FontFormatException ex)
                        {
                            setMessage(ex.getMessage());
                        }
                        catch (IOException ex)
                        {
                            setMessage(ex.getMessage());
                        }
                        if (starlogfont != null)
                        {
                            writelog("Font created");
                            e.registerFont(starlogfont);
                            setMessage(bundle.getString("StarlogFontSetUp"), JOptionPane.INFORMATION_MESSAGE);
                        }
                        else
                        {
                            setMessage(bundle.getString("StarlogFontNotInPackage"), JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    else
                    {
                        destination = destination.replace("Starlog.ttf", "");
                        setMessage(bundle.getString("NoAccessRightsToCopyStarlogttf").concat(" ").concat(destination).concat(".\r\n").concat(bundle.getString("CopyItManually")).concat(" ").concat(filename).concat("."), JOptionPane.WARNING_MESSAGE);
                    }
                }
                else
                    writelog("starlog.ttf filename is null");
            }
            starLoginManager.updateDataBase("INSERT INTO FENETRE(NOM) VALUES('STARLOGFONT')");
        }
        
        currentOption = starLoginManager.getDefaultOption();
        if (currentOption == null)
        {
            MainClass.setMessage("OptionsNotFound");
            try
            {
                starLoginManager.getConnection().close();
            }
            catch (java.sql.SQLException ex)
            {
                MainClass.setMessage(ex.getMessage());
            }
            System.exit(0);
        }
        currentEventID = currentOption.getDefaultEvent();
        
        getOptions();
        dbrOptions = starLoginManager.getDBRecord();
        
        if (vers.compareTo(bundle.getString("JAVA_VERSION_NB")) < 0)//"1.5.0_07"
        {
            writelog(bundle.getString("WARNING_VERSION"));
        }
        setAstrobj();
        mainForm = new MainForm();
        mainForm.setVisible(true);
    }
    
    public static int getCurrentRow(Records records, int selectedRow)
    {
        selectedRow -= 1;
        if (records == null)
            return 0;
        ArrayList rows = records.getRecords();
        if (rows.isEmpty())
            return 0;
        else if (selectedRow < rows.size())
            return selectedRow;
        else if (selectedRow > 0)
            return selectedRow -1;
        else
            return 0;
    }
    
    public static void beep()
    {
        /*
                UIManager.getLookAndFeel().provideErrorFeedback(null);
                System.out.print("\007");
                System.out.flush();*/
        Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
        tk.beep();
    }
    
    public static void testPlace(String sPlace, String sLatitude, String sLongitude, JFrame parent)
    {
        String id = starLoginManager.getStringFieldValue("places", "count(ID)", " WHERE PLACENAME='" + replaceQuotes(sPlace) + "' AND PLACELATITUDE='" + replaceQuotes(sLatitude) + "' AND PLACELONGITUDE='" + replaceQuotes(sLongitude) + "'");
        if (id.equals("-1") || id.equals("0"))
            updatePlace(2, sPlace, sLatitude, sLongitude);
    }
    
    public static void testPlace(String sPlace, String sLatitude, String sLongitude, JDialog parent, boolean bNewEvent)
    {
        String id = starLoginManager.getStringFieldValue("places", "count(ID)", " WHERE PLACENAME='" + replaceQuotes(sPlace) + "' AND PLACELATITUDE='" + replaceQuotes(sLatitude) + "' AND PLACELONGITUDE='" + replaceQuotes(sLongitude) + "'");
        if (!id.equals("-1") && !id.equals("0"))
        {
            if (!bNewEvent)
                return;
            DlgAskToSavePlace dasp = new DlgAskToSavePlace(parent, true);
            
            int choixAction0 = MainClass.choixAction;
            if (parent != null)
            {
                if (parent instanceof DialogEvent)
                    choixAction0 = ((DialogEvent)parent).getChoix();
            }
            updatePlace(choixAction0, sPlace, sLatitude, sLongitude);
        }
        else
            updatePlace(2, sPlace, sLatitude, sLongitude);
    }
    
    private static void updatePlace(int choix, String sPlace, String sLatitude, String sLongitude)
    {
        switch (choix)
        {
            case 1:
                starLoginManager.updateDataBase("UPDATE Places SET PlaceName='" + replaceQuotes(sPlace) + "'"
                                                + ", PlaceLatitude='" + replaceQuotes(sLatitude) + "'"
                                                + ", PlaceLongitude='" + replaceQuotes(sLongitude) + "'"
                                                + " WHERE PlaceName='" + replaceQuotes(sPlace) + "'");
                break;

            case 2:
                starLoginManager.updateDataBase("INSERT INTO Places (PlaceName, PlaceLatitude, PlaceLongitude) VALUES ("
                                                + "'" + replaceQuotes(sPlace) + "', "
                                                + "'" + replaceQuotes(sLatitude) + "', "
                                                + "'" + replaceQuotes(sLongitude) + "')");
                break;

            default:
        }
    }
    
    
    /*public static String searchFile(String fileToFind, File searchIn)
    {
        File[] listOfFiles = searchIn.listFiles();
        if (listOfFiles == null)
            return "0";
        String fichiertrouve = "0";
        while (fichiertrouve.equals("0"))
        {
            for (int i=0; i<listOfFiles.length; i++)
            {
                if (listOfFiles[i].isDirectory())
                {
                    fichiertrouve = searchFile(fileToFind, listOfFiles[i]);
                }
                else
                {
                    if (listOfFiles[i].getName().toUpperCase().equals(fileToFind.toUpperCase()))
                    {
                        fichiertrouve = listOfFiles[i].getAbsolutePath();
                        return fichiertrouve;
                    }
                    else
                        fichiertrouve = "0";
                }
            }
            return fichiertrouve;
        }
        return fichiertrouve;
    }*/
    
    private static void getOptions()
    {
        options = new Options();
    }    
    
    public static void writelog(String message)
    {
        /*String datetime = FDate.curUsFormDateTime();
        datetime = datetime.concat(":\n");
        String logfilename = new java.io.File("messages.log").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
        File logFile = new File(logfilename);
        String contenu = "";
        if (logFile.exists())
        {
            File file = new File(logfilename);
            int lb =(int)file.length()+2;
            contenu = FileAccess.readFile(logfilename, lb);
        }
        FileAccess.writeFile(logfilename, contenu.concat(datetime).concat(message).concat("\n\n"));*/
        System.out.println(message);
    }
    
    @SuppressWarnings("unchecked")
    public static void setMessage(String message, int typeMessage)
    {
        writelog(message);
        if (message == null)
        {
            message = "";
        }
        int size = message.length();
        if (size > 3000)
        {
            message = message.substring(0, 3000);
        }
        ArrayList objs = new ArrayList();
        while (message.length() > 100)
        {
            int pos = message.substring(0, 100).lastIndexOf(" ");
            if (pos > 0)
            {
                objs.add(message.substring(0, pos));
                message = message.substring(pos);
            }
            else
            {
                objs.add(message.substring(0, 100));
                message = message.substring(100);
            }
        }
        if (message.length() > 0)
        {
            objs.add(message);
        }
        Object[] obj = objs.toArray();
        message = "";
        for (int j=0; j<objs.size(); j++)
        {
            message = message.concat(null2String(obj[j])).concat("\n");
        }
        if (typeMessage == JOptionPane.INFORMATION_MESSAGE)
            JOptionPane.showMessageDialog(null, message, bundle.getString("StarlogVersion"), typeMessage);
        else if (typeMessage == JOptionPane.WARNING_MESSAGE)
            JOptionPane.showMessageDialog(null, message, bundle.getString("Warning"), typeMessage);
        else
        {
            beep();
            JOptionPane.showMessageDialog(null, message, bundle.getString("ERREUR"), typeMessage);
        }
        
    }
    
    public static int getOtherFieldsNumber(String sfields)
    {
        int pos = 1;
        int count = 0;
        while (pos>=0)
        {
            pos = sfields.indexOf(",");
            if (pos>=0)
            {
                sfields = sfields.substring(0, pos).concat(sfields.substring(pos+1));
                count++;
            }
        }
        return count;
    }

    public static void setMessage(String message)
    {
        setMessage(message, JOptionPane.ERROR_MESSAGE);
    }


    public static void ToUpper(java.awt.event.KeyEvent evt)
    {
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            char ch = evt.getKeyChar();
            String s = String.valueOf(ch);
            s = s.toUpperCase();
            char[] charray = s.toCharArray();
            ch = charray[0];
            evt.setKeyChar(ch);
        }
    }

    public static void ToLower(java.awt.event.KeyEvent evt)
    {
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            char ch = evt.getKeyChar();
            String s = String.valueOf(ch);
            s = s.toLowerCase();
            char[] charray = s.toCharArray();
            ch = charray[0];
            evt.setKeyChar(ch);
        }
    }
    
    public static Frame checkInstance(String name)
    {
        Frame frames[] = java.awt.Frame.getFrames();
        for (int i = 0; i < frames.length; i++)
        {
            String formname = frames[i].getClass().getName();
            int pos = formname.lastIndexOf(".");
            if (pos > 0)
                formname = formname.substring(pos + 1);
            if (formname.equals(name))
            {
                if (frames[i].getExtendedState() == java.awt.Frame.ICONIFIED || frames[i].getExtendedState() == 7)
                    frames[i].setExtendedState(0);
                else
                    frames[i].toFront();
                return frames[i];
                //break;
            }
        }
        return null;
    }
    
    public static void buildRecursRdv(String sdebut, String srdvid, boolean bKeepState)
    {
        FDate fdebut = new FDate(sdebut);
        Date debut = fdebut.getDate2();
        String sdatemax = addDays2Date(sdebut, 20*365);
        FDate fdmax = new FDate(sdatemax);
        Date datemax = fdmax.getDate2();

        Record rdvrecur = starLoginManager.getRecord("SELECT ID, RDVID, DEBUT, FIN, TYPE_RECUR, NB_RECUR, WEEKDAY_RECUR, MONTHDAY_RECUR, MONTH_RECUR, NUMWEEKINMONTH_RECUR, NBMAXRECUR FROM rdvrecur WHERE RDVID=" + srdvid, "rdvrecur", "");
        String recurid = null2String(rdvrecur.getData(0));
        String rdvid = null2String(rdvrecur.getData(1));
        String sdatedebut = null2StringDate(rdvrecur.getData(2));
        String sdatefin = null2StringDate(rdvrecur.getData(3));
        String type_recur = null2String0(rdvrecur.getData(4));
        String nb_recur = null2String0(rdvrecur.getData(5));
        int nbrecur = Integer.valueOf(nb_recur).intValue();
        String wd_recur = null2String0(rdvrecur.getData(6));
        
        String nbmax_recur = null2String0(rdvrecur.getData(10));
        int nbmaxrecur = Integer.valueOf(nbmax_recur).intValue();
        FDate fd = new FDate(sdatedebut);
        Date ddebut = fd.getDate2();
        if (ddebut.before(debut))
        {
            ddebut = debut;
            sdatedebut = sdebut;
        }
        if (sdatefin.equals("2000-01-01"))
        {
            sdatefin = sdatemax;
        }
        fd = new FDate(sdatefin);
        Date dfin = fd.getDate2();
        if (dfin.after(datemax))
        {
            dfin = datemax;
        }

        int ir = 1;
        if (type_recur.equals("1"))
        {
            while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
            {
                sdatedebut = addDays2Date(sdatedebut, nbrecur);
                if (bKeepState)
                    starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,RDV.DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                else
                    starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,RDV.DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                
                fd = new FDate(sdatedebut);
                ddebut = fd.getDate2();
                ir++;
            }
        }
        
        else if (type_recur.equals("2"))
        {
            int wd = AstronomyMaths.getWeekDay(sdatedebut);
            
            while (wd_recur.length() > 0)
            {
                ir = 1;
                int wdrecur = Integer.valueOf(wd_recur.substring(0, 1)).intValue();
                int diff_days = wdrecur - wd;
                if (diff_days < 0)
                {
                    diff_days += 7;
                }
                String sdatedebut2 = addDays2Date(sdatedebut, diff_days);
                fd = new FDate(sdatedebut2);
                ddebut = fd.getDate2();
                while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
                {
                    if (!(sdatedebut2.equals(sdatedebut) && ir == 1))
                    {
                        if (bKeepState)
                            starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut2 + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                        else
                            starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut2 + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                    }
                    fd = new FDate(sdatedebut2);
                    ddebut = fd.getDate2();
                    ir++;
                    sdatedebut2 = addDays2Date(sdatedebut2, nbrecur * 7);
                }
                wd_recur = wd_recur.substring(1);
            }
        }
        else if (type_recur.equals("3"))
        {
            if (nbrecur == 0)
                nbrecur = 1;
            fd = new FDate(sdatedebut);
            long year = fd.getYear();
            long month = fd.getMonth();
            String md_recur = null2String0(rdvrecur.getData(7));
            int mdrecur = Integer.valueOf(md_recur).intValue();
            if (mdrecur > 0)
            {
                long day = mdrecur;
                fd = new FDate(day, month, year, "");
                ddebut = fd.getDate2();
                while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
                {
                    month += nbrecur;
                    if (month > 12l)
                    {
                        month -= 12l;
                        year += 1l;
                    }
                    fd = new FDate(day, month, year, "");
                    ddebut = fd.getDate2();
                    sdatedebut = fd.getDateUS();
                    if (bKeepState)
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                    else
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                    ir++;
                }
            }
            else
            {
                int wdrecur = Integer.valueOf(wd_recur).intValue();
                fd = new FDate(1l, month, year, "");
                sdatedebut = fd.getDateUS();
                int wd = AstronomyMaths.getWeekDay(sdatedebut);
                ir = 1;
                int diff_days = wdrecur - wd;
                if (diff_days < 0)
                {
                    diff_days += 7;
                }
                sdatedebut = addDays2Date(sdatedebut, diff_days);
                fd = new FDate(sdatedebut);
                year = fd.getYear();
                month = fd.getMonth();
                long day = fd.getDay();
                String nwim_recur = null2String0(rdvrecur.getData(9));
                int nwinrecur = Integer.valueOf(nwim_recur).intValue();
                long difdays = (nwinrecur - 1) * 7;
                if (nwinrecur < 5)
                {
                    fd = new FDate(day + difdays, month, year, "");
                }
                else
                {
                    difdays = 21l;
                    fd = new FDate(day + difdays, month, year, "");
                    sdatedebut = fd.getDateUS();
                    String sdd = addDays2Date(sdatedebut, 7);
                    FDate fd2 = new FDate(sdd);
                    long m = fd2.getMonth();
                    if (m == month)
                    {
                        sdatedebut = sdd;
                        fd = new FDate(sdatedebut);
                    }
                }
                ddebut = fd.getDate2();
                sdatedebut = fd.getDateUS();

                while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
                {
                    if (bKeepState)
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                    else
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                        
                    month += nbrecur;
                    if (month > 12l)
                    {
                        month -= 12l;
                        year += 1l;
                    }
                    
                    fd = new FDate(1l, month, year, "");
                    sdatedebut = fd.getDateUS();
                    wd = AstronomyMaths.getWeekDay(sdatedebut);
                    diff_days = wdrecur - wd;
                    if (diff_days < 0)
                    {
                        diff_days += 7;
                    }
                    sdatedebut = addDays2Date(sdatedebut, diff_days);
                    fd = new FDate(sdatedebut);
                    year = fd.getYear();
                    month = fd.getMonth();
                    day = fd.getDay();
                    difdays = (nwinrecur - 1) * 7;
                    if (nwinrecur < 5)
                    {
                        fd = new FDate(day + difdays, month, year, "");
                    }
                    else
                    {
                        difdays = 21l;
                        fd = new FDate(day + difdays, month, year, "");
                        sdatedebut = fd.getDateUS();
                        String sdd = addDays2Date(sdatedebut, 7);
                        FDate fd2 = new FDate(sdd);
                        long m = fd2.getMonth();
                        if (m == month)
                        {
                            sdatedebut = sdd;
                            fd = new FDate(sdatedebut);
                        }
                    }
                    ddebut = fd.getDate2();
                    sdatedebut = fd.getDateUS();
                    ir++;
                }
            }
        }
        else if (type_recur.equals("4"))
        {
            String m_recur = null2String0(rdvrecur.getData(8));
            int mrecur = Integer.valueOf(m_recur).intValue();

            fd = new FDate(sdatedebut);
            long year = fd.getYear();
            String md_recur = null2String0(rdvrecur.getData(7));
            int mdrecur = Integer.valueOf(md_recur).intValue();
            if (mdrecur > 0)
            {
                long day = mdrecur;
                fd = new FDate(day, mrecur, year, "");
                ddebut = fd.getDate2();
                while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
                {
                    year += 1l;
                    fd = new FDate(day, mrecur, year, "");
                    ddebut = fd.getDate2();
                    sdatedebut = fd.getDateUS();
                    if (bKeepState)
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                    else
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                    ir++;
                }
            }
            else
            {
                int wdrecur = Integer.valueOf(wd_recur).intValue();
                fd = new FDate(1l, mrecur, year, "");
                sdatedebut = fd.getDateUS();
                int wd = AstronomyMaths.getWeekDay(sdatedebut);
                ir = 1;
                int diff_days = wdrecur - wd;
                if (diff_days < 0)
                    diff_days += 7;
                
                sdatedebut = addDays2Date(sdatedebut, diff_days);
                fd = new FDate(sdatedebut);
                year = fd.getYear();
                long day = fd.getDay();
                String nwim_recur = null2String0(rdvrecur.getData(9));
                int nwinrecur = Integer.valueOf(nwim_recur).intValue();
                long difdays = (nwinrecur - 1) * 7;
                if (nwinrecur < 5)
                {
                    fd = new FDate(day + difdays, mrecur, year, "");
                }
                else
                {
                    difdays = 21l;
                    fd = new FDate(day + difdays, mrecur, year, "");
                    sdatedebut = fd.getDateUS();
                    String sdd = addDays2Date(sdatedebut, 7);
                    FDate fd2 = new FDate(sdd);
                    long m = fd2.getMonth();
                    if (m == mrecur)
                    {
                        sdatedebut = sdd;
                        fd = new FDate(sdatedebut);
                    }
                }
                ddebut = fd.getDate2();
                sdatedebut = fd.getDateUS();

                while (ddebut.before(dfin) && (ir <= nbmaxrecur || nbmaxrecur == 0))
                {
                    if (bKeepState)
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID,STATUS_ FROM RDV WHERE ID=" + rdvid);
                    else
                        starLoginManager.updateDataBase("INSERT INTO rdv(CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID) SELECT CLIENTID,NOM_CLIENT,TEL_CLIENT,'" + sdatedebut + "',DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,RDVRECURID FROM RDV WHERE ID=" + rdvid);
                    
                    year += 1l;
                    fd = new FDate(1l, mrecur, year, "");
                
                    sdatedebut = fd.getDateUS();
                    wd = AstronomyMaths.getWeekDay(sdatedebut);
                    diff_days = wdrecur - wd;
                    if (diff_days < 0)
                        diff_days += 7;

                    sdatedebut = addDays2Date(sdatedebut, diff_days);
                    fd = new FDate(sdatedebut);
                    year = fd.getYear();
                    day = fd.getDay();
                    nwim_recur = null2String0(rdvrecur.getData(9));
                    nwinrecur = Integer.valueOf(nwim_recur).intValue();
                    difdays = (nwinrecur - 1) * 7;
                    if (nwinrecur < 5)
                    {
                        fd = new FDate(day + difdays, mrecur, year, "");
                    }
                    else
                    {
                        difdays = 21l;
                        fd = new FDate(day + difdays, mrecur, year, "");
                        sdatedebut = fd.getDateUS();
                        String sdd = addDays2Date(sdatedebut, 7);
                        FDate fd2 = new FDate(sdd);
                        long m = fd2.getMonth();
                        if (m == mrecur)
                        {
                            sdatedebut = sdd;
                            fd = new FDate(sdatedebut);
                        }
                    }
                    ddebut = fd.getDate2();
                    sdatedebut = fd.getDateUS();
                    ir++;
                }
            }
        }
    }
    
    public static String getLookForField2(JTextField txtField, DefaultComboBoxModel model, String tableName, String fieldName)
    {
        Point pt = txtField.getLocationOnScreen();
        Dimension dim = txtField.getPreferredSize();
        dim.width += 20;
        dim.height += 1;
        String defaultVal = txtField.getText().trim();
        return getField2(defaultVal, model, tableName, fieldName, pt, dim);
    }
    
    public static String addDays2Date(String sDate, int days)
    {
        FDate fd = new FDate(sDate);
        long jour = fd.getDay();
        long mois = fd.getMonth();
        long annee = fd.getYear();
        double jdc = AstronomyMaths.gregorianToJulian(jour, mois, annee);
        jdc += days;
        jdc = AstronomyMaths.julianToGregorian(jdc);
        fd = new FDate(jdc);
        sDate = fd.getDateUS();
        return sDate;
    }
    
    public static String addDays2DateFR(String sDate, int days)
    {
        FDate fd = new FDate(sDate);
        long jour = fd.getDay();
        long mois = fd.getMonth();
        long annee = fd.getYear();
        double jdc = AstronomyMaths.gregorianToJulian(jour, mois, annee);
        jdc += days;
        jdc = AstronomyMaths.julianToGregorian(jdc);
        fd = new FDate(jdc);
        sDate = fd.getFormatedDate().replace(" ", "");
        return sDate;
    }
    
    public static String diffDates(String sDate1, String sDate2)
    {
        FDate fd1 = new FDate(sDate1);
        long jour1 = fd1.getDay();
        long mois1 = fd1.getMonth();
        long annee1 = fd1.getYear();
        double jdc1 = AstronomyMaths.gregorianToJulian(jour1, mois1, annee1);
        FDate fd2 = new FDate(sDate2);
        long jour2 = fd2.getDay();
        long mois2 = fd2.getMonth();
        long annee2 = fd2.getYear();
        double jdc2 = AstronomyMaths.gregorianToJulian(jour2, mois2, annee2);
        long nbj = (long)(jdc2 - jdc1);
        return Long.valueOf(nbj).toString();
    }

    private static String getField(String defaultVal, String tableName, String fieldName, String title, Point pt, Dimension dim, boolean bFilterOnDefaultVal, String newVal, String filter, boolean bdistinct)
    {
        DefaultComboBoxModel model;
        String select = "SELECT ";
        if (bdistinct)
            select = select.concat("DISTINCT ");
        if (filter == null || filter.equals(""))
            filter = "1=1";
        
        if (defaultVal.equals(""))
        {
            model = starLoginManager.getListe(select.concat(fieldName).concat(" FROM ").concat(tableName).concat(" WHERE ").concat(fieldName).concat("!='' AND ").concat(fieldName).concat(" IS NOT NULL AND " + filter + " ORDER BY ").concat(fieldName));
        }
        else
        {
            if (bFilterOnDefaultVal)
            {
                model = starLoginManager.getListe(select.concat(fieldName).concat(" FROM ").concat(tableName).concat(" WHERE ").concat(fieldName).concat(" Like '").concat(defaultVal).concat("%' AND " + filter + " ORDER BY ").concat(fieldName));
            }
            else
            {
                model = starLoginManager.getListe(select.concat(fieldName).concat(" FROM ").concat(tableName).concat(" WHERE ").concat(fieldName).concat("!='' AND ").concat(fieldName).concat(" IS NOT NULL AND " + filter + " ORDER BY ").concat(fieldName));
            }
        }
        if (newVal != null && !newVal.equals(""))
            model.addElement(newVal);
        model.addElement("");
        //fieldName = fieldName.replace(" ", "_");
        String strText = CboPopup.ShowInput(title, defaultVal, model, pt, dim);
        return strText;
        
    }
    
    public static String getLookForField(JTextField txtField, String tableName, String fieldName, String title, boolean bFilterOnDefaultVal, String newVal, boolean btel, String filter, boolean bdistinct)
    {
        Point pt = txtField.getLocationOnScreen();
        Dimension dim = txtField.getPreferredSize();
        dim.width += 190;
        dim.height += 2;
        String defaultVal = txtField.getText().trim();
        if (btel == true)
            defaultVal = defaultVal.replace("(", "").replace(")", "").replace(" ", "").replace("-", "").replace(".", "");
        return getField(defaultVal, tableName, fieldName, title, pt, dim, bFilterOnDefaultVal, newVal, filter, bdistinct);
    }

    public static String getLookForField(JFormattedTextField txtField, String tableName, String fieldName, String title, boolean bFilterOnDefaultVal, String newVal, boolean btel, String filter, boolean bdistinct)
    {
        Point pt = txtField.getLocationOnScreen();
        Dimension dim = txtField.getPreferredSize();
        dim.width += 190;
        dim.height += 2;
        String defaultVal = txtField.getText().trim();
        if (btel == true)
            defaultVal = defaultVal.replace("(", "").replace(")", "").replace(" ", "").replace("-", "").replace(".", "");
        return getField(defaultVal, tableName, fieldName, title, pt, dim, bFilterOnDefaultVal, newVal, filter, bdistinct);
    }
    
    private static String getField2(String defaultVal, DefaultComboBoxModel model, String shortTablename, String fieldName, Point pt, Dimension dim)
    {
        fieldName = fieldName.replace(" ", "_");
        String strText = CboPopup.ShowInput(bundle.getString(shortTablename.concat(fieldName)), defaultVal, model, pt, dim);
        return strText;
    }
    
    public static String null2String(Object object)
    {
        if (object == null)
            return "";
        else
            return object.toString();
    }
    
    private static String null2String0(Object object)
    {
        if (object == null||object.toString().equals(""))
            return "0";
        else
            return object.toString();
    }
    
    private static String null2StringDate(Object object)
    {
        if (object == null||object.toString().equals(""))
            return "2000-01-01";
        else
            return object.toString();
    }
    
    public static DataBaseRecord getDBROptions()
    {
        return dbrOptions;
    }
    
    public static int[] getWindowParams(String classname)
    {
        Record fenetre = starLoginManager.getRecord("SELECT ID, GAUCHE, HAUT, LARGEUR, HAUTEUR, ETAT FROM fenetre WHERE NOM='" + classname + "'", "fenetre", "");
        String sgauche = fenetre.getData(1);
        String shaut = fenetre.getData(2);
        String slargeur = fenetre.getData(3);
        String shauteur = fenetre.getData(4);
        String setat = fenetre.getData(5);
        if (sgauche.equals("")||sgauche.equals("-1"))
            sgauche = "0";
        if (shaut.equals("")||shaut.equals("-1"))
            shaut = "0";
        if (slargeur.equals("")||slargeur.equals("-1"))
            slargeur = "0";
        if (shauteur.equals("")||shauteur.equals("-1"))
            shauteur = "0";
        if (setat.equals("")||setat.equals("-1"))
            setat = "0";
        int result[] = new int[5];
        result[0] = Integer.valueOf(sgauche).intValue();
        result[1] = Integer.valueOf(shaut).intValue();
        result[2] = Integer.valueOf(slargeur).intValue();
        result[3] = Integer.valueOf(shauteur).intValue();
        result[4] = Integer.valueOf(setat).intValue();
        return result;
    }
    
    public static String no2defaultDate(String sdate, int defaultType)
    {
        if (sdate == null||sdate.equals(""))
        {
            switch(defaultType)
            {
                case DATE_1900: sdate = SDATE_1900; break;
                case DATE_1950: sdate = SDATE_1950; break;
                case DATE_2000: sdate = SDATE_2000; break;
                case DATE_CURRENT:
                default: sdate = FDate.curUsFormDate();
            }
        }
        sdate = getFormatedDate(sdate);
        return sdate;
    }
    
    public static String no2defaultTime(String stime, int defaultType)
    {
        if (stime == null||stime.equals(""))
        {
            switch(defaultType)
            {
                case TIME_000000: stime = STIME_000000; break;
                case TIME_235959: stime = STIME_235959; break;
                case TIME_120000: stime = STIME_120000; break;
                case TIME_240000: stime = STIME_240000; break;
                case TIME_CURRENT:
                default: stime = FTime.curTime();
            }
        }
        stime = getFormatedTime(stime);
        return stime;
    }
    
    public static String getFormatedDate(String sdate)
    {
        FDate fd = new FDate(sdate);
        sdate = fd.getFormatedDate();
        return sdate;
    }
    
    public static String getFormatedTime(String stime)
    {
        FTime ft = new FTime(stime);
        stime = ft.getTime();
        return stime;
    }
    
    public static String replaceQuotes(String sField)
    {
        if (sField == null)
            return "";
        return sField.replace("'", "''");
    }
    
    public static void renameFile(String directory, String oldName, String newName)
    {
        oldName = oldName.toLowerCase();
        newName = newName.toLowerCase();
        File filePath = new File(directory);
        FileSystemView fsv = FileSystemView.getFileSystemView();
        File files[] = fsv.getFiles(filePath, false);
        for (int i=0; i<files.length; i++)
        {
            String fileName = files[i].getPath().toLowerCase();
            if (oldName.equals(fileName))
            {
                files[i].renameTo(new File(newName));
                return;
            }
        }
    }
    
    public static void deleteFile(String directory, String file)
    {
        file = file.toLowerCase();
        File filePath = new File(directory);
        FileSystemView fsv = FileSystemView.getFileSystemView();
        File files[] = fsv.getFiles(filePath, false);
        for (int i=0; i<files.length; i++)
        {
            String fileName = files[i].getPath().toLowerCase();
            if (file.equals(fileName))
            {
                files[i].delete();
                return;
            }
        }
    }
    
    public static void removeRdv(String recurid, String rdvid)
    {
        if (!recurid.equals("") && !recurid.equals("0") && !recurid.equals("-1"))
        {
            starLoginManager.updateDataBase("delete FROM rdvrecur WHERE ID=" + recurid);
            String daterdv = starLoginManager.getStringFieldValue("rdv", "DATE_", " WHERE ID=" + rdvid);
            starLoginManager.updateDataBase("DELETE FROM rdv WHERE DATE_>'" + daterdv + "' AND RDVRECURID=" + recurid);
            starLoginManager.updateDataBase("UPDATE rdv SET RDVRECURID=0 WHERE RDVRECURID=" + recurid);
        }
        else
        {
            starLoginManager.updateDataBase("delete FROM rdv WHERE ID=" + rdvid);
        }
    }
    
    public static boolean copy(String sin, String sout)
    {
        FileChannel in = null; // canal d'entree
        FileChannel out = null; // canal de sortie
        boolean result = true;

        try
        {
            // Init
            in = new FileInputStream(sin).getChannel();
            out = new FileOutputStream(sout).getChannel();

            // Copie depuis le in vers le out
            in.transferTo(0, in.size(), out);
        }
        catch (Exception e)
        {
            result = false;
            JOptionPane.showMessageDialog(null, e.getMessage(), bundle.getString("ERREUR"), JOptionPane.ERROR_MESSAGE);
        }
        finally
        {
            // finalement on ferme
            if (in != null)
            {
                try
                {
                    in.close();
                }
                catch (IOException e)
                {
                }
            }
            if (out != null)
            {
                try
                {
                    out.close();
                }
                catch (IOException e)
                {
                }
            }
        }
        return result;
    }
    
    public static String formatDouble(String value)
    {
        if (value == null || value.equals("") || value.equals("0"))
            value = "0.00";
        int pos = value.indexOf(".");
        if (pos<0)
            value = value.concat(".00");
        else if (value.length() - pos <=2)
            value = value.concat("0");
        return value;
    }

    public static void setRestrict(Container container, boolean enabled, boolean bouton)
    {
        Component components[] = container.getComponents();
        for (int i = 0; i < container.getComponentCount(); i++)
        {
            Component component = components[i];
            if (component instanceof JComboBox || component instanceof JRadioButton || component instanceof JFormattedTextField || component instanceof JCheckBox || component instanceof JTextArea || component instanceof JTextPane || component instanceof JTextField || component instanceof JList || component instanceof JButton)
            {
                if (component instanceof JComboBox)
                {
                    ((JComboBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JFormattedTextField)
                {
                    ((JFormattedTextField) (JComponent) (Container) component).setEnabled(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JFormattedTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JCheckBox)
                {
                    ((JCheckBox) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JRadioButton)
                {
                    ((JRadioButton) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JTextArea)
                {
                    ((JTextArea) (JComponent) (Container) component).setEnabled(enabled);
                    ((JTextArea) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextArea) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextPane)
                {
                    ((JTextPane) (JComponent) (Container) component).setEnabled(enabled);
                    ((JTextPane) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextPane) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JTextField)
                {
                    ((JTextField) (JComponent) (Container) component).setEnabled(enabled);
                    ((JTextField) (JComponent) (Container) component).setFocusable(enabled);
                    ((JTextField) (JComponent) (Container) component).setRequestFocusEnabled(enabled);
                }
                else if (component instanceof JList)
                {
                    ((JList) (JComponent) (Container) component).setEnabled(enabled);
                }
                else if (component instanceof JButton && bouton == true)
                {
                    ((JButton) (JComponent) (Container) component).setEnabled(enabled);
                }
            }
            Container subContainer = (Container) component;
            setRestrict(subContainer, enabled, false);
        }
    }
    
}