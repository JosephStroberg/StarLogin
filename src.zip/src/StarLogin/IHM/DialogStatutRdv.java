/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.Persistence.DataBaseRecord;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Record;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author Francois
 */
public class DialogStatutRdv extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager;
    private Record statut;
    private String sQuery = "SELECT ID, NOM, COULEUR FROM statutrdv";
    private boolean bolAdding = false;
    private boolean bolEditing = false;
    private java.util.ResourceBundle bundle;
    private DataBaseRecord dbr;
    private int kc; //key code
    private Color color;
    private String statutid = "1";
    private String nom;
    private DefaultComboBoxModel cmStatus;
    private String couleur;
    private boolean bSetting = true;
    private Window parentForm;

    /**
     * Creates new form DialogCommis
     */
    public DialogStatutRdv(java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        setDlg(parentForm);
    }
    
    public DialogStatutRdv(JDialog parent, boolean modal)
    {
        super(parent, modal);
        parentForm = (Window) parent;
        setDlg(parentForm);
    }
    
    private void setDlg(Window parent)
    {
        parentForm = parent;
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        this.starLoginManager = MainClass.starLoginManager;

        bundle = MainClass.bundle;
        initComponents();

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        resetLangue();

        setCombos();
        bSetting = false;
        refreshRecord();
        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        this.setVisible(true);
    }
    
    private void setCombos()
    {
        DefaultComboBoxModel comboModel = starLoginManager.getListe("SELECT NOM,ID FROM statutrdv");
        cmStatus = starLoginManager.getListe("SELECT ID,NOM FROM statutrdv");
        cboStatus.setModel(comboModel);
        if (bolAdding)
            cboStatus.setSelectedIndex(-1);
        else if (cmStatus.getSize()>0)
            cboStatus.setSelectedIndex(0);
        else
            cboStatus.setSelectedIndex(-1);
        statutid = null2String(cmStatus.getElementAt(cboStatus.getSelectedIndex()));
    }
    
    private boolean save()
    {
        //case of row modified or added
        if ((bolEditing == true) || (bolAdding == true))
        {
            setCursor(new Cursor(Cursor.WAIT_CURSOR));
            setTextToData();
            
            //update data
            statut.setAdding(bolAdding);
            statut.setData(1, nom);
            statut.setData(2, couleur);
            starLoginManager.setRecord(statut, dbr);
            /*if (bolAdding)
            {
                statutid = starLoginManager.getStringFieldValue("statutrdv", "max(id)", " WHERE nom='" + nom.replace("'", "''") + "'");
            }*/
            setNormalMode();
            bSetting = true;
            setCombos();
            cboStatus.setSelectedItem(nom);
            statutid = null2String(cmStatus.getElementAt(cboStatus.getSelectedIndex()));
            if (statutid.equals(""))
                statutid = "-1";
            bolEditing = false;
            bolAdding = false;
            bSetting = false;
            refreshRecord();
            cboStatus.setEnabled(true);
            updateInstances();
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }
        return true;
    }
    
    private void updateInstances()
    {
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof GestionTempsForm)
            {
                ((GestionTempsForm)windows[i]).refreshRdvs(false, null);
                break;
            }
            else if (windows[i] instanceof DialogRdv)
            {
                ((DialogRdv)windows[i]).setStatus(true);
                break;
            }
        }
    }
    
    private void setEditMode()
    {
        pnlBoutons.setBackground(MainClass.options.getEditColor());
    }
    
    private void setNormalMode()
    {
        pnlBoutons.setBackground(MainClass.options.getNormalColor());
    }

    private int askToSave(boolean bClosing)
    {
        int result = JOptionPane.NO_OPTION;
        if (bolEditing||bolAdding)
        {
            if (!nom.equals(""))
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("rdvSTATUS_").concat(" ").concat(nom),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingStatus"),bundle.getString("rdvSTATUS_").concat(" ").concat(nom),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
            else
            {
                if (MainClass.askToSave == MainClass.SAVEDATA_ASK)
                {
                    if (bClosing)
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModif"),bundle.getString("NoStatusName"),JOptionPane.YES_NO_OPTION);
                    else
                        result = JOptionPane.showConfirmDialog(this, bundle.getString("SaveModifBeforeAddingStatus"),bundle.getString("NoStatusName"),JOptionPane.YES_NO_OPTION);
                }
                else
                    result = JOptionPane.YES_OPTION;
            }
        }
        return result;
    }
    
    private void refreshRecord()
    {
        if (statutid.equals(""))
            statutid = "-1";
        if (statutid.equals("-1"))
        {
            bolAdding = true;
            bolEditing = true;
            setEditMode();
        }
        else
        {
            bolAdding = false;
            bolEditing = false;
            setNormalMode();
        }
        statut = starLoginManager.getRecord(sQuery + " WHERE ID=" + statutid, "statutrdv", "");
        dbr = starLoginManager.getDBRecord();
        nom = statut.getData(1);
        if (bolAdding)
        {
            color = Color.BLACK;
            couleur = Integer.toString(color.getRGB());
        }
        else
            couleur = statut.getData(2);
    }

    private void addRecord()
    {
        cboStatus.setEnabled(false);
        nom = txtStatus.getText();
        if (askToSave(false) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
                return;
        }
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        bolAdding = true;
        //bolEditing = true;
        bSetting = true;
        setCombos();
        bSetting = false;
        statutid = "-1";
        refreshRecord();
        //setEditMode();
        setDataToText();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    public void setColor(Color color)
    {
        this.color = color;
    }
    
    private void removeRec()
    {
        if (!statutid.equals("-1"))
        {
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), bundle.getString("DelRecord"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                //starLoginManager.removeRecord(statutid, "statuts");
                starLoginManager.updateDataBase("DELETE FROM statutrdv WHERE ID=" + statutid);
                //addRecord();
                setCombos();
                updateInstances();
                //statutid = "-1";
                refreshRecord();
                setDataToText();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        }
        else
        {
            //addRecord();
            setCombos();
            //statutid = "-1";
            refreshRecord();
            setDataToText();
        }
    }
    
    private void setTextToData()
    {
        color = txtCouleur.getBackground();
        couleur = Integer.toString(color.getRGB());
        nom = txtStatus.getText();
    }

    private void resetLangue()
    {
        setTitle(bundle.getString("GestionStatusRdv"));
        btnAdd.setText(bundle.getString("AddRecord"));
        btnRemove.setText(bundle.getString("RemoveRecord"));
        lblEtat.setText(bundle.getString("rdvSTATUS_"));
        lblCouleur.setText(bundle.getString("Color"));
        btnOK.setText(bundle.getString("Valider"));
        btnCancel.setText(bundle.getString("Cancel"));
    }

    private void setDataToText()
    {
        bSetting = true;
        if (couleur == null || couleur.equals(""))
            couleur = "-1";
        color = new Color(Integer.valueOf(couleur));
        txtCouleur.setBackground(color);
        txtStatus.setText(nom);
        bSetting = false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        pnlBoutons = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnOK = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlData = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        lblEtat = new javax.swing.JLabel();
        cboStatus = new javax.swing.JComboBox();
        jPanel4 = new javax.swing.JPanel();
        lblEtat1 = new javax.swing.JLabel();
        txtStatus = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        lblCouleur = new javax.swing.JLabel();
        txtCouleur = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlHeader.setBackground(new java.awt.Color(255, 225, 220));
        pnlHeader.setLayout(new java.awt.BorderLayout());

        pnlBoutons.setPreferredSize(new java.awt.Dimension(480, 42));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnAdd.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAdd.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAdd.setMaximumSize(new java.awt.Dimension(31, 31));
        btnAdd.setMinimumSize(new java.awt.Dimension(29, 29));
        btnAdd.setPreferredSize(new java.awt.Dimension(115, 32));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnAdd);

        btnRemove.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnRemove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemove.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemove.setMaximumSize(new java.awt.Dimension(31, 31));
        btnRemove.setMinimumSize(new java.awt.Dimension(29, 29));
        btnRemove.setPreferredSize(new java.awt.Dimension(115, 32));
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnRemove);

        btnOK.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setDefaultCapable(false);
        btnOK.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnOK.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnOK.setPreferredSize(new java.awt.Dimension(115, 32));
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnCancel.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCancel.setPreferredSize(new java.awt.Dimension(115, 32));
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        pnlHeader.add(pnlBoutons, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pnlHeader, java.awt.BorderLayout.NORTH);

        pnlData.setPreferredSize(new java.awt.Dimension(485, 86));

        jPanel9.setPreferredSize(new java.awt.Dimension(470, 23));
        jPanel9.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblEtat.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblEtat.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel9.add(lblEtat);

        cboStatus.setMaximumRowCount(20);
        cboStatus.setPreferredSize(new java.awt.Dimension(320, 22));
        cboStatus.setRenderer(new StarLogin.IHM.components.ComboStatusRenderer());
        cboStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStatusActionPerformed(evt);
            }
        });
        jPanel9.add(cboStatus);

        pnlData.add(jPanel9);

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblEtat1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblEtat1.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel4.add(lblEtat1);

        txtStatus.setPreferredSize(new java.awt.Dimension(320, 22));
        txtStatus.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtStatusKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtStatusKeyPressed(evt);
            }
        });
        jPanel4.add(txtStatus);

        pnlData.add(jPanel4);

        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        lblCouleur.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblCouleur.setPreferredSize(new java.awt.Dimension(150, 22));
        jPanel8.add(lblCouleur);

        txtCouleur.setEditable(false);
        txtCouleur.setPreferredSize(new java.awt.Dimension(320, 22));
        txtCouleur.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtCouleurMouseClicked(evt);
            }
        });
        jPanel8.add(txtCouleur);

        pnlData.add(jPanel8);

        getContentPane().add(pnlData, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddActionPerformed
    {//GEN-HEADEREND:event_btnAddActionPerformed
        addRecord();
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveActionPerformed
    {//GEN-HEADEREND:event_btnRemoveActionPerformed
        if (cboStatus.getSelectedIndex()>4)
            removeRec();
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void txtCouleurMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtCouleurMouseClicked
    {//GEN-HEADEREND:event_txtCouleurMouseClicked
        color = txtCouleur.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null)
            return;
        txtCouleur.setBackground(color);
        couleur = Integer.toString(color.getRGB());
        bolEditing = true;
        setEditMode();
    }//GEN-LAST:event_txtCouleurMouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        nom = txtStatus.getText();
        if (askToSave(true) == JOptionPane.YES_OPTION)
        {
            if (save()== false)
            {
                setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            }
            else
                setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
        else
        {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        }
    }//GEN-LAST:event_formWindowClosing

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        /*bolEditing = false;
        bolAdding = false;
        //statutid = "-1";
        bSetting = true;
        if (cmStatus.getSize()>0)
            cboStatus.setSelectedIndex(0);
        else
            cboStatus.setSelectedIndex(-1);
        bSetting = false;
        statutid = null2String(cmStatus.getElementAt(cboStatus.getSelectedIndex()));
        //setNormalMode();
        refreshRecord();
        setDataToText();
        cboStatus.setEnabled(true);*/
        bolEditing = false;
        bolAdding = false;
        setVisible(false);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        save();
    }//GEN-LAST:event_btnOKActionPerformed

    private void cboStatusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboStatusActionPerformed
    {//GEN-HEADEREND:event_cboStatusActionPerformed
        if (bSetting)
        {
            return;
        }
        statutid = null2String(cmStatus.getElementAt(cboStatus.getSelectedIndex()));
        if (statutid.equals(""))
            statutid = "-1";
        if (bolEditing||bolAdding)
        {
            if (askToSave(false) == JOptionPane.YES_OPTION)
            {
                save();
            }
            else
            {
                refreshRecord();
                setDataToText();
            }
        }
        else
        {
            refreshRecord();
            setDataToText();
        }
    }//GEN-LAST:event_cboStatusActionPerformed

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private void txtStatusKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStatusKeyPressed
    {//GEN-HEADEREND:event_txtStatusKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtStatus.setText(nom);
        }
        else
        {
            bolEditing = true;
            setEditMode();
        }
    }//GEN-LAST:event_txtStatusKeyPressed

    private void txtStatusKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtStatusKeyTyped
    {//GEN-HEADEREND:event_txtStatusKeyTyped
        int size = 50;
        if (txtStatus.getText().length() >= size)
        {
            txtStatus.setText(txtStatus.getText().substring(0, size - 1));
        }
    }//GEN-LAST:event_txtStatusKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnRemove;
    private javax.swing.JComboBox cboStatus;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblCouleur;
    private javax.swing.JLabel lblEtat;
    private javax.swing.JLabel lblEtat1;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlData;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JTextField txtCouleur;
    private javax.swing.JTextField txtStatus;
    // End of variables declaration//GEN-END:variables
}
