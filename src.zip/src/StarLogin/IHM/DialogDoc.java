/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.Systeme.Enum.AlignOptions;
import StarLogin.Systeme.Enum.WidthOption;
import com.wildcrest.j2printerworks.J2Printer;
import com.wildcrest.j2printerworks.J2TextPrinter;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.AccessControlException;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.*;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
/**
 *
 * @author francoisdeschamps
 */
public class DialogDoc extends javax.swing.JDialog
{
    private Color color;
    private ResourceBundle bundle = MainClass.bundle;
    private String classname = this.getClass().getName();
    private HTMLDocument document;
    private UndoManager undo = new UndoManager();
    private static String currentDirectory = null;
    private String lines = "";
    private String columns = "";
    private byte align = AlignOptions._default;
    private String border = "";
    private String cellPadding = "";
    private String cellSpacing = "";
    private String tableWidth = "";
    private boolean specifyWidth = false;
    private byte widthOption;
    private DialogDoc current = this;
    private Window parent;
    
    /**
     * Creates new form DialogDoc
     */
    public DialogDoc(java.awt.Dialog parent, boolean modal, HTMLDocument doc, String title)
    {
        super(parent, modal);
        this.parent = parent;
        setDlg(doc, title);
    }
    
    public DialogDoc(java.awt.Frame parent, boolean modal, HTMLDocument doc, String title)
    {
        super(parent, modal);
        this.parent = parent;
        setDlg(doc, title);
    }
    
    private void setDlg(HTMLDocument doc, String title)
    {
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        setTitle(title);
                
        btnBKColor.setVisible(false);

        document = doc;//(HTMLDocument) textPane.getStyledDocument();
        textPane.setStyledDocument(doc);
        textPane.setSelectionStart(0);
        textPane.setSelectionEnd(0);
        undo.discardAllEdits();
        setLast();
    }
    
    @SuppressWarnings("unchecked")
    private void setLast()
    {
        document.addUndoableEditListener(new UndoableEditListener()
        {
            @Override
            public void undoableEditHappened(UndoableEditEvent e)
            {
                undo.addEdit(e.getEdit());
            }
        });
        
        int pos = classname.lastIndexOf(".");
        if (pos > 0)
            classname = classname.substring(pos + 1);
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        

        //fill in the lists for the font size and name
        String fontList[] = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        cboSize.addItem("6");
        cboSize.addItem("8");
        cboSize.addItem("10");
        cboSize.addItem("12");
        cboSize.addItem("14");
        cboSize.addItem("16");
        cboSize.addItem("18");
        cboSize.addItem("20");
        cboSize.addItem("24");
        cboSize.addItem("28");
        cboSize.addItem("36");
        cboSize.addItem("48");
        cboSize.addItem("72");
        cboSize.setSelectedIndex(3);
        for (int i = 0; i < fontList.length; i++)
        {
            cboFonts.addItem(fontList[i]);
        }
        cboFonts.setSelectedItem("Dialog");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setVisible(true);
    }
    
    public DialogDoc(java.awt.Frame parent, boolean modal, String fileName)
    {
        super(parent, modal);

        File f = new File(fileName);
        if (f.exists() == false)
        {
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            MainClass.setMessage(bundle.getString("NoFile"), JOptionPane.WARNING_MESSAGE);
            return;
        }

        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        
        setTitle(f.getName());
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/doc.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);

        //StyleContext sc = new StyleContext();

        try
        {
            textPane.setPage("file:"+f.getAbsolutePath());
        }
        catch (IOException io)
        {
            MainClass.setMessage(io.getMessage());
        }

        document = (HTMLDocument) textPane.getStyledDocument();
        
        setLast();
    }

/*
    public void resetUndo()
    {
        undo.discardAllEdits();
    }*/

    public void setLines(String lines)
    {
        this.lines = lines;
    }

    public String getLines()
    {
        return lines;
    }

    public void setColumns(String columns)
    {
        this.columns = columns;
    }

    public String getColumns()
    {
        return columns;
    }

    public void setBorder(String border)
    {
        this.border = border;
    }

    public String getBorder()
    {
        return border;
    }

    public void setCellPadding(String cellPadding)
    {
        this.cellPadding = cellPadding;
    }

    public String getCellPading()
    {
        return cellPadding;
    }

    public void setCellSpacing(String cellSpacing)
    {
        this.cellSpacing = cellSpacing;
    }

    public String getCellSpacing()
    {
        return cellSpacing;
    }

    public void setTableWidth(String tableWidth)
    {
        this.tableWidth = tableWidth;
    }

    public String getTableWidth()
    {
        return tableWidth;
    }

    public void setSpecifyWidth(boolean specifyWidth)
    {
        this.specifyWidth = specifyWidth;
    }

    public boolean getSpecifyWidth()
    {
        return specifyWidth;
    }

    public void setWidthOption(byte widthOption)
    {
        this.widthOption = widthOption;
    }

    public byte getWidthOption()
    {
        return widthOption;
    }

    public void setAlign(byte align)
    {
        this.align = align;
    }

    public byte getAlign()
    {
        return align;
    }

    public void setColor(Color color)
    {
        this.color = color;
    }

    public Color getColor()
    {
        return color;
    }
/*
    public JTextPane getTextPane()
    {
        return textPane;
    }

    public DefaultStyledDocument getDocument()
    {
        return document;
    }*/


    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT
     * modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBoutons = new javax.swing.JPanel();
        pnlBoutons1 = new javax.swing.JPanel();
        btnSave = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        btnCopy = new javax.swing.JButton();
        btnCut = new javax.swing.JButton();
        btnPaste = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        btnInsertPicture = new javax.swing.JButton();
        btnTable = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        btnFGColor = new javax.swing.JButton();
        btnBKColor = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        btnBold = new javax.swing.JButton();
        btnItalic = new javax.swing.JButton();
        cboFonts = new javax.swing.JComboBox();
        cboSize = new javax.swing.JComboBox();
        pnlBoutons2 = new javax.swing.JPanel();
        btnLeftAlign = new javax.swing.JButton();
        btnCenter = new javax.swing.JButton();
        btnRightAlign = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        btnBullets = new javax.swing.JButton();
        btnLeftIndent = new javax.swing.JButton();
        btnRightIndent = new javax.swing.JButton();
        btnFirstLineIndent = new javax.swing.JButton();
        btnSpaceAbove = new javax.swing.JButton();
        btnSpaceBelow = new javax.swing.JButton();
        btnLineSpacing = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();
        btnUndo = new javax.swing.JButton();
        btnRedo = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        btnFind = new javax.swing.JButton();
        txtFind = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textPane = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        pnlBoutons.setBackground(new java.awt.Color(255, 255, 255));
        pnlBoutons.setPreferredSize(new java.awt.Dimension(850, 72));
        pnlBoutons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 2));

        pnlBoutons1.setOpaque(false);
        pnlBoutons1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 2, 0));

        btnSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/save2.png"))); // NOI18N
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        btnSave.setToolTipText(bundle.getString("Save")); // NOI18N
        btnSave.setBorder(null);
        btnSave.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnSave);

        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/printer2.png"))); // NOI18N
        btnPrint.setToolTipText(bundle.getString("Print")); // NOI18N
        btnPrint.setBorder(null);
        btnPrint.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnPrint);

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator1.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator1.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator1.setOpaque(true);
        jSeparator1.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons1.add(jSeparator1);

        btnCopy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/copy.png"))); // NOI18N
        btnCopy.setToolTipText(bundle.getString("Copy")); // NOI18N
        btnCopy.setBorder(null);
        btnCopy.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCopy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCopyActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnCopy);

        btnCut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cut.png"))); // NOI18N
        btnCut.setToolTipText(bundle.getString("Cut")); // NOI18N
        btnCut.setBorder(null);
        btnCut.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCutActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnCut);

        btnPaste.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/paste.png"))); // NOI18N
        btnPaste.setToolTipText(bundle.getString("Paste")); // NOI18N
        btnPaste.setBorder(null);
        btnPaste.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnPaste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPasteActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnPaste);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator4.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator4.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator4.setOpaque(true);
        jSeparator4.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons1.add(jSeparator4);

        btnInsertPicture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/insertpicture.png"))); // NOI18N
        btnInsertPicture.setToolTipText(bundle.getString("InsertPicture")); // NOI18N
        btnInsertPicture.setBorder(null);
        btnInsertPicture.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnInsertPicture.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertPictureActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnInsertPicture);

        btnTable.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
        btnTable.setToolTipText(bundle.getString("InsertTable")); // NOI18N
        btnTable.setBorder(null);
        btnTable.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnTable.setPreferredSize(new java.awt.Dimension(32, 32));
        btnTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTableActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnTable);

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator2.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator2.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator2.setOpaque(true);
        jSeparator2.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons1.add(jSeparator2);

        btnFGColor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/fontcolor.png"))); // NOI18N
        btnFGColor.setToolTipText(bundle.getString("TextColor")); // NOI18N
        btnFGColor.setBorder(null);
        btnFGColor.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFGColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFGColorActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnFGColor);

        btnBKColor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/bkcolor.png"))); // NOI18N
        btnBKColor.setToolTipText(bundle.getString("BackgroundColor")); // NOI18N
        btnBKColor.setBorder(null);
        btnBKColor.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnBKColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBKColorActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnBKColor);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator3.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator3.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator3.setOpaque(true);
        jSeparator3.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons1.add(jSeparator3);

        btnBold.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/bold.png"))); // NOI18N
        btnBold.setToolTipText(bundle.getString("Bold")); // NOI18N
        btnBold.setBorder(null);
        btnBold.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnBold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBoldActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnBold);

        btnItalic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/italic.png"))); // NOI18N
        btnItalic.setToolTipText(bundle.getString("Italic")); // NOI18N
        btnItalic.setBorder(null);
        btnItalic.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnItalic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItalicActionPerformed(evt);
            }
        });
        pnlBoutons1.add(btnItalic);

        cboFonts.setMaximumRowCount(20);
        cboFonts.setPreferredSize(new java.awt.Dimension(360, 25));
        cboFonts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFontsActionPerformed(evt);
            }
        });
        pnlBoutons1.add(cboFonts);

        cboSize.setEditable(true);
        cboSize.setMaximumRowCount(20);
        cboSize.setPreferredSize(new java.awt.Dimension(100, 25));
        cboSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboSizeActionPerformed(evt);
            }
        });
        pnlBoutons1.add(cboSize);

        pnlBoutons.add(pnlBoutons1);

        pnlBoutons2.setOpaque(false);
        pnlBoutons2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 2, 0));

        btnLeftAlign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/alignleft.png"))); // NOI18N
        btnLeftAlign.setToolTipText(bundle.getString("LeftAlign")); // NOI18N
        btnLeftAlign.setBorder(null);
        btnLeftAlign.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnLeftAlign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLeftAlignActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnLeftAlign);

        btnCenter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/center.png"))); // NOI18N
        btnCenter.setToolTipText(bundle.getString("Center")); // NOI18N
        btnCenter.setBorder(null);
        btnCenter.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCenter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCenterActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnCenter);

        btnRightAlign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/alignright.png"))); // NOI18N
        btnRightAlign.setToolTipText(bundle.getString("RightAlign")); // NOI18N
        btnRightAlign.setBorder(null);
        btnRightAlign.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRightAlign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRightAlignActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnRightAlign);

        jSeparator7.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator7.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator7.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator7.setOpaque(true);
        jSeparator7.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons2.add(jSeparator7);

        btnBullets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/bullets.png"))); // NOI18N
        btnBullets.setToolTipText(bundle.getString("Bullet")); // NOI18N
        btnBullets.setBorder(null);
        btnBullets.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnBullets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBulletsActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnBullets);

        btnLeftIndent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/indentleft.png"))); // NOI18N
        btnLeftIndent.setToolTipText(bundle.getString("LeftIndent")); // NOI18N
        btnLeftIndent.setBorder(null);
        btnLeftIndent.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnLeftIndent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLeftIndentActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnLeftIndent);

        btnRightIndent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/indentright.png"))); // NOI18N
        btnRightIndent.setToolTipText(bundle.getString("RightIndent")); // NOI18N
        btnRightIndent.setBorder(null);
        btnRightIndent.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRightIndent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRightIndentActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnRightIndent);

        btnFirstLineIndent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/firstlineindent.png"))); // NOI18N
        btnFirstLineIndent.setToolTipText(bundle.getString("FirstLineIndent")); // NOI18N
        btnFirstLineIndent.setBorder(null);
        btnFirstLineIndent.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFirstLineIndent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstLineIndentActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnFirstLineIndent);

        btnSpaceAbove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/spaceabove.png"))); // NOI18N
        btnSpaceAbove.setToolTipText(bundle.getString("SpaceAbove")); // NOI18N
        btnSpaceAbove.setBorder(null);
        btnSpaceAbove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnSpaceAbove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpaceAboveActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnSpaceAbove);

        btnSpaceBelow.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/spacebelow.png"))); // NOI18N
        btnSpaceBelow.setToolTipText(bundle.getString("SpaceBelow")); // NOI18N
        btnSpaceBelow.setBorder(null);
        btnSpaceBelow.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnSpaceBelow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpaceBelowActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnSpaceBelow);

        btnLineSpacing.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/linespacing.png"))); // NOI18N
        btnLineSpacing.setToolTipText(bundle.getString("LineSpacing")); // NOI18N
        btnLineSpacing.setBorder(null);
        btnLineSpacing.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnLineSpacing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLineSpacingActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnLineSpacing);

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator5.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator5.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator5.setOpaque(true);
        jSeparator5.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons2.add(jSeparator5);

        btnUndo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/undo.png"))); // NOI18N
        btnUndo.setToolTipText(bundle.getString("Undo")); // NOI18N
        btnUndo.setBorder(null);
        btnUndo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUndoActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnUndo);

        btnRedo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/redo.png"))); // NOI18N
        btnRedo.setToolTipText(bundle.getString("Redo")); // NOI18N
        btnRedo.setBorder(null);
        btnRedo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRedo.setMaximumSize(new java.awt.Dimension(25, 25));
        btnRedo.setMinimumSize(new java.awt.Dimension(25, 25));
        btnRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRedoActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnRedo);

        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator6.setMaximumSize(new java.awt.Dimension(3, 24));
        jSeparator6.setMinimumSize(new java.awt.Dimension(1, 24));
        jSeparator6.setOpaque(true);
        jSeparator6.setPreferredSize(new java.awt.Dimension(2, 24));
        pnlBoutons2.add(jSeparator6);

        btnFind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/lookfor.png"))); // NOI18N
        btnFind.setToolTipText(bundle.getString("Find")); // NOI18N
        btnFind.setBorder(null);
        btnFind.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFind.setPreferredSize(new java.awt.Dimension(32, 32));
        btnFind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindActionPerformed(evt);
            }
        });
        pnlBoutons2.add(btnFind);

        txtFind.setPreferredSize(new java.awt.Dimension(390, 20));
        pnlBoutons2.add(txtFind);

        pnlBoutons.add(pnlBoutons2);

        getContentPane().add(pnlBoutons, java.awt.BorderLayout.NORTH);

        jPanel2.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setPreferredSize(new java.awt.Dimension(800, 600));

        textPane.setEditorKit(new HTMLEditorKit());
        textPane.setStyledDocument(new HTMLDocument());
        jScrollPane1.setViewportView(textPane);

        jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveActionPerformed
    {//GEN-HEADEREND:event_btnSaveActionPerformed
        //show the open file dialog box
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        File selectedFile;
        final JFileChooser fc = new JFileChooser();
        fc.setDialogTitle(bundle.getString("SaveAsStarLoginDocument"));
        fc.setAcceptAllFileFilterUsed(false);   //can select only the defined filter
        fc.setMultiSelectionEnabled(false);     //only one file can be selected
        //fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("HTML", "html", "htm"));
        fc.setDialogType(JFileChooser.SAVE_DIALOG);
        if (currentDirectory != null && !currentDirectory.equals(""))
        {
            fc.setCurrentDirectory(new File(currentDirectory));
        }
        fc.addChoosableFileFilter(new StarLoginDocFilter());   //HTML document filter

        int returnVal = fc.showSaveDialog(this);
        String fileName = null;
        //click on the OK button --> get the file absolute path
        if (returnVal == JFileChooser.APPROVE_OPTION)
        {
            selectedFile = fc.getSelectedFile();
            fileName = selectedFile.getAbsolutePath();
            if (!fileName.substring(fileName.length() - 4).toLowerCase().equals(".htm"))
            {
                fileName = fileName.concat(".htm");
            }
            currentDirectory = selectedFile.getParent();
        }
        if (fileName == null)
        {
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            return;
        }

        FileWriter writer = null;
        try
        {
            writer = new FileWriter(fileName);
            textPane.write(writer);
        }
        catch (IOException io)
        {
            JOptionPane.showMessageDialog(this, bundle.getString("NotSaved"), io.getMessage(), JOptionPane.ERROR_MESSAGE);
        }
        finally
        {
            if (writer != null)
            {
                try
                {
                    writer.close();
                }
                catch (IOException x)
                {
                }
            }
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

        textPane.grabFocus();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrintActionPerformed
    {//GEN-HEADEREND:event_btnPrintActionPerformed
        try
        {
            J2Printer printer = new J2Printer("17E-51C-4D3-4F4");
            J2TextPrinter textPrinter = new J2TextPrinter();
            textPrinter.setPane(textPane);
            textPrinter.setCenterHeader("StarLogin 7.1 - 2009");
            textPrinter.setLeftHeader("Fran�ois Deschamps = Joseph Stroberg");
            textPrinter.setRightHeader("jstroberg@yahoo.com");
            printer.setPageable(textPrinter);
            printer.print();
        }
        catch (AccessControlException ace)
        {
            JOptionPane.showMessageDialog(this, bundle.getString("PrinterAccessErrMessage"), bundle.getString("PrinterAccessError"), JOptionPane.ERROR_MESSAGE);
        }
        catch (Exception ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        textPane.grabFocus();
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnCopyActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCopyActionPerformed
    {//GEN-HEADEREND:event_btnCopyActionPerformed
        textPane.grabFocus();
        textPane.copy();
    }//GEN-LAST:event_btnCopyActionPerformed

    private void btnCutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCutActionPerformed
    {//GEN-HEADEREND:event_btnCutActionPerformed
        textPane.grabFocus();
        textPane.cut();
    }//GEN-LAST:event_btnCutActionPerformed

    private void btnPasteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPasteActionPerformed
    {//GEN-HEADEREND:event_btnPasteActionPerformed
        textPane.grabFocus();
        textPane.paste();
    }//GEN-LAST:event_btnPasteActionPerformed

    private void btnInsertPictureActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnInsertPictureActionPerformed
    {//GEN-HEADEREND:event_btnInsertPictureActionPerformed
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        File selectedFile;
        final JFileChooser fc = new JFileChooser();
        fc.setDialogTitle(bundle.getString("SelectingAPictureFile"));
        fc.setAcceptAllFileFilterUsed(false);   //can select only the defined filter
        fc.setMultiSelectionEnabled(false);     //only one file can be selected
        fc.setAccessory(new ImagePreview(fc));  //image previewer
        fc.setDialogType(JFileChooser.OPEN_DIALOG);
        if (currentDirectory != null && !currentDirectory.equals(""))
        {
            fc.setCurrentDirectory(new File(currentDirectory));
        }
        fc.addChoosableFileFilter(new ImageFilter());   //gif and jpeg filter

        int returnVal = fc.showOpenDialog(this);
        //click on the OK button --> get the file absolute path
        if (returnVal == JFileChooser.APPROVE_OPTION)
        {
            selectedFile = fc.getSelectedFile();
            String picture = selectedFile.getAbsolutePath();
            currentDirectory = selectedFile.getParent();
            if ((picture != null) && (!picture.equals("")))
            {
                File file = new File(picture);
                if (file != null && file.exists())
                {
                    try
                    {
                        HTMLEditorKit kit = (HTMLEditorKit) textPane.getEditorKit();
                        String fileName = "file:" + file.getAbsolutePath();//.toURL().toString();
                        kit.insertHTML(document, textPane.getCaretPosition(), "<img src=\"" + fileName + "\">", 0, 0, HTML.Tag.IMG);
                    }
                    catch (Exception e)
                    {
                        JOptionPane.showMessageDialog(this, bundle.getString("ImageNotLoaded"), e.getMessage(), JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnInsertPictureActionPerformed

    private void btnTableActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnTableActionPerformed
    {//GEN-HEADEREND:event_btnTableActionPerformed
        try
        {
            HTMLEditorKit kit = (HTMLEditorKit) textPane.getEditorKit();

            String table = "<table";

            //ask for the table characteristics
            new DialogHTMLTable(this, true).setVisible(true);

            //set the beginning TAG
            table = table.concat(" bgcolor=\"#CCFFCC\" bordercolor=\"#000000\" border=\"" + border + "\" cellpadding=\"" + cellPadding + "\" cellspacing=\"" + cellSpacing + "\"");
            switch (align)
            {
                case AlignOptions.left:
                    table = table.concat(" align=\"left\"");
                    break;
                case AlignOptions.center:
                    table = table.concat(" align=\"center\"");
                    break;
                case AlignOptions.right:
                    table = table.concat(" align=\"right\"");
                    break;
                default:
                    ;
            }
            if (specifyWidth = true)
            {
                table = table.concat(" width=\"" + tableWidth);
                if (widthOption == WidthOption.pixels)
                {
                    table = table.concat("px\"");
                }
                else
                {
                    table = table.concat("%\"");
                }
            }
            table = table.concat(">");

            //set the table rows and columns
            for (int i = 0; i < new Integer(lines).intValue(); i++)   //rows
            {
                table = table.concat("<tr>");
                for (int j = 0; j < new Integer(columns).intValue(); j++)   //columns
                {
                    table = table.concat("<td>_</td>");
                }
                table = table.concat("</tr>");
            }

            //set the final TAG
            table = table.concat("</table>");

            //insert the table
            kit.insertHTML(document, textPane.getCaretPosition(), table, 0, 0, HTML.Tag.TABLE);
        }
        catch (Exception ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }//GEN-LAST:event_btnTableActionPerformed

    private void btnFGColorActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFGColorActionPerformed
    {//GEN-HEADEREND:event_btnFGColorActionPerformed
        new DialogColor(this, true, Color.black).setVisible(true);
        if (color == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setForeground(s, color);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnFGColorActionPerformed

    private void btnBKColorActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBKColorActionPerformed
    {//GEN-HEADEREND:event_btnBKColorActionPerformed
        new DialogColor(this, true, Color.white).setVisible(true);
        if (color == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setBackground(s, color);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnBKColorActionPerformed

    private void btnBoldActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBoldActionPerformed
    {//GEN-HEADEREND:event_btnBoldActionPerformed
        textPane.grabFocus();
        Element element;
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        if (selectEnd == 0)
        {
            element = document.getCharacterElement(selectEnd);
        }
        else
        {
            element = document.getCharacterElement(selectEnd - 1);
        }
        AttributeSet attributeSet = element.getAttributes();
        boolean bold = StyleConstants.isBold(attributeSet);
        bold = !bold;
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setBold(s, bold);
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnBoldActionPerformed

    private void btnItalicActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnItalicActionPerformed
    {//GEN-HEADEREND:event_btnItalicActionPerformed
        textPane.grabFocus();
        Element element;
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        if (selectEnd == 0)
        {
            element = document.getCharacterElement(selectEnd);
        }
        else
        {
            element = document.getCharacterElement(selectEnd - 1);
        }
        AttributeSet attributeSet = element.getAttributes();
        boolean italic = StyleConstants.isItalic(attributeSet);
        italic = !italic;
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setItalic(s, italic);
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnItalicActionPerformed

    private void cboFontsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboFontsActionPerformed
    {//GEN-HEADEREND:event_cboFontsActionPerformed
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        String fontName = cboFonts.getSelectedItem().toString();
        StyleConstants.setFontFamily(s, fontName);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_cboFontsActionPerformed

    private void cboSizeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboSizeActionPerformed
    {//GEN-HEADEREND:event_cboSizeActionPerformed
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        int size = new Integer(cboSize.getSelectedItem().toString()).intValue();
        StyleConstants.setFontSize(s, size);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setCharacterAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_cboSizeActionPerformed

    private void btnLeftAlignActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLeftAlignActionPerformed
    {//GEN-HEADEREND:event_btnLeftAlignActionPerformed
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setAlignment(s, StyleConstants.ALIGN_LEFT);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnLeftAlignActionPerformed

    private void btnCenterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCenterActionPerformed
    {//GEN-HEADEREND:event_btnCenterActionPerformed
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setAlignment(s, StyleConstants.ALIGN_CENTER);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnCenterActionPerformed

    private void btnRightAlignActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRightAlignActionPerformed
    {//GEN-HEADEREND:event_btnRightAlignActionPerformed
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setAlignment(s, StyleConstants.ALIGN_RIGHT);
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnRightAlignActionPerformed

    private void btnBulletsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBulletsActionPerformed
    {//GEN-HEADEREND:event_btnBulletsActionPerformed
        textPane.grabFocus();
        Element element;
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        int pos = selectStart;

        try
        {
            while (pos < selectEnd)
            {
                element = document.getCharacterElement(pos);
                pos = element.getStartOffset();
                AttributeSet attributeSet = element.getAttributes();
                document.insertString(pos, "\u25CF ", attributeSet);
                pos = element.getEndOffset() + 1;
            }
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }//GEN-LAST:event_btnBulletsActionPerformed

    private void btnLeftIndentActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLeftIndentActionPerformed
    {//GEN-HEADEREND:event_btnLeftIndentActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getLeftIndent(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("LeftIndent"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setLeftIndent(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnLeftIndentActionPerformed

    private void btnRightIndentActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRightIndentActionPerformed
    {//GEN-HEADEREND:event_btnRightIndentActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getRightIndent(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("RightIndent"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setRightIndent(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnRightIndentActionPerformed

    private void btnFirstLineIndentActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstLineIndentActionPerformed
    {//GEN-HEADEREND:event_btnFirstLineIndentActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getFirstLineIndent(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("FirstLineIndent"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setFirstLineIndent(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnFirstLineIndentActionPerformed

    private void btnSpaceAboveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSpaceAboveActionPerformed
    {//GEN-HEADEREND:event_btnSpaceAboveActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getSpaceAbove(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("SpaceAbove"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setSpaceAbove(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnSpaceAboveActionPerformed

    private void btnSpaceBelowActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSpaceBelowActionPerformed
    {//GEN-HEADEREND:event_btnSpaceBelowActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getSpaceBelow(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("SpaceBelow"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setSpaceBelow(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnSpaceBelowActionPerformed

    private void btnLineSpacingActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLineSpacingActionPerformed
    {//GEN-HEADEREND:event_btnLineSpacingActionPerformed
        Element element = document.getCharacterElement(textPane.getCaretPosition());
        AttributeSet attributeSet = element.getAttributes();
        float fValue = StyleConstants.getLineSpacing(attributeSet);
        String value = String.valueOf(fValue);
        value = JOptionPane.showInputDialog(this, bundle.getString("LineSpacing"), value);
        if (value == null)
        {
            return;
        }
        textPane.grabFocus();
        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        StyleConstants.setLineSpacing(s, new Float(value).floatValue());
        int selectEnd = textPane.getSelectionEnd();
        int selectStart = textPane.getSelectionStart();
        document.setParagraphAttributes(selectStart, selectEnd - selectStart, s, false);
    }//GEN-LAST:event_btnLineSpacingActionPerformed

    private void btnUndoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnUndoActionPerformed
    {//GEN-HEADEREND:event_btnUndoActionPerformed
        textPane.grabFocus();
        try
        {
            undo.undo();
        }
        catch (CannotUndoException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }//GEN-LAST:event_btnUndoActionPerformed

    private void btnRedoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRedoActionPerformed
    {//GEN-HEADEREND:event_btnRedoActionPerformed
        textPane.grabFocus();
        try
        {
            undo.redo();
        }
        catch (CannotRedoException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }//GEN-LAST:event_btnRedoActionPerformed

    private void btnFindActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFindActionPerformed
    {//GEN-HEADEREND:event_btnFindActionPerformed
        textPane.grabFocus();
        String strText = "";
        try
        {
            strText = document.getText(0, document.getLength());
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        String strFind = txtFind.getText();
        int pos = strText.indexOf(strFind, textPane.getCaretPosition());
        int posEnd;
        if (pos >= 0)
        {
            posEnd = pos + strFind.length();
            textPane.grabFocus();
            textPane.setSelectionStart(pos);
            textPane.setSelectionEnd(posEnd);
            //or we could use :  textPane.setCaretPosition(pos);
            //and             :  textPane.moveCaretPosition(posEnd);
        }
        else
        {
            pos = strText.indexOf(strFind, 0);
            if (pos >= 0)
            {
                posEnd = pos + strFind.length();
                textPane.grabFocus();
                textPane.setSelectionStart(pos);
                textPane.setSelectionEnd(posEnd);
            }
            else
            {
                txtFind.setText("? ? ?");
                textPane.setCaretPosition(0);
                textPane.moveCaretPosition(document.getLength());
            }
        }
    }//GEN-LAST:event_btnFindActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        int w = this.getBounds().width;
        if (w < 1697-34)
        {
            pnlBoutons.setPreferredSize(new Dimension(10,72));
            pnlBoutons.setSize(new Dimension(w,72));
        }
        else
        {
            pnlBoutons.setPreferredSize(new Dimension(10,36));
            pnlBoutons.setSize(new Dimension(w,36));
        }
        pnlBoutons.paintImmediately(pnlBoutons.getBounds());
        jPanel2.paintImmediately(jPanel2.getBounds());
        current.paintAll(current.getGraphics());
    }//GEN-LAST:event_formComponentResized

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        Rectangle rct = this.getBounds();
        int state = 0;
        MainClass.starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
    }//GEN-LAST:event_formWindowClosing

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBKColor;
    private javax.swing.JButton btnBold;
    private javax.swing.JButton btnBullets;
    private javax.swing.JButton btnCenter;
    private javax.swing.JButton btnCopy;
    private javax.swing.JButton btnCut;
    private javax.swing.JButton btnFGColor;
    private javax.swing.JButton btnFind;
    private javax.swing.JButton btnFirstLineIndent;
    private javax.swing.JButton btnInsertPicture;
    private javax.swing.JButton btnItalic;
    private javax.swing.JButton btnLeftAlign;
    private javax.swing.JButton btnLeftIndent;
    private javax.swing.JButton btnLineSpacing;
    private javax.swing.JButton btnPaste;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnRedo;
    private javax.swing.JButton btnRightAlign;
    private javax.swing.JButton btnRightIndent;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSpaceAbove;
    private javax.swing.JButton btnSpaceBelow;
    private javax.swing.JButton btnTable;
    private javax.swing.JButton btnUndo;
    private javax.swing.JComboBox cboFonts;
    private javax.swing.JComboBox cboSize;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlBoutons1;
    private javax.swing.JPanel pnlBoutons2;
    private javax.swing.JTextPane textPane;
    private javax.swing.JTextField txtFind;
    // End of variables declaration//GEN-END:variables
}
