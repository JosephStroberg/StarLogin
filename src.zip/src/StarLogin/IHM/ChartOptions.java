
package StarLogin.IHM;

import StarLogin.IHM.components.KeyType.KTUnsignedDecimal;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Enum.CoordSystem;
import StarLogin.Systeme.Enum.HouseSystem;
import StarLogin.Systeme.Enum.Planets;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartOptions extends javax.swing.JDialog
{
    private ChartElements chartElements;
    private DrawChart drawChart;
    //private Option defaultOption;
    private int kc; //key code
    private boolean bHouseCalc = false;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    
    /** Creates new form ChartChoiceForm */
    public ChartOptions(java.awt.Frame parent, boolean modal, ChartElements chartElements, DrawChart drawChart)
    {
        super(parent, modal);
        this.drawChart = drawChart;
        this.chartElements = chartElements;
        //defaultOption = MainClass.getCurrentOption();
        initComponents();
        resetLangue();
        tabSettings.setTitleAt(0, bundle.getString("CoordinatesSystem"));
        tabSettings.setTitleAt(1, bundle.getString("HousesSystem"));
        tabSettings.setTitleAt(2, bundle.getString("ChartLook"));
        tabSettings.setTitleAt(3, bundle.getString("Planets"));
        tabSettings.setTitleAt(4, bundle.getString("Aspects"));
        tabSettings.setTitleAt(5, bundle.getString("Orbs"));
        tabSettings.setTitleAt(6, bundle.getString("Composite"));
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/config.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        /*cboD2.addItem(bundle.getString("year"));
        cboD2.addItem(bundle.getString("month"));
        cboD2.addItem(bundle.getString("week"));*/
        
        chkHeliocentricNormal.setVisible(false);
        chkHeliocentricSidereal.setVisible(false);
        lblOtherAspectValue.setText(new Double(chartElements.getOtherAspectValue()).toString());
        
        //Get the default options
        //-----------------------
        //coordinates system
        int system = chartElements.getCoordSys();
        switch (system)
        {
            case CoordSystem.Tropical:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
                break;
            case CoordSystem.Sidereal:
                chkGeocentric.setSelected(true);
                chkSidereal.setSelected(true);
                break;
            case CoordSystem.Local:
                chkGeocentric.setSelected(true);
                chkLocal.setSelected(true);
                break;
            case CoordSystem.Domitudes:
                chkGeocentric.setSelected(true);
                chkDomitudes.setSelected(true);
                break;
            case CoordSystem.Equatorial:
                chkGeocentric.setSelected(true);
                chkEquatorial.setSelected(true);
                break;
            case CoordSystem.Ecliptic:
                chkGeocentric.setSelected(true);
                chkEcliptic.setSelected(true);
                break;
            case CoordSystem.HelioNormal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricNormal.setSelected(true);
                break;
            case CoordSystem.HelioSidereal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricSidereal.setSelected(true);
                break;
            default:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
        }
        boolean bolHelio = chkHeliocentric.isSelected();
        chkTropical.setVisible(!bolHelio);
        chkSidereal.setVisible(!bolHelio);
        chkEquatorial.setVisible(!bolHelio);
        chkEcliptic.setVisible(!bolHelio);
        chkLocal.setVisible(!bolHelio);
        chkDomitudes.setVisible(!bolHelio);
        chkHeliocentricNormal.setVisible(bolHelio);
        chkHeliocentricSidereal.setVisible(bolHelio);
        
        //houses system
        int domif = chartElements.getHouseSys();
        switch (domif)
        {
            case HouseSystem.Abenragel:
                optAbenragel.setSelected(true);
                break;
            case HouseSystem.Albategnius:
                optAlbategnius.setSelected(true);
                break;
            case HouseSystem.Alcabitius:
                optAlcabitius.setSelected(true);
                break;
            case HouseSystem.Ancient:
                optAncient.setSelected(true);
                break;
            case HouseSystem.Bazchenoff:
                optBazchenoff.setSelected(true);
                break;
            case HouseSystem.Campanus:
                optCampanus.setSelected(true);
                break;
            case HouseSystem.ColinEvans:
                optColinEvans.setSelected(true);
                break;
            case HouseSystem.EquatorialRegular:
                optEquatorialRegular.setSelected(true);
                break;
            case HouseSystem.Koch:
                optKoch.setSelected(true);
                break;
            case HouseSystem.MaternusAs:
                optMaternusAs.setSelected(true);
                break;
            case HouseSystem.MaternusMC:
                optMaternusMC.setSelected(true);
                break;
            case HouseSystem.Nodal:
                optNodal.setSelected(true);
                break;
            case HouseSystem.Placidus:
                optPlacidus.setSelected(true);
                break;
            case HouseSystem.Porphyre:
                optPorpyre.setSelected(true);
                break;
            case HouseSystem.Regiomontanus:
                optRegiomontanus.setSelected(true);
                break;
            case HouseSystem.SemiAngular:
                optSemiAngular.setSelected(true);
                break;
            case HouseSystem.Solar:
                optSolar.setSelected(true);
                break;
            case HouseSystem.TwoHours:
                optTwoHours.setSelected(true);
                break;
            case HouseSystem.Wiesel:
                optWiesel.setSelected(true);
                break;
            case HouseSystem.Zenithal:
                optZenithal.setSelected(true);
                break;
            case HouseSystem.Zodiacal:
                optZodiacal.setSelected(true);
                break;
            default:
                optCampanus.setSelected(true);
        }
        
        
        //other aspect
        chkOtherAspect.setSelected(chartElements.getShownAspect17());
        lblOtherAspectValue.setText(new Double(chartElements.getOtherAspectValue()).toString());
        
        //chart sizes
        sldZodiac.setValue(chartElements.getZodiacSize());
        int sSize = chartElements.getSignSize();
        int pSize = chartElements.getPlanetSize();
        int cSize = chartElements.getCharacterSize();
        sldSigns.setValue(sSize);
        sldPlanets.setValue(pSize);
        sldCharacters.setValue(cSize);
        
        //selected planets
        chkSun.setSelected(chartElements.getShownSun());
        chkMoon.setSelected(chartElements.getShownMoon());
        chkMercury.setSelected(chartElements.getShownMercury());
        chkVenus.setSelected(chartElements.getShownVenus());
        chkMars.setSelected(chartElements.getShownMars());
        chkJupiter.setSelected(chartElements.getShownJupiter());
        chkSaturn.setSelected(chartElements.getShownSaturn());
        chkUranus.setSelected(chartElements.getShownUranus());
        chkNeptune.setSelected(chartElements.getShownNeptune());
        chkPluto.setSelected(chartElements.getShownPluto());
        chkGaia.setSelected(chartElements.getShownGaia());
        chkNN.setSelected(chartElements.getShownNorthNode());
        chkLilith.setSelected(chartElements.getShownLilith());
        chkTrueLilith.setSelected(chartElements.getTrueLilith());
        chkEast.setSelected(chartElements.getShownEast());
        chkZenith.setSelected(chartElements.getShownZenith());
        chkVertex.setSelected(chartElements.getShownVertex());
        chkVulcan.setSelected(chartElements.getShownVulcan());
        chkCeres.setSelected(chartElements.getShownCeres());
        chkPallas.setSelected(chartElements.getShownPallas());
        chkJuno.setSelected(chartElements.getShownJuno());
        chkVesta.setSelected(chartElements.getShownVesta());
        chkChiron.setSelected(chartElements.getShownChiron());
        chkOtherPoint.setSelected(chartElements.getShownOtherPoint());
        
        //aspects definition
        chkConjunction.setSelected(chartElements.getShownAspect0());
        chkSextile.setSelected(chartElements.getShownAspect1());
        chkSquare.setSelected(chartElements.getShownAspect2());
        chkTrine.setSelected(chartElements.getShownAspect3());
        chkOpposition.setSelected(chartElements.getShownAspect4());
        chkVigintile.setSelected(chartElements.getShownAspect5());
        chkSemiSextile.setSelected(chartElements.getShownAspect6());
        chkSemiQuintile.setSelected(chartElements.getShownAspect7());
        chkNonagon.setSelected(chartElements.getShownAspect8());
        chkSemiSquare.setSelected(chartElements.getShownAspect9());
        chkSeptile.setSelected(chartElements.getShownAspect10());
        chkQuintile.setSelected(chartElements.getShownAspect11());
        chkTriDectile.setSelected(chartElements.getShownAspect12());
        chkSesquiSquare.setSelected(chartElements.getShownAspect13());
        chkBiQuintile.setSelected(chartElements.getShownAspect14());
        chkInconjunct.setSelected(chartElements.getShownAspect15());
        chkQuadriNonagon.setSelected(chartElements.getShownAspect16());
        
        //Aspected planets
        chkAspectSun.setSelected(chartElements.getAspectsSun());
        chkAspectMoon.setSelected(chartElements.getAspectsMoon());
        chkAspectMercury.setSelected(chartElements.getAspectsMercury());
        chkAspectVenus.setSelected(chartElements.getAspectsVenus());
        chkAspectMars.setSelected(chartElements.getAspectsMars());
        chkAspectJupiter.setSelected(chartElements.getAspectsJupiter());
        chkAspectSaturn.setSelected(chartElements.getAspectsSaturn());
        chkAspectUranus.setSelected(chartElements.getAspectsUranus());
        chkAspectNeptune.setSelected(chartElements.getAspectsNeptune());
        chkAspectPluto.setSelected(chartElements.getAspectsPluto());
        chkAspectGaia.setSelected(chartElements.getAspectsGaia());
        chkAspectNodes.setSelected(chartElements.getAspectsNorthNode());
        chkAspectLilith.setSelected(chartElements.getAspectsLilith());
        chkAspectEast.setSelected(chartElements.getAspectsEast());
        chkAspectZenith.setSelected(chartElements.getAspectsZenith());
        chkAspectVertex.setSelected(chartElements.getAspectsVertex());
        chkAspectVulcan.setSelected(chartElements.getAspectsVulcan());
        chkAspectCeres.setSelected(chartElements.getAspectsCeres());
        chkAspectPallas.setSelected(chartElements.getAspectsPallas());
        chkAspectJuno.setSelected(chartElements.getAspectsJuno());
        chkAspectVesta.setSelected(chartElements.getAspectsVesta());
        chkAspectChiron.setSelected(chartElements.getAspectsChiron());
        chkAspectAS.setSelected(chartElements.getAspectsAS());
        chkAspectMC.setSelected(chartElements.getAspectsMC());
        chkAspectOtherPoint.setSelected(chartElements.getAspectsOtherPoint());
        
        //Orbs
        txtOrbLumLum.setText(new Double(chartElements.getOrbLightLight()).toString());
        txtOrbLumIndiv.setText(new Double(chartElements.getOrbLightTell()).toString());
        txtOrbLumJS.setText(new Double(chartElements.getOrbLightOtherInd()).toString());
        txtOrbLumCol.setText(new Double(chartElements.getOrbLightColl()).toString());
        txtOrbLumVirtMaj.setText(new Double(chartElements.getOrbLightVirtMax()).toString());
        txtOrbLumVirtMin.setText(new Double(chartElements.getOrbLightVirtMin()).toString());
        txtOrbIndivIndiv.setText(new Double(chartElements.getOrbTellTell()).toString());
        txtOrbIndivJS.setText(new Double(chartElements.getOrbTellOtherInd()).toString());
        txtOrbIndivCol.setText(new Double(chartElements.getOrbTellColl()).toString());
        txtOrbIndivVirtMaj.setText(new Double(chartElements.getOrbTellVirtMax()).toString());
        txtOrbIndivVirtMin.setText(new Double(chartElements.getOrbTellVirtMin()).toString());
        txtOrbJSJS.setText(new Double(chartElements.getOrbOtherIndOtherInd()).toString());
        txtOrbJSCol.setText(new Double(chartElements.getOrbOtherIndColl()).toString());
        txtOrbJSvirtMaj.setText(new Double(chartElements.getOrbOtherIndVirtMax()).toString());
        txtOrbJSVirtMin.setText(new Double(chartElements.getOrbOtherIndVirtMin()).toString());
        txtOrbColCol.setText(new Double(chartElements.getOrbCollColl()).toString());
        txtOrbColVirtMaj.setText(new Double(chartElements.getOrbCollVirtMax()).toString());
        txtOrbColVirtMin.setText(new Double(chartElements.getOrbCollVirtMin()).toString());
        txtOrbVirtMajVirtMaj.setText(new Double(chartElements.getOrbVirtMaxVirtMax()).toString());
        txtOrbVirtMajVirtMin.setText(new Double(chartElements.getOrbVirtMaxVirtMin()).toString());
        txtOrbvirtMinVirtMin.setText(new Double(chartElements.getOrbVirtMinVirtMin()).toString());
        
        //orbs divisors
        txtDivConjunction.setText(new Double(chartElements.getDivConjunction()).toString());
        txtDivSextile.setText(new Double(chartElements.getDivSextile()).toString());
        txtDivSquare.setText(new Double(chartElements.getDivSquare()).toString());
        txtDivTrine.setText(new Double(chartElements.getDivTrine()).toString());
        txtDivOpposition.setText(new Double(chartElements.getDivOpposition()).toString());
        txtDivOther.setText(new Double(chartElements.getDivMin()).toString());
        
        //other
        chkAspectsSymbol.setSelected(chartElements.getSymbolAspects());
        chkHousesCoord.setSelected(chartElements.getHousesCoords());
        chkSignsName.setSelected(chartElements.getSignsNames());
        chkStars.setSelected(chartElements.getViewStars());
        sldStars.setValue((int)(new Double(chartElements.getLimitMag()).doubleValue() * 2.0));
        chkConstellations.setSelected(chartElements.getViewConstellations());
        chkAsteroids.setSelected(chartElements.getViewAsteroids());
        chkHouses.setSelected(chartElements.getViewHouses());
        chkAspects.setSelected(chartElements.getViewAspects());
        chkCoordinates.setSelected(chartElements.getViewCoordinates());
        chkStraightLines.setSelected(chartElements.getViewStraightLines());
        chkShaded.setSelected(chartElements.getViewShadedLines());
        chkBarycenter.setSelected(chartElements.getViewBarycenter());
        if (chartElements.getSingleWeight() == true)
        {
            optSingleWeight.setSelected(true);
        }
        else
        {
            optDifferentWeights.setSelected(true);
        }
        if (chartElements.getChartCompositeFromAS() == true)
        {
            optCompositeFromAS.setSelected(true);
        }
        else
        {
            optCompositeFromAS.setSelected(true);
        }
        if (chartElements.getLeftAsct() == true)
        {
            optEastAS.setSelected(true);
        }
        else
        {
            optEastAries.setSelected(true);
        }
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    
    
    private void resetLangue()
    {
        setTitle(bundle.getString("ChartsSelection"));
        //lblFrom.setText(bundle.getString("From"));
        chkGeocentric.setText(bundle.getString("Geocentric"));
        chkHeliocentric.setText(bundle.getString("Heliocentric"));
        chkTropical.setText(bundle.getString("Tropical"));
        chkSidereal.setText(bundle.getString("Sidereal"));
        chkEquatorial.setText(bundle.getString("Equatorial"));
        chkEcliptic.setText(bundle.getString("Ecliptic"));
        chkLocal.setText(bundle.getString("Local"));
        chkDomitudes.setText(bundle.getString("Domitudes"));
        chkHeliocentricNormal.setText(bundle.getString("HeliocentricNormal"));
        chkHeliocentricSidereal.setText(bundle.getString("HeliocentricSidereal"));
        optAncient.setText(bundle.getString("Ancient"));
        optTwoHours.setText(bundle.getString("TwoHours"));
        optSemiAngular.setText(bundle.getString("SemiAngular"));
        optEquatorialRegular.setText(bundle.getString("EquatorialRegular"));
        optColinEvans.setText(bundle.getString("ColinEvans"));
        optBazchenoff.setText(bundle.getString("Bazchenoff"));
        optNodal.setText(bundle.getString("Nodal"));
        optSolar.setText(bundle.getString("Solar"));
        optZenithal.setText(bundle.getString("Zenithal"));
        optZodiacal.setText(bundle.getString("Zodiacal"));
        jLabel22.setText(bundle.getString("Sizes"));
        jLabel30.setText(bundle.getString("Zodiac"));
        jLabel34.setText(bundle.getString("Signs"));
        jLabel38.setText(bundle.getString("Planets"));
        jLabel42.setText(bundle.getString("Characters"));
        jLabel40.setText(bundle.getString("Main"));
        chkSun.setText(bundle.getString("Sun"));
        chkMoon.setText(bundle.getString("Moon"));
        chkMercury.setText(bundle.getString("Mercury"));
        chkVenus.setText(bundle.getString("Venus"));
        chkMars.setText(bundle.getString("Mars"));
        chkJupiter.setText(bundle.getString("Jupiter"));
        chkSaturn.setText(bundle.getString("Saturn"));
        chkUranus.setText(bundle.getString("Uranus"));
        chkNeptune.setText(bundle.getString("Neptune"));
        chkPluto.setText(bundle.getString("Pluto"));
        jLabel44.setText(bundle.getString("Other"));
        chkGaia.setText(bundle.getString("Gaia"));
        chkNN.setText(bundle.getString("NorthNode"));
        chkLilith.setText(bundle.getString("Lilith"));
        chkTrueLilith.setText(bundle.getString("True"));
        chkEast.setText(bundle.getString("East"));
        chkZenith.setText(bundle.getString("Zenith"));
        chkVertex.setText(bundle.getString("Vertex"));
        chkVulcan.setText(bundle.getString("Vulcan"));
        chkCeres.setText(bundle.getString("Ceres"));
        chkPallas.setText(bundle.getString("Pallas"));
        chkJuno.setText(bundle.getString("Juno"));
        chkVesta.setText(bundle.getString("Vesta"));
        chkChiron.setText(bundle.getString("Chiron"));
        chkOtherPoint.setText(bundle.getString("OtherPoint"));
        jLabel46.setText(bundle.getString("Display"));
        chkStars.setText(bundle.getString("Stars"));
        chkConstellations.setText(bundle.getString("Constellations"));
        chkAsteroids.setText(bundle.getString("Asteroids"));
        chkHouses.setText(bundle.getString("Houses"));
        chkAspects.setText(bundle.getString("Aspects"));
        chkCoordinates.setText(bundle.getString("Coordinates"));
        chkStraightLines.setText(bundle.getString("StraightLines"));
        chkShaded.setText(bundle.getString("ShadedColors"));
        chkBarycenter.setText(bundle.getString("Barycenter"));
        optSingleWeight.setText(bundle.getString("SameWeight"));
        optDifferentWeights.setText(bundle.getString("DifferentWeights"));
        jLabel48.setText(bundle.getString("ZodiacDirection"));
        optEastAS.setText(bundle.getString("LeftAS"));
        optEastAries.setText(bundle.getString("LeftAries"));
        chkAspectsSymbol.setText(bundle.getString("AspectsSymbol"));
        chkSignsName.setText(bundle.getString("SignsName"));
        chkHousesCoord.setText(bundle.getString("HousesCoords"));
        chkConjunction.setText(bundle.getString("Conjunction"));
        chkSextile.setText(bundle.getString("Sextile"));
        chkSquare.setText(bundle.getString("Square"));
        chkTrine.setText(bundle.getString("Trine"));
        chkOpposition.setText(bundle.getString("Opposition"));
        chkVigintile.setText(bundle.getString("Vigintile"));
        chkSemiSextile.setText(bundle.getString("SemiSextile"));
        chkSemiQuintile.setText(bundle.getString("SemiQuintile"));
        chkNonagon.setText(bundle.getString("Nonagon"));
        chkSemiSquare.setText(bundle.getString("SemiSquare"));
        chkSeptile.setText(bundle.getString("Septile"));
        chkQuintile.setText(bundle.getString("Quintile"));
        chkTriDectile.setText(bundle.getString("TriDectile"));
        chkSesquiSquare.setText(bundle.getString("SesquiSquare"));
        chkBiQuintile.setText(bundle.getString("BiQuintile"));
        chkInconjunct.setText(bundle.getString("Inconjunct"));
        chkQuadriNonagon.setText(bundle.getString("QuadriNonagon"));
        chkOtherAspect.setText(bundle.getString("OtherAspect"));
        jLabel118.setFont(new java.awt.Font("StarLogin", 1, 18));
        jLabel119.setText(bundle.getString("AspectedPlanets"));
        chkAspectSun.setText(bundle.getString("Sun"));
        chkAspectMoon.setText(bundle.getString("Moon"));
        chkAspectMercury.setText(bundle.getString("Mercury"));
        chkAspectVenus.setText(bundle.getString("Venus"));
        chkAspectMars.setText(bundle.getString("Mars"));
        chkAspectJupiter.setText(bundle.getString("Jupiter"));
        chkAspectSaturn.setText(bundle.getString("Saturn"));
        chkAspectUranus.setText(bundle.getString("Uranus"));
        chkAspectNeptune.setText(bundle.getString("Neptune"));
        chkAspectPluto.setText(bundle.getString("Pluto"));
        chkAspectGaia.setText(bundle.getString("Gaia"));
        chkAspectNodes.setText(bundle.getString("NorthNode"));
        chkAspectLilith.setText(bundle.getString("Lilith"));
        chkAspectEast.setText(bundle.getString("East"));
        chkAspectZenith.setText(bundle.getString("Zenith"));
        chkAspectVertex.setText(bundle.getString("Vertex"));
        chkAspectVulcan.setText(bundle.getString("Vulcan"));
        chkAspectCeres.setText(bundle.getString("Ceres"));
        chkAspectPallas.setText(bundle.getString("Pallas"));
        chkAspectJuno.setText(bundle.getString("Juno"));
        chkAspectVesta.setText(bundle.getString("Vesta"));
        chkAspectChiron.setText(bundle.getString("Chiron"));
        chkAspectAS.setText(bundle.getString("Ascendant"));
        chkAspectMC.setText(bundle.getString("Midheaven"));
        chkAspectOtherPoint.setText(bundle.getString("OtherPointName"));
    }
    
    private String getPlanetID(JComboBox planet)
    {
        String planetName = planet.getSelectedItem().toString();
        for (byte i=0; i<Planets.getLast(); i++)
        {
            String strName = Planets.getPlanetName(i);
            if (strName.equals(planetName))
            {
                return new Integer(i).toString();
            }
        }
        return "-1";
    }
    
    /*private String getPlaceID(Places allPlaces, String placeName)
    {
        ArrayList p = allPlaces.getPlaces();
        for (int i=0; i<p.size() ; i++)
        {
            ArrayList v = (ArrayList)p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1));
            if (strName.equals(placeName))
            {
                return strID;
            }
        }
        return "-1";
    }*/
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpChartChoice = new javax.swing.ButtonGroup();
        grpSavedCharts = new javax.swing.ButtonGroup();
        grpGeoHelio = new javax.swing.ButtonGroup();
        grpGeo = new javax.swing.ButtonGroup();
        grpHelio = new javax.swing.ButtonGroup();
        grpHouseSystem = new javax.swing.ButtonGroup();
        grpAstronView = new javax.swing.ButtonGroup();
        grpBarycenter = new javax.swing.ButtonGroup();
        grpZodDir = new javax.swing.ButtonGroup();
        grpColorMode = new javax.swing.ButtonGroup();
        grpOtherPoint = new javax.swing.ButtonGroup();
        grpSynastrySelect = new javax.swing.ButtonGroup();
        grpCompositeSelect = new javax.swing.ButtonGroup();
        grpCompositeFrom = new javax.swing.ButtonGroup();
        tabSettings = new javax.swing.JTabbedPane();
        pnlCoordSystem = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        chkGeocentric = new javax.swing.JRadioButton();
        chkHeliocentric = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        chkTropical = new javax.swing.JRadioButton();
        chkSidereal = new javax.swing.JRadioButton();
        chkEquatorial = new javax.swing.JRadioButton();
        chkEcliptic = new javax.swing.JRadioButton();
        chkLocal = new javax.swing.JRadioButton();
        chkDomitudes = new javax.swing.JRadioButton();
        chkHeliocentricNormal = new javax.swing.JRadioButton();
        chkHeliocentricSidereal = new javax.swing.JRadioButton();
        pnlHouseSystem = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        optAncient = new javax.swing.JRadioButton();
        optTwoHours = new javax.swing.JRadioButton();
        optSemiAngular = new javax.swing.JRadioButton();
        optCampanus = new javax.swing.JRadioButton();
        optEquatorialRegular = new javax.swing.JRadioButton();
        optColinEvans = new javax.swing.JRadioButton();
        optBazchenoff = new javax.swing.JRadioButton();
        optMaternusAs = new javax.swing.JRadioButton();
        optMaternusMC = new javax.swing.JRadioButton();
        optNodal = new javax.swing.JRadioButton();
        optPorpyre = new javax.swing.JRadioButton();
        optRegiomontanus = new javax.swing.JRadioButton();
        optSolar = new javax.swing.JRadioButton();
        optWiesel = new javax.swing.JRadioButton();
        optZenithal = new javax.swing.JRadioButton();
        optZodiacal = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        optAbenragel = new javax.swing.JRadioButton();
        optAlbategnius = new javax.swing.JRadioButton();
        optAlcabitius = new javax.swing.JRadioButton();
        optKoch = new javax.swing.JRadioButton();
        optPlacidus = new javax.swing.JRadioButton();
        pnlChartLook = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        sldZodiac = new javax.swing.JSlider();
        lblZodiacSize = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        sldSigns = new javax.swing.JSlider();
        lblSignSize = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        sldPlanets = new javax.swing.JSlider();
        lblPlanetSize = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        sldCharacters = new javax.swing.JSlider();
        lblCharactersSize = new javax.swing.JLabel();
        pnlPlanets = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        chkSun = new javax.swing.JCheckBox();
        chkMoon = new javax.swing.JCheckBox();
        chkMercury = new javax.swing.JCheckBox();
        chkVenus = new javax.swing.JCheckBox();
        chkMars = new javax.swing.JCheckBox();
        chkJupiter = new javax.swing.JCheckBox();
        chkSaturn = new javax.swing.JCheckBox();
        chkUranus = new javax.swing.JCheckBox();
        chkNeptune = new javax.swing.JCheckBox();
        chkPluto = new javax.swing.JCheckBox();
        jPanel50 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        chkGaia = new javax.swing.JCheckBox();
        chkNN = new javax.swing.JCheckBox();
        jPanel56 = new javax.swing.JPanel();
        chkLilith = new javax.swing.JCheckBox();
        chkTrueLilith = new javax.swing.JCheckBox();
        chkEast = new javax.swing.JCheckBox();
        chkZenith = new javax.swing.JCheckBox();
        chkVertex = new javax.swing.JCheckBox();
        chkVulcan = new javax.swing.JCheckBox();
        chkCeres = new javax.swing.JCheckBox();
        chkPallas = new javax.swing.JCheckBox();
        chkJuno = new javax.swing.JCheckBox();
        chkVesta = new javax.swing.JCheckBox();
        chkChiron = new javax.swing.JCheckBox();
        chkOtherPoint = new javax.swing.JCheckBox();
        jPanel52 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        chkStars = new javax.swing.JCheckBox();
        sldStars = new javax.swing.JSlider();
        jLabel50 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        chkConstellations = new javax.swing.JCheckBox();
        chkAsteroids = new javax.swing.JCheckBox();
        chkHouses = new javax.swing.JCheckBox();
        chkAspects = new javax.swing.JCheckBox();
        chkCoordinates = new javax.swing.JCheckBox();
        chkStraightLines = new javax.swing.JCheckBox();
        chkShaded = new javax.swing.JCheckBox();
        jPanel62 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        chkBarycenter = new javax.swing.JCheckBox();
        optSingleWeight = new javax.swing.JRadioButton();
        optDifferentWeights = new javax.swing.JRadioButton();
        jPanel63 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        optEastAS = new javax.swing.JRadioButton();
        optEastAries = new javax.swing.JRadioButton();
        chkAspectsSymbol = new javax.swing.JCheckBox();
        chkSignsName = new javax.swing.JCheckBox();
        chkHousesCoord = new javax.swing.JCheckBox();
        pnlAspects = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jPanel90 = new javax.swing.JPanel();
        jPanel72 = new javax.swing.JPanel();
        chkConjunction = new javax.swing.JCheckBox();
        jLabel60 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jPanel73 = new javax.swing.JPanel();
        chkSextile = new javax.swing.JCheckBox();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        chkSquare = new javax.swing.JCheckBox();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jPanel75 = new javax.swing.JPanel();
        chkTrine = new javax.swing.JCheckBox();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jPanel76 = new javax.swing.JPanel();
        chkOpposition = new javax.swing.JCheckBox();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jPanel77 = new javax.swing.JPanel();
        chkVigintile = new javax.swing.JCheckBox();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        chkSemiSextile = new javax.swing.JCheckBox();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jPanel79 = new javax.swing.JPanel();
        chkSemiQuintile = new javax.swing.JCheckBox();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        chkNonagon = new javax.swing.JCheckBox();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jPanel81 = new javax.swing.JPanel();
        chkSemiSquare = new javax.swing.JCheckBox();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jPanel82 = new javax.swing.JPanel();
        chkSeptile = new javax.swing.JCheckBox();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        chkQuintile = new javax.swing.JCheckBox();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        chkTriDectile = new javax.swing.JCheckBox();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jPanel85 = new javax.swing.JPanel();
        chkSesquiSquare = new javax.swing.JCheckBox();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        chkBiQuintile = new javax.swing.JCheckBox();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        chkInconjunct = new javax.swing.JCheckBox();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        chkQuadriNonagon = new javax.swing.JCheckBox();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jPanel89 = new javax.swing.JPanel();
        chkOtherAspect = new javax.swing.JCheckBox();
        lblOtherAspectValue = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jPanel69 = new javax.swing.JPanel();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        chkAspectSun = new javax.swing.JCheckBox();
        chkAspectMoon = new javax.swing.JCheckBox();
        chkAspectMercury = new javax.swing.JCheckBox();
        chkAspectVenus = new javax.swing.JCheckBox();
        chkAspectMars = new javax.swing.JCheckBox();
        chkAspectJupiter = new javax.swing.JCheckBox();
        chkAspectSaturn = new javax.swing.JCheckBox();
        chkAspectUranus = new javax.swing.JCheckBox();
        chkAspectNeptune = new javax.swing.JCheckBox();
        chkAspectPluto = new javax.swing.JCheckBox();
        chkAspectGaia = new javax.swing.JCheckBox();
        chkAspectNodes = new javax.swing.JCheckBox();
        chkAspectLilith = new javax.swing.JCheckBox();
        chkAspectEast = new javax.swing.JCheckBox();
        chkAspectZenith = new javax.swing.JCheckBox();
        chkAspectVertex = new javax.swing.JCheckBox();
        chkAspectVulcan = new javax.swing.JCheckBox();
        chkAspectCeres = new javax.swing.JCheckBox();
        chkAspectPallas = new javax.swing.JCheckBox();
        chkAspectJuno = new javax.swing.JCheckBox();
        chkAspectVesta = new javax.swing.JCheckBox();
        chkAspectChiron = new javax.swing.JCheckBox();
        chkAspectAS = new javax.swing.JCheckBox();
        chkAspectMC = new javax.swing.JCheckBox();
        chkAspectOtherPoint = new javax.swing.JCheckBox();
        pnlOrbs = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jPanel98 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jPanel99 = new javax.swing.JPanel();
        jLabel70 = new javax.swing.JLabel();
        jPanel100 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jPanel101 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jPanel102 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jPanel103 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        jPanel104 = new javax.swing.JPanel();
        txtOrbLumLum = new javax.swing.JTextField();
        jPanel105 = new javax.swing.JPanel();
        txtOrbLumIndiv = new javax.swing.JTextField();
        jPanel106 = new javax.swing.JPanel();
        txtOrbLumJS = new javax.swing.JTextField();
        jPanel107 = new javax.swing.JPanel();
        txtOrbLumCol = new javax.swing.JTextField();
        jPanel108 = new javax.swing.JPanel();
        txtOrbLumVirtMaj = new javax.swing.JTextField();
        jPanel109 = new javax.swing.JPanel();
        txtOrbLumVirtMin = new javax.swing.JTextField();
        jPanel110 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jPanel111 = new javax.swing.JPanel();
        jPanel113 = new javax.swing.JPanel();
        txtOrbIndivIndiv = new javax.swing.JTextField();
        jPanel114 = new javax.swing.JPanel();
        txtOrbIndivJS = new javax.swing.JTextField();
        jPanel115 = new javax.swing.JPanel();
        txtOrbIndivCol = new javax.swing.JTextField();
        jPanel116 = new javax.swing.JPanel();
        txtOrbIndivVirtMaj = new javax.swing.JTextField();
        jPanel117 = new javax.swing.JPanel();
        txtOrbIndivVirtMin = new javax.swing.JTextField();
        jPanel118 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jPanel119 = new javax.swing.JPanel();
        jPanel120 = new javax.swing.JPanel();
        jPanel121 = new javax.swing.JPanel();
        txtOrbJSJS = new javax.swing.JTextField();
        jPanel122 = new javax.swing.JPanel();
        txtOrbJSCol = new javax.swing.JTextField();
        jPanel123 = new javax.swing.JPanel();
        txtOrbJSvirtMaj = new javax.swing.JTextField();
        jPanel124 = new javax.swing.JPanel();
        txtOrbJSVirtMin = new javax.swing.JTextField();
        jPanel125 = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jPanel126 = new javax.swing.JPanel();
        jPanel127 = new javax.swing.JPanel();
        jPanel128 = new javax.swing.JPanel();
        jPanel129 = new javax.swing.JPanel();
        txtOrbColCol = new javax.swing.JTextField();
        jPanel130 = new javax.swing.JPanel();
        txtOrbColVirtMaj = new javax.swing.JTextField();
        jPanel131 = new javax.swing.JPanel();
        txtOrbColVirtMin = new javax.swing.JTextField();
        jPanel132 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jPanel133 = new javax.swing.JPanel();
        jPanel134 = new javax.swing.JPanel();
        jPanel135 = new javax.swing.JPanel();
        jPanel136 = new javax.swing.JPanel();
        jPanel137 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMaj = new javax.swing.JTextField();
        jPanel138 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMin = new javax.swing.JTextField();
        jPanel139 = new javax.swing.JPanel();
        jLabel98 = new javax.swing.JLabel();
        jPanel140 = new javax.swing.JPanel();
        jPanel141 = new javax.swing.JPanel();
        jPanel142 = new javax.swing.JPanel();
        jPanel143 = new javax.swing.JPanel();
        jPanel144 = new javax.swing.JPanel();
        jPanel112 = new javax.swing.JPanel();
        txtOrbvirtMinVirtMin = new javax.swing.JTextField();
        jPanel95 = new javax.swing.JPanel();
        jPanel145 = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        jPanel146 = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        jPanel147 = new javax.swing.JPanel();
        jLabel107 = new javax.swing.JLabel();
        jPanel148 = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        jPanel149 = new javax.swing.JPanel();
        jLabel113 = new javax.swing.JLabel();
        jPanel150 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        jPanel151 = new javax.swing.JPanel();
        jLabel117 = new javax.swing.JLabel();
        txtDivConjunction = new javax.swing.JTextField();
        jPanel152 = new javax.swing.JPanel();
        jLabel120 = new javax.swing.JLabel();
        txtDivSextile = new javax.swing.JTextField();
        jPanel153 = new javax.swing.JPanel();
        jLabel121 = new javax.swing.JLabel();
        txtDivSquare = new javax.swing.JTextField();
        jPanel154 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        txtDivTrine = new javax.swing.JTextField();
        jPanel155 = new javax.swing.JPanel();
        jLabel123 = new javax.swing.JLabel();
        txtDivOpposition = new javax.swing.JTextField();
        jPanel156 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        txtDivOther = new javax.swing.JTextField();
        pnlComposite = new javax.swing.JPanel();
        lblFrom = new javax.swing.JLabel();
        optCompositeFromAS = new javax.swing.JRadioButton();
        optCompositeFromMC = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        btnClose = new javax.swing.JButton();

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        setTitle(bundle.getString("ChartsSelection")); // NOI18N
        setMinimumSize(new java.awt.Dimension(800, 594));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        tabSettings.setPreferredSize(new java.awt.Dimension(1024, 642));

        pnlCoordSystem.setLayout(new java.awt.BorderLayout());

        jPanel5.setPreferredSize(new java.awt.Dimension(210, 460));
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel2.setPreferredSize(new java.awt.Dimension(200, 75));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        grpGeoHelio.add(chkGeocentric);
        chkGeocentric.setSelected(true);
        chkGeocentric.setText(bundle.getString("Geocentric")); // NOI18N
        chkGeocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkGeocentric.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkGeocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkGeocentric);

        grpGeoHelio.add(chkHeliocentric);
        chkHeliocentric.setText(bundle.getString("Heliocentric")); // NOI18N
        chkHeliocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkHeliocentric);

        jPanel5.add(jPanel2);

        jPanel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 0, 5));
        jPanel3.setPreferredSize(new java.awt.Dimension(210, 460));

        grpGeo.add(chkTropical);
        chkTropical.setSelected(true);
        chkTropical.setText(bundle.getString("Tropical")); // NOI18N
        chkTropical.setMaximumSize(new java.awt.Dimension(175, 31));
        chkTropical.setMinimumSize(new java.awt.Dimension(175, 31));
        chkTropical.setPreferredSize(new java.awt.Dimension(200, 31));
        chkTropical.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTropicalActionPerformed(evt);
            }
        });
        jPanel3.add(chkTropical);

        grpGeo.add(chkSidereal);
        chkSidereal.setText(bundle.getString("Sidereal")); // NOI18N
        chkSidereal.setMaximumSize(new java.awt.Dimension(175, 31));
        chkSidereal.setMinimumSize(new java.awt.Dimension(175, 31));
        chkSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkSidereal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkSidereal);

        grpGeo.add(chkEquatorial);
        chkEquatorial.setText(bundle.getString("Equatorial")); // NOI18N
        chkEquatorial.setMaximumSize(new java.awt.Dimension(175, 31));
        chkEquatorial.setMinimumSize(new java.awt.Dimension(175, 31));
        chkEquatorial.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEquatorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEquatorialActionPerformed(evt);
            }
        });
        jPanel3.add(chkEquatorial);

        grpGeo.add(chkEcliptic);
        chkEcliptic.setText(bundle.getString("Ecliptic")); // NOI18N
        chkEcliptic.setMaximumSize(new java.awt.Dimension(175, 31));
        chkEcliptic.setMinimumSize(new java.awt.Dimension(175, 31));
        chkEcliptic.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEcliptic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEclipticActionPerformed(evt);
            }
        });
        jPanel3.add(chkEcliptic);

        grpGeo.add(chkLocal);
        chkLocal.setText(bundle.getString("Local")); // NOI18N
        chkLocal.setMaximumSize(new java.awt.Dimension(175, 31));
        chkLocal.setMinimumSize(new java.awt.Dimension(175, 31));
        chkLocal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkLocalActionPerformed(evt);
            }
        });
        jPanel3.add(chkLocal);

        grpGeo.add(chkDomitudes);
        chkDomitudes.setText(bundle.getString("Domitudes")); // NOI18N
        chkDomitudes.setMaximumSize(new java.awt.Dimension(175, 31));
        chkDomitudes.setMinimumSize(new java.awt.Dimension(175, 31));
        chkDomitudes.setPreferredSize(new java.awt.Dimension(200, 31));
        chkDomitudes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDomitudesActionPerformed(evt);
            }
        });
        jPanel3.add(chkDomitudes);

        grpHelio.add(chkHeliocentricNormal);
        chkHeliocentricNormal.setSelected(true);
        chkHeliocentricNormal.setText(bundle.getString("HeliocentricNormal")); // NOI18N
        chkHeliocentricNormal.setMaximumSize(new java.awt.Dimension(200, 31));
        chkHeliocentricNormal.setMinimumSize(new java.awt.Dimension(200, 31));
        chkHeliocentricNormal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricNormalActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricNormal);

        grpHelio.add(chkHeliocentricSidereal);
        chkHeliocentricSidereal.setText(bundle.getString("HeliocentricSidereal")); // NOI18N
        chkHeliocentricSidereal.setMaximumSize(new java.awt.Dimension(200, 31));
        chkHeliocentricSidereal.setMinimumSize(new java.awt.Dimension(200, 31));
        chkHeliocentricSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricSidereal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricSidereal);

        jPanel5.add(jPanel3);

        pnlCoordSystem.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        tabSettings.addTab("Coordinates system", null, pnlCoordSystem, "");

        pnlHouseSystem.setLayout(new java.awt.BorderLayout());

        jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel4.setPreferredSize(new java.awt.Dimension(250, 521));
        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.Y_AXIS));

        grpHouseSystem.add(optAncient);
        optAncient.setText(bundle.getString("Ancient")); // NOI18N
        optAncient.setMaximumSize(new java.awt.Dimension(235, 24));
        optAncient.setMinimumSize(new java.awt.Dimension(235, 24));
        optAncient.setPreferredSize(new java.awt.Dimension(235, 24));
        optAncient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAncientActionPerformed(evt);
            }
        });
        jPanel4.add(optAncient);

        grpHouseSystem.add(optTwoHours);
        optTwoHours.setText(bundle.getString("TwoHours")); // NOI18N
        optTwoHours.setMaximumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setMinimumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setPreferredSize(new java.awt.Dimension(235, 24));
        optTwoHours.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optTwoHoursActionPerformed(evt);
            }
        });
        jPanel4.add(optTwoHours);

        grpHouseSystem.add(optSemiAngular);
        optSemiAngular.setText(bundle.getString("SemiAngular")); // NOI18N
        optSemiAngular.setMaximumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setMinimumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setPreferredSize(new java.awt.Dimension(235, 24));
        optSemiAngular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSemiAngularActionPerformed(evt);
            }
        });
        jPanel4.add(optSemiAngular);

        grpHouseSystem.add(optCampanus);
        optCampanus.setSelected(true);
        optCampanus.setText("Campanus");
        optCampanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optCampanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optCampanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optCampanus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optCampanusActionPerformed(evt);
            }
        });
        jPanel4.add(optCampanus);

        grpHouseSystem.add(optEquatorialRegular);
        optEquatorialRegular.setText(bundle.getString("EquatorialRegular")); // NOI18N
        optEquatorialRegular.setMaximumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setMinimumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setPreferredSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optEquatorialRegularActionPerformed(evt);
            }
        });
        jPanel4.add(optEquatorialRegular);

        grpHouseSystem.add(optColinEvans);
        optColinEvans.setText(bundle.getString("ColinEvans")); // NOI18N
        optColinEvans.setMaximumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setMinimumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setPreferredSize(new java.awt.Dimension(235, 24));
        optColinEvans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optColinEvansActionPerformed(evt);
            }
        });
        jPanel4.add(optColinEvans);

        grpHouseSystem.add(optBazchenoff);
        optBazchenoff.setText(bundle.getString("Bazchenoff")); // NOI18N
        optBazchenoff.setMaximumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setMinimumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setPreferredSize(new java.awt.Dimension(235, 24));
        optBazchenoff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optBazchenoffActionPerformed(evt);
            }
        });
        jPanel4.add(optBazchenoff);

        grpHouseSystem.add(optMaternusAs);
        optMaternusAs.setText("Maternus / AS");
        optMaternusAs.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusAsActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusAs);

        grpHouseSystem.add(optMaternusMC);
        optMaternusMC.setText("Maternus / MC");
        optMaternusMC.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusMC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusMCActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusMC);

        grpHouseSystem.add(optNodal);
        optNodal.setText(bundle.getString("Nodal")); // NOI18N
        optNodal.setMaximumSize(new java.awt.Dimension(235, 24));
        optNodal.setMinimumSize(new java.awt.Dimension(235, 24));
        optNodal.setPreferredSize(new java.awt.Dimension(235, 24));
        optNodal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optNodalActionPerformed(evt);
            }
        });
        jPanel4.add(optNodal);

        grpHouseSystem.add(optPorpyre);
        optPorpyre.setText("Porphyre");
        optPorpyre.setMaximumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setMinimumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setPreferredSize(new java.awt.Dimension(235, 24));
        optPorpyre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPorpyreActionPerformed(evt);
            }
        });
        jPanel4.add(optPorpyre);

        grpHouseSystem.add(optRegiomontanus);
        optRegiomontanus.setText("Regiomontanus");
        optRegiomontanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optRegiomontanusActionPerformed(evt);
            }
        });
        jPanel4.add(optRegiomontanus);

        grpHouseSystem.add(optSolar);
        optSolar.setText(bundle.getString("Solar")); // NOI18N
        optSolar.setMaximumSize(new java.awt.Dimension(235, 24));
        optSolar.setMinimumSize(new java.awt.Dimension(235, 24));
        optSolar.setPreferredSize(new java.awt.Dimension(235, 24));
        optSolar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSolarActionPerformed(evt);
            }
        });
        jPanel4.add(optSolar);

        grpHouseSystem.add(optWiesel);
        optWiesel.setText("Wiesel");
        optWiesel.setMaximumSize(new java.awt.Dimension(235, 24));
        optWiesel.setMinimumSize(new java.awt.Dimension(235, 24));
        optWiesel.setPreferredSize(new java.awt.Dimension(235, 24));
        optWiesel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optWieselActionPerformed(evt);
            }
        });
        jPanel4.add(optWiesel);

        grpHouseSystem.add(optZenithal);
        optZenithal.setText(bundle.getString("Zenithal")); // NOI18N
        optZenithal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZenithal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZenithal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZenithal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZenithalActionPerformed(evt);
            }
        });
        jPanel4.add(optZenithal);

        grpHouseSystem.add(optZodiacal);
        optZodiacal.setText(bundle.getString("Zodiacal")); // NOI18N
        optZodiacal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZodiacal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZodiacalActionPerformed(evt);
            }
        });
        jPanel4.add(optZodiacal);

        jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator1.setMaximumSize(new java.awt.Dimension(32767, 2));
        jSeparator1.setPreferredSize(new java.awt.Dimension(235, 2));
        jPanel4.add(jSeparator1);

        grpHouseSystem.add(optAbenragel);
        optAbenragel.setText("Abenragel");
        optAbenragel.setMaximumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setMinimumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setPreferredSize(new java.awt.Dimension(235, 24));
        optAbenragel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAbenragelActionPerformed(evt);
            }
        });
        jPanel4.add(optAbenragel);

        grpHouseSystem.add(optAlbategnius);
        optAlbategnius.setText("Albategnius");
        optAlbategnius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlbategnius.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlbategniusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlbategnius);

        grpHouseSystem.add(optAlcabitius);
        optAlcabitius.setText("Alcabitius");
        optAlcabitius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlcabitius.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlcabitiusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlcabitius);

        grpHouseSystem.add(optKoch);
        optKoch.setText("Koch");
        optKoch.setMaximumSize(new java.awt.Dimension(235, 24));
        optKoch.setMinimumSize(new java.awt.Dimension(235, 24));
        optKoch.setPreferredSize(new java.awt.Dimension(235, 24));
        optKoch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optKochActionPerformed(evt);
            }
        });
        jPanel4.add(optKoch);

        grpHouseSystem.add(optPlacidus);
        optPlacidus.setText("Placidus");
        optPlacidus.setMaximumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setMinimumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setPreferredSize(new java.awt.Dimension(235, 24));
        optPlacidus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPlacidusActionPerformed(evt);
            }
        });
        jPanel4.add(optPlacidus);

        pnlHouseSystem.add(jPanel4, java.awt.BorderLayout.WEST);

        tabSettings.addTab("Houses system", null, pnlHouseSystem, "");

        pnlChartLook.setLayout(new java.awt.BorderLayout());

        jPanel36.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        jPanel36.setPreferredSize(new java.awt.Dimension(20, 612));
        jPanel36.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        jPanel38.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel38.setPreferredSize(new java.awt.Dimension(224, 602));
        jPanel38.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 4));

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setAlignmentX(0.5F);
        jLabel22.setOpaque(true);
        jLabel22.setPreferredSize(new java.awt.Dimension(210, 18));
        jPanel38.add(jLabel22);

        jPanel40.setPreferredSize(new java.awt.Dimension(210, 150));
        jPanel40.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel30.setOpaque(true);
        jLabel30.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel40.add(jLabel30);

        sldZodiac.setMajorTickSpacing(10);
        sldZodiac.setMinimum(50);
        sldZodiac.setMinorTickSpacing(5);
        sldZodiac.setPaintLabels(true);
        sldZodiac.setPaintTicks(true);
        sldZodiac.setValue(75);
        sldZodiac.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldZodiacStateChanged(evt);
            }
        });
        jPanel40.add(sldZodiac);

        lblZodiacSize.setBackground(new java.awt.Color(102, 200, 255));
        lblZodiacSize.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblZodiacSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblZodiacSize.setText("%");
        lblZodiacSize.setPreferredSize(new java.awt.Dimension(200, 86));
        jPanel40.add(lblZodiacSize);

        jPanel38.add(jPanel40);

        jPanel42.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel42.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setOpaque(true);
        jLabel34.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel42.add(jLabel34);

        sldSigns.setMajorTickSpacing(2);
        sldSigns.setMaximum(72);
        sldSigns.setMinimum(10);
        sldSigns.setMinorTickSpacing(1);
        sldSigns.setPaintTicks(true);
        sldSigns.setValue(20);
        sldSigns.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldSignsStateChanged(evt);
            }
        });
        jPanel42.add(sldSigns);

        lblSignSize.setBackground(new java.awt.Color(102, 200, 255));
        lblSignSize.setFont(new java.awt.Font("StarLogin", 1, 20)); // NOI18N
        lblSignSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSignSize.setText("}");
        lblSignSize.setPreferredSize(new java.awt.Dimension(200, 86));
        jPanel42.add(lblSignSize);

        jPanel38.add(jPanel42);

        jPanel44.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel44.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setOpaque(true);
        jLabel38.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel44.add(jLabel38);

        sldPlanets.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        sldPlanets.setMajorTickSpacing(2);
        sldPlanets.setMaximum(72);
        sldPlanets.setMinimum(8);
        sldPlanets.setMinorTickSpacing(1);
        sldPlanets.setPaintTicks(true);
        sldPlanets.setValue(12);
        sldPlanets.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldPlanetsStateChanged(evt);
            }
        });
        jPanel44.add(sldPlanets);

        lblPlanetSize.setBackground(new java.awt.Color(102, 200, 255));
        lblPlanetSize.setFont(new java.awt.Font("StarLogin", 1, 14)); // NOI18N
        lblPlanetSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPlanetSize.setText("H");
        lblPlanetSize.setPreferredSize(new java.awt.Dimension(200, 86));
        jPanel44.add(lblPlanetSize);

        jPanel38.add(jPanel44);

        jPanel46.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel46.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setOpaque(true);
        jLabel42.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel46.add(jLabel42);

        sldCharacters.setMajorTickSpacing(2);
        sldCharacters.setMaximum(48);
        sldCharacters.setMinimum(8);
        sldCharacters.setMinorTickSpacing(1);
        sldCharacters.setPaintTicks(true);
        sldCharacters.setValue(10);
        sldCharacters.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldCharactersStateChanged(evt);
            }
        });
        jPanel46.add(sldCharacters);

        lblCharactersSize.setBackground(new java.awt.Color(102, 200, 255));
        lblCharactersSize.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        lblCharactersSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCharactersSize.setText("18�23'");
        lblCharactersSize.setPreferredSize(new java.awt.Dimension(200, 86));
        jPanel46.add(lblCharactersSize);

        jPanel38.add(jPanel46);

        jPanel36.add(jPanel38);

        pnlChartLook.add(jPanel36, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Chart look", null, pnlChartLook, "");

        pnlPlanets.setLayout(new java.awt.BorderLayout());

        jPanel54.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 0, 0, 0));

        jPanel48.setAlignmentX(0.0F);
        jPanel48.setAlignmentY(0.0F);
        jPanel48.setPreferredSize(new java.awt.Dimension(200, 600));

        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setAlignmentX(0.5F);
        jLabel40.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel40.setOpaque(true);
        jLabel40.setPreferredSize(new java.awt.Dimension(175, 18));
        jPanel48.add(jLabel40);

        chkSun.setSelected(true);
        chkSun.setText(bundle.getString("Sun")); // NOI18N
        chkSun.setPreferredSize(new java.awt.Dimension(175, 24));
        chkSun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSunActionPerformed(evt);
            }
        });
        jPanel48.add(chkSun);

        chkMoon.setSelected(true);
        chkMoon.setText(bundle.getString("Moon")); // NOI18N
        chkMoon.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMoonActionPerformed(evt);
            }
        });
        jPanel48.add(chkMoon);

        chkMercury.setSelected(true);
        chkMercury.setText(bundle.getString("Mercury")); // NOI18N
        chkMercury.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMercury.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMercuryActionPerformed(evt);
            }
        });
        jPanel48.add(chkMercury);

        chkVenus.setSelected(true);
        chkVenus.setText(bundle.getString("Venus")); // NOI18N
        chkVenus.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVenus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkVenusActionPerformed(evt);
            }
        });
        jPanel48.add(chkVenus);

        chkMars.setSelected(true);
        chkMars.setText(bundle.getString("Mars")); // NOI18N
        chkMars.setPreferredSize(new java.awt.Dimension(175, 24));
        chkMars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMarsActionPerformed(evt);
            }
        });
        jPanel48.add(chkMars);

        chkJupiter.setSelected(true);
        chkJupiter.setText(bundle.getString("Jupiter")); // NOI18N
        chkJupiter.setPreferredSize(new java.awt.Dimension(175, 24));
        chkJupiter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkJupiterActionPerformed(evt);
            }
        });
        jPanel48.add(chkJupiter);

        chkSaturn.setSelected(true);
        chkSaturn.setText(bundle.getString("Saturn")); // NOI18N
        chkSaturn.setPreferredSize(new java.awt.Dimension(175, 24));
        chkSaturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSaturnActionPerformed(evt);
            }
        });
        jPanel48.add(chkSaturn);

        chkUranus.setSelected(true);
        chkUranus.setText(bundle.getString("Uranus")); // NOI18N
        chkUranus.setPreferredSize(new java.awt.Dimension(175, 24));
        chkUranus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkUranusActionPerformed(evt);
            }
        });
        jPanel48.add(chkUranus);

        chkNeptune.setSelected(true);
        chkNeptune.setText(bundle.getString("Neptune")); // NOI18N
        chkNeptune.setPreferredSize(new java.awt.Dimension(175, 24));
        chkNeptune.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkNeptuneActionPerformed(evt);
            }
        });
        jPanel48.add(chkNeptune);

        chkPluto.setSelected(true);
        chkPluto.setText(bundle.getString("Pluto")); // NOI18N
        chkPluto.setPreferredSize(new java.awt.Dimension(175, 24));
        chkPluto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPlutoActionPerformed(evt);
            }
        });
        jPanel48.add(chkPluto);

        jPanel54.add(jPanel48);

        jPanel50.setAlignmentX(0.0F);
        jPanel50.setAlignmentY(0.0F);
        jPanel50.setMaximumSize(new java.awt.Dimension(200, 600));
        jPanel50.setPreferredSize(new java.awt.Dimension(200, 600));
        jPanel50.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setAlignmentX(0.5F);
        jLabel44.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel44.setOpaque(true);
        jLabel44.setPreferredSize(new java.awt.Dimension(175, 18));
        jPanel50.add(jLabel44);

        chkGaia.setText(bundle.getString("Gaia")); // NOI18N
        chkGaia.setPreferredSize(new java.awt.Dimension(175, 24));
        chkGaia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkGaiaActionPerformed(evt);
            }
        });
        jPanel50.add(chkGaia);

        chkNN.setSelected(true);
        chkNN.setText(bundle.getString("NorthNode")); // NOI18N
        chkNN.setPreferredSize(new java.awt.Dimension(175, 24));
        chkNN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkNNActionPerformed(evt);
            }
        });
        jPanel50.add(chkNN);

        jPanel56.setMaximumSize(new java.awt.Dimension(175, 24));
        jPanel56.setMinimumSize(new java.awt.Dimension(175, 24));
        jPanel56.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel56.setLayout(new javax.swing.BoxLayout(jPanel56, javax.swing.BoxLayout.LINE_AXIS));

        chkLilith.setSelected(true);
        chkLilith.setText(bundle.getString("Lilith")); // NOI18N
        chkLilith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkLilithActionPerformed(evt);
            }
        });
        jPanel56.add(chkLilith);

        chkTrueLilith.setSelected(true);
        chkTrueLilith.setText(bundle.getString("True")); // NOI18N
        chkTrueLilith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTrueLilithActionPerformed(evt);
            }
        });
        jPanel56.add(chkTrueLilith);

        jPanel50.add(jPanel56);

        chkEast.setText(bundle.getString("East")); // NOI18N
        chkEast.setPreferredSize(new java.awt.Dimension(175, 24));
        chkEast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEastActionPerformed(evt);
            }
        });
        jPanel50.add(chkEast);

        chkZenith.setText(bundle.getString("Zenith")); // NOI18N
        chkZenith.setPreferredSize(new java.awt.Dimension(175, 24));
        chkZenith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkZenithActionPerformed(evt);
            }
        });
        jPanel50.add(chkZenith);

        chkVertex.setText(bundle.getString("Vertex")); // NOI18N
        chkVertex.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVertex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkVertexActionPerformed(evt);
            }
        });
        jPanel50.add(chkVertex);

        chkVulcan.setText(bundle.getString("Vulcan")); // NOI18N
        chkVulcan.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVulcan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkVulcanActionPerformed(evt);
            }
        });
        jPanel50.add(chkVulcan);

        chkCeres.setText(bundle.getString("Ceres")); // NOI18N
        chkCeres.setPreferredSize(new java.awt.Dimension(175, 24));
        chkCeres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCeresActionPerformed(evt);
            }
        });
        jPanel50.add(chkCeres);

        chkPallas.setText(bundle.getString("Pallas")); // NOI18N
        chkPallas.setPreferredSize(new java.awt.Dimension(175, 24));
        chkPallas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPallasActionPerformed(evt);
            }
        });
        jPanel50.add(chkPallas);

        chkJuno.setText(bundle.getString("Juno")); // NOI18N
        chkJuno.setPreferredSize(new java.awt.Dimension(175, 24));
        chkJuno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkJunoActionPerformed(evt);
            }
        });
        jPanel50.add(chkJuno);

        chkVesta.setText(bundle.getString("Vesta")); // NOI18N
        chkVesta.setPreferredSize(new java.awt.Dimension(175, 24));
        chkVesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkVestaActionPerformed(evt);
            }
        });
        jPanel50.add(chkVesta);

        chkChiron.setSelected(true);
        chkChiron.setText(bundle.getString("Chiron")); // NOI18N
        chkChiron.setPreferredSize(new java.awt.Dimension(175, 24));
        chkChiron.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkChironActionPerformed(evt);
            }
        });
        jPanel50.add(chkChiron);

        chkOtherPoint.setText(bundle.getString("OtherPoint")); // NOI18N
        chkOtherPoint.setPreferredSize(new java.awt.Dimension(175, 24));
        chkOtherPoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkOtherPointActionPerformed(evt);
            }
        });
        jPanel50.add(chkOtherPoint);

        jPanel54.add(jPanel50);

        jPanel52.setAlignmentX(0.0F);
        jPanel52.setAlignmentY(0.0F);
        jPanel52.setPreferredSize(new java.awt.Dimension(310, 600));
        jPanel52.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setAlignmentX(0.5F);
        jLabel46.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel46.setOpaque(true);
        jLabel46.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(jLabel46);

        jPanel57.setPreferredSize(new java.awt.Dimension(300, 85));
        jPanel57.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        chkStars.setText(bundle.getString("Stars")); // NOI18N
        chkStars.setPreferredSize(new java.awt.Dimension(300, 18));
        chkStars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkStarsActionPerformed(evt);
            }
        });
        jPanel57.add(chkStars);

        sldStars.setMajorTickSpacing(2);
        sldStars.setMaximum(12);
        sldStars.setMinorTickSpacing(1);
        sldStars.setPaintTicks(true);
        sldStars.setValue(5);
        sldStars.setPreferredSize(new java.awt.Dimension(300, 31));
        sldStars.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldStarsStateChanged(evt);
            }
        });
        jPanel57.add(sldStars);

        jLabel50.setBackground(new java.awt.Color(102, 200, 255));
        jLabel50.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel50.setText("-");
        jLabel50.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel50.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel50.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel50.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel50.setPreferredSize(new java.awt.Dimension(150, 18));
        jPanel57.add(jLabel50);

        jLabel52.setBackground(new java.awt.Color(102, 200, 255));
        jLabel52.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel52.setText("+");
        jLabel52.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel52.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel52.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel52.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel52.setPreferredSize(new java.awt.Dimension(150, 18));
        jPanel57.add(jLabel52);

        jPanel52.add(jPanel57);

        chkConstellations.setText(bundle.getString("Constellations")); // NOI18N
        chkConstellations.setPreferredSize(new java.awt.Dimension(300, 18));
        chkConstellations.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkConstellationsActionPerformed(evt);
            }
        });
        jPanel52.add(chkConstellations);

        chkAsteroids.setSelected(true);
        chkAsteroids.setText(bundle.getString("Asteroids")); // NOI18N
        chkAsteroids.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAsteroids.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAsteroidsActionPerformed(evt);
            }
        });
        jPanel52.add(chkAsteroids);

        chkHouses.setSelected(true);
        chkHouses.setText(bundle.getString("Houses")); // NOI18N
        chkHouses.setPreferredSize(new java.awt.Dimension(300, 18));
        chkHouses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHousesActionPerformed(evt);
            }
        });
        jPanel52.add(chkHouses);

        chkAspects.setSelected(true);
        chkAspects.setText(bundle.getString("Aspects")); // NOI18N
        chkAspects.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAspects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectsActionPerformed(evt);
            }
        });
        jPanel52.add(chkAspects);

        chkCoordinates.setText(bundle.getString("Coordinates")); // NOI18N
        chkCoordinates.setPreferredSize(new java.awt.Dimension(300, 18));
        chkCoordinates.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCoordinatesActionPerformed(evt);
            }
        });
        jPanel52.add(chkCoordinates);

        chkStraightLines.setText(bundle.getString("StraightLines")); // NOI18N
        chkStraightLines.setPreferredSize(new java.awt.Dimension(300, 18));
        chkStraightLines.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkStraightLinesActionPerformed(evt);
            }
        });
        jPanel52.add(chkStraightLines);

        chkShaded.setSelected(true);
        chkShaded.setText(bundle.getString("ShadedColors")); // NOI18N
        chkShaded.setPreferredSize(new java.awt.Dimension(300, 18));
        chkShaded.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkShadedActionPerformed(evt);
            }
        });
        jPanel52.add(chkShaded);

        jPanel62.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel62.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel62.setPreferredSize(new java.awt.Dimension(210, 9));
        jPanel52.add(jPanel62);

        jPanel58.setMaximumSize(new java.awt.Dimension(210, 85));
        jPanel58.setMinimumSize(new java.awt.Dimension(210, 85));
        jPanel58.setPreferredSize(new java.awt.Dimension(300, 75));
        jPanel58.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkBarycenter.setText(bundle.getString("Barycenter")); // NOI18N
        chkBarycenter.setPreferredSize(new java.awt.Dimension(300, 18));
        chkBarycenter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkBarycenterActionPerformed(evt);
            }
        });
        jPanel58.add(chkBarycenter);

        grpBarycenter.add(optSingleWeight);
        optSingleWeight.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        optSingleWeight.setSelected(true);
        optSingleWeight.setText(bundle.getString("SameWeight")); // NOI18N
        optSingleWeight.setPreferredSize(new java.awt.Dimension(300, 24));
        optSingleWeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSingleWeightActionPerformed(evt);
            }
        });
        jPanel58.add(optSingleWeight);

        grpBarycenter.add(optDifferentWeights);
        optDifferentWeights.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        optDifferentWeights.setText(bundle.getString("DifferentWeights")); // NOI18N
        optDifferentWeights.setMaximumSize(new java.awt.Dimension(220, 24));
        optDifferentWeights.setMinimumSize(new java.awt.Dimension(220, 24));
        optDifferentWeights.setPreferredSize(new java.awt.Dimension(300, 24));
        optDifferentWeights.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optDifferentWeightsActionPerformed(evt);
            }
        });
        jPanel58.add(optDifferentWeights);

        jPanel52.add(jPanel58);

        jPanel63.setMaximumSize(new java.awt.Dimension(210, 85));
        jPanel63.setMinimumSize(new java.awt.Dimension(210, 85));
        jPanel63.setPreferredSize(new java.awt.Dimension(300, 75));
        jPanel63.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel48.setAlignmentX(0.5F);
        jLabel48.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel48.setOpaque(true);
        jLabel48.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel63.add(jLabel48);

        grpZodDir.add(optEastAS);
        optEastAS.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        optEastAS.setSelected(true);
        optEastAS.setText(bundle.getString("LeftAS")); // NOI18N
        optEastAS.setPreferredSize(new java.awt.Dimension(300, 24));
        optEastAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optEastASActionPerformed(evt);
            }
        });
        jPanel63.add(optEastAS);

        grpZodDir.add(optEastAries);
        optEastAries.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        optEastAries.setText(bundle.getString("LeftAries")); // NOI18N
        optEastAries.setPreferredSize(new java.awt.Dimension(300, 24));
        optEastAries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optEastAriesActionPerformed(evt);
            }
        });
        jPanel63.add(optEastAries);

        jPanel52.add(jPanel63);

        chkAspectsSymbol.setText(bundle.getString("AspectsSymbol")); // NOI18N
        chkAspectsSymbol.setPreferredSize(new java.awt.Dimension(300, 18));
        chkAspectsSymbol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectsSymbolActionPerformed(evt);
            }
        });
        jPanel52.add(chkAspectsSymbol);

        chkSignsName.setText(bundle.getString("SignsName")); // NOI18N
        chkSignsName.setPreferredSize(new java.awt.Dimension(300, 18));
        chkSignsName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSignsNameActionPerformed(evt);
            }
        });
        jPanel52.add(chkSignsName);

        chkHousesCoord.setText(bundle.getString("HousesCoords")); // NOI18N
        chkHousesCoord.setPreferredSize(new java.awt.Dimension(300, 18));
        chkHousesCoord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHousesCoordActionPerformed(evt);
            }
        });
        jPanel52.add(chkHousesCoord);

        jPanel54.add(jPanel52);

        pnlPlanets.add(jPanel54, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Planets", null, pnlPlanets, "");

        pnlAspects.setLayout(new java.awt.BorderLayout());

        jPanel68.setPreferredSize(new java.awt.Dimension(360, 30));
        jPanel68.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 2));

        jPanel90.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel90.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel90.setPreferredSize(new java.awt.Dimension(210, 9));
        jPanel68.add(jPanel90);

        jPanel72.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel72.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkConjunction.setSelected(true);
        chkConjunction.setText(bundle.getString("Conjunction")); // NOI18N
        chkConjunction.setPreferredSize(new java.awt.Dimension(125, 18));
        chkConjunction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkConjunctionActionPerformed(evt);
            }
        });
        jPanel72.add(chkConjunction);

        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel60.setText("0�");
        jLabel60.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel60.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel72.add(jLabel60);

        jLabel62.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel62.setText("a");
        jLabel62.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel62.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel72.add(jLabel62);

        jPanel68.add(jPanel72);

        jPanel73.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel73.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSextile.setSelected(true);
        chkSextile.setText(bundle.getString("Sextile")); // NOI18N
        chkSextile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSextile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSextileActionPerformed(evt);
            }
        });
        jPanel73.add(chkSextile);

        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel66.setText("60�");
        jLabel66.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel66.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel73.add(jLabel66);

        jLabel68.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel68.setText("b");
        jLabel68.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel68.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel73.add(jLabel68);

        jPanel68.add(jPanel73);

        jPanel74.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel74.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSquare.setSelected(true);
        chkSquare.setText(bundle.getString("Square")); // NOI18N
        chkSquare.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSquare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSquareActionPerformed(evt);
            }
        });
        jPanel74.add(chkSquare);

        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel72.setText("90�");
        jLabel72.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel72.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel74.add(jLabel72);

        jLabel73.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel73.setText("c");
        jLabel73.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel73.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel74.add(jLabel73);

        jPanel68.add(jPanel74);

        jPanel75.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel75.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkTrine.setSelected(true);
        chkTrine.setText(bundle.getString("Trine")); // NOI18N
        chkTrine.setPreferredSize(new java.awt.Dimension(125, 18));
        chkTrine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTrineActionPerformed(evt);
            }
        });
        jPanel75.add(chkTrine);

        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel75.setText("120�");
        jLabel75.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel75.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel75.add(jLabel75);

        jLabel76.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel76.setText("d");
        jLabel76.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel76.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel75.add(jLabel76);

        jPanel68.add(jPanel75);

        jPanel76.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel76.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkOpposition.setSelected(true);
        chkOpposition.setText(bundle.getString("Opposition")); // NOI18N
        chkOpposition.setPreferredSize(new java.awt.Dimension(125, 18));
        chkOpposition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkOppositionActionPerformed(evt);
            }
        });
        jPanel76.add(chkOpposition);

        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel78.setText("180�");
        jLabel78.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel78.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel76.add(jLabel78);

        jLabel79.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel79.setText("e");
        jLabel79.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel79.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel76.add(jLabel79);

        jPanel68.add(jPanel76);

        jPanel77.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel77.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkVigintile.setText(bundle.getString("Vigintile")); // NOI18N
        chkVigintile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkVigintile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkVigintileActionPerformed(evt);
            }
        });
        jPanel77.add(chkVigintile);

        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel81.setText("18�");
        jLabel81.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel81.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel77.add(jLabel81);

        jLabel82.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel82.setText("q");
        jLabel82.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel82.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel77.add(jLabel82);

        jPanel68.add(jPanel77);

        jPanel78.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel78.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiSextile.setText(bundle.getString("SemiSextile")); // NOI18N
        chkSemiSextile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSemiSextile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSemiSextileActionPerformed(evt);
            }
        });
        jPanel78.add(chkSemiSextile);

        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel84.setText("30�");
        jLabel84.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel84.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel78.add(jLabel84);

        jLabel85.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel85.setText("f");
        jLabel85.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel85.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel78.add(jLabel85);

        jPanel68.add(jPanel78);

        jPanel79.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel79.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiQuintile.setText(bundle.getString("SemiQuintile")); // NOI18N
        chkSemiQuintile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSemiQuintile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSemiQuintileActionPerformed(evt);
            }
        });
        jPanel79.add(chkSemiQuintile);

        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel87.setText("36�");
        jLabel87.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel87.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel79.add(jLabel87);

        jLabel88.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel88.setText("g");
        jLabel88.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel88.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel79.add(jLabel88);

        jPanel68.add(jPanel79);

        jPanel80.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel80.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkNonagon.setText(bundle.getString("Nonagon")); // NOI18N
        chkNonagon.setPreferredSize(new java.awt.Dimension(125, 18));
        chkNonagon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkNonagonActionPerformed(evt);
            }
        });
        jPanel80.add(chkNonagon);

        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel90.setText("40�");
        jLabel90.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel90.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel80.add(jLabel90);

        jLabel91.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel91.setText("h");
        jLabel91.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel91.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel80.add(jLabel91);

        jPanel68.add(jPanel80);

        jPanel81.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel81.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiSquare.setText(bundle.getString("SemiSquare")); // NOI18N
        chkSemiSquare.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSemiSquare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSemiSquareActionPerformed(evt);
            }
        });
        jPanel81.add(chkSemiSquare);

        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel93.setText("45�");
        jLabel93.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel93.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel81.add(jLabel93);

        jLabel94.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel94.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel94.setText("i");
        jLabel94.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel94.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel81.add(jLabel94);

        jPanel68.add(jPanel81);

        jPanel82.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel82.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSeptile.setText(bundle.getString("Septile")); // NOI18N
        chkSeptile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSeptile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSeptileActionPerformed(evt);
            }
        });
        jPanel82.add(chkSeptile);

        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel96.setText("51�");
        jLabel96.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel96.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel82.add(jLabel96);

        jLabel97.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel97.setText("j");
        jLabel97.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel97.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel82.add(jLabel97);

        jPanel68.add(jPanel82);

        jPanel83.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel83.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkQuintile.setText(bundle.getString("Quintile")); // NOI18N
        chkQuintile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkQuintile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkQuintileActionPerformed(evt);
            }
        });
        jPanel83.add(chkQuintile);

        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel99.setText("72�");
        jLabel99.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel99.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel83.add(jLabel99);

        jLabel100.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel100.setText("k");
        jLabel100.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel100.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel83.add(jLabel100);

        jPanel68.add(jPanel83);

        jPanel84.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel84.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkTriDectile.setText(bundle.getString("TriDectile")); // NOI18N
        chkTriDectile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkTriDectile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTriDectileActionPerformed(evt);
            }
        });
        jPanel84.add(chkTriDectile);

        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel102.setText("108�");
        jLabel102.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel102.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel84.add(jLabel102);

        jLabel103.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel103.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel103.setText("l");
        jLabel103.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel103.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel84.add(jLabel103);

        jPanel68.add(jPanel84);

        jPanel85.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel85.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSesquiSquare.setText(bundle.getString("SesquiSquare")); // NOI18N
        chkSesquiSquare.setPreferredSize(new java.awt.Dimension(125, 18));
        chkSesquiSquare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSesquiSquareActionPerformed(evt);
            }
        });
        jPanel85.add(chkSesquiSquare);

        jLabel105.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel105.setText("135�");
        jLabel105.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel105.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel85.add(jLabel105);

        jLabel106.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel106.setText("m");
        jLabel106.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel106.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel85.add(jLabel106);

        jPanel68.add(jPanel85);

        jPanel86.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel86.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkBiQuintile.setText(bundle.getString("BiQuintile")); // NOI18N
        chkBiQuintile.setPreferredSize(new java.awt.Dimension(125, 18));
        chkBiQuintile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkBiQuintileActionPerformed(evt);
            }
        });
        jPanel86.add(chkBiQuintile);

        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel108.setText("144�");
        jLabel108.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel108.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel86.add(jLabel108);

        jLabel109.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel109.setText("n");
        jLabel109.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel109.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel86.add(jLabel109);

        jPanel68.add(jPanel86);

        jPanel87.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel87.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkInconjunct.setSelected(true);
        chkInconjunct.setText(bundle.getString("Inconjunct")); // NOI18N
        chkInconjunct.setPreferredSize(new java.awt.Dimension(125, 18));
        chkInconjunct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkInconjunctActionPerformed(evt);
            }
        });
        jPanel87.add(chkInconjunct);

        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111.setText("150�");
        jLabel111.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel111.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel87.add(jLabel111);

        jLabel112.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel112.setText("o");
        jLabel112.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel112.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel87.add(jLabel112);

        jPanel68.add(jPanel87);

        jPanel88.setPreferredSize(new java.awt.Dimension(360, 24));
        jPanel88.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkQuadriNonagon.setText(bundle.getString("QuadriNonagon")); // NOI18N
        chkQuadriNonagon.setPreferredSize(new java.awt.Dimension(125, 18));
        chkQuadriNonagon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkQuadriNonagonActionPerformed(evt);
            }
        });
        jPanel88.add(chkQuadriNonagon);

        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel114.setText("160�");
        jLabel114.setPreferredSize(new java.awt.Dimension(40, 16));
        jLabel114.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel88.add(jLabel114);

        jLabel115.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel115.setText("p");
        jLabel115.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel115.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel88.add(jLabel115);

        jPanel68.add(jPanel88);

        jPanel89.setPreferredSize(new java.awt.Dimension(360, 48));
        jPanel89.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkOtherAspect.setText(bundle.getString("OtherAspect")); // NOI18N
        chkOtherAspect.setPreferredSize(new java.awt.Dimension(125, 18));
        chkOtherAspect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkOtherAspectActionPerformed(evt);
            }
        });
        jPanel89.add(chkOtherAspect);

        lblOtherAspectValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblOtherAspectValue.setText("?�");
        lblOtherAspectValue.setPreferredSize(new java.awt.Dimension(40, 16));
        lblOtherAspectValue.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel89.add(lblOtherAspectValue);

        jLabel118.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel118.setText("r");
        jLabel118.setPreferredSize(new java.awt.Dimension(40, 24));
        jLabel118.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel89.add(jLabel118);

        jPanel68.add(jPanel89);

        pnlAspects.add(jPanel68, java.awt.BorderLayout.WEST);

        jPanel69.setPreferredSize(new java.awt.Dimension(150, 34));
        jPanel69.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel91.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel91.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel91.setPreferredSize(new java.awt.Dimension(150, 14));
        jPanel69.add(jPanel91);

        jPanel92.setPreferredSize(new java.awt.Dimension(150, 24));
        jPanel92.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel119.setAlignmentX(0.5F);
        jLabel119.setOpaque(true);
        jLabel119.setPreferredSize(new java.awt.Dimension(140, 18));
        jPanel92.add(jLabel119);

        jPanel69.add(jPanel92);

        chkAspectSun.setSelected(true);
        chkAspectSun.setText(bundle.getString("Sun")); // NOI18N
        chkAspectSun.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectSun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectSunActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectSun);

        chkAspectMoon.setSelected(true);
        chkAspectMoon.setText(bundle.getString("Moon")); // NOI18N
        chkAspectMoon.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectMoonActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectMoon);

        chkAspectMercury.setSelected(true);
        chkAspectMercury.setText(bundle.getString("Mercury")); // NOI18N
        chkAspectMercury.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMercury.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectMercuryActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectMercury);

        chkAspectVenus.setSelected(true);
        chkAspectVenus.setText(bundle.getString("Venus")); // NOI18N
        chkAspectVenus.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVenus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectVenusActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectVenus);

        chkAspectMars.setSelected(true);
        chkAspectMars.setText(bundle.getString("Mars")); // NOI18N
        chkAspectMars.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectMarsActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectMars);

        chkAspectJupiter.setSelected(true);
        chkAspectJupiter.setText(bundle.getString("Jupiter")); // NOI18N
        chkAspectJupiter.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectJupiter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectJupiterActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectJupiter);

        chkAspectSaturn.setSelected(true);
        chkAspectSaturn.setText(bundle.getString("Saturn")); // NOI18N
        chkAspectSaturn.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectSaturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectSaturnActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectSaturn);

        chkAspectUranus.setSelected(true);
        chkAspectUranus.setText(bundle.getString("Uranus")); // NOI18N
        chkAspectUranus.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectUranus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectUranusActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectUranus);

        chkAspectNeptune.setSelected(true);
        chkAspectNeptune.setText(bundle.getString("Neptune")); // NOI18N
        chkAspectNeptune.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectNeptune.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectNeptuneActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectNeptune);

        chkAspectPluto.setSelected(true);
        chkAspectPluto.setText(bundle.getString("Pluto")); // NOI18N
        chkAspectPluto.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectPluto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectPlutoActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectPluto);

        chkAspectGaia.setText(bundle.getString("Gaia")); // NOI18N
        chkAspectGaia.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectGaia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectGaiaActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectGaia);

        chkAspectNodes.setSelected(true);
        chkAspectNodes.setText(bundle.getString("NorthNode")); // NOI18N
        chkAspectNodes.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectNodes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectNodesActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectNodes);

        chkAspectLilith.setSelected(true);
        chkAspectLilith.setText(bundle.getString("Lilith")); // NOI18N
        chkAspectLilith.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectLilith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectLilithActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectLilith);

        chkAspectEast.setText(bundle.getString("East")); // NOI18N
        chkAspectEast.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectEast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectEastActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectEast);

        chkAspectZenith.setText(bundle.getString("Zenith")); // NOI18N
        chkAspectZenith.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectZenith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectZenithActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectZenith);

        chkAspectVertex.setText(bundle.getString("Vertex")); // NOI18N
        chkAspectVertex.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVertex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectVertexActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectVertex);

        chkAspectVulcan.setText(bundle.getString("Vulcan")); // NOI18N
        chkAspectVulcan.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVulcan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectVulcanActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectVulcan);

        chkAspectCeres.setText(bundle.getString("Ceres")); // NOI18N
        chkAspectCeres.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectCeres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectCeresActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectCeres);

        chkAspectPallas.setText(bundle.getString("Pallas")); // NOI18N
        chkAspectPallas.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectPallas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectPallasActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectPallas);

        chkAspectJuno.setText(bundle.getString("Juno")); // NOI18N
        chkAspectJuno.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectJuno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectJunoActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectJuno);

        chkAspectVesta.setText(bundle.getString("Vesta")); // NOI18N
        chkAspectVesta.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectVesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectVestaActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectVesta);

        chkAspectChiron.setSelected(true);
        chkAspectChiron.setText(bundle.getString("Chiron")); // NOI18N
        chkAspectChiron.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectChiron.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectChironActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectChiron);

        chkAspectAS.setText(bundle.getString("Ascendant")); // NOI18N
        chkAspectAS.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectASActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectAS);

        chkAspectMC.setText(bundle.getString("Midheaven")); // NOI18N
        chkAspectMC.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectMC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectMCActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectMC);

        chkAspectOtherPoint.setText(bundle.getString("OtherPointName")); // NOI18N
        chkAspectOtherPoint.setPreferredSize(new java.awt.Dimension(140, 20));
        chkAspectOtherPoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAspectOtherPointActionPerformed(evt);
            }
        });
        jPanel69.add(chkAspectOtherPoint);

        pnlAspects.add(jPanel69, java.awt.BorderLayout.EAST);

        tabSettings.addTab("Aspects", null, pnlAspects, "");

        pnlOrbs.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 85));

        jPanel93.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel93.setPreferredSize(new java.awt.Dimension(700, 230));
        jPanel93.setLayout(new java.awt.GridLayout(7, 7));
        jPanel93.add(jPanel96);

        jLabel58.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(51, 153, 255));
        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel58.setText("AB");
        jLabel58.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel58.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel97.add(jLabel58);

        jPanel93.add(jPanel97);

        jLabel64.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(51, 102, 255));
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("CDE");
        jLabel64.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel64.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel98.add(jLabel64);

        jPanel93.add(jPanel98);

        jLabel70.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(0, 51, 255));
        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText("FG");
        jLabel70.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel70.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel99.add(jLabel70);

        jPanel93.add(jPanel99);

        jLabel74.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(0, 0, 204));
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setText("HIJKQ...");
        jLabel74.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel74.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel100.add(jLabel74);

        jPanel93.add(jPanel100);

        jLabel77.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(51, 0, 153));
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel77.setText("LMX Y");
        jLabel77.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel77.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel101.add(jLabel77);

        jPanel93.add(jPanel101);

        jLabel80.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel80.setText("NOPR");
        jLabel80.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel80.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel102.add(jLabel80);

        jPanel93.add(jPanel102);

        jLabel83.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(51, 153, 255));
        jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel83.setText("AB");
        jLabel83.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel83.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel103.add(jLabel83);

        jPanel93.add(jPanel103);

        txtOrbLumLum.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumLum.setText("0");
        txtOrbLumLum.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumLum.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumLum.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumLum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumLumKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumLumkeyTyped(evt);
            }
        });
        jPanel104.add(txtOrbLumLum);

        jPanel93.add(jPanel104);

        txtOrbLumIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumIndiv.setText("0");
        txtOrbLumIndiv.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumIndiv.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumIndiv.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumIndivKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumIndivkeyTyped(evt);
            }
        });
        jPanel105.add(txtOrbLumIndiv);

        jPanel93.add(jPanel105);

        txtOrbLumJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumJS.setText("0");
        txtOrbLumJS.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumJS.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumJSkeyTyped(evt);
            }
        });
        jPanel106.add(txtOrbLumJS);

        jPanel93.add(jPanel106);

        txtOrbLumCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumCol.setText("0");
        txtOrbLumCol.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumCol.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumColkeyTyped(evt);
            }
        });
        jPanel107.add(txtOrbLumCol);

        jPanel93.add(jPanel107);

        txtOrbLumVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMaj.setText("0");
        txtOrbLumVirtMaj.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumVirtMaj.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMajkeyTyped(evt);
            }
        });
        jPanel108.add(txtOrbLumVirtMaj);

        jPanel93.add(jPanel108);

        txtOrbLumVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMin.setText("0");
        txtOrbLumVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbLumVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbLumVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMinkeyTyped(evt);
            }
        });
        jPanel109.add(txtOrbLumVirtMin);

        jPanel93.add(jPanel109);

        jLabel86.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(51, 102, 255));
        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel86.setText("CDE");
        jLabel86.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel86.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel110.add(jLabel86);

        jPanel93.add(jPanel110);
        jPanel93.add(jPanel111);

        txtOrbIndivIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivIndiv.setText("0");
        txtOrbIndivIndiv.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivIndiv.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivIndiv.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivIndivKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivIndivkeyTyped(evt);
            }
        });
        jPanel113.add(txtOrbIndivIndiv);

        jPanel93.add(jPanel113);

        txtOrbIndivJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivJS.setText("0");
        txtOrbIndivJS.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivJS.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivJSkeyTyped(evt);
            }
        });
        jPanel114.add(txtOrbIndivJS);

        jPanel93.add(jPanel114);

        txtOrbIndivCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivCol.setText("0");
        txtOrbIndivCol.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivCol.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivColkeyTyped(evt);
            }
        });
        jPanel115.add(txtOrbIndivCol);

        jPanel93.add(jPanel115);

        txtOrbIndivVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMaj.setText("0");
        txtOrbIndivVirtMaj.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivVirtMaj.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMajkeyTyped(evt);
            }
        });
        jPanel116.add(txtOrbIndivVirtMaj);

        jPanel93.add(jPanel116);

        txtOrbIndivVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMin.setText("0");
        txtOrbIndivVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbIndivVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMinkeyTyped(evt);
            }
        });
        jPanel117.add(txtOrbIndivVirtMin);

        jPanel93.add(jPanel117);

        jLabel89.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(0, 51, 255));
        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("FG");
        jLabel89.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel89.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel118.add(jLabel89);

        jPanel93.add(jPanel118);
        jPanel93.add(jPanel119);
        jPanel93.add(jPanel120);

        txtOrbJSJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSJS.setText("0");
        txtOrbJSJS.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbJSJS.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbJSJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSJSkeyTyped(evt);
            }
        });
        jPanel121.add(txtOrbJSJS);

        jPanel93.add(jPanel121);

        txtOrbJSCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSCol.setText("0");
        txtOrbJSCol.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbJSCol.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbJSCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSColkeyTyped(evt);
            }
        });
        jPanel122.add(txtOrbJSCol);

        jPanel93.add(jPanel122);

        txtOrbJSvirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSvirtMaj.setText("0");
        txtOrbJSvirtMaj.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbJSvirtMaj.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbJSvirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSvirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSvirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSvirtMajkeyTyped(evt);
            }
        });
        jPanel123.add(txtOrbJSvirtMaj);

        jPanel93.add(jPanel123);

        txtOrbJSVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSVirtMin.setText("0");
        txtOrbJSVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbJSVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbJSVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSVirtMinkeyTyped(evt);
            }
        });
        jPanel124.add(txtOrbJSVirtMin);

        jPanel93.add(jPanel124);

        jLabel92.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(0, 0, 204));
        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel92.setText("HIJKQ...");
        jLabel92.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel92.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel125.add(jLabel92);

        jPanel93.add(jPanel125);
        jPanel93.add(jPanel126);
        jPanel93.add(jPanel127);
        jPanel93.add(jPanel128);

        txtOrbColCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColCol.setText("0");
        txtOrbColCol.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbColCol.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbColCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColColkeyTyped(evt);
            }
        });
        jPanel129.add(txtOrbColCol);

        jPanel93.add(jPanel129);

        txtOrbColVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMaj.setText("0");
        txtOrbColVirtMaj.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbColVirtMaj.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbColVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMajkeyTyped(evt);
            }
        });
        jPanel130.add(txtOrbColVirtMaj);

        jPanel93.add(jPanel130);

        txtOrbColVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMin.setText("0");
        txtOrbColVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbColVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbColVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMinkeyTyped(evt);
            }
        });
        jPanel131.add(txtOrbColVirtMin);

        jPanel93.add(jPanel131);

        jLabel95.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(51, 0, 153));
        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel95.setText("LMX Y");
        jLabel95.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel95.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel132.add(jLabel95);

        jPanel93.add(jPanel132);
        jPanel93.add(jPanel133);
        jPanel93.add(jPanel134);
        jPanel93.add(jPanel135);
        jPanel93.add(jPanel136);

        txtOrbVirtMajVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMaj.setText("0");
        txtOrbVirtMajVirtMaj.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbVirtMajVirtMaj.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbVirtMajVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMajkeyTyped(evt);
            }
        });
        jPanel137.add(txtOrbVirtMajVirtMaj);

        jPanel93.add(jPanel137);

        txtOrbVirtMajVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMin.setText("0");
        txtOrbVirtMajVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbVirtMajVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbVirtMajVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMinkeyTyped(evt);
            }
        });
        jPanel138.add(txtOrbVirtMajVirtMin);

        jPanel93.add(jPanel138);

        jLabel98.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel98.setText("NOPR");
        jLabel98.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel98.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel139.add(jLabel98);

        jPanel93.add(jPanel139);
        jPanel93.add(jPanel140);
        jPanel93.add(jPanel141);
        jPanel93.add(jPanel142);
        jPanel93.add(jPanel143);
        jPanel93.add(jPanel144);

        txtOrbvirtMinVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbvirtMinVirtMin.setText("0");
        txtOrbvirtMinVirtMin.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOrbvirtMinVirtMin.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOrbvirtMinVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbvirtMinVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbvirtMinVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbvirtMinVirtMinkeyTyped(evt);
            }
        });
        jPanel112.add(txtOrbvirtMinVirtMin);

        jPanel93.add(jPanel112);

        pnlOrbs.add(jPanel93);

        jPanel95.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel95.setPreferredSize(new java.awt.Dimension(600, 80));
        jPanel95.setLayout(new java.awt.GridLayout(2, 6));

        jLabel101.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(51, 153, 255));
        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel101.setText("a");
        jLabel101.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel101.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel145.add(jLabel101);

        jPanel95.add(jPanel145);

        jLabel104.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(51, 102, 255));
        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel104.setText("b");
        jLabel104.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel104.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel146.add(jLabel104);

        jPanel95.add(jPanel146);

        jLabel107.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel107.setForeground(new java.awt.Color(0, 51, 255));
        jLabel107.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel107.setText("c");
        jLabel107.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel107.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel147.add(jLabel107);

        jPanel95.add(jPanel147);

        jLabel110.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(0, 0, 204));
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("d");
        jLabel110.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel110.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel148.add(jLabel110);

        jPanel95.add(jPanel148);

        jLabel113.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel113.setForeground(new java.awt.Color(51, 0, 153));
        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel113.setText("e");
        jLabel113.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel113.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel149.add(jLabel113);

        jPanel95.add(jPanel149);

        jLabel116.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("...");
        jLabel116.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel116.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel150.add(jLabel116);

        jPanel95.add(jPanel150);

        jPanel151.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel117.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel117.setText("/");
        jLabel117.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel117.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel151.add(jLabel117);

        txtDivConjunction.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivConjunction.setText("0");
        txtDivConjunction.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivConjunction.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivConjunction.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivConjunction.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivConjunctionFocusLost(evt);
            }
        });
        txtDivConjunction.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivConjunctionKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivConjunctionkeyTyped(evt);
            }
        });
        jPanel151.add(txtDivConjunction);

        jPanel95.add(jPanel151);

        jPanel152.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel120.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("/");
        jLabel120.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel120.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel152.add(jLabel120);

        txtDivSextile.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSextile.setText("0");
        txtDivSextile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivSextile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivSextile.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSextile.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivSextileFocusLost(evt);
            }
        });
        txtDivSextile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivSextileKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivSextilekeyTyped(evt);
            }
        });
        jPanel152.add(txtDivSextile);

        jPanel95.add(jPanel152);

        jPanel153.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel121.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("/");
        jLabel121.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel121.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel153.add(jLabel121);

        txtDivSquare.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSquare.setText("0");
        txtDivSquare.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivSquare.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivSquare.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSquare.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivSquareFocusLost(evt);
            }
        });
        txtDivSquare.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivSquareKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivSquarekeyTyped(evt);
            }
        });
        jPanel153.add(txtDivSquare);

        jPanel95.add(jPanel153);

        jPanel154.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel122.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("/");
        jLabel122.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel122.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel154.add(jLabel122);

        txtDivTrine.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivTrine.setText("0");
        txtDivTrine.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivTrine.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivTrine.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivTrine.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivTrineFocusLost(evt);
            }
        });
        txtDivTrine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivTrineKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivTrinekeyTyped(evt);
            }
        });
        jPanel154.add(txtDivTrine);

        jPanel95.add(jPanel154);

        jPanel155.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel123.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel123.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel123.setText("/");
        jLabel123.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel123.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel155.add(jLabel123);

        txtDivOpposition.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOpposition.setText("0");
        txtDivOpposition.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivOpposition.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivOpposition.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOpposition.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivOppositionFocusLost(evt);
            }
        });
        txtDivOpposition.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivOppositionKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivOppositionkeyTyped(evt);
            }
        });
        jPanel155.add(txtDivOpposition);

        jPanel95.add(jPanel155);

        jPanel156.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel124.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("/");
        jLabel124.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel124.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel156.add(jLabel124);

        txtDivOther.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOther.setText("0");
        txtDivOther.setMaximumSize(new java.awt.Dimension(20, 20));
        txtDivOther.setMinimumSize(new java.awt.Dimension(20, 20));
        txtDivOther.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOther.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivOtherFocusLost(evt);
            }
        });
        txtDivOther.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivOtherKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivOtherkeyTyped(evt);
            }
        });
        jPanel156.add(txtDivOther);

        jPanel95.add(jPanel156);

        pnlOrbs.add(jPanel95);

        tabSettings.addTab("Orbs", null, pnlOrbs, "");

        lblFrom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrom.setText("/");
        lblFrom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFrom.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFrom.setOpaque(true);
        lblFrom.setPreferredSize(new java.awt.Dimension(40, 18));
        pnlComposite.add(lblFrom);

        grpCompositeFrom.add(optCompositeFromAS);
        optCompositeFromAS.setText("AS");
        optCompositeFromAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optCompositeFromASActionPerformed(evt);
            }
        });
        pnlComposite.add(optCompositeFromAS);

        grpCompositeFrom.add(optCompositeFromMC);
        optCompositeFromMC.setSelected(true);
        optCompositeFromMC.setText("MC");
        optCompositeFromMC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optCompositeFromMCActionPerformed(evt);
            }
        });
        pnlComposite.add(optCompositeFromMC);

        tabSettings.addTab("Composite", pnlComposite);

        getContentPane().add(tabSettings, java.awt.BorderLayout.CENTER);

        btnClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnClose.setBorder(null);
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });
        jPanel1.add(btnClose);

        getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chkDomitudesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkDomitudesActionPerformed
        chartElements.setCoordSys(CoordSystem.Domitudes);
    }//GEN-LAST:event_chkDomitudesActionPerformed

    private void txtDivOtherKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOtherKeyPressed
    {//GEN-HEADEREND:event_txtDivOtherKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivOtherKeyPressed

    private void txtDivOppositionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOppositionKeyPressed
    {//GEN-HEADEREND:event_txtDivOppositionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivOppositionKeyPressed

    private void txtDivTrineKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivTrineKeyPressed
    {//GEN-HEADEREND:event_txtDivTrineKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivTrineKeyPressed

    private void txtDivSquareKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSquareKeyPressed
    {//GEN-HEADEREND:event_txtDivSquareKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivSquareKeyPressed

    private void txtDivSextileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSextileKeyPressed
    {//GEN-HEADEREND:event_txtDivSextileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivSextileKeyPressed

    private void txtDivConjunctionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivConjunctionKeyPressed
    {//GEN-HEADEREND:event_txtDivConjunctionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivConjunctionKeyPressed

    private void txtOrbvirtMinVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbvirtMinVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbvirtMinVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbvirtMinVirtMinKeyPressed

    private void txtOrbVirtMajVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbVirtMajVirtMinKeyPressed

    private void txtOrbColVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbColVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColVirtMinKeyPressed

    private void txtOrbJSVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSVirtMinKeyPressed

    private void txtOrbIndivVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivVirtMinKeyPressed

    private void txtOrbLumVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumVirtMinKeyPressed

    private void txtOrbVirtMajVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbVirtMajVirtMajKeyPressed

    private void txtOrbColVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbColVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColVirtMajKeyPressed

    private void txtOrbJSvirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSvirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSvirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSvirtMajKeyPressed

    private void txtOrbIndivVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivVirtMajKeyPressed

    private void txtOrbLumVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumVirtMajKeyPressed

    private void txtOrbColColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColColKeyPressed
    {//GEN-HEADEREND:event_txtOrbColColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColColKeyPressed

    private void txtOrbJSColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSColKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSColKeyPressed

    private void txtOrbIndivColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivColKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivColKeyPressed

    private void txtOrbLumColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumColKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumColKeyPressed

    private void txtOrbJSJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSJSKeyPressed

    private void txtOrbIndivJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivJSKeyPressed

    private void txtOrbLumJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumJSKeyPressed

    private void txtOrbIndivIndivKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivIndivKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivIndivKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivIndivKeyPressed

    private void txtOrbLumIndivKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumIndivKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumIndivKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumIndivKeyPressed

    private void txtOrbLumLumKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumLumKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumLumKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumLumKeyPressed

    private void optCompositeFromMCActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optCompositeFromMCActionPerformed
    {//GEN-HEADEREND:event_optCompositeFromMCActionPerformed
        chartElements.setChartCompositeFromAS(false);
    }//GEN-LAST:event_optCompositeFromMCActionPerformed

    private void optCompositeFromASActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optCompositeFromASActionPerformed
    {//GEN-HEADEREND:event_optCompositeFromASActionPerformed
        chartElements.setChartCompositeFromAS(true);
    }//GEN-LAST:event_optCompositeFromASActionPerformed

    private void sldZodiacStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldZodiacStateChanged
    {//GEN-HEADEREND:event_sldZodiacStateChanged
        int value = sldZodiac.getValue();
        Font f = lblZodiacSize.getFont();
        lblZodiacSize.setFont(new Font(f.getName(), Font.BOLD, value));
        chartElements.setZodiacSize(value);
    }//GEN-LAST:event_sldZodiacStateChanged

    private void chkHousesCoordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkHousesCoordActionPerformed
        chartElements.setHousesCoords(chkHousesCoord.isSelected());
    }//GEN-LAST:event_chkHousesCoordActionPerformed

    private void chkSignsNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSignsNameActionPerformed
        chartElements.setSignsNames(chkSignsName.isSelected());
    }//GEN-LAST:event_chkSignsNameActionPerformed

    private void chkAspectsSymbolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectsSymbolActionPerformed
        chartElements.setSymbolAspects(chkAspectsSymbol.isSelected());
    }//GEN-LAST:event_chkAspectsSymbolActionPerformed

    private void optEastAriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optEastAriesActionPerformed
        chartElements.setLeftAsct(false);
    }//GEN-LAST:event_optEastAriesActionPerformed

    private void optEastASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optEastASActionPerformed
        chartElements.setLeftAsct(true);
    }//GEN-LAST:event_optEastASActionPerformed

    private void optDifferentWeightsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optDifferentWeightsActionPerformed
        chartElements.setSingleWeight(false);
    }//GEN-LAST:event_optDifferentWeightsActionPerformed

    private void optSingleWeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optSingleWeightActionPerformed
        chartElements.setSingleWeight(true);
    }//GEN-LAST:event_optSingleWeightActionPerformed

    private void chkBarycenterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkBarycenterActionPerformed
        chartElements.setViewBarycenter(chkBarycenter.isSelected());
    }//GEN-LAST:event_chkBarycenterActionPerformed

    private void chkShadedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkShadedActionPerformed
        chartElements.setViewShadedLines(chkShaded.isSelected());
    }//GEN-LAST:event_chkShadedActionPerformed

    private void chkStraightLinesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkStraightLinesActionPerformed
        chartElements.setViewStraightLines(chkStraightLines.isSelected());
    }//GEN-LAST:event_chkStraightLinesActionPerformed

    private void chkCoordinatesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCoordinatesActionPerformed
        chartElements.setViewCoordinates(chkCoordinates.isSelected());
    }//GEN-LAST:event_chkCoordinatesActionPerformed

    private void chkAspectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectsActionPerformed
        chartElements.setViewAspects(chkAspects.isSelected());
    }//GEN-LAST:event_chkAspectsActionPerformed

    private void chkHousesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkHousesActionPerformed
        chartElements.setViewHouses(chkHouses.isSelected());
    }//GEN-LAST:event_chkHousesActionPerformed

    private void chkAsteroidsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAsteroidsActionPerformed
        chartElements.setViewAsteroids(chkAsteroids.isSelected());
    }//GEN-LAST:event_chkAsteroidsActionPerformed

    private void chkConstellationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkConstellationsActionPerformed
        chartElements.setViewConstellations(chkConstellations.isSelected());
    }//GEN-LAST:event_chkConstellationsActionPerformed

    private void sldStarsStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldStarsStateChanged
        chartElements.setLimitMag((double)sldStars.getValue() / 2.0);
    }//GEN-LAST:event_sldStarsStateChanged

    private void chkStarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkStarsActionPerformed
        chartElements.setViewStars(chkStars.isSelected());
    }//GEN-LAST:event_chkStarsActionPerformed

    private void chkOtherAspectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkOtherAspectActionPerformed
        chartElements.setShownAspect17(chkOtherAspect.isSelected());
    }//GEN-LAST:event_chkOtherAspectActionPerformed

    private void chkQuadriNonagonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkQuadriNonagonActionPerformed
        chartElements.setShownAspect16(chkQuadriNonagon.isSelected());
    }//GEN-LAST:event_chkQuadriNonagonActionPerformed

    private void chkInconjunctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkInconjunctActionPerformed
        chartElements.setShownAspect15(chkInconjunct.isSelected());
    }//GEN-LAST:event_chkInconjunctActionPerformed

    private void chkBiQuintileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkBiQuintileActionPerformed
        chartElements.setShownAspect14(chkBiQuintile.isSelected());
    }//GEN-LAST:event_chkBiQuintileActionPerformed

    private void chkSesquiSquareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSesquiSquareActionPerformed
        chartElements.setShownAspect13(chkSesquiSquare.isSelected());
    }//GEN-LAST:event_chkSesquiSquareActionPerformed

    private void chkTriDectileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkTriDectileActionPerformed
        chartElements.setShownAspect12(chkTriDectile.isSelected());
    }//GEN-LAST:event_chkTriDectileActionPerformed

    private void chkQuintileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkQuintileActionPerformed
        chartElements.setShownAspect11(chkQuintile.isSelected());
    }//GEN-LAST:event_chkQuintileActionPerformed

    private void chkSemiSquareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSemiSquareActionPerformed
        chartElements.setShownAspect9(chkSemiSquare.isSelected());
    }//GEN-LAST:event_chkSemiSquareActionPerformed

    private void chkNonagonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkNonagonActionPerformed
        chartElements.setShownAspect8(chkNonagon.isSelected());
    }//GEN-LAST:event_chkNonagonActionPerformed

    private void chkSemiQuintileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSemiQuintileActionPerformed
        chartElements.setShownAspect7(chkSemiQuintile.isSelected());
    }//GEN-LAST:event_chkSemiQuintileActionPerformed

    private void chkSemiSextileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSemiSextileActionPerformed
        chartElements.setShownAspect6(chkSemiSextile.isSelected());
    }//GEN-LAST:event_chkSemiSextileActionPerformed

    private void chkVigintileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkVigintileActionPerformed
        chartElements.setShownAspect5(chkVigintile.isSelected());
    }//GEN-LAST:event_chkVigintileActionPerformed

    private void chkOppositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkOppositionActionPerformed
        chartElements.setShownAspect4(chkOpposition.isSelected());
    }//GEN-LAST:event_chkOppositionActionPerformed

    private void chkTrineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkTrineActionPerformed
        chartElements.setShownAspect3(chkTrine.isSelected());
    }//GEN-LAST:event_chkTrineActionPerformed

    private void chkSquareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSquareActionPerformed
        chartElements.setShownAspect2(chkSquare.isSelected());
    }//GEN-LAST:event_chkSquareActionPerformed

    private void chkSextileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSextileActionPerformed
        chartElements.setShownAspect1(chkSextile.isSelected());
    }//GEN-LAST:event_chkSextileActionPerformed

    private void chkConjunctionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkConjunctionActionPerformed
        chartElements.setShownAspect0(chkConjunction.isSelected());
    }//GEN-LAST:event_chkConjunctionActionPerformed

    private void chkSeptileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSeptileActionPerformed
        chartElements.setShownAspect10(chkSeptile.isSelected());
    }//GEN-LAST:event_chkSeptileActionPerformed

    private void chkOtherPointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkOtherPointActionPerformed
        chartElements.setShownOtherPoint(chkOtherPoint.isSelected());
    }//GEN-LAST:event_chkOtherPointActionPerformed

    private void chkChironActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkChironActionPerformed
        chartElements.setShownChiron(chkChiron.isSelected());
    }//GEN-LAST:event_chkChironActionPerformed

    private void chkVestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkVestaActionPerformed
        chartElements.setShownVesta(chkVesta.isSelected());
    }//GEN-LAST:event_chkVestaActionPerformed

    private void chkJunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkJunoActionPerformed
        chartElements.setShownJuno(chkJuno.isSelected());
    }//GEN-LAST:event_chkJunoActionPerformed

    private void chkPallasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkPallasActionPerformed
        chartElements.setShownPallas(chkPallas.isSelected());
    }//GEN-LAST:event_chkPallasActionPerformed

    private void chkCeresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCeresActionPerformed
        chartElements.setShownCeres(chkCeres.isSelected());
    }//GEN-LAST:event_chkCeresActionPerformed

    private void chkVulcanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkVulcanActionPerformed
        chartElements.setShownVulcan(chkVulcan.isSelected());
    }//GEN-LAST:event_chkVulcanActionPerformed

    private void chkVertexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkVertexActionPerformed
        chartElements.setShownVertex(chkVertex.isSelected());
    }//GEN-LAST:event_chkVertexActionPerformed

    private void chkZenithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkZenithActionPerformed
        chartElements.setShownZenith(chkZenith.isSelected());
    }//GEN-LAST:event_chkZenithActionPerformed

    private void chkEastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkEastActionPerformed
        chartElements.setShownEast(chkEast.isSelected());
    }//GEN-LAST:event_chkEastActionPerformed

    private void chkTrueLilithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkTrueLilithActionPerformed
        chartElements.setTrueLilith(chkTrueLilith.isSelected());
    }//GEN-LAST:event_chkTrueLilithActionPerformed

    private void chkLilithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkLilithActionPerformed
        chartElements.setShownLilith(chkLilith.isSelected());
    }//GEN-LAST:event_chkLilithActionPerformed

    private void chkNNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkNNActionPerformed
        chartElements.setShownNorthNode(chkNN.isSelected());
    }//GEN-LAST:event_chkNNActionPerformed

    private void chkGaiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkGaiaActionPerformed
        chartElements.setShownGaia(chkGaia.isSelected());
    }//GEN-LAST:event_chkGaiaActionPerformed

    private void chkPlutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkPlutoActionPerformed
        chartElements.setShownPluto(chkPluto.isSelected());
    }//GEN-LAST:event_chkPlutoActionPerformed

    private void chkNeptuneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkNeptuneActionPerformed
        chartElements.setShownNeptune(chkNeptune.isSelected());
    }//GEN-LAST:event_chkNeptuneActionPerformed

    private void chkUranusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkUranusActionPerformed
        chartElements.setShownUranus(chkUranus.isSelected());
    }//GEN-LAST:event_chkUranusActionPerformed

    private void chkSaturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSaturnActionPerformed
        chartElements.setShownSaturn(chkSaturn.isSelected());
    }//GEN-LAST:event_chkSaturnActionPerformed

    private void chkJupiterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkJupiterActionPerformed
        chartElements.setShownJupiter(chkJupiter.isSelected());
    }//GEN-LAST:event_chkJupiterActionPerformed

    private void chkMarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMarsActionPerformed
        chartElements.setShownMars(chkMars.isSelected());
    }//GEN-LAST:event_chkMarsActionPerformed

    private void chkVenusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkVenusActionPerformed
        chartElements.setShownVenus(chkVenus.isSelected());
    }//GEN-LAST:event_chkVenusActionPerformed

    private void chkMercuryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMercuryActionPerformed
        chartElements.setShownMercury(chkMercury.isSelected());
    }//GEN-LAST:event_chkMercuryActionPerformed

    private void chkMoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMoonActionPerformed
        chartElements.setShownMoon(chkMoon.isSelected());
    }//GEN-LAST:event_chkMoonActionPerformed

    private void chkSunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSunActionPerformed
        chartElements.setShownSun(chkSun.isSelected());
    }//GEN-LAST:event_chkSunActionPerformed

    private void chkAspectOtherPointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectOtherPointActionPerformed
        chartElements.setAspectsOtherPoint(chkAspectOtherPoint.isSelected());
    }//GEN-LAST:event_chkAspectOtherPointActionPerformed

    private void chkAspectMCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectMCActionPerformed
        chartElements.setAspectsMC(chkAspectMC.isSelected());
    }//GEN-LAST:event_chkAspectMCActionPerformed

    private void chkAspectASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectASActionPerformed
        chartElements.setAspectsAS(chkAspectAS.isSelected());
    }//GEN-LAST:event_chkAspectASActionPerformed

    private void chkAspectChironActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectChironActionPerformed
        chartElements.setAspectsChiron(chkAspectChiron.isSelected());
    }//GEN-LAST:event_chkAspectChironActionPerformed

    private void chkAspectVestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectVestaActionPerformed
        chartElements.setAspectsVesta(chkAspectVesta.isSelected());
    }//GEN-LAST:event_chkAspectVestaActionPerformed

    private void chkAspectJunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectJunoActionPerformed
        chartElements.setAspectsJuno(chkAspectJuno.isSelected());
    }//GEN-LAST:event_chkAspectJunoActionPerformed

    private void chkAspectPallasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectPallasActionPerformed
        chartElements.setAspectsPallas(chkAspectPallas.isSelected());
    }//GEN-LAST:event_chkAspectPallasActionPerformed

    private void chkAspectCeresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectCeresActionPerformed
        chartElements.setAspectsCeres(chkAspectCeres.isSelected());
    }//GEN-LAST:event_chkAspectCeresActionPerformed

    private void chkAspectVulcanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectVulcanActionPerformed
        chartElements.setAspectsVulcan(chkAspectVulcan.isSelected());
    }//GEN-LAST:event_chkAspectVulcanActionPerformed

    private void chkAspectVertexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectVertexActionPerformed
        chartElements.setAspectsVertex(chkAspectVertex.isSelected());
    }//GEN-LAST:event_chkAspectVertexActionPerformed

    private void chkAspectZenithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectZenithActionPerformed
        chartElements.setAspectsZenith(chkAspectZenith.isSelected());
    }//GEN-LAST:event_chkAspectZenithActionPerformed

    private void chkAspectEastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectEastActionPerformed
        chartElements.setAspectsEast(chkAspectEast.isSelected());
    }//GEN-LAST:event_chkAspectEastActionPerformed

    private void chkAspectLilithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectLilithActionPerformed
        chartElements.setAspectsLilith(chkAspectLilith.isSelected());
    }//GEN-LAST:event_chkAspectLilithActionPerformed

    private void chkAspectNodesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectNodesActionPerformed
        chartElements.setAspectsNorthNode(chkAspectNodes.isSelected());
    }//GEN-LAST:event_chkAspectNodesActionPerformed

    private void chkAspectGaiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectGaiaActionPerformed
        chartElements.setAspectsGaia(chkAspectGaia.isSelected());
    }//GEN-LAST:event_chkAspectGaiaActionPerformed

    private void chkAspectPlutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectPlutoActionPerformed
        chartElements.setAspectsGaia(chkAspectGaia.isSelected());
    }//GEN-LAST:event_chkAspectPlutoActionPerformed

    private void chkAspectNeptuneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectNeptuneActionPerformed
        chartElements.setAspectsNeptune(chkAspectNeptune.isSelected());
    }//GEN-LAST:event_chkAspectNeptuneActionPerformed

    private void chkAspectUranusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectUranusActionPerformed
        chartElements.setAspectsUranus(chkAspectUranus.isSelected());
    }//GEN-LAST:event_chkAspectUranusActionPerformed

    private void chkAspectSaturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectSaturnActionPerformed
        chartElements.setAspectsSaturn(chkAspectSaturn.isSelected());
    }//GEN-LAST:event_chkAspectSaturnActionPerformed

    private void chkAspectJupiterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectJupiterActionPerformed
        chartElements.setAspectsJupiter(chkAspectJupiter.isSelected());
    }//GEN-LAST:event_chkAspectJupiterActionPerformed

    private void chkAspectMarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectMarsActionPerformed
        chartElements.setAspectsMars(chkAspectMars.isSelected());
    }//GEN-LAST:event_chkAspectMarsActionPerformed

    private void chkAspectVenusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectVenusActionPerformed
        chartElements.setAspectsVenus(chkAspectVenus.isSelected());
    }//GEN-LAST:event_chkAspectVenusActionPerformed

    private void chkAspectMercuryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectMercuryActionPerformed
        chartElements.setAspectsMercury(chkAspectMercury.isSelected());
    }//GEN-LAST:event_chkAspectMercuryActionPerformed

    private void chkAspectMoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectMoonActionPerformed
        chartElements.setAspectsMoon(chkAspectMoon.isSelected());
    }//GEN-LAST:event_chkAspectMoonActionPerformed

    private void chkAspectSunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAspectSunActionPerformed
        chartElements.setAspectsSun(chkAspectSun.isSelected());
    }//GEN-LAST:event_chkAspectSunActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        setVisible(false);
        drawChart.setChartElements(chartElements, bHouseCalc);
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed
                                 
    private void txtDivOtherFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivOtherFocusLost
    {//GEN-HEADEREND:event_txtDivOtherFocusLost
        if (txtDivOther.getText().equals("")) txtDivOther.setText("0");
        Double d = new Double(txtDivOther.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivOther.setText("1");
        }
        chartElements.setDivMin(new Double(txtDivOther.getText()).doubleValue());
    }//GEN-LAST:event_txtDivOtherFocusLost
    
    private void txtDivOppositionFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivOppositionFocusLost
    {//GEN-HEADEREND:event_txtDivOppositionFocusLost
        if (txtDivOpposition.getText().equals("")) txtDivOpposition.setText("0");
        Double d = new Double(txtDivOpposition.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivOpposition.setText("1");
        }
        chartElements.setDivOpposition(new Double(txtDivOpposition.getText()).doubleValue());
    }//GEN-LAST:event_txtDivOppositionFocusLost
    
    private void txtDivTrineFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivTrineFocusLost
    {//GEN-HEADEREND:event_txtDivTrineFocusLost
        if (txtDivTrine.getText().equals("")) txtDivTrine.setText("0");
        Double d = new Double(txtDivTrine.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivTrine.setText("1");
        }
        chartElements.setDivTrine(new Double(txtDivTrine.getText()).doubleValue());
    }//GEN-LAST:event_txtDivTrineFocusLost
    
    private void txtDivSquareFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivSquareFocusLost
    {//GEN-HEADEREND:event_txtDivSquareFocusLost
        if (txtDivSquare.getText().equals("")) txtDivSquare.setText("0");
        Double d = new Double(txtDivSquare.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivSquare.setText("1");
        }
        chartElements.setDivSquare(new Double(txtDivSquare.getText()).doubleValue());
    }//GEN-LAST:event_txtDivSquareFocusLost
    
    private void txtDivSextileFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivSextileFocusLost
    {//GEN-HEADEREND:event_txtDivSextileFocusLost
        if (txtDivSextile.getText().equals("")) txtDivSextile.setText("0");
        Double d = new Double(txtDivSextile.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivSextile.setText("1");
        }
        chartElements.setDivSextile(new Double(txtDivSextile.getText()).doubleValue());
    }//GEN-LAST:event_txtDivSextileFocusLost
    
    private void txtDivConjunctionFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivConjunctionFocusLost
    {//GEN-HEADEREND:event_txtDivConjunctionFocusLost
        if (txtDivConjunction.getText().equals("")) txtDivConjunction.setText("0");
        Double d = new Double(txtDivConjunction.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivConjunction.setText("1");
        }
        chartElements.setDivConjunction(new Double(txtDivConjunction.getText()).doubleValue());
    }//GEN-LAST:event_txtDivConjunctionFocusLost
    
    private void txtDivOtherkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOtherkeyTyped
    {//GEN-HEADEREND:event_txtDivOtherkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivOther, 5, kc);
    }//GEN-LAST:event_txtDivOtherkeyTyped
    
    private void txtDivOppositionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOppositionkeyTyped
    {//GEN-HEADEREND:event_txtDivOppositionkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivOpposition, 5, kc);
    }//GEN-LAST:event_txtDivOppositionkeyTyped
    
    private void txtDivTrinekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivTrinekeyTyped
    {//GEN-HEADEREND:event_txtDivTrinekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivTrine, 5, kc);
    }//GEN-LAST:event_txtDivTrinekeyTyped
    
    private void txtDivSquarekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSquarekeyTyped
    {//GEN-HEADEREND:event_txtDivSquarekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivSquare, 5, kc);
    }//GEN-LAST:event_txtDivSquarekeyTyped
    
    private void txtDivSextilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSextilekeyTyped
    {//GEN-HEADEREND:event_txtDivSextilekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivSextile, 5, kc);
    }//GEN-LAST:event_txtDivSextilekeyTyped
    
    private void txtDivConjunctionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivConjunctionkeyTyped
    {//GEN-HEADEREND:event_txtDivConjunctionkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivConjunction, 5, kc);
    }//GEN-LAST:event_txtDivConjunctionkeyTyped
    
    private void txtOrbvirtMinVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbvirtMinVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbvirtMinVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbvirtMinVirtMin, 5, kc);
        chartElements.setOrbVirtMinVirtMin(new Double(txtOrbvirtMinVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbvirtMinVirtMinkeyTyped
    
    private void txtOrbVirtMajVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMin, 5, kc);
        chartElements.setOrbVirtMaxVirtMin(new Double(txtOrbVirtMajVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbVirtMajVirtMinkeyTyped
    
    private void txtOrbVirtMajVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMaj, 5, kc);
        chartElements.setOrbVirtMaxVirtMax(new Double(txtOrbVirtMajVirtMaj.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbVirtMajVirtMajkeyTyped
    
    private void txtOrbColVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbColVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColVirtMin, 5, kc);
        chartElements.setOrbCollVirtMin(new Double(txtOrbColVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbColVirtMinkeyTyped
    
    private void txtOrbColVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbColVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColVirtMaj, 5, kc);
        chartElements.setOrbCollVirtMax(new Double(txtOrbColVirtMaj.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbColVirtMajkeyTyped
    
    private void txtOrbColColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColColkeyTyped
    {//GEN-HEADEREND:event_txtOrbColColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColCol, 5, kc);
        chartElements.setOrbCollColl(new Double(txtOrbColCol.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbColColkeyTyped
    
    private void txtOrbJSVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSVirtMin, 5, kc);
        chartElements.setOrbOtherIndVirtMin(new Double(txtOrbJSVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbJSVirtMinkeyTyped
    
    private void txtOrbJSvirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSvirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSvirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSvirtMaj, 5, kc);
        chartElements.setOrbOtherIndVirtMax(new Double(txtOrbJSvirtMaj.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbJSvirtMajkeyTyped
    
    private void txtOrbJSColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSColkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSCol, 5, kc);
        chartElements.setOrbOtherIndColl(new Double(txtOrbJSCol.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbJSColkeyTyped
    
    private void txtOrbJSJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSJS, 5, kc);
        chartElements.setOrbOtherIndOtherInd(new Double(txtOrbJSJS.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbJSJSkeyTyped
    
    private void txtOrbIndivVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivVirtMin, 5, kc);
        chartElements.setOrbTellVirtMin(new Double(txtOrbIndivVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbIndivVirtMinkeyTyped
    
    private void txtOrbIndivVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivVirtMaj, 5, kc);
        chartElements.setOrbTellVirtMax(new Double(txtOrbIndivVirtMaj.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbIndivVirtMajkeyTyped
    
    private void txtOrbIndivColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivColkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivCol, 5, kc);
        chartElements.setOrbTellColl(new Double(txtOrbIndivCol.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbIndivColkeyTyped
    
    private void txtOrbIndivJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivJS, 5, kc);
        chartElements.setOrbTellOtherInd(new Double(txtOrbIndivJS.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbIndivJSkeyTyped
    
    private void txtOrbIndivIndivkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivIndivkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivIndivkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivIndiv, 5, kc);
        chartElements.setOrbTellTell(new Double(txtOrbIndivIndiv.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbIndivIndivkeyTyped
    
    private void txtOrbLumVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumVirtMin, 5, kc);
        chartElements.setOrbLightVirtMin(new Double(txtOrbLumVirtMin.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumVirtMinkeyTyped
    
    private void txtOrbLumVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumVirtMaj, 5, kc);
        chartElements.setOrbLightVirtMax(new Double(txtOrbLumVirtMaj.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumVirtMajkeyTyped
    
    private void txtOrbLumColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumColkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumCol, 5, kc);
        chartElements.setOrbLightColl(new Double(txtOrbLumCol.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumColkeyTyped
    
    private void txtOrbLumJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumJS, 5, kc);
        chartElements.setOrbLightOtherInd(new Double(txtOrbLumJS.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumJSkeyTyped
    
    private void txtOrbLumIndivkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumIndivkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumIndivkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumIndiv, 5, kc);
        chartElements.setOrbLightTell(new Double(txtOrbLumIndiv.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumIndivkeyTyped
    
    private void txtOrbLumLumkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumLumkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumLumkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumLum, 5, kc);
        chartElements.setOrbLightLight(new Double(txtOrbLumLum.getText()).doubleValue());
    }//GEN-LAST:event_txtOrbLumLumkeyTyped
                                                                                                                                                                                                                                                                                        
    private void sldCharactersStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldCharactersStateChanged
    {//GEN-HEADEREND:event_sldCharactersStateChanged
        int value = sldCharacters.getValue();
        Font f = lblCharactersSize.getFont();
        lblCharactersSize.setFont(new Font(f.getName(), Font.PLAIN, value));
        chartElements.setCharacterSize(value);
    }//GEN-LAST:event_sldCharactersStateChanged
    
    private void sldPlanetsStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldPlanetsStateChanged
    {//GEN-HEADEREND:event_sldPlanetsStateChanged
        int value = sldPlanets.getValue();
        Font f = lblPlanetSize.getFont();
        lblPlanetSize.setFont(new Font(f.getName(), Font.BOLD, value));
        chartElements.setPlanetSize(value);
    }//GEN-LAST:event_sldPlanetsStateChanged
    
    private void sldSignsStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldSignsStateChanged
    {//GEN-HEADEREND:event_sldSignsStateChanged
        int value = sldSigns.getValue();
        Font f = lblSignSize.getFont();
        lblSignSize.setFont(new Font(f.getName(), Font.BOLD, value));
        chartElements.setSignSize(value);
    }//GEN-LAST:event_sldSignsStateChanged
                                                                                                
    private void optPlacidusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPlacidusActionPerformed
    {//GEN-HEADEREND:event_optPlacidusActionPerformed
        chartElements.setHouseSys(HouseSystem.Placidus);
        bHouseCalc = true;
    }//GEN-LAST:event_optPlacidusActionPerformed
    
    private void optKochActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optKochActionPerformed
    {//GEN-HEADEREND:event_optKochActionPerformed
        chartElements.setHouseSys(HouseSystem.Koch);
        bHouseCalc = true;
    }//GEN-LAST:event_optKochActionPerformed
    
    private void optAlcabitiusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAlcabitiusActionPerformed
    {//GEN-HEADEREND:event_optAlcabitiusActionPerformed
        chartElements.setHouseSys(HouseSystem.Alcabitius);
        bHouseCalc = true;
    }//GEN-LAST:event_optAlcabitiusActionPerformed
    
    private void optAlbategniusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAlbategniusActionPerformed
    {//GEN-HEADEREND:event_optAlbategniusActionPerformed
        chartElements.setHouseSys(HouseSystem.Albategnius);
        bHouseCalc = true;
    }//GEN-LAST:event_optAlbategniusActionPerformed
    
    private void optAbenragelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAbenragelActionPerformed
    {//GEN-HEADEREND:event_optAbenragelActionPerformed
        chartElements.setHouseSys(HouseSystem.Abenragel);
        bHouseCalc = true;
    }//GEN-LAST:event_optAbenragelActionPerformed
    
    private void optZodiacalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optZodiacalActionPerformed
    {//GEN-HEADEREND:event_optZodiacalActionPerformed
        chartElements.setHouseSys(HouseSystem.Zodiacal);
        bHouseCalc = true;
    }//GEN-LAST:event_optZodiacalActionPerformed
    
    private void optZenithalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optZenithalActionPerformed
    {//GEN-HEADEREND:event_optZenithalActionPerformed
        chartElements.setHouseSys(HouseSystem.Zenithal);
        bHouseCalc = true;
    }//GEN-LAST:event_optZenithalActionPerformed
    
    private void optWieselActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optWieselActionPerformed
    {//GEN-HEADEREND:event_optWieselActionPerformed
        chartElements.setHouseSys(HouseSystem.Wiesel);
        bHouseCalc = true;
    }//GEN-LAST:event_optWieselActionPerformed
    
    private void optSolarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSolarActionPerformed
    {//GEN-HEADEREND:event_optSolarActionPerformed
        chartElements.setHouseSys(HouseSystem.Solar);
        bHouseCalc = true;
    }//GEN-LAST:event_optSolarActionPerformed
    
    private void optRegiomontanusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optRegiomontanusActionPerformed
    {//GEN-HEADEREND:event_optRegiomontanusActionPerformed
        chartElements.setHouseSys(HouseSystem.Regiomontanus);
        bHouseCalc = true;
    }//GEN-LAST:event_optRegiomontanusActionPerformed
    
    private void optPorpyreActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPorpyreActionPerformed
    {//GEN-HEADEREND:event_optPorpyreActionPerformed
        chartElements.setHouseSys(HouseSystem.Porphyre);
        bHouseCalc = true;
    }//GEN-LAST:event_optPorpyreActionPerformed
    
    private void optNodalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optNodalActionPerformed
    {//GEN-HEADEREND:event_optNodalActionPerformed
        chartElements.setHouseSys(HouseSystem.Nodal);
        bHouseCalc = true;
    }//GEN-LAST:event_optNodalActionPerformed
    
    private void optMaternusMCActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMaternusMCActionPerformed
    {//GEN-HEADEREND:event_optMaternusMCActionPerformed
        chartElements.setHouseSys(HouseSystem.MaternusMC);
        bHouseCalc = true;
    }//GEN-LAST:event_optMaternusMCActionPerformed
    
    private void optMaternusAsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMaternusAsActionPerformed
    {//GEN-HEADEREND:event_optMaternusAsActionPerformed
        chartElements.setHouseSys(HouseSystem.MaternusAs);
        bHouseCalc = true;
    }//GEN-LAST:event_optMaternusAsActionPerformed
    
    private void optBazchenoffActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optBazchenoffActionPerformed
    {//GEN-HEADEREND:event_optBazchenoffActionPerformed
        chartElements.setHouseSys(HouseSystem.Bazchenoff);
        bHouseCalc = true;
    }//GEN-LAST:event_optBazchenoffActionPerformed
    
    private void optColinEvansActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optColinEvansActionPerformed
    {//GEN-HEADEREND:event_optColinEvansActionPerformed
        chartElements.setHouseSys(HouseSystem.ColinEvans);
        bHouseCalc = true;
    }//GEN-LAST:event_optColinEvansActionPerformed
    
    private void optEquatorialRegularActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optEquatorialRegularActionPerformed
    {//GEN-HEADEREND:event_optEquatorialRegularActionPerformed
        chartElements.setHouseSys(HouseSystem.EquatorialRegular);
        bHouseCalc = true;
    }//GEN-LAST:event_optEquatorialRegularActionPerformed
    
    private void optCampanusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optCampanusActionPerformed
    {//GEN-HEADEREND:event_optCampanusActionPerformed
        chartElements.setHouseSys(HouseSystem.Campanus);
        bHouseCalc = true;
    }//GEN-LAST:event_optCampanusActionPerformed
    
    private void optSemiAngularActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSemiAngularActionPerformed
    {//GEN-HEADEREND:event_optSemiAngularActionPerformed
        chartElements.setHouseSys(HouseSystem.SemiAngular);
        bHouseCalc = true;
    }//GEN-LAST:event_optSemiAngularActionPerformed
    
    private void optTwoHoursActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optTwoHoursActionPerformed
    {//GEN-HEADEREND:event_optTwoHoursActionPerformed
        chartElements.setHouseSys(HouseSystem.TwoHours);
        bHouseCalc = true;
    }//GEN-LAST:event_optTwoHoursActionPerformed
    
    private void optAncientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAncientActionPerformed
    {//GEN-HEADEREND:event_optAncientActionPerformed
        chartElements.setHouseSys(HouseSystem.Ancient);
        bHouseCalc = true;
    }//GEN-LAST:event_optAncientActionPerformed
    
    private void chkHeliocentricSiderealActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricSiderealActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricSiderealActionPerformed
        chartElements.setCoordSys(CoordSystem.HelioSidereal);
    }//GEN-LAST:event_chkHeliocentricSiderealActionPerformed
    
    private void chkHeliocentricNormalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricNormalActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricNormalActionPerformed
        chartElements.setCoordSys(CoordSystem.HelioNormal);
    }//GEN-LAST:event_chkHeliocentricNormalActionPerformed
    
    private void chkLocalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkLocalActionPerformed
    {//GEN-HEADEREND:event_chkLocalActionPerformed
        chartElements.setCoordSys(CoordSystem.Local);
    }//GEN-LAST:event_chkLocalActionPerformed
    
    private void chkEclipticActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkEclipticActionPerformed
    {//GEN-HEADEREND:event_chkEclipticActionPerformed
        chartElements.setCoordSys(CoordSystem.Ecliptic);
    }//GEN-LAST:event_chkEclipticActionPerformed
    
    private void chkEquatorialActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkEquatorialActionPerformed
    {//GEN-HEADEREND:event_chkEquatorialActionPerformed
        chartElements.setCoordSys(CoordSystem.Equatorial);
    }//GEN-LAST:event_chkEquatorialActionPerformed
    
    private void chkSiderealActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSiderealActionPerformed
    {//GEN-HEADEREND:event_chkSiderealActionPerformed
        chartElements.setCoordSys(CoordSystem.Sidereal);
    }//GEN-LAST:event_chkSiderealActionPerformed
    
    private void chkTropicalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkTropicalActionPerformed
    {//GEN-HEADEREND:event_chkTropicalActionPerformed
        chartElements.setCoordSys(CoordSystem.Tropical);
    }//GEN-LAST:event_chkTropicalActionPerformed
    
    private void chkHeliocentricActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricActionPerformed
        boolean bolHelio = chkHeliocentric.isSelected();
        chkTropical.setVisible(!bolHelio);
        chkSidereal.setVisible(!bolHelio);
        chkEquatorial.setVisible(!bolHelio);
        chkEcliptic.setVisible(!bolHelio);
        chkLocal.setVisible(!bolHelio);
        chkDomitudes.setVisible(!bolHelio);
        chkHeliocentricNormal.setVisible(bolHelio);
        chkHeliocentricSidereal.setVisible(bolHelio);
    }//GEN-LAST:event_chkHeliocentricActionPerformed
    
    private void chkGeocentricActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkGeocentricActionPerformed
    {//GEN-HEADEREND:event_chkGeocentricActionPerformed
        boolean bolGeo = chkGeocentric.isSelected();
        chkTropical.setVisible(bolGeo);
        chkSidereal.setVisible(bolGeo);
        chkEquatorial.setVisible(bolGeo);
        chkEcliptic.setVisible(bolGeo);
        chkLocal.setVisible(bolGeo);
        chkDomitudes.setVisible(bolGeo);
        chkHeliocentricNormal.setVisible(!bolGeo);
        chkHeliocentricSidereal.setVisible(!bolGeo);
    }//GEN-LAST:event_chkGeocentricActionPerformed
        
    /** close the window */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        setVisible(false);
        dispose();
    }//GEN-LAST:event_exitForm
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JCheckBox chkAspectAS;
    private javax.swing.JCheckBox chkAspectCeres;
    private javax.swing.JCheckBox chkAspectChiron;
    private javax.swing.JCheckBox chkAspectEast;
    private javax.swing.JCheckBox chkAspectGaia;
    private javax.swing.JCheckBox chkAspectJuno;
    private javax.swing.JCheckBox chkAspectJupiter;
    private javax.swing.JCheckBox chkAspectLilith;
    private javax.swing.JCheckBox chkAspectMC;
    private javax.swing.JCheckBox chkAspectMars;
    private javax.swing.JCheckBox chkAspectMercury;
    private javax.swing.JCheckBox chkAspectMoon;
    private javax.swing.JCheckBox chkAspectNeptune;
    private javax.swing.JCheckBox chkAspectNodes;
    private javax.swing.JCheckBox chkAspectOtherPoint;
    private javax.swing.JCheckBox chkAspectPallas;
    private javax.swing.JCheckBox chkAspectPluto;
    private javax.swing.JCheckBox chkAspectSaturn;
    private javax.swing.JCheckBox chkAspectSun;
    private javax.swing.JCheckBox chkAspectUranus;
    private javax.swing.JCheckBox chkAspectVenus;
    private javax.swing.JCheckBox chkAspectVertex;
    private javax.swing.JCheckBox chkAspectVesta;
    private javax.swing.JCheckBox chkAspectVulcan;
    private javax.swing.JCheckBox chkAspectZenith;
    private javax.swing.JCheckBox chkAspects;
    private javax.swing.JCheckBox chkAspectsSymbol;
    private javax.swing.JCheckBox chkAsteroids;
    private javax.swing.JCheckBox chkBarycenter;
    private javax.swing.JCheckBox chkBiQuintile;
    private javax.swing.JCheckBox chkCeres;
    private javax.swing.JCheckBox chkChiron;
    private javax.swing.JCheckBox chkConjunction;
    private javax.swing.JCheckBox chkConstellations;
    private javax.swing.JCheckBox chkCoordinates;
    private javax.swing.JRadioButton chkDomitudes;
    private javax.swing.JCheckBox chkEast;
    private javax.swing.JRadioButton chkEcliptic;
    private javax.swing.JRadioButton chkEquatorial;
    private javax.swing.JCheckBox chkGaia;
    private javax.swing.JRadioButton chkGeocentric;
    private javax.swing.JRadioButton chkHeliocentric;
    private javax.swing.JRadioButton chkHeliocentricNormal;
    private javax.swing.JRadioButton chkHeliocentricSidereal;
    private javax.swing.JCheckBox chkHouses;
    private javax.swing.JCheckBox chkHousesCoord;
    private javax.swing.JCheckBox chkInconjunct;
    private javax.swing.JCheckBox chkJuno;
    private javax.swing.JCheckBox chkJupiter;
    private javax.swing.JCheckBox chkLilith;
    private javax.swing.JRadioButton chkLocal;
    private javax.swing.JCheckBox chkMars;
    private javax.swing.JCheckBox chkMercury;
    private javax.swing.JCheckBox chkMoon;
    private javax.swing.JCheckBox chkNN;
    private javax.swing.JCheckBox chkNeptune;
    private javax.swing.JCheckBox chkNonagon;
    private javax.swing.JCheckBox chkOpposition;
    private javax.swing.JCheckBox chkOtherAspect;
    private javax.swing.JCheckBox chkOtherPoint;
    private javax.swing.JCheckBox chkPallas;
    private javax.swing.JCheckBox chkPluto;
    private javax.swing.JCheckBox chkQuadriNonagon;
    private javax.swing.JCheckBox chkQuintile;
    private javax.swing.JCheckBox chkSaturn;
    private javax.swing.JCheckBox chkSemiQuintile;
    private javax.swing.JCheckBox chkSemiSextile;
    private javax.swing.JCheckBox chkSemiSquare;
    private javax.swing.JCheckBox chkSeptile;
    private javax.swing.JCheckBox chkSesquiSquare;
    private javax.swing.JCheckBox chkSextile;
    private javax.swing.JCheckBox chkShaded;
    private javax.swing.JRadioButton chkSidereal;
    private javax.swing.JCheckBox chkSignsName;
    private javax.swing.JCheckBox chkSquare;
    private javax.swing.JCheckBox chkStars;
    private javax.swing.JCheckBox chkStraightLines;
    private javax.swing.JCheckBox chkSun;
    private javax.swing.JCheckBox chkTriDectile;
    private javax.swing.JCheckBox chkTrine;
    private javax.swing.JRadioButton chkTropical;
    private javax.swing.JCheckBox chkTrueLilith;
    private javax.swing.JCheckBox chkUranus;
    private javax.swing.JCheckBox chkVenus;
    private javax.swing.JCheckBox chkVertex;
    private javax.swing.JCheckBox chkVesta;
    private javax.swing.JCheckBox chkVigintile;
    private javax.swing.JCheckBox chkVulcan;
    private javax.swing.JCheckBox chkZenith;
    private javax.swing.ButtonGroup grpAstronView;
    private javax.swing.ButtonGroup grpBarycenter;
    private javax.swing.ButtonGroup grpChartChoice;
    private javax.swing.ButtonGroup grpColorMode;
    private javax.swing.ButtonGroup grpCompositeFrom;
    private javax.swing.ButtonGroup grpCompositeSelect;
    private javax.swing.ButtonGroup grpGeo;
    private javax.swing.ButtonGroup grpGeoHelio;
    private javax.swing.ButtonGroup grpHelio;
    private javax.swing.ButtonGroup grpHouseSystem;
    private javax.swing.ButtonGroup grpOtherPoint;
    private javax.swing.ButtonGroup grpSavedCharts;
    private javax.swing.ButtonGroup grpSynastrySelect;
    private javax.swing.ButtonGroup grpZodDir;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel108;
    private javax.swing.JPanel jPanel109;
    private javax.swing.JPanel jPanel110;
    private javax.swing.JPanel jPanel111;
    private javax.swing.JPanel jPanel112;
    private javax.swing.JPanel jPanel113;
    private javax.swing.JPanel jPanel114;
    private javax.swing.JPanel jPanel115;
    private javax.swing.JPanel jPanel116;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel118;
    private javax.swing.JPanel jPanel119;
    private javax.swing.JPanel jPanel120;
    private javax.swing.JPanel jPanel121;
    private javax.swing.JPanel jPanel122;
    private javax.swing.JPanel jPanel123;
    private javax.swing.JPanel jPanel124;
    private javax.swing.JPanel jPanel125;
    private javax.swing.JPanel jPanel126;
    private javax.swing.JPanel jPanel127;
    private javax.swing.JPanel jPanel128;
    private javax.swing.JPanel jPanel129;
    private javax.swing.JPanel jPanel130;
    private javax.swing.JPanel jPanel131;
    private javax.swing.JPanel jPanel132;
    private javax.swing.JPanel jPanel133;
    private javax.swing.JPanel jPanel134;
    private javax.swing.JPanel jPanel135;
    private javax.swing.JPanel jPanel136;
    private javax.swing.JPanel jPanel137;
    private javax.swing.JPanel jPanel138;
    private javax.swing.JPanel jPanel139;
    private javax.swing.JPanel jPanel140;
    private javax.swing.JPanel jPanel141;
    private javax.swing.JPanel jPanel142;
    private javax.swing.JPanel jPanel143;
    private javax.swing.JPanel jPanel144;
    private javax.swing.JPanel jPanel145;
    private javax.swing.JPanel jPanel146;
    private javax.swing.JPanel jPanel147;
    private javax.swing.JPanel jPanel148;
    private javax.swing.JPanel jPanel149;
    private javax.swing.JPanel jPanel150;
    private javax.swing.JPanel jPanel151;
    private javax.swing.JPanel jPanel152;
    private javax.swing.JPanel jPanel153;
    private javax.swing.JPanel jPanel154;
    private javax.swing.JPanel jPanel155;
    private javax.swing.JPanel jPanel156;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblCharactersSize;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblOtherAspectValue;
    private javax.swing.JLabel lblPlanetSize;
    private javax.swing.JLabel lblSignSize;
    private javax.swing.JLabel lblZodiacSize;
    private javax.swing.JRadioButton optAbenragel;
    private javax.swing.JRadioButton optAlbategnius;
    private javax.swing.JRadioButton optAlcabitius;
    private javax.swing.JRadioButton optAncient;
    private javax.swing.JRadioButton optBazchenoff;
    private javax.swing.JRadioButton optCampanus;
    private javax.swing.JRadioButton optColinEvans;
    private javax.swing.JRadioButton optCompositeFromAS;
    private javax.swing.JRadioButton optCompositeFromMC;
    private javax.swing.JRadioButton optDifferentWeights;
    private javax.swing.JRadioButton optEastAS;
    private javax.swing.JRadioButton optEastAries;
    private javax.swing.JRadioButton optEquatorialRegular;
    private javax.swing.JRadioButton optKoch;
    private javax.swing.JRadioButton optMaternusAs;
    private javax.swing.JRadioButton optMaternusMC;
    private javax.swing.JRadioButton optNodal;
    private javax.swing.JRadioButton optPlacidus;
    private javax.swing.JRadioButton optPorpyre;
    private javax.swing.JRadioButton optRegiomontanus;
    private javax.swing.JRadioButton optSemiAngular;
    private javax.swing.JRadioButton optSingleWeight;
    private javax.swing.JRadioButton optSolar;
    private javax.swing.JRadioButton optTwoHours;
    private javax.swing.JRadioButton optWiesel;
    private javax.swing.JRadioButton optZenithal;
    private javax.swing.JRadioButton optZodiacal;
    private javax.swing.JPanel pnlAspects;
    private javax.swing.JPanel pnlChartLook;
    private javax.swing.JPanel pnlComposite;
    private javax.swing.JPanel pnlCoordSystem;
    private javax.swing.JPanel pnlHouseSystem;
    private javax.swing.JPanel pnlOrbs;
    private javax.swing.JPanel pnlPlanets;
    private javax.swing.JSlider sldCharacters;
    private javax.swing.JSlider sldPlanets;
    private javax.swing.JSlider sldSigns;
    private javax.swing.JSlider sldStars;
    private javax.swing.JSlider sldZodiac;
    private javax.swing.JTabbedPane tabSettings;
    private javax.swing.JTextField txtDivConjunction;
    private javax.swing.JTextField txtDivOpposition;
    private javax.swing.JTextField txtDivOther;
    private javax.swing.JTextField txtDivSextile;
    private javax.swing.JTextField txtDivSquare;
    private javax.swing.JTextField txtDivTrine;
    private javax.swing.JTextField txtOrbColCol;
    private javax.swing.JTextField txtOrbColVirtMaj;
    private javax.swing.JTextField txtOrbColVirtMin;
    private javax.swing.JTextField txtOrbIndivCol;
    private javax.swing.JTextField txtOrbIndivIndiv;
    private javax.swing.JTextField txtOrbIndivJS;
    private javax.swing.JTextField txtOrbIndivVirtMaj;
    private javax.swing.JTextField txtOrbIndivVirtMin;
    private javax.swing.JTextField txtOrbJSCol;
    private javax.swing.JTextField txtOrbJSJS;
    private javax.swing.JTextField txtOrbJSVirtMin;
    private javax.swing.JTextField txtOrbJSvirtMaj;
    private javax.swing.JTextField txtOrbLumCol;
    private javax.swing.JTextField txtOrbLumIndiv;
    private javax.swing.JTextField txtOrbLumJS;
    private javax.swing.JTextField txtOrbLumLum;
    private javax.swing.JTextField txtOrbLumVirtMaj;
    private javax.swing.JTextField txtOrbLumVirtMin;
    private javax.swing.JTextField txtOrbVirtMajVirtMaj;
    private javax.swing.JTextField txtOrbVirtMajVirtMin;
    private javax.swing.JTextField txtOrbvirtMinVirtMin;
    // End of variables declaration//GEN-END:variables
    
}
