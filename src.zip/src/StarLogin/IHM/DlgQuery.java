package StarLogin.IHM;

import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author Francois DESCHAMPS
 * @version 1.0.0
 */
public class DlgQuery extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private String script = "";
    private Timer timer;
    private String query;
    private boolean bNewClick = false;

    
    /** Creates new form DialogColor */
    public DlgQuery(java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        initComponents();
        btnNext.setVisible(false);
        
        timer = new Timer(50, new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
                if (bNewClick)
                {
                    calcNext();
                }
            }
        });
        resetLangue();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setVisible(true);
    }
    
    private void resetLangue()
    {
        setTitle("");
    }
    
    private void calcNext()
    {
        String tablename = "";
        bNewClick = true;
        
        if (script.length()>1)
        {
            int pos = script.indexOf(";");
            if (pos>0)
            {
                query = script.substring(0, pos);
                script = script.substring(pos+1);
            }
            else
            {
                query = script;
                script = "";
            }
            query = query.toUpperCase();
            query = query.replace("\r\n", " ").trim();

            if (query.startsWith("ALTER ") || query.startsWith("INSERT ") || query.startsWith("UPDATE ") || query.startsWith("DELETE ") || query.startsWith("DROP ") || query.startsWith("SELECT "))
            {
                if (query.startsWith("SELECT"))
                {                    
                    int pos2 = query.indexOf("FROM ");
                    if (pos2 > 0)
                    {
                        int pos3 = query.indexOf("WHERE ");
                        if (pos3 < 0)
                        {
                            pos3 = query.indexOf("ORDER BY ");
                            if (pos3 < 0)
                            {
                                pos3 = query.indexOf("GROUP BY ");
                            }
                        }
                        if (pos3 > 0)
                        {
                            tablename = query.substring(pos2 + 5, pos3 - 1);
                        }
                        else
                        {
                            tablename = query.substring(pos2 + 5);
                        }
                        if (query.startsWith("SELECT * FROM "))
                            query = query.replace("SELECT * FROM ", "SELECT ID FROM ");
                    }
                    if (!tablename.equals(""))
                    {
                        tablename = tablename.toLowerCase().trim();
                        Records records = starLoginManager.getRecords(query, tablename);
                        DataGrid dgrGrid = new DataGrid(records.getRecords(), records.getHeaders(), records.getFields(), records.getSizes(), pnlGrid, false, true, false, false, this, true, 50);
                        //pnlGrid.paintImmediately(pnlGrid.getBounds());
                        pnlGrid.paintAll(pnlGrid.getGraphics());
                        bNewClick = false;
                    }
                }
                else
                {
                    pnlGrid.removeAll();
                    pnlGrid.paintAll(pnlGrid.getGraphics());
                    boolean result = starLoginManager.updateDataBase(query);
                    if (query.length() > 1000)
                    {
                        query = query.substring(0, 1000).concat("...");
                    }
                    if (result)
                        MainClass.setMessage(query.concat("\r\n").concat(String.valueOf(result)), JOptionPane.INFORMATION_MESSAGE);
                    else
                        MainClass.setMessage(query.concat("\r\n").concat(String.valueOf(result)));
                }
            }
        }
    }

    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpTable = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        pnlParams = new javax.swing.JPanel();
        pnlTexte = new javax.swing.JPanel();
        scrScript = new javax.swing.JScrollPane();
        txtScript = new javax.swing.JTextArea();
        pnlBoutons = new javax.swing.JPanel();
        btnOK = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        pnlGrid = new javax.swing.JPanel();

        jPanel2.setPreferredSize(new java.awt.Dimension(910, 42));

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new java.awt.FlowLayout());

        pnlParams.setPreferredSize(new java.awt.Dimension(1000, 720));
        pnlParams.setLayout(new java.awt.BorderLayout());

        pnlTexte.setPreferredSize(new java.awt.Dimension(800, 300));
        pnlTexte.setLayout(new java.awt.BorderLayout());

        scrScript.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        scrScript.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrScript.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        txtScript.setLineWrap(true);
        txtScript.setWrapStyleWord(true);
        scrScript.setViewportView(txtScript);

        pnlTexte.add(scrScript, java.awt.BorderLayout.CENTER);

        pnlParams.add(pnlTexte, java.awt.BorderLayout.CENTER);

        pnlBoutons.setPreferredSize(new java.awt.Dimension(42, 42));

        btnOK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/ok.png"))); // NOI18N
        btnOK.setBorder(null);
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnOK);

        btnNext.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/right.png"))); // NOI18N
        btnNext.setBorder(null);
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnNext);

        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/cancel.png"))); // NOI18N
        btnCancel.setBorder(null);
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        pnlBoutons.add(btnCancel);

        pnlParams.add(pnlBoutons, java.awt.BorderLayout.NORTH);

        pnlGrid.setPreferredSize(new java.awt.Dimension(100, 400));
        pnlGrid.setLayout(new java.awt.BorderLayout());
        pnlParams.add(pnlGrid, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pnlParams);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKActionPerformed
    {//GEN-HEADEREND:event_btnOKActionPerformed
        script = txtScript.getText();
        calcNext();
        timer.start();
        btnNext.setVisible(true);
    }//GEN-LAST:event_btnOKActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelActionPerformed
    {//GEN-HEADEREND:event_btnCancelActionPerformed
        txtScript.setText("");
        script = "";
        query = "";
        pnlGrid.removeAll();
        pnlGrid.paintAll(pnlGrid.getGraphics());
        timer.stop();
        btnNext.setVisible(false);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextActionPerformed
    {//GEN-HEADEREND:event_btnNextActionPerformed
        bNewClick = true;
    }//GEN-LAST:event_btnNextActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        timer.stop();
    }//GEN-LAST:event_formWindowClosing

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnOK;
    private javax.swing.ButtonGroup grpTable;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel pnlBoutons;
    private javax.swing.JPanel pnlGrid;
    private javax.swing.JPanel pnlParams;
    private javax.swing.JPanel pnlTexte;
    private javax.swing.JScrollPane scrScript;
    private javax.swing.JTextArea txtScript;
    // End of variables declaration//GEN-END:variables
    
}
