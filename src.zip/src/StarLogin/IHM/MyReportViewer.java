/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

/**
 *
 * @author Francois
 */
import java.awt.*;
import java.sql.Connection;
import java.util.HashMap;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

public class MyReportViewer extends JFrame
{
    private JRViewer viewer;
    
    public MyReportViewer(String fileName)
    {
        this(fileName, null);
    }

    public MyReportViewer(String fileName, HashMap parameter)
    {
        this(fileName, parameter, false);
    }
    
    public void printReport()
    {
        viewer.printDirectly();
    }
    
    public void printWithDialog()
    {
        viewer.printWithDialog();
    }
    
    public void saveReport()
    {
        viewer.saveDirectly();
    }
    
    public void autoSave(String destinationFile, int fileType)
    {
        viewer.autoSave(destinationFile, fileType);
    }

    @SuppressWarnings("unchecked")
    public MyReportViewer(String fileName, HashMap parameter, boolean hidden)
    {
        super(MainClass.bundle.getString("ViewReport"));
        try
        {
            Connection con = MainClass.starLoginManager.getConnection().GetConnection();//DriverManager.getConnection("jdbc:odbc:DataSourceName");

            //Way 1
            /*JasperDesign jasperDesign = JasperManager.loadXmlDesign(fileName);
            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            JasperPrint print = JasperFillManager.fillReport(jasperReport, parameter, con);*/

            //Way 2
            /*JasperReport jasperReport = JasperCompileManager.compileReport(fileName);
            JasperPrint print = JasperFillManager.fillReport(jasperReport, parameter, con);*/

            //Way 3 (Here the parameter file should be in .jasper extension i.e., the compiled report)
            JasperPrint print = JasperFillManager.fillReport(fileName, parameter, con);

            //JRViewer viewer = new JRViewer(print, hidden);
            viewer = new JRViewer(print, hidden);

            Container c = getContentPane();
            c.add(viewer);
        }
        catch (JRException jre)
        {
            MainClass.setMessage(jre.getMessage());
        }

        setBounds(10, 10, 1000, 700);
        this.setPreferredSize(new Dimension(1000, 700));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/rapports.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}