package StarLogin.IHM;


import StarLogin.IHM.components.KeyType.*;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartChoiceForm extends JFrame
{
    private Color color;
    private int kc; //key code
    private int cp; //caret position
    private StarLogin.Systeme.Data.Event event;
    private byte currentSelectedChart = ChartKind.all;
    private byte currentSelectedHouseSystem = HouseSystem.Campanus;
    private byte currentSelectedCoordSystem = CoordSystem.Tropical;
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Places places;
    private Option defaultOption;
    private Parts parts;
    private Stars stars;
    private ChartEvent chartEvent;
    private ChartElements chartSynastryElements = new ChartElements();
    private ChartElements chartCompositeElements = new ChartElements();
    private ChartElements chartFreeElements = new ChartElements();
    private static int windowNB = 0;
    private String selectedChartID = null;
    private Color neutralColor;
    private Color dynamicColor;
    private Color harmonicColor;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private JFrame parentForm;
    private String placeReturn;
    private String placeCycle;
    private int choixAction = 0;
   
    public void setColor(Color color)
    {
        this.color = color;
    }
    public Color getColor()
    {
        return color;
    }
    
    private void resetLangue()
    {
        setTitle(bundle.getString("ChartsSelection"));
        txtPlaceReturn.setToolTipText(bundle.getString("DoubleClick4List"));
        txtPlaceCycle.setToolTipText(bundle.getString("DoubleClick4List"));
        jOptSingleSelection.setText(bundle.getString("SingleChartSelection"));
        jOptMultiSelection.setText(bundle.getString("MultiChartSelection"));
        btnSelectAll.setText(bundle.getString("SelectAllKinds"));
        chkNormal.setText(bundle.getString("NormalChart"));
        chkAstronomical.setText(bundle.getString("LocalChart"));
        jLabel36.setText(bundle.getString("View"));
        optHorizon.setText(bundle.getString("Horizon"));
        optZenith.setText(bundle.getString("Zenith"));
        chkSymbolicDir.setText(bundle.getString("SymbolicDir"));
        jLabel4.setText(bundle.getString("Age"));
        jLabel16.setText(bundle.getString("WithCorrespondance"));
        jLabel17.setText(bundle.getString("DegreeEquals"));
        chkPrimaryDir.setText(bundle.getString("PrimaryDir"));
        jLabel3.setText(bundle.getString("Age"));
        jLabel14.setText(bundle.getString("WithCorrespondance"));
        jLabel15.setText(bundle.getString("DegreeEquals"));
        chkSecondaryDir.setText(bundle.getString("SecondaryDir"));
        jLabel2.setText(bundle.getString("Age"));
        jLabel10.setText(bundle.getString("WithCorrespondance"));
        jLabel12.setText(bundle.getString("DayEquals"));
        chkTransits.setText(bundle.getString("Transits"));
        jLabel1.setText(bundle.getString("Date"));
        chkRevolution.setText(bundle.getString("Revolution"));
        chkPrecession.setText(bundle.getString("Precessionned"));
        jLabel5.setText(bundle.getString("ReturnsNumber"));
        jLabel21.setText(bundle.getString("Planet"));
        jLabel18.setText(bundle.getString("Place"));
        jLabel19.setText(bundle.getString("Latitude"));
        jLabel20.setText(bundle.getString("Longitude"));
        chkCycle.setText(bundle.getString("Cycle"));
        jLabel6.setText(bundle.getString("CyclesNumber"));
        jLabel26.setText(bundle.getString("Planet1"));
        jLabel27.setText(bundle.getString("Planet2"));
        jLabel23.setText(bundle.getString("Place"));
        jLabel24.setText(bundle.getString("Latitude"));
        jLabel25.setText(bundle.getString("Longitude"));
        chkSynastry.setText(bundle.getString("Synastry"));
        jLabel7.setText(bundle.getString("RemainingEventSelections"));
        optSynastryChartSelect.setText(bundle.getString("Chart"));
        optSynastryChartSelect.setToolTipText(bundle.getString("FromSavedCharts"));
        optSynastryEventSelect.setText(bundle.getString("Event"));
        optSynastryEventSelect.setToolTipText(bundle.getString("FromEvent"));
        btnOKEventSelectSysnastry.setToolTipText(bundle.getString("ValidateCurrentEventSelection"));
        chkComposite.setText(bundle.getString("Composite"));
        jLabel8.setText(bundle.getString("Charts"));
        jLabel28.setText(bundle.getString("RemainingEventSelections"));
        optCompositeChartSelect.setText(bundle.getString("Chart"));
        optCompositeChartSelect.setToolTipText(bundle.getString("FromSavedCharts"));
        optCompositeEventSelect.setText(bundle.getString("Event"));
        optCompositeEventSelect.setToolTipText(bundle.getString("FromEvent"));
        btnOKEventSelectComposite.setToolTipText(bundle.getString("ValidateCurrentEventSelection"));
        chkFree.setText(bundle.getString("FreeChart"));
        btnEditFree.setText(bundle.getString("EditFreeChart"));
        chkHarmonic.setText(bundle.getString("HarmonicChart"));
        jLabel9.setText(bundle.getString("HarmonicNB"));
        chkSeed.setText(bundle.getString("SeedHoroscope"));
        chkProjective.setText(bundle.getString("ProjectiveChart"));
        chkGeocentric.setText(bundle.getString("Geocentric"));
        chkHeliocentric.setText(bundle.getString("Heliocentric"));
        chkTropical.setText(bundle.getString("Tropical"));
        chkSidereal.setText(bundle.getString("Sidereal"));
        chkEquatorial.setText(bundle.getString("Equatorial"));
        chkEcliptic.setText(bundle.getString("Ecliptic"));
        chkLocal.setText(bundle.getString("Local"));
        chkDomitudes.setText(bundle.getString("Domitudes"));
        chkHeliocentricNormal.setText(bundle.getString("HeliocentricNormal"));
        chkHeliocentricSidereal.setText(bundle.getString("HeliocentricSidereal"));
        optAbenragel.setText("Abenragel");
        optAlbategnius.setText("Albategnius");
        optAlcabitius.setText("Alcabitius");
        optKoch.setText("Koch");
        optPlacidus.setText("Placidus");
        optWiesel.setText("Wiesel");
        optPorpyre.setText("Porphyre");
        optCampanus.setText("Campanus");
        optRegiomontanus.setText("Regiomontanus");
        optMaternusAs.setText("Maternus / AS");
        optMaternusMC.setText("Maternus / MC");
        optAncient.setText(bundle.getString("Ancient"));
        optTwoHours.setText(bundle.getString("TwoHours"));
        optSemiAngular.setText(bundle.getString("SemiAngular"));
        optEquatorialRegular.setText(bundle.getString("EquatorialRegular"));
        optColinEvans.setText(bundle.getString("ColinEvans"));
        optBazchenoff.setText(bundle.getString("Bazchenoff"));
        optNodal.setText(bundle.getString("Nodal"));
        optSolar.setText(bundle.getString("Solar"));
        optZenithal.setText(bundle.getString("Zenithal"));
        optZodiacal.setText(bundle.getString("Zodiacal"));
        jLabel11.setText(bundle.getString("Colors"));
        jLabel13.setText(bundle.getString("Sun"));
        jLabel29.setText(bundle.getString("Moon"));
        jLabel31.setText(bundle.getString("Mercury"));
        jLabel33.setText(bundle.getString("Venus"));
        jLabel35.setText(bundle.getString("Mars"));
        jLabel37.setText(bundle.getString("Jupiter"));
        lblColorJupiter.setToolTipText(bundle.getString("Click2ModifyColor"));
        jLabel39.setText(bundle.getString("Saturn"));
        jLabel41.setText(bundle.getString("Uranus"));
        jLabel43.setText(bundle.getString("Neptune"));
        jLabel45.setText(bundle.getString("Pluto"));
        jLabel47.setText(bundle.getString("Gaia"));
        jLabel49.setText(bundle.getString("Nodes"));
        lblColorNodes.setToolTipText(bundle.getString("Click2ModifyColor"));
        jLabel51.setText(bundle.getString("Houses"));
        jLabel53.setText(bundle.getString("Asteroids"));
        jLabel55.setText(bundle.getString("Vulcan"));
        jLabel57.setText(bundle.getString("Text"));
        jLabel59.setText(bundle.getString("Fire"));
        jLabel61.setText(bundle.getString("Earth"));
        lblColorEarth.setToolTipText(bundle.getString("Click2ModifyColor"));
        jLabel63.setText(bundle.getString("Air"));
        jLabel65.setText(bundle.getString("Water"));
        jLabel67.setText(bundle.getString("Neutral"));
        jLabel69.setText(bundle.getString("Dynamic"));
        jLabel71.setText(bundle.getString("Harmonic"));
        jLabel22.setText(bundle.getString("Sizes"));
        jLabel30.setText(bundle.getString("Zodiac"));
        jLabel34.setText(bundle.getString("Signs"));
        jLabel38.setText(bundle.getString("Planets"));
        jLabel42.setText(bundle.getString("Characters"));
        jLabel40.setText(bundle.getString("Main"));
        chkSun.setText(bundle.getString("Sun"));
        chkMoon.setText(bundle.getString("Moon"));
        chkMercury.setText(bundle.getString("Mercury"));
        chkVenus.setText(bundle.getString("Venus"));
        chkMars.setText(bundle.getString("Mars"));
        chkJupiter.setText(bundle.getString("Jupiter"));
        chkSaturn.setText(bundle.getString("Saturn"));
        chkUranus.setText(bundle.getString("Uranus"));
        chkNeptune.setText(bundle.getString("Neptune"));
        chkPluto.setText(bundle.getString("Pluto"));
        jLabel44.setText(bundle.getString("Other"));
        chkGaia.setText(bundle.getString("Gaia"));
        chkNN.setText(bundle.getString("NorthNode"));
        chkLilith.setText(bundle.getString("Lilith"));
        chkTrueLilith.setText(bundle.getString("True"));
        chkEast.setText(bundle.getString("East"));
        chkZenith.setText(bundle.getString("Zenith"));
        chkVertex.setText(bundle.getString("Vertex"));
        chkVulcan.setText(bundle.getString("Vulcan"));
        chkCeres.setText(bundle.getString("Ceres"));
        chkPallas.setText(bundle.getString("Pallas"));
        chkJuno.setText(bundle.getString("Juno"));
        chkVesta.setText(bundle.getString("Vesta"));
        chkChiron.setText(bundle.getString("Chiron"));
        chkOtherPoint.setText(bundle.getString("OtherPoint"));
        jLabel125.setText(bundle.getString("OtherPoint"));
        optOtherPtStar.setText(bundle.getString("Star"));
        optOtherPtPart.setText(bundle.getString("ArabianPart"));
        optOtherPtComet.setText(bundle.getString("Comet"));
        optOtherPtAsteroid.setText(bundle.getString("Asteroid"));
        optOtherPtNone.setText(bundle.getString("None"));
        jLabel46.setText(bundle.getString("Display"));
        chkStars.setText(bundle.getString("Stars"));
        chkConstellations.setText(bundle.getString("Constellations"));
        chkAsteroids.setText(bundle.getString("Asteroids"));
        chkHouses.setText(bundle.getString("Houses"));
        chkAspects.setText(bundle.getString("Aspects"));
        chkCoordinates.setText(bundle.getString("Coordinates"));
        chkStraightLines.setText(bundle.getString("StraightLines"));
        chkShaded.setText(bundle.getString("ShadedColors"));
        chkBarycenter.setText(bundle.getString("Barycenter"));
        optSingleWeight.setText(bundle.getString("SameWeight"));
        optDifferentWeights.setText(bundle.getString("DifferentWeights"));
        jLabel48.setText(bundle.getString("ZodiacDirection"));
        optEastAS.setText(bundle.getString("LeftAS"));
        optEastAries.setText(bundle.getString("LeftAries"));
        chkAspectsSymbol.setText(bundle.getString("AspectsSymbol"));
        chkSignsName.setText(bundle.getString("SignsName"));
        chkHousesCoord.setText(bundle.getString("HousesCoords"));
        jLabel54.setText(bundle.getString("AspectDefinition"));
        lblAspectsColorMode.setText(bundle.getString("AspectsColorMode"));
        optColorMode1.setText(bundle.getString("ByAspectKind"));
        optColorMode2.setText(bundle.getString("ForEachAspect"));
        chkConjunction.setText(bundle.getString("Conjunction"));
        chkSextile.setText(bundle.getString("Sextile"));
        chkSquare.setText(bundle.getString("Square"));
        chkTrine.setText(bundle.getString("Trine"));
        chkOpposition.setText(bundle.getString("Opposition"));
        chkVigintile.setText(bundle.getString("Vigintile"));
        chkSemiSextile.setText(bundle.getString("SemiSextile"));
        chkSemiQuintile.setText(bundle.getString("SemiQuintile"));
        chkNonagon.setText(bundle.getString("Nonagon"));
        chkSemiSquare.setText(bundle.getString("SemiSquare"));
        chkSeptile.setText(bundle.getString("Septile"));
        chkQuintile.setText(bundle.getString("Quintile"));
        chkTriDectile.setText(bundle.getString("TriDectile"));
        chkSesquiSquare.setText(bundle.getString("SesquiSquare"));
        chkBiQuintile.setText(bundle.getString("BiQuintile"));
        chkInconjunct.setText(bundle.getString("Inconjunct"));
        chkQuadriNonagon.setText(bundle.getString("QuadriNonagon"));
        chkOtherAspect.setText(bundle.getString("OtherAspect"));
        jLabel129.setText(bundle.getString("OtherAspectName"));
        jLabel119.setText(bundle.getString("AspectedPlanets"));
        chkAspectSun.setText(bundle.getString("Sun"));
        chkAspectMoon.setText(bundle.getString("Moon"));
        chkAspectMercury.setText(bundle.getString("Mercury"));
        chkAspectVenus.setText(bundle.getString("Venus"));
        chkAspectMars.setText(bundle.getString("Mars"));
        chkAspectJupiter.setText(bundle.getString("Jupiter"));
        chkAspectSaturn.setText(bundle.getString("Saturn"));
        chkAspectUranus.setText(bundle.getString("Uranus"));
        chkAspectNeptune.setText(bundle.getString("Neptune"));
        chkAspectPluto.setText(bundle.getString("Pluto"));
        chkAspectGaia.setText(bundle.getString("Gaia"));
        chkAspectNodes.setText(bundle.getString("NorthNode"));
        chkAspectLilith.setText(bundle.getString("Lilith"));
        chkAspectEast.setText(bundle.getString("East"));
        chkAspectZenith.setText(bundle.getString("Zenith"));
        chkAspectVertex.setText(bundle.getString("Vertex"));
        chkAspectVulcan.setText(bundle.getString("Vulcan"));
        chkAspectCeres.setText(bundle.getString("Ceres"));
        chkAspectPallas.setText(bundle.getString("Pallas"));
        chkAspectJuno.setText(bundle.getString("Juno"));
        chkAspectVesta.setText(bundle.getString("Vesta"));
        chkAspectChiron.setText(bundle.getString("Chiron"));
        chkAspectAS.setText(bundle.getString("Ascendant"));
        chkAspectMC.setText(bundle.getString("Midheaven"));
        chkAspectOtherPoint.setText(bundle.getString("OtherPointName"));
        btnReadChart.setText(bundle.getString("ReadSavedChart"));
        optLastSavedChart.setText(bundle.getString("LastSavedChart"));
        optSavedChart.setText(bundle.getString("SavedChart"));
        btnDisplayCharts.setText(bundle.getString("DisplaySelectedCharts"));
    }
    
    /** Creates new form ChartChoiceForm */
    @SuppressWarnings("unchecked")
    public ChartChoiceForm(JFrame parent)
    {
        //java.text.DecimalFormatSymbols decimalFormatSymbol = new java.text.DecimalFormatSymbols();
        //decimalFormatSymbol.setDecimalSeparator('.');
        defaultOption = MainClass.getCurrentOption();
        parentForm = parent;
        initComponents();
        resetLangue();
        
        jPanel55.setVisible(false);
        event = MainForm.currentEvent;
        lblForEvent.setText(bundle.getString("for").concat(" ").concat(event.getEventName()).concat(" ").concat(event.getOtherNames()).concat(" ").concat(event.getSurname()));
        chartEvent = new ChartEvent(event);
        tabSettings.setTitleAt(0, bundle.getString("ChartKind"));
        tabSettings.setTitleAt(1, bundle.getString("CoordinatesSystem"));
        tabSettings.setTitleAt(2, bundle.getString("HousesSystem"));
        tabSettings.setTitleAt(3, bundle.getString("ChartLook"));
        tabSettings.setTitleAt(4, bundle.getString("Planets"));
        tabSettings.setTitleAt(5, bundle.getString("Aspects"));
        tabSettings.setTitleAt(6, bundle.getString("Orbs"));
        //this.setExtendedState(MAXIMIZED_BOTH);
        pnlOtherPoint.setVisible(false);
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/carter.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        places = starLoginManager.getPlaces();
        
        Asteroids asteroids = starLoginManager.getAsteroids();
        ArrayList getFields = asteroids.fieldsValues();
        DefaultComboBoxModel comboModel = (DefaultComboBoxModel)getFields.get(1);
        cboAsteroid.setModel(comboModel);
        
        stars = starLoginManager.getStars();
        getFields = stars.fieldsValues();
        comboModel = (DefaultComboBoxModel)getFields.get(3);
        cboStarIdentity.setModel(comboModel);
        
        Comets comets = starLoginManager.getComets();
        getFields = comets.fieldsValues();
        comboModel = (DefaultComboBoxModel)getFields.get(1);
        cboComet.setModel(comboModel);
        
        parts = starLoginManager.getParts();
        getFields = parts.fieldsValues();
        //cboPart.removeAllItems();
        comboModel = (DefaultComboBoxModel)getFields.get(1);
        cboPart.setModel(comboModel);
        
        cboD2.addItem(bundle.getString("year"));
        cboD2.addItem(bundle.getString("month"));
        cboD2.addItem(bundle.getString("week"));
        cboD1.addItem(bundle.getString("year"));
        cboD1.addItem(bundle.getString("month"));
        cboD1.addItem(bundle.getString("week"));
        cboDS.addItem(bundle.getString("year"));
        cboDS.addItem(bundle.getString("month"));
        cboDS.addItem(bundle.getString("week"));
        cboD2.setSelectedIndex(0);
        cboD1.setSelectedIndex(0);
        cboDS.setSelectedIndex(0);
        String planet;
        for (byte i=0;i<=Planets.Lilith;i++)
        {
            if (i == Planets.Gaia) i++;
            planet = MainForm.planetName[i];
            cboPlanetReturn.addItem(planet);
            cboPlanet1Cycle.addItem(planet);
            cboPlanet2Cycle.addItem(planet);
        }
        planet = MainForm.planetName[Planets.Chiron];
        cboPlanetReturn.addItem(planet);
        cboPlanet1Cycle.addItem(planet);
        cboPlanet2Cycle.addItem(planet);
        cboPlanetReturn.setSelectedIndex(Planets.Sun);
        cboPlanet1Cycle.setSelectedIndex(Planets.Jupiter);
        cboPlanet2Cycle.setSelectedIndex(Planets.Saturn);
        for (byte i=0;i<=Planets.MC;i++)
        {
            planet = MainForm.planetName[i];
            cboPartRef.addItem(planet);
            cboPartPlus.addItem(planet);
            cboPartMinus.addItem(planet);
        }
        
        unselectAllChartKinds();
        chkNormal.setSelected(true);
        //pnlNormal.setVisible(true);
        currentSelectedChart = ChartKind.normal;
        //btnSelectAll.setVisible(false);
        
        chkHeliocentricNormal.setVisible(false);
        chkHeliocentricSidereal.setVisible(false);
        
        //Get the default options
        //-----------------------
        //coordinates system
        byte system = defaultOption.getCoordSys();
        currentSelectedCoordSystem = system;
        switch ((int) system)
        {
            case CoordSystem.Tropical:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
                break;
            case CoordSystem.Sidereal:
                chkGeocentric.setSelected(true);
                chkSidereal.setSelected(true);
                break;
            case CoordSystem.Local:
                chkGeocentric.setSelected(true);
                chkLocal.setSelected(true);
                break;
            case CoordSystem.Domitudes:
                chkGeocentric.setSelected(true);
                chkDomitudes.setSelected(true);
                break;
            case CoordSystem.Equatorial:
                chkGeocentric.setSelected(true);
                chkEquatorial.setSelected(true);
                break;
            case CoordSystem.Ecliptic:
                chkGeocentric.setSelected(true);
                chkEcliptic.setSelected(true);
                break;
            case CoordSystem.HelioNormal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricNormal.setSelected(true);
                break;
            case CoordSystem.HelioSidereal:
                chkHeliocentric.setSelected(true);
                chkHeliocentricSidereal.setSelected(true);
                break;
            default:
                chkGeocentric.setSelected(true);
                chkTropical.setSelected(true);
        }
        
        //houses system
        byte domif = defaultOption.getHouseSys();
        currentSelectedHouseSystem = domif;
        switch ((int) domif)
        {
            case HouseSystem.Abenragel:
                optAbenragel.setSelected(true);
                break;
            case HouseSystem.Albategnius:
                optAlbategnius.setSelected(true);
                break;
            case HouseSystem.Alcabitius:
                optAlcabitius.setSelected(true);
                break;
            case HouseSystem.Ancient:
                optAncient.setSelected(true);
                break;
            case HouseSystem.Bazchenoff:
                optBazchenoff.setSelected(true);
                break;
            case HouseSystem.Campanus:
                optCampanus.setSelected(true);
                break;
            case HouseSystem.ColinEvans:
                optColinEvans.setSelected(true);
                break;
            case HouseSystem.EquatorialRegular:
                optEquatorialRegular.setSelected(true);
                break;
            case HouseSystem.Koch:
                optKoch.setSelected(true);
                break;
            case HouseSystem.MaternusAs:
                optMaternusAs.setSelected(true);
                break;
            case HouseSystem.MaternusMC:
                optMaternusMC.setSelected(true);
                break;
            case HouseSystem.Nodal:
                optNodal.setSelected(true);
                break;
            case HouseSystem.Placidus:
                optPlacidus.setSelected(true);
                break;
            case HouseSystem.Porphyre:
                optPorpyre.setSelected(true);
                break;
            case HouseSystem.Regiomontanus:
                optRegiomontanus.setSelected(true);
                break;
            case HouseSystem.SemiAngular:
                optSemiAngular.setSelected(true);
                break;
            case HouseSystem.Solar:
                optSolar.setSelected(true);
                break;
            case HouseSystem.TwoHours:
                optTwoHours.setSelected(true);
                break;
            case HouseSystem.Wiesel:
                optWiesel.setSelected(true);
                break;
            case HouseSystem.Zenithal:
                optZenithal.setSelected(true);
                break;
            case HouseSystem.Zodiacal:
                optZodiacal.setSelected(true);
                break;
            default:
                optCampanus.setSelected(true);
        }
        
        //other point
        byte otherPt = defaultOption.getOtherPointType();
        switch ((int) otherPt)
        {
            case OtherPt.asteroid:
                optOtherPtAsteroid.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(true);
                cboComet.setVisible(false);
                cboAsteroid.setSelectedItem(defaultOption.getOtherPointName());
                break;
            case OtherPt.part:
                optOtherPtPart.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(true);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
                cboPart.setSelectedItem(defaultOption.getOtherPointName());
                setPart();
                break;
            case OtherPt.star:
                optOtherPtStar.setSelected(true);
                pnlOtherPtStar.setVisible(true);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
                cboStarIdentity.setSelectedItem(defaultOption.getOtherPointName());
                setStar();
                break;
            case OtherPt.comet:
                optOtherPtComet.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(true);
                cboComet.setSelectedItem(defaultOption.getOtherPointName());
                break;
            default:
                optOtherPtNone.setSelected(true);
                pnlOtherPtStar.setVisible(false);
                pnlOtherPtPart.setVisible(false);
                cboAsteroid.setVisible(false);
                cboComet.setVisible(false);
        }
        
        neutralColor = defaultOption.getNeutralColor();
        dynamicColor = defaultOption.getDynamicColor();
        harmonicColor = defaultOption.getHarmonicColor();
        
        //other aspect
        txtOtherAspectName.setText(defaultOption.getOtherAspectName());
        chkOtherAspect.setSelected(defaultOption.getShownAspect17());
        txtOtherAspect.setText(defaultOption.getTypeAspect17());
        txtOtherAspect.setForeground(getColorTypeAspect(defaultOption.getTypeAspect17()));
        lblColorOtherAspect.setBackground(defaultOption.getColorAspect17());
        txtValueOtherAspect.setText(defaultOption.getOtherAspectValue());
        
        //selected charts with their characteristics
        String chartKinds = defaultOption.getChartKinds();
        int pos = chartKinds.indexOf(';');
        String chart;
        
        if (pos>0)
        {
            while (pos>0)
            {
                chart = chartKinds.substring(0,pos);
                setChart(new Integer(chart).intValue());
                chartKinds = chartKinds.substring(pos+1);
                pos = chartKinds.indexOf(';');
            }
            if (!chartKinds.equals(""))
            {
                setChart(new Integer(chartKinds).intValue());
            }
        }
        else
        {
            setChart(new Integer(chartKinds).intValue());
        }
        
        chkAspectsSymbol.setSelected(defaultOption.getSymbolAspects());
        chkHousesCoord.setSelected(defaultOption.getHousesCoords());
        chkSignsName.setSelected(defaultOption.getSignsNames());
        chkStars.setSelected(defaultOption.getViewStars());
        sldStars.setValue((int)(new Double(defaultOption.getLimitMag()).doubleValue() * 2.0));
        chkConstellations.setSelected(defaultOption.getViewConstellations());
        chkAsteroids.setSelected(defaultOption.getViewAsteroids());
        chkHouses.setSelected(defaultOption.getViewHouses());
        chkAspects.setSelected(defaultOption.getViewAspects());
        chkCoordinates.setSelected(defaultOption.getViewCoordinates());
        chkStraightLines.setSelected(defaultOption.getViewStraightLines());
        chkShaded.setSelected(defaultOption.getViewShadedLines());
        chkBarycenter.setSelected(defaultOption.getViewBarycenter());
        if (defaultOption.getSingleWeight() == true)
        {
            optSingleWeight.setSelected(true);
        }
        else
        {
            optDifferentWeights.setSelected(true);
        }
        if (defaultOption.getChartCompositeFromAS() == true)
        {
            optCompositeFromAS.setSelected(true);
        }
        else
        {
            optCompositeFromAS.setSelected(true);
        }
        if (defaultOption.getChartSelectSingle() == true)
        {
            jOptSingleSelection.setSelected(true);
        }
        else
        {
            jOptMultiSelection.setSelected(true);
        }
        if (defaultOption.getColoredAspects() == true)
        {
            optColorMode2.setSelected(true);
        }
        else
        {
            optColorMode1.setSelected(true);
        }
        if (defaultOption.getLeftAsct() == true)
        {
            optEastAS.setSelected(true);
        }
        else
        {
            optEastAries.setSelected(true);
        }
        if (defaultOption.getHorizon() == true)
        {
            optHorizon.setSelected(true);
        }
        else
        {
            optZenith.setSelected(true);
        }
        
        txtCorrespondDS.setText(defaultOption.getChartDirSCorresp());
        txtEqualsDS.setText(defaultOption.getChartDirSDegree());
        cboDS.setSelectedIndex(new Integer(defaultOption.getChartDirSSpaceKind()).intValue());
        txtCorrespondD1.setText(defaultOption.getChartDir1Corresp());
        txtEqualsD1.setText(defaultOption.getChartDir1Degree());
        cboD1.setSelectedIndex(new Integer(defaultOption.getChartDir1SpaceKind()).intValue());
        txtCorrespondD2.setText(defaultOption.getChartDir2Corresp());
        txtEqualsD2.setText(defaultOption.getChartDir2Day());
        cboD2.setSelectedIndex(new Integer(defaultOption.getChartDir2SpaceKind()).intValue());
        chkPrecession.setSelected(defaultOption.getChartReturnPrecess());
        cboPlanetReturn.setSelectedIndex(new Integer(defaultOption.getChartReturnPlanet()).intValue());
        cboPlanet1Cycle.setSelectedIndex(new Integer(defaultOption.getChartCyclePlanet1()).intValue());
        cboPlanet2Cycle.setSelectedIndex(new Integer(defaultOption.getChartCyclePlanet2()).intValue());
        
        Place place = starLoginManager.getPlace(defaultOption.getChartCyclePlaceID());
        placeCycle = place.getPlaceName();
        txtPlaceCycle.setText(placeCycle);
        String latitude = place.getPlaceLatitude();
        String longitude = place.getPlaceLongitude();
        FLatitude l = new FLatitude(latitude);
        latitude = l.getLatitude();
        FLongitude lo = new FLongitude(longitude);
        longitude = lo.getLongitude();
        txtLatitudeCycle.setText(latitude);
        txtLongitudeCycle.setText(longitude);
        
        place = starLoginManager.getPlace(defaultOption.getChartReturnPlaceID());
        placeReturn = place.getPlaceName();
        txtPlaceReturn.setText(placeReturn);
        latitude = place.getPlaceLatitude();
        longitude = place.getPlaceLongitude();
        l = new FLatitude(latitude);
        latitude = l.getLatitude();
        lo = new FLongitude(longitude);
        longitude = lo.getLongitude();
        txtLatitudeReturn.setText(latitude);
        txtLongitudeReturn.setText(longitude);
        
        txtCompositeChartsNB.setText(defaultOption.getChartCompositeNB());
        txtHarmonicNB.setText(defaultOption.getChartHarmonicNB());
        
        //chart colors
        lblColorSun.setBackground(defaultOption.getSunColor());
        lblColorMoon.setBackground(defaultOption.getMoonColor());
        lblColorMercury.setBackground(defaultOption.getMercuryColor());
        lblColorVenus.setBackground(defaultOption.getVenusColor());
        lblColorMars.setBackground(defaultOption.getMarsColor());
        lblColorJupiter.setBackground(defaultOption.getJupiterColor());
        lblColorSaturn.setBackground(defaultOption.getSaturnColor());
        lblColorUranus.setBackground(defaultOption.getUranusColor());
        lblColorNeptune.setBackground(defaultOption.getNeptuneColor());
        lblColorPluto.setBackground(defaultOption.getPlutoColor());
        lblColorGaia.setBackground(defaultOption.getGaiaColor());
        lblColorNodes.setBackground(defaultOption.getNodesColor());
        lblColorHouses.setBackground(defaultOption.getCuspsColor());
        lblColorAsteroids.setBackground(defaultOption.getAsteroidsColor());
        lblColorVulcan.setBackground(defaultOption.getVulcanColor());
        lblColorText.setBackground(defaultOption.getVariousColor());
        lblColorFire.setBackground(defaultOption.getFireColor());
        lblColorEarth.setBackground(defaultOption.getEarthColor());
        lblColorAir.setBackground(defaultOption.getAirColor());
        lblColorWater.setBackground(defaultOption.getWaterColor());
        lblColorNeutral.setBackground(defaultOption.getNeutralColor());
        lblColorDynamic.setBackground(defaultOption.getDynamicColor());
        lblColorHarmonic.setBackground(defaultOption.getHarmonicColor());
        
        //chart sizes
        sldZodiac.setValue(defaultOption.getZodiacSize());
        int sSize = defaultOption.getSignSize();
        int pSize = defaultOption.getPlanetSize();
        int cSize = defaultOption.getCharacterSize();
        sldSigns.setValue(sSize);
        sldPlanets.setValue(pSize);
        sldCharacters.setValue(cSize);
        
        //selected planets
        chkSun.setSelected(defaultOption.getShownSun());
        chkMoon.setSelected(defaultOption.getShownMoon());
        chkMercury.setSelected(defaultOption.getShownMercury());
        chkVenus.setSelected(defaultOption.getShownVenus());
        chkMars.setSelected(defaultOption.getShownMars());
        chkJupiter.setSelected(defaultOption.getShownJupiter());
        chkSaturn.setSelected(defaultOption.getShownSaturn());
        chkUranus.setSelected(defaultOption.getShownUranus());
        chkNeptune.setSelected(defaultOption.getShownNeptune());
        chkPluto.setSelected(defaultOption.getShownPluto());
        chkGaia.setSelected(defaultOption.getShownGaia());
        chkNN.setSelected(defaultOption.getShownNorthNode());
        chkLilith.setSelected(defaultOption.getShownLilith());
        chkTrueLilith.setSelected(defaultOption.getTrueLilith());
        chkEast.setSelected(defaultOption.getShownEast());
        chkZenith.setSelected(defaultOption.getShownZenith());
        chkVertex.setSelected(defaultOption.getShownVertex());
        chkVulcan.setSelected(defaultOption.getShownVulcan());
        chkCeres.setSelected(defaultOption.getShownCeres());
        chkPallas.setSelected(defaultOption.getShownPallas());
        chkJuno.setSelected(defaultOption.getShownJuno());
        chkVesta.setSelected(defaultOption.getShownVesta());
        chkChiron.setSelected(defaultOption.getShownChiron());
        chkOtherPoint.setSelected(defaultOption.getShownOtherPoint());
        pnlOtherPoint.setVisible(chkOtherPoint.isSelected());
        
        //aspects definition
        chkConjunction.setSelected(defaultOption.getShownAspect0());
        txtConjunction.setText(defaultOption.getTypeAspect0());
        txtConjunction.setForeground(getColorTypeAspect(defaultOption.getTypeAspect0()));
        lblColorConjunction.setBackground(defaultOption.getColorAspect0());
        chkSextile.setSelected(defaultOption.getShownAspect1());
        txtSextile.setText(defaultOption.getTypeAspect1());
        txtSextile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect1()));
        lblColorSextile.setBackground(defaultOption.getColorAspect1());
        chkSquare.setSelected(defaultOption.getShownAspect2());
        txtSquare.setText(defaultOption.getTypeAspect2());
        txtSquare.setForeground(getColorTypeAspect(defaultOption.getTypeAspect2()));
        lblColorSquare.setBackground(defaultOption.getColorAspect2());
        chkTrine.setSelected(defaultOption.getShownAspect3());
        txtTrine.setText(defaultOption.getTypeAspect3());
        txtTrine.setForeground(getColorTypeAspect(defaultOption.getTypeAspect3()));
        lblColorTrine.setBackground(defaultOption.getColorAspect3());
        chkOpposition.setSelected(defaultOption.getShownAspect4());
        txtOpposition.setText(defaultOption.getTypeAspect4());
        txtOpposition.setForeground(getColorTypeAspect(defaultOption.getTypeAspect4()));
        lblColorOpposition.setBackground(defaultOption.getColorAspect4());
        chkVigintile.setSelected(defaultOption.getShownAspect5());
        txtVigintile.setText(defaultOption.getTypeAspect5());
        txtVigintile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect5()));
        lblColorVigintile.setBackground(defaultOption.getColorAspect5());
        chkSemiSextile.setSelected(defaultOption.getShownAspect6());
        txtSemiSextile.setText(defaultOption.getTypeAspect6());
        txtSemiSextile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect6()));
        lblColorSemiSextile.setBackground(defaultOption.getColorAspect6());
        chkSemiQuintile.setSelected(defaultOption.getShownAspect7());
        txtSemiQuintile.setText(defaultOption.getTypeAspect7());
        txtSemiQuintile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect7()));
        lblColorSemiQuintile.setBackground(defaultOption.getColorAspect7());
        chkNonagon.setSelected(defaultOption.getShownAspect8());
        txtNonagone.setText(defaultOption.getTypeAspect8());
        txtNonagone.setForeground(getColorTypeAspect(defaultOption.getTypeAspect8()));
        lblColorNonagon.setBackground(defaultOption.getColorAspect8());
        chkSemiSquare.setSelected(defaultOption.getShownAspect9());
        txtSemiSquare.setText(defaultOption.getTypeAspect9());
        txtSemiSquare.setForeground(getColorTypeAspect(defaultOption.getTypeAspect9()));
        lblColorSemiSquare.setBackground(defaultOption.getColorAspect9());
        chkSeptile.setSelected(defaultOption.getShownAspect10());
        txtSeptile.setText(defaultOption.getTypeAspect10());
        txtSeptile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect10()));
        lblColorSeptile.setBackground(defaultOption.getColorAspect10());
        chkQuintile.setSelected(defaultOption.getShownAspect11());
        txtQuintile.setText(defaultOption.getTypeAspect11());
        txtQuintile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect11()));
        lblColorQuintile.setBackground(defaultOption.getColorAspect11());
        chkTriDectile.setSelected(defaultOption.getShownAspect12());
        txtTriDectile.setText(defaultOption.getTypeAspect12());
        txtTriDectile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect12()));
        lblColorTridectile.setBackground(defaultOption.getColorAspect12());
        chkSesquiSquare.setSelected(defaultOption.getShownAspect13());
        txtSesquiSquare.setText(defaultOption.getTypeAspect13());
        txtSesquiSquare.setForeground(getColorTypeAspect(defaultOption.getTypeAspect13()));
        lblColorSesquiSquare.setBackground(defaultOption.getColorAspect13());
        chkBiQuintile.setSelected(defaultOption.getShownAspect14());
        txtBiquintile.setText(defaultOption.getTypeAspect14());
        txtBiquintile.setForeground(getColorTypeAspect(defaultOption.getTypeAspect14()));
        lblColorBiQuintile.setBackground(defaultOption.getColorAspect14());
        chkInconjunct.setSelected(defaultOption.getShownAspect15());
        txtInconjunct.setText(defaultOption.getTypeAspect15());
        txtInconjunct.setForeground(getColorTypeAspect(defaultOption.getTypeAspect15()));
        lblColorInconjunct.setBackground(defaultOption.getColorAspect15());
        chkQuadriNonagon.setSelected(defaultOption.getShownAspect16());
        txtQuadriNonagon.setText(defaultOption.getTypeAspect16());
        txtQuadriNonagon.setForeground(getColorTypeAspect(defaultOption.getTypeAspect16()));
        lblColorQuadriNonagon.setBackground(defaultOption.getColorAspect16());
        
        //Aspected planets
        chkAspectSun.setSelected(defaultOption.getAspectsSun());
        chkAspectMoon.setSelected(defaultOption.getAspectsMoon());
        chkAspectMercury.setSelected(defaultOption.getAspectsMercury());
        chkAspectVenus.setSelected(defaultOption.getAspectsVenus());
        chkAspectMars.setSelected(defaultOption.getAspectsMars());
        chkAspectJupiter.setSelected(defaultOption.getAspectsJupiter());
        chkAspectSaturn.setSelected(defaultOption.getAspectsSaturn());
        chkAspectUranus.setSelected(defaultOption.getAspectsUranus());
        chkAspectNeptune.setSelected(defaultOption.getAspectsNeptune());
        chkAspectPluto.setSelected(defaultOption.getAspectsPluto());
        chkAspectGaia.setSelected(defaultOption.getAspectsGaia());
        chkAspectNodes.setSelected(defaultOption.getAspectsNorthNode());
        chkAspectLilith.setSelected(defaultOption.getAspectsLilith());
        chkAspectEast.setSelected(defaultOption.getAspectsEast());
        chkAspectZenith.setSelected(defaultOption.getAspectsZenith());
        chkAspectVertex.setSelected(defaultOption.getAspectsVertex());
        chkAspectVulcan.setSelected(defaultOption.getAspectsVulcan());
        chkAspectCeres.setSelected(defaultOption.getAspectsCeres());
        chkAspectPallas.setSelected(defaultOption.getAspectsPallas());
        chkAspectJuno.setSelected(defaultOption.getAspectsJuno());
        chkAspectVesta.setSelected(defaultOption.getAspectsVesta());
        chkAspectChiron.setSelected(defaultOption.getAspectsChiron());
        chkAspectAS.setSelected(defaultOption.getAspectsAS());
        chkAspectMC.setSelected(defaultOption.getAspectsMC());
        chkAspectOtherPoint.setSelected(defaultOption.getAspectsOtherPoint());
        
        //Orbs
        txtOrbLumLum.setText(defaultOption.getOrbLightLight());
        txtOrbLumIndiv.setText(defaultOption.getOrbLightTell());
        txtOrbLumJS.setText(defaultOption.getOrbLightOtherInd());
        txtOrbLumCol.setText(defaultOption.getOrbLightColl());
        txtOrbLumVirtMaj.setText(defaultOption.getOrbLightVirtMax());
        txtOrbLumVirtMin.setText(defaultOption.getOrbLightVirtMin());
        txtOrbIndivIndiv.setText(defaultOption.getOrbTellTell());
        txtOrbIndivJS.setText(defaultOption.getOrbTellOtherInd());
        txtOrbIndivCol.setText(defaultOption.getOrbTellColl());
        txtOrbIndivVirtMaj.setText(defaultOption.getOrbTellVirtMax());
        txtOrbIndivVirtMin.setText(defaultOption.getOrbTellVirtMin());
        txtOrbJSJS.setText(defaultOption.getOrbOtherIndOtherInd());
        txtOrbJSCol.setText(defaultOption.getOrbOtherIndColl());
        txtOrbJSvirtMaj.setText(defaultOption.getOrbOtherIndVirtMax());
        txtOrbJSVirtMin.setText(defaultOption.getOrbOtherIndVirtMin());
        txtOrbColCol.setText(defaultOption.getOrbCollColl());
        txtOrbColVirtMaj.setText(defaultOption.getOrbCollVirtMax());
        txtOrbColVirtMin.setText(defaultOption.getOrbCollVirtMin());
        txtOrbVirtMajVirtMaj.setText(defaultOption.getOrbVirtMaxVirtMax());
        txtOrbVirtMajVirtMin.setText(defaultOption.getOrbVirtMaxVirtMin());
        txtOrbvirtMinVirtMin.setText(defaultOption.getOrbVirtMinVirtMin());
        
        //orbs divisors
        txtDivConjunction.setText(defaultOption.getDivConjuntion());
        txtDivSextile.setText(defaultOption.getDivSextil());
        txtDivSquare.setText(defaultOption.getDivSquare());
        txtDivTrine.setText(defaultOption.getDivTrine());
        txtDivOpposition.setText(defaultOption.getDivOpposition());
        txtDivOther.setText(defaultOption.getDivMin());
        
        if (MainClass.dateType == MainClass.DATEFR)
            txtTransitsDate.setText(" ".concat(FDate.curFrFormDate()));
        else
            txtTransitsDate.setText(" ".concat(FDate.curUsFormDate()));
        
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle rect = ge.getMaximumWindowBounds();
        this.setLocation((int) ((rect.getWidth() - this.getWidth()) / 2), (int) ((rect.getHeight() - this.getHeight()) / 2));
        //this.setExtendedState(MAXIMIZED_BOTH);
        this.toFront();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private Color getColorTypeAspect(String typeAspect)
    {
        if (typeAspect == null || typeAspect.equals("")) return Color.BLACK;
        char ch = typeAspect.charAt(0);
        if ((ch == 'n') ||(ch == 'N')) return neutralColor;
        else if ((ch == 'd') ||(ch == 'D')) return dynamicColor;
        else if ((ch == 'h') ||(ch == 'H')) return harmonicColor;
        else return Color.BLACK;
    }
    
    
    public void setSelectedChartID(String sData)
    {
        selectedChartID = sData;
    }
    
    private void setChart(int chart)
    {
        switch (chart)
        {
            case ChartKind.normal: chkNormal.setSelected(true); break;
            case ChartKind.local: chkAstronomical.setSelected(true); pnlLocal.setVisible(true); break;
            case ChartKind.symbolicDir: chkSymbolicDir.setSelected(true); pnlSymbolicDir.setVisible(true); break;
            case ChartKind.primaryDir: chkPrimaryDir.setSelected(true); pnlPrimaryDir.setVisible(true); break;
            case ChartKind.secondaryDir: chkSecondaryDir.setSelected(true); pnlSecondaryDir.setVisible(true); break;
            case ChartKind.transit: chkTransits.setSelected(true); pnlTransits.setVisible(true); break;
            case ChartKind.revolution: chkRevolution.setSelected(true); pnlRevolution.setVisible(true); break;
            case ChartKind.cycle: chkCycle.setSelected(true); pnlCycle.setVisible(true); break;
            case ChartKind.synastry: chkSynastry.setSelected(true); pnlSynastry.setVisible(true); break;
            case ChartKind.composite: chkComposite.setSelected(true); pnlComposite.setVisible(true); break;
            case ChartKind.free: chkFree.setSelected(true); pnlFree.setVisible(true); break;
            case ChartKind.harmonic: chkHarmonic.setSelected(true); pnlHarmonic.setVisible(true); break;
            case ChartKind.seed: chkSeed.setSelected(true); break;
            case ChartKind.projective: chkProjective.setSelected(true); break;
            default: chkNormal.setSelected(true);
        }
    }
    
    public void setChoix(int choix)
    {
        choixAction = choix;
    }
    
    public int getChoix()
    {
        return choixAction;
    }
    
    private int getStepKindValue(String stepKind)
    {
        if(stepKind.equals(bundle.getString("year")))
        {
            return 0;
        }
        else if(stepKind.equals(bundle.getString("month")))
        {
            return 1;
        }
        else //if(stepKind.equals(bundle.getString("week")))
        {
            return 2;
        }
    }
    
    private ChartElements getOtherInfoFromHeader(String header, ChartElements chartElements)
    {
        int chartKind = chartElements.getChartKind();
        int pos1;
        int pos2;
        int pos3;
        int pos4;
        int pos5;
        final String strAge = bundle.getString("Age_");
        final String strCor = " " + bundle.getString("WithCorrespondance") + " ";
        final String strDeg = " " + bundle.getString("DegreeEquals") + " ";
        final String strDay = " " + bundle.getString("DayEquals") + " ";
        final String strPre = bundle.getString("Precessionned");
        final String strPla = bundle.getString("Place") + " :  ";
        
        switch(chartKind)
        {
            case ChartKind.symbolicDir:
                pos1 = header.indexOf(strAge);
                pos2 = header.indexOf(strCor);
                pos3 = header.indexOf(strDeg);
                pos4 = header.indexOf(" ", pos3 + strDeg.length());
                pos5 = header.indexOf("\r\n", pos4);
                if (pos5 < 0) pos5 = header.length();
                String sDirSAge = header.substring(pos1 + strAge.length(), pos2);
                chartElements.setDirSAge(new Double(sDirSAge).doubleValue());
                String sDirSCorresp = header.substring(pos2 + strDeg.length(), pos3);
                chartElements.setChartDirSCorresp(new Double(sDirSCorresp).doubleValue());
                String sDirSDegree = header.substring(pos3 + strCor.length(), pos4);
                chartElements.setChartDirSDegree(new Double(sDirSDegree).doubleValue());
                String sDirSSpaceKind = header.substring(pos4, pos5).trim();
                chartElements.setChartDirSSpaceKind(new Integer(getStepKindValue(sDirSSpaceKind)).intValue());
                break;
                
            case ChartKind.primaryDir:
                pos1 = header.indexOf(strAge);
                pos2 = header.indexOf(strCor);
                pos3 = header.indexOf(strDeg);
                pos4 = header.indexOf(" ", pos3 + strDeg.length());
                pos5 = header.indexOf("\r\n", pos4);
                if (pos5 < 0) pos5 = header.length();
                String sDir1Age = header.substring(pos1 + strAge.length(), pos2);
                chartElements.setDir1Age(new Double(sDir1Age).doubleValue());
                String sDir1Degree = header.substring(pos2 + strCor.length(), pos3);
                chartElements.setChartDir1Degree(new Double(sDir1Degree).doubleValue());
                String sDir1Corresp = header.substring(pos3 + strDeg.length(), pos4);
                chartElements.setChartDir1Corresp(new Double(sDir1Corresp).doubleValue());
                String sDir1SpaceKind = header.substring(pos4, pos5).trim();
                chartElements.setChartDir1SpaceKind(new Integer(getStepKindValue(sDir1SpaceKind)).intValue());
                break;
                
            case ChartKind.secondaryDir:
                pos1 = header.indexOf(strAge);
                pos2 = header.indexOf(strCor);
                pos3 = header.indexOf(strDay);
                pos4 = header.indexOf(" ", pos3 + strDeg.length());
                pos5 = header.indexOf("\r\n", pos4);
                if (pos5 < 0) pos5 = header.length();
                String sDir2Age = header.substring(pos1 + strAge.length(), pos2);
                chartElements.setDir2Age(new Double(sDir2Age).doubleValue());
                String sDir2Day = header.substring(pos2 + strCor.length(), pos3);
                chartElements.setChartDir2Day(new Double(sDir2Day).doubleValue());
                String sDir2Corresp = header.substring(pos3 + strDay.length(), pos4);
                chartElements.setChartDir2Corresp(new Double(sDir2Corresp).doubleValue());
                String sDir2SpaceKind = header.substring(pos4, pos5).trim();
                chartElements.setChartDir2SpaceKind(new Integer(getStepKindValue(sDir2SpaceKind)).intValue());
                break;
                
            case ChartKind.transit:
                pos1 = header.indexOf("Date :  ");
                pos2 = header.indexOf("\r\n", pos1);
                if (pos2 < 0) pos2 = header.length();
                String sDate = header.substring(pos1+8, pos2);
                chartElements.setTransitsDate(sDate);
                break;
                
            case ChartKind.harmonic:
                final String strHar = bundle.getString("Harmonic") + " ";
                pos1 = header.indexOf(ChartKind.getChartKindName(ChartKind.harmonic));
                pos1 = header.indexOf(strHar, pos1 + 1);
                pos2 = header.indexOf("\r\n", pos1);
                if (pos2 < 0) pos2 = header.length();
                String strHarmo = header.substring(pos1 + strHar.length(), pos2);
                chartElements.setChartHarmonicNB(new Integer(strHarmo).intValue());
                break;
                
            case ChartKind.revolution:
                pos1 = header.indexOf(strPre);
                if ( pos1 >= 0)
                {
                    chartElements.setChartReturnPrecess(true);
                }
                pos1 = header.indexOf("Age ");
                pos2 = header.indexOf(" = ", pos1);
                pos3 = header.indexOf("\r\n", pos2);
                pos4 = header.indexOf(strPla);
                pos5 = header.indexOf("\r\n", pos4);
                if (pos5 < 0) pos5 = header.length();
                String sRPlanetName = header.substring(pos1 + 4, pos2);
                int rPlanetNumber = Planets.getPlanetNumber(sRPlanetName, chartElements);
                chartElements.setChartReturnPlanet(rPlanetNumber);
                String chartRNB = header.substring(pos2 + 3, pos3);
                chartElements.setChartReturnNB(new Double(chartRNB).doubleValue());
                String chartRPlace = header.substring(pos4 + strPla.length(), pos5);
                chartElements.setChartReturnPlaceName(chartRPlace);
                break;
                
            case ChartKind.cycle:
                pos1 = header.indexOf("Age ");
                pos2 = header.indexOf(" - ", pos1);
                pos3 = header.indexOf(" = ", pos2);
                pos4 = header.indexOf("\r\n", pos3);
                pos5 = header.indexOf(strPla);
                int pos6 = header.indexOf("\r\n", pos5);
                if (pos6 < 0) pos6 = header.length();
                String sCPlanetName1 = header.substring(pos1 + 4, pos2);
                int cPlanetNumber = Planets.getPlanetNumber(sCPlanetName1, chartElements);
                chartElements.setChartCyclePlanet1(cPlanetNumber);
                String sCPlanetName2 = header.substring(pos2 + 3, pos3);
                cPlanetNumber = Planets.getPlanetNumber(sCPlanetName2, chartElements);
                chartElements.setChartCyclePlanet2(cPlanetNumber);
                String chartCNB = header.substring(pos3 + 3, pos4);
                chartElements.setChartCycleNB(new Double(chartCNB).doubleValue());
                String chartCPlace = header.substring(pos5 + strPla.length(), pos6);
                chartElements.setChartCyclePlaceName(chartCPlace);
                break;
                
            default: break;
        }
        return chartElements;
    }
    
    @SuppressWarnings("unchecked")
    private ChartElements readChart(Chart chart)
    {
        ChartElements chartElements = new ChartElements();
        String eventID = String.valueOf(chart.getEventID());
        event = starLoginManager.getEvent(eventID);
        ChartEvent chartEvent0 = new ChartEvent(event);
        String strHeader = chart.getHeader();
        chartEvent0.setHeader(strHeader);
        chartElements.setChartHeader(strHeader);
        ArrayList chartEvents = new ArrayList();
        chartEvents.add(chartEvent0);
        
        chartElements.setChartEvents(chartEvents);
        chartElements.setChartKind((int)chart.getChartType());
        chartElements.setCoordSys((int)chart.getCoordinatesSystem());
        chartElements.setHouseSys((int)chart.getHousesSystem());
        chartElements.setOtherPointName(chart.getOtherPointName());
        chartElements.setOtherPointType(chart.getOtherPointType());
        chartElements.setPlanetaryConfigurations(chart.getConfigurations());
        chartElements = getOtherInfoFromHeader(strHeader, chartElements);
        updateChartElements(chartElements);
        
        ArrayList allCoords = new ArrayList();
        ChartPositions chartPositions = starLoginManager.getChartPositions(chart.getId());
        ArrayList planets = chartPositions.getRecords();
        if (planets == null || planets.isEmpty()) return null;
        
        AllCoord allCoord = new AllCoord();
        for (int i = 0; i < Planets.getLast(); i++)
        {
            ArrayList planet = (ArrayList)planets.get(i);
            Coord planetCoord = new Coord();
            planetCoord.setHelioLat(new Double(planet.get(0).toString()).doubleValue());
            planetCoord.setTropicHelioLong(new Double(planet.get(1).toString()).doubleValue());
            planetCoord.setSiderHelioLong(new Double(planet.get(2).toString()).doubleValue());
            planetCoord.setHelioDist(new Double(planet.get(3).toString()).doubleValue());
            planetCoord.setGeoLat(new Double(planet.get(4).toString()).doubleValue());
            planetCoord.setTropicGeoLong(new Double(planet.get(5).toString()).doubleValue());
            planetCoord.setSiderHelioLong(new Double(planet.get(6).toString()).doubleValue());
            planetCoord.setGeoDist(new Double(planet.get(7).toString()).doubleValue());
            planetCoord.setRA(new Double(planet.get(8).toString()).doubleValue());
            planetCoord.setDecl(new Double(planet.get(9).toString()).doubleValue());
            planetCoord.setAz(new Double(planet.get(10).toString()).doubleValue());
            planetCoord.setAlt(new Double(planet.get(11).toString()).doubleValue());
            allCoord.set(planetCoord, i);
        }
        
        //add an empty ArrayList for the barycenter (last element - not saved)
        allCoords.add(allCoord);
        
        //second chart
        if (planets.size()>Planets.getLast())
        {
            allCoord = new AllCoord();
            for (int i = Planets.getLast(); i < Planets.getLast() * 2 - 2; i++)
            {
                ArrayList planet = (ArrayList)planets.get(i);
                Coord planetCoord = new Coord();
                planetCoord.setHelioLat(new Double(planet.get(0).toString()).doubleValue());
                planetCoord.setTropicHelioLong(new Double(planet.get(1).toString()).doubleValue());
                planetCoord.setSiderHelioLong(new Double(planet.get(2).toString()).doubleValue());
                planetCoord.setHelioDist(new Double(planet.get(3).toString()).doubleValue());
                planetCoord.setGeoLat(new Double(planet.get(4).toString()).doubleValue());
                planetCoord.setTropicGeoLong(new Double(planet.get(5).toString()).doubleValue());
                planetCoord.setSiderHelioLong(new Double(planet.get(6).toString()).doubleValue());
                planetCoord.setGeoDist(new Double(planet.get(7).toString()).doubleValue());
                planetCoord.setRA(new Double(planet.get(8).toString()).doubleValue());
                planetCoord.setDecl(new Double(planet.get(9).toString()).doubleValue());
                planetCoord.setAz(new Double(planet.get(10).toString()).doubleValue());
                planetCoord.setAlt(new Double(planet.get(11).toString()).doubleValue());
                allCoord.set(planetCoord, i - Planets.getLast());
            }
            
            //add an empty ArrayList for the barycenter (last element - not saved)
            allCoords.add(allCoord);
            chartEvents.add(chartEvent0.cloneEvent());
        }
        chartElements.setChartCoords(allCoords);
        
        return chartElements;
    }
    
    private String getPlanetID(JComboBox planet)
    {
        String planetName = planet.getSelectedItem().toString();
        for (byte i=0; i<Planets.getLast(); i++)
        {
            String strName = Planets.getPlanetName(i);
            if (strName.equals(planetName))
            {
                return String.valueOf(i);
            }
        }
        return "-1";
    }
    
    private String getPlaceID(Places allPlaces, String placeName)
    {
        ArrayList p = allPlaces.getRecords();
        for (int i=0; i<p.size() ; i++)
        {
            ArrayList v = (ArrayList)p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1));
            if (strName.equals(placeName))
            {
                return strID;
            }
        }
        return "-1";
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpChartChoice = new javax.swing.ButtonGroup();
        grpSavedCharts = new javax.swing.ButtonGroup();
        grpGeoHelio = new javax.swing.ButtonGroup();
        grpGeo = new javax.swing.ButtonGroup();
        grpHelio = new javax.swing.ButtonGroup();
        grpHouseSystem = new javax.swing.ButtonGroup();
        grpAstronView = new javax.swing.ButtonGroup();
        grpBarycenter = new javax.swing.ButtonGroup();
        grpZodDir = new javax.swing.ButtonGroup();
        grpColorMode = new javax.swing.ButtonGroup();
        grpOtherPoint = new javax.swing.ButtonGroup();
        grpSynastrySelect = new javax.swing.ButtonGroup();
        grpCompositeSelect = new javax.swing.ButtonGroup();
        grpCompositeFrom = new javax.swing.ButtonGroup();
        tabSettings = new javax.swing.JTabbedPane();
        pnlChartKind = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jOptSingleSelection = new javax.swing.JRadioButton();
        jOptMultiSelection = new javax.swing.JRadioButton();
        btnSelectAll = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        chkNormal = new javax.swing.JCheckBox();
        jPanel29 = new javax.swing.JPanel();
        chkAstronomical = new javax.swing.JCheckBox();
        pnlLocal = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        optHorizon = new javax.swing.JRadioButton();
        optZenith = new javax.swing.JRadioButton();
        jPanel33 = new javax.swing.JPanel();
        chkSymbolicDir = new javax.swing.JCheckBox();
        pnlSymbolicDir = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtDirSAge = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtCorrespondDS = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtEqualsDS = new javax.swing.JTextField();
        cboDS = new javax.swing.JComboBox();
        jPanel35 = new javax.swing.JPanel();
        chkPrimaryDir = new javax.swing.JCheckBox();
        pnlPrimaryDir = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtDir1Age = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtCorrespondD1 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtEqualsD1 = new javax.swing.JTextField();
        cboD1 = new javax.swing.JComboBox();
        jPanel37 = new javax.swing.JPanel();
        chkSecondaryDir = new javax.swing.JCheckBox();
        pnlSecondaryDir = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtDir2Age = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtCorrespondD2 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtEqualsD2 = new javax.swing.JTextField();
        cboD2 = new javax.swing.JComboBox();
        jPanel39 = new javax.swing.JPanel();
        chkTransits = new javax.swing.JCheckBox();
        pnlTransits = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTransitsDate = new javax.swing.JTextField();
        jPanel41 = new javax.swing.JPanel();
        chkRevolution = new javax.swing.JCheckBox();
        pnlRevolution = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        chkPrecession = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        txtRevolNB = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        cboPlanetReturn = new javax.swing.JComboBox();
        jPanel61 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        txtPlaceReturn = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtLatitudeReturn = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtLongitudeReturn = new javax.swing.JTextField();
        jPanel43 = new javax.swing.JPanel();
        chkCycle = new javax.swing.JCheckBox();
        pnlCycle = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtCyclesNB = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        cboPlanet1Cycle = new javax.swing.JComboBox();
        jLabel27 = new javax.swing.JLabel();
        cboPlanet2Cycle = new javax.swing.JComboBox();
        jPanel66 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        txtPlaceCycle = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtLatitudeCycle = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txtLongitudeCycle = new javax.swing.JTextField();
        jPanel45 = new javax.swing.JPanel();
        chkSynastry = new javax.swing.JCheckBox();
        pnlSynastry = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lblRemainEventSynastry = new javax.swing.JLabel();
        optSynastryChartSelect = new javax.swing.JRadioButton();
        optSynastryEventSelect = new javax.swing.JRadioButton();
        btnOKEventSelectSysnastry = new javax.swing.JButton();
        jPanel47 = new javax.swing.JPanel();
        chkComposite = new javax.swing.JCheckBox();
        pnlComposite = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtCompositeChartsNB = new javax.swing.JTextField();
        lblFrom = new javax.swing.JLabel();
        optCompositeFromAS = new javax.swing.JRadioButton();
        optCompositeFromMC = new javax.swing.JRadioButton();
        jLabel28 = new javax.swing.JLabel();
        lblRemainEventComposite = new javax.swing.JLabel();
        optCompositeChartSelect = new javax.swing.JRadioButton();
        optCompositeEventSelect = new javax.swing.JRadioButton();
        btnOKEventSelectComposite = new javax.swing.JButton();
        jPanel49 = new javax.swing.JPanel();
        chkFree = new javax.swing.JCheckBox();
        pnlFree = new javax.swing.JPanel();
        btnEditFree = new javax.swing.JButton();
        jPanel53 = new javax.swing.JPanel();
        chkHarmonic = new javax.swing.JCheckBox();
        pnlHarmonic = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtHarmonicNB = new javax.swing.JTextField();
        jPanel31 = new javax.swing.JPanel();
        chkSeed = new javax.swing.JCheckBox();
        jPanel55 = new javax.swing.JPanel();
        chkProjective = new javax.swing.JCheckBox();
        pnlCoordSystem = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        chkGeocentric = new javax.swing.JRadioButton();
        chkHeliocentric = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        chkTropical = new javax.swing.JRadioButton();
        chkSidereal = new javax.swing.JRadioButton();
        chkEquatorial = new javax.swing.JRadioButton();
        chkEcliptic = new javax.swing.JRadioButton();
        chkLocal = new javax.swing.JRadioButton();
        chkDomitudes = new javax.swing.JRadioButton();
        chkHeliocentricNormal = new javax.swing.JRadioButton();
        chkHeliocentricSidereal = new javax.swing.JRadioButton();
        pnlHouseSystem = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        optAncient = new javax.swing.JRadioButton();
        optTwoHours = new javax.swing.JRadioButton();
        optSemiAngular = new javax.swing.JRadioButton();
        optCampanus = new javax.swing.JRadioButton();
        optEquatorialRegular = new javax.swing.JRadioButton();
        optColinEvans = new javax.swing.JRadioButton();
        optBazchenoff = new javax.swing.JRadioButton();
        optMaternusAs = new javax.swing.JRadioButton();
        optMaternusMC = new javax.swing.JRadioButton();
        optNodal = new javax.swing.JRadioButton();
        optPorpyre = new javax.swing.JRadioButton();
        optRegiomontanus = new javax.swing.JRadioButton();
        optSolar = new javax.swing.JRadioButton();
        optWiesel = new javax.swing.JRadioButton();
        optZenithal = new javax.swing.JRadioButton();
        optZodiacal = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        optAbenragel = new javax.swing.JRadioButton();
        optAlbategnius = new javax.swing.JRadioButton();
        optAlcabitius = new javax.swing.JRadioButton();
        optKoch = new javax.swing.JRadioButton();
        optPlacidus = new javax.swing.JRadioButton();
        pnlChartLook = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        lblColorSun = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        lblColorMoon = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        lblColorMercury = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        lblColorVenus = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        lblColorMars = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        lblColorJupiter = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        lblColorSaturn = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        lblColorUranus = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        lblColorNeptune = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        lblColorPluto = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        lblColorGaia = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        lblColorNodes = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        lblColorHouses = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        lblColorAsteroids = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        lblColorVulcan = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        lblColorText = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        lblColorFire = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        lblColorEarth = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        lblColorAir = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        lblColorWater = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        lblColorNeutral = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        lblColorDynamic = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        lblColorHarmonic = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        sldZodiac = new javax.swing.JSlider();
        lblZodiacSize = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        sldSigns = new javax.swing.JSlider();
        lblSignSize = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        sldPlanets = new javax.swing.JSlider();
        lblPlanetSize = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        sldCharacters = new javax.swing.JSlider();
        lblCharactersSize = new javax.swing.JLabel();
        pnlChartColorChoice = new javax.swing.JPanel();
        pnlPlanets = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        chkSun = new javax.swing.JCheckBox();
        chkMoon = new javax.swing.JCheckBox();
        chkMercury = new javax.swing.JCheckBox();
        chkVenus = new javax.swing.JCheckBox();
        chkMars = new javax.swing.JCheckBox();
        chkJupiter = new javax.swing.JCheckBox();
        chkSaturn = new javax.swing.JCheckBox();
        chkUranus = new javax.swing.JCheckBox();
        chkNeptune = new javax.swing.JCheckBox();
        chkPluto = new javax.swing.JCheckBox();
        jPanel50 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        chkGaia = new javax.swing.JCheckBox();
        chkNN = new javax.swing.JCheckBox();
        jPanel56 = new javax.swing.JPanel();
        chkLilith = new javax.swing.JCheckBox();
        chkTrueLilith = new javax.swing.JCheckBox();
        chkEast = new javax.swing.JCheckBox();
        chkZenith = new javax.swing.JCheckBox();
        chkVertex = new javax.swing.JCheckBox();
        chkVulcan = new javax.swing.JCheckBox();
        chkCeres = new javax.swing.JCheckBox();
        chkPallas = new javax.swing.JCheckBox();
        chkJuno = new javax.swing.JCheckBox();
        chkVesta = new javax.swing.JCheckBox();
        chkChiron = new javax.swing.JCheckBox();
        chkOtherPoint = new javax.swing.JCheckBox();
        pnlOtherPoint = new javax.swing.JPanel();
        jLabel125 = new javax.swing.JLabel();
        optOtherPtStar = new javax.swing.JRadioButton();
        pnlOtherPtStar = new javax.swing.JPanel();
        lblStarName = new javax.swing.JLabel();
        cboStarIdentity = new javax.swing.JComboBox();
        optOtherPtPart = new javax.swing.JRadioButton();
        pnlOtherPtPart = new javax.swing.JPanel();
        cboPart = new javax.swing.JComboBox();
        jLabel126 = new javax.swing.JLabel();
        cboPartRef = new javax.swing.JComboBox();
        jLabel127 = new javax.swing.JLabel();
        cboPartPlus = new javax.swing.JComboBox();
        jLabel128 = new javax.swing.JLabel();
        cboPartMinus = new javax.swing.JComboBox();
        optOtherPtComet = new javax.swing.JRadioButton();
        cboComet = new javax.swing.JComboBox();
        optOtherPtAsteroid = new javax.swing.JRadioButton();
        cboAsteroid = new javax.swing.JComboBox();
        optOtherPtNone = new javax.swing.JRadioButton();
        jPanel52 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        chkStars = new javax.swing.JCheckBox();
        sldStars = new javax.swing.JSlider();
        jLabel50 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        chkConstellations = new javax.swing.JCheckBox();
        chkAsteroids = new javax.swing.JCheckBox();
        chkHouses = new javax.swing.JCheckBox();
        chkAspects = new javax.swing.JCheckBox();
        chkCoordinates = new javax.swing.JCheckBox();
        chkStraightLines = new javax.swing.JCheckBox();
        chkShaded = new javax.swing.JCheckBox();
        jPanel62 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        chkBarycenter = new javax.swing.JCheckBox();
        optSingleWeight = new javax.swing.JRadioButton();
        optDifferentWeights = new javax.swing.JRadioButton();
        jPanel63 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        optEastAS = new javax.swing.JRadioButton();
        optEastAries = new javax.swing.JRadioButton();
        chkAspectsSymbol = new javax.swing.JCheckBox();
        chkSignsName = new javax.swing.JCheckBox();
        chkHousesCoord = new javax.swing.JCheckBox();
        pnlAspects = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jPanel90 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jPanel71 = new javax.swing.JPanel();
        jPanel51 = new javax.swing.JPanel();
        lblAspectsColorMode = new javax.swing.JLabel();
        optColorMode1 = new javax.swing.JRadioButton();
        optColorMode2 = new javax.swing.JRadioButton();
        jPanel72 = new javax.swing.JPanel();
        chkConjunction = new javax.swing.JCheckBox();
        txtConjunction = new javax.swing.JTextField();
        lblColorConjunction = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jPanel73 = new javax.swing.JPanel();
        chkSextile = new javax.swing.JCheckBox();
        txtSextile = new javax.swing.JTextField();
        lblColorSextile = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        chkSquare = new javax.swing.JCheckBox();
        txtSquare = new javax.swing.JTextField();
        lblColorSquare = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jPanel75 = new javax.swing.JPanel();
        chkTrine = new javax.swing.JCheckBox();
        txtTrine = new javax.swing.JTextField();
        lblColorTrine = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jPanel76 = new javax.swing.JPanel();
        chkOpposition = new javax.swing.JCheckBox();
        txtOpposition = new javax.swing.JTextField();
        lblColorOpposition = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jPanel77 = new javax.swing.JPanel();
        chkVigintile = new javax.swing.JCheckBox();
        txtVigintile = new javax.swing.JTextField();
        lblColorVigintile = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        chkSemiSextile = new javax.swing.JCheckBox();
        txtSemiSextile = new javax.swing.JTextField();
        lblColorSemiSextile = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jPanel79 = new javax.swing.JPanel();
        chkSemiQuintile = new javax.swing.JCheckBox();
        txtSemiQuintile = new javax.swing.JTextField();
        lblColorSemiQuintile = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        chkNonagon = new javax.swing.JCheckBox();
        txtNonagone = new javax.swing.JTextField();
        lblColorNonagon = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jPanel81 = new javax.swing.JPanel();
        chkSemiSquare = new javax.swing.JCheckBox();
        txtSemiSquare = new javax.swing.JTextField();
        lblColorSemiSquare = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jPanel82 = new javax.swing.JPanel();
        chkSeptile = new javax.swing.JCheckBox();
        txtSeptile = new javax.swing.JTextField();
        lblColorSeptile = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        chkQuintile = new javax.swing.JCheckBox();
        txtQuintile = new javax.swing.JTextField();
        lblColorQuintile = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        chkTriDectile = new javax.swing.JCheckBox();
        txtTriDectile = new javax.swing.JTextField();
        lblColorTridectile = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jPanel85 = new javax.swing.JPanel();
        chkSesquiSquare = new javax.swing.JCheckBox();
        txtSesquiSquare = new javax.swing.JTextField();
        lblColorSesquiSquare = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        chkBiQuintile = new javax.swing.JCheckBox();
        txtBiquintile = new javax.swing.JTextField();
        lblColorBiQuintile = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        chkInconjunct = new javax.swing.JCheckBox();
        txtInconjunct = new javax.swing.JTextField();
        lblColorInconjunct = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        chkQuadriNonagon = new javax.swing.JCheckBox();
        txtQuadriNonagon = new javax.swing.JTextField();
        lblColorQuadriNonagon = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jPanel89 = new javax.swing.JPanel();
        chkOtherAspect = new javax.swing.JCheckBox();
        txtOtherAspect = new javax.swing.JTextField();
        lblColorOtherAspect = new javax.swing.JLabel();
        txtValueOtherAspect = new javax.swing.JTextField();
        jLabel118 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        txtOtherAspectName = new javax.swing.JTextField();
        pnlAspectColorChoice = new javax.swing.JPanel();
        jPanel94 = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        chkAspectSun = new javax.swing.JCheckBox();
        chkAspectMoon = new javax.swing.JCheckBox();
        chkAspectMercury = new javax.swing.JCheckBox();
        chkAspectVenus = new javax.swing.JCheckBox();
        chkAspectMars = new javax.swing.JCheckBox();
        chkAspectJupiter = new javax.swing.JCheckBox();
        chkAspectSaturn = new javax.swing.JCheckBox();
        chkAspectUranus = new javax.swing.JCheckBox();
        chkAspectNeptune = new javax.swing.JCheckBox();
        chkAspectPluto = new javax.swing.JCheckBox();
        chkAspectGaia = new javax.swing.JCheckBox();
        chkAspectNodes = new javax.swing.JCheckBox();
        chkAspectLilith = new javax.swing.JCheckBox();
        chkAspectEast = new javax.swing.JCheckBox();
        chkAspectZenith = new javax.swing.JCheckBox();
        chkAspectVertex = new javax.swing.JCheckBox();
        chkAspectVulcan = new javax.swing.JCheckBox();
        chkAspectCeres = new javax.swing.JCheckBox();
        chkAspectPallas = new javax.swing.JCheckBox();
        chkAspectJuno = new javax.swing.JCheckBox();
        chkAspectVesta = new javax.swing.JCheckBox();
        chkAspectChiron = new javax.swing.JCheckBox();
        chkAspectAS = new javax.swing.JCheckBox();
        chkAspectMC = new javax.swing.JCheckBox();
        chkAspectOtherPoint = new javax.swing.JCheckBox();
        pnlOrbs = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jPanel98 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jPanel99 = new javax.swing.JPanel();
        jLabel70 = new javax.swing.JLabel();
        jPanel100 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jPanel101 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jPanel102 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jPanel103 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        jPanel104 = new javax.swing.JPanel();
        txtOrbLumLum = new javax.swing.JTextField();
        jPanel105 = new javax.swing.JPanel();
        txtOrbLumIndiv = new javax.swing.JTextField();
        jPanel106 = new javax.swing.JPanel();
        txtOrbLumJS = new javax.swing.JTextField();
        jPanel107 = new javax.swing.JPanel();
        txtOrbLumCol = new javax.swing.JTextField();
        jPanel108 = new javax.swing.JPanel();
        txtOrbLumVirtMaj = new javax.swing.JTextField();
        jPanel109 = new javax.swing.JPanel();
        txtOrbLumVirtMin = new javax.swing.JTextField();
        jPanel110 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jPanel111 = new javax.swing.JPanel();
        jPanel113 = new javax.swing.JPanel();
        txtOrbIndivIndiv = new javax.swing.JTextField();
        jPanel114 = new javax.swing.JPanel();
        txtOrbIndivJS = new javax.swing.JTextField();
        jPanel115 = new javax.swing.JPanel();
        txtOrbIndivCol = new javax.swing.JTextField();
        jPanel116 = new javax.swing.JPanel();
        txtOrbIndivVirtMaj = new javax.swing.JTextField();
        jPanel117 = new javax.swing.JPanel();
        txtOrbIndivVirtMin = new javax.swing.JTextField();
        jPanel118 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jPanel119 = new javax.swing.JPanel();
        jPanel120 = new javax.swing.JPanel();
        jPanel121 = new javax.swing.JPanel();
        txtOrbJSJS = new javax.swing.JTextField();
        jPanel122 = new javax.swing.JPanel();
        txtOrbJSCol = new javax.swing.JTextField();
        jPanel123 = new javax.swing.JPanel();
        txtOrbJSvirtMaj = new javax.swing.JTextField();
        jPanel124 = new javax.swing.JPanel();
        txtOrbJSVirtMin = new javax.swing.JTextField();
        jPanel125 = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jPanel126 = new javax.swing.JPanel();
        jPanel127 = new javax.swing.JPanel();
        jPanel128 = new javax.swing.JPanel();
        jPanel129 = new javax.swing.JPanel();
        txtOrbColCol = new javax.swing.JTextField();
        jPanel130 = new javax.swing.JPanel();
        txtOrbColVirtMaj = new javax.swing.JTextField();
        jPanel131 = new javax.swing.JPanel();
        txtOrbColVirtMin = new javax.swing.JTextField();
        jPanel132 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jPanel133 = new javax.swing.JPanel();
        jPanel134 = new javax.swing.JPanel();
        jPanel135 = new javax.swing.JPanel();
        jPanel136 = new javax.swing.JPanel();
        jPanel137 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMaj = new javax.swing.JTextField();
        jPanel138 = new javax.swing.JPanel();
        txtOrbVirtMajVirtMin = new javax.swing.JTextField();
        jPanel139 = new javax.swing.JPanel();
        jLabel98 = new javax.swing.JLabel();
        jPanel140 = new javax.swing.JPanel();
        jPanel141 = new javax.swing.JPanel();
        jPanel142 = new javax.swing.JPanel();
        jPanel143 = new javax.swing.JPanel();
        jPanel144 = new javax.swing.JPanel();
        jPanel112 = new javax.swing.JPanel();
        txtOrbvirtMinVirtMin = new javax.swing.JTextField();
        jPanel95 = new javax.swing.JPanel();
        jPanel145 = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        jPanel146 = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        jPanel147 = new javax.swing.JPanel();
        jLabel107 = new javax.swing.JLabel();
        jPanel148 = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        jPanel149 = new javax.swing.JPanel();
        jLabel113 = new javax.swing.JLabel();
        jPanel150 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        jPanel151 = new javax.swing.JPanel();
        jLabel117 = new javax.swing.JLabel();
        txtDivConjunction = new javax.swing.JTextField();
        jPanel152 = new javax.swing.JPanel();
        jLabel120 = new javax.swing.JLabel();
        txtDivSextile = new javax.swing.JTextField();
        jPanel153 = new javax.swing.JPanel();
        jLabel121 = new javax.swing.JLabel();
        txtDivSquare = new javax.swing.JTextField();
        jPanel154 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        txtDivTrine = new javax.swing.JTextField();
        jPanel155 = new javax.swing.JPanel();
        jLabel123 = new javax.swing.JLabel();
        txtDivOpposition = new javax.swing.JTextField();
        jPanel156 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        txtDivOther = new javax.swing.JTextField();
        pnl2 = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        btnDisplayCharts = new javax.swing.JButton();
        lblForEvent = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        btnReadChart = new javax.swing.JButton();
        pnl1 = new javax.swing.JPanel();
        optLastSavedChart = new javax.swing.JRadioButton();
        optSavedChart = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        tabSettings.setPreferredSize(new java.awt.Dimension(1020, 640));

        pnlChartKind.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlChartKind.setPreferredSize(new java.awt.Dimension(988, 554));
        pnlChartKind.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        jPanel1.setPreferredSize(new java.awt.Dimension(994, 35));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 5));

        grpChartChoice.add(jOptSingleSelection);
        jOptSingleSelection.setSelected(true);
        jOptSingleSelection.setPreferredSize(new java.awt.Dimension(220, 24));
        jOptSingleSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOptSingleSelectionActionPerformed(evt);
            }
        });
        jPanel1.add(jOptSingleSelection);

        grpChartChoice.add(jOptMultiSelection);
        jOptMultiSelection.setMaximumSize(new java.awt.Dimension(197, 24));
        jOptMultiSelection.setMinimumSize(new java.awt.Dimension(197, 24));
        jOptMultiSelection.setPreferredSize(new java.awt.Dimension(250, 24));
        jOptMultiSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOptMultiSelectionActionPerformed(evt);
            }
        });
        jPanel1.add(jOptMultiSelection);

        btnSelectAll.setPreferredSize(new java.awt.Dimension(280, 24));
        btnSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectAllActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectAll);

        pnlChartKind.add(jPanel1);

        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel12.setPreferredSize(new java.awt.Dimension(994, 554));
        jPanel12.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel13.setLayout(new java.awt.BorderLayout());

        chkNormal.setSelected(true);
        chkNormal.setPreferredSize(new java.awt.Dimension(215, 31));
        chkNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkNormalActionPerformed(evt);
            }
        });
        jPanel13.add(chkNormal, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel13);

        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel29.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel29.setLayout(new java.awt.BorderLayout());

        chkAstronomical.setMaximumSize(new java.awt.Dimension(175, 31));
        chkAstronomical.setMinimumSize(new java.awt.Dimension(175, 31));
        chkAstronomical.setPreferredSize(new java.awt.Dimension(215, 31));
        chkAstronomical.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAstronomicalActionPerformed(evt);
            }
        });
        jPanel29.add(chkAstronomical, java.awt.BorderLayout.WEST);

        pnlLocal.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel36.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel36.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel36.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel36.setOpaque(true);
        jLabel36.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlLocal.add(jLabel36);

        grpAstronView.add(optHorizon);
        pnlLocal.add(optHorizon);

        grpAstronView.add(optZenith);
        optZenith.setSelected(true);
        pnlLocal.add(optZenith);

        jPanel29.add(pnlLocal, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel29);

        jPanel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel33.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel33.setLayout(new java.awt.BorderLayout());

        chkSymbolicDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSymbolicDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSymbolicDirActionPerformed(evt);
            }
        });
        jPanel33.add(chkSymbolicDir, java.awt.BorderLayout.WEST);

        pnlSymbolicDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel4.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel4.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel4.setOpaque(true);
        jLabel4.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlSymbolicDir.add(jLabel4);

        txtDirSAge.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDirSAge.setText("1");
        txtDirSAge.setPreferredSize(new java.awt.Dimension(50, 22));
        txtDirSAge.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDirSAgeFocusLost(evt);
            }
        });
        txtDirSAge.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDirSAgekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDirSAgeKeyPressed(evt);
            }
        });
        pnlSymbolicDir.add(txtDirSAge);

        jLabel16.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel16.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel16.setMaximumSize(new java.awt.Dimension(200, 18));
        jLabel16.setMinimumSize(new java.awt.Dimension(200, 18));
        jLabel16.setOpaque(true);
        jLabel16.setPreferredSize(new java.awt.Dimension(200, 22));
        pnlSymbolicDir.add(jLabel16);

        txtCorrespondDS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondDS.setText("1");
        txtCorrespondDS.setPreferredSize(new java.awt.Dimension(50, 22));
        txtCorrespondDS.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCorrespondDSFocusLost(evt);
            }
        });
        txtCorrespondDS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCorrespondDSkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCorrespondDSKeyPressed(evt);
            }
        });
        pnlSymbolicDir.add(txtCorrespondDS);

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel17.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel17.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel17.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel17.setOpaque(true);
        jLabel17.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlSymbolicDir.add(jLabel17);

        txtEqualsDS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsDS.setText("1");
        txtEqualsDS.setPreferredSize(new java.awt.Dimension(50, 22));
        txtEqualsDS.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtEqualsDSFocusLost(evt);
            }
        });
        txtEqualsDS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEqualsDSkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEqualsDSKeyPressed(evt);
            }
        });
        pnlSymbolicDir.add(txtEqualsDS);

        cboDS.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlSymbolicDir.add(cboDS);

        jPanel33.add(pnlSymbolicDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel33);

        jPanel35.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel35.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel35.setLayout(new java.awt.BorderLayout());

        chkPrimaryDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkPrimaryDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPrimaryDirActionPerformed(evt);
            }
        });
        jPanel35.add(chkPrimaryDir, java.awt.BorderLayout.WEST);

        pnlPrimaryDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel3.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel3.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel3.setOpaque(true);
        jLabel3.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlPrimaryDir.add(jLabel3);

        txtDir1Age.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDir1Age.setText("1");
        txtDir1Age.setPreferredSize(new java.awt.Dimension(50, 22));
        txtDir1Age.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDir1AgeFocusLost(evt);
            }
        });
        txtDir1Age.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDir1AgekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDir1AgeKeyPressed(evt);
            }
        });
        pnlPrimaryDir.add(txtDir1Age);

        jLabel14.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel14.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel14.setMaximumSize(new java.awt.Dimension(200, 18));
        jLabel14.setMinimumSize(new java.awt.Dimension(200, 18));
        jLabel14.setOpaque(true);
        jLabel14.setPreferredSize(new java.awt.Dimension(200, 22));
        pnlPrimaryDir.add(jLabel14);

        txtCorrespondD1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondD1.setText("1");
        txtCorrespondD1.setPreferredSize(new java.awt.Dimension(50, 22));
        txtCorrespondD1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCorrespondD1FocusLost(evt);
            }
        });
        txtCorrespondD1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCorrespondD1keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCorrespondD1KeyPressed(evt);
            }
        });
        pnlPrimaryDir.add(txtCorrespondD1);

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel15.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel15.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel15.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel15.setOpaque(true);
        jLabel15.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlPrimaryDir.add(jLabel15);

        txtEqualsD1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsD1.setText("1");
        txtEqualsD1.setPreferredSize(new java.awt.Dimension(50, 22));
        txtEqualsD1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtEqualsD1FocusLost(evt);
            }
        });
        txtEqualsD1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEqualsD1keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEqualsD1KeyPressed(evt);
            }
        });
        pnlPrimaryDir.add(txtEqualsD1);

        cboD1.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlPrimaryDir.add(cboD1);

        jPanel35.add(pnlPrimaryDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel35);

        jPanel37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel37.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel37.setLayout(new java.awt.BorderLayout());

        chkSecondaryDir.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSecondaryDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSecondaryDirActionPerformed(evt);
            }
        });
        jPanel37.add(chkSecondaryDir, java.awt.BorderLayout.WEST);

        pnlSecondaryDir.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel2.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel2.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel2.setOpaque(true);
        jLabel2.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlSecondaryDir.add(jLabel2);

        txtDir2Age.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDir2Age.setText("1");
        txtDir2Age.setPreferredSize(new java.awt.Dimension(50, 22));
        txtDir2Age.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDir2AgeFocusLost(evt);
            }
        });
        txtDir2Age.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDir2AgekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDir2AgeKeyPressed(evt);
            }
        });
        pnlSecondaryDir.add(txtDir2Age);

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel10.setMaximumSize(new java.awt.Dimension(200, 18));
        jLabel10.setMinimumSize(new java.awt.Dimension(200, 18));
        jLabel10.setOpaque(true);
        jLabel10.setPreferredSize(new java.awt.Dimension(200, 22));
        pnlSecondaryDir.add(jLabel10);

        txtCorrespondD2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCorrespondD2.setText("1");
        txtCorrespondD2.setPreferredSize(new java.awt.Dimension(50, 22));
        txtCorrespondD2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCorrespondD2FocusLost(evt);
            }
        });
        txtCorrespondD2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCorrespondD2keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCorrespondD2KeyPressed(evt);
            }
        });
        pnlSecondaryDir.add(txtCorrespondD2);

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel12.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel12.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel12.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel12.setOpaque(true);
        jLabel12.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlSecondaryDir.add(jLabel12);

        txtEqualsD2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtEqualsD2.setText("1");
        txtEqualsD2.setPreferredSize(new java.awt.Dimension(50, 22));
        txtEqualsD2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtEqualsD2FocusLost(evt);
            }
        });
        txtEqualsD2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEqualsD2keyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEqualsD2KeyPressed(evt);
            }
        });
        pnlSecondaryDir.add(txtEqualsD2);

        cboD2.setPreferredSize(new java.awt.Dimension(100, 25));
        pnlSecondaryDir.add(cboD2);

        jPanel37.add(pnlSecondaryDir, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel37);

        jPanel39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel39.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel39.setLayout(new java.awt.BorderLayout());

        chkTransits.setPreferredSize(new java.awt.Dimension(215, 31));
        chkTransits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTransitsActionPerformed(evt);
            }
        });
        jPanel39.add(chkTransits, java.awt.BorderLayout.WEST);

        pnlTransits.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel1.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel1.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel1.setOpaque(true);
        jLabel1.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlTransits.add(jLabel1);

        txtTransitsDate.setPreferredSize(new java.awt.Dimension(100, 22));
        txtTransitsDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTransitsDateFocusLost(evt);
            }
        });
        txtTransitsDate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTransitsDatekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTransitsDateKeyPressed(evt);
            }
        });
        pnlTransits.add(txtTransitsDate);

        jPanel39.add(pnlTransits, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel39);

        jPanel41.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel41.setPreferredSize(new java.awt.Dimension(990, 65));
        jPanel41.setLayout(new java.awt.BorderLayout());

        chkRevolution.setPreferredSize(new java.awt.Dimension(215, 60));
        chkRevolution.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkRevolutionActionPerformed(evt);
            }
        });
        jPanel41.add(chkRevolution, java.awt.BorderLayout.WEST);

        pnlRevolution.setMinimumSize(new java.awt.Dimension(654, 31));
        pnlRevolution.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jPanel60.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        jPanel60.add(chkPrecession);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel5.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel5.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel5.setOpaque(true);
        jLabel5.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel60.add(jLabel5);

        txtRevolNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtRevolNB.setText("1");
        txtRevolNB.setPreferredSize(new java.awt.Dimension(50, 22));
        txtRevolNB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRevolNBkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtRevolNBKeyPressed(evt);
            }
        });
        jPanel60.add(txtRevolNB);

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel21.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel21.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel21.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel21.setOpaque(true);
        jLabel21.setPreferredSize(new java.awt.Dimension(80, 22));
        jPanel60.add(jLabel21);

        cboPlanetReturn.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel60.add(cboPlanetReturn);

        pnlRevolution.add(jPanel60);

        jPanel61.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel18.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel18.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel18.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel18.setOpaque(true);
        jLabel18.setPreferredSize(new java.awt.Dimension(80, 22));
        jPanel61.add(jLabel18);

        txtPlaceReturn.setPreferredSize(new java.awt.Dimension(220, 22));
        txtPlaceReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPlaceReturnMouseClicked(evt);
            }
        });
        txtPlaceReturn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlaceReturnKeyPressed(evt);
            }
        });
        jPanel61.add(txtPlaceReturn);

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel19.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel19.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel19.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel19.setOpaque(true);
        jLabel19.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel61.add(jLabel19);

        txtLatitudeReturn.setText(" 00�00'00\"");
        txtLatitudeReturn.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLatitudeReturn.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLatitudeReturnFocusLost(evt);
            }
        });
        txtLatitudeReturn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLatitudeReturnKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLatitudeReturnkeyTyped(evt);
            }
        });
        jPanel61.add(txtLatitudeReturn);

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel20.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel20.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel20.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel20.setOpaque(true);
        jLabel20.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel61.add(jLabel20);

        txtLongitudeReturn.setText(" 000�00'00\"");
        txtLongitudeReturn.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLongitudeReturn.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLongitudeReturnFocusLost(evt);
            }
        });
        txtLongitudeReturn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLongitudeReturnkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLongitudeReturnKeyPressed(evt);
            }
        });
        jPanel61.add(txtLongitudeReturn);

        pnlRevolution.add(jPanel61);

        jPanel41.add(pnlRevolution, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel41);

        jPanel43.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel43.setPreferredSize(new java.awt.Dimension(990, 65));
        jPanel43.setLayout(new java.awt.BorderLayout());

        chkCycle.setPreferredSize(new java.awt.Dimension(215, 60));
        chkCycle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCycleActionPerformed(evt);
            }
        });
        jPanel43.add(chkCycle, java.awt.BorderLayout.WEST);

        pnlCycle.setMinimumSize(new java.awt.Dimension(654, 31));
        pnlCycle.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jPanel65.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel6.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel6.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel6.setOpaque(true);
        jLabel6.setPreferredSize(new java.awt.Dimension(200, 22));
        jPanel65.add(jLabel6);

        txtCyclesNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCyclesNB.setText("1");
        txtCyclesNB.setPreferredSize(new java.awt.Dimension(50, 22));
        txtCyclesNB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCyclesNBFocusLost(evt);
            }
        });
        txtCyclesNB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCyclesNBkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCyclesNBKeyPressed(evt);
            }
        });
        jPanel65.add(txtCyclesNB);

        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel26.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel26.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel26.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel26.setOpaque(true);
        jLabel26.setPreferredSize(new java.awt.Dimension(80, 22));
        jPanel65.add(jLabel26);

        cboPlanet1Cycle.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel65.add(cboPlanet1Cycle);

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel27.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel27.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel27.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel27.setOpaque(true);
        jLabel27.setPreferredSize(new java.awt.Dimension(80, 22));
        jPanel65.add(jLabel27);

        cboPlanet2Cycle.setPreferredSize(new java.awt.Dimension(100, 25));
        jPanel65.add(cboPlanet2Cycle);

        pnlCycle.add(jPanel65);

        jPanel66.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel23.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel23.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel23.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel23.setOpaque(true);
        jLabel23.setPreferredSize(new java.awt.Dimension(80, 22));
        jPanel66.add(jLabel23);

        txtPlaceCycle.setPreferredSize(new java.awt.Dimension(220, 22));
        txtPlaceCycle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPlaceCycleMouseClicked(evt);
            }
        });
        txtPlaceCycle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlaceCycleKeyPressed(evt);
            }
        });
        jPanel66.add(txtPlaceCycle);

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel24.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel24.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel24.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel24.setOpaque(true);
        jLabel24.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel66.add(jLabel24);

        txtLatitudeCycle.setText(" 00�00'00\"");
        txtLatitudeCycle.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLatitudeCycle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLatitudeCycleFocusLost(evt);
            }
        });
        txtLatitudeCycle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLatitudeCycleKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLatitudeCyclekeyTyped(evt);
            }
        });
        jPanel66.add(txtLatitudeCycle);

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel25.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel25.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel25.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel25.setOpaque(true);
        jLabel25.setPreferredSize(new java.awt.Dimension(110, 22));
        jPanel66.add(jLabel25);

        txtLongitudeCycle.setText(" 000�00'00\"");
        txtLongitudeCycle.setPreferredSize(new java.awt.Dimension(100, 22));
        txtLongitudeCycle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtLongitudeCycleFocusLost(evt);
            }
        });
        txtLongitudeCycle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLongitudeCyclekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtLongitudeCycleKeyPressed(evt);
            }
        });
        jPanel66.add(txtLongitudeCycle);

        pnlCycle.add(jPanel66);

        jPanel43.add(pnlCycle, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel43);

        jPanel45.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel45.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel45.setLayout(new java.awt.BorderLayout());

        chkSynastry.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSynastry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSynastryActionPerformed(evt);
            }
        });
        jPanel45.add(chkSynastry, java.awt.BorderLayout.WEST);

        pnlSynastry.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 2));

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel7.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel7.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel7.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel7.setOpaque(true);
        jLabel7.setPreferredSize(new java.awt.Dimension(275, 18));
        pnlSynastry.add(jLabel7);

        lblRemainEventSynastry.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRemainEventSynastry.setText("2");
        lblRemainEventSynastry.setAlignmentX(0.5F);
        lblRemainEventSynastry.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblRemainEventSynastry.setIconTextGap(0);
        lblRemainEventSynastry.setMaximumSize(new java.awt.Dimension(110, 18));
        lblRemainEventSynastry.setMinimumSize(new java.awt.Dimension(110, 18));
        lblRemainEventSynastry.setPreferredSize(new java.awt.Dimension(35, 21));
        pnlSynastry.add(lblRemainEventSynastry);

        grpSynastrySelect.add(optSynastryChartSelect);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        optSynastryChartSelect.setToolTipText(bundle.getString("FromSavedCharts")); // NOI18N
        pnlSynastry.add(optSynastryChartSelect);

        grpSynastrySelect.add(optSynastryEventSelect);
        optSynastryEventSelect.setSelected(true);
        optSynastryEventSelect.setToolTipText(bundle.getString("FromEvent")); // NOI18N
        pnlSynastry.add(optSynastryEventSelect);

        btnOKEventSelectSysnastry.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/selected.png"))); // NOI18N
        btnOKEventSelectSysnastry.setBorder(null);
        btnOKEventSelectSysnastry.setMaximumSize(new java.awt.Dimension(200, 24));
        btnOKEventSelectSysnastry.setMinimumSize(new java.awt.Dimension(200, 24));
        btnOKEventSelectSysnastry.setPreferredSize(new java.awt.Dimension(28, 28));
        btnOKEventSelectSysnastry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKEventSelectSysnastryActionPerformed(evt);
            }
        });
        pnlSynastry.add(btnOKEventSelectSysnastry);

        jPanel45.add(pnlSynastry, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel45);

        jPanel47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel47.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel47.setLayout(new java.awt.BorderLayout());

        chkComposite.setPreferredSize(new java.awt.Dimension(215, 31));
        chkComposite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCompositeActionPerformed(evt);
            }
        });
        jPanel47.add(chkComposite, java.awt.BorderLayout.WEST);

        pnlComposite.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 2));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel8.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel8.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel8.setOpaque(true);
        jLabel8.setPreferredSize(new java.awt.Dimension(80, 22));
        pnlComposite.add(jLabel8);

        txtCompositeChartsNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCompositeChartsNB.setText("2");
        txtCompositeChartsNB.setPreferredSize(new java.awt.Dimension(50, 22));
        txtCompositeChartsNB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCompositeChartsNBFocusLost(evt);
            }
        });
        txtCompositeChartsNB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCompositeChartsNBkeyTyped(evt);
            }
        });
        pnlComposite.add(txtCompositeChartsNB);

        lblFrom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrom.setText("/");
        lblFrom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        lblFrom.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblFrom.setOpaque(true);
        lblFrom.setPreferredSize(new java.awt.Dimension(25, 22));
        pnlComposite.add(lblFrom);

        grpCompositeFrom.add(optCompositeFromAS);
        optCompositeFromAS.setText("AS");
        pnlComposite.add(optCompositeFromAS);

        grpCompositeFrom.add(optCompositeFromMC);
        optCompositeFromMC.setSelected(true);
        optCompositeFromMC.setText("MC");
        pnlComposite.add(optCompositeFromMC);

        jLabel28.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel28.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel28.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel28.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel28.setOpaque(true);
        jLabel28.setPreferredSize(new java.awt.Dimension(275, 18));
        pnlComposite.add(jLabel28);

        lblRemainEventComposite.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRemainEventComposite.setText("2");
        lblRemainEventComposite.setAlignmentX(0.5F);
        lblRemainEventComposite.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblRemainEventComposite.setIconTextGap(0);
        lblRemainEventComposite.setMaximumSize(new java.awt.Dimension(110, 18));
        lblRemainEventComposite.setMinimumSize(new java.awt.Dimension(110, 18));
        lblRemainEventComposite.setPreferredSize(new java.awt.Dimension(35, 21));
        pnlComposite.add(lblRemainEventComposite);

        grpCompositeSelect.add(optCompositeChartSelect);
        pnlComposite.add(optCompositeChartSelect);

        grpCompositeSelect.add(optCompositeEventSelect);
        optCompositeEventSelect.setSelected(true);
        pnlComposite.add(optCompositeEventSelect);

        btnOKEventSelectComposite.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/selected.png"))); // NOI18N
        btnOKEventSelectComposite.setBorder(null);
        btnOKEventSelectComposite.setMaximumSize(new java.awt.Dimension(200, 24));
        btnOKEventSelectComposite.setMinimumSize(new java.awt.Dimension(200, 24));
        btnOKEventSelectComposite.setPreferredSize(new java.awt.Dimension(28, 28));
        btnOKEventSelectComposite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKEventSelectCompositeActionPerformed(evt);
            }
        });
        pnlComposite.add(btnOKEventSelectComposite);

        jPanel47.add(pnlComposite, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel47);

        jPanel49.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel49.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel49.setLayout(new java.awt.BorderLayout());

        chkFree.setPreferredSize(new java.awt.Dimension(215, 31));
        chkFree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkFreeActionPerformed(evt);
            }
        });
        jPanel49.add(chkFree, java.awt.BorderLayout.WEST);

        pnlFree.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        btnEditFree.setPreferredSize(new java.awt.Dimension(250, 24));
        btnEditFree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditFreeActionPerformed(evt);
            }
        });
        pnlFree.add(btnEditFree);

        jPanel49.add(pnlFree, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel49);

        jPanel53.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel53.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel53.setLayout(new java.awt.BorderLayout());

        chkHarmonic.setPreferredSize(new java.awt.Dimension(215, 31));
        chkHarmonic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHarmonicActionPerformed(evt);
            }
        });
        jPanel53.add(chkHarmonic, java.awt.BorderLayout.WEST);

        pnlHarmonic.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel9.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel9.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel9.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel9.setOpaque(true);
        jLabel9.setPreferredSize(new java.awt.Dimension(200, 22));
        pnlHarmonic.add(jLabel9);

        txtHarmonicNB.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtHarmonicNB.setText("2");
        txtHarmonicNB.setPreferredSize(new java.awt.Dimension(50, 22));
        txtHarmonicNB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtHarmonicNBFocusLost(evt);
            }
        });
        txtHarmonicNB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHarmonicNBkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHarmonicNBKeyPressed(evt);
            }
        });
        pnlHarmonic.add(txtHarmonicNB);

        jPanel53.add(pnlHarmonic, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel53);

        jPanel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel31.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel31.setLayout(new java.awt.BorderLayout());

        chkSeed.setPreferredSize(new java.awt.Dimension(215, 31));
        chkSeed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSeedActionPerformed(evt);
            }
        });
        jPanel31.add(chkSeed, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel31);

        jPanel55.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel55.setPreferredSize(new java.awt.Dimension(990, 35));
        jPanel55.setLayout(new java.awt.BorderLayout());

        chkProjective.setPreferredSize(new java.awt.Dimension(215, 31));
        chkProjective.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkProjectiveActionPerformed(evt);
            }
        });
        jPanel55.add(chkProjective, java.awt.BorderLayout.WEST);

        jPanel12.add(jPanel55);

        pnlChartKind.add(jPanel12);

        tabSettings.addTab("Chart kind", null, pnlChartKind, "");

        pnlCoordSystem.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlCoordSystem.setLayout(new java.awt.BorderLayout());

        jPanel64.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel2.setPreferredSize(new java.awt.Dimension(200, 75));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        grpGeoHelio.add(chkGeocentric);
        chkGeocentric.setSelected(true);
        chkGeocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkGeocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkGeocentric.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkGeocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkGeocentric);

        grpGeoHelio.add(chkHeliocentric);
        chkHeliocentric.setMaximumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setMinimumSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.setPreferredSize(new java.awt.Dimension(175, 31));
        chkHeliocentric.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricActionPerformed(evt);
            }
        });
        jPanel2.add(chkHeliocentric);

        jPanel64.add(jPanel2);

        jPanel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 0, 5));
        jPanel3.setPreferredSize(new java.awt.Dimension(210, 460));

        grpGeo.add(chkTropical);
        chkTropical.setSelected(true);
        chkTropical.setPreferredSize(new java.awt.Dimension(200, 31));
        chkTropical.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkTropicalActionPerformed(evt);
            }
        });
        jPanel3.add(chkTropical);

        grpGeo.add(chkSidereal);
        chkSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkSidereal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkSidereal);

        grpGeo.add(chkEquatorial);
        chkEquatorial.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEquatorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEquatorialActionPerformed(evt);
            }
        });
        jPanel3.add(chkEquatorial);

        grpGeo.add(chkEcliptic);
        chkEcliptic.setPreferredSize(new java.awt.Dimension(200, 31));
        chkEcliptic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEclipticActionPerformed(evt);
            }
        });
        jPanel3.add(chkEcliptic);

        grpGeo.add(chkLocal);
        chkLocal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkLocalActionPerformed(evt);
            }
        });
        jPanel3.add(chkLocal);

        grpGeo.add(chkDomitudes);
        chkDomitudes.setPreferredSize(new java.awt.Dimension(200, 31));
        chkDomitudes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkDomitudesActionPerformed(evt);
            }
        });
        jPanel3.add(chkDomitudes);

        grpHelio.add(chkHeliocentricNormal);
        chkHeliocentricNormal.setSelected(true);
        chkHeliocentricNormal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricNormalActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricNormal);

        grpHelio.add(chkHeliocentricSidereal);
        chkHeliocentricSidereal.setPreferredSize(new java.awt.Dimension(200, 31));
        chkHeliocentricSidereal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHeliocentricSiderealActionPerformed(evt);
            }
        });
        jPanel3.add(chkHeliocentricSidereal);

        jPanel64.add(jPanel3);

        pnlCoordSystem.add(jPanel64, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Coordinates system", null, pnlCoordSystem, "");

        pnlHouseSystem.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlHouseSystem.setLayout(new java.awt.BorderLayout());

        jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 0, 5));
        jPanel4.setPreferredSize(new java.awt.Dimension(250, 511));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        grpHouseSystem.add(optAncient);
        optAncient.setMaximumSize(new java.awt.Dimension(235, 24));
        optAncient.setMinimumSize(new java.awt.Dimension(235, 24));
        optAncient.setPreferredSize(new java.awt.Dimension(235, 24));
        optAncient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAncientActionPerformed(evt);
            }
        });
        jPanel4.add(optAncient);

        grpHouseSystem.add(optTwoHours);
        optTwoHours.setMaximumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setMinimumSize(new java.awt.Dimension(235, 24));
        optTwoHours.setPreferredSize(new java.awt.Dimension(235, 24));
        optTwoHours.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optTwoHoursActionPerformed(evt);
            }
        });
        jPanel4.add(optTwoHours);

        grpHouseSystem.add(optSemiAngular);
        optSemiAngular.setMaximumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setMinimumSize(new java.awt.Dimension(235, 24));
        optSemiAngular.setPreferredSize(new java.awt.Dimension(235, 24));
        optSemiAngular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSemiAngularActionPerformed(evt);
            }
        });
        jPanel4.add(optSemiAngular);

        grpHouseSystem.add(optCampanus);
        optCampanus.setSelected(true);
        optCampanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optCampanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optCampanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optCampanus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optCampanusActionPerformed(evt);
            }
        });
        jPanel4.add(optCampanus);

        grpHouseSystem.add(optEquatorialRegular);
        optEquatorialRegular.setMaximumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setMinimumSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.setPreferredSize(new java.awt.Dimension(235, 24));
        optEquatorialRegular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optEquatorialRegularActionPerformed(evt);
            }
        });
        jPanel4.add(optEquatorialRegular);

        grpHouseSystem.add(optColinEvans);
        optColinEvans.setMaximumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setMinimumSize(new java.awt.Dimension(235, 24));
        optColinEvans.setPreferredSize(new java.awt.Dimension(235, 24));
        optColinEvans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optColinEvansActionPerformed(evt);
            }
        });
        jPanel4.add(optColinEvans);

        grpHouseSystem.add(optBazchenoff);
        optBazchenoff.setMaximumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setMinimumSize(new java.awt.Dimension(235, 24));
        optBazchenoff.setPreferredSize(new java.awt.Dimension(235, 24));
        optBazchenoff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optBazchenoffActionPerformed(evt);
            }
        });
        jPanel4.add(optBazchenoff);

        grpHouseSystem.add(optMaternusAs);
        optMaternusAs.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusAs.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusAsActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusAs);

        grpHouseSystem.add(optMaternusMC);
        optMaternusMC.setMaximumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setMinimumSize(new java.awt.Dimension(235, 24));
        optMaternusMC.setPreferredSize(new java.awt.Dimension(235, 24));
        optMaternusMC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optMaternusMCActionPerformed(evt);
            }
        });
        jPanel4.add(optMaternusMC);

        grpHouseSystem.add(optNodal);
        optNodal.setMaximumSize(new java.awt.Dimension(235, 24));
        optNodal.setMinimumSize(new java.awt.Dimension(235, 24));
        optNodal.setPreferredSize(new java.awt.Dimension(235, 24));
        optNodal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optNodalActionPerformed(evt);
            }
        });
        jPanel4.add(optNodal);

        grpHouseSystem.add(optPorpyre);
        optPorpyre.setMaximumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setMinimumSize(new java.awt.Dimension(235, 24));
        optPorpyre.setPreferredSize(new java.awt.Dimension(235, 24));
        optPorpyre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPorpyreActionPerformed(evt);
            }
        });
        jPanel4.add(optPorpyre);

        grpHouseSystem.add(optRegiomontanus);
        optRegiomontanus.setMaximumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setMinimumSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.setPreferredSize(new java.awt.Dimension(235, 24));
        optRegiomontanus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optRegiomontanusActionPerformed(evt);
            }
        });
        jPanel4.add(optRegiomontanus);

        grpHouseSystem.add(optSolar);
        optSolar.setMaximumSize(new java.awt.Dimension(235, 24));
        optSolar.setMinimumSize(new java.awt.Dimension(235, 24));
        optSolar.setPreferredSize(new java.awt.Dimension(235, 24));
        optSolar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optSolarActionPerformed(evt);
            }
        });
        jPanel4.add(optSolar);

        grpHouseSystem.add(optWiesel);
        optWiesel.setMaximumSize(new java.awt.Dimension(235, 24));
        optWiesel.setMinimumSize(new java.awt.Dimension(235, 24));
        optWiesel.setPreferredSize(new java.awt.Dimension(235, 24));
        optWiesel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optWieselActionPerformed(evt);
            }
        });
        jPanel4.add(optWiesel);

        grpHouseSystem.add(optZenithal);
        optZenithal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZenithal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZenithal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZenithal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZenithalActionPerformed(evt);
            }
        });
        jPanel4.add(optZenithal);

        grpHouseSystem.add(optZodiacal);
        optZodiacal.setMaximumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setMinimumSize(new java.awt.Dimension(235, 24));
        optZodiacal.setPreferredSize(new java.awt.Dimension(235, 24));
        optZodiacal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optZodiacalActionPerformed(evt);
            }
        });
        jPanel4.add(optZodiacal);

        jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jSeparator1.setMaximumSize(new java.awt.Dimension(32767, 2));
        jSeparator1.setPreferredSize(new java.awt.Dimension(175, 2));
        jPanel4.add(jSeparator1);

        grpHouseSystem.add(optAbenragel);
        optAbenragel.setMaximumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setMinimumSize(new java.awt.Dimension(235, 24));
        optAbenragel.setPreferredSize(new java.awt.Dimension(235, 24));
        optAbenragel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAbenragelActionPerformed(evt);
            }
        });
        jPanel4.add(optAbenragel);

        grpHouseSystem.add(optAlbategnius);
        optAlbategnius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlbategnius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlbategnius.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlbategniusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlbategnius);

        grpHouseSystem.add(optAlcabitius);
        optAlcabitius.setMaximumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setMinimumSize(new java.awt.Dimension(235, 24));
        optAlcabitius.setPreferredSize(new java.awt.Dimension(235, 24));
        optAlcabitius.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optAlcabitiusActionPerformed(evt);
            }
        });
        jPanel4.add(optAlcabitius);

        grpHouseSystem.add(optKoch);
        optKoch.setMaximumSize(new java.awt.Dimension(235, 24));
        optKoch.setMinimumSize(new java.awt.Dimension(235, 24));
        optKoch.setPreferredSize(new java.awt.Dimension(235, 24));
        optKoch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optKochActionPerformed(evt);
            }
        });
        jPanel4.add(optKoch);

        grpHouseSystem.add(optPlacidus);
        optPlacidus.setMaximumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setMinimumSize(new java.awt.Dimension(235, 24));
        optPlacidus.setPreferredSize(new java.awt.Dimension(235, 24));
        optPlacidus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optPlacidusActionPerformed(evt);
            }
        });
        jPanel4.add(optPlacidus);

        pnlHouseSystem.add(jPanel4, java.awt.BorderLayout.WEST);

        tabSettings.addTab("Houses system", null, pnlHouseSystem, "");

        pnlChartLook.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlChartLook.setLayout(new java.awt.BorderLayout());

        jPanel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        jPanel5.setPreferredSize(new java.awt.Dimension(220, 20));
        jPanel5.setLayout(new java.awt.BorderLayout());

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel6.setPreferredSize(new java.awt.Dimension(210, 632));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setAlignmentX(0.5F);
        jLabel11.setMaximumSize(new java.awt.Dimension(175, 18));
        jLabel11.setMinimumSize(new java.awt.Dimension(175, 18));
        jLabel11.setOpaque(true);
        jLabel11.setPreferredSize(new java.awt.Dimension(185, 18));
        jPanel6.add(jLabel11);

        jPanel7.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel7.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel7.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setOpaque(true);
        jLabel13.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel7.add(jLabel13);

        lblColorSun.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorSun.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSun.setText("A");
        lblColorSun.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSun.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorSun.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorSun.setOpaque(true);
        lblColorSun.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorSun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSunMouseClicked(evt);
            }
        });
        jPanel7.add(lblColorSun);

        jPanel6.add(jPanel7);

        jPanel8.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel8.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel8.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setOpaque(true);
        jLabel29.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel8.add(jLabel29);

        lblColorMoon.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorMoon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMoon.setText("B");
        lblColorMoon.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorMoon.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorMoon.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorMoon.setOpaque(true);
        lblColorMoon.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMoon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorMoonMouseClicked(evt);
            }
        });
        jPanel8.add(lblColorMoon);

        jPanel6.add(jPanel8);

        jPanel9.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel9.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel9.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setOpaque(true);
        jLabel31.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel9.add(jLabel31);

        lblColorMercury.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorMercury.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMercury.setText("C");
        lblColorMercury.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorMercury.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorMercury.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorMercury.setOpaque(true);
        lblColorMercury.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMercury.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorMercuryMouseClicked(evt);
            }
        });
        jPanel9.add(lblColorMercury);

        jPanel6.add(jPanel9);

        jPanel10.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel10.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel10.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setOpaque(true);
        jLabel33.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel10.add(jLabel33);

        lblColorVenus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorVenus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorVenus.setText("D");
        lblColorVenus.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorVenus.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorVenus.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorVenus.setOpaque(true);
        lblColorVenus.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorVenus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorVenusMouseClicked(evt);
            }
        });
        jPanel10.add(lblColorVenus);

        jPanel6.add(jPanel10);

        jPanel11.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel11.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel11.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setOpaque(true);
        jLabel35.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel11.add(jLabel35);

        lblColorMars.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorMars.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorMars.setText("E");
        lblColorMars.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorMars.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorMars.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorMars.setOpaque(true);
        lblColorMars.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorMars.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorMarsMouseClicked(evt);
            }
        });
        jPanel11.add(lblColorMars);

        jPanel6.add(jPanel11);

        jPanel14.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel14.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel14.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setOpaque(true);
        jLabel37.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel14.add(jLabel37);

        lblColorJupiter.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorJupiter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorJupiter.setText("F");
        lblColorJupiter.setToolTipText(bundle.getString("Click2ModifyColor")); // NOI18N
        lblColorJupiter.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorJupiter.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorJupiter.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorJupiter.setOpaque(true);
        lblColorJupiter.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorJupiter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorJupiterMouseClicked(evt);
            }
        });
        jPanel14.add(lblColorJupiter);

        jPanel6.add(jPanel14);

        jPanel15.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel15.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel15.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setOpaque(true);
        jLabel39.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel15.add(jLabel39);

        lblColorSaturn.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorSaturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorSaturn.setText("G");
        lblColorSaturn.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSaturn.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorSaturn.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorSaturn.setOpaque(true);
        lblColorSaturn.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorSaturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSaturnMouseClicked(evt);
            }
        });
        jPanel15.add(lblColorSaturn);

        jPanel6.add(jPanel15);

        jPanel16.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel16.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel16.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setOpaque(true);
        jLabel41.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel16.add(jLabel41);

        lblColorUranus.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorUranus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorUranus.setText("H");
        lblColorUranus.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorUranus.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorUranus.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorUranus.setOpaque(true);
        lblColorUranus.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorUranus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorUranusMouseClicked(evt);
            }
        });
        jPanel16.add(lblColorUranus);

        jPanel6.add(jPanel16);

        jPanel17.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel17.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel17.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setOpaque(true);
        jLabel43.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel17.add(jLabel43);

        lblColorNeptune.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorNeptune.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNeptune.setText("I");
        lblColorNeptune.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorNeptune.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorNeptune.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorNeptune.setOpaque(true);
        lblColorNeptune.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNeptune.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorNeptuneMouseClicked(evt);
            }
        });
        jPanel17.add(lblColorNeptune);

        jPanel6.add(jPanel17);

        jPanel18.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel18.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel18.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setOpaque(true);
        jLabel45.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel18.add(jLabel45);

        lblColorPluto.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorPluto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorPluto.setText("J");
        lblColorPluto.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorPluto.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorPluto.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorPluto.setOpaque(true);
        lblColorPluto.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorPluto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorPlutoMouseClicked(evt);
            }
        });
        jPanel18.add(lblColorPluto);

        jPanel6.add(jPanel18);

        jPanel19.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel19.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel19.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setOpaque(true);
        jLabel47.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel19.add(jLabel47);

        lblColorGaia.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorGaia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorGaia.setText("K");
        lblColorGaia.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorGaia.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorGaia.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorGaia.setOpaque(true);
        lblColorGaia.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorGaia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorGaiaMouseClicked(evt);
            }
        });
        jPanel19.add(lblColorGaia);

        jPanel6.add(jPanel19);

        jPanel20.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel20.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel20.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setOpaque(true);
        jLabel49.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel20.add(jLabel49);

        lblColorNodes.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorNodes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNodes.setText("L Z");
        lblColorNodes.setToolTipText(bundle.getString("Click2ModifyColor")); // NOI18N
        lblColorNodes.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorNodes.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorNodes.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorNodes.setOpaque(true);
        lblColorNodes.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNodes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorNodesMouseClicked(evt);
            }
        });
        jPanel20.add(lblColorNodes);

        jPanel6.add(jPanel20);

        jPanel21.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel21.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel21.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setOpaque(true);
        jLabel51.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel21.add(jLabel51);

        lblColorHouses.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorHouses.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorHouses.setText("X   Y");
        lblColorHouses.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorHouses.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorHouses.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorHouses.setOpaque(true);
        lblColorHouses.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorHouses.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorHousesMouseClicked(evt);
            }
        });
        jPanel21.add(lblColorHouses);

        jPanel6.add(jPanel21);

        jPanel22.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel22.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel22.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setOpaque(true);
        jLabel53.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel22.add(jLabel53);

        lblColorAsteroids.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorAsteroids.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorAsteroids.setText("S T U V W");
        lblColorAsteroids.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorAsteroids.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorAsteroids.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorAsteroids.setOpaque(true);
        lblColorAsteroids.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorAsteroids.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorAsteroidsMouseClicked(evt);
            }
        });
        jPanel22.add(lblColorAsteroids);

        jPanel6.add(jPanel22);

        jPanel23.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel23.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel23.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel55.setOpaque(true);
        jLabel55.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel23.add(jLabel55);

        lblColorVulcan.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorVulcan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorVulcan.setText("Q");
        lblColorVulcan.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorVulcan.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorVulcan.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorVulcan.setOpaque(true);
        lblColorVulcan.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorVulcan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorVulcanMouseClicked(evt);
            }
        });
        jPanel23.add(lblColorVulcan);

        jPanel6.add(jPanel23);

        jPanel24.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel24.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel24.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setOpaque(true);
        jLabel57.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel24.add(jLabel57);

        lblColorText.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorText.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorText.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorText.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorText.setOpaque(true);
        lblColorText.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorText.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorTextMouseClicked(evt);
            }
        });
        jPanel24.add(lblColorText);

        jPanel6.add(jPanel24);

        jPanel25.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel25.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel25.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel59.setOpaque(true);
        jLabel59.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel25.add(jLabel59);

        lblColorFire.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorFire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorFire.setText("s w {");
        lblColorFire.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorFire.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorFire.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorFire.setOpaque(true);
        lblColorFire.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorFire.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorFireMouseClicked(evt);
            }
        });
        jPanel25.add(lblColorFire);

        jPanel6.add(jPanel25);

        jPanel26.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel26.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel26.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel61.setOpaque(true);
        jLabel61.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel26.add(jLabel61);

        lblColorEarth.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorEarth.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorEarth.setText("t x |");
        lblColorEarth.setToolTipText(bundle.getString("Click2ModifyColor")); // NOI18N
        lblColorEarth.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorEarth.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorEarth.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorEarth.setOpaque(true);
        lblColorEarth.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorEarth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorEarthMouseClicked(evt);
            }
        });
        jPanel26.add(lblColorEarth);

        jPanel6.add(jPanel26);

        jPanel27.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel27.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel27.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setOpaque(true);
        jLabel63.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel27.add(jLabel63);

        lblColorAir.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorAir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorAir.setText("u y }");
        lblColorAir.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorAir.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorAir.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorAir.setOpaque(true);
        lblColorAir.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorAir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorAirMouseClicked(evt);
            }
        });
        jPanel27.add(lblColorAir);

        jPanel6.add(jPanel27);

        jPanel28.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel28.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel28.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setOpaque(true);
        jLabel65.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel28.add(jLabel65);

        lblColorWater.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorWater.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorWater.setText("v z ~");
        lblColorWater.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorWater.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorWater.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorWater.setOpaque(true);
        lblColorWater.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorWater.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorWaterMouseClicked(evt);
            }
        });
        jPanel28.add(lblColorWater);

        jPanel6.add(jPanel28);

        jPanel30.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel30.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel30.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel67.setOpaque(true);
        jLabel67.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel30.add(jLabel67);

        lblColorNeutral.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorNeutral.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorNeutral.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorNeutral.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorNeutral.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorNeutral.setOpaque(true);
        lblColorNeutral.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorNeutral.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorNeutralMouseClicked(evt);
            }
        });
        jPanel30.add(lblColorNeutral);

        jPanel6.add(jPanel30);

        jPanel32.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel32.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel32.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setOpaque(true);
        jLabel69.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel32.add(jLabel69);

        lblColorDynamic.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorDynamic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorDynamic.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorDynamic.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorDynamic.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorDynamic.setOpaque(true);
        lblColorDynamic.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorDynamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorDynamicMouseClicked(evt);
            }
        });
        jPanel32.add(lblColorDynamic);

        jPanel6.add(jPanel32);

        jPanel34.setMaximumSize(new java.awt.Dimension(175, 23));
        jPanel34.setMinimumSize(new java.awt.Dimension(175, 23));
        jPanel34.setPreferredSize(new java.awt.Dimension(200, 23));

        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setOpaque(true);
        jLabel71.setPreferredSize(new java.awt.Dimension(100, 18));
        jPanel34.add(jLabel71);

        lblColorHarmonic.setFont(new java.awt.Font("StarLogin", 0, 13)); // NOI18N
        lblColorHarmonic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblColorHarmonic.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorHarmonic.setMaximumSize(new java.awt.Dimension(110, 18));
        lblColorHarmonic.setMinimumSize(new java.awt.Dimension(110, 18));
        lblColorHarmonic.setOpaque(true);
        lblColorHarmonic.setPreferredSize(new java.awt.Dimension(80, 18));
        lblColorHarmonic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorHarmonicMouseClicked(evt);
            }
        });
        jPanel34.add(lblColorHarmonic);

        jPanel6.add(jPanel34);

        jPanel5.add(jPanel6, java.awt.BorderLayout.CENTER);

        pnlChartLook.add(jPanel5, java.awt.BorderLayout.WEST);

        jPanel36.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        jPanel36.setLayout(new java.awt.BorderLayout());

        jPanel38.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel38.setOpaque(false);
        jPanel38.setPreferredSize(new java.awt.Dimension(214, 612));
        jPanel38.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 1));

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setAlignmentX(0.5F);
        jLabel22.setOpaque(true);
        jLabel22.setPreferredSize(new java.awt.Dimension(200, 18));
        jPanel38.add(jLabel22);

        jPanel40.setPreferredSize(new java.awt.Dimension(210, 150));
        jPanel40.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel30.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel30.setOpaque(true);
        jLabel30.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel40.add(jLabel30);

        sldZodiac.setMajorTickSpacing(10);
        sldZodiac.setMinimum(50);
        sldZodiac.setMinorTickSpacing(5);
        sldZodiac.setPaintLabels(true);
        sldZodiac.setPaintTicks(true);
        sldZodiac.setValue(75);
        sldZodiac.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldZodiacStateChanged(evt);
            }
        });
        jPanel40.add(sldZodiac);

        lblZodiacSize.setBackground(new java.awt.Color(102, 200, 255));
        lblZodiacSize.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lblZodiacSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblZodiacSize.setText("%");
        lblZodiacSize.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblZodiacSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblZodiacSize.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel40.add(lblZodiacSize);

        jPanel38.add(jPanel40);

        jPanel42.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel42.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setOpaque(true);
        jLabel34.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel42.add(jLabel34);

        sldSigns.setMajorTickSpacing(2);
        sldSigns.setMaximum(72);
        sldSigns.setMinimum(10);
        sldSigns.setMinorTickSpacing(1);
        sldSigns.setPaintTicks(true);
        sldSigns.setValue(20);
        sldSigns.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldSignsStateChanged(evt);
            }
        });
        jPanel42.add(sldSigns);

        lblSignSize.setBackground(new java.awt.Color(102, 200, 255));
        lblSignSize.setFont(new java.awt.Font("StarLogin", 1, 20)); // NOI18N
        lblSignSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSignSize.setText("}");
        lblSignSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblSignSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblSignSize.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel42.add(lblSignSize);

        jPanel38.add(jPanel42);

        jPanel44.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel44.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setOpaque(true);
        jLabel38.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel44.add(jLabel38);

        sldPlanets.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        sldPlanets.setMajorTickSpacing(2);
        sldPlanets.setMaximum(72);
        sldPlanets.setMinimum(8);
        sldPlanets.setMinorTickSpacing(1);
        sldPlanets.setPaintTicks(true);
        sldPlanets.setValue(12);
        sldPlanets.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldPlanetsStateChanged(evt);
            }
        });
        jPanel44.add(sldPlanets);

        lblPlanetSize.setBackground(new java.awt.Color(102, 200, 255));
        lblPlanetSize.setFont(new java.awt.Font("StarLogin", 1, 14)); // NOI18N
        lblPlanetSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPlanetSize.setText("H");
        lblPlanetSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblPlanetSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblPlanetSize.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel44.add(lblPlanetSize);

        jPanel38.add(jPanel44);

        jPanel46.setOpaque(false);
        jPanel46.setPreferredSize(new java.awt.Dimension(210, 136));
        jPanel46.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setOpaque(true);
        jLabel42.setPreferredSize(new java.awt.Dimension(80, 18));
        jPanel46.add(jLabel42);

        sldCharacters.setMajorTickSpacing(2);
        sldCharacters.setMaximum(48);
        sldCharacters.setMinimum(8);
        sldCharacters.setMinorTickSpacing(1);
        sldCharacters.setPaintTicks(true);
        sldCharacters.setValue(10);
        sldCharacters.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldCharactersStateChanged(evt);
            }
        });
        jPanel46.add(sldCharacters);

        lblCharactersSize.setBackground(new java.awt.Color(102, 200, 255));
        lblCharactersSize.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        lblCharactersSize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCharactersSize.setText("18�23'");
        lblCharactersSize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblCharactersSize.setPreferredSize(new java.awt.Dimension(200, 86));
        lblCharactersSize.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel46.add(lblCharactersSize);

        jPanel38.add(jPanel46);

        jPanel36.add(jPanel38, java.awt.BorderLayout.CENTER);

        pnlChartLook.add(jPanel36, java.awt.BorderLayout.EAST);

        pnlChartColorChoice.setPreferredSize(new java.awt.Dimension(70, 594));

        org.jdesktop.layout.GroupLayout pnlChartColorChoiceLayout = new org.jdesktop.layout.GroupLayout(pnlChartColorChoice);
        pnlChartColorChoice.setLayout(pnlChartColorChoiceLayout);
        pnlChartColorChoiceLayout.setHorizontalGroup(
            pnlChartColorChoiceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 569, Short.MAX_VALUE)
        );
        pnlChartColorChoiceLayout.setVerticalGroup(
            pnlChartColorChoiceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 594, Short.MAX_VALUE)
        );

        pnlChartLook.add(pnlChartColorChoice, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Chart look", null, pnlChartLook, "");

        pnlPlanets.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlPlanets.setLayout(new java.awt.BorderLayout());

        jPanel54.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 0, 0, 0));

        jPanel48.setAlignmentX(0.0F);
        jPanel48.setAlignmentY(0.0F);
        jPanel48.setPreferredSize(new java.awt.Dimension(200, 600));

        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setAlignmentX(0.5F);
        jLabel40.setOpaque(true);
        jLabel40.setPreferredSize(new java.awt.Dimension(175, 18));
        jPanel48.add(jLabel40);

        chkSun.setSelected(true);
        chkSun.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkSun);

        chkMoon.setSelected(true);
        chkMoon.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkMoon);

        chkMercury.setSelected(true);
        chkMercury.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkMercury);

        chkVenus.setSelected(true);
        chkVenus.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkVenus);

        chkMars.setSelected(true);
        chkMars.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkMars);

        chkJupiter.setSelected(true);
        chkJupiter.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkJupiter);

        chkSaturn.setSelected(true);
        chkSaturn.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkSaturn);

        chkUranus.setSelected(true);
        chkUranus.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkUranus);

        chkNeptune.setSelected(true);
        chkNeptune.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkNeptune);

        chkPluto.setSelected(true);
        chkPluto.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel48.add(chkPluto);

        jPanel54.add(jPanel48);

        jPanel50.setAlignmentX(0.0F);
        jPanel50.setAlignmentY(0.0F);
        jPanel50.setMaximumSize(new java.awt.Dimension(200, 600));
        jPanel50.setPreferredSize(new java.awt.Dimension(200, 600));
        jPanel50.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setAlignmentX(0.5F);
        jLabel44.setOpaque(true);
        jLabel44.setPreferredSize(new java.awt.Dimension(175, 18));
        jPanel50.add(jLabel44);

        chkGaia.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkGaia);

        chkNN.setSelected(true);
        chkNN.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkNN);

        jPanel56.setMaximumSize(new java.awt.Dimension(175, 24));
        jPanel56.setMinimumSize(new java.awt.Dimension(175, 24));
        jPanel56.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel56.setLayout(new javax.swing.BoxLayout(jPanel56, javax.swing.BoxLayout.LINE_AXIS));

        chkLilith.setSelected(true);
        jPanel56.add(chkLilith);

        chkTrueLilith.setSelected(true);
        jPanel56.add(chkTrueLilith);

        jPanel50.add(jPanel56);

        chkEast.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkEast);

        chkZenith.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkZenith);

        chkVertex.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkVertex);

        chkVulcan.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkVulcan);

        chkCeres.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkCeres);

        chkPallas.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkPallas);

        chkJuno.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkJuno);

        chkVesta.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkVesta);

        chkChiron.setSelected(true);
        chkChiron.setPreferredSize(new java.awt.Dimension(175, 24));
        jPanel50.add(chkChiron);

        chkOtherPoint.setPreferredSize(new java.awt.Dimension(175, 24));
        chkOtherPoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkOtherPointActionPerformed(evt);
            }
        });
        jPanel50.add(chkOtherPoint);

        jPanel54.add(jPanel50);

        pnlOtherPoint.setPreferredSize(new java.awt.Dimension(200, 600));
        pnlOtherPoint.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel125.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel125.setAlignmentX(0.5F);
        jLabel125.setOpaque(true);
        jLabel125.setPreferredSize(new java.awt.Dimension(175, 18));
        pnlOtherPoint.add(jLabel125);

        grpOtherPoint.add(optOtherPtStar);
        optOtherPtStar.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtStar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optOtherPtStarActionPerformed(evt);
            }
        });
        pnlOtherPoint.add(optOtherPtStar);

        pnlOtherPtStar.setPreferredSize(new java.awt.Dimension(175, 70));
        pnlOtherPtStar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 2));

        lblStarName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStarName.setPreferredSize(new java.awt.Dimension(175, 22));
        pnlOtherPtStar.add(lblStarName);

        cboStarIdentity.setPreferredSize(new java.awt.Dimension(175, 25));
        cboStarIdentity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStarIdentityActionPerformed(evt);
            }
        });
        pnlOtherPtStar.add(cboStarIdentity);

        pnlOtherPoint.add(pnlOtherPtStar);

        grpOtherPoint.add(optOtherPtPart);
        optOtherPtPart.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtPart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optOtherPtPartActionPerformed(evt);
            }
        });
        pnlOtherPoint.add(optOtherPtPart);

        pnlOtherPtPart.setPreferredSize(new java.awt.Dimension(175, 130));
        pnlOtherPtPart.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 5));

        cboPart.setPreferredSize(new java.awt.Dimension(175, 25));
        cboPart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPartActionPerformed(evt);
            }
        });
        pnlOtherPtPart.add(cboPart);

        jLabel126.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("=");
        jLabel126.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel126.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel126.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel126.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel126.setOpaque(true);
        jLabel126.setPreferredSize(new java.awt.Dimension(40, 24));
        pnlOtherPtPart.add(jLabel126);

        cboPartRef.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartRef.setEnabled(false);
        pnlOtherPtPart.add(cboPartRef);

        jLabel127.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel127.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel127.setText("+");
        jLabel127.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel127.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel127.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel127.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel127.setOpaque(true);
        jLabel127.setPreferredSize(new java.awt.Dimension(40, 24));
        pnlOtherPtPart.add(jLabel127);

        cboPartPlus.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartPlus.setEnabled(false);
        pnlOtherPtPart.add(cboPartPlus);

        jLabel128.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel128.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel128.setText("-");
        jLabel128.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel128.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel128.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel128.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel128.setOpaque(true);
        jLabel128.setPreferredSize(new java.awt.Dimension(40, 24));
        pnlOtherPtPart.add(jLabel128);

        cboPartMinus.setPreferredSize(new java.awt.Dimension(120, 25));
        cboPartMinus.setEnabled(false);
        pnlOtherPtPart.add(cboPartMinus);

        pnlOtherPoint.add(pnlOtherPtPart);

        grpOtherPoint.add(optOtherPtComet);
        optOtherPtComet.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtComet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optOtherPtCometActionPerformed(evt);
            }
        });
        pnlOtherPoint.add(optOtherPtComet);

        cboComet.setPreferredSize(new java.awt.Dimension(175, 25));
        pnlOtherPoint.add(cboComet);

        grpOtherPoint.add(optOtherPtAsteroid);
        optOtherPtAsteroid.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtAsteroid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optOtherPtAsteroidActionPerformed(evt);
            }
        });
        pnlOtherPoint.add(optOtherPtAsteroid);

        cboAsteroid.setPreferredSize(new java.awt.Dimension(175, 25));
        pnlOtherPoint.add(cboAsteroid);

        grpOtherPoint.add(optOtherPtNone);
        optOtherPtNone.setSelected(true);
        optOtherPtNone.setPreferredSize(new java.awt.Dimension(175, 24));
        optOtherPtNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optOtherPtNoneActionPerformed(evt);
            }
        });
        pnlOtherPoint.add(optOtherPtNone);

        jPanel54.add(pnlOtherPoint);

        jPanel52.setAlignmentX(0.0F);
        jPanel52.setAlignmentY(0.0F);
        jPanel52.setPreferredSize(new java.awt.Dimension(305, 600));
        jPanel52.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setAlignmentX(0.5F);
        jLabel46.setOpaque(true);
        jLabel46.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(jLabel46);

        jPanel57.setMaximumSize(new java.awt.Dimension(200, 85));
        jPanel57.setMinimumSize(new java.awt.Dimension(200, 85));
        jPanel57.setPreferredSize(new java.awt.Dimension(300, 85));
        jPanel57.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 5));

        chkStars.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel57.add(chkStars);

        sldStars.setMajorTickSpacing(2);
        sldStars.setMaximum(12);
        sldStars.setMinorTickSpacing(1);
        sldStars.setPaintTicks(true);
        sldStars.setValue(5);
        sldStars.setPreferredSize(new java.awt.Dimension(300, 31));
        jPanel57.add(sldStars);

        jLabel50.setBackground(new java.awt.Color(102, 200, 255));
        jLabel50.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel50.setText("-");
        jLabel50.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel50.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel50.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel50.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel50.setPreferredSize(new java.awt.Dimension(150, 18));
        jPanel57.add(jLabel50);

        jLabel52.setBackground(new java.awt.Color(102, 200, 255));
        jLabel52.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel52.setText("+");
        jLabel52.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel52.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel52.setMaximumSize(new java.awt.Dimension(110, 18));
        jLabel52.setMinimumSize(new java.awt.Dimension(110, 18));
        jLabel52.setPreferredSize(new java.awt.Dimension(150, 18));
        jPanel57.add(jLabel52);

        jPanel52.add(jPanel57);

        chkConstellations.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkConstellations);

        chkAsteroids.setSelected(true);
        chkAsteroids.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkAsteroids);

        chkHouses.setSelected(true);
        chkHouses.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkHouses);

        chkAspects.setSelected(true);
        chkAspects.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkAspects);

        chkCoordinates.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkCoordinates);

        chkStraightLines.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkStraightLines);

        chkShaded.setSelected(true);
        chkShaded.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkShaded);

        jPanel62.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel62.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel62.setPreferredSize(new java.awt.Dimension(210, 9));
        jPanel52.add(jPanel62);

        jPanel58.setMaximumSize(new java.awt.Dimension(210, 85));
        jPanel58.setMinimumSize(new java.awt.Dimension(210, 85));
        jPanel58.setPreferredSize(new java.awt.Dimension(300, 75));
        jPanel58.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        chkBarycenter.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel58.add(chkBarycenter);

        grpBarycenter.add(optSingleWeight);
        optSingleWeight.setSelected(true);
        optSingleWeight.setPreferredSize(new java.awt.Dimension(300, 24));
        jPanel58.add(optSingleWeight);

        grpBarycenter.add(optDifferentWeights);
        optDifferentWeights.setPreferredSize(new java.awt.Dimension(300, 24));
        jPanel58.add(optDifferentWeights);

        jPanel52.add(jPanel58);

        jPanel63.setMaximumSize(new java.awt.Dimension(210, 85));
        jPanel63.setMinimumSize(new java.awt.Dimension(210, 85));
        jPanel63.setPreferredSize(new java.awt.Dimension(300, 75));
        jPanel63.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel48.setAlignmentX(0.5F);
        jLabel48.setOpaque(true);
        jLabel48.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel63.add(jLabel48);

        grpZodDir.add(optEastAS);
        optEastAS.setSelected(true);
        optEastAS.setPreferredSize(new java.awt.Dimension(300, 24));
        jPanel63.add(optEastAS);

        grpZodDir.add(optEastAries);
        optEastAries.setPreferredSize(new java.awt.Dimension(300, 24));
        jPanel63.add(optEastAries);

        jPanel52.add(jPanel63);

        chkAspectsSymbol.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkAspectsSymbol);

        chkSignsName.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkSignsName);

        chkHousesCoord.setPreferredSize(new java.awt.Dimension(300, 18));
        jPanel52.add(chkHousesCoord);

        jPanel54.add(jPanel52);

        pnlPlanets.add(jPanel54, java.awt.BorderLayout.CENTER);

        tabSettings.addTab("Planets", null, pnlPlanets, "");

        pnlAspects.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlAspects.setLayout(new java.awt.BorderLayout());

        jPanel68.setPreferredSize(new java.awt.Dimension(500, 30));
        jPanel68.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        jPanel90.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel90.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel90.setPreferredSize(new java.awt.Dimension(210, 9));

        org.jdesktop.layout.GroupLayout jPanel90Layout = new org.jdesktop.layout.GroupLayout(jPanel90);
        jPanel90.setLayout(jPanel90Layout);
        jPanel90Layout.setHorizontalGroup(
            jPanel90Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 210, Short.MAX_VALUE)
        );
        jPanel90Layout.setVerticalGroup(
            jPanel90Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 9, Short.MAX_VALUE)
        );

        jPanel68.add(jPanel90);

        jPanel70.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel70.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setAlignmentX(0.5F);
        jLabel54.setOpaque(true);
        jLabel54.setPreferredSize(new java.awt.Dimension(410, 18));
        jPanel70.add(jLabel54);

        jPanel68.add(jPanel70);

        jPanel71.setPreferredSize(new java.awt.Dimension(500, 24));
        jPanel71.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));

        jPanel51.setPreferredSize(new java.awt.Dimension(490, 24));
        jPanel51.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        lblAspectsColorMode.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAspectsColorMode.setOpaque(true);
        lblAspectsColorMode.setPreferredSize(new java.awt.Dimension(135, 24));
        jPanel51.add(lblAspectsColorMode);

        grpColorMode.add(optColorMode1);
        optColorMode1.setSelected(true);
        optColorMode1.setPreferredSize(new java.awt.Dimension(150, 24));
        jPanel51.add(optColorMode1);

        grpColorMode.add(optColorMode2);
        optColorMode2.setPreferredSize(new java.awt.Dimension(160, 24));
        jPanel51.add(optColorMode2);

        jPanel71.add(jPanel51);

        jPanel68.add(jPanel71);

        jPanel72.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel72.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkConjunction.setBackground(new java.awt.Color(102, 204, 255));
        chkConjunction.setSelected(true);
        chkConjunction.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel72.add(chkConjunction);

        txtConjunction.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtConjunction.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtConjunction.setMaximumSize(new java.awt.Dimension(20, 20));
        txtConjunction.setMinimumSize(new java.awt.Dimension(20, 20));
        txtConjunction.setPreferredSize(new java.awt.Dimension(30, 20));
        txtConjunction.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtConjunctionkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtConjunctionKeyPressed(evt);
            }
        });
        jPanel72.add(txtConjunction);

        lblColorConjunction.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorConjunction.setOpaque(true);
        lblColorConjunction.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorConjunction.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorConjunctionMouseClicked(evt);
            }
        });
        jPanel72.add(lblColorConjunction);

        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel60.setText("0�");
        jLabel60.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel72.add(jLabel60);

        jLabel62.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel62.setText("a");
        jLabel62.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel72.add(jLabel62);

        jPanel68.add(jPanel72);

        jPanel73.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel73.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSextile.setBackground(new java.awt.Color(102, 204, 255));
        chkSextile.setSelected(true);
        chkSextile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel73.add(chkSextile);

        txtSextile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSextile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSextile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSextile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSextile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSextile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSextilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSextileKeyPressed(evt);
            }
        });
        jPanel73.add(txtSextile);

        lblColorSextile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSextile.setOpaque(true);
        lblColorSextile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSextile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSextileMouseClicked(evt);
            }
        });
        jPanel73.add(lblColorSextile);

        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel66.setText("60�");
        jLabel66.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel73.add(jLabel66);

        jLabel68.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel68.setText("b");
        jLabel68.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel73.add(jLabel68);

        jPanel68.add(jPanel73);

        jPanel74.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel74.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSquare.setBackground(new java.awt.Color(102, 204, 255));
        chkSquare.setSelected(true);
        chkSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel74.add(chkSquare);

        txtSquare.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSquare.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSquare.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSquare.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSquarekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSquareKeyPressed(evt);
            }
        });
        jPanel74.add(txtSquare);

        lblColorSquare.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSquare.setOpaque(true);
        lblColorSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSquare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSquareMouseClicked(evt);
            }
        });
        jPanel74.add(lblColorSquare);

        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel72.setText("90�");
        jLabel72.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel74.add(jLabel72);

        jLabel73.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel73.setText("c");
        jLabel73.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel74.add(jLabel73);

        jPanel68.add(jPanel74);

        jPanel75.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel75.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkTrine.setBackground(new java.awt.Color(102, 204, 255));
        chkTrine.setSelected(true);
        chkTrine.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel75.add(chkTrine);

        txtTrine.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtTrine.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTrine.setMaximumSize(new java.awt.Dimension(20, 20));
        txtTrine.setMinimumSize(new java.awt.Dimension(20, 20));
        txtTrine.setPreferredSize(new java.awt.Dimension(30, 20));
        txtTrine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTrinekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTrineKeyPressed(evt);
            }
        });
        jPanel75.add(txtTrine);

        lblColorTrine.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorTrine.setOpaque(true);
        lblColorTrine.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorTrine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorTrineMouseClicked(evt);
            }
        });
        jPanel75.add(lblColorTrine);

        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel75.setText("120�");
        jLabel75.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel75.add(jLabel75);

        jLabel76.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel76.setText("d");
        jLabel76.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel75.add(jLabel76);

        jPanel68.add(jPanel75);

        jPanel76.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel76.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkOpposition.setBackground(new java.awt.Color(102, 204, 255));
        chkOpposition.setSelected(true);
        chkOpposition.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel76.add(chkOpposition);

        txtOpposition.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtOpposition.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtOpposition.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOpposition.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOpposition.setPreferredSize(new java.awt.Dimension(30, 20));
        txtOpposition.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOppositionkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOppositionKeyPressed(evt);
            }
        });
        jPanel76.add(txtOpposition);

        lblColorOpposition.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorOpposition.setOpaque(true);
        lblColorOpposition.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorOpposition.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorOppositionMouseClicked(evt);
            }
        });
        jPanel76.add(lblColorOpposition);

        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel78.setText("180�");
        jLabel78.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel76.add(jLabel78);

        jLabel79.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel79.setText("e");
        jLabel79.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel76.add(jLabel79);

        jPanel68.add(jPanel76);

        jPanel77.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel77.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkVigintile.setBackground(new java.awt.Color(102, 204, 255));
        chkVigintile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel77.add(chkVigintile);

        txtVigintile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtVigintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtVigintile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtVigintile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtVigintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtVigintile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtVigintilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtVigintileKeyPressed(evt);
            }
        });
        jPanel77.add(txtVigintile);

        lblColorVigintile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorVigintile.setOpaque(true);
        lblColorVigintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorVigintile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorVigintileMouseClicked(evt);
            }
        });
        jPanel77.add(lblColorVigintile);

        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel81.setText("18�");
        jLabel81.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel77.add(jLabel81);

        jLabel82.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel82.setText("q");
        jLabel82.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel77.add(jLabel82);

        jPanel68.add(jPanel77);

        jPanel78.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel78.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiSextile.setBackground(new java.awt.Color(102, 204, 255));
        chkSemiSextile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel78.add(chkSemiSextile);

        txtSemiSextile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSemiSextile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSemiSextile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSemiSextile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSemiSextile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiSextile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSemiSextilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSemiSextileKeyPressed(evt);
            }
        });
        jPanel78.add(txtSemiSextile);

        lblColorSemiSextile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSemiSextile.setOpaque(true);
        lblColorSemiSextile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiSextile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSemiSextileMouseClicked(evt);
            }
        });
        jPanel78.add(lblColorSemiSextile);

        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel84.setText("30�");
        jLabel84.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel78.add(jLabel84);

        jLabel85.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel85.setText("f");
        jLabel85.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel78.add(jLabel85);

        jPanel68.add(jPanel78);

        jPanel79.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel79.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiQuintile.setBackground(new java.awt.Color(102, 204, 255));
        chkSemiQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel79.add(chkSemiQuintile);

        txtSemiQuintile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSemiQuintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSemiQuintile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSemiQuintile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSemiQuintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiQuintile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSemiQuintilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSemiQuintileKeyPressed(evt);
            }
        });
        jPanel79.add(txtSemiQuintile);

        lblColorSemiQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSemiQuintile.setOpaque(true);
        lblColorSemiQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiQuintile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSemiQuintileMouseClicked(evt);
            }
        });
        jPanel79.add(lblColorSemiQuintile);

        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel87.setText("36�");
        jLabel87.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel79.add(jLabel87);

        jLabel88.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel88.setText("g");
        jLabel88.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel79.add(jLabel88);

        jPanel68.add(jPanel79);

        jPanel80.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel80.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkNonagon.setBackground(new java.awt.Color(102, 204, 255));
        chkNonagon.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel80.add(chkNonagon);

        txtNonagone.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtNonagone.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNonagone.setMaximumSize(new java.awt.Dimension(20, 20));
        txtNonagone.setMinimumSize(new java.awt.Dimension(20, 20));
        txtNonagone.setPreferredSize(new java.awt.Dimension(30, 20));
        txtNonagone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNonagonekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNonagoneKeyPressed(evt);
            }
        });
        jPanel80.add(txtNonagone);

        lblColorNonagon.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorNonagon.setOpaque(true);
        lblColorNonagon.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorNonagon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorNonagonMouseClicked(evt);
            }
        });
        jPanel80.add(lblColorNonagon);

        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel90.setText("40�");
        jLabel90.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel80.add(jLabel90);

        jLabel91.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel91.setText("h");
        jLabel91.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel80.add(jLabel91);

        jPanel68.add(jPanel80);

        jPanel81.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel81.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSemiSquare.setBackground(new java.awt.Color(102, 204, 255));
        chkSemiSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel81.add(chkSemiSquare);

        txtSemiSquare.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSemiSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSemiSquare.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSemiSquare.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSemiSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSemiSquare.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSemiSquarekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSemiSquareKeyPressed(evt);
            }
        });
        jPanel81.add(txtSemiSquare);

        lblColorSemiSquare.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSemiSquare.setOpaque(true);
        lblColorSemiSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSemiSquare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSemiSquareMouseClicked(evt);
            }
        });
        jPanel81.add(lblColorSemiSquare);

        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel93.setText("45�");
        jLabel93.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel81.add(jLabel93);

        jLabel94.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel94.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel94.setText("i");
        jLabel94.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel81.add(jLabel94);

        jPanel68.add(jPanel81);

        jPanel82.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel82.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSeptile.setBackground(new java.awt.Color(102, 204, 255));
        chkSeptile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel82.add(chkSeptile);

        txtSeptile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSeptile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSeptile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSeptile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSeptile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSeptile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSeptilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSeptileKeyPressed(evt);
            }
        });
        jPanel82.add(txtSeptile);

        lblColorSeptile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSeptile.setOpaque(true);
        lblColorSeptile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSeptile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSeptileMouseClicked(evt);
            }
        });
        jPanel82.add(lblColorSeptile);

        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel96.setText("51�");
        jLabel96.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel82.add(jLabel96);

        jLabel97.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel97.setText("j");
        jLabel97.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel82.add(jLabel97);

        jPanel68.add(jPanel82);

        jPanel83.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel83.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkQuintile.setBackground(new java.awt.Color(102, 204, 255));
        chkQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel83.add(chkQuintile);

        txtQuintile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtQuintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtQuintile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtQuintile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtQuintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtQuintile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtQuintilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtQuintileKeyPressed(evt);
            }
        });
        jPanel83.add(txtQuintile);

        lblColorQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorQuintile.setOpaque(true);
        lblColorQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorQuintile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorQuintileMouseClicked(evt);
            }
        });
        jPanel83.add(lblColorQuintile);

        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel99.setText("72�");
        jLabel99.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel83.add(jLabel99);

        jLabel100.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel100.setText("k");
        jLabel100.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel83.add(jLabel100);

        jPanel68.add(jPanel83);

        jPanel84.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel84.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkTriDectile.setBackground(new java.awt.Color(102, 204, 255));
        chkTriDectile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel84.add(chkTriDectile);

        txtTriDectile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtTriDectile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTriDectile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtTriDectile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtTriDectile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtTriDectile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTriDectilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTriDectileKeyPressed(evt);
            }
        });
        jPanel84.add(txtTriDectile);

        lblColorTridectile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorTridectile.setOpaque(true);
        lblColorTridectile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorTridectile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorTridectileMouseClicked(evt);
            }
        });
        jPanel84.add(lblColorTridectile);

        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel102.setText("108�");
        jLabel102.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel84.add(jLabel102);

        jLabel103.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel103.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel103.setText("l");
        jLabel103.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel84.add(jLabel103);

        jPanel68.add(jPanel84);

        jPanel85.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel85.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkSesquiSquare.setBackground(new java.awt.Color(102, 204, 255));
        chkSesquiSquare.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel85.add(chkSesquiSquare);

        txtSesquiSquare.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtSesquiSquare.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSesquiSquare.setMaximumSize(new java.awt.Dimension(20, 20));
        txtSesquiSquare.setMinimumSize(new java.awt.Dimension(20, 20));
        txtSesquiSquare.setPreferredSize(new java.awt.Dimension(30, 20));
        txtSesquiSquare.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSesquiSquarekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSesquiSquareKeyPressed(evt);
            }
        });
        jPanel85.add(txtSesquiSquare);

        lblColorSesquiSquare.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorSesquiSquare.setOpaque(true);
        lblColorSesquiSquare.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorSesquiSquare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorSesquiSquareMouseClicked(evt);
            }
        });
        jPanel85.add(lblColorSesquiSquare);

        jLabel105.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel105.setText("135�");
        jLabel105.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel85.add(jLabel105);

        jLabel106.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel106.setText("m");
        jLabel106.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel85.add(jLabel106);

        jPanel68.add(jPanel85);

        jPanel86.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel86.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkBiQuintile.setBackground(new java.awt.Color(102, 204, 255));
        chkBiQuintile.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel86.add(chkBiQuintile);

        txtBiquintile.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtBiquintile.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtBiquintile.setMaximumSize(new java.awt.Dimension(20, 20));
        txtBiquintile.setMinimumSize(new java.awt.Dimension(20, 20));
        txtBiquintile.setPreferredSize(new java.awt.Dimension(30, 20));
        txtBiquintile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBiquintilekeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBiquintileKeyPressed(evt);
            }
        });
        jPanel86.add(txtBiquintile);

        lblColorBiQuintile.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorBiQuintile.setOpaque(true);
        lblColorBiQuintile.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorBiQuintile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorBiQuintileMouseClicked(evt);
            }
        });
        jPanel86.add(lblColorBiQuintile);

        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel108.setText("144�");
        jLabel108.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel86.add(jLabel108);

        jLabel109.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel109.setText("n");
        jLabel109.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel86.add(jLabel109);

        jPanel68.add(jPanel86);

        jPanel87.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel87.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkInconjunct.setBackground(new java.awt.Color(102, 204, 255));
        chkInconjunct.setSelected(true);
        chkInconjunct.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel87.add(chkInconjunct);

        txtInconjunct.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtInconjunct.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtInconjunct.setMaximumSize(new java.awt.Dimension(20, 20));
        txtInconjunct.setMinimumSize(new java.awt.Dimension(20, 20));
        txtInconjunct.setPreferredSize(new java.awt.Dimension(30, 20));
        txtInconjunct.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtInconjunctkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtInconjunctKeyPressed(evt);
            }
        });
        jPanel87.add(txtInconjunct);

        lblColorInconjunct.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorInconjunct.setOpaque(true);
        lblColorInconjunct.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorInconjunct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorInconjunctMouseClicked(evt);
            }
        });
        jPanel87.add(lblColorInconjunct);

        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111.setText("150�");
        jLabel111.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel87.add(jLabel111);

        jLabel112.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel112.setText("o");
        jLabel112.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel87.add(jLabel112);

        jPanel68.add(jPanel87);

        jPanel88.setPreferredSize(new java.awt.Dimension(410, 24));
        jPanel88.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkQuadriNonagon.setBackground(new java.awt.Color(102, 204, 255));
        chkQuadriNonagon.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel88.add(chkQuadriNonagon);

        txtQuadriNonagon.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtQuadriNonagon.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtQuadriNonagon.setMaximumSize(new java.awt.Dimension(20, 20));
        txtQuadriNonagon.setMinimumSize(new java.awt.Dimension(20, 20));
        txtQuadriNonagon.setPreferredSize(new java.awt.Dimension(30, 20));
        txtQuadriNonagon.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtQuadriNonagonkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtQuadriNonagonKeyPressed(evt);
            }
        });
        jPanel88.add(txtQuadriNonagon);

        lblColorQuadriNonagon.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorQuadriNonagon.setOpaque(true);
        lblColorQuadriNonagon.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorQuadriNonagon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorQuadriNonagonMouseClicked(evt);
            }
        });
        jPanel88.add(lblColorQuadriNonagon);

        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel114.setText("160�");
        jLabel114.setPreferredSize(new java.awt.Dimension(40, 16));
        jPanel88.add(jLabel114);

        jLabel115.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel115.setText("p");
        jLabel115.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel88.add(jLabel115);

        jPanel68.add(jPanel88);

        jPanel89.setPreferredSize(new java.awt.Dimension(410, 48));
        jPanel89.setRequestFocusEnabled(false);
        jPanel89.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        chkOtherAspect.setBackground(new java.awt.Color(102, 204, 255));
        chkOtherAspect.setPreferredSize(new java.awt.Dimension(160, 18));
        jPanel89.add(chkOtherAspect);

        txtOtherAspect.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txtOtherAspect.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtOtherAspect.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOtherAspect.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOtherAspect.setPreferredSize(new java.awt.Dimension(30, 20));
        txtOtherAspect.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOtherAspectkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOtherAspectKeyPressed(evt);
            }
        });
        jPanel89.add(txtOtherAspect);

        lblColorOtherAspect.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        lblColorOtherAspect.setOpaque(true);
        lblColorOtherAspect.setPreferredSize(new java.awt.Dimension(40, 18));
        lblColorOtherAspect.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblColorOtherAspectMouseClicked(evt);
            }
        });
        jPanel89.add(lblColorOtherAspect);

        txtValueOtherAspect.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        txtValueOtherAspect.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtValueOtherAspect.setText("0");
        txtValueOtherAspect.setMaximumSize(new java.awt.Dimension(20, 20));
        txtValueOtherAspect.setMinimumSize(new java.awt.Dimension(20, 20));
        txtValueOtherAspect.setPreferredSize(new java.awt.Dimension(40, 20));
        txtValueOtherAspect.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtValueOtherAspectFocusLost(evt);
            }
        });
        txtValueOtherAspect.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtValueOtherAspectkeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtValueOtherAspectKeyPressed(evt);
            }
        });
        jPanel89.add(txtValueOtherAspect);

        jLabel118.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel118.setText("r");
        jLabel118.setPreferredSize(new java.awt.Dimension(40, 24));
        jPanel89.add(jLabel118);

        jLabel129.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel129.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        jLabel129.setMaximumSize(new java.awt.Dimension(175, 18));
        jLabel129.setMinimumSize(new java.awt.Dimension(175, 18));
        jLabel129.setOpaque(true);
        jLabel129.setPreferredSize(new java.awt.Dimension(175, 18));
        jPanel89.add(jLabel129);

        txtOtherAspectName.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        txtOtherAspectName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOtherAspectName.setMaximumSize(new java.awt.Dimension(20, 20));
        txtOtherAspectName.setMinimumSize(new java.awt.Dimension(20, 20));
        txtOtherAspectName.setPreferredSize(new java.awt.Dimension(175, 20));
        txtOtherAspectName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOtherAspectNameKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOtherAspectNameKeyPressed(evt);
            }
        });
        jPanel89.add(txtOtherAspectName);

        jPanel68.add(jPanel89);

        pnlAspects.add(jPanel68, java.awt.BorderLayout.WEST);

        pnlAspectColorChoice.setLayout(new javax.swing.BoxLayout(pnlAspectColorChoice, javax.swing.BoxLayout.Y_AXIS));

        jPanel94.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel94.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel94.setPreferredSize(new java.awt.Dimension(210, 9));
        pnlAspectColorChoice.add(jPanel94);

        pnlAspects.add(pnlAspectColorChoice, java.awt.BorderLayout.CENTER);

        jPanel69.setPreferredSize(new java.awt.Dimension(150, 34));
        jPanel69.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 0));

        jPanel91.setMaximumSize(new java.awt.Dimension(210, 9));
        jPanel91.setMinimumSize(new java.awt.Dimension(210, 9));
        jPanel91.setPreferredSize(new java.awt.Dimension(150, 14));
        jPanel69.add(jPanel91);

        jPanel92.setPreferredSize(new java.awt.Dimension(150, 24));
        jPanel92.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel119.setAlignmentX(0.5F);
        jLabel119.setOpaque(true);
        jLabel119.setPreferredSize(new java.awt.Dimension(140, 18));
        jPanel92.add(jLabel119);

        jPanel69.add(jPanel92);

        chkAspectSun.setSelected(true);
        chkAspectSun.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectSun);

        chkAspectMoon.setSelected(true);
        chkAspectMoon.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectMoon);

        chkAspectMercury.setSelected(true);
        chkAspectMercury.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectMercury);

        chkAspectVenus.setSelected(true);
        chkAspectVenus.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectVenus);

        chkAspectMars.setSelected(true);
        chkAspectMars.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectMars);

        chkAspectJupiter.setSelected(true);
        chkAspectJupiter.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectJupiter);

        chkAspectSaturn.setSelected(true);
        chkAspectSaturn.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectSaturn);

        chkAspectUranus.setSelected(true);
        chkAspectUranus.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectUranus);

        chkAspectNeptune.setSelected(true);
        chkAspectNeptune.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectNeptune);

        chkAspectPluto.setSelected(true);
        chkAspectPluto.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectPluto);

        chkAspectGaia.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectGaia);

        chkAspectNodes.setSelected(true);
        chkAspectNodes.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectNodes);

        chkAspectLilith.setSelected(true);
        chkAspectLilith.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectLilith);

        chkAspectEast.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectEast);

        chkAspectZenith.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectZenith);

        chkAspectVertex.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectVertex);

        chkAspectVulcan.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectVulcan);

        chkAspectCeres.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectCeres);

        chkAspectPallas.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectPallas);

        chkAspectJuno.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectJuno);

        chkAspectVesta.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectVesta);

        chkAspectChiron.setSelected(true);
        chkAspectChiron.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectChiron);

        chkAspectAS.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectAS);

        chkAspectMC.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectMC);

        chkAspectOtherPoint.setPreferredSize(new java.awt.Dimension(140, 20));
        jPanel69.add(chkAspectOtherPoint);

        pnlAspects.add(jPanel69, java.awt.BorderLayout.EAST);

        tabSettings.addTab("Aspects", null, pnlAspects, "");

        pnlOrbs.setMinimumSize(new java.awt.Dimension(500, 400));
        pnlOrbs.setPreferredSize(new java.awt.Dimension(1000, 400));
        pnlOrbs.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 85));

        jPanel93.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel93.setPreferredSize(new java.awt.Dimension(700, 230));
        jPanel93.setLayout(new java.awt.GridLayout(7, 7));
        jPanel93.add(jPanel96);

        jLabel58.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(51, 153, 255));
        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel58.setText("AB");
        jLabel58.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel58.setPreferredSize(new java.awt.Dimension(90, 24));
        jPanel97.add(jLabel58);

        jPanel93.add(jPanel97);

        jLabel64.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(51, 102, 255));
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("CDE");
        jLabel64.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel64.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel98.add(jLabel64);

        jPanel93.add(jPanel98);

        jLabel70.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(0, 51, 255));
        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText("FG");
        jLabel70.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel70.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel99.add(jLabel70);

        jPanel93.add(jPanel99);

        jLabel74.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(0, 0, 204));
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setText("HIJKQ...");
        jLabel74.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel74.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel100.add(jLabel74);

        jPanel93.add(jPanel100);

        jLabel77.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(51, 0, 153));
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel77.setText("LMX Y");
        jLabel77.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel77.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel101.add(jLabel77);

        jPanel93.add(jPanel101);

        jLabel80.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel80.setText("NOPR");
        jLabel80.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel80.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel102.add(jLabel80);

        jPanel93.add(jPanel102);

        jLabel83.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(51, 153, 255));
        jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel83.setText("AB");
        jLabel83.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel83.setPreferredSize(new java.awt.Dimension(90, 24));
        jPanel103.add(jLabel83);

        jPanel93.add(jPanel103);

        txtOrbLumLum.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumLum.setText("0");
        txtOrbLumLum.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumLum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumLumKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumLumkeyTyped(evt);
            }
        });
        jPanel104.add(txtOrbLumLum);

        jPanel93.add(jPanel104);

        txtOrbLumIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumIndiv.setText("0");
        txtOrbLumIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumIndiv.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumIndivKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumIndivkeyTyped(evt);
            }
        });
        jPanel105.add(txtOrbLumIndiv);

        jPanel93.add(jPanel105);

        txtOrbLumJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumJS.setText("0");
        txtOrbLumJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumJSkeyTyped(evt);
            }
        });
        jPanel106.add(txtOrbLumJS);

        jPanel93.add(jPanel106);

        txtOrbLumCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumCol.setText("0");
        txtOrbLumCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumColkeyTyped(evt);
            }
        });
        jPanel107.add(txtOrbLumCol);

        jPanel93.add(jPanel107);

        txtOrbLumVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMaj.setText("0");
        txtOrbLumVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMajkeyTyped(evt);
            }
        });
        jPanel108.add(txtOrbLumVirtMaj);

        jPanel93.add(jPanel108);

        txtOrbLumVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbLumVirtMin.setText("0");
        txtOrbLumVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbLumVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbLumVirtMinkeyTyped(evt);
            }
        });
        jPanel109.add(txtOrbLumVirtMin);

        jPanel93.add(jPanel109);

        jLabel86.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(51, 102, 255));
        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel86.setText("CDE");
        jLabel86.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel86.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel110.add(jLabel86);

        jPanel93.add(jPanel110);
        jPanel93.add(jPanel111);

        txtOrbIndivIndiv.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivIndiv.setText("0");
        txtOrbIndivIndiv.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivIndiv.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivIndivKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivIndivkeyTyped(evt);
            }
        });
        jPanel113.add(txtOrbIndivIndiv);

        jPanel93.add(jPanel113);

        txtOrbIndivJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivJS.setText("0");
        txtOrbIndivJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivJSkeyTyped(evt);
            }
        });
        jPanel114.add(txtOrbIndivJS);

        jPanel93.add(jPanel114);

        txtOrbIndivCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivCol.setText("0");
        txtOrbIndivCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivColkeyTyped(evt);
            }
        });
        jPanel115.add(txtOrbIndivCol);

        jPanel93.add(jPanel115);

        txtOrbIndivVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMaj.setText("0");
        txtOrbIndivVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMajkeyTyped(evt);
            }
        });
        jPanel116.add(txtOrbIndivVirtMaj);

        jPanel93.add(jPanel116);

        txtOrbIndivVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbIndivVirtMin.setText("0");
        txtOrbIndivVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbIndivVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbIndivVirtMinkeyTyped(evt);
            }
        });
        jPanel117.add(txtOrbIndivVirtMin);

        jPanel93.add(jPanel117);

        jLabel89.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(0, 51, 255));
        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("FG");
        jLabel89.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel89.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel118.add(jLabel89);

        jPanel93.add(jPanel118);
        jPanel93.add(jPanel119);
        jPanel93.add(jPanel120);

        txtOrbJSJS.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSJS.setText("0");
        txtOrbJSJS.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSJS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSJSKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSJSkeyTyped(evt);
            }
        });
        jPanel121.add(txtOrbJSJS);

        jPanel93.add(jPanel121);

        txtOrbJSCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSCol.setText("0");
        txtOrbJSCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSColkeyTyped(evt);
            }
        });
        jPanel122.add(txtOrbJSCol);

        jPanel93.add(jPanel122);

        txtOrbJSvirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSvirtMaj.setText("0");
        txtOrbJSvirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSvirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSvirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSvirtMajkeyTyped(evt);
            }
        });
        jPanel123.add(txtOrbJSvirtMaj);

        jPanel93.add(jPanel123);

        txtOrbJSVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbJSVirtMin.setText("0");
        txtOrbJSVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbJSVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbJSVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbJSVirtMinkeyTyped(evt);
            }
        });
        jPanel124.add(txtOrbJSVirtMin);

        jPanel93.add(jPanel124);

        jLabel92.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(0, 0, 204));
        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel92.setText("HIJKQ...");
        jLabel92.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel92.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel125.add(jLabel92);

        jPanel93.add(jPanel125);
        jPanel93.add(jPanel126);
        jPanel93.add(jPanel127);
        jPanel93.add(jPanel128);

        txtOrbColCol.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColCol.setText("0");
        txtOrbColCol.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColCol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColColKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColColkeyTyped(evt);
            }
        });
        jPanel129.add(txtOrbColCol);

        jPanel93.add(jPanel129);

        txtOrbColVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMaj.setText("0");
        txtOrbColVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMajkeyTyped(evt);
            }
        });
        jPanel130.add(txtOrbColVirtMaj);

        jPanel93.add(jPanel130);

        txtOrbColVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbColVirtMin.setText("0");
        txtOrbColVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbColVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbColVirtMinkeyTyped(evt);
            }
        });
        jPanel131.add(txtOrbColVirtMin);

        jPanel93.add(jPanel131);

        jLabel95.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(51, 0, 153));
        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel95.setText("LMX Y");
        jLabel95.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel95.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel132.add(jLabel95);

        jPanel93.add(jPanel132);
        jPanel93.add(jPanel133);
        jPanel93.add(jPanel134);
        jPanel93.add(jPanel135);
        jPanel93.add(jPanel136);

        txtOrbVirtMajVirtMaj.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMaj.setText("0");
        txtOrbVirtMajVirtMaj.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMaj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMajKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMajkeyTyped(evt);
            }
        });
        jPanel137.add(txtOrbVirtMajVirtMaj);

        jPanel93.add(jPanel137);

        txtOrbVirtMajVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbVirtMajVirtMin.setText("0");
        txtOrbVirtMajVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbVirtMajVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbVirtMajVirtMinkeyTyped(evt);
            }
        });
        jPanel138.add(txtOrbVirtMajVirtMin);

        jPanel93.add(jPanel138);

        jLabel98.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel98.setText("NOPR");
        jLabel98.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel98.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel139.add(jLabel98);

        jPanel93.add(jPanel139);
        jPanel93.add(jPanel140);
        jPanel93.add(jPanel141);
        jPanel93.add(jPanel142);
        jPanel93.add(jPanel143);
        jPanel93.add(jPanel144);

        txtOrbvirtMinVirtMin.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtOrbvirtMinVirtMin.setText("0");
        txtOrbvirtMinVirtMin.setPreferredSize(new java.awt.Dimension(40, 20));
        txtOrbvirtMinVirtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrbvirtMinVirtMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOrbvirtMinVirtMinkeyTyped(evt);
            }
        });
        jPanel112.add(txtOrbvirtMinVirtMin);

        jPanel93.add(jPanel112);

        pnlOrbs.add(jPanel93);

        jPanel95.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel95.setPreferredSize(new java.awt.Dimension(600, 80));
        jPanel95.setLayout(new java.awt.GridLayout(2, 6));

        jLabel101.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(51, 153, 255));
        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel101.setText("a");
        jLabel101.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel101.setPreferredSize(new java.awt.Dimension(90, 24));
        jPanel145.add(jLabel101);

        jPanel95.add(jPanel145);

        jLabel104.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(51, 102, 255));
        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel104.setText("b");
        jLabel104.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel104.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel146.add(jLabel104);

        jPanel95.add(jPanel146);

        jLabel107.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel107.setForeground(new java.awt.Color(0, 51, 255));
        jLabel107.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel107.setText("c");
        jLabel107.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel107.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel147.add(jLabel107);

        jPanel95.add(jPanel147);

        jLabel110.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(0, 0, 204));
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("d");
        jLabel110.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel110.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel148.add(jLabel110);

        jPanel95.add(jPanel148);

        jLabel113.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel113.setForeground(new java.awt.Color(51, 0, 153));
        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel113.setText("e");
        jLabel113.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel113.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel149.add(jLabel113);

        jPanel95.add(jPanel149);

        jLabel116.setFont(new java.awt.Font("StarLogin", 1, 18)); // NOI18N
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("...");
        jLabel116.setPreferredSize(new java.awt.Dimension(90, 24));
        jLabel116.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel150.add(jLabel116);

        jPanel95.add(jPanel150);

        jPanel151.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel117.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel117.setText("/");
        jLabel117.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel117.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel151.add(jLabel117);

        txtDivConjunction.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivConjunction.setText("0");
        txtDivConjunction.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivConjunction.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivConjunctionFocusLost(evt);
            }
        });
        txtDivConjunction.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivConjunctionKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivConjunctionkeyTyped(evt);
            }
        });
        jPanel151.add(txtDivConjunction);

        jPanel95.add(jPanel151);

        jPanel152.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel120.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("/");
        jLabel120.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel120.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel152.add(jLabel120);

        txtDivSextile.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSextile.setText("0");
        txtDivSextile.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSextile.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivSextileFocusLost(evt);
            }
        });
        txtDivSextile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivSextileKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivSextilekeyTyped(evt);
            }
        });
        jPanel152.add(txtDivSextile);

        jPanel95.add(jPanel152);

        jPanel153.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel121.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("/");
        jLabel121.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel121.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel153.add(jLabel121);

        txtDivSquare.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivSquare.setText("0");
        txtDivSquare.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivSquare.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivSquareFocusLost(evt);
            }
        });
        txtDivSquare.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivSquareKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivSquarekeyTyped(evt);
            }
        });
        jPanel153.add(txtDivSquare);

        jPanel95.add(jPanel153);

        jPanel154.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel122.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("/");
        jLabel122.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel122.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel154.add(jLabel122);

        txtDivTrine.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivTrine.setText("0");
        txtDivTrine.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivTrine.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivTrineFocusLost(evt);
            }
        });
        txtDivTrine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivTrineKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivTrinekeyTyped(evt);
            }
        });
        jPanel154.add(txtDivTrine);

        jPanel95.add(jPanel154);

        jPanel155.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel123.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel123.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel123.setText("/");
        jLabel123.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel123.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel155.add(jLabel123);

        txtDivOpposition.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOpposition.setText("0");
        txtDivOpposition.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOpposition.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivOppositionFocusLost(evt);
            }
        });
        txtDivOpposition.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivOppositionKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivOppositionkeyTyped(evt);
            }
        });
        jPanel155.add(txtDivOpposition);

        jPanel95.add(jPanel155);

        jPanel156.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 0));

        jLabel124.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("/");
        jLabel124.setPreferredSize(new java.awt.Dimension(20, 24));
        jLabel124.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel156.add(jLabel124);

        txtDivOther.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtDivOther.setText("0");
        txtDivOther.setPreferredSize(new java.awt.Dimension(40, 20));
        txtDivOther.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDivOtherFocusLost(evt);
            }
        });
        txtDivOther.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDivOtherKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDivOtherkeyTyped(evt);
            }
        });
        jPanel156.add(txtDivOther);

        jPanel95.add(jPanel156);

        pnlOrbs.add(jPanel95);

        tabSettings.addTab("Orbs", null, pnlOrbs, "");

        getContentPane().add(tabSettings, java.awt.BorderLayout.NORTH);

        pnl2.setPreferredSize(new java.awt.Dimension(1015, 70));
        pnl2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 40, 5));

        jPanel67.setPreferredSize(new java.awt.Dimension(330, 46));
        jPanel67.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnDisplayCharts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/carter.png"))); // NOI18N
        btnDisplayCharts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnDisplayCharts.setPreferredSize(new java.awt.Dimension(330, 35));
        btnDisplayCharts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayChartsActionPerformed(evt);
            }
        });
        jPanel67.add(btnDisplayCharts);

        lblForEvent.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblForEvent.setPreferredSize(new java.awt.Dimension(530, 22));
        jPanel67.add(lblForEvent);

        pnl2.add(jPanel67);

        jPanel59.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 255, 255), java.awt.Color.gray));
        jPanel59.setPreferredSize(new java.awt.Dimension(560, 58));

        btnReadChart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/savedcarte.png"))); // NOI18N
        btnReadChart.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnReadChart.setPreferredSize(new java.awt.Dimension(320, 35));
        btnReadChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReadChartActionPerformed(evt);
            }
        });
        jPanel59.add(btnReadChart);

        pnl1.setPreferredSize(new java.awt.Dimension(220, 44));
        pnl1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        grpSavedCharts.add(optLastSavedChart);
        optLastSavedChart.setPreferredSize(new java.awt.Dimension(220, 22));
        pnl1.add(optLastSavedChart);

        grpSavedCharts.add(optSavedChart);
        optSavedChart.setSelected(true);
        optSavedChart.setPreferredSize(new java.awt.Dimension(220, 22));
        pnl1.add(optSavedChart);

        jPanel59.add(pnl1);

        pnl2.add(jPanel59);

        getContentPane().add(pnl2, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chkDomitudesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkDomitudesActionPerformed
        currentSelectedCoordSystem = CoordSystem.Domitudes;
    }//GEN-LAST:event_chkDomitudesActionPerformed

    private void txtDivOtherKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOtherKeyPressed
    {//GEN-HEADEREND:event_txtDivOtherKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivOtherKeyPressed

    private void txtDivOppositionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOppositionKeyPressed
    {//GEN-HEADEREND:event_txtDivOppositionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivOppositionKeyPressed

    private void txtDivTrineKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivTrineKeyPressed
    {//GEN-HEADEREND:event_txtDivTrineKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivTrineKeyPressed

    private void txtDivSquareKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSquareKeyPressed
    {//GEN-HEADEREND:event_txtDivSquareKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivSquareKeyPressed

    private void txtDivSextileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSextileKeyPressed
    {//GEN-HEADEREND:event_txtDivSextileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivSextileKeyPressed

    private void txtDivConjunctionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivConjunctionKeyPressed
    {//GEN-HEADEREND:event_txtDivConjunctionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDivConjunctionKeyPressed

    private void txtOrbvirtMinVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbvirtMinVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbvirtMinVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbvirtMinVirtMinKeyPressed

    private void txtOrbVirtMajVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbVirtMajVirtMinKeyPressed

    private void txtOrbColVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbColVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColVirtMinKeyPressed

    private void txtOrbJSVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSVirtMinKeyPressed

    private void txtOrbIndivVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivVirtMinKeyPressed

    private void txtOrbLumVirtMinKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMinKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumVirtMinKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumVirtMinKeyPressed

    private void txtOrbVirtMajVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbVirtMajVirtMajKeyPressed

    private void txtOrbColVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbColVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColVirtMajKeyPressed

    private void txtOrbJSvirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSvirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSvirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSvirtMajKeyPressed

    private void txtOrbIndivVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivVirtMajKeyPressed

    private void txtOrbLumVirtMajKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMajKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumVirtMajKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumVirtMajKeyPressed

    private void txtOrbColColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColColKeyPressed
    {//GEN-HEADEREND:event_txtOrbColColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbColColKeyPressed

    private void txtOrbJSColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSColKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSColKeyPressed

    private void txtOrbIndivColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivColKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivColKeyPressed

    private void txtOrbLumColKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumColKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumColKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumColKeyPressed

    private void txtOrbIndivJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivJSKeyPressed

    private void txtOrbJSJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbJSJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbJSJSKeyPressed

    private void txtOrbLumJSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumJSKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumJSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumJSKeyPressed

    private void txtOrbIndivIndivKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivIndivKeyPressed
    {//GEN-HEADEREND:event_txtOrbIndivIndivKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbIndivIndivKeyPressed

    private void txtOrbLumIndivKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumIndivKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumIndivKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumIndivKeyPressed

    private void txtOrbLumLumKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumLumKeyPressed
    {//GEN-HEADEREND:event_txtOrbLumLumKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOrbLumLumKeyPressed

    private void txtOtherAspectNameKeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherAspectNameKeyTyped
    {//GEN-HEADEREND:event_txtOtherAspectNameKeyTyped
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOtherAspectNameKeyTyped

    private void txtOtherAspectNameKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherAspectNameKeyPressed
    {//GEN-HEADEREND:event_txtOtherAspectNameKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOtherAspectNameKeyPressed

    private void txtValueOtherAspectKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtValueOtherAspectKeyPressed
    {//GEN-HEADEREND:event_txtValueOtherAspectKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtValueOtherAspectKeyPressed

    private void txtOtherAspectKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherAspectKeyPressed
    {//GEN-HEADEREND:event_txtOtherAspectKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOtherAspectKeyPressed

    private void txtQuadriNonagonKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtQuadriNonagonKeyPressed
    {//GEN-HEADEREND:event_txtQuadriNonagonKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtQuadriNonagonKeyPressed

    private void txtInconjunctKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtInconjunctKeyPressed
    {//GEN-HEADEREND:event_txtInconjunctKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtInconjunctKeyPressed

    private void txtBiquintileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBiquintileKeyPressed
    {//GEN-HEADEREND:event_txtBiquintileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtBiquintileKeyPressed

    private void txtSesquiSquareKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSesquiSquareKeyPressed
    {//GEN-HEADEREND:event_txtSesquiSquareKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSesquiSquareKeyPressed

    private void txtTriDectileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTriDectileKeyPressed
    {//GEN-HEADEREND:event_txtTriDectileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtTriDectileKeyPressed

    private void txtQuintileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtQuintileKeyPressed
    {//GEN-HEADEREND:event_txtQuintileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtQuintileKeyPressed

    private void txtSeptileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSeptileKeyPressed
    {//GEN-HEADEREND:event_txtSeptileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSeptileKeyPressed

    private void txtSemiSquareKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiSquareKeyPressed
    {//GEN-HEADEREND:event_txtSemiSquareKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSemiSquareKeyPressed

    private void txtNonagoneKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNonagoneKeyPressed
    {//GEN-HEADEREND:event_txtNonagoneKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtNonagoneKeyPressed

    private void txtSemiQuintileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiQuintileKeyPressed
    {//GEN-HEADEREND:event_txtSemiQuintileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSemiQuintileKeyPressed

    private void txtSemiSextileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiSextileKeyPressed
    {//GEN-HEADEREND:event_txtSemiSextileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSemiSextileKeyPressed

    private void txtVigintileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVigintileKeyPressed
    {//GEN-HEADEREND:event_txtVigintileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtVigintileKeyPressed

    private void txtOppositionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOppositionKeyPressed
    {//GEN-HEADEREND:event_txtOppositionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtOppositionKeyPressed

    private void txtTrineKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTrineKeyPressed
    {//GEN-HEADEREND:event_txtTrineKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtTrineKeyPressed

    private void txtSquareKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSquareKeyPressed
    {//GEN-HEADEREND:event_txtSquareKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSquareKeyPressed

    private void txtSextileKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSextileKeyPressed
    {//GEN-HEADEREND:event_txtSextileKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtSextileKeyPressed

    private void txtConjunctionKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConjunctionKeyPressed
    {//GEN-HEADEREND:event_txtConjunctionKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtConjunctionKeyPressed

    private void txtHarmonicNBKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHarmonicNBKeyPressed
    {//GEN-HEADEREND:event_txtHarmonicNBKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtHarmonicNBKeyPressed

    private void txtLongitudeCycleKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeCycleKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeCycleKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeCycle.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudeCycle, kc);
    }//GEN-LAST:event_txtLongitudeCycleKeyPressed

    private void txtLatitudeCycleKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeCycleKeyPressed
    {//GEN-HEADEREND:event_txtLatitudeCycleKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudeCycle.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudeCycle, kc);
    }//GEN-LAST:event_txtLatitudeCycleKeyPressed

    private void txtCyclesNBKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCyclesNBKeyPressed
    {//GEN-HEADEREND:event_txtCyclesNBKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtCyclesNBKeyPressed

    private void txtLongitudeReturnKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeReturnKeyPressed
    {//GEN-HEADEREND:event_txtLongitudeReturnKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLongitudeReturn.getCaretPosition();
        }
        KTLongitude lng;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lng = new KTLongitude(evt, txtLongitudeReturn, kc);
    }//GEN-LAST:event_txtLongitudeReturnKeyPressed

    private void txtLatitudeReturnKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeReturnKeyPressed
    {//GEN-HEADEREND:event_txtLatitudeReturnKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
            cp = txtLatitudeReturn.getCaretPosition();
        }
        KTLatitude lat;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            lat = new KTLatitude(evt, txtLatitudeReturn, kc);
    }//GEN-LAST:event_txtLatitudeReturnKeyPressed

    private void txtRevolNBKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRevolNBKeyPressed
    {//GEN-HEADEREND:event_txtRevolNBKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtRevolNBKeyPressed

    private void txtTransitsDateKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTransitsDateKeyPressed
    {//GEN-HEADEREND:event_txtTransitsDateKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
        
        KTDateAstro td;
        if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
            td = new KTDateAstro(evt, txtTransitsDate, kc);
    }//GEN-LAST:event_txtTransitsDateKeyPressed

    private void txtEqualsD2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsD2KeyPressed
    {//GEN-HEADEREND:event_txtEqualsD2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtEqualsD2KeyPressed

    private void txtEqualsD1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsD1KeyPressed
    {//GEN-HEADEREND:event_txtEqualsD1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtEqualsD1KeyPressed

    private void txtEqualsDSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsDSKeyPressed
    {//GEN-HEADEREND:event_txtEqualsDSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtEqualsDSKeyPressed

    private void txtCorrespondD2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondD2KeyPressed
    {//GEN-HEADEREND:event_txtCorrespondD2KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtCorrespondD2KeyPressed

    private void txtDir2AgeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDir2AgeKeyPressed
    {//GEN-HEADEREND:event_txtDir2AgeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDir2AgeKeyPressed

    private void txtCorrespondD1KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondD1KeyPressed
    {//GEN-HEADEREND:event_txtCorrespondD1KeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtCorrespondD1KeyPressed

    private void txtDir1AgeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDir1AgeKeyPressed
    {//GEN-HEADEREND:event_txtDir1AgeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDir1AgeKeyPressed

    private void txtCorrespondDSKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondDSKeyPressed
    {//GEN-HEADEREND:event_txtCorrespondDSKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtCorrespondDSKeyPressed

    private void txtDirSAgeKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDirSAgeKeyPressed
    {//GEN-HEADEREND:event_txtDirSAgeKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT) kc = evt.getKeyCode();
    }//GEN-LAST:event_txtDirSAgeKeyPressed

    private void txtTransitsDateFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtTransitsDateFocusLost
    {//GEN-HEADEREND:event_txtTransitsDateFocusLost
        FDate dat = new FDate(txtTransitsDate.getText());
        String sText = dat.getDate();
        txtTransitsDate.setText(sText);
    }//GEN-LAST:event_txtTransitsDateFocusLost

    private void txtLongitudeCycleFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeCycleFocusLost
    {//GEN-HEADEREND:event_txtLongitudeCycleFocusLost
        FLongitude l = new FLongitude(txtLongitudeCycle.getText());
        String sText = l.getLongitude();
        txtLongitudeCycle.setText(sText);
    }//GEN-LAST:event_txtLongitudeCycleFocusLost

    private void txtLongitudeReturnFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLongitudeReturnFocusLost
    {//GEN-HEADEREND:event_txtLongitudeReturnFocusLost
        FLongitude l = new FLongitude(txtLongitudeReturn.getText());
        String sText = l.getLongitude();
        txtLongitudeReturn.setText(sText);
    }//GEN-LAST:event_txtLongitudeReturnFocusLost

    private void txtLatitudeCycleFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudeCycleFocusLost
    {//GEN-HEADEREND:event_txtLatitudeCycleFocusLost
        FLatitude l = new FLatitude(txtLatitudeCycle.getText());
        String sText = l.getLatitude();
        txtLatitudeCycle.setText(sText);
    }//GEN-LAST:event_txtLatitudeCycleFocusLost

    private void txtLatitudeReturnFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtLatitudeReturnFocusLost
    {//GEN-HEADEREND:event_txtLatitudeReturnFocusLost
        FLatitude l = new FLatitude(txtLatitudeReturn.getText());
        String sText = l.getLatitude();
        txtLatitudeReturn.setText(sText);
    }//GEN-LAST:event_txtLatitudeReturnFocusLost
    
	private void txtCompositeChartsNBFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtCompositeChartsNBFocusLost
	{//GEN-HEADEREND:event_txtCompositeChartsNBFocusLost
            if (txtCompositeChartsNB.getText().equals("") || txtCompositeChartsNB.getText().equals("1")) txtCompositeChartsNB.setText("2");
            lblRemainEventComposite.setText(txtCompositeChartsNB.getText());
	}//GEN-LAST:event_txtCompositeChartsNBFocusLost
        
    private void txtHarmonicNBFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtHarmonicNBFocusLost
    {//GEN-HEADEREND:event_txtHarmonicNBFocusLost
        if (txtHarmonicNB.getText().equals("")) txtHarmonicNB.setText("0");
        Integer i = new Integer(txtHarmonicNB.getText());
        String sText = i.toString();
        txtHarmonicNB.setText(sText);
    }//GEN-LAST:event_txtHarmonicNBFocusLost
    
    private void txtCyclesNBFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtCyclesNBFocusLost
    {//GEN-HEADEREND:event_txtCyclesNBFocusLost
        if (txtCyclesNB.getText().equals("")) txtCyclesNB.setText("0");
        Double d = new Double(txtCyclesNB.getText());
        String sText = d.toString();
        txtCyclesNB.setText(sText);
    }//GEN-LAST:event_txtCyclesNBFocusLost
    
    private void txtDir2AgeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDir2AgeFocusLost
    {//GEN-HEADEREND:event_txtDir2AgeFocusLost
        if (txtDir2Age.getText().equals("")) txtDir2Age.setText("0");
        Double d = new Double(txtDir2Age.getText());
        String sText = d.toString();
        txtDir2Age.setText(sText);
    }//GEN-LAST:event_txtDir2AgeFocusLost
    
    private void txtDir1AgeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDir1AgeFocusLost
    {//GEN-HEADEREND:event_txtDir1AgeFocusLost
        if (txtDir1Age.getText().equals("")) txtDir1Age.setText("0");
        Double d = new Double(txtDir1Age.getText());
        String sText = d.toString();
        txtDir1Age.setText(sText);
    }//GEN-LAST:event_txtDir1AgeFocusLost
    
    private void txtDirSAgeFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDirSAgeFocusLost
    {//GEN-HEADEREND:event_txtDirSAgeFocusLost
        if (txtDirSAge.getText().equals("")) txtDirSAge.setText("0");
        Double d = new Double(txtDirSAge.getText());
        String sText = d.toString();
        txtDirSAge.setText(sText);
    }//GEN-LAST:event_txtDirSAgeFocusLost
    
    private void btnReadChartActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnReadChartActionPerformed
    {//GEN-HEADEREND:event_btnReadChartActionPerformed
        Chart chart = new Chart();
        if (optSavedChart.isSelected())
        {
            new ChartSelectionDialog(new JFrame(), true, this, starLoginManager).setVisible(true);
            if (selectedChartID == null) return;
            chart = starLoginManager.getChart(selectedChartID);
        }
        else if (optLastSavedChart.isSelected())
        {
            Charts charts = starLoginManager.getCharts();
            ArrayList v = charts.getRecords();
            if (v == null || v.isEmpty())
            {
                JOptionPane.showMessageDialog(this, bundle.getString("NoExistingChart"), "StarLogin", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            int chartID = -1;
            for (int i = 0; i < v.size(); i++)
            {
                ArrayList vChart = (ArrayList)v.get(i);
                int newChartID = new Integer(vChart.get(0).toString()).intValue();
                if (newChartID > chartID) chartID = newChartID;
            }
            if (chartID >= 0)
            {
                chart = starLoginManager.getChart(String.valueOf(chartID));
            }
            else
            {
                chart = null;
            }
        }
        if (chart != null)
        {
            ChartElements chartElements = readChart(chart);
            if (chartElements == null) return;
            SkyChart skyChart = new SkyChart(chartElements, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(chartElements.getChartKind()) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        else
        {
            JOptionPane.showMessageDialog(this, bundle.getString("NoExistingChart"), "StarLogin", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnReadChartActionPerformed
    
    private void btnDisplayChartsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnDisplayChartsActionPerformed
    {//GEN-HEADEREND:event_btnDisplayChartsActionPerformed
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        ChartElements chartElements = new ChartElements();
        setChartElements(chartElements);
        
        if (chkNormal.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.normal, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.normal) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkAstronomical.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            chartElements2.setCoordSys(CoordSystem.Local);
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.local, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.local) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkSymbolicDir.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.symbolicDir, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.symbolicDir) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkPrimaryDir.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.primaryDir, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.primaryDir) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkSecondaryDir.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.secondaryDir, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.secondaryDir) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkTransits.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.transit, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.transit) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkRevolution.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            //chartEvent2.setPlaceLat(txtLatitudeReturn.getText());
            //chartEvent2.setPlaceLong(txtLongitudeReturn.getText());
            //chartEvent2.setPlace(txtPlaceReturn.getText());
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.revolution, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.revolution) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkCycle.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            //chartEvent2.setPlaceLat(txtLatitudeCycle.getText());
            //chartEvent2.setPlaceLong(txtLongitudeCycle.getText());
            //chartEvent2.setPlace(txtPlaceCycle.getText());
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.cycle, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.cycle) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkSynastry.isSelected())
        {
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartSynastryElements, chartEvent2, ChartKind.synastry, starLoginManager);
            SkyChart skyChart = new SkyChart(chartSynastryElements, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.synastry) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkComposite.isSelected())
        {
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartCompositeElements, chartEvent2, ChartKind.composite, starLoginManager);
            SkyChart skyChart = new SkyChart(chartCompositeElements, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.composite) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkFree.isSelected())
        {
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartFreeElements, chartEvent2, ChartKind.free, starLoginManager);
            SkyChart skyChart = new SkyChart(chartFreeElements, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.free) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkHarmonic.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.harmonic, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.harmonic) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkSeed.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.seed, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.seed) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (chkProjective.isSelected())
        {
            ChartElements chartElements2 = chartElements.cloneInitElements();
            ChartEvent chartEvent2 = chartEvent.cloneEvent();
            Astrology astrology = new Astrology(chartElements2, chartEvent2, ChartKind.projective, starLoginManager);
            SkyChart skyChart = new SkyChart(chartElements2, starLoginManager);
            windowNB += 1;
            skyChart.setTitle(ChartKind.getChartKindName(ChartKind.projective) + " - " + windowNB);
            skyChart.setVisible(true);
        }
        if (parentForm instanceof MainForm)
            ((MainForm)parentForm).setCartesFrame(false);
        setVisible(false);
        dispose();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        
    }//GEN-LAST:event_btnDisplayChartsActionPerformed
    
    private void setChartElements(ChartElements chartElements)
    {
        
        chartElements.setHouseSys(currentSelectedHouseSystem);
        chartElements.setCoordSys(currentSelectedCoordSystem);
        
        //other point
        if (optOtherPtAsteroid.isSelected())
        {
            chartElements.setOtherPointName(cboAsteroid.getSelectedItem().toString());
            chartElements.setOtherPointType(OtherPt.asteroid);
        }
        else if (optOtherPtPart.isSelected())
        {
            chartElements.setOtherPointName(cboPart.getSelectedItem().toString());
            chartElements.setOtherPointType(OtherPt.part);
        }
        else if (optOtherPtStar.isSelected())
        {
            chartElements.setOtherPointName(cboStarIdentity.getSelectedItem().toString());
            chartElements.setOtherPointType(OtherPt.star);
        }
        else if (optOtherPtComet.isSelected())
        {
            chartElements.setOtherPointName(cboComet.getSelectedItem().toString());
            chartElements.setOtherPointType(OtherPt.comet);
        }
        else
        {
            chartElements.setOtherPointName("");
            chartElements.setOtherPointType(OtherPt.none);
        }
        
        chartElements.setSunColor(lblColorSun.getBackground());
        chartElements.setMoonColor(lblColorMoon.getBackground());
        chartElements.setMercuryColor(lblColorMercury.getBackground());
        chartElements.setVenusColor(lblColorVenus.getBackground());
        chartElements.setMarsColor(lblColorMars.getBackground());
        chartElements.setJupiterColor(lblColorJupiter.getBackground());
        chartElements.setSaturnColor(lblColorSaturn.getBackground());
        chartElements.setUranusColor(lblColorUranus.getBackground());
        chartElements.setNeptuneColor(lblColorNeptune.getBackground());
        chartElements.setPlutoColor(lblColorPluto.getBackground());
        chartElements.setGaiaColor(lblColorGaia.getBackground());
        chartElements.setNodesColor(lblColorNodes.getBackground());
        chartElements.setCuspsColor(lblColorHouses.getBackground());
        chartElements.setAsteroidsColor(lblColorAsteroids.getBackground());
        chartElements.setVulcanColor(lblColorVulcan.getBackground());
        chartElements.setVariousColor(lblColorText.getBackground());
        chartElements.setFireColor(lblColorFire.getBackground());
        chartElements.setEarthColor(lblColorEarth.getBackground());
        chartElements.setAirColor(lblColorAir.getBackground());
        chartElements.setWaterColor(lblColorWater.getBackground());
        chartElements.setNeutralColor(lblColorNeutral.getBackground());
        chartElements.setDynamicColor(lblColorDynamic.getBackground());
        chartElements.setHarmonicColor(lblColorHarmonic.getBackground());
        
        chartElements.setZodiacSize(sldZodiac.getValue());
        chartElements.setSignSize(sldSigns.getValue());
        chartElements.setPlanetSize(sldPlanets.getValue());
        chartElements.setCharacterSize(sldCharacters.getValue());
        
        chartElements.setShownSun(chkSun.isSelected());
        chartElements.setShownMoon(chkMoon.isSelected());
        chartElements.setShownMercury(chkMercury.isSelected());
        chartElements.setShownVenus(chkVenus.isSelected());
        chartElements.setShownMars(chkMars.isSelected());
        chartElements.setShownJupiter(chkJupiter.isSelected());
        chartElements.setShownSaturn(chkSaturn.isSelected());
        chartElements.setShownUranus(chkUranus.isSelected());
        chartElements.setShownNeptune(chkNeptune.isSelected());
        chartElements.setShownPluto(chkPluto.isSelected());
        chartElements.setShownGaia(chkGaia.isSelected());
        chartElements.setShownNorthNode(chkNN.isSelected());
        chartElements.setShownLilith(chkLilith.isSelected());
        chartElements.setShownEast(chkEast.isSelected());
        chartElements.setShownZenith(chkZenith.isSelected());
        chartElements.setShownVertex(chkVertex.isSelected());
        chartElements.setShownVulcan(chkVulcan.isSelected());
        chartElements.setShownOtherPoint(chkOtherPoint.isSelected());
        chartElements.setShownCeres(chkCeres.isSelected());
        chartElements.setShownPallas(chkPallas.isSelected());
        chartElements.setShownJuno(chkJuno.isSelected());
        chartElements.setShownVesta(chkVesta.isSelected());
        chartElements.setShownChiron(chkChiron.isSelected());
        chartElements.setTrueLilith(chkTrueLilith.isSelected());
        chartElements.setColoredAspects(optColorMode2.isSelected());
        
        chartElements.setHousesCoords(chkHousesCoord.isSelected());
        chartElements.setSignsNames(chkSignsName.isSelected());
        chartElements.setLeftAsct(optEastAS.isSelected());
        chartElements.setSymbolAspects(chkAspectsSymbol.isSelected());
        chartElements.setViewStars(chkStars.isSelected());
        chartElements.setViewAsteroids(chkAsteroids.isSelected());
        chartElements.setViewCoordinates(chkCoordinates.isSelected());
        chartElements.setViewStraightLines(chkStraightLines.isSelected());
        chartElements.setViewHouses(chkHouses.isSelected());
        chartElements.setViewConstellations(chkConstellations.isSelected());
        chartElements.setViewShadedLines(chkShaded.isSelected());
        chartElements.setViewAspects(chkAspects.isSelected());
        chartElements.setViewBarycenter(chkBarycenter.isSelected());
        chartElements.setHorizon(optHorizon.isSelected());
        chartElements.setChartCompositeFromAS(optCompositeFromAS.isSelected());
        
        chartElements.setAspectsSun(chkAspectSun.isSelected());
        chartElements.setAspectsMoon(chkAspectMoon.isSelected());
        chartElements.setAspectsMercury(chkAspectMercury.isSelected());
        chartElements.setAspectsVenus(chkAspectVenus.isSelected());
        chartElements.setAspectsMars(chkAspectMars.isSelected());
        chartElements.setAspectsJupiter(chkAspectJupiter.isSelected());
        chartElements.setAspectsSaturn(chkAspectSaturn.isSelected());
        chartElements.setAspectsUranus(chkAspectUranus.isSelected());
        chartElements.setAspectsNeptune(chkAspectNeptune.isSelected());
        chartElements.setAspectsPluto(chkAspectPluto.isSelected());
        chartElements.setAspectsGaia(chkAspectGaia.isSelected());
        chartElements.setAspectsNorthNode(chkAspectNodes.isSelected());
        chartElements.setAspectsLilith(chkAspectLilith.isSelected());
        chartElements.setAspectsEast(chkAspectEast.isSelected());
        chartElements.setAspectsZenith(chkAspectZenith.isSelected());
        chartElements.setAspectsVertex(chkAspectVertex.isSelected());
        chartElements.setAspectsVulcan(chkAspectVulcan.isSelected());
        chartElements.setAspectsOtherPoint(chkAspectOtherPoint.isSelected());
        chartElements.setAspectsCeres(chkAspectCeres.isSelected());
        chartElements.setAspectsPallas(chkAspectPallas.isSelected());
        chartElements.setAspectsJuno(chkAspectJuno.isSelected());
        chartElements.setAspectsVesta(chkAspectVesta.isSelected());
        chartElements.setAspectsChiron(chkAspectChiron.isSelected());
        chartElements.setAspectsAS(chkAspectAS.isSelected());
        chartElements.setAspectsMC(chkAspectMC.isSelected());
        
        chartElements.setColorAspect0(lblColorConjunction.getBackground());
        chartElements.setColorAspect1(lblColorSextile.getBackground());
        chartElements.setColorAspect2(lblColorSquare.getBackground());
        chartElements.setColorAspect3(lblColorTrine.getBackground());
        chartElements.setColorAspect4(lblColorOpposition.getBackground());
        chartElements.setColorAspect5(lblColorVigintile.getBackground());
        chartElements.setColorAspect6(lblColorSemiSextile.getBackground());
        chartElements.setColorAspect7(lblColorSemiQuintile.getBackground());
        chartElements.setColorAspect8(lblColorNonagon.getBackground());
        chartElements.setColorAspect9(lblColorSemiSquare.getBackground());
        chartElements.setColorAspect10(lblColorSeptile.getBackground());
        chartElements.setColorAspect11(lblColorQuintile.getBackground());
        chartElements.setColorAspect12(lblColorTridectile.getBackground());
        chartElements.setColorAspect13(lblColorSesquiSquare.getBackground());
        chartElements.setColorAspect14(lblColorBiQuintile.getBackground());
        chartElements.setColorAspect15(lblColorInconjunct.getBackground());
        chartElements.setColorAspect16(lblColorQuadriNonagon.getBackground());
        chartElements.setColorAspect17(lblColorOtherAspect.getBackground());
        chartElements.setShownAspect0(chkConjunction.isSelected());
        chartElements.setShownAspect1(chkSextile.isSelected());
        chartElements.setShownAspect2(chkSquare.isSelected());
        chartElements.setShownAspect3(chkTrine.isSelected());
        chartElements.setShownAspect4(chkOpposition.isSelected());
        chartElements.setShownAspect5(chkVigintile.isSelected());
        chartElements.setShownAspect6(chkSemiSextile.isSelected());
        chartElements.setShownAspect7(chkSemiQuintile.isSelected());
        chartElements.setShownAspect8(chkNonagon.isSelected());
        chartElements.setShownAspect9(chkSemiSquare.isSelected());
        chartElements.setShownAspect10(chkSeptile.isSelected());
        chartElements.setShownAspect11(chkQuintile.isSelected());
        chartElements.setShownAspect12(chkTriDectile.isSelected());
        chartElements.setShownAspect13(chkSesquiSquare.isSelected());
        chartElements.setShownAspect14(chkBiQuintile.isSelected());
        chartElements.setShownAspect15(chkInconjunct.isSelected());
        chartElements.setShownAspect16(chkQuadriNonagon.isSelected());
        chartElements.setShownAspect17(chkOtherAspect.isSelected());
        
        chartElements.setOtherAspectName(txtOtherAspectName.getText());
        chartElements.setChartSelectSingle(jOptSingleSelection.isSelected());
        chartElements.setChartDir1SpaceKind(cboD1.getSelectedIndex());
        chartElements.setChartDir2SpaceKind(cboD2.getSelectedIndex());
        chartElements.setChartDirSSpaceKind(cboDS.getSelectedIndex());
        chartElements.setChartReturnPrecess(chkPrecession.isSelected());
        String chartCyclePlaceID = getPlaceID(places, txtPlaceCycle.getText());
        String chartReturnPlaceID = getPlaceID(places, txtPlaceReturn.getText());
        Place cplace = starLoginManager.getPlace(chartCyclePlaceID);
        String sLat1 = cplace.getPlaceLatitude();
        FLatitude fLat1 = new FLatitude(sLat1);
        chartElements.setChartCycleLatitude(fLat1.getDecimalDegree());
        String sLong1 = cplace.getPlaceLongitude();
        FLongitude fLong1 = new FLongitude(sLong1);
        chartElements.setChartCycleLongitude(fLong1.getDecimalDegree());
        chartElements.setChartCyclePlaceName(txtPlaceCycle.getText());
        Place rp = starLoginManager.getPlace(chartReturnPlaceID);
        String sLat2 = rp.getPlaceLatitude();
        FLatitude fLat2 = new FLatitude(sLat2);
        chartElements.setChartReturnLatitude(fLat2.getDecimalDegree());
        String sLong2 = rp.getPlaceLongitude();
        FLongitude fLong2 = new FLongitude(sLong2);
        chartElements.setChartReturnLongitude(fLong2.getDecimalDegree());
        chartElements.setChartReturnPlaceName(txtPlaceReturn.getText());
        chartElements.setSingleWeight(optSingleWeight.isSelected());
        chartElements.setTransitsDate(txtTransitsDate.getText());
        try
        {
            chartElements.setChartReturnNB(new Double(txtRevolNB.getText()).doubleValue());
            chartElements.setChartCycleNB(new Double(txtCyclesNB.getText()).doubleValue());
            chartElements.setLimitMag((double)sldStars.getValue()/2.0);
            chartElements.setChartReturnPlanet(new Integer(getPlanetID(cboPlanetReturn)).intValue());
            chartElements.setChartCyclePlanet1(new Integer(getPlanetID(cboPlanet1Cycle)).intValue());
            chartElements.setChartCyclePlanet2(new Integer(getPlanetID(cboPlanet2Cycle)).intValue());
            chartElements.setChartCompositeNB(new Integer(txtCompositeChartsNB.getText()).intValue());
            chartElements.setChartHarmonicNB(new Integer(txtHarmonicNB.getText()).intValue());
            chartElements.setChartDir1Corresp(new Double(txtCorrespondD1.getText()).doubleValue());
            chartElements.setChartDir2Corresp(new Double(txtCorrespondD2.getText()).doubleValue());
            chartElements.setChartDirSCorresp(new Double(txtCorrespondDS.getText()).doubleValue());
            chartElements.setChartDir1Degree(new Double(txtEqualsD1.getText()).doubleValue());
            chartElements.setChartDir2Day(new Double(txtEqualsD2.getText()).doubleValue());
            chartElements.setChartDirSDegree(new Double(txtEqualsDS.getText()).doubleValue());
            chartElements.setDirSAge(new Double(txtDirSAge.getText()).doubleValue());
            chartElements.setDir1Age(new Double(txtDir1Age.getText()).doubleValue());
            chartElements.setDir2Age(new Double(txtDir2Age.getText()).doubleValue());
            
            chartElements.setTypeAspect0(AspectType.translateAspectType(txtConjunction.getText()));
            chartElements.setTypeAspect1(AspectType.translateAspectType(txtSextile.getText()));
            chartElements.setTypeAspect2(AspectType.translateAspectType(txtSquare.getText()));
            chartElements.setTypeAspect3(AspectType.translateAspectType(txtTrine.getText()));
            chartElements.setTypeAspect4(AspectType.translateAspectType(txtOpposition.getText()));
            chartElements.setTypeAspect5(AspectType.translateAspectType(txtVigintile.getText()));
            chartElements.setTypeAspect6(AspectType.translateAspectType(txtSemiSextile.getText()));
            chartElements.setTypeAspect7(AspectType.translateAspectType(txtSemiQuintile.getText()));
            chartElements.setTypeAspect8(AspectType.translateAspectType(txtNonagone.getText()));
            chartElements.setTypeAspect9(AspectType.translateAspectType(txtSemiSquare.getText()));
            chartElements.setTypeAspect10(AspectType.translateAspectType(txtSeptile.getText()));
            chartElements.setTypeAspect11(AspectType.translateAspectType(txtQuintile.getText()));
            chartElements.setTypeAspect12(AspectType.translateAspectType(txtTriDectile.getText()));
            chartElements.setTypeAspect13(AspectType.translateAspectType(txtSesquiSquare.getText()));
            chartElements.setTypeAspect14(AspectType.translateAspectType(txtBiquintile.getText()));
            chartElements.setTypeAspect15(AspectType.translateAspectType(txtInconjunct.getText()));
            chartElements.setTypeAspect16(AspectType.translateAspectType(txtQuadriNonagon.getText()));
            chartElements.setTypeAspect17(AspectType.translateAspectType(txtOtherAspect.getText()));
            
            chartElements.setOtherAspectValue(new Double(txtValueOtherAspect.getText()).doubleValue());
            chartElements.setOrbLightLight(new Double(txtOrbLumLum.getText()).doubleValue());
            chartElements.setOrbLightTell(new Double(txtOrbLumIndiv.getText()).doubleValue());
            chartElements.setOrbLightOtherInd(new Double(txtOrbLumJS.getText()).doubleValue());
            chartElements.setOrbLightColl(new Double(txtOrbLumCol.getText()).doubleValue());
            chartElements.setOrbLightVirtMax(new Double(txtOrbLumVirtMaj.getText()).doubleValue());
            chartElements.setOrbLightVirtMin(new Double(txtOrbLumVirtMin.getText()).doubleValue());
            chartElements.setOrbTellTell(new Double(txtOrbIndivIndiv.getText()).doubleValue());
            chartElements.setOrbTellOtherInd(new Double(txtOrbIndivJS.getText()).doubleValue());
            chartElements.setOrbTellColl(new Double(txtOrbIndivCol.getText()).doubleValue());
            chartElements.setOrbTellVirtMax(new Double(txtOrbIndivVirtMaj.getText()).doubleValue());
            chartElements.setOrbTellVirtMin(new Double(txtOrbIndivVirtMin.getText()).doubleValue());
            chartElements.setOrbOtherIndOtherInd(new Double(txtOrbJSJS.getText()).doubleValue());
            chartElements.setOrbOtherIndColl(new Double(txtOrbJSCol.getText()).doubleValue());
            chartElements.setOrbOtherIndVirtMax(new Double(txtOrbJSvirtMaj.getText()).doubleValue());
            chartElements.setOrbOtherIndVirtMin(new Double(txtOrbJSVirtMin.getText()).doubleValue());
            chartElements.setOrbCollColl(new Double(txtOrbColCol.getText()).doubleValue());
            chartElements.setOrbCollVirtMax(new Double(txtOrbColVirtMaj.getText()).doubleValue());
            chartElements.setOrbCollVirtMin(new Double(txtOrbColVirtMin.getText()).doubleValue());
            chartElements.setOrbVirtMaxVirtMax(new Double(txtOrbVirtMajVirtMaj.getText()).doubleValue());
            chartElements.setOrbVirtMaxVirtMin(new Double(txtOrbVirtMajVirtMin.getText()).doubleValue());
            chartElements.setOrbVirtMinVirtMin(new Double(txtOrbvirtMinVirtMin.getText()).doubleValue());
            
            chartElements.setDivMin(new Double(txtDivOther.getText()).doubleValue());
            chartElements.setDivConjunction(new Double(txtDivConjunction.getText()).doubleValue());
            chartElements.setDivSextile(new Double(txtDivSextile.getText()).doubleValue());
            chartElements.setDivSquare(new Double(txtDivSquare.getText()).doubleValue());
            chartElements.setDivTrine(new Double(txtDivTrine.getText()).doubleValue());
            chartElements.setDivOpposition(new Double(txtDivOpposition.getText()).doubleValue());
        }
        catch(java.lang.NumberFormatException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    private void updateChartElements(ChartElements chartElements)
    {
        chartElements.setSunColor(lblColorSun.getBackground());
        chartElements.setMoonColor(lblColorMoon.getBackground());
        chartElements.setMercuryColor(lblColorMercury.getBackground());
        chartElements.setVenusColor(lblColorVenus.getBackground());
        chartElements.setMarsColor(lblColorMars.getBackground());
        chartElements.setJupiterColor(lblColorJupiter.getBackground());
        chartElements.setSaturnColor(lblColorSaturn.getBackground());
        chartElements.setUranusColor(lblColorUranus.getBackground());
        chartElements.setNeptuneColor(lblColorNeptune.getBackground());
        chartElements.setPlutoColor(lblColorPluto.getBackground());
        chartElements.setGaiaColor(lblColorGaia.getBackground());
        chartElements.setNodesColor(lblColorNodes.getBackground());
        chartElements.setCuspsColor(lblColorHouses.getBackground());
        chartElements.setAsteroidsColor(lblColorAsteroids.getBackground());
        chartElements.setVulcanColor(lblColorVulcan.getBackground());
        chartElements.setVariousColor(lblColorText.getBackground());
        chartElements.setFireColor(lblColorFire.getBackground());
        chartElements.setEarthColor(lblColorEarth.getBackground());
        chartElements.setAirColor(lblColorAir.getBackground());
        chartElements.setWaterColor(lblColorWater.getBackground());
        chartElements.setNeutralColor(lblColorNeutral.getBackground());
        chartElements.setDynamicColor(lblColorDynamic.getBackground());
        chartElements.setHarmonicColor(lblColorHarmonic.getBackground());
        
        chartElements.setZodiacSize(sldZodiac.getValue());
        chartElements.setSignSize(sldSigns.getValue());
        chartElements.setPlanetSize(sldPlanets.getValue());
        chartElements.setCharacterSize(sldCharacters.getValue());
        
        chartElements.setShownSun(chkSun.isSelected());
        chartElements.setShownMoon(chkMoon.isSelected());
        chartElements.setShownMercury(chkMercury.isSelected());
        chartElements.setShownVenus(chkVenus.isSelected());
        chartElements.setShownMars(chkMars.isSelected());
        chartElements.setShownJupiter(chkJupiter.isSelected());
        chartElements.setShownSaturn(chkSaturn.isSelected());
        chartElements.setShownUranus(chkUranus.isSelected());
        chartElements.setShownNeptune(chkNeptune.isSelected());
        chartElements.setShownPluto(chkPluto.isSelected());
        chartElements.setShownGaia(chkGaia.isSelected());
        chartElements.setShownNorthNode(chkNN.isSelected());
        chartElements.setShownLilith(chkLilith.isSelected());
        chartElements.setShownEast(chkEast.isSelected());
        chartElements.setShownZenith(chkZenith.isSelected());
        chartElements.setShownVertex(chkVertex.isSelected());
        chartElements.setShownVulcan(chkVulcan.isSelected());
        chartElements.setShownOtherPoint(chkOtherPoint.isSelected());
        chartElements.setShownCeres(chkCeres.isSelected());
        chartElements.setShownPallas(chkPallas.isSelected());
        chartElements.setShownJuno(chkJuno.isSelected());
        chartElements.setShownVesta(chkVesta.isSelected());
        chartElements.setShownChiron(chkChiron.isSelected());
        chartElements.setTrueLilith(chkTrueLilith.isSelected());
        chartElements.setColoredAspects(optColorMode2.isSelected());
        
        chartElements.setHousesCoords(chkHousesCoord.isSelected());
        chartElements.setSignsNames(chkSignsName.isSelected());
        chartElements.setLeftAsct(optEastAS.isSelected());
        chartElements.setSymbolAspects(chkAspectsSymbol.isSelected());
        chartElements.setViewStars(chkStars.isSelected());
        chartElements.setViewAsteroids(chkAsteroids.isSelected());
        chartElements.setViewCoordinates(chkCoordinates.isSelected());
        chartElements.setViewStraightLines(chkStraightLines.isSelected());
        chartElements.setViewHouses(chkHouses.isSelected());
        chartElements.setViewConstellations(chkConstellations.isSelected());
        chartElements.setViewShadedLines(chkShaded.isSelected());
        chartElements.setViewAspects(chkAspects.isSelected());
        chartElements.setViewBarycenter(chkBarycenter.isSelected());
        chartElements.setHorizon(optHorizon.isSelected());
        chartElements.setChartCompositeFromAS(optCompositeFromAS.isSelected());
        
        chartElements.setAspectsSun(chkAspectSun.isSelected());
        chartElements.setAspectsMoon(chkAspectMoon.isSelected());
        chartElements.setAspectsMercury(chkAspectMercury.isSelected());
        chartElements.setAspectsVenus(chkAspectVenus.isSelected());
        chartElements.setAspectsMars(chkAspectMars.isSelected());
        chartElements.setAspectsJupiter(chkAspectJupiter.isSelected());
        chartElements.setAspectsSaturn(chkAspectSaturn.isSelected());
        chartElements.setAspectsUranus(chkAspectUranus.isSelected());
        chartElements.setAspectsNeptune(chkAspectNeptune.isSelected());
        chartElements.setAspectsPluto(chkAspectPluto.isSelected());
        chartElements.setAspectsGaia(chkAspectGaia.isSelected());
        chartElements.setAspectsNorthNode(chkAspectNodes.isSelected());
        chartElements.setAspectsLilith(chkAspectLilith.isSelected());
        chartElements.setAspectsEast(chkAspectEast.isSelected());
        chartElements.setAspectsZenith(chkAspectZenith.isSelected());
        chartElements.setAspectsVertex(chkAspectVertex.isSelected());
        chartElements.setAspectsVulcan(chkAspectVulcan.isSelected());
        chartElements.setAspectsOtherPoint(chkAspectOtherPoint.isSelected());
        chartElements.setAspectsCeres(chkAspectCeres.isSelected());
        chartElements.setAspectsPallas(chkAspectPallas.isSelected());
        chartElements.setAspectsJuno(chkAspectJuno.isSelected());
        chartElements.setAspectsVesta(chkAspectVesta.isSelected());
        chartElements.setAspectsChiron(chkAspectChiron.isSelected());
        chartElements.setAspectsAS(chkAspectAS.isSelected());
        chartElements.setAspectsMC(chkAspectMC.isSelected());
        
        chartElements.setColorAspect0(lblColorConjunction.getBackground());
        chartElements.setColorAspect1(lblColorSextile.getBackground());
        chartElements.setColorAspect2(lblColorSquare.getBackground());
        chartElements.setColorAspect3(lblColorTrine.getBackground());
        chartElements.setColorAspect4(lblColorOpposition.getBackground());
        chartElements.setColorAspect5(lblColorVigintile.getBackground());
        chartElements.setColorAspect6(lblColorSemiSextile.getBackground());
        chartElements.setColorAspect7(lblColorSemiQuintile.getBackground());
        chartElements.setColorAspect8(lblColorNonagon.getBackground());
        chartElements.setColorAspect9(lblColorSemiSquare.getBackground());
        chartElements.setColorAspect10(lblColorSeptile.getBackground());
        chartElements.setColorAspect11(lblColorQuintile.getBackground());
        chartElements.setColorAspect12(lblColorTridectile.getBackground());
        chartElements.setColorAspect13(lblColorSesquiSquare.getBackground());
        chartElements.setColorAspect14(lblColorBiQuintile.getBackground());
        chartElements.setColorAspect15(lblColorInconjunct.getBackground());
        chartElements.setColorAspect16(lblColorQuadriNonagon.getBackground());
        chartElements.setColorAspect17(lblColorOtherAspect.getBackground());
        chartElements.setShownAspect0(chkConjunction.isSelected());
        chartElements.setShownAspect1(chkSextile.isSelected());
        chartElements.setShownAspect2(chkSquare.isSelected());
        chartElements.setShownAspect3(chkTrine.isSelected());
        chartElements.setShownAspect4(chkOpposition.isSelected());
        chartElements.setShownAspect5(chkVigintile.isSelected());
        chartElements.setShownAspect6(chkSemiSextile.isSelected());
        chartElements.setShownAspect7(chkSemiQuintile.isSelected());
        chartElements.setShownAspect8(chkNonagon.isSelected());
        chartElements.setShownAspect9(chkSemiSquare.isSelected());
        chartElements.setShownAspect10(chkSeptile.isSelected());
        chartElements.setShownAspect11(chkQuintile.isSelected());
        chartElements.setShownAspect12(chkTriDectile.isSelected());
        chartElements.setShownAspect13(chkSesquiSquare.isSelected());
        chartElements.setShownAspect14(chkBiQuintile.isSelected());
        chartElements.setShownAspect15(chkInconjunct.isSelected());
        chartElements.setShownAspect16(chkQuadriNonagon.isSelected());
        chartElements.setShownAspect17(chkOtherAspect.isSelected());
        
        chartElements.setOtherAspectName(txtOtherAspectName.getText());
        chartElements.setChartSelectSingle(jOptSingleSelection.isSelected());
        String chartCyclePlaceID = getPlaceID(places, chartElements.getChartCyclePlaceName());
        String chartReturnPlaceID = getPlaceID(places, chartElements.getChartReturnPlaceName());
        Place cplace = starLoginManager.getPlace(chartCyclePlaceID);
        String sLat1 = cplace.getPlaceLatitude();
        FLatitude fLat1 = new FLatitude(sLat1);
        chartElements.setChartCycleLatitude(fLat1.getDecimalDegree());
        String sLong1 = cplace.getPlaceLongitude();
        FLongitude fLong1 = new FLongitude(sLong1);
        chartElements.setChartCycleLongitude(fLong1.getDecimalDegree());
        Place rp = starLoginManager.getPlace(chartReturnPlaceID);
        String sLat2 = rp.getPlaceLatitude();
        FLatitude fLat2 = new FLatitude(sLat2);
        chartElements.setChartReturnLatitude(fLat2.getDecimalDegree());
        String sLong2 = rp.getPlaceLongitude();
        FLongitude fLong2 = new FLongitude(sLong2);
        chartElements.setChartReturnLongitude(fLong2.getDecimalDegree());
        chartElements.setSingleWeight(optSingleWeight.isSelected());
        try
        {
            chartElements.setLimitMag((double)sldStars.getValue()/2.0);
            
            chartElements.setTypeAspect0(AspectType.translateAspectType(txtConjunction.getText()));
            chartElements.setTypeAspect1(AspectType.translateAspectType(txtSextile.getText()));
            chartElements.setTypeAspect2(AspectType.translateAspectType(txtSquare.getText()));
            chartElements.setTypeAspect3(AspectType.translateAspectType(txtTrine.getText()));
            chartElements.setTypeAspect4(AspectType.translateAspectType(txtOpposition.getText()));
            chartElements.setTypeAspect5(AspectType.translateAspectType(txtVigintile.getText()));
            chartElements.setTypeAspect6(AspectType.translateAspectType(txtSemiSextile.getText()));
            chartElements.setTypeAspect7(AspectType.translateAspectType(txtSemiQuintile.getText()));
            chartElements.setTypeAspect8(AspectType.translateAspectType(txtNonagone.getText()));
            chartElements.setTypeAspect9(AspectType.translateAspectType(txtSemiSquare.getText()));
            chartElements.setTypeAspect10(AspectType.translateAspectType(txtSeptile.getText()));
            chartElements.setTypeAspect11(AspectType.translateAspectType(txtQuintile.getText()));
            chartElements.setTypeAspect12(AspectType.translateAspectType(txtTriDectile.getText()));
            chartElements.setTypeAspect13(AspectType.translateAspectType(txtSesquiSquare.getText()));
            chartElements.setTypeAspect14(AspectType.translateAspectType(txtBiquintile.getText()));
            chartElements.setTypeAspect15(AspectType.translateAspectType(txtInconjunct.getText()));
            chartElements.setTypeAspect16(AspectType.translateAspectType(txtQuadriNonagon.getText()));
            chartElements.setTypeAspect17(AspectType.translateAspectType(txtOtherAspect.getText()));
            
            chartElements.setOtherAspectValue(new Double(txtValueOtherAspect.getText()).doubleValue());
            chartElements.setOrbLightLight(new Double(txtOrbLumLum.getText()).doubleValue());
            chartElements.setOrbLightTell(new Double(txtOrbLumIndiv.getText()).doubleValue());
            chartElements.setOrbLightOtherInd(new Double(txtOrbLumJS.getText()).doubleValue());
            chartElements.setOrbLightColl(new Double(txtOrbLumCol.getText()).doubleValue());
            chartElements.setOrbLightVirtMax(new Double(txtOrbLumVirtMaj.getText()).doubleValue());
            chartElements.setOrbLightVirtMin(new Double(txtOrbLumVirtMin.getText()).doubleValue());
            chartElements.setOrbTellTell(new Double(txtOrbIndivIndiv.getText()).doubleValue());
            chartElements.setOrbTellOtherInd(new Double(txtOrbIndivJS.getText()).doubleValue());
            chartElements.setOrbTellColl(new Double(txtOrbIndivCol.getText()).doubleValue());
            chartElements.setOrbTellVirtMax(new Double(txtOrbIndivVirtMaj.getText()).doubleValue());
            chartElements.setOrbTellVirtMin(new Double(txtOrbIndivVirtMin.getText()).doubleValue());
            chartElements.setOrbOtherIndOtherInd(new Double(txtOrbJSJS.getText()).doubleValue());
            chartElements.setOrbOtherIndColl(new Double(txtOrbJSCol.getText()).doubleValue());
            chartElements.setOrbOtherIndVirtMax(new Double(txtOrbJSvirtMaj.getText()).doubleValue());
            chartElements.setOrbOtherIndVirtMin(new Double(txtOrbJSVirtMin.getText()).doubleValue());
            chartElements.setOrbCollColl(new Double(txtOrbColCol.getText()).doubleValue());
            chartElements.setOrbCollVirtMax(new Double(txtOrbColVirtMaj.getText()).doubleValue());
            chartElements.setOrbCollVirtMin(new Double(txtOrbColVirtMin.getText()).doubleValue());
            chartElements.setOrbVirtMaxVirtMax(new Double(txtOrbVirtMajVirtMaj.getText()).doubleValue());
            chartElements.setOrbVirtMaxVirtMin(new Double(txtOrbVirtMajVirtMin.getText()).doubleValue());
            chartElements.setOrbVirtMinVirtMin(new Double(txtOrbvirtMinVirtMin.getText()).doubleValue());
            
            chartElements.setDivMin(new Double(txtDivOther.getText()).doubleValue());
            chartElements.setDivConjunction(new Double(txtDivConjunction.getText()).doubleValue());
            chartElements.setDivSextile(new Double(txtDivSextile.getText()).doubleValue());
            chartElements.setDivSquare(new Double(txtDivSquare.getText()).doubleValue());
            chartElements.setDivTrine(new Double(txtDivTrine.getText()).doubleValue());
            chartElements.setDivOpposition(new Double(txtDivOpposition.getText()).doubleValue());
        }
        catch(java.lang.NumberFormatException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    private void cboPartActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboPartActionPerformed
    {//GEN-HEADEREND:event_cboPartActionPerformed
        setPart();
    }//GEN-LAST:event_cboPartActionPerformed
    
    private void setPart()
    {
        ArrayList p = parts.getRecords();
        for (int i=0; i<p.size() ; i++)
        {
            ArrayList v = (ArrayList)p.get(i);
            String strID = String.valueOf(v.get(0));
            String strName = String.valueOf(v.get(1));
            String selectedPart = null2String(cboPart.getSelectedItem());
            if (strName.equals(selectedPart))
            {
                Part part = starLoginManager.getPart(strID);
                cboPartRef.setSelectedIndex(part.getRef());
                cboPartPlus.setSelectedIndex(part.getPlus());
                cboPartMinus.setSelectedIndex(part.getMinus());
                break;
            }
        }
    }
    
    private void cboStarIdentityActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_cboStarIdentityActionPerformed
    {//GEN-HEADEREND:event_cboStarIdentityActionPerformed
        setStar();
    }//GEN-LAST:event_cboStarIdentityActionPerformed
    
    private void setStar()
    {
        ArrayList p = stars.getRecords();
        for (int i=0; i<p.size() ; i++)
        {
            ArrayList v = (ArrayList)p.get(i);
            String strID = String.valueOf(v.get(0));
            String strIdentity = String.valueOf(v.get(3));
            String selectedStar = null2String(cboStarIdentity.getSelectedItem());
            if (strIdentity.equals(selectedStar))
            {
                Star star = starLoginManager.getStar(strID, "");
                lblStarName.setText(star.getStarName());
                break;
            }
        }
    }
                    
    private void optOtherPtNoneActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optOtherPtNoneActionPerformed
    {//GEN-HEADEREND:event_optOtherPtNoneActionPerformed
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
    }//GEN-LAST:event_optOtherPtNoneActionPerformed
    
    private void optOtherPtAsteroidActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optOtherPtAsteroidActionPerformed
    {//GEN-HEADEREND:event_optOtherPtAsteroidActionPerformed
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(true);
        cboComet.setVisible(false);
    }//GEN-LAST:event_optOtherPtAsteroidActionPerformed
    
    private void optOtherPtCometActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optOtherPtCometActionPerformed
    {//GEN-HEADEREND:event_optOtherPtCometActionPerformed
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(true);
    }//GEN-LAST:event_optOtherPtCometActionPerformed
    
    private void optOtherPtPartActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optOtherPtPartActionPerformed
    {//GEN-HEADEREND:event_optOtherPtPartActionPerformed
        pnlOtherPtStar.setVisible(false);
        pnlOtherPtPart.setVisible(true);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
    }//GEN-LAST:event_optOtherPtPartActionPerformed
    
    private void optOtherPtStarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optOtherPtStarActionPerformed
    {//GEN-HEADEREND:event_optOtherPtStarActionPerformed
        pnlOtherPtStar.setVisible(true);
        pnlOtherPtPart.setVisible(false);
        cboAsteroid.setVisible(false);
        cboComet.setVisible(false);
    }//GEN-LAST:event_optOtherPtStarActionPerformed
    
    private void chkOtherPointActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkOtherPointActionPerformed
    {//GEN-HEADEREND:event_chkOtherPointActionPerformed
        pnlOtherPoint.setVisible(chkOtherPoint.isSelected());
    }//GEN-LAST:event_chkOtherPointActionPerformed
            
    private void txtDivOtherFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivOtherFocusLost
    {//GEN-HEADEREND:event_txtDivOtherFocusLost
        if (txtDivOther.getText().equals("")) txtDivOther.setText("0");
        Double d = new Double(txtDivOther.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivOther.setText("1");
        }
    }//GEN-LAST:event_txtDivOtherFocusLost
    
    private void txtDivOppositionFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivOppositionFocusLost
    {//GEN-HEADEREND:event_txtDivOppositionFocusLost
        if (txtDivOpposition.getText().equals("")) txtDivOpposition.setText("0");
        Double d = new Double(txtDivOpposition.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivOpposition.setText("1");
        }
    }//GEN-LAST:event_txtDivOppositionFocusLost
    
    private void txtDivTrineFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivTrineFocusLost
    {//GEN-HEADEREND:event_txtDivTrineFocusLost
        if (txtDivTrine.getText().equals("")) txtDivTrine.setText("0");
        Double d = new Double(txtDivTrine.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivTrine.setText("1");
        }
    }//GEN-LAST:event_txtDivTrineFocusLost
    
    private void txtDivSquareFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivSquareFocusLost
    {//GEN-HEADEREND:event_txtDivSquareFocusLost
        if (txtDivSquare.getText().equals("")) txtDivSquare.setText("0");
        Double d = new Double(txtDivSquare.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivSquare.setText("1");
        }
    }//GEN-LAST:event_txtDivSquareFocusLost
    
    private void txtDivSextileFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivSextileFocusLost
    {//GEN-HEADEREND:event_txtDivSextileFocusLost
        if (txtDivSextile.getText().equals("")) txtDivSextile.setText("0");
        Double d = new Double(txtDivSextile.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivSextile.setText("1");
        }
    }//GEN-LAST:event_txtDivSextileFocusLost
    
    private void txtDivConjunctionFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtDivConjunctionFocusLost
    {//GEN-HEADEREND:event_txtDivConjunctionFocusLost
        if (txtDivConjunction.getText().equals("")) txtDivConjunction.setText("0");
        Double d = new Double(txtDivConjunction.getText());
        if (d.doubleValue()<1.0)
        {
            txtDivConjunction.setText("1");
        }
    }//GEN-LAST:event_txtDivConjunctionFocusLost
    
    private void txtDivOtherkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOtherkeyTyped
    {//GEN-HEADEREND:event_txtDivOtherkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivOther, 5, kc);
    }//GEN-LAST:event_txtDivOtherkeyTyped
    
    private void txtDivOppositionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivOppositionkeyTyped
    {//GEN-HEADEREND:event_txtDivOppositionkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivOpposition, 5, kc);
    }//GEN-LAST:event_txtDivOppositionkeyTyped
    
    private void txtDivTrinekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivTrinekeyTyped
    {//GEN-HEADEREND:event_txtDivTrinekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivTrine, 5, kc);
    }//GEN-LAST:event_txtDivTrinekeyTyped
    
    private void txtDivSquarekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSquarekeyTyped
    {//GEN-HEADEREND:event_txtDivSquarekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivSquare, 5, kc);
    }//GEN-LAST:event_txtDivSquarekeyTyped
    
    private void txtDivSextilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivSextilekeyTyped
    {//GEN-HEADEREND:event_txtDivSextilekeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivSextile, 5, kc);
    }//GEN-LAST:event_txtDivSextilekeyTyped
    
    private void txtDivConjunctionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDivConjunctionkeyTyped
    {//GEN-HEADEREND:event_txtDivConjunctionkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtDivConjunction, 5, kc);
    }//GEN-LAST:event_txtDivConjunctionkeyTyped
    
    private void txtOrbvirtMinVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbvirtMinVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbvirtMinVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbvirtMinVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbvirtMinVirtMinkeyTyped
    
    private void txtOrbVirtMajVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbVirtMajVirtMinkeyTyped
    
    private void txtOrbVirtMajVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbVirtMajVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbVirtMajVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbVirtMajVirtMaj, 5, kc);
    }//GEN-LAST:event_txtOrbVirtMajVirtMajkeyTyped
    
    private void txtOrbColVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbColVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbColVirtMinkeyTyped
    
    private void txtOrbColVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbColVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColVirtMaj, 5, kc);
    }//GEN-LAST:event_txtOrbColVirtMajkeyTyped
    
    private void txtOrbColColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbColColkeyTyped
    {//GEN-HEADEREND:event_txtOrbColColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbColCol, 5, kc);
    }//GEN-LAST:event_txtOrbColColkeyTyped
    
    private void txtOrbJSVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbJSVirtMinkeyTyped
    
    private void txtOrbJSvirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSvirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSvirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSvirtMaj, 5, kc);
    }//GEN-LAST:event_txtOrbJSvirtMajkeyTyped
    
    private void txtOrbJSColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSColkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSCol, 5, kc);
    }//GEN-LAST:event_txtOrbJSColkeyTyped
    
    private void txtOrbJSJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbJSJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbJSJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbJSJS, 5, kc);
    }//GEN-LAST:event_txtOrbJSJSkeyTyped
    
    private void txtOrbIndivVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbIndivVirtMinkeyTyped
    
    private void txtOrbIndivVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivVirtMaj, 5, kc);
    }//GEN-LAST:event_txtOrbIndivVirtMajkeyTyped
    
    private void txtOrbIndivColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivColkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivCol, 5, kc);
    }//GEN-LAST:event_txtOrbIndivColkeyTyped
    
    private void txtOrbIndivJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivJS, 5, kc);
    }//GEN-LAST:event_txtOrbIndivJSkeyTyped
    
    private void txtOrbIndivIndivkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbIndivIndivkeyTyped
    {//GEN-HEADEREND:event_txtOrbIndivIndivkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbIndivIndiv, 5, kc);
    }//GEN-LAST:event_txtOrbIndivIndivkeyTyped
    
    private void txtOrbLumVirtMinkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMinkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumVirtMinkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumVirtMin, 5, kc);
    }//GEN-LAST:event_txtOrbLumVirtMinkeyTyped
    
    private void txtOrbLumVirtMajkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumVirtMajkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumVirtMajkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumVirtMaj, 5, kc);
    }//GEN-LAST:event_txtOrbLumVirtMajkeyTyped
    
    private void txtOrbLumColkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumColkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumColkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumCol, 5, kc);
    }//GEN-LAST:event_txtOrbLumColkeyTyped
    
    private void txtOrbLumJSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumJSkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumJSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumJS, 5, kc);
    }//GEN-LAST:event_txtOrbLumJSkeyTyped
    
    private void txtOrbLumIndivkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumIndivkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumIndivkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumIndiv, 5, kc);
    }//GEN-LAST:event_txtOrbLumIndivkeyTyped
    
    private void txtOrbLumLumkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOrbLumLumkeyTyped
    {//GEN-HEADEREND:event_txtOrbLumLumkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtOrbLumLum, 5, kc);
    }//GEN-LAST:event_txtOrbLumLumkeyTyped
                        
    private void txtEqualsD2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEqualsD2FocusLost
    {//GEN-HEADEREND:event_txtEqualsD2FocusLost
        if (txtEqualsD2.getText().equals("")) txtEqualsD2.setText("1");
        Double d = new Double(txtEqualsD2.getText());
        String sText = d.toString();
        txtEqualsD2.setText(sText);
    }//GEN-LAST:event_txtEqualsD2FocusLost
    
    private void txtCorrespondD2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtCorrespondD2FocusLost
    {//GEN-HEADEREND:event_txtCorrespondD2FocusLost
        if (txtCorrespondD2.getText().equals("")) txtCorrespondD2.setText("1");
        Double d = new Double(txtCorrespondD2.getText());
        String sText = d.toString();
        txtCorrespondD2.setText(sText);
    }//GEN-LAST:event_txtCorrespondD2FocusLost
    
    private void txtEqualsD1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEqualsD1FocusLost
    {//GEN-HEADEREND:event_txtEqualsD1FocusLost
        if (txtEqualsD1.getText().equals("")) txtEqualsD1.setText("1");
        Double d = new Double(txtEqualsD1.getText());
        String sText = d.toString();
        txtEqualsD1.setText(sText);
    }//GEN-LAST:event_txtEqualsD1FocusLost
    
    private void txtCorrespondD1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtCorrespondD1FocusLost
    {//GEN-HEADEREND:event_txtCorrespondD1FocusLost
        if (txtCorrespondD1.getText().equals("")) txtCorrespondD1.setText("1");
        Double d = new Double(txtCorrespondD1.getText());
        String sText = d.toString();
        txtCorrespondD1.setText(sText);
    }//GEN-LAST:event_txtCorrespondD1FocusLost
    
    private void txtEqualsDSFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtEqualsDSFocusLost
    {//GEN-HEADEREND:event_txtEqualsDSFocusLost
        if (txtEqualsDS.getText().equals("")) txtEqualsDS.setText("1");
        Double d = new Double(txtEqualsDS.getText());
        String sText = d.toString();
        txtEqualsDS.setText(sText);
    }//GEN-LAST:event_txtEqualsDSFocusLost
    
    private void txtCorrespondDSFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtCorrespondDSFocusLost
    {//GEN-HEADEREND:event_txtCorrespondDSFocusLost
        if (txtCorrespondDS.getText().equals("")) txtCorrespondDS.setText("1");
        Double d = new Double(txtCorrespondDS.getText());
        String sText = d.toString();
        txtCorrespondDS.setText(sText);
    }//GEN-LAST:event_txtCorrespondDSFocusLost
    
    private void txtCompositeChartsNBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCompositeChartsNBkeyTyped
    {//GEN-HEADEREND:event_txtCompositeChartsNBkeyTyped
        KTUnsignedInteger ui = new KTUnsignedInteger(evt, txtCompositeChartsNB, 2, kc);
    }//GEN-LAST:event_txtCompositeChartsNBkeyTyped
    
    private void txtLongitudeCyclekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeCyclekeyTyped
    {//GEN-HEADEREND:event_txtLongitudeCyclekeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudeCycle, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeCycle.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeCyclekeyTyped
    
    private void txtLatitudeCyclekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeCyclekeyTyped
    {//GEN-HEADEREND:event_txtLatitudeCyclekeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudeCycle, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudeCycle.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudeCyclekeyTyped
    
    private void txtCyclesNBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCyclesNBkeyTyped
    {//GEN-HEADEREND:event_txtCyclesNBkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtCyclesNB, 9, kc);
    }//GEN-LAST:event_txtCyclesNBkeyTyped
    
    private void txtLongitudeReturnkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLongitudeReturnkeyTyped
    {//GEN-HEADEREND:event_txtLongitudeReturnkeyTyped
        KTLongitude lng = new KTLongitude(evt, txtLongitudeReturn, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLongitudeReturn.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLongitudeReturnkeyTyped
    
    private void txtLatitudeReturnkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtLatitudeReturnkeyTyped
    {//GEN-HEADEREND:event_txtLatitudeReturnkeyTyped
        KTLatitude lat = new KTLatitude(evt, txtLatitudeReturn, kc);
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtLatitudeReturn.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtLatitudeReturnkeyTyped
    
    private void txtRevolNBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtRevolNBkeyTyped
    {//GEN-HEADEREND:event_txtRevolNBkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtRevolNB, 9, kc);
    }//GEN-LAST:event_txtRevolNBkeyTyped
    
    private void txtTransitsDatekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTransitsDatekeyTyped
    {//GEN-HEADEREND:event_txtTransitsDatekeyTyped
        KTDateAstro d = new KTDateAstro(evt, txtTransitsDate, kc);
        int pos = txtTransitsDate.getCaretPosition();
        if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
            txtTransitsDate.setCaretPosition(cp-1);
    }//GEN-LAST:event_txtTransitsDatekeyTyped
    
    private void txtEqualsD2keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsD2keyTyped
    {//GEN-HEADEREND:event_txtEqualsD2keyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtEqualsD2, 5, kc);
    }//GEN-LAST:event_txtEqualsD2keyTyped
    
    private void txtCorrespondD2keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondD2keyTyped
    {//GEN-HEADEREND:event_txtCorrespondD2keyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtCorrespondD2, 5, kc);
    }//GEN-LAST:event_txtCorrespondD2keyTyped
    
    private void txtDir2AgekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDir2AgekeyTyped
    {//GEN-HEADEREND:event_txtDir2AgekeyTyped
        KTUnsignedDecimal ui = new KTUnsignedDecimal(evt, txtDir2Age, 7, kc);
    }//GEN-LAST:event_txtDir2AgekeyTyped
    
    private void txtEqualsD1keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsD1keyTyped
    {//GEN-HEADEREND:event_txtEqualsD1keyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtEqualsD1, 5, kc);
    }//GEN-LAST:event_txtEqualsD1keyTyped
    
    private void txtCorrespondD1keyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondD1keyTyped
    {//GEN-HEADEREND:event_txtCorrespondD1keyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtCorrespondD1, 5, kc);
    }//GEN-LAST:event_txtCorrespondD1keyTyped
    
    private void txtDir1AgekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDir1AgekeyTyped
    {//GEN-HEADEREND:event_txtDir1AgekeyTyped
        KTUnsignedDecimal ui = new KTUnsignedDecimal(evt, txtDir1Age, 7, kc);
    }//GEN-LAST:event_txtDir1AgekeyTyped
    
    private void txtEqualsDSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtEqualsDSkeyTyped
    {//GEN-HEADEREND:event_txtEqualsDSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtEqualsDS, 5, kc);
    }//GEN-LAST:event_txtEqualsDSkeyTyped
    
    private void txtDirSAgekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtDirSAgekeyTyped
    {//GEN-HEADEREND:event_txtDirSAgekeyTyped
        KTUnsignedDecimal ui = new KTUnsignedDecimal(evt, txtDirSAge, 7, kc);
    }//GEN-LAST:event_txtDirSAgekeyTyped
    
    private void txtCorrespondDSkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtCorrespondDSkeyTyped
    {//GEN-HEADEREND:event_txtCorrespondDSkeyTyped
        KTUnsignedDecimal d = new KTUnsignedDecimal(evt, txtCorrespondDS, 5, kc);
    }//GEN-LAST:event_txtCorrespondDSkeyTyped
    
    private void txtValueOtherAspectFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_txtValueOtherAspectFocusLost
    {//GEN-HEADEREND:event_txtValueOtherAspectFocusLost
        if (txtValueOtherAspect.getText().equals("")) txtValueOtherAspect.setText("0");
        Double d = new Double(txtValueOtherAspect.getText());
        if (d.doubleValue()>180.0)
        {
            txtValueOtherAspect.setText("180");
        }
    }//GEN-LAST:event_txtValueOtherAspectFocusLost
    
    private void txtValueOtherAspectkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtValueOtherAspectkeyTyped
    {//GEN-HEADEREND:event_txtValueOtherAspectkeyTyped
        KTUnsignedDecimal ud = new KTUnsignedDecimal(evt, txtValueOtherAspect, 6, kc);
    }//GEN-LAST:event_txtValueOtherAspectkeyTyped
    
    private void txtOtherAspectkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOtherAspectkeyTyped
    {//GEN-HEADEREND:event_txtOtherAspectkeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtOtherAspect, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtOtherAspectkeyTyped
    
    private void txtQuadriNonagonkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtQuadriNonagonkeyTyped
    {//GEN-HEADEREND:event_txtQuadriNonagonkeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtQuadriNonagon, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtQuadriNonagonkeyTyped
    
    private void txtInconjunctkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtInconjunctkeyTyped
    {//GEN-HEADEREND:event_txtInconjunctkeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtInconjunct, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtInconjunctkeyTyped
    
    private void txtBiquintilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtBiquintilekeyTyped
    {//GEN-HEADEREND:event_txtBiquintilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtBiquintile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtBiquintilekeyTyped
    
    private void txtSesquiSquarekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSesquiSquarekeyTyped
    {//GEN-HEADEREND:event_txtSesquiSquarekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSesquiSquare, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSesquiSquarekeyTyped
    
    private void txtTriDectilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTriDectilekeyTyped
    {//GEN-HEADEREND:event_txtTriDectilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtTriDectile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtTriDectilekeyTyped
    
    private void txtQuintilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtQuintilekeyTyped
    {//GEN-HEADEREND:event_txtQuintilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtQuintile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtQuintilekeyTyped
    
    private void txtSeptilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSeptilekeyTyped
    {//GEN-HEADEREND:event_txtSeptilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSeptile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSeptilekeyTyped
    
    private void txtSemiSquarekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiSquarekeyTyped
    {//GEN-HEADEREND:event_txtSemiSquarekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSemiSquare, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSemiSquarekeyTyped
    
    private void txtNonagonekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtNonagonekeyTyped
    {//GEN-HEADEREND:event_txtNonagonekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtNonagone, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtNonagonekeyTyped
    
    private void txtSemiQuintilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiQuintilekeyTyped
    {//GEN-HEADEREND:event_txtSemiQuintilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSemiQuintile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSemiQuintilekeyTyped
    
    private void txtSemiSextilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSemiSextilekeyTyped
    {//GEN-HEADEREND:event_txtSemiSextilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSemiSextile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSemiSextilekeyTyped
    
    private void txtVigintilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtVigintilekeyTyped
    {//GEN-HEADEREND:event_txtVigintilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtVigintile, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtVigintilekeyTyped
    
    private void txtOppositionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtOppositionkeyTyped
    {//GEN-HEADEREND:event_txtOppositionkeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtOpposition, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtOppositionkeyTyped
    
    private void txtTrinekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtTrinekeyTyped
    {//GEN-HEADEREND:event_txtTrinekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtTrine, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtTrinekeyTyped
    
    private void txtSquarekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSquarekeyTyped
    {//GEN-HEADEREND:event_txtSquarekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtSquare, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSquarekeyTyped
    
    private void txtSextilekeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtSextilekeyTyped
    {//GEN-HEADEREND:event_txtSextilekeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtConjunction, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtSextilekeyTyped
    
    private void lblColorQuadriNonagonMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorQuadriNonagonMouseClicked
    {//GEN-HEADEREND:event_lblColorQuadriNonagonMouseClicked
        color = lblColorQuadriNonagon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorQuadriNonagon.setBackground(color);
    }//GEN-LAST:event_lblColorQuadriNonagonMouseClicked
    
    private void txtConjunctionkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtConjunctionkeyTyped
    {//GEN-HEADEREND:event_txtConjunctionkeyTyped
        KTAspectKind ak = new KTAspectKind(evt, txtConjunction, 1, neutralColor, dynamicColor, harmonicColor, kc);
    }//GEN-LAST:event_txtConjunctionkeyTyped
    
    private void lblColorOtherAspectMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorOtherAspectMouseClicked
    {//GEN-HEADEREND:event_lblColorOtherAspectMouseClicked
        color = lblColorOtherAspect.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorOtherAspect.setBackground(color);
    }//GEN-LAST:event_lblColorOtherAspectMouseClicked
    
    private void lblColorInconjunctMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorInconjunctMouseClicked
    {//GEN-HEADEREND:event_lblColorInconjunctMouseClicked
        color = lblColorInconjunct.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorInconjunct.setBackground(color);
    }//GEN-LAST:event_lblColorInconjunctMouseClicked
    
    private void lblColorBiQuintileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorBiQuintileMouseClicked
    {//GEN-HEADEREND:event_lblColorBiQuintileMouseClicked
        color = lblColorBiQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorBiQuintile.setBackground(color);
    }//GEN-LAST:event_lblColorBiQuintileMouseClicked
    
    private void lblColorSesquiSquareMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSesquiSquareMouseClicked
    {//GEN-HEADEREND:event_lblColorSesquiSquareMouseClicked
        color = lblColorSesquiSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSesquiSquare.setBackground(color);
    }//GEN-LAST:event_lblColorSesquiSquareMouseClicked
    
    private void lblColorTridectileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorTridectileMouseClicked
    {//GEN-HEADEREND:event_lblColorTridectileMouseClicked
        color = lblColorTridectile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorTridectile.setBackground(color);
    }//GEN-LAST:event_lblColorTridectileMouseClicked
    
    private void lblColorQuintileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorQuintileMouseClicked
    {//GEN-HEADEREND:event_lblColorQuintileMouseClicked
        color = lblColorQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorQuintile.setBackground(color);
    }//GEN-LAST:event_lblColorQuintileMouseClicked
    
    private void lblColorSeptileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSeptileMouseClicked
    {//GEN-HEADEREND:event_lblColorSeptileMouseClicked
        color = lblColorSeptile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSeptile.setBackground(color);
    }//GEN-LAST:event_lblColorSeptileMouseClicked
    
    private void lblColorSemiSquareMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSemiSquareMouseClicked
    {//GEN-HEADEREND:event_lblColorSemiSquareMouseClicked
        color = lblColorSemiSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSemiSquare.setBackground(color);
    }//GEN-LAST:event_lblColorSemiSquareMouseClicked
    
    private void lblColorNonagonMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorNonagonMouseClicked
    {//GEN-HEADEREND:event_lblColorNonagonMouseClicked
        color = lblColorNonagon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorNonagon.setBackground(color);
    }//GEN-LAST:event_lblColorNonagonMouseClicked
    
    private void lblColorSemiQuintileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSemiQuintileMouseClicked
    {//GEN-HEADEREND:event_lblColorSemiQuintileMouseClicked
        color = lblColorSemiQuintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSemiQuintile.setBackground(color);
    }//GEN-LAST:event_lblColorSemiQuintileMouseClicked
    
    private void lblColorSemiSextileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSemiSextileMouseClicked
    {//GEN-HEADEREND:event_lblColorSemiSextileMouseClicked
        color = lblColorSemiSextile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSemiSextile.setBackground(color);
    }//GEN-LAST:event_lblColorSemiSextileMouseClicked
    
    private void lblColorVigintileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorVigintileMouseClicked
    {//GEN-HEADEREND:event_lblColorVigintileMouseClicked
        color = lblColorVigintile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorVigintile.setBackground(color);
    }//GEN-LAST:event_lblColorVigintileMouseClicked
    
    private void lblColorOppositionMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorOppositionMouseClicked
    {//GEN-HEADEREND:event_lblColorOppositionMouseClicked
        color = lblColorOpposition.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorOpposition.setBackground(color);
    }//GEN-LAST:event_lblColorOppositionMouseClicked
    
    private void lblColorTrineMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorTrineMouseClicked
    {//GEN-HEADEREND:event_lblColorTrineMouseClicked
        color = lblColorTrine.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorTrine.setBackground(color);
    }//GEN-LAST:event_lblColorTrineMouseClicked
    
    private void lblColorSquareMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSquareMouseClicked
    {//GEN-HEADEREND:event_lblColorSquareMouseClicked
        color = lblColorSquare.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSquare.setBackground(color);
    }//GEN-LAST:event_lblColorSquareMouseClicked
    
    private void lblColorSextileMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSextileMouseClicked
    {//GEN-HEADEREND:event_lblColorSextileMouseClicked
        color = lblColorSextile.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSextile.setBackground(color);
    }//GEN-LAST:event_lblColorSextileMouseClicked
    
    private void lblColorConjunctionMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorConjunctionMouseClicked
    {//GEN-HEADEREND:event_lblColorConjunctionMouseClicked
        color = lblColorConjunction.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorConjunction.setBackground(color);
    }//GEN-LAST:event_lblColorConjunctionMouseClicked
        
    private void txtHarmonicNBkeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtHarmonicNBkeyTyped
    {//GEN-HEADEREND:event_txtHarmonicNBkeyTyped
        KTUnsignedInteger ui = new KTUnsignedInteger(evt, txtHarmonicNB, 1, kc);
    }//GEN-LAST:event_txtHarmonicNBkeyTyped
        
    private void sldCharactersStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldCharactersStateChanged
    {//GEN-HEADEREND:event_sldCharactersStateChanged
        int value = sldCharacters.getValue();
        Font f = lblCharactersSize.getFont();
        lblCharactersSize.setFont(new Font(f.getName(), Font.PLAIN, value));
    }//GEN-LAST:event_sldCharactersStateChanged
    
    private void sldPlanetsStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldPlanetsStateChanged
    {//GEN-HEADEREND:event_sldPlanetsStateChanged
        int value = sldPlanets.getValue();
        Font f = lblPlanetSize.getFont();
        lblPlanetSize.setFont(new Font(f.getName(), Font.BOLD, value));
    }//GEN-LAST:event_sldPlanetsStateChanged
    
    private void sldSignsStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldSignsStateChanged
    {//GEN-HEADEREND:event_sldSignsStateChanged
        int value = sldSigns.getValue();
        Font f = lblSignSize.getFont();
        lblSignSize.setFont(new Font(f.getName(), Font.BOLD, value));
    }//GEN-LAST:event_sldSignsStateChanged
    
    private void lblColorHarmonicMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorHarmonicMouseClicked
    {//GEN-HEADEREND:event_lblColorHarmonicMouseClicked
        color = lblColorHarmonic.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorHarmonic.setBackground(color);
    }//GEN-LAST:event_lblColorHarmonicMouseClicked
    
    private void lblColorDynamicMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorDynamicMouseClicked
    {//GEN-HEADEREND:event_lblColorDynamicMouseClicked
        color = lblColorDynamic.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorDynamic.setBackground(color);
    }//GEN-LAST:event_lblColorDynamicMouseClicked
    
    private void lblColorNeutralMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorNeutralMouseClicked
    {//GEN-HEADEREND:event_lblColorNeutralMouseClicked
        color = lblColorNeutral.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorNeutral.setBackground(color);
    }//GEN-LAST:event_lblColorNeutralMouseClicked
    
    private void lblColorWaterMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorWaterMouseClicked
    {//GEN-HEADEREND:event_lblColorWaterMouseClicked
        color = lblColorWater.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorWater.setBackground(color);
    }//GEN-LAST:event_lblColorWaterMouseClicked
    
    private void lblColorAirMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorAirMouseClicked
    {//GEN-HEADEREND:event_lblColorAirMouseClicked
        color = lblColorAir.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorAir.setBackground(color);
    }//GEN-LAST:event_lblColorAirMouseClicked
    
    private void lblColorEarthMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorEarthMouseClicked
    {//GEN-HEADEREND:event_lblColorEarthMouseClicked
        color = lblColorEarth.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorEarth.setBackground(color);
    }//GEN-LAST:event_lblColorEarthMouseClicked
    
    private void lblColorFireMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorFireMouseClicked
    {//GEN-HEADEREND:event_lblColorFireMouseClicked
        color = lblColorFire.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorFire.setBackground(color);
    }//GEN-LAST:event_lblColorFireMouseClicked
    
    private void lblColorTextMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorTextMouseClicked
    {//GEN-HEADEREND:event_lblColorTextMouseClicked
        color = lblColorText.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorText.setBackground(color);
    }//GEN-LAST:event_lblColorTextMouseClicked
    
    private void lblColorVulcanMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorVulcanMouseClicked
    {//GEN-HEADEREND:event_lblColorVulcanMouseClicked
        color = lblColorVulcan.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorVulcan.setBackground(color);
    }//GEN-LAST:event_lblColorVulcanMouseClicked
    
    private void lblColorAsteroidsMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorAsteroidsMouseClicked
    {//GEN-HEADEREND:event_lblColorAsteroidsMouseClicked
        color = lblColorAsteroids.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorAsteroids.setBackground(color);
    }//GEN-LAST:event_lblColorAsteroidsMouseClicked
    
    private void lblColorHousesMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorHousesMouseClicked
    {//GEN-HEADEREND:event_lblColorHousesMouseClicked
        color = lblColorHouses.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorHouses.setBackground(color);
    }//GEN-LAST:event_lblColorHousesMouseClicked
    
    private void lblColorNodesMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorNodesMouseClicked
    {//GEN-HEADEREND:event_lblColorNodesMouseClicked
        color = lblColorNodes.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorNodes.setBackground(color);
    }//GEN-LAST:event_lblColorNodesMouseClicked
    
    private void lblColorGaiaMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorGaiaMouseClicked
    {//GEN-HEADEREND:event_lblColorGaiaMouseClicked
        color = lblColorGaia.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorGaia.setBackground(color);
    }//GEN-LAST:event_lblColorGaiaMouseClicked
    
    private void lblColorPlutoMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorPlutoMouseClicked
    {//GEN-HEADEREND:event_lblColorPlutoMouseClicked
        color = lblColorPluto.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorPluto.setBackground(color);
    }//GEN-LAST:event_lblColorPlutoMouseClicked
    
    private void lblColorNeptuneMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorNeptuneMouseClicked
    {//GEN-HEADEREND:event_lblColorNeptuneMouseClicked
        color = lblColorNeptune.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorNeptune.setBackground(color);
    }//GEN-LAST:event_lblColorNeptuneMouseClicked
    
    private void lblColorUranusMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorUranusMouseClicked
    {//GEN-HEADEREND:event_lblColorUranusMouseClicked
        color = lblColorUranus.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorUranus.setBackground(color);
    }//GEN-LAST:event_lblColorUranusMouseClicked
    
    private void lblColorSaturnMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSaturnMouseClicked
    {//GEN-HEADEREND:event_lblColorSaturnMouseClicked
        color = lblColorSaturn.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSaturn.setBackground(color);
    }//GEN-LAST:event_lblColorSaturnMouseClicked
    
    private void lblColorJupiterMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorJupiterMouseClicked
    {//GEN-HEADEREND:event_lblColorJupiterMouseClicked
        color = lblColorJupiter.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorJupiter.setBackground(color);
    }//GEN-LAST:event_lblColorJupiterMouseClicked
    
    private void lblColorMarsMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorMarsMouseClicked
    {//GEN-HEADEREND:event_lblColorMarsMouseClicked
        color = lblColorMars.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorMars.setBackground(color);
    }//GEN-LAST:event_lblColorMarsMouseClicked
    
    private void lblColorVenusMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorVenusMouseClicked
    {//GEN-HEADEREND:event_lblColorVenusMouseClicked
        color = lblColorVenus.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorVenus.setBackground(color);
    }//GEN-LAST:event_lblColorVenusMouseClicked
    
    private void lblColorMercuryMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorMercuryMouseClicked
    {//GEN-HEADEREND:event_lblColorMercuryMouseClicked
        color = lblColorMercury.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorMercury.setBackground(color);
    }//GEN-LAST:event_lblColorMercuryMouseClicked
    
    private void lblColorMoonMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorMoonMouseClicked
    {//GEN-HEADEREND:event_lblColorMoonMouseClicked
        color = lblColorMoon.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorMoon.setBackground(color);
    }//GEN-LAST:event_lblColorMoonMouseClicked
    
    private void lblColorSunMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_lblColorSunMouseClicked
    {//GEN-HEADEREND:event_lblColorSunMouseClicked
        color = lblColorSun.getBackground();
        DialogColor dlgColor = new DialogColor(this, true, color);
        if (color == null) return;
        lblColorSun.setBackground(color);
    }//GEN-LAST:event_lblColorSunMouseClicked
    
    private void optPlacidusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPlacidusActionPerformed
    {//GEN-HEADEREND:event_optPlacidusActionPerformed
        currentSelectedHouseSystem = HouseSystem.Placidus;
    }//GEN-LAST:event_optPlacidusActionPerformed
    
    private void optKochActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optKochActionPerformed
    {//GEN-HEADEREND:event_optKochActionPerformed
        currentSelectedHouseSystem = HouseSystem.Koch;
    }//GEN-LAST:event_optKochActionPerformed
    
    private void optAlcabitiusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAlcabitiusActionPerformed
    {//GEN-HEADEREND:event_optAlcabitiusActionPerformed
        currentSelectedHouseSystem = HouseSystem.Alcabitius;
    }//GEN-LAST:event_optAlcabitiusActionPerformed
    
    private void optAlbategniusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAlbategniusActionPerformed
    {//GEN-HEADEREND:event_optAlbategniusActionPerformed
        currentSelectedHouseSystem = HouseSystem.Albategnius;
    }//GEN-LAST:event_optAlbategniusActionPerformed
    
    private void optAbenragelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAbenragelActionPerformed
    {//GEN-HEADEREND:event_optAbenragelActionPerformed
        currentSelectedHouseSystem = HouseSystem.Abenragel;
    }//GEN-LAST:event_optAbenragelActionPerformed
    
    private void optZodiacalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optZodiacalActionPerformed
    {//GEN-HEADEREND:event_optZodiacalActionPerformed
        currentSelectedHouseSystem = HouseSystem.Zodiacal;
    }//GEN-LAST:event_optZodiacalActionPerformed
    
    private void optZenithalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optZenithalActionPerformed
    {//GEN-HEADEREND:event_optZenithalActionPerformed
        currentSelectedHouseSystem = HouseSystem.Zenithal;
    }//GEN-LAST:event_optZenithalActionPerformed
    
    private void optWieselActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optWieselActionPerformed
    {//GEN-HEADEREND:event_optWieselActionPerformed
        currentSelectedHouseSystem = HouseSystem.Wiesel;
    }//GEN-LAST:event_optWieselActionPerformed
    
    private void optSolarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSolarActionPerformed
    {//GEN-HEADEREND:event_optSolarActionPerformed
        currentSelectedHouseSystem = HouseSystem.Solar;
    }//GEN-LAST:event_optSolarActionPerformed
    
    private void optRegiomontanusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optRegiomontanusActionPerformed
    {//GEN-HEADEREND:event_optRegiomontanusActionPerformed
        currentSelectedHouseSystem = HouseSystem.Regiomontanus;
    }//GEN-LAST:event_optRegiomontanusActionPerformed
    
    private void optPorpyreActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optPorpyreActionPerformed
    {//GEN-HEADEREND:event_optPorpyreActionPerformed
        currentSelectedHouseSystem = HouseSystem.Porphyre;
    }//GEN-LAST:event_optPorpyreActionPerformed
    
    private void optNodalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optNodalActionPerformed
    {//GEN-HEADEREND:event_optNodalActionPerformed
        currentSelectedHouseSystem = HouseSystem.Nodal;
    }//GEN-LAST:event_optNodalActionPerformed
    
    private void optMaternusMCActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMaternusMCActionPerformed
    {//GEN-HEADEREND:event_optMaternusMCActionPerformed
        currentSelectedHouseSystem = HouseSystem.MaternusMC;
    }//GEN-LAST:event_optMaternusMCActionPerformed
    
    private void optMaternusAsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optMaternusAsActionPerformed
    {//GEN-HEADEREND:event_optMaternusAsActionPerformed
        currentSelectedHouseSystem = HouseSystem.MaternusAs;
    }//GEN-LAST:event_optMaternusAsActionPerformed
    
    private void optBazchenoffActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optBazchenoffActionPerformed
    {//GEN-HEADEREND:event_optBazchenoffActionPerformed
        currentSelectedHouseSystem = HouseSystem.Bazchenoff;
    }//GEN-LAST:event_optBazchenoffActionPerformed
    
    private void optColinEvansActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optColinEvansActionPerformed
    {//GEN-HEADEREND:event_optColinEvansActionPerformed
        currentSelectedHouseSystem = HouseSystem.ColinEvans;
    }//GEN-LAST:event_optColinEvansActionPerformed
    
    private void optEquatorialRegularActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optEquatorialRegularActionPerformed
    {//GEN-HEADEREND:event_optEquatorialRegularActionPerformed
        currentSelectedHouseSystem = HouseSystem.EquatorialRegular;
    }//GEN-LAST:event_optEquatorialRegularActionPerformed
    
    private void optCampanusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optCampanusActionPerformed
    {//GEN-HEADEREND:event_optCampanusActionPerformed
        currentSelectedHouseSystem = HouseSystem.Campanus;
    }//GEN-LAST:event_optCampanusActionPerformed
    
    private void optSemiAngularActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optSemiAngularActionPerformed
    {//GEN-HEADEREND:event_optSemiAngularActionPerformed
        currentSelectedHouseSystem = HouseSystem.SemiAngular;
    }//GEN-LAST:event_optSemiAngularActionPerformed
    
    private void optTwoHoursActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optTwoHoursActionPerformed
    {//GEN-HEADEREND:event_optTwoHoursActionPerformed
        currentSelectedHouseSystem = HouseSystem.TwoHours;
    }//GEN-LAST:event_optTwoHoursActionPerformed
    
    private void optAncientActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_optAncientActionPerformed
    {//GEN-HEADEREND:event_optAncientActionPerformed
        currentSelectedHouseSystem = HouseSystem.Ancient;
    }//GEN-LAST:event_optAncientActionPerformed
    
    private void chkHeliocentricSiderealActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricSiderealActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricSiderealActionPerformed
        currentSelectedCoordSystem = CoordSystem.HelioSidereal;
    }//GEN-LAST:event_chkHeliocentricSiderealActionPerformed
    
    private void chkHeliocentricNormalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricNormalActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricNormalActionPerformed
        currentSelectedCoordSystem = CoordSystem.HelioNormal;
    }//GEN-LAST:event_chkHeliocentricNormalActionPerformed
    
    private void chkLocalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkLocalActionPerformed
    {//GEN-HEADEREND:event_chkLocalActionPerformed
        currentSelectedCoordSystem = CoordSystem.Local;
    }//GEN-LAST:event_chkLocalActionPerformed
    
    private void chkEclipticActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkEclipticActionPerformed
    {//GEN-HEADEREND:event_chkEclipticActionPerformed
        currentSelectedCoordSystem = CoordSystem.Ecliptic;
    }//GEN-LAST:event_chkEclipticActionPerformed
    
    private void chkEquatorialActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkEquatorialActionPerformed
    {//GEN-HEADEREND:event_chkEquatorialActionPerformed
        currentSelectedCoordSystem = CoordSystem.Equatorial;
    }//GEN-LAST:event_chkEquatorialActionPerformed
    
    private void chkSiderealActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSiderealActionPerformed
    {//GEN-HEADEREND:event_chkSiderealActionPerformed
        currentSelectedCoordSystem = CoordSystem.Sidereal;
    }//GEN-LAST:event_chkSiderealActionPerformed
    
    private void chkTropicalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkTropicalActionPerformed
    {//GEN-HEADEREND:event_chkTropicalActionPerformed
        currentSelectedCoordSystem = CoordSystem.Tropical;
    }//GEN-LAST:event_chkTropicalActionPerformed
    
    private void chkHeliocentricActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHeliocentricActionPerformed
    {//GEN-HEADEREND:event_chkHeliocentricActionPerformed
        boolean bolHelio = chkHeliocentric.isSelected();
        chkTropical.setVisible(!bolHelio);
        chkSidereal.setVisible(!bolHelio);
        chkEquatorial.setVisible(!bolHelio);
        chkEcliptic.setVisible(!bolHelio);
        chkLocal.setVisible(!bolHelio);
        chkDomitudes.setVisible(!bolHelio);
        chkHeliocentricNormal.setVisible(bolHelio);
        chkHeliocentricSidereal.setVisible(bolHelio);
    }//GEN-LAST:event_chkHeliocentricActionPerformed
    
    private void chkGeocentricActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkGeocentricActionPerformed
    {//GEN-HEADEREND:event_chkGeocentricActionPerformed
        boolean bolGeo = chkGeocentric.isSelected();
        chkTropical.setVisible(bolGeo);
        chkSidereal.setVisible(bolGeo);
        chkEquatorial.setVisible(bolGeo);
        chkEcliptic.setVisible(bolGeo);
        chkLocal.setVisible(bolGeo);
        chkDomitudes.setVisible(bolGeo);
        chkHeliocentricNormal.setVisible(!bolGeo);
        chkHeliocentricSidereal.setVisible(!bolGeo);
    }//GEN-LAST:event_chkGeocentricActionPerformed
    
    private void btnEditFreeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnEditFreeActionPerformed
    {//GEN-HEADEREND:event_btnEditFreeActionPerformed
        setChartElements(chartFreeElements);
        FreeChartDialog chartDialog = new FreeChartDialog(this, true, chartFreeElements);
        chartDialog.setVisible(true);
        chartFreeElements = chartDialog.getChartElements();
    }//GEN-LAST:event_btnEditFreeActionPerformed
    
    //get the current record
    @SuppressWarnings("unchecked")
    private void btnOKEventSelectCompositeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKEventSelectCompositeActionPerformed
    {//GEN-HEADEREND:event_btnOKEventSelectCompositeActionPerformed
        int iRemain = new Integer(lblRemainEventComposite.getText()).intValue();
        if (iRemain <= 0) return;
        txtCompositeChartsNB.setEnabled(false);
        String header = "";
        
        ChartElements chartElements;
        int iM = new Integer(txtCompositeChartsNB.getText()).intValue();
        
        if (optCompositeEventSelect.isSelected())
        {

            //if (iRemain > 0)
            //{
                setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
                ListeEventForm lef = new ListeEventForm(this, true, "-1");
                setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            //}
            event = MainForm.currentEvent;
            ChartEvent chartEvent0 = new ChartEvent(event);
            ArrayList chartEvents = new ArrayList();
            chartEvents.add(chartEvent0);
            chartElements = new ChartElements();
            setChartElements(chartElements);
            chartElements.setChartEvents(chartEvents);
            chartElements.setChartKind(ChartKind.normal);
            Astrology astrology = new Astrology(starLoginManager);
            astrology.chartCalculation(chartElements);
            
        }
        else
        {
            new ChartSelectionDialog(new JFrame(), true, this, starLoginManager).setVisible(true);
            if (selectedChartID == null||selectedChartID.equals("-1")||selectedChartID.equals(""))
                return;
            Chart chart = starLoginManager.getChart(selectedChartID);
            chartElements = readChart(chart);
            header = chartElements.getChartHeader();
            
            //get only the part of coordinates we need
            int chartKind = chartElements.getChartKind();
            //ArrayList allCoords = chartElements.getChartCoords();
            AllCoord newCoord;
            if ((chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.transit))
            {
                newCoord = (AllCoord)(chartElements.getChartCoords().get(1));
            }
            else
            {
                newCoord = (AllCoord)(chartElements.getChartCoords().get(0));
            }
            ArrayList allCoords = new ArrayList();
            allCoords.add(newCoord);
            chartElements.setChartCoords(allCoords);
        }
        
        if (iRemain == iM)
        {
            chartElements.setChartCompositeNB(iM);
            chartCompositeElements = chartElements;
        }
        else
        {
            //Add the new coordinates to the composite elements
            ArrayList allCoords = chartCompositeElements.getChartCoords();
            AllCoord newCoord = (AllCoord)(chartElements.getChartCoords().get(0));
            allCoords.add(newCoord);
            
            //Add the new chart event to the composite elements
            ArrayList chartCompositeEvents = chartCompositeElements.getChartEvents();
            ChartEvent newChartEvent = (ChartEvent)(chartElements.getChartEvents().get(0));
            newChartEvent.setHeader(header);
            chartCompositeEvents.add(newChartEvent);
        }
        
        lblRemainEventComposite.setText(String.valueOf(iRemain - 1));
    }//GEN-LAST:event_btnOKEventSelectCompositeActionPerformed
    
    //get the current record
    @SuppressWarnings("unchecked")
    private void btnOKEventSelectSysnastryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnOKEventSelectSysnastryActionPerformed
    {//GEN-HEADEREND:event_btnOKEventSelectSysnastryActionPerformed
        int iRemain = new Integer(lblRemainEventSynastry.getText()).intValue();
        if (iRemain <= 0) return;
        String header = "";
        
        ChartElements chartElements;
        
        if (optSynastryEventSelect.isSelected())
        {
            //if (iRemain > 0)
            //{
                setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
                ListeEventForm lef = new ListeEventForm(this, true, "-1");
                setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            //}
            event = MainForm.currentEvent;
            ChartEvent chartEvent0 = new ChartEvent(event);
            ArrayList chartEvents = new ArrayList();
            chartEvents.add(chartEvent0);
            chartElements = new ChartElements();
            setChartElements(chartElements);
            chartElements.setChartEvents(chartEvents);
            chartElements.setChartKind(ChartKind.normal);
            Astrology astrology = new Astrology(starLoginManager);
            astrology.chartCalculation(chartElements);
            
        }
        else
        {
            new ChartSelectionDialog(new JFrame(), true, this, starLoginManager).setVisible(true);
            if (selectedChartID == null||selectedChartID.equals("-1")||selectedChartID.equals(""))
                return;
            Chart chart = starLoginManager.getChart(selectedChartID);
            chartElements = readChart(chart);
            header = chartElements.getChartHeader();
            
            //get only the part of coordinates we need
            int chartKind = chartElements.getChartKind();
            //ArrayList allCoords = chartElements.getChartCoords();
            AllCoord newCoord;
            if ((chartKind == ChartKind.cycle) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.revolution) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.transit))
            {
                newCoord = (AllCoord)(chartElements.getChartCoords().get(1));
            }
            else
            {
                newCoord = (AllCoord)(chartElements.getChartCoords().get(0));
            }
            ArrayList allCoords = new ArrayList();
            allCoords.add(newCoord);
            chartElements.setChartCoords(allCoords);
        }
        
        if (iRemain == 2)
        {
            chartSynastryElements = chartElements;
        }
        else
        {
            //Add the new coordinates to the synastry elements
            ArrayList allCoords = chartSynastryElements.getChartCoords();
            AllCoord newCoord = (AllCoord)(chartElements.getChartCoords().get(0));
            allCoords.add(newCoord);
            
            //Add the new chart event to the synastry elements
            ArrayList chartSynastryEvents = chartSynastryElements.getChartEvents();
            ChartEvent newChartEvent = (ChartEvent)(chartElements.getChartEvents().get(0));
            newChartEvent.setHeader(header);
            chartSynastryEvents.add(newChartEvent);
        }
        
        lblRemainEventSynastry.setText(String.valueOf(iRemain - 1));
    }//GEN-LAST:event_btnOKEventSelectSysnastryActionPerformed
    
    private void chkProjectiveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkProjectiveActionPerformed
    {//GEN-HEADEREND:event_chkProjectiveActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkProjective.setSelected(true);
            }
            jPanel55.setVisible(chkProjective.isSelected());
        }
        else if (currentSelectedChart == ChartKind.projective)
        {
            chkProjective.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.projective;
            chkProjective.setSelected(true);
            jPanel55.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkProjectiveActionPerformed
    
    private void chkHarmonicActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkHarmonicActionPerformed
    {//GEN-HEADEREND:event_chkHarmonicActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkHarmonic.setSelected(true);
            }
            pnlHarmonic.setVisible(chkHarmonic.isSelected());
        }
        else if (currentSelectedChart == ChartKind.harmonic)
        {
            chkHarmonic.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.harmonic;
            chkHarmonic.setSelected(true);
            pnlHarmonic.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkHarmonicActionPerformed
        
    private void chkFreeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkFreeActionPerformed
    {//GEN-HEADEREND:event_chkFreeActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkFree.setSelected(true);
            }
            pnlFree.setVisible(chkFree.isSelected());
        }
        else if (currentSelectedChart == ChartKind.free)
        {
            chkFree.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.free;
            chkFree.setSelected(true);
            pnlFree.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkFreeActionPerformed
    
    private byte selectedCharts()
    {
        byte i=0;
        if (chkNormal.isSelected()) i+=1;
        if (chkAstronomical.isSelected()) i+=1;
        if (chkSeed.isSelected()) i+=1;
        if (chkSymbolicDir.isSelected()) i+=1;
        if (chkPrimaryDir.isSelected()) i+=1;
        if (chkSecondaryDir.isSelected()) i+=1;
        if (chkTransits.isSelected()) i+=1;
        if (chkRevolution.isSelected()) i+=1;
        if (chkCycle.isSelected()) i+=1;
        if (chkSynastry.isSelected()) i+=1;
        if (chkComposite.isSelected()) i+=1;
        if (chkFree.isSelected()) i+=1;
        if (chkProjective.isSelected()) i+=1;
        if (chkHarmonic.isSelected()) i+=1;
        return i;
    }
    
    private void chkCompositeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkCompositeActionPerformed
    {//GEN-HEADEREND:event_chkCompositeActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkComposite.setSelected(true);
            }
            pnlComposite.setVisible(chkComposite.isSelected());
        }
        else if (currentSelectedChart == ChartKind.composite)
        {
            chkComposite.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.composite;
            chkComposite.setSelected(true);
            pnlComposite.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkCompositeActionPerformed
    
    private void chkSynastryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSynastryActionPerformed
    {//GEN-HEADEREND:event_chkSynastryActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSynastry.setSelected(true);
            }
            pnlSynastry.setVisible(chkSynastry.isSelected());
        }
        else if (currentSelectedChart == ChartKind.synastry)
        {
            chkSynastry.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.synastry;
            chkSynastry.setSelected(true);
            pnlSynastry.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (chkSynastry.isSelected() == false)
        {
            lblRemainEventSynastry.setText("2");
            chartSynastryElements = new ChartElements();
        }
    }//GEN-LAST:event_chkSynastryActionPerformed
    
    private void chkCycleActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkCycleActionPerformed
    {//GEN-HEADEREND:event_chkCycleActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkCycle.setSelected(true);
            }
            pnlCycle.setVisible(chkCycle.isSelected());
        }
        else if (currentSelectedChart == ChartKind.cycle)
        {
            chkCycle.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.cycle;
            chkCycle.setSelected(true);
            pnlCycle.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
        if (chkCycle.isSelected() == false)
        {
            txtCompositeChartsNB.setText(defaultOption.getChartCompositeNB());
            lblRemainEventComposite.setText(txtCompositeChartsNB.getText());
            chartCompositeElements = new ChartElements();
        }
    }//GEN-LAST:event_chkCycleActionPerformed
    
    private void chkRevolutionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkRevolutionActionPerformed
    {//GEN-HEADEREND:event_chkRevolutionActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkRevolution.setSelected(true);
            }
            pnlRevolution.setVisible(chkRevolution.isSelected());
        }
        else if (currentSelectedChart == ChartKind.revolution)
        {
            chkRevolution.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.revolution;
            chkRevolution.setSelected(true);
            pnlRevolution.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkRevolutionActionPerformed
    
    private void chkTransitsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkTransitsActionPerformed
    {//GEN-HEADEREND:event_chkTransitsActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkTransits.setSelected(true);
            }
            pnlTransits.setVisible(chkTransits.isSelected());
        }
        else if (currentSelectedChart == ChartKind.transit)
        {
            chkTransits.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.transit;
            chkTransits.setSelected(true);
            pnlTransits.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkTransitsActionPerformed
    
    private void chkSecondaryDirActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSecondaryDirActionPerformed
    {//GEN-HEADEREND:event_chkSecondaryDirActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSecondaryDir.setSelected(true);
            }
            pnlSecondaryDir.setVisible(chkSecondaryDir.isSelected());
        }
        else if (currentSelectedChart == ChartKind.secondaryDir)
        {
            chkSecondaryDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.secondaryDir;
            chkSecondaryDir.setSelected(true);
            pnlSecondaryDir.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkSecondaryDirActionPerformed
    
    private void chkPrimaryDirActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkPrimaryDirActionPerformed
    {//GEN-HEADEREND:event_chkPrimaryDirActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkPrimaryDir.setSelected(true);
            }
            pnlPrimaryDir.setVisible(chkPrimaryDir.isSelected());
        }
        else if (currentSelectedChart == ChartKind.primaryDir)
        {
            chkPrimaryDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.primaryDir;
            chkPrimaryDir.setSelected(true);
            pnlPrimaryDir.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkPrimaryDirActionPerformed
    
    private void chkSymbolicDirActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSymbolicDirActionPerformed
    {//GEN-HEADEREND:event_chkSymbolicDirActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSymbolicDir.setSelected(true);
            }
            pnlSymbolicDir.setVisible(chkSymbolicDir.isSelected());
        }
        else if (currentSelectedChart == ChartKind.symbolicDir)
        {
            chkSymbolicDir.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.symbolicDir;
            chkSymbolicDir.setSelected(true);
            pnlSymbolicDir.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkSymbolicDirActionPerformed
    
    private void chkSeedActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkSeedActionPerformed
    {//GEN-HEADEREND:event_chkSeedActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkSeed.setSelected(true);
            }
            jPanel31.setVisible(chkSeed.isSelected());
        }
        else if (currentSelectedChart == ChartKind.seed)
        {
            chkSeed.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.seed;
            chkSeed.setSelected(true);
            jPanel31.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkSeedActionPerformed
    
    private void chkNormalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkNormalActionPerformed
    {//GEN-HEADEREND:event_chkNormalActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkNormal.setSelected(true);
            }
            //pnlNormal.setVisible(chkNormal.isSelected());
        }
        else if (currentSelectedChart == ChartKind.normal)
        {
            chkNormal.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.normal;
            chkNormal.setSelected(true);
            //pnlNormal.setVisible(true);
            pnlCoordSystem.setEnabled(true);
            pnlHouseSystem.setEnabled(true);
        }
    }//GEN-LAST:event_chkNormalActionPerformed
    
    private void chkAstronomicalActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_chkAstronomicalActionPerformed
    {//GEN-HEADEREND:event_chkAstronomicalActionPerformed
        if (currentSelectedChart == ChartKind.all)
        {
            if (selectedCharts() < 1)
            {
                chkAstronomical.setSelected(true);
            }
            pnlLocal.setVisible(chkAstronomical.isSelected());
        }
        else if (currentSelectedChart == ChartKind.local)
        {
            chkAstronomical.setSelected(true);    //Must keep the check box selected
        }
        else
        {
            unselectAllChartKinds();
            currentSelectedChart = ChartKind.local;
            chkAstronomical.setSelected(true);
            pnlLocal.setVisible(true);
            pnlCoordSystem.setEnabled(false);
            pnlHouseSystem.setEnabled(false);
        }
    }//GEN-LAST:event_chkAstronomicalActionPerformed
    
    private void jOptSingleSelectionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jOptSingleSelectionActionPerformed
    {//GEN-HEADEREND:event_jOptSingleSelectionActionPerformed
        unselectAllChartKinds();
        chkNormal.setSelected(true);
        //pnlNormal.setVisible(true);
        currentSelectedChart = ChartKind.normal;
        //btnSelectAll.setVisible(false);
    }//GEN-LAST:event_jOptSingleSelectionActionPerformed
    
    private void jOptMultiSelectionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jOptMultiSelectionActionPerformed
    {//GEN-HEADEREND:event_jOptMultiSelectionActionPerformed
        //btnSelectAll.setVisible(true);
        currentSelectedChart = ChartKind.all;
    }//GEN-LAST:event_jOptMultiSelectionActionPerformed
    
    private void unselectAllChartKinds()
    {
        chkNormal.setSelected(false);
        chkAstronomical.setSelected(false);
        chkSeed.setSelected(false);
        chkSymbolicDir.setSelected(false);
        chkPrimaryDir.setSelected(false);
        chkSecondaryDir.setSelected(false);
        chkTransits.setSelected(false);
        chkRevolution.setSelected(false);
        chkCycle.setSelected(false);
        chkSynastry.setSelected(false);
        chkComposite.setSelected(false);
        chkFree.setSelected(false);
        chkProjective.setSelected(false);
        chkHarmonic.setSelected(false);
        
        //pnlNormal.setVisible(false);
        pnlLocal.setVisible(false);
        jPanel31.setVisible(false);
        pnlSymbolicDir.setVisible(false);
        pnlPrimaryDir.setVisible(false);
        pnlSecondaryDir.setVisible(false);
        pnlTransits.setVisible(false);
        pnlRevolution.setVisible(false);
        pnlCycle.setVisible(false);
        pnlSynastry.setVisible(false);
        pnlComposite.setVisible(false);
        pnlFree.setVisible(false);
        jPanel55.setVisible(false);
        pnlHarmonic.setVisible(false);
    }
    
    private void btnSelectAllActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSelectAllActionPerformed
    {//GEN-HEADEREND:event_btnSelectAllActionPerformed
        chkNormal.setSelected(true);
        chkAstronomical.setSelected(true);
        chkSeed.setSelected(true);
        chkSymbolicDir.setSelected(true);
        chkPrimaryDir.setSelected(true);
        chkSecondaryDir.setSelected(true);
        chkTransits.setSelected(true);
        chkRevolution.setSelected(true);
        chkCycle.setSelected(true);
        chkSynastry.setSelected(true);
        chkComposite.setSelected(true);
        chkFree.setSelected(true);
        chkProjective.setSelected(true);
        chkHarmonic.setSelected(true);
        
        //pnlNormal.setVisible(true);
        pnlLocal.setVisible(true);
        jPanel31.setVisible(true);
        pnlSymbolicDir.setVisible(true);
        pnlPrimaryDir.setVisible(true);
        pnlSecondaryDir.setVisible(true);
        pnlTransits.setVisible(true);
        pnlRevolution.setVisible(true);
        pnlCycle.setVisible(true);
        pnlSynastry.setVisible(true);
        pnlComposite.setVisible(true);
        pnlFree.setVisible(true);
        jPanel55.setVisible(true);
        pnlHarmonic.setVisible(true);
        jOptMultiSelection.setSelected(true);
        //jOptMultiSelectionActionPerformed(null);
    }//GEN-LAST:event_btnSelectAllActionPerformed
    
    /** close the frame */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        if (parentForm instanceof MainForm)
            ((MainForm)parentForm).setCartesFrame(false);
        setVisible(false);
        dispose();
    }//GEN-LAST:event_exitForm

    private void sldZodiacStateChanged(javax.swing.event.ChangeEvent evt)//GEN-FIRST:event_sldZodiacStateChanged
    {//GEN-HEADEREND:event_sldZodiacStateChanged
        int value = sldZodiac.getValue();
        Font f = lblZodiacSize.getFont();
        lblZodiacSize.setFont(new Font(f.getName(), Font.PLAIN, value));
    }//GEN-LAST:event_sldZodiacStateChanged

    private void txtPlaceReturnMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtPlaceReturnMouseClicked
    {//GEN-HEADEREND:event_txtPlaceReturnMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtPlaceReturn, "places", "PLACENAME", bundle.getString("placesPLACENAME"), false, null, false, null, false);
            txtPlaceReturn.setText(strText);

            String latitude = "";
            String longitude = "";

            if (!strText.equals(""))
            {
                ArrayList p = places.getRecords();
                for (int i = 0; i < p.size(); i++)
                {
                    ArrayList v = (ArrayList) p.get(i);
                    String strID = String.valueOf(v.get(0));
                    String strName = String.valueOf(v.get(1));
                    if (strName.equals(strText))
                    {
                        Place place = starLoginManager.getPlace(strID);
                        latitude = place.getPlaceLatitude();
                        longitude = place.getPlaceLongitude();
                        
                        FLatitude l = new FLatitude(latitude);
                        latitude = l.getLatitude();
                        FLongitude lo = new FLongitude(longitude);
                        longitude = lo.getLongitude();
                        break;
                    }
                }
            }

            //update latitude and longitude fields
            txtLatitudeReturn.setText(latitude);
            txtLongitudeReturn.setText(longitude);
            placeReturn = strText;
            MainClass.testPlace(strText, latitude, longitude, this);
        }
    }//GEN-LAST:event_txtPlaceReturnMouseClicked

    private void txtPlaceReturnKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceReturnKeyPressed
    {//GEN-HEADEREND:event_txtPlaceReturnKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPlaceReturn.setText(placeReturn);
        }
    }//GEN-LAST:event_txtPlaceReturnKeyPressed

    private void txtPlaceCycleMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_txtPlaceCycleMouseClicked
    {//GEN-HEADEREND:event_txtPlaceCycleMouseClicked
        if (evt.getClickCount() == 2)
        {
            String strText = MainClass.getLookForField(txtPlaceCycle, "places", "PLACENAME", bundle.getString("placesPLACENAME"), false, null, false, null, false);
            txtPlaceCycle.setText(strText);

            String latitude = "";
            String longitude = "";

            if (!strText.equals(""))
            {
                ArrayList p = places.getRecords();
                for (int i = 0; i < p.size(); i++)
                {
                    ArrayList v = (ArrayList) p.get(i);
                    String strID = String.valueOf(v.get(0));
                    String strName = String.valueOf(v.get(1));
                    if (strName.equals(strText))
                    {
                        Place place = starLoginManager.getPlace(strID);
                        latitude = place.getPlaceLatitude();
                        longitude = place.getPlaceLongitude();
                        
                        FLatitude l = new FLatitude(latitude);
                        latitude = l.getLatitude();
                        FLongitude lo = new FLongitude(longitude);
                        longitude = lo.getLongitude();
                        break;
                    }
                }
            }

            //update latitude and longitude fields
            txtLatitudeCycle.setText(latitude);
            txtLongitudeCycle.setText(longitude);
            placeCycle = strText;
            MainClass.testPlace(strText, latitude, longitude, this);
        }
    }//GEN-LAST:event_txtPlaceCycleMouseClicked

    private void txtPlaceCycleKeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_txtPlaceCycleKeyPressed
    {//GEN-HEADEREND:event_txtPlaceCycleKeyPressed
        if (evt.getKeyCode() != KeyEvent.VK_ALT)
        {
            kc = evt.getKeyCode();
        }
        if (kc == KeyEvent.VK_ESCAPE)
        {
            txtPlaceCycle.setText(placeCycle);
        }
    }//GEN-LAST:event_txtPlaceCycleKeyPressed
    
    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDisplayCharts;
    private javax.swing.JButton btnEditFree;
    private javax.swing.JButton btnOKEventSelectComposite;
    private javax.swing.JButton btnOKEventSelectSysnastry;
    private javax.swing.JButton btnReadChart;
    private javax.swing.JButton btnSelectAll;
    private javax.swing.JComboBox cboAsteroid;
    private javax.swing.JComboBox cboComet;
    private javax.swing.JComboBox cboD1;
    private javax.swing.JComboBox cboD2;
    private javax.swing.JComboBox cboDS;
    private javax.swing.JComboBox cboPart;
    private javax.swing.JComboBox cboPartMinus;
    private javax.swing.JComboBox cboPartPlus;
    private javax.swing.JComboBox cboPartRef;
    private javax.swing.JComboBox cboPlanet1Cycle;
    private javax.swing.JComboBox cboPlanet2Cycle;
    private javax.swing.JComboBox cboPlanetReturn;
    private javax.swing.JComboBox cboStarIdentity;
    private javax.swing.JCheckBox chkAspectAS;
    private javax.swing.JCheckBox chkAspectCeres;
    private javax.swing.JCheckBox chkAspectChiron;
    private javax.swing.JCheckBox chkAspectEast;
    private javax.swing.JCheckBox chkAspectGaia;
    private javax.swing.JCheckBox chkAspectJuno;
    private javax.swing.JCheckBox chkAspectJupiter;
    private javax.swing.JCheckBox chkAspectLilith;
    private javax.swing.JCheckBox chkAspectMC;
    private javax.swing.JCheckBox chkAspectMars;
    private javax.swing.JCheckBox chkAspectMercury;
    private javax.swing.JCheckBox chkAspectMoon;
    private javax.swing.JCheckBox chkAspectNeptune;
    private javax.swing.JCheckBox chkAspectNodes;
    private javax.swing.JCheckBox chkAspectOtherPoint;
    private javax.swing.JCheckBox chkAspectPallas;
    private javax.swing.JCheckBox chkAspectPluto;
    private javax.swing.JCheckBox chkAspectSaturn;
    private javax.swing.JCheckBox chkAspectSun;
    private javax.swing.JCheckBox chkAspectUranus;
    private javax.swing.JCheckBox chkAspectVenus;
    private javax.swing.JCheckBox chkAspectVertex;
    private javax.swing.JCheckBox chkAspectVesta;
    private javax.swing.JCheckBox chkAspectVulcan;
    private javax.swing.JCheckBox chkAspectZenith;
    private javax.swing.JCheckBox chkAspects;
    private javax.swing.JCheckBox chkAspectsSymbol;
    private javax.swing.JCheckBox chkAsteroids;
    private javax.swing.JCheckBox chkAstronomical;
    private javax.swing.JCheckBox chkBarycenter;
    private javax.swing.JCheckBox chkBiQuintile;
    private javax.swing.JCheckBox chkCeres;
    private javax.swing.JCheckBox chkChiron;
    private javax.swing.JCheckBox chkComposite;
    private javax.swing.JCheckBox chkConjunction;
    private javax.swing.JCheckBox chkConstellations;
    private javax.swing.JCheckBox chkCoordinates;
    private javax.swing.JCheckBox chkCycle;
    private javax.swing.JRadioButton chkDomitudes;
    private javax.swing.JCheckBox chkEast;
    private javax.swing.JRadioButton chkEcliptic;
    private javax.swing.JRadioButton chkEquatorial;
    private javax.swing.JCheckBox chkFree;
    private javax.swing.JCheckBox chkGaia;
    private javax.swing.JRadioButton chkGeocentric;
    private javax.swing.JCheckBox chkHarmonic;
    private javax.swing.JRadioButton chkHeliocentric;
    private javax.swing.JRadioButton chkHeliocentricNormal;
    private javax.swing.JRadioButton chkHeliocentricSidereal;
    private javax.swing.JCheckBox chkHouses;
    private javax.swing.JCheckBox chkHousesCoord;
    private javax.swing.JCheckBox chkInconjunct;
    private javax.swing.JCheckBox chkJuno;
    private javax.swing.JCheckBox chkJupiter;
    private javax.swing.JCheckBox chkLilith;
    private javax.swing.JRadioButton chkLocal;
    private javax.swing.JCheckBox chkMars;
    private javax.swing.JCheckBox chkMercury;
    private javax.swing.JCheckBox chkMoon;
    private javax.swing.JCheckBox chkNN;
    private javax.swing.JCheckBox chkNeptune;
    private javax.swing.JCheckBox chkNonagon;
    private javax.swing.JCheckBox chkNormal;
    private javax.swing.JCheckBox chkOpposition;
    private javax.swing.JCheckBox chkOtherAspect;
    private javax.swing.JCheckBox chkOtherPoint;
    private javax.swing.JCheckBox chkPallas;
    private javax.swing.JCheckBox chkPluto;
    private javax.swing.JCheckBox chkPrecession;
    private javax.swing.JCheckBox chkPrimaryDir;
    private javax.swing.JCheckBox chkProjective;
    private javax.swing.JCheckBox chkQuadriNonagon;
    private javax.swing.JCheckBox chkQuintile;
    private javax.swing.JCheckBox chkRevolution;
    private javax.swing.JCheckBox chkSaturn;
    private javax.swing.JCheckBox chkSecondaryDir;
    private javax.swing.JCheckBox chkSeed;
    private javax.swing.JCheckBox chkSemiQuintile;
    private javax.swing.JCheckBox chkSemiSextile;
    private javax.swing.JCheckBox chkSemiSquare;
    private javax.swing.JCheckBox chkSeptile;
    private javax.swing.JCheckBox chkSesquiSquare;
    private javax.swing.JCheckBox chkSextile;
    private javax.swing.JCheckBox chkShaded;
    private javax.swing.JRadioButton chkSidereal;
    private javax.swing.JCheckBox chkSignsName;
    private javax.swing.JCheckBox chkSquare;
    private javax.swing.JCheckBox chkStars;
    private javax.swing.JCheckBox chkStraightLines;
    private javax.swing.JCheckBox chkSun;
    private javax.swing.JCheckBox chkSymbolicDir;
    private javax.swing.JCheckBox chkSynastry;
    private javax.swing.JCheckBox chkTransits;
    private javax.swing.JCheckBox chkTriDectile;
    private javax.swing.JCheckBox chkTrine;
    private javax.swing.JRadioButton chkTropical;
    private javax.swing.JCheckBox chkTrueLilith;
    private javax.swing.JCheckBox chkUranus;
    private javax.swing.JCheckBox chkVenus;
    private javax.swing.JCheckBox chkVertex;
    private javax.swing.JCheckBox chkVesta;
    private javax.swing.JCheckBox chkVigintile;
    private javax.swing.JCheckBox chkVulcan;
    private javax.swing.JCheckBox chkZenith;
    private javax.swing.ButtonGroup grpAstronView;
    private javax.swing.ButtonGroup grpBarycenter;
    private javax.swing.ButtonGroup grpChartChoice;
    private javax.swing.ButtonGroup grpColorMode;
    private javax.swing.ButtonGroup grpCompositeFrom;
    private javax.swing.ButtonGroup grpCompositeSelect;
    private javax.swing.ButtonGroup grpGeo;
    private javax.swing.ButtonGroup grpGeoHelio;
    private javax.swing.ButtonGroup grpHelio;
    private javax.swing.ButtonGroup grpHouseSystem;
    private javax.swing.ButtonGroup grpOtherPoint;
    private javax.swing.ButtonGroup grpSavedCharts;
    private javax.swing.ButtonGroup grpSynastrySelect;
    private javax.swing.ButtonGroup grpZodDir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JRadioButton jOptMultiSelection;
    private javax.swing.JRadioButton jOptSingleSelection;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel108;
    private javax.swing.JPanel jPanel109;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel110;
    private javax.swing.JPanel jPanel111;
    private javax.swing.JPanel jPanel112;
    private javax.swing.JPanel jPanel113;
    private javax.swing.JPanel jPanel114;
    private javax.swing.JPanel jPanel115;
    private javax.swing.JPanel jPanel116;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel118;
    private javax.swing.JPanel jPanel119;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel120;
    private javax.swing.JPanel jPanel121;
    private javax.swing.JPanel jPanel122;
    private javax.swing.JPanel jPanel123;
    private javax.swing.JPanel jPanel124;
    private javax.swing.JPanel jPanel125;
    private javax.swing.JPanel jPanel126;
    private javax.swing.JPanel jPanel127;
    private javax.swing.JPanel jPanel128;
    private javax.swing.JPanel jPanel129;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel130;
    private javax.swing.JPanel jPanel131;
    private javax.swing.JPanel jPanel132;
    private javax.swing.JPanel jPanel133;
    private javax.swing.JPanel jPanel134;
    private javax.swing.JPanel jPanel135;
    private javax.swing.JPanel jPanel136;
    private javax.swing.JPanel jPanel137;
    private javax.swing.JPanel jPanel138;
    private javax.swing.JPanel jPanel139;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel140;
    private javax.swing.JPanel jPanel141;
    private javax.swing.JPanel jPanel142;
    private javax.swing.JPanel jPanel143;
    private javax.swing.JPanel jPanel144;
    private javax.swing.JPanel jPanel145;
    private javax.swing.JPanel jPanel146;
    private javax.swing.JPanel jPanel147;
    private javax.swing.JPanel jPanel148;
    private javax.swing.JPanel jPanel149;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel150;
    private javax.swing.JPanel jPanel151;
    private javax.swing.JPanel jPanel152;
    private javax.swing.JPanel jPanel153;
    private javax.swing.JPanel jPanel154;
    private javax.swing.JPanel jPanel155;
    private javax.swing.JPanel jPanel156;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblAspectsColorMode;
    private javax.swing.JLabel lblCharactersSize;
    private javax.swing.JLabel lblColorAir;
    private javax.swing.JLabel lblColorAsteroids;
    private javax.swing.JLabel lblColorBiQuintile;
    private javax.swing.JLabel lblColorConjunction;
    private javax.swing.JLabel lblColorDynamic;
    private javax.swing.JLabel lblColorEarth;
    private javax.swing.JLabel lblColorFire;
    private javax.swing.JLabel lblColorGaia;
    private javax.swing.JLabel lblColorHarmonic;
    private javax.swing.JLabel lblColorHouses;
    private javax.swing.JLabel lblColorInconjunct;
    private javax.swing.JLabel lblColorJupiter;
    private javax.swing.JLabel lblColorMars;
    private javax.swing.JLabel lblColorMercury;
    private javax.swing.JLabel lblColorMoon;
    private javax.swing.JLabel lblColorNeptune;
    private javax.swing.JLabel lblColorNeutral;
    private javax.swing.JLabel lblColorNodes;
    private javax.swing.JLabel lblColorNonagon;
    private javax.swing.JLabel lblColorOpposition;
    private javax.swing.JLabel lblColorOtherAspect;
    private javax.swing.JLabel lblColorPluto;
    private javax.swing.JLabel lblColorQuadriNonagon;
    private javax.swing.JLabel lblColorQuintile;
    private javax.swing.JLabel lblColorSaturn;
    private javax.swing.JLabel lblColorSemiQuintile;
    private javax.swing.JLabel lblColorSemiSextile;
    private javax.swing.JLabel lblColorSemiSquare;
    private javax.swing.JLabel lblColorSeptile;
    private javax.swing.JLabel lblColorSesquiSquare;
    private javax.swing.JLabel lblColorSextile;
    private javax.swing.JLabel lblColorSquare;
    private javax.swing.JLabel lblColorSun;
    private javax.swing.JLabel lblColorText;
    private javax.swing.JLabel lblColorTridectile;
    private javax.swing.JLabel lblColorTrine;
    private javax.swing.JLabel lblColorUranus;
    private javax.swing.JLabel lblColorVenus;
    private javax.swing.JLabel lblColorVigintile;
    private javax.swing.JLabel lblColorVulcan;
    private javax.swing.JLabel lblColorWater;
    private javax.swing.JLabel lblForEvent;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblPlanetSize;
    private javax.swing.JLabel lblRemainEventComposite;
    private javax.swing.JLabel lblRemainEventSynastry;
    private javax.swing.JLabel lblSignSize;
    private javax.swing.JLabel lblStarName;
    private javax.swing.JLabel lblZodiacSize;
    private javax.swing.JRadioButton optAbenragel;
    private javax.swing.JRadioButton optAlbategnius;
    private javax.swing.JRadioButton optAlcabitius;
    private javax.swing.JRadioButton optAncient;
    private javax.swing.JRadioButton optBazchenoff;
    private javax.swing.JRadioButton optCampanus;
    private javax.swing.JRadioButton optColinEvans;
    private javax.swing.JRadioButton optColorMode1;
    private javax.swing.JRadioButton optColorMode2;
    private javax.swing.JRadioButton optCompositeChartSelect;
    private javax.swing.JRadioButton optCompositeEventSelect;
    private javax.swing.JRadioButton optCompositeFromAS;
    private javax.swing.JRadioButton optCompositeFromMC;
    private javax.swing.JRadioButton optDifferentWeights;
    private javax.swing.JRadioButton optEastAS;
    private javax.swing.JRadioButton optEastAries;
    private javax.swing.JRadioButton optEquatorialRegular;
    private javax.swing.JRadioButton optHorizon;
    private javax.swing.JRadioButton optKoch;
    private javax.swing.JRadioButton optLastSavedChart;
    private javax.swing.JRadioButton optMaternusAs;
    private javax.swing.JRadioButton optMaternusMC;
    private javax.swing.JRadioButton optNodal;
    private javax.swing.JRadioButton optOtherPtAsteroid;
    private javax.swing.JRadioButton optOtherPtComet;
    private javax.swing.JRadioButton optOtherPtNone;
    private javax.swing.JRadioButton optOtherPtPart;
    private javax.swing.JRadioButton optOtherPtStar;
    private javax.swing.JRadioButton optPlacidus;
    private javax.swing.JRadioButton optPorpyre;
    private javax.swing.JRadioButton optRegiomontanus;
    private javax.swing.JRadioButton optSavedChart;
    private javax.swing.JRadioButton optSemiAngular;
    private javax.swing.JRadioButton optSingleWeight;
    private javax.swing.JRadioButton optSolar;
    private javax.swing.JRadioButton optSynastryChartSelect;
    private javax.swing.JRadioButton optSynastryEventSelect;
    private javax.swing.JRadioButton optTwoHours;
    private javax.swing.JRadioButton optWiesel;
    private javax.swing.JRadioButton optZenith;
    private javax.swing.JRadioButton optZenithal;
    private javax.swing.JRadioButton optZodiacal;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnlAspectColorChoice;
    private javax.swing.JPanel pnlAspects;
    private javax.swing.JPanel pnlChartColorChoice;
    private javax.swing.JPanel pnlChartKind;
    private javax.swing.JPanel pnlChartLook;
    private javax.swing.JPanel pnlComposite;
    private javax.swing.JPanel pnlCoordSystem;
    private javax.swing.JPanel pnlCycle;
    private javax.swing.JPanel pnlFree;
    private javax.swing.JPanel pnlHarmonic;
    private javax.swing.JPanel pnlHouseSystem;
    private javax.swing.JPanel pnlLocal;
    private javax.swing.JPanel pnlOrbs;
    private javax.swing.JPanel pnlOtherPoint;
    private javax.swing.JPanel pnlOtherPtPart;
    private javax.swing.JPanel pnlOtherPtStar;
    private javax.swing.JPanel pnlPlanets;
    private javax.swing.JPanel pnlPrimaryDir;
    private javax.swing.JPanel pnlRevolution;
    private javax.swing.JPanel pnlSecondaryDir;
    private javax.swing.JPanel pnlSymbolicDir;
    private javax.swing.JPanel pnlSynastry;
    private javax.swing.JPanel pnlTransits;
    private javax.swing.JSlider sldCharacters;
    private javax.swing.JSlider sldPlanets;
    private javax.swing.JSlider sldSigns;
    private javax.swing.JSlider sldStars;
    private javax.swing.JSlider sldZodiac;
    private javax.swing.JTabbedPane tabSettings;
    private javax.swing.JTextField txtBiquintile;
    private javax.swing.JTextField txtCompositeChartsNB;
    private javax.swing.JTextField txtConjunction;
    private javax.swing.JTextField txtCorrespondD1;
    private javax.swing.JTextField txtCorrespondD2;
    private javax.swing.JTextField txtCorrespondDS;
    private javax.swing.JTextField txtCyclesNB;
    private javax.swing.JTextField txtDir1Age;
    private javax.swing.JTextField txtDir2Age;
    private javax.swing.JTextField txtDirSAge;
    private javax.swing.JTextField txtDivConjunction;
    private javax.swing.JTextField txtDivOpposition;
    private javax.swing.JTextField txtDivOther;
    private javax.swing.JTextField txtDivSextile;
    private javax.swing.JTextField txtDivSquare;
    private javax.swing.JTextField txtDivTrine;
    private javax.swing.JTextField txtEqualsD1;
    private javax.swing.JTextField txtEqualsD2;
    private javax.swing.JTextField txtEqualsDS;
    private javax.swing.JTextField txtHarmonicNB;
    private javax.swing.JTextField txtInconjunct;
    private javax.swing.JTextField txtLatitudeCycle;
    private javax.swing.JTextField txtLatitudeReturn;
    private javax.swing.JTextField txtLongitudeCycle;
    private javax.swing.JTextField txtLongitudeReturn;
    private javax.swing.JTextField txtNonagone;
    private javax.swing.JTextField txtOpposition;
    private javax.swing.JTextField txtOrbColCol;
    private javax.swing.JTextField txtOrbColVirtMaj;
    private javax.swing.JTextField txtOrbColVirtMin;
    private javax.swing.JTextField txtOrbIndivCol;
    private javax.swing.JTextField txtOrbIndivIndiv;
    private javax.swing.JTextField txtOrbIndivJS;
    private javax.swing.JTextField txtOrbIndivVirtMaj;
    private javax.swing.JTextField txtOrbIndivVirtMin;
    private javax.swing.JTextField txtOrbJSCol;
    private javax.swing.JTextField txtOrbJSJS;
    private javax.swing.JTextField txtOrbJSVirtMin;
    private javax.swing.JTextField txtOrbJSvirtMaj;
    private javax.swing.JTextField txtOrbLumCol;
    private javax.swing.JTextField txtOrbLumIndiv;
    private javax.swing.JTextField txtOrbLumJS;
    private javax.swing.JTextField txtOrbLumLum;
    private javax.swing.JTextField txtOrbLumVirtMaj;
    private javax.swing.JTextField txtOrbLumVirtMin;
    private javax.swing.JTextField txtOrbVirtMajVirtMaj;
    private javax.swing.JTextField txtOrbVirtMajVirtMin;
    private javax.swing.JTextField txtOrbvirtMinVirtMin;
    private javax.swing.JTextField txtOtherAspect;
    private javax.swing.JTextField txtOtherAspectName;
    private javax.swing.JTextField txtPlaceCycle;
    private javax.swing.JTextField txtPlaceReturn;
    private javax.swing.JTextField txtQuadriNonagon;
    private javax.swing.JTextField txtQuintile;
    private javax.swing.JTextField txtRevolNB;
    private javax.swing.JTextField txtSemiQuintile;
    private javax.swing.JTextField txtSemiSextile;
    private javax.swing.JTextField txtSemiSquare;
    private javax.swing.JTextField txtSeptile;
    private javax.swing.JTextField txtSesquiSquare;
    private javax.swing.JTextField txtSextile;
    private javax.swing.JTextField txtSquare;
    private javax.swing.JTextField txtTransitsDate;
    private javax.swing.JTextField txtTriDectile;
    private javax.swing.JTextField txtTrine;
    private javax.swing.JTextField txtValueOtherAspect;
    private javax.swing.JTextField txtVigintile;
    // End of variables declaration//GEN-END:variables
    
}
