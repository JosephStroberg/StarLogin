/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.IHM;

import StarLogin.IHM.components.ImageSurface;
import StarLogin.IHM.components.KeyType.MultiKeySelectionManager;
import StarLogin.Persistence.DataBaseRecords;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.DateTimeEvent;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Events;
import StarLogin.Systeme.Data.Option;
import StarLogin.Systeme.Data.Place;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.Systeme.grids.DataGrid;
import java.awt.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author francoisdeschamps
 */
public class ListeEventForm extends javax.swing.JDialog
{
    private StarLoginManager starLoginManager = MainClass.starLoginManager;
    private Option currentOption;
    private StarLogin.Systeme.Data.Event event;
    private Events events;
    private String orderby = " ORDER BY Surname, OtherNames, EventType";
    private Records fields;
    private Records vEvents;//champs visibles seulement
    private String sFRQ = ",COMMENTS,PICTURE";
    private String sFRQv = "";
    String listeChampsVisibles;
    String listeTousChamps;
    private boolean bFilter = false;
    private String sQuery;
    private String sQueryV;
    private String eventID;
    //private String saveEventID;
    private ImageIcon picture;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private int eventRow;
    private int nbOfRows;
    private int saveEventRow;
    private DataGrid dgrEvents;
    public boolean bolClickFromGrid=false;
    private DefaultComboBoxModel cmLookFor;     //liste des champs
    private String classname = this.getClass().getName();
    ArrayList champs2;
    ArrayList alias2;
    ArrayList vchamps;
    ArrayList vsizes;
    ArrayList valias;
    private String filter = "";
    private String sQueryFields = "SELECT ID, SURNAME, OTHERNAMES, ENTITYTYPE, EVENTTYPE, SIGN, ASCENDANT";
    private boolean bdelete = false;
    
    /**
     * Creates new form DlgListEventForm
     */
    public ListeEventForm(java.awt.Frame parent, boolean modal, String eventid)
    {
        super(parent, modal);
        eventID = eventid;
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        events = starLoginManager.getEvents(null);
        currentOption = MainClass.getCurrentOption();
        String currentEventID;
        if (eventID.equals("-1"))
            currentEventID = MainClass.currentEventID;
        else
            currentEventID = eventID;
        
        initComponents();
        resetLangue();
        
        ImageIcon iconImage = new ImageIcon(getClass().getResource("/StarLogin/images/event.png"));
        Image icon = iconImage.getImage();
        this.setIconImage(icon);
        
        int pos = classname.lastIndexOf(".");
        if (pos > 0)
            classname = classname.substring(pos + 1);
        int params[] = MainClass.getWindowParams(classname);
        this.setBounds(params[0], params[1], params[2], params[3]);
        
        //initialize data
        initData(currentEventID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        setVisible(true);
    }
    
    public void setOrder(String order)
    {
        orderby = order;
        refreshRecord();
        showEvent(eventID);
    }

    public void removeFromGrid(int grdRow)
    {
        String id = events.getIDFromRow(grdRow);
        starLoginManager.removeRecord(id, "events");
        bdelete = true;
    }
    
    public void saveColOrder()
    {
        if (dgrEvents == null)
            return;
        JTable tbl = dgrEvents.getTable();
        String listeChamps = "";
        for (int i=1; i<tbl.getColumnCount(); i++)
        {
            String colName = tbl.getColumnName(i);
            for (int j=1; j<vchamps.size(); j++)
            {
                if (String.valueOf(valias.get(j)).equals(colName))
                {
                    colName = String.valueOf(vchamps.get(j));
                }
            }
            if (!colName.equals("ID"))
                listeChamps = listeChamps.concat(colName).concat(",");
        }
        listeChamps = listeChamps.substring(0, listeChamps.length() - 1);
        listeChamps = listeChamps.replace(DataBaseRecords.HDFORMAT, "HEURE_DEBUT");
        listeChamps = listeChamps.replace(DataBaseRecords.HFFORMAT, "HEURE_FIN");
        listeChampsVisibles = listeChamps;
        starLoginManager.updateDataBase("UPDATE ordrechamps SET LISTECHAMPSVISIBLES='" + listeChamps + "' WHERE NOMTABLE='Events'");
    }
    
    public void setRow()
    {
        refreshRecord();
        saveEventRow = MainClass.getCurrentRow(events, saveEventRow);
        showEvent(saveEventRow);
    }
    
    public void refreshRecord()
    {
        //show the record data
        listeChampsVisibles = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPSVISIBLES", " WHERE NOMTABLE='Events'");
        listeTousChamps = starLoginManager.getStringFieldValue("ordrechamps", "LISTECHAMPS", " WHERE NOMTABLE='Events'");
        sQueryV = "SELECT ID,".concat(listeChampsVisibles).concat(sFRQv).concat(" FROM events");
        sQuery = "SELECT ID,".concat(listeTousChamps).concat(sFRQ).concat(" FROM Events");
        events = starLoginManager.getEvents(sQuery + " WHERE ID>0 " + filter + orderby);
        vEvents = starLoginManager.getRecords(sQueryV + " WHERE ID>0 " + filter + orderby, "events");
        fields = starLoginManager.getRecords(sQueryFields + " FROM events WHERE ID=1", "events");
        vchamps = vEvents.getFields();
        vsizes = vEvents.getSizes();
        valias = vEvents.getHeaders();
        champs2 = fields.getFields();
        alias2 = fields.getHeaders();
        dgrEvents = new DataGrid(vEvents.getRecords(), valias, vchamps, vsizes, pnlTable, false, true, false, false, this, true, 40);
        dgrEvents.getTable().setToolTipText(bundle.getString("DoubleClic2Modify"));
        Rectangle rec = this.getBounds();
        this.setBounds(rec.x, rec.y, rec.width, rec.height-1);
        this.setBounds(rec.x, rec.y, rec.width, rec.height+1);
        //showEvent(saveEventID);
        
        if (bdelete)
            pnlTable.paintAll(pnlTable.getGraphics());
        bdelete = false;
    }
    
    public ListeEventForm getForm()
    {
        return this;
    }
    
    private void resetLangue()
    {
        mnuDelete.setText(bundle.getString("SUPPRIMER_L'ENREGISTREMENT_SELECTIONNE"));
        setTitle(bundle.getString("Events"));
        btnFilter.setText(bundle.getString("Filtrer"));
        btnRemove.setToolTipText(bundle.getString("RemoveEvent"));
        btnAdd.setText(bundle.getString("Add"));
        btnAdd.setToolTipText(bundle.getString("AddEvent"));
        btnModify.setText(bundle.getString("Modifier"));
        btnModify.setToolTipText(bundle.getString("ModifierEvent"));
        btnLookFor.setText(bundle.getString("LookFor"));
        btnLookFor1.setText(bundle.getString("TraitementDonnees"));
        btnRemove.setText(bundle.getString("Remove"));
        btnSelectFields.setText(bundle.getString("SelectFields"));
        btnFilter.setText(bundle.getString("Filter"));
        btnCurrentDayTimeEvent.setToolTipText(bundle.getString("CurentDayTimeEvent"));
        //btnQueries.setToolTipText(bundle.getString("DataGrids"));
        btnHelp.setToolTipText(bundle.getString("Help"));
    }

    private void removeRec()
    {
        if (nbOfRows > 0)
        {
            if (javax.swing.JOptionPane.showConfirmDialog(this, bundle.getString("WantDelete"), "Suppression d'enregistrement", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                setCursor(new Cursor(Cursor.WAIT_CURSOR));
                /*starLoginManager.removeEvent(event);
                events = starLoginManager.getEvents(null);

                if (eventRow > 1)
                    eventRow = eventRow - 1;
                else
                    eventRow = eventRow + 1;
                saveEventID = events.getIDFromRow(eventRow);
                bdelete = true;
                setRow();*/
                JTable tbl = dgrEvents.getTable();
                int row[] = tbl.getSelectedRows();
                for (int i = 0; i < tbl.getSelectedRowCount(); i++)
                {
                    eventID = null2String(tbl.getValueAt(row[i], 0));
                    if (!eventID.equals("-1"))
                    {
                        starLoginManager.updateDataBase("DELETE FROM events WHERE ID=" + eventID);
                    }
                }
                bdelete = true;
                setRow();
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        }
    }

    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    public void setPicture(ImageIcon data)
    {
        picture = data;
    }
    
    public String getEventID()
    {
        return eventID;
    }
    
    public StarLogin.Systeme.Data.Event getEvent()
    {
        return event;
    }
    
    public void setEvent(String eventid)
    {
        eventID = eventid;
        refreshRecord();
        showEvent(eventid);
    }
    
    private void initData(String strID)
    {
        //saveEventID = strID;
        refreshRecord();
        showEvent(strID);
        setLookForCombos();
    }
    
    private void reloadPicture()
    {
        pnlPicture.removeAll();
        ImageSurface imageSurface = new ImageSurface(this, pnlPicture.getSize());
        imageSurface.setToolTipText(null);
        pnlPicture.add(imageSurface, BorderLayout.CENTER);
        imageSurface.loadPicture(picture);
        imageSurface.setMenuEnabled(false);
    }
    
    public void showEvent(int row)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        eventID = events.getIDFromRow(row);
        if (eventID == null || eventID.equals(""))
            eventID = "-1";
        //saveEventID = eventID;
        event = starLoginManager.getEvent(eventID, filter);
        eventRow = row;
        saveEventRow = eventRow;
        nbOfRows = event.getRowNB();
        picture = event.getPicture();
        reloadPicture();
        if (bolClickFromGrid == false)
        {
            dgrEvents.setSelectedRow(eventRow);
        }
        else
        {
            bolClickFromGrid = false;
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void showEvent(String strID)
    {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        eventID = strID;
        //saveEventID = strID;
        event = starLoginManager.getEvent(eventID, filter);
        MainClass.event = event;
        eventRow = events.getRowFromID(eventID);// event.getRow();
        if (!strID.equals("-1")) saveEventRow = eventRow;
        nbOfRows = event.getRowNB();
        picture = event.getPicture();
        reloadPicture();
        dgrEvents.setSelectedRow(eventRow);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    private void setLookForCombos()
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        DefaultComboBoxModel comboModel2 = new DefaultComboBoxModel();
        DefaultComboBoxModel comboModel3 = new DefaultComboBoxModel();
        DefaultComboBoxModel comboModel4 = new DefaultComboBoxModel();
        cmLookFor = new DefaultComboBoxModel();
        for (int i=1; i<alias2.size(); i++)
        {
            String nomchamp = String.valueOf(alias2.get(i));
            if (!nomchamp.startsWith("_"))
            {
                comboModel.addElement(nomchamp);
                comboModel2.addElement(nomchamp);
                comboModel3.addElement(nomchamp);
                comboModel4.addElement(nomchamp);
                cmLookFor.addElement(champs2.get(i));
            }
        }
        comboModel.addElement("");
        comboModel2.addElement("");
        comboModel3.addElement("");
        comboModel4.addElement("");
        cboLookFor.setModel(comboModel);
        cboLookFor1.setModel(comboModel2);
        cboLookFor2.setModel(comboModel3);
        cboLookFor3.setModel(comboModel4);
        cboLookFor.setSelectedIndex(-1);
        cboLookFor1.setSelectedIndex(-1);
        cboLookFor2.setSelectedIndex(-1);
        cboLookFor3.setSelectedIndex(-1);
    }

    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT
     * modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPMenu = new javax.swing.JPopupMenu();
        mnuDelete = new javax.swing.JMenuItem();
        pnlTable = new javax.swing.JPanel();
        pnlControlBar = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnModify = new javax.swing.JButton();
        pnlLookFor = new javax.swing.JPanel();
        cboLookFor = new javax.swing.JComboBox();
        txtLookFor = new javax.swing.JTextField();
        btnLookFor = new javax.swing.JButton();
        btnLookFor1 = new javax.swing.JButton();
        btnSelectFields = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        btnCurrentDayTimeEvent = new javax.swing.JButton();
        btnHelp = new javax.swing.JButton();
        pnlFiltre = new javax.swing.JPanel();
        pnlFilter1 = new javax.swing.JPanel();
        cboLookFor1 = new javax.swing.JComboBox();
        txtLookFor1 = new javax.swing.JTextField();
        pnlFilter2 = new javax.swing.JPanel();
        cboLookFor2 = new javax.swing.JComboBox();
        txtLookFor2 = new javax.swing.JTextField();
        pnlFilter3 = new javax.swing.JPanel();
        cboLookFor3 = new javax.swing.JComboBox();
        txtLookFor3 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        btnFilter = new javax.swing.JButton();
        pnlPicture = new javax.swing.JPanel();

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources"); // NOI18N
        mnuDelete.setText(bundle.getString("SUPPRIMER_L'ENREGISTREMENT_SELECTIONNE")); // NOI18N
        mnuDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuDeleteActionPerformed(evt);
            }
        });
        jPMenu.add(mnuDelete);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        pnlTable.setLayout(new java.awt.BorderLayout());
        getContentPane().add(pnlTable, java.awt.BorderLayout.CENTER);

        pnlControlBar.setMaximumSize(new java.awt.Dimension(32767, 32));
        pnlControlBar.setMinimumSize(new java.awt.Dimension(1000, 32));
        pnlControlBar.setPreferredSize(new java.awt.Dimension(1000, 198));
        pnlControlBar.setLayout(new java.awt.BorderLayout());

        jPanel1.setPreferredSize(new java.awt.Dimension(575, 198));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        jPanel11.setOpaque(false);
        jPanel11.setPreferredSize(new java.awt.Dimension(570, 102));
        jPanel11.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/add.png"))); // NOI18N
        btnAdd.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnAdd.setMaximumSize(new java.awt.Dimension(31, 31));
        btnAdd.setMinimumSize(new java.awt.Dimension(29, 29));
        btnAdd.setPreferredSize(new java.awt.Dimension(185, 32));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel11.add(btnAdd);

        btnRemove.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/remove.png"))); // NOI18N
        btnRemove.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnRemove.setMaximumSize(new java.awt.Dimension(31, 31));
        btnRemove.setMinimumSize(new java.awt.Dimension(29, 29));
        btnRemove.setPreferredSize(new java.awt.Dimension(185, 32));
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        jPanel11.add(btnRemove);

        btnModify.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/edit.png"))); // NOI18N
        btnModify.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnModify.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnModify.setMaximumSize(new java.awt.Dimension(31, 31));
        btnModify.setMinimumSize(new java.awt.Dimension(29, 29));
        btnModify.setPreferredSize(new java.awt.Dimension(185, 32));
        btnModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModifyActionPerformed(evt);
            }
        });
        jPanel11.add(btnModify);

        pnlLookFor.setPreferredSize(new java.awt.Dimension(565, 32));
        pnlLookFor.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        cboLookFor.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlLookFor.add(cboLookFor);

        txtLookFor.setPreferredSize(new java.awt.Dimension(145, 30));
        pnlLookFor.add(txtLookFor);

        btnLookFor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/lookfor.png"))); // NOI18N
        btnLookFor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor.setPreferredSize(new java.awt.Dimension(200, 32));
        btnLookFor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookForActionPerformed(evt);
            }
        });
        pnlLookFor.add(btnLookFor);

        jPanel11.add(pnlLookFor);

        btnLookFor1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/grid.png"))); // NOI18N
        btnLookFor1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLookFor1.setPreferredSize(new java.awt.Dimension(220, 32));
        btnLookFor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLookFor1ActionPerformed(evt);
            }
        });
        jPanel11.add(btnLookFor1);

        btnSelectFields.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/selected.png"))); // NOI18N
        btnSelectFields.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSelectFields.setPreferredSize(new java.awt.Dimension(220, 32));
        btnSelectFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectFieldsActionPerformed(evt);
            }
        });
        jPanel11.add(btnSelectFields);

        jPanel3.setPreferredSize(new java.awt.Dimension(50, 10));

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 50, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 10, Short.MAX_VALUE)
        );

        jPanel11.add(jPanel3);

        btnCurrentDayTimeEvent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/time.png"))); // NOI18N
        btnCurrentDayTimeEvent.setToolTipText(bundle.getString("CurentDayTimeEvent")); // NOI18N
        btnCurrentDayTimeEvent.setBorder(null);
        btnCurrentDayTimeEvent.setContentAreaFilled(false);
        btnCurrentDayTimeEvent.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnCurrentDayTimeEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCurrentDayTimeEventActionPerformed(evt);
            }
        });
        jPanel11.add(btnCurrentDayTimeEvent);

        btnHelp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/help.png"))); // NOI18N
        btnHelp.setToolTipText(bundle.getString("Help")); // NOI18N
        btnHelp.setBorder(null);
        btnHelp.setContentAreaFilled(false);
        btnHelp.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHelpActionPerformed(evt);
            }
        });
        jPanel11.add(btnHelp);

        jPanel1.add(jPanel11);

        pnlFiltre.setPreferredSize(new java.awt.Dimension(360, 94));
        pnlFiltre.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 1, 0));

        pnlFilter1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        cboLookFor1.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor1.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlFilter1.add(cboLookFor1);

        txtLookFor1.setPreferredSize(new java.awt.Dimension(140, 30));
        pnlFilter1.add(txtLookFor1);

        pnlFiltre.add(pnlFilter1);

        pnlFilter2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        cboLookFor2.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor2.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlFilter2.add(cboLookFor2);

        txtLookFor2.setPreferredSize(new java.awt.Dimension(140, 30));
        pnlFilter2.add(txtLookFor2);

        pnlFiltre.add(pnlFilter2);

        pnlFilter3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        cboLookFor3.setKeySelectionManager(new MultiKeySelectionManager());
        cboLookFor3.setPreferredSize(new java.awt.Dimension(220, 30));
        pnlFilter3.add(cboLookFor3);

        txtLookFor3.setPreferredSize(new java.awt.Dimension(140, 30));
        pnlFilter3.add(txtLookFor3);

        pnlFiltre.add(pnlFilter3);

        jPanel1.add(pnlFiltre);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnFilter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StarLogin/images/filtrer.png"))); // NOI18N
        btnFilter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFilter.setPreferredSize(new java.awt.Dimension(150, 32));
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });
        jPanel2.add(btnFilter);

        jPanel1.add(jPanel2);

        pnlControlBar.add(jPanel1, java.awt.BorderLayout.WEST);

        pnlPicture.setLayout(new java.awt.BorderLayout());
        pnlControlBar.add(pnlPicture, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlControlBar, java.awt.BorderLayout.NORTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAddActionPerformed
    {//GEN-HEADEREND:event_btnAddActionPerformed
        DialogEvent dlgevt = new DialogEvent(this, true, "-1");
        //refreshRecord();
        //showEvent(eventID);
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnRemoveActionPerformed
    {//GEN-HEADEREND:event_btnRemoveActionPerformed
        removeRec();
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnModifyActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnModifyActionPerformed
    {//GEN-HEADEREND:event_btnModifyActionPerformed
        DialogEvent dlgevt = new DialogEvent(this, true, eventID);
        //refreshRecord();
        //showEvent(eventID);
    }//GEN-LAST:event_btnModifyActionPerformed

    private void btnCurrentDayTimeEventActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCurrentDayTimeEventActionPerformed
    {//GEN-HEADEREND:event_btnCurrentDayTimeEventActionPerformed
        /*if (MainClass.getReadOnly())
        {
            JOptionPane.showMessageDialog(this, bundle.getString("CantUseThisFunctionInDemo"), "StarLogin", JOptionPane.WARNING_MESSAGE);
            return;
        }*/

        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        //saveEventID = eventID;

        //get the time zone plus daylight saving time
        TimeZone timeZone = TimeZone.getDefault();
        int timz = timeZone.getRawOffset() + timeZone.getDSTSavings();
        double dblTZ = (double) timz / 3600000.0;

        //get the current date on the system
        GregorianCalendar gc = new GregorianCalendar(timeZone);
        int y = gc.get(Calendar.YEAR);
        int m = 1 + gc.get(Calendar.MONTH);
        int d = gc.get(Calendar.DAY_OF_MONTH);
        int h = gc.get(Calendar.HOUR_OF_DAY);
        int mn = gc.get(Calendar.MINUTE);
        int s = gc.get(Calendar.SECOND);
        FDate fDate = new FDate(d, m, y, " ");
        String localDate = fDate.getFormatedDate();
        FTime fTime = new FTime(h, mn, s);
        String localTime = fTime.getTime();
        double t = fTime.getDecimalHour();
        double utT = t - dblTZ;
        DateTimeEvent dt = new DateTimeEvent(event);
        String utDate;
        String utTime;
        if (utT < 0.0)
        {
            //minus one day
            utDate = dt.addDate(localDate, -1);
        }
        else
        {
            if (utT > 24.0)
            {
                //plus one day
                utDate = dt.addDate(localDate, 1);
            }
            else
            {
                utDate = localDate;
            }
        }
        utTime = new FTime(utT).getTime();

        //get the default place and initialize other event information
        //Place defaultPlace = starLoginManager.getRecord("SELECT PlaceName, PlaceLatitude, PlaceLongitude, Comments, Picture FROM Places WHERE ID=" + currentOption.getData(31), "Places", "");
        Place defaultPlace = starLoginManager.getPlace(currentOption.getDefaultPlace());
        String place = defaultPlace.getPlaceName();//.getData(0);
        String latitude = defaultPlace.getPlaceLatitude();//.getData(1);
        String longitude = defaultPlace.getPlaceLongitude();//.getData(2);
        String surname = Planets.getPlanetName(Planets.Gaia) + " - " + localDate;
        String otherNames = "";
        String entityType = "";
        String comments = "";
        String sign = "";
        String ascendant = "";
        String tz = String.valueOf(utT - t);
        picture = null;
        String eventName = bundle.getString("CurrentChart");

        event.setSurname(surname);
        event.setOtherNames(otherNames);
        event.setEntityType(entityType);
        event.setEventName(eventName);
        event.setLocalDate(localDate);
        event.setLocalTime(localTime);
        event.setUtDate(utDate);
        event.setUtTime(utTime);
        event.setTimeLag(tz);
        event.setPlace(place);
        event.setLatitude(latitude);
        event.setLongitude(longitude);
        event.setComments(comments);
        event.setSign(sign);
        event.setAscendant(ascendant);
        event.setPicture(picture);

        //calculate the time lag
        //dt = new DateTimeEvent(event);
        //dt.localTimeCalculation(TZRules.FirstTime);
        //localDate = dt.getDateTimeEvent().getLocalDate();//.getData(5);
        //localTime = dt.getDateTimeEvent().getLocalTime();//.getData(7);
        //tz = dt.getTimeLag();

        nbOfRows += 1;
        eventRow += 1;

        //setTextToData();
        event.setAdding(true);
        starLoginManager.setEvent(event);
        eventID = event.getId();//starLoginManager.getStringFieldValue("events", "MAX(ID)", " WHERE ID>0" + filter);
        refreshRecord();
        showEvent(eventID);
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnCurrentDayTimeEventActionPerformed

    private void btnHelpActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnHelpActionPerformed
    {//GEN-HEADEREND:event_btnHelpActionPerformed
        StarLogin.Systeme.Enum.OS.runExplorer("starlogin/".concat(MainClass.langue).concat("/presentation.html"));
    }//GEN-LAST:event_btnHelpActionPerformed

    private void btnLookForActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookForActionPerformed
    {//GEN-HEADEREND:event_btnLookForActionPerformed
        Object ofield = cmLookFor.getElementAt(cboLookFor.getSelectedIndex());
        if (ofield == null)
        {
            return;
        }
        if (txtLookFor.getText().equals(""))
        {
            return;
        }
        String sText = txtLookFor.getText().replace("'", "''").toUpperCase();
        String sfield = String.valueOf(ofield);
        sfield = "UCASE(".concat(sfield).concat(")");
        String search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
        String search2 = sfield.concat(" Like '").concat(sText).concat("%'");
        String search3 = sfield.concat(" Like '%").concat(sText).concat("'");
        String search4 = sfield.concat(" ='").concat(sText).concat("'");
        String id = starLoginManager.getStringFieldValue("events", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID>" + eventID + filter));
        if (id.equals("-1"))
        {
            id = starLoginManager.getStringFieldValue("events", "ID", " WHERE (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") AND ID<" + eventID + filter));
        }
        showEvent(id);
        int row = events.getRowFromID(id);
        dgrEvents.setSelectedRow(row);
    }//GEN-LAST:event_btnLookForActionPerformed

    private void btnLookFor1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLookFor1ActionPerformed
    {//GEN-HEADEREND:event_btnLookFor1ActionPerformed
        DialogQueryTool gf = new DialogQueryTool(3, this, true);
    }//GEN-LAST:event_btnLookFor1ActionPerformed

    private void btnSelectFieldsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSelectFieldsActionPerformed
    {//GEN-HEADEREND:event_btnSelectFieldsActionPerformed
        DlgSelectEventFields.ShowDialog();
        refreshRecord();
        showEvent(eventID);
    }//GEN-LAST:event_btnSelectFieldsActionPerformed

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFilterActionPerformed
    {//GEN-HEADEREND:event_btnFilterActionPerformed
        bFilter = !bFilter;
        if (!bFilter)
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            filter = "";
            cboLookFor1.setSelectedIndex(-1);
            cboLookFor2.setSelectedIndex(-1);
            cboLookFor3.setSelectedIndex(-1);
            txtLookFor1.setText("");
            txtLookFor2.setText("");
            txtLookFor3.setText("");
            refreshRecord();
            //setDataToText();
            //pnlFiltre.paintAll(pnlFiltre.getGraphics());
            pnlFiltre.paintImmediately(pnlFiltre.getBounds());
        }
        else
        {
            btnFilter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
            Object ofield1 = cmLookFor.getElementAt(cboLookFor1.getSelectedIndex());
            Object ofield2 = cmLookFor.getElementAt(cboLookFor2.getSelectedIndex());
            Object ofield3 = cmLookFor.getElementAt(cboLookFor3.getSelectedIndex());
            if (ofield1 == null && ofield2 == null && ofield3 == null)
            {
                filter = "";
                refreshRecord();
                //pnlFiltre.paintAll(pnlFiltre.getGraphics());
                pnlFiltre.paintImmediately(pnlFiltre.getBounds());
                return;
            }
            if (txtLookFor1.getText().equals("") && txtLookFor2.getText().equals("") && txtLookFor3.getText().equals(""))
            {
                filter = "";
                refreshRecord();
                //pnlFiltre.paintAll(pnlFiltre.getGraphics());
                pnlFiltre.paintImmediately(pnlFiltre.getBounds());
                return;
            }
            String sText;
            String sfield;
            String search1;
            String search2;
            String search3;
            String search4;
            String filter1 = "";
            String filter2 = "";
            String filter3 = "";
            if (ofield1 != null && !txtLookFor1.getText().equals(""))
            {
                sText = txtLookFor1.getText().replace("'", "''").toUpperCase();
                sfield = String.valueOf(ofield1);
                sfield = "UCASE(".concat(sfield).concat(")");
                search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
                search2 = sfield.concat(" Like '").concat(sText).concat("%'");
                search3 = sfield.concat(" Like '%").concat(sText).concat("'");
                search4 = sfield.concat(" ='").concat(sText).concat("'");
                filter1 = " AND (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") ");
            }
            if (ofield2 != null && !txtLookFor2.getText().equals(""))
            {
                sText = txtLookFor2.getText().replace("'", "''").toUpperCase();
                sfield = String.valueOf(ofield2);
                sfield = "UCASE(".concat(sfield).concat(")");
                search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
                search2 = sfield.concat(" Like '").concat(sText).concat("%'");
                search3 = sfield.concat(" Like '%").concat(sText).concat("'");
                search4 = sfield.concat(" ='").concat(sText).concat("'");
                filter2 = " AND (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") ");
                //if (sfield.equals("NOMPRODUIT"));
            }
            if (ofield3 != null && !txtLookFor3.getText().equals(""))
            {
                sText = txtLookFor3.getText().replace("'", "''").toUpperCase();
                sfield = String.valueOf(ofield3);
                sfield = "UCASE(".concat(sfield).concat(")");
                search1 = sfield.concat(" Like '%").concat(sText).concat("%'");
                search2 = sfield.concat(" Like '").concat(sText).concat("%'");
                search3 = sfield.concat(" Like '%").concat(sText).concat("'");
                search4 = sfield.concat(" ='").concat(sText).concat("'");
                filter3 = " AND (".concat(search1).concat(" OR ").concat(search2).concat(" OR ").concat(search3).concat(" OR ").concat(search4).concat(") ");
                //if (sfield.equals("NOMPRODUIT"));
            }
            filter = filter1.concat(filter2).concat(filter3);
            refreshRecord();
            //pnlFiltre.paintAll(pnlFiltre.getGraphics());
            pnlFiltre.paintImmediately(pnlFiltre.getBounds());
        }
        showEvent(eventID);
    }//GEN-LAST:event_btnFilterActionPerformed

    private void mnuDeleteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_mnuDeleteActionPerformed
    {//GEN-HEADEREND:event_mnuDeleteActionPerformed
        removeRec();
    }//GEN-LAST:event_mnuDeleteActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        Window windows[] = java.awt.Frame.getWindows();
        for (int i = 0; i < windows.length; i++)
        {
            if (windows[i] instanceof MainForm)
            {
                ((MainForm)windows[i]).resetEvent(event);
                break;
            }
        }
        Rectangle rct = this.getBounds();
        int state = 0;
        starLoginManager.updateDataBase("update fenetre set GAUCHE=" + rct.x + ",HAUT=" + rct.y + ",LARGEUR=" + rct.width + ",HAUTEUR=" + rct.height + ",ETAT=" + state + " WHERE NOM='" + classname + "'");
        setVisible(false);
        dispose();
    }//GEN-LAST:event_formWindowClosing

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCurrentDayTimeEvent;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnHelp;
    private javax.swing.JButton btnLookFor;
    private javax.swing.JButton btnLookFor1;
    private javax.swing.JButton btnModify;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSelectFields;
    private javax.swing.JComboBox cboLookFor;
    private javax.swing.JComboBox cboLookFor1;
    private javax.swing.JComboBox cboLookFor2;
    private javax.swing.JComboBox cboLookFor3;
    private javax.swing.JPopupMenu jPMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JMenuItem mnuDelete;
    private javax.swing.JPanel pnlControlBar;
    private javax.swing.JPanel pnlFilter1;
    private javax.swing.JPanel pnlFilter2;
    private javax.swing.JPanel pnlFilter3;
    private javax.swing.JPanel pnlFiltre;
    private javax.swing.JPanel pnlLookFor;
    private javax.swing.JPanel pnlPicture;
    private javax.swing.JPanel pnlTable;
    private javax.swing.JTextField txtLookFor;
    private javax.swing.JTextField txtLookFor1;
    private javax.swing.JTextField txtLookFor2;
    private javax.swing.JTextField txtLookFor3;
    // End of variables declaration//GEN-END:variables
}
