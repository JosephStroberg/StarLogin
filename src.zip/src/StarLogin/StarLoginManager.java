package StarLogin;

import StarLogin.IHM.MainClass;
import StarLogin.Persistence.*;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.OS;
import java.util.ArrayList;

/**
 *
 * @Christophe & Fran�ois DESCHAMPS
 * @version 8.0.0
 */
public class StarLoginManager
{
    private DataBaseRecords tableRecords;
    private DataBaseConnection dataBaseConnection;
    private DataBaseEvent dataBaseEvent;
    private DataBaseEvents dataBaseEvents;
    private DataBaseOption dataBaseOption;
    private DataBaseOptions dataBaseOptions;
    private DataBaseChart dataBaseChart;
    private DataBaseCharts dataBaseCharts;
    private DataBaseChartPositions dataBaseChartPositions;
    private DataBaseQuery dataBaseQuery;
    private DataBasePlace dataBasePlace;
    private DataBasePlaces dataBasePlaces;
    private DataBaseConstellationBoundaries dataBaseConstellationBoundaries;
    private DataBaseConstellBound dataBaseConstellBound;
    private DataBaseShowConstel dataBaseShowConstel;
    private DataBaseAsteroid dataBaseAsteroid;
    private DataBaseAsteroids dataBaseAsteroids;
    private DataBaseComet dataBaseComet;
    private DataBaseComets dataBaseComets;
    private DataBaseConfigurationsMeaning dataBaseConfigurationsMeaning;
    private DataBaseConfigurationsMeanings dataBaseConfigurationsMeanings;
    private DataBaseConsultation dataBaseConsultation;
    private DataBaseConsultations dataBaseConsultations;
    private DataBaseService dataBaseService;
    private DataBaseServices dataBaseServices;
    private DataBaseStar dataBaseStar;
    private DataBaseStars dataBaseStars;
    private DataBaseConstellations dataBaseConstellations;
    private DataBaseHouseInSign dataBaseHouseInSign;
    private DataBasePlanetInSign dataBasePlanetInSign;
    private DataBaseObjectsMeaning dataBaseObjectsMeaning;
    private DataBaseRelationships dataBaseRelationships;
    private DataBasePlanetInHouse dataBasePlanetInHouse;
    private DataBasePlanetInZodConstel dataBasePlanetInZodConstel;
    private DataBasePart dataBasePart;
    private DataBaseParts dataBaseParts;
    private DataBasePosition dataBasePosition;
    private DataBaseRecord tableRecord;
    private DataBaseQueries dataBaseQueries;
    private DataBaseVarious dataBaseVarious;
    private DataBaseGroup dataBaseGroup;
    
    /** Creates new StarLoginManager */
    public StarLoginManager()
    {
        String sUrl = "jdbc:derby:starlog8".concat(MainClass.langue);
        String sDriver = "org.apache.derby.jdbc.EmbeddedDriver";
        String sUser = "admin";
        String sPassword = "heraclion5";
        dataBaseConnection = new DataBaseConnection(sUrl, sDriver, sUser, sPassword);
        if (dataBaseConnection == null)
        {
            if (OS.getOS() == OS.apple)
            {
                sUrl = "jdbc:derby:/Applications/starlogin8/starlog8".concat(MainClass.langue);
                dataBaseConnection = new DataBaseConnection(sUrl, sDriver, sUser, sPassword);
                if (dataBaseConnection == null)
                {
                    MainClass.setMessage(MainClass.bundle.getString("msg_notConnected"));
                    System.exit(0);
                }
            }
            else
            {
                MainClass.setMessage(MainClass.bundle.getString("msg_notConnected"));
                System.exit(0);
            }
        }
        MainClass.writelog(dataBaseConnection.toString());
        //dataBaseConnection = new DataBaseConnection(sUrl, "sun.jdbc.odbc.JdbcOdbcDriver", "admin", "");
        
        tableRecords = new DataBaseRecords(dataBaseConnection);
        //JOptionPane.showMessageDialog(null, "tableRecords = " + tableRecords, "StarLogin 8", JOptionPane.INFORMATION_MESSAGE);
        dataBaseEvent = new DataBaseEvent(dataBaseConnection);
        dataBaseEvents = new DataBaseEvents(dataBaseConnection);
        dataBaseOption = new DataBaseOption(dataBaseConnection);
        dataBaseOptions = new DataBaseOptions(dataBaseConnection);
        dataBaseChart = new DataBaseChart(dataBaseConnection);
        dataBaseCharts = new DataBaseCharts(dataBaseConnection);
        dataBaseQuery = new DataBaseQuery(dataBaseConnection);
        dataBasePlace = new DataBasePlace(dataBaseConnection);
        dataBasePlaces = new DataBasePlaces(dataBaseConnection);
        dataBaseChartPositions = new DataBaseChartPositions(dataBaseConnection);
        dataBaseConstellationBoundaries = new DataBaseConstellationBoundaries(dataBaseConnection);
        dataBaseConstellBound = new DataBaseConstellBound(dataBaseConnection);
        dataBaseShowConstel = new DataBaseShowConstel(dataBaseConnection);
        dataBaseAsteroid = new DataBaseAsteroid(dataBaseConnection);
        dataBaseAsteroids = new DataBaseAsteroids(dataBaseConnection);
        dataBaseComet = new DataBaseComet(dataBaseConnection);
        dataBaseComets = new DataBaseComets(dataBaseConnection);
        dataBaseConfigurationsMeaning = new DataBaseConfigurationsMeaning(dataBaseConnection);
        dataBaseConfigurationsMeanings = new DataBaseConfigurationsMeanings(dataBaseConnection);
        dataBaseConsultation = new DataBaseConsultation(dataBaseConnection);
        dataBaseConsultations = new DataBaseConsultations(dataBaseConnection);
        dataBaseService = new DataBaseService(dataBaseConnection);
        dataBaseServices = new DataBaseServices(dataBaseConnection);
        dataBaseStar = new DataBaseStar(dataBaseConnection);
        dataBaseStars = new DataBaseStars(dataBaseConnection);
        dataBaseConstellations = new DataBaseConstellations(dataBaseConnection);
        dataBaseHouseInSign = new DataBaseHouseInSign(dataBaseConnection);
        dataBasePlanetInSign = new DataBasePlanetInSign(dataBaseConnection);
        dataBaseObjectsMeaning = new DataBaseObjectsMeaning(dataBaseConnection);
        dataBaseRelationships = new DataBaseRelationships(dataBaseConnection);
        dataBasePlanetInHouse = new DataBasePlanetInHouse(dataBaseConnection);
        dataBasePlanetInZodConstel = new DataBasePlanetInZodConstel(dataBaseConnection);
        dataBasePart = new DataBasePart(dataBaseConnection);
        dataBaseParts = new DataBaseParts(dataBaseConnection);
        dataBasePosition = new DataBasePosition(dataBaseConnection);
        dataBaseVarious = new DataBaseVarious(dataBaseConnection);
        dataBaseGroup = new DataBaseGroup(dataBaseConnection);
        //JOptionPane.showMessageDialog(null, "dataBase tables init", "StarLogin 8", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public DataBaseConnection getConnection()
    {
        return dataBaseConnection;
    }

    /*public boolean stopServer()
    {
        return dataBaseConnection.stopServer();
    }*/
    
    public boolean getReadOnly()
    {
        return false;
    }
    
    public StarLogin.Systeme.Data.Event getEvent(String eventID, String filter)
    {
        return dataBaseEvent.getEvent(eventID, filter);
    }
    
    public StarLogin.Systeme.Data.Event getEvent(String eventID)
    {
        return dataBaseEvent.getEvent(eventID, null);
    }
    
    public StarLogin.Systeme.Data.Event getEventFromNames(String surname, String otherNames, String eventType)
    {
        return dataBaseEvent.getEventFromNames(surname, otherNames, eventType);
    }
    
    public String getStringFieldValue(String table, String fieldName, String sWhere)
    {
        return tableRecords.getStringFieldValue(table, fieldName, sWhere);
    }
    
    public Events getEvents(String sql)
    {
        return dataBaseEvents.getEvents(sql);
    }
    
    public void setEvent(StarLogin.Systeme.Data.Event event)
    {
        dataBaseEvent.setEvent(event);
    }

    /*public void updateClientAddPhone()
    {
        dataBaseClient.updateClientAddPhone();
    }*/
    
    public void removeEvent(StarLogin.Systeme.Data.Event event)
    {
        dataBaseEvent.removeRecord(event);
    }
    
    public void removeEventFromID(String eventID)
    {
        dataBaseEvents.removeEventFromID(eventID);
    }
    
    public Option getOption(String optionID)
    {
        return dataBaseOption.getOption(optionID);
    }
    
    public Option getDefaultOption()
    {
        return dataBaseOption.getDefaultOption();
    }
    
    public Options getOptions()
    {
        return dataBaseOptions.getOptions();
    }
    
    public void setOption(Option option)
    {
        dataBaseOption.setOption(option);
    }
    
    public void removeOption(Option option)
    {
        dataBaseOption.removeRecord(option);
    }
    
    public Chart getChart(String chartID)
    {
        return dataBaseChart.getChart(chartID);
    }
    
    public Charts getCharts()
    {
        return dataBaseCharts.getCharts();
    }
    
    public Charts getChartsOfEvent(String eventID)
    {
        return dataBaseCharts.getChartsOfEvent(eventID);
    }
    
    public void setChart(Chart chart)
    {
        dataBaseChart.setChart(chart);
    }
    
    public void removeChart(Chart chart)
    {
        dataBaseChart.removeRecord(chart);
    }
    
    public void removeChartFromID(String chartID)
    {
        dataBaseCharts.removeChartFromID(chartID);
    }
    
    public Query getQuery(String strQuery)
    {
        return dataBaseQuery.getQuery(strQuery);
    }
    
    public Place getPlace(String placeID)
    {
        return dataBasePlace.getPlace(placeID);
    }
    
    public Places getPlaces()
    {
        return dataBasePlaces.getPlaces();
    }
    
    public void setPlace(Place place)
    {
        dataBasePlace.setPlace(place);
    }
    
    public void removePlace(Place place)
    {
        dataBasePlace.removeRecord(place);
    }
    
    public ChartPositions getChartPositions(String chartID)
    {
        return dataBaseChartPositions.getChartPositions(chartID);
    }
    
    public ConstellationBoundaries getConstellationBoundaries()
    {
        return dataBaseConstellationBoundaries.getConstellationBoundaries();
    }
    
    public ConstellBound getConstellBound()
    {
        return dataBaseConstellBound.getConstellBound();
    }
    
    public ShowConstel getShowConstel()
    {
        return dataBaseShowConstel.getShowConstel();
    }
    
    public Part getPart(String partID)
    {
        return dataBasePart.getPart(partID);
    }
    
    public Part getPartFrom(String ref, String plus, String minus)
    {
        return dataBasePart.getPartFrom(ref, plus, minus);
    }
    
    public Part getPartFromName(String partName)
    {
        return dataBasePart.getPartFromName(partName);
    }
    
    public Parts getParts()
    {
        return dataBaseParts.getParts();
    }
    
    public void setPart(Part part)
    {
        dataBasePart.setPart(part);
    }
    
    public void removePart(Part part)
    {
        dataBasePart.removeRecord(part);
    }
    
    public Asteroids getAsteroids()
    {
        return dataBaseAsteroids.getAsteroids();
    }
    
    public Asteroid getAsteroid(String asteroidID, String filter)
    {
        return dataBaseAsteroid.getAsteroid(asteroidID, filter);
    }
    
    public void setAsteroid(Asteroid asteroid)
    {
        dataBaseAsteroid.setAsteroid(asteroid);
    }
    
    public void removeAsteroid(Asteroid asteroid)
    {
        dataBaseAsteroid.removeRecord(asteroid);
    }
    
    public Comets getComets()
    {
        return dataBaseComets.getComets();
    }
    
    public Comet getComet(String cometID, String filter)
    {
        return dataBaseComet.getComet(cometID, filter);
    }
    
    public void setComet(Comet comet)
    {
        dataBaseComet.setComet(comet);
    }
    
    public void removeComet(Comet comet)
    {
        dataBaseComet.removeRecord(comet);
    }
    
    public ConfigurationsMeanings getConfigurationsMeanings()
    {
        return dataBaseConfigurationsMeanings.getConfigurationsMeanings();
    }
    
    public ConfigurationsMeaning getConfigurationsMeaning(String configurationsMeaningID)
    {
        return dataBaseConfigurationsMeaning.getConfigurationsMeaning(configurationsMeaningID);
    }
    
    public void setConfigurationsMeaning(ConfigurationsMeaning configurationsMeaning)
    {
        dataBaseConfigurationsMeaning.setConfigurationsMeaning(configurationsMeaning);
    }
    
    public void removeConfigurationsMeaning(ConfigurationsMeaning configurationsMeaning)
    {
        dataBaseConfigurationsMeaning.removeRecord(configurationsMeaning);
    }
    
    public Consultations getConsultations()
    {
        return dataBaseConsultations.getConsultations();
    }
    
    public Consultation getConsultation(String consultationID)
    {
        return dataBaseConsultation.getConsultation(consultationID);
    }
    
    public void setConsultation(Consultation consultation)
    {
        dataBaseConsultation.setConsultation(consultation);
    }
    
    public void removeConsultation(Consultation consultation)
    {
        dataBaseConsultation.removeRecord(consultation);
    }
    
    public Services getServices()
    {
        return dataBaseServices.getServices();
    }
    
    public Service getService(String serviceID)
    {
        return dataBaseService.getService(serviceID);
    }
    
    public void setService(Service service)
    {
        dataBaseService.setService(service);
    }
    
    public void removeService(Service service)
    {
        dataBaseService.removeRecord(service);
    }
    
    public Stars getStars()
    {
        return dataBaseStars.getStars();
    }
    
    public Star getStar(String starID, String filter)
    {
        return dataBaseStar.getStar(starID, filter);
    }
    
    public void setStar(Star star)
    {
        dataBaseStar.setStar(star);
    }
    
    public void removeStar(Star star)
    {
        dataBaseStar.removeRecord(star);
    }
    
    public Constellations getConstellations()
    {
        return dataBaseConstellations.getConstellations();
    }
    
    public HouseInSign getHouseInSign(byte houseID, byte signID)
    {
        return dataBaseHouseInSign.getHouseInSign(houseID, signID);
    }
    
    public PlanetInSign getPlanetInSign(byte planetID, byte signID)
    {
        return dataBasePlanetInSign.getPlanetInSign(planetID, signID);
    }
    
    public ObjectsMeaning getObjectsMeaning(byte objectID, byte typeID)
    {
        return dataBaseObjectsMeaning.getObjectsMeaning(objectID, typeID);
    }
    
    public Relationships getRelationships(byte planet1ID, byte planet2ID)
    {
        return dataBaseRelationships.getRelationships(planet1ID, planet2ID);
    }
    
    public PlanetInHouse getPlanetInHouse(byte planetID, byte houseID)
    {
        return dataBasePlanetInHouse.getPlanetInHouse(planetID, houseID);
    }
    
    public PlanetInZodConstel getPlanetInZodConstel(byte planetID, byte zodConstelID)
    {
        return dataBasePlanetInZodConstel.getPlanetInZodConstel(planetID, zodConstelID);
    }
    
    public StarLogin.Systeme.Data.Position getPosition(String objectID, String chartID, String chartNB)
    {
        return dataBasePosition.getPosition(objectID, chartID, chartNB);
    }
    
    public void setPosition(StarLogin.Systeme.Data.Position position)
    {
        dataBasePosition.setPosition(position);
    }
    
    public void removePosition(StarLogin.Systeme.Data.Position position)
    {
        dataBasePosition.removePosition(position);
    }

    /*public String getInsertQuery(String requete)
    {
        return tableRecord.getInsertQuery(requete);
    }*/

    public String lookForField(String partialName, String fieldName, String table, String oldName, String sFilter, String sOrder)
    {
        return tableRecords.lookForField(partialName, fieldName, table, oldName, sFilter, sOrder);
    }

    public boolean checkRecord(String table, String sWhere)
    {
        return tableRecords.checkRecord(table, sWhere);
    }

    public String getMainFieldID_S(String table, String fieldName, String fieldValue)
    {
        return tableRecords.getMainFieldID_S(table, fieldName,fieldValue );
    }

    public String getMainFieldID_N(String table, String fieldName, String fieldValue)
    {
        return tableRecords.getMainFieldID_N(table, fieldName,fieldValue );
    }

    /*public ArrayList getQueries()
    {
        return dataBaseQueries.getQueries();
    }
    
    public boolean isTable(String table)
    {
        return tableRecords.isTable(table);
    }*/

    public String buildQuery(ArrayList fields, ArrayList headers, String from, String where, String group, String order, String having)
    {
        return dataBaseQueries.buildQuery(fields, headers, from, where, group, order, having);
    }

    public javax.swing.DefaultComboBoxModel getListe(String query)
    {
        return tableRecords.getListe(query);
    }

    public javax.swing.DefaultListModel getListe2(String query)
    {
        return tableRecords.getListe2(query);
    }

    public Records getRecords(String sql, String tableName)
    {
        return tableRecords.getRecords(sql, tableName);
    }

    public ArrayList getShortRecords(String sql, String tableName)
    {
        return tableRecords.getShortRecords(sql, tableName);
    }

    public DataBaseRecord getDBRecord()
    {
        return tableRecord;
    }

    public Record getRecord(String sql, String tableName, String strPartialWhere)
    {
        tableRecord = new DataBaseRecord(dataBaseConnection);
        return tableRecord.getRecord(sql, tableName, strPartialWhere);
    }

    public void setRecord(Record table, DataBaseRecord tableRecord)
    {
        tableRecord.setRecord(table);
        this.tableRecord = tableRecord;
    }

    public void setRecord(Record table)
    {
        tableRecord.setRecord(table);
    }

    public int getIntFieldValue(String table, String fieldName, String sWhere)
    {
        return tableRecords.getIntFieldValue(table, fieldName, sWhere);
    }

    public String getMonetaryFieldValue(String table, String fieldName, String sWhere)
    {
        return tableRecords.getMonetaryFieldValue(table, fieldName, sWhere);
    }

    public void removeRecord(String iD, String tableName)
    {
        tableRecords.removeFromID(iD, tableName);
    }

    public boolean updateDataBase(String query)
    {
        return dataBaseVarious.updateDataBase(query);
    }

    public Groups getGroups()
    {
        return dataBaseGroup.GetGroups();
    }

    public boolean removeGroup(Groups groups, String groupID)
    {
        return dataBaseGroup.removeGroup(groups, groupID);
    }

    public boolean recoverGroupsLostParents()
    {
        return dataBaseGroup.recoverGroupsLostParents();
    }

    public boolean changeGroupName(String oldName, String newName)
    {
        return dataBaseGroup.changeGroupName(oldName, newName);
    }

    public boolean changeGroups(Groups groups, String strSource, String strDestination)
    {
        return dataBaseGroup.changeGroups(groups, strSource, strDestination);
    }

    public boolean addGroup(Groups groups, String strSource, String strNewGroup, String strNewDescript)
    {
        return dataBaseGroup.addGroup(groups, strSource, strNewGroup, strNewDescript);
    }

    public boolean getClientsInGroup(String strGroup)
    {
        return dataBaseGroup.getClientsInGroup(strGroup);
    }
    
}
