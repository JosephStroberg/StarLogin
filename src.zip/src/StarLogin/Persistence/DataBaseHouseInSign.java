package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.HouseInSign;
import java.util.ArrayList;
import java.sql.*;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseHouseInSign extends DataBaseRecord  {

    DataBaseConnection dataBase;
    
    /** Creates new DataBaseHouseInSign */
    public DataBaseHouseInSign(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "HouseInSign";
    }

    public HouseInSign getHouseInSign(byte houseID, byte signID)
    {
        HouseInSign houseInSign = new HouseInSign();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM HouseInSign WHERE ID=" + houseID + " AND S_I=" + signID);
            while (rs.next())
            {
                houseInSign.setMeaning(rs.getString(1));
                houseInSign.setValue(rs.getDouble(2));
            }
            houseInSign.setHouseID(houseID);
            houseInSign.setSignID(signID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return houseInSign;
        
    }
}
