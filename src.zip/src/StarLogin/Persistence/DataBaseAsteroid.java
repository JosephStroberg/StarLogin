package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Asteroid;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseAsteroid extends DataBaseRecord
{
    private String id;
    private String filter;
    
    /** Creates new DataBaseAsteroid */
    public DataBaseAsteroid(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "asteroids";
    }
    
    public DataBaseAsteroid()
    {
        setConnection(dataBase);
    }

    public Asteroid getAsteroid(String asteroidID, String filter)
    {
        Asteroid asteroid = new Asteroid();
        asteroid.setId(asteroidID);
        if (filter == null)
            filter = "";
        this.filter = filter;
        this.id = asteroidID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Asteroid, Numero, HMagnitude, MeanAnomaly, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, DailyMotion, Epoch, Comments, Picture FROM Asteroids WHERE ID=" + asteroidID);
            while (rs.next())
            {
                asteroid.setAsteroidName(rs.getString(1));
                asteroid.setAsteroidNumber(rs.getInt(2));
                asteroid.setHMagnitude(rs.getDouble(3));
                asteroid.setMeanAnomaly(rs.getDouble(4));
                asteroid.setEccentricity(rs.getDouble(5));
                asteroid.setPerihelionLongitude(rs.getDouble(6));
                asteroid.setNorthNodeLongitude(rs.getDouble(7));
                asteroid.setInclination(rs.getDouble(8));
                asteroid.setSemiMajorAxis(rs.getDouble(9));
                asteroid.setDailyMotion(rs.getDouble(10));
                asteroid.setEpoch(rs.getDouble(11));
                asteroid.setComments(rs.getString(12));
                Blob blob = rs.getBlob(13);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                asteroid.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        asteroid.setRow(findRow(asteroidID));
        asteroid.setRowNB(findRowNB());
        return asteroid;
        
    }
    
    public void setAsteroid(Asteroid asteroid)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sAsteroidName = asteroid.getAsteroidName();
            int asteroidNumber = asteroid.getAsteroidNumber();
            double hMagnitude = asteroid.getHMagnitude();
            double meanAnomaly = asteroid.getMeanAnomaly();
            double eccentricity = asteroid.getEccentricity();
            double perihelionLongitude = asteroid.getPerihelionLongitude();
            double northNodeLongitude = asteroid.getNorthNodeLongitude();
            double inclination = asteroid.getInclination();
            double semiMajorAxis = asteroid.getSemiMajorAxis();
            double dailyMotion = asteroid.getDailyMotion();
            double epoch = asteroid.getEpoch();
            String sComments = SQLString.processNull(asteroid.getComments());
            //String imgIcon = SQLString.processNull(asteroid.getPicture());
            ImageIcon imgIcon = asteroid.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(imgIcon);
            if (asteroid.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }
            if (asteroid.getAdding()==true)
            {
                query = "INSERT INTO Asteroids (Asteroid, Numero, HMagnitude, MeanAnomaly, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, DailyMotion, Epoch, Comments) VALUES ("
                + "'" + MainClass.replaceQuotes(sAsteroidName) + "', " + asteroidNumber + ", " + hMagnitude + ", " + meanAnomaly + ", " + eccentricity + ", " + perihelionLongitude + ", " + northNodeLongitude + ", " + inclination + ", " + semiMajorAxis + ", " + dailyMotion + ", " + epoch + ", '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                asteroid.setId(newID);

                id = newID;
                int row = findRow(newID);
                asteroid.setRow(row);
                asteroid.setRowNB(asteroid.getRowNB() + 1);
                asteroid.setAdding(false);
            }
            else
            {
                query = "UPDATE Asteroids SET Asteroid='" + MainClass.replaceQuotes(sAsteroidName)+ "'"
                + ", Numero=" + asteroidNumber
                + ", HMagnitude=" + hMagnitude
                + ", MeanAnomaly=" + meanAnomaly
                + ", Eccentricity=" + eccentricity
                + ", PerihelionLongitude=" + perihelionLongitude
                + ", NorthNodeLongitude=" + northNodeLongitude
                + ", Inclination=" + inclination
                + ", SemiMajorAxis=" + semiMajorAxis
                + ", DailyMotion=" + dailyMotion
                + ", Epoch=" + epoch
                + ", Comments='" + MainClass.replaceQuotes(sComments)+ "' WHERE ID=" + asteroid.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (imgIcon == null)
                {
                    statement.executeUpdate("UPDATE Asteroids SET picture=null where id=" + asteroid.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM asteroids where id=" + asteroid.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Asteroid asteroid)
    {
        rRecord("asteroids", id);
        asteroid.setRowNB(asteroid.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("asteroids");
    }

    private int findRow(String id)
    {
        return fRow("asteroids", id, " ORDER BY Asteroid", "asteroids", " WHERE ID>0 " + filter);
    }

    private int findRowNB()
    {
        return fRowNB("asteroids", "asteroids", " WHERE ID>0 " + filter);
    }
}
