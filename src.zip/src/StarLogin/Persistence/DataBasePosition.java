package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Position;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePosition extends DataBaseRecord
{
    
    /** Creates new DataBaseStar */
    public DataBasePosition(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "Positions";
    }
    
    public Position getPosition(String objectID, String chartID, String chartNB)
    {
        Position position = new Position();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ObjName, HelioLatitude, HelioLongitude, HelioLongitudeSider, HelioDistance, GeoLatitude, GeoLongitude, GeoLongitudeSider, GeoDistance, RightAscension, Declination, Azimuth, Altitude, AngleWithSun, AngleWithMoon, AngleWithMercury, AngleWithVenus, AngleWithMars, AngleWithJupiter, AngleWithSaturn, AngleWithUranus, AngleWithNeptune, AngleWithPluto, AngleWithEarth, AngleWithNorthNode, AngleWithLilith, AngleWithEast, AngleWithZenith, AngleWithVertex, AngleWithVulcan, AngleWithOtherPoint, AngleWithCeres, AngleWithPallas, AngleWithJuno, AngleWithVesta, AngleWithChiron, AngleWithAscendant, AngleWithMidheaven, Sign, ZodConstel, Constellation, House, Decan, Direction, Element, Angle, Dignity FROM Positions WHERE ObjectID=" + objectID + " AND ChartID=" + chartID + " AND ChartNB=" + chartNB);
            while (rs.next())
            {
                position.setObjName(rs.getString(1));
                position.setHelioLatitude(rs.getDouble(2));
                position.setHelioLongitude(rs.getDouble(3));
                position.setHelioLongitudeSider(rs.getDouble(4));
                position.setHelioDistance(rs.getDouble(5));
                position.setGeoLatitude(rs.getDouble(6));
                position.setGeoLongitude(rs.getDouble(7));
                position.setGeoLongitudeSider(rs.getDouble(8));
                position.setGeoDistance(rs.getDouble(9));
                position.setRightAscension(rs.getDouble(10));
                position.setDeclination(rs.getDouble(11));
                position.setAzimuth(rs.getDouble(12));
                position.setAltitude(rs.getDouble(13));
                position.setAngleWithSun(rs.getDouble(14));
                position.setAngleWithMoon(rs.getDouble(15));
                position.setAngleWithMercury(rs.getDouble(16));
                position.setAngleWithVenus(rs.getDouble(17));
                position.setAngleWithMars(rs.getDouble(18));
                position.setAngleWithJupiter(rs.getDouble(19));
                position.setAngleWithSaturn(rs.getDouble(20));
                position.setAngleWithUranus(rs.getDouble(21));
                position.setAngleWithNeptune(rs.getDouble(22));
                position.setAngleWithPluto(rs.getDouble(23));
                position.setAngleWithEarth(rs.getDouble(24));
                position.setAngleWithNorthNode(rs.getDouble(25));
                position.setAngleWithLilith(rs.getDouble(26));
                position.setAngleWithEast(rs.getDouble(27));
                position.setAngleWithZenith(rs.getDouble(28));
                position.setAngleWithVertex(rs.getDouble(29));
                position.setAngleWithVulcan(rs.getDouble(30));
                position.setAngleWithOtherPoint(rs.getDouble(31));
                position.setAngleWithCeres(rs.getDouble(32));
                position.setAngleWithPallas(rs.getDouble(33));
                position.setAngleWithJuno(rs.getDouble(34));
                position.setAngleWithVesta(rs.getDouble(35));
                position.setAngleWithChiron(rs.getDouble(36));
                position.setAngleWithAscendant(rs.getDouble(37));
                position.setAngleWithMidheaven(rs.getDouble(38));
                position.setSign(rs.getString(39));
                position.setZodConstel(rs.getString(40));
                position.setConstellation(rs.getString(41));
                position.setHouse(rs.getString(42));
                position.setDecan(rs.getByte(43));
                position.setDirection(rs.getString(44));
                position.setElement(rs.getString(45));
                position.setAngle(rs.getString(46));
                position.setDignity(rs.getString(47));
            }
            position.setObjectID(objectID);
            position.setChartID(chartID);
            position.setChartNB(chartNB);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return position;
        
    }
    
    public void setPosition(Position position)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String objName = SQLString.processNull(position.getObjName());
            double helioLatitude = position.getHelioLatitude();
            double helioLongitude = position.getHelioLongitude();
            double helioLongitudeSider = position.getHelioLongitudeSider();
            double helioDistance = position.getHelioDistance();
            double geoLatitude = position.getGeoLatitude();
            double geoLongitude = position.getGeoLongitude();
            double geoLongitudeSider = position.getGeoLongitudeSider();
            double geoDistance = position.getGeoDistance();
            double rightAscension = position.getRightAscension();
            double declination = position.getDeclination();
            double azimuth = position.getAzimuth();
            double altitude = position.getAltitude();
            double angleWithSun = position.getAngleWithSun();
            double angleWithMoon = position.getAngleWithMoon();
            double angleWithMercury = position.getAngleWithMercury();
            double angleWithVenus = position.getAngleWithVenus();
            double angleWithMars = position.getAngleWithMars();
            double angleWithJupiter = position.getAngleWithJupiter();
            double angleWithSaturn = position.getAngleWithSaturn();
            double angleWithUranus = position.getAngleWithUranus();
            double angleWithNeptune = position.getAngleWithNeptune();
            double angleWithPluto = position.getAngleWithPluto();
            double angleWithEarth = position.getAngleWithEarth();
            double angleWithNorthNode = position.getAngleWithNorthNode();
            double angleWithLilith = position.getAngleWithLilith();
            double angleWithEast = position.getAngleWithEast();
            double angleWithZenith = position.getAngleWithZenith();
            double angleWithVertex = position.getAngleWithVertex();
            double angleWithVulcan = position.getAngleWithVulcan();
            double angleWithOtherPoint = position.getAngleWithOtherPoint();
            double angleWithCeres = position.getAngleWithCeres();
            double angleWithPallas = position.getAngleWithPallas();
            double angleWithJuno = position.getAngleWithJuno();
            double angleWithVesta = position.getAngleWithVesta();
            double angleWithChiron = position.getAngleWithChiron();
            double angleWithAscendant = position.getAngleWithAscendant();
            double angleWithMidheaven = position.getAngleWithMidheaven();
            String sign = SQLString.processNull(position.getSign());
            String zodConstel = SQLString.processNull(position.getZodConstel());
            String constellation = SQLString.processNull(position.getConstellation());
            String house = SQLString.processNull(position.getHouse());
            byte decan = position.getDecan();
            String direction = SQLString.processNull(position.getDirection());
            String element = SQLString.processNull(position.getElement());
            String angle = SQLString.processNull(position.getAngle());
            String dignity = SQLString.processNull(position.getDignity());
            String objectID = position.getObjectID();
            String chartID = position.getChartID();
            String chartNB = position.getChartNB();
            
            //We never update an existing chart record. We only add new records or delete the existing ones
            query = "INSERT INTO Positions (ObjectID, ChartID, ChartNB, ObjName, HelioLatitude, HelioLongitude, HelioLongitudeSider, HelioDistance, GeoLatitude, GeoLongitude, GeoLongitudeSider, GeoDistance, RightAscension, Declination, Azimuth, Altitude, AngleWithSun, AngleWithMoon, AngleWithMercury, AngleWithVenus, AngleWithMars, AngleWithJupiter, AngleWithSaturn, AngleWithUranus, AngleWithNeptune, AngleWithPluto, AngleWithEarth, AngleWithNorthNode, AngleWithLilith, AngleWithEast, AngleWithZenith, AngleWithVertex, AngleWithVulcan, AngleWithOtherPoint, AngleWithCeres, AngleWithPallas, AngleWithJuno, AngleWithVesta, AngleWithChiron, AngleWithAscendant, AngleWithMidheaven, Sign, ZodConstel, Constellation, House, Decan, Direction, Element, Angle, Dignity) VALUES (" + objectID + ", "  + chartID + ", "  + chartNB + ", '" + MainClass.replaceQuotes(objName) + "', " + helioLatitude + ", " + helioLongitude + ", " + helioLongitudeSider + ", " + helioDistance + ", " + geoLatitude + ", " + geoLongitude + ", " + geoLongitudeSider + ", " + geoDistance + ", " + rightAscension + ", " + declination + ", " + azimuth + ", " + altitude + ", " + angleWithSun + ", " + angleWithMoon + ", " + angleWithMercury + ", " + angleWithVenus + ", " + angleWithMars + ", " + angleWithJupiter + ", " + angleWithSaturn + ", " + angleWithUranus + ", " + angleWithNeptune + ", " + angleWithPluto + ", " + angleWithEarth + ", " + angleWithNorthNode + ", " + angleWithLilith + ", " + angleWithEast + ", " + angleWithZenith + ", " + angleWithVertex + ", " + angleWithVulcan + ", " + angleWithOtherPoint + ", " + angleWithCeres + ", " + angleWithPallas + ", " + angleWithJuno + ", " + angleWithVesta + ", " + angleWithChiron + ", " + angleWithAscendant + ", " + angleWithMidheaven + ", '" + MainClass.replaceQuotes(sign) + "', '" + MainClass.replaceQuotes(zodConstel) + "', '" + MainClass.replaceQuotes(constellation) + "', '" + MainClass.replaceQuotes(house) + "', " + decan + ", '" + MainClass.replaceQuotes(direction) + "', '" + MainClass.replaceQuotes(element) + "', '" + MainClass.replaceQuotes(angle) + "', '" + MainClass.replaceQuotes(dignity) + "')";
            query = query.replace("'null'", "null");
            statement.executeUpdate(query);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    public void removePosition(Position position)
    {
        try
        {
            Statement statement = dataBase.createStatement();
            String objectID = position.getObjectID();
            String chartID = position.getChartID();
            String chartNB = position.getChartNB();
            statement.executeUpdate("DELETE FROM Positions WHERE ObjectID=" + objectID + " AND ChartID=" + chartID + " AND chartNB=" + chartNB);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
}
