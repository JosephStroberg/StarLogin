package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Parts;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseParts extends DataBaseRecords {

    /** Creates new DataBaseParts */
    public DataBaseParts(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Parts getParts()
    {
        Parts parts = new Parts();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("select ID, Part, Ref, Plus, Minus, Comments FROM Parts");
            ArrayList rows = parts.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = parts.getHeaders();
        ArrayList fields = parts.getFields();
        ArrayList fieldsVal = parts.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("Part"));
        columnNames.add(2, bundle.getString("Ref"));
        columnNames.add(3, bundle.getString("Plus"));
        columnNames.add(4, bundle.getString("Minus"));
        columnNames.add(5, bundle.getString("Comments"));
        fields.add(0, "ID");
        fields.add(1, "Part");
        fields.add(2, "Ref");
        fields.add(3, "Plus");
        fields.add(4, "Minus");
        fields.add(5, "Comments");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT Part FROM Parts WHERE Part is not null AND Part!='' ORDER BY Part"));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        
        return parts;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
