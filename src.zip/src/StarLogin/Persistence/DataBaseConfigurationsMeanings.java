package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.ConfigurationsMeanings;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConfigurationsMeanings extends DataBaseRecords {

    DataBaseConnection dataBase;
    
    /** Creates new DataBaseConfigurationsMeanings */
    public DataBaseConfigurationsMeanings(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public ConfigurationsMeanings getConfigurationsMeanings()
    {
        ConfigurationsMeanings configurationsMeanings = new ConfigurationsMeanings();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, ConfigurationName, ConfigurationNumber, ConfigurationDescription, ConfigurationMeaning, ConfigurationValue FROM ConfigurationsMeaning");
            ArrayList rows = configurationsMeanings.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = configurationsMeanings.getHeaders();
        ArrayList fields = configurationsMeanings.getFields();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("PlanetaryConfiguration"));
        columnNames.add(2, bundle.getString("PlanetsNumber"));
        columnNames.add(3, bundle.getString("ConfigurationDescription"));
        columnNames.add(4, bundle.getString("ConfigurationMeaning"));
        columnNames.add(5, bundle.getString("ConfigurationValue"));
        fields.add(0, "ID");
        fields.add(1, "ConfigurationName");
        fields.add(2, "ConfigurationNumber");
        fields.add(3, "ConfigurationDescription");
        fields.add(4, "ConfigurationMeaning");
        fields.add(5, "ConfigurationValue");
        
        return configurationsMeanings;
    }
}

