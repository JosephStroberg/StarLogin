package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.PlanetInZodConstel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePlanetInZodConstel extends DataBaseRecord  {

    /** Creates new DataBasePlanetInZodConstel */
    public DataBasePlanetInZodConstel(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "PlanetInZodConstel";
    }

    public PlanetInZodConstel getPlanetInZodConstel(byte planetID, byte zodConstelID)
    {
        PlanetInZodConstel planetInZodConstel = new PlanetInZodConstel();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM PlanetInZodConstel WHERE ID=" + planetID + " AND C_I=" + zodConstelID);
            while (rs.next())
            {
                planetInZodConstel.setMeaning(rs.getString(1));
                planetInZodConstel.setValue(rs.getDouble(2));
            }
            planetInZodConstel.setPlanetID(planetID);
            planetInZodConstel.setZodConstelID(zodConstelID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return planetInZodConstel;
        
    }
}
