/*
 * DataBaseEvents.java
 *
 * Created on 15 mai 2003, 08:54
 */

package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Events;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseEvents extends DataBaseRecords {

    /** Creates new DataBaseEvents */
    public DataBaseEvents(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Events getEvents(String sql)
    {
        Events events = new Events();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            if (sql == null)
                sql = "SELECT ID, SURNAME, OTHERNAMES, ENTITYTYPE, EVENTTYPE, UTDATE, LOCALDATE, UTTIME, LOCAL_TIME, TIMELAG, PLACENAME, PLACELATITUDE, PLACELONGITUDE, SIGN, ASCENDANT, COMMENTS, PICTURE FROM events";
            ResultSet rs = statement.executeQuery(sql);
            ArrayList rows = events.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = events.getHeaders();
        ArrayList fields = events.getFields();
        ArrayList fieldsVal = events.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("Surname"));
        columnNames.add(2, bundle.getString("OtherNames"));
        columnNames.add(3, bundle.getString("EntityType"));
        columnNames.add(4, bundle.getString("Event"));
        columnNames.add(5, "_5");
        columnNames.add(6, bundle.getString("LocalDate"));
        columnNames.add(7, "_7");
        columnNames.add(8, bundle.getString("LocalTime"));
        columnNames.add(9, bundle.getString("TimeZone"));
        columnNames.add(10, bundle.getString("Place"));
        columnNames.add(11, bundle.getString("Latitude"));
        columnNames.add(12, bundle.getString("Longitude"));
        columnNames.add(13, bundle.getString("Comments"));
        columnNames.add(14, bundle.getString("Sign"));
        columnNames.add(15, bundle.getString("Ascendant"));
        columnNames.add(16, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "Surname");
        fields.add(2, "OtherNames");
        fields.add(3, "EntityType");
        fields.add(4, "EventType");
        fields.add(5, "UTDate");
        fields.add(6, "LocalDate");
        fields.add(7, "UTTime");
        fields.add(8, "Localtime");
        fields.add(9, "TimeLag");
        fields.add(10, "PlaceName");
        fields.add(11, "PlaceLatitude");
        fields.add(12, "PlaceLongitude");
        fields.add(13, "Comments");
        fields.add(14, "Sign");
        fields.add(15, "Ascendant");
        fields.add(16, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT Distinct Surname FROM Events WHERE Surname is not null AND Surname!='' ORDER BY Surname"));
        fieldsVal.add(2, getListe("SELECT Distinct OtherNames FROM Events WHERE OtherNames is not null AND OtherNames!='' ORDER BY OtherNames"));
        fieldsVal.add(3, getListe("SELECT Distinct EntityType FROM Events WHERE EntityType is not null AND EntityType!='' ORDER BY EntityType"));
        fieldsVal.add(4, getListe("SELECT Distinct EventType FROM Events WHERE EventType is not null AND EventType!='' ORDER BY EventType"));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        fieldsVal.add(9, getListe(""));
        fieldsVal.add(10, getListe("SELECT PlaceName FROM Places WHERE PlaceName is not null AND PlaceName!='' ORDER BY PlaceName"));
        fieldsVal.add(11, getListe(""));
        fieldsVal.add(12, getListe(""));
        fieldsVal.add(13, getListe(""));
        fieldsVal.add(14, getListe(""));
        fieldsVal.add(15, getListe(""));
        fieldsVal.add(16, getListe(""));
        
        return events;
    }
    
    public void removeEventFromID(String eventID)
    {
        try
        {
            Statement statement = dataBase.createStatement();
            statement.executeUpdate("DELETE FROM Events WHERE ID=" + eventID);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
}
