package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Comets;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseComets extends DataBaseRecords {

    DataBaseConnection dataBase;
    
    /** Creates new DataBaseComets */
    public DataBaseComets(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Comets getComets()
    {
        Comets comets = new Comets();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, Comet, PerihelionDate, PerihelionUA, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, Period, Epoch, Comments, Picture FROM Comets ORDER BY Comet");
            ArrayList rows = comets.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = comets.getHeaders();
        ArrayList fields = comets.getFields();
        ArrayList fieldsVal = comets.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("Comet"));
        columnNames.add(2, bundle.getString("PerihelionDate"));
        columnNames.add(3, bundle.getString("PerihelionUA"));
        columnNames.add(4, bundle.getString("MeanAnomaly"));
        columnNames.add(5, bundle.getString("Eccentricity"));
        columnNames.add(6, bundle.getString("PerihelionLongitude"));
        columnNames.add(7, bundle.getString("NorthNodeLongitude"));
        columnNames.add(8, bundle.getString("Inclination"));
        columnNames.add(9, bundle.getString("SemiMajorAxis"));
        columnNames.add(10, bundle.getString("Period"));
        columnNames.add(11, bundle.getString("Epoch"));
        columnNames.add(12, bundle.getString("Comments"));
        columnNames.add(13, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "Comet");
        fields.add(2, "PerihelionDate");
        fields.add(3, "PerihelionUA");
        fields.add(4, "MeanAnomaly");
        fields.add(5, "Eccentricity");
        fields.add(6, "PerihelionLongitude");
        fields.add(7, "NorthNodeLongitude");
        fields.add(8, "Inclination");
        fields.add(9, "SemiMajorAxis");
        fields.add(10, "Period");
        fields.add(11, "Epoch");
        fields.add(12, "Comments");
        fields.add(13, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT Comet FROM Comets WHERE Comet is not null AND Comet!='' ORDER BY Comet"));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        fieldsVal.add(9, getListe(""));
        fieldsVal.add(10, getListe(""));
        fieldsVal.add(11, getListe(""));
        fieldsVal.add(12, getListe(""));
        fieldsVal.add(13, getListe(""));
        
        return comets;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
