package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Service;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseService extends DataBaseRecord 
{

    private String id;
    
    /** Creates new DataBaseService */
    public DataBaseService(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "Services";
    }

    public Service getService(String serviceID)
    {
        Service service = new Service();
        service.setId(serviceID);
        this.id = serviceID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ServiceName, ServiceType, AverageDuration, AstrologicalTechniques, OtherTechniques, Rate, Repetitiveness, Comments FROM Services WHERE ID=" + serviceID);
            while (rs.next())
            {
                service.setServiceName(rs.getString(1));
                service.setServiceType(rs.getString(2));
                service.setAverageDuration(rs.getString(3));
                service.setAstrologicalTechniques(rs.getString(4));
                service.setOtherTechniques(rs.getString(5));
                service.setRate(rs.getString(6));
                service.setRepetitiveness(rs.getString(7));
                service.setComments(rs.getString(8));
                /*Blob blob = rs.getBlob(9);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                service.setPicture(icon);*/
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        service.setRow(findRow(serviceID));
        service.setRowNB(findRowNB());
        return service;
        
    }
    
    public void setService(Service service)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sServiceName = SQLString.processNull(service.getServiceName());
            String sServiceType = SQLString.processNull(service.getServiceType());
            String sAverageDuration = SQLString.processNull(service.getAverageDuration());
            String sAstrologicalTechniques = SQLString.processNull(service.getAstrologicalTechniques());
            String sOtherTechniques = SQLString.processNull(service.getOtherTechniques());
            String sRate = SQLString.processNull(service.getRate());
            String sRepetitiveness = SQLString.processNull(service.getRepetitiveness());
            String sComments = SQLString.processNull(service.getComments());
            
            if (service.getAdding()==true)
            {
                query = "INSERT INTO Services (ServiceName, ServiceType, AverageDuration, AstrologicalTechniques, OtherTechniques, Rate, Repetitiveness, Comments) VALUES ('" + MainClass.replaceQuotes(sServiceName) + "', '" + MainClass.replaceQuotes(sServiceType) + "', '" + MainClass.replaceQuotes(sAverageDuration) + "', '" + MainClass.replaceQuotes(sAstrologicalTechniques) + "', '" + MainClass.replaceQuotes(sOtherTechniques) + "', '" + MainClass.replaceQuotes(sRate) + "', '" + MainClass.replaceQuotes(sRepetitiveness) + "', '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                service.setId(newID);

                id = newID;
                int row = findRow(newID);
                service.setRow(row);
                service.setRowNB(service.getRowNB() + 1);
                service.setAdding(false);
            }
            else
            {
                query = "UPDATE Services SET ServiceName='" + MainClass.replaceQuotes(sServiceName) + "', ServiceType='" + MainClass.replaceQuotes(sServiceType) + "', AverageDuration='" + MainClass.replaceQuotes(sAverageDuration) + "', AstrologicalTechniques='" + MainClass.replaceQuotes(sAstrologicalTechniques) + "', OtherTechniques='" + MainClass.replaceQuotes(sOtherTechniques) + "', Rate='" + MainClass.replaceQuotes(sRate) + "', Repetitiveness='" + MainClass.replaceQuotes(sRepetitiveness) + "', Comments='" + MainClass.replaceQuotes(sComments) + "'WHERE ID=" + service.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);
            }
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Service service)
    {
        rRecord("services", id);
        service.setRowNB(service.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("services");
    }

    private int findRow(String id)
    {
        return fRow("services", id, " ORDER BY ServiceName", "services");
    }

    private int findRowNB()
    {
        return fRowNB("services", "services");
    }
}

