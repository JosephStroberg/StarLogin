/*
 * DataBaseGroup.java
 *
 * Created on 15 mai 2003, 08:54
 */

package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Groups;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @authors  Fran�ois & Christophe DESCHAMPS
 * @version 1.0.0
 */
public class DataBaseGroup
{

    DataBaseConnection dataBase;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    /** Creates new DataBaseGroup */
    public DataBaseGroup(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    @SuppressWarnings("unchecked")
    public Groups GetGroups()
    {
        Groups groups = new Groups();
        
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement= dataBase.createStatement();
            String query;
            query = "select ID, GROUPE, PARENTID, 0 AS INTLEVEL, DESCRIPT from GROUPES order by GROUPE";
            ResultSet rs = statement.executeQuery(query);
            ArrayList rows = new ArrayList();
            try
            {
                ResultSetMetaData metaData = rs.getMetaData();
                while (rs.next())
                {
                    ArrayList newRow = new ArrayList();
                    for (int i = 1; i <= metaData.getColumnCount(); i++)
                    {
                        newRow.add(rs.getObject(i));
                    }
                    rows.add(newRow);
                }
            }
            catch (SQLException ex)
            {
                MainClass.writelog(ex.getMessage());
            }

            groups.setGroupsList(rows);
            
            //Build the tree from the root
            //----------------------------
            int maxLevel = 1;
            int iLevel;
            
            //first, get the data
            for (int i=0;i<rows.size();i++)
            {
                ArrayList v = (ArrayList)rows.get(i);
                String strID = String.valueOf(v.get(0));
                String strLevel = groups.getLevel(strID);
                Integer iT = new Integer(strLevel);
                iLevel = iT.intValue();
                if ( iLevel > maxLevel) maxLevel = iLevel;
                v.set(3, strLevel);
            }
            
            //then reorder the data by level, building a new ArrayList
            ArrayList newRows = new ArrayList();
            for (int il=1; il<= maxLevel; il++)
            {
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    Integer iT = new Integer(String.valueOf(v.get(3)));
                    iLevel = iT.intValue();
                    if (iLevel == il)
                    {
                        newRows.add(v);
                    }
                }
            }
            
            //groups.setGroupsList(newRows);
            
            //finally, look at the data by level
            for (int i=0;i<newRows.size();i++)
            {
                ArrayList v = (ArrayList)newRows.get(i);
                String strID = String.valueOf(v.get(0));
                String strGroup = String.valueOf(v.get(1));
                String strParentID = String.valueOf(v.get(2));
                String strLevel = String.valueOf(v.get(3));
                if (strLevel.equals(String.valueOf(2)))//1 + groupKind)))
                {
                    DefaultMutableTreeNode child = new DefaultMutableTreeNode(strGroup);
                    groups.getTopNode().add(child);
                    DefaultMutableTreeNode child2 = new DefaultMutableTreeNode(strID);
                    groups.getTopIDsNode().add(child2);
                }
                else
                {
                    groups.checkGroupChildren(groups.getTopNode(), groups.getTopIDsNode(), strParentID, strGroup, strID);
                }
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return null;
        }
        
        return groups;
    }
    
    public boolean removeGroup(Groups groups, String strGroupID)
    {
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ArrayList groupChildren = groups.getGroupChildren(strGroupID);
            for (int i=0; i<groupChildren.size(); i++)
            {
                String strID = (String)groupChildren.get(i);
                groups.removeChildren(strID);
            }
            statement.executeUpdate("DELETE FROM GROUPES WHERE ID=" + strGroupID);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return false;
        }
        
        return true;
    }

    public boolean recoverGroupsLostParents()
    {
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            //statement.executeUpdate("UPDATE GROUPES SET PARENTID=0 WHERE PARENTID NOT IN (SELECT GROUPESID FROM GROUPES) AND PARENTID != 0");
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return false;
        }
        
        return true;
    }

    public boolean changeGroupName(String oldName, String newName)
    {
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            String query = "Update GROUPES Set GROUPE='" + newName.replace("'", "''") + "' WHERE GROUPE='" + oldName.replace("'", "''") + "'";
            statement.executeUpdate(query);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return false;
        }
        
        return true;
    }

    public boolean changeGroups(Groups groups, String strSource, String strDestination)
    {
        try
        {
            String strDestinationID = groups.getGroupID(strDestination);
            String strSourceID = groups.getGroupID(strSource);
            boolean bolFound = false;
            String strParent = strDestinationID;
            
            while (!strParent.equals("0"))
            {
                strParent = groups.getParentID(strParent);
                if (strParent.equals(strSourceID)) bolFound = true;
            }
            if (bolFound == true)
            {
                return false;
            }
            else
            {
                if (dataBase == null)
                    dataBase = MainClass.starLoginManager.getConnection();
                Statement statement = dataBase.createStatement();
                statement.executeUpdate("UPDATE GROUPES SET PARENTID=" + strDestinationID + " WHERE ID=" + strSourceID);
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return false;
        }
        
        return true;
    }
    
    public boolean getClientsInGroup(String strGroup)
    {
        boolean recipes = false;
        try
        {
            int result;
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Count(CLIENTID) FROM client WHERE GROUPEID=" + strGroup);
            rs.next();
            result = rs.getInt(1);
            if (result >0)
            {
                recipes = true;
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
        }
        return recipes;
    }

    public boolean addGroup(Groups groups, String strSource, String strNewGroup, String strNewDescript)
    {
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            String query = "INSERT INTO GROUPES (GROUPE, DESCRIPT, PARENTID) VALUES ('".concat(strNewGroup.replace("'", "''")).concat("','").concat(strNewDescript.replace("'", "''")).concat("',").concat(groups.getGroupID(strSource)) + ")";
            statement.executeUpdate(query);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.writelog(ex.getMessage());
            return false;
        }
        
        return true;
    }

}
