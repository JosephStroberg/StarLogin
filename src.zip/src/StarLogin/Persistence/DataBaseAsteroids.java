package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Asteroids;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseAsteroids extends DataBaseRecords
{
    /** Creates new DataBaseAsteroids */
    public DataBaseAsteroids(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Asteroids getAsteroids()
    {
        Asteroids asteroids = new Asteroids();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, Asteroid, Numero, HMagnitude, MeanAnomaly, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, DailyMotion, Epoch, Comments, Picture FROM Asteroids ORDER BY Asteroid");
            ArrayList rows = asteroids.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = asteroids.getHeaders();
        ArrayList fields = asteroids.getFields();
        ArrayList fieldsVal = asteroids.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("Asteroid"));
        columnNames.add(2, bundle.getString("Number"));
        columnNames.add(3, bundle.getString("HMagnitude"));
        columnNames.add(4, bundle.getString("MeanAnomaly"));
        columnNames.add(5, bundle.getString("Eccentricity"));
        columnNames.add(6, bundle.getString("PerihelionLongitude"));
        columnNames.add(7, bundle.getString("NorthNodeLongitude"));
        columnNames.add(8, bundle.getString("Inclination"));
        columnNames.add(9, bundle.getString("SemiMajorAxis"));
        columnNames.add(10, bundle.getString("DailyMotion"));
        columnNames.add(11, bundle.getString("Epoch"));
        columnNames.add(12, bundle.getString("Comments"));
        columnNames.add(13, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "Asteroid");
        fields.add(2, "Number");
        fields.add(3, "HMagnitude");
        fields.add(4, "MeanAnomaly");
        fields.add(5, "Eccentricity");
        fields.add(6, "PerihelionLongitude");
        fields.add(7, "NorthNodeLongitude");
        fields.add(8, "Inclination");
        fields.add(9, "SemiMajorAxis");
        fields.add(10, "DailyMotion");
        fields.add(11, "Epoch");
        fields.add(12, "Comments");
        fields.add(13, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT Asteroid FROM Asteroids WHERE Asteroid is not null AND Asteroid!='' ORDER BY Asteroid"));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        fieldsVal.add(9, getListe(""));
        fieldsVal.add(10, getListe(""));
        fieldsVal.add(11, getListe(""));
        fieldsVal.add(12, getListe(""));
        fieldsVal.add(13, getListe(""));
        
        return asteroids;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}

