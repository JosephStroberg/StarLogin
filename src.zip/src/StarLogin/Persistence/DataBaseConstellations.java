package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Constellations;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConstellations extends DataBaseRecords {

    /** Creates new DataBaseConstellations */
    public DataBaseConstellations(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Constellations getConstellations()
    {
        Constellations constellations = new Constellations();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Constellation, Translation, Abbreviation, RACenter, DCenter, Comments, Picture FROM Constellations ORDER BY Translation");
            ArrayList rows = constellations.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = constellations.getHeaders();
        ArrayList fields = constellations.getFields();
        ArrayList fieldsVal = constellations.fieldsValues();
  
        columnNames.add(0, bundle.getString("Constellation"));
        columnNames.add(1, bundle.getString("Translation"));
        columnNames.add(2, bundle.getString("Abbreviation"));
        columnNames.add(3, bundle.getString("RACenter"));
        columnNames.add(5, bundle.getString("DCenter"));
        columnNames.add(5, bundle.getString("Comments"));
        columnNames.add(6, bundle.getString("Picture"));
        fields.add(0, "Constellation");
        fields.add(1, "Translation");
        fields.add(2, "Abbreviation");
        fields.add(3, "RACenter");
        fields.add(4, "DCenter");
        fields.add(5, "Comments");
        fields.add(6, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe(""));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        
        return constellations;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
