package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.ConfigurationsMeaning;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConfigurationsMeaning extends DataBaseRecord  {

    private String id;
    
    /** Creates new DataBaseConfigurationsMeaning */
    public DataBaseConfigurationsMeaning(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "ConfigurationsMeaning";
    }

    public ConfigurationsMeaning getConfigurationsMeaning(String configurationsMeaningID)
    {
        ConfigurationsMeaning configurationsMeaning = new ConfigurationsMeaning();
        configurationsMeaning.setId(configurationsMeaningID);
        this.id = configurationsMeaningID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ConfigurationName, ConfigurationNumber, ConfigurationDescription, ConfigurationMeaning, ConfigurationValue FROM ConfigurationsMeaning WHERE ID=" + configurationsMeaningID);
            while (rs.next())
            {
                configurationsMeaning.setConfigurationName(rs.getString(1));
                configurationsMeaning.setConfigurationNumber(rs.getByte(2));
                configurationsMeaning.setConfigurationDescription(rs.getString(3));
                configurationsMeaning.setConfigurationMeaning(rs.getString(4));
                configurationsMeaning.setConfigurationValue(rs.getDouble(5));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        configurationsMeaning.setRow(findRow());
        configurationsMeaning.setRowNB(findRowNB());
        return configurationsMeaning;
        
    }
    
    public void setConfigurationsMeaning(ConfigurationsMeaning configurationsMeaning)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            byte configurationNumber = configurationsMeaning.getConfigurationNumber();
            String sConfigurationName = SQLString.processNull(configurationsMeaning.getConfigurationName());
            String sConfigurationDescription = SQLString.processNull(configurationsMeaning.getConfigurationDescription());
            String sConfigurationMeaning = SQLString.processNull(configurationsMeaning.getConfigurationMeaning());
            double configurationValue = configurationsMeaning.getConfigurationValue();
            
            if (configurationsMeaning.getAdding()==true)
            {
                query = "INSERT INTO ConfigurationsMeaning (ConfigurationName, ConfigurationNumber, ConfigurationDescription, ConfigurationMeaning, ConfigurationValue) VALUES ("
                + "'" + MainClass.replaceQuotes(sConfigurationName) + "', "
                + configurationNumber + ", '" + MainClass.replaceQuotes(sConfigurationDescription) + "', '" + MainClass.replaceQuotes(sConfigurationMeaning) + "', "
                + configurationValue + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                configurationsMeaning.setId(newID);

                id = newID;
                int row = findRow();
                configurationsMeaning.setRow(row);
                configurationsMeaning.setRowNB(configurationsMeaning.getRowNB() + 1);
                configurationsMeaning.setAdding(false);
            }
            else
            {
                query = "UPDATE ConfigurationsMeaning SET ConfigurationName='" + MainClass.replaceQuotes(sConfigurationName) + "', ConfigurationNumber=" + configurationNumber + ", ConfigurationDescription='" + MainClass.replaceQuotes(sConfigurationDescription) + "', ConfigurationsMeaning='" + MainClass.replaceQuotes(sConfigurationMeaning) + "', ConfigurationValue=" + configurationValue + " WHERE ID=" + configurationsMeaning.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);
            }
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(ConfigurationsMeaning configurationsMeaning)
    {
        rRecord("configurationsMeanings", id);
        configurationsMeaning.setRowNB(configurationsMeaning.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("configurationsMeanings");
    }

    private int findRow()
    {
        return fRow("configurationsMeanings", id, " ORDER BY ConfigurationName", "configurationsMeanings");
    }

    private int findRowNB()
    {
        return fRowNB("configurationsMeanings", "configurationsMeanings");
    }
}
