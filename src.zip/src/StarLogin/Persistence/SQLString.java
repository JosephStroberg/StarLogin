package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class SQLString extends Object
{
    public static final String Canceled = "$-1$50124656";
    public static final String Enter = "\r\n";
    public static final String Tab = "\t";
    public static final int LEN_SELECT  = 6;
    public static final int LEN_SELECT_  = 7;
    public static final int LEN__WHERE  = 6;
    public static final int LEN__ORDER_BY  = 9;
    public static final int LEN__FROM  = 5;
    
    //Get a ArrayList from a resultset
    //get the current record
    @SuppressWarnings("unchecked")
    public static ArrayList processRows(ResultSet rs)
    {
        ArrayList rows = new ArrayList();
        try
        {
            ResultSetMetaData metaData = rs.getMetaData();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= metaData.getColumnCount(); i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return rows;
    }
    
    public static String processNull(String value)
    {
        if (value==null || value.equals(""))
        {
            return "null";
        }
        else
        {
            return value;
        }
    }
    
}
