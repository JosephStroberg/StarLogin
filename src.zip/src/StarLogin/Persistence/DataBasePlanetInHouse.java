package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.PlanetInHouse;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePlanetInHouse extends DataBaseRecord
{

    /** Creates new DataBasePlanetInHouse */
    public DataBasePlanetInHouse(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "PlanetInHouse";
    }

    public PlanetInHouse getPlanetInHouse(byte planetID, byte houseID)
    {
        PlanetInHouse planetInHouse = new PlanetInHouse();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM PlanetInHouse WHERE ID=" + planetID + " AND H_I=" + houseID);
            while (rs.next())
            {
                planetInHouse.setMeaning(rs.getString(1));
                planetInHouse.setValue(rs.getDouble(2));
            }
            planetInHouse.setPlanetID(planetID);
            planetInHouse.setHouseID(houseID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return planetInHouse;
        
    }
}
