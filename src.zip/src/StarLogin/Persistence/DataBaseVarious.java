package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 */
public class DataBaseVarious
{
    DataBaseConnection dataBase;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    /** Creates new DataBaseUser */
    public DataBaseVarious(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }
    
    public boolean updateDataBase(String query)
    {
        //boolean result = false;
        int retryCount = 10;
        Statement statement = null;
        boolean transactionCompleted = false;
        do
        {
            try
            {
                if (dataBase == null)
                    dataBase = MainClass.starLoginManager.getConnection();
                retryCount = 0;
                statement = dataBase.createStatement();
                if (statement != null)
                {
                    statement.executeUpdate(query);
                    statement.close();
                    transactionCompleted = true;
                }
            }
            catch (SQLException ex)
            {
                MainClass.setMessage(ex.getMessage()); //int errno =
                ex.getErrorCode(); //if (errno == 1205 || errno == 1213)
            }
            finally
            {
                if (statement != null)
                {
                    try
                    {
                        statement.close();
                    }
                    catch (SQLException sqlEx)
                    {
                        MainClass.setMessage(sqlEx.getMessage());
                    }
                }
            }
        }
        while (!transactionCompleted && (retryCount > 0));
        return transactionCompleted;
    }
    
}

