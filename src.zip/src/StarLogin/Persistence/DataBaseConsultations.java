package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Consultations;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConsultations extends DataBaseRecords {

    /** Creates new DataBaseConsultations */
    public DataBaseConsultations(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Consultations getConsultations()
    {
        Consultations consultations = new Consultations();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, ClientID, ClientName, Services, Fee, ConsultationDate, ConsultationTime, Location, Done, Due, Payed, Comments, Picture FROM Consultations ORDER BY ConsultationDate, ConsultationTime");
            ArrayList rows = consultations.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = consultations.getHeaders();
        ArrayList fields = consultations.getFields();
        ArrayList fieldsVal = consultations.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, "_1");
        columnNames.add(2, bundle.getString("consultationsCLIENTNAME"));
        columnNames.add(3, bundle.getString("consultationsSERVICES"));
        columnNames.add(4, bundle.getString("consultationsFEE"));
        columnNames.add(5, bundle.getString("consultationsCONSULTATIONDATE"));
        columnNames.add(6, bundle.getString("consultationsCONSULTATIONTIME"));
        columnNames.add(7, bundle.getString("consultationsLOCATION"));
        columnNames.add(8, bundle.getString("consultationsDONE"));
        columnNames.add(9, bundle.getString("consultationsDUE"));
        columnNames.add(10, bundle.getString("consultationsPAYED"));
        columnNames.add(11, bundle.getString("consultationsCOMMENTS"));
        columnNames.add(12, bundle.getString("consultationsPICTURE"));
        fields.add(0, "ID");
        fields.add(1, "ClientID");
        fields.add(2, "ClientName");
        fields.add(3, "Services");
        fields.add(4, "Fee");
        fields.add(5, "ConsultationDate");
        fields.add(6, "ConsultationTime");
        fields.add(7, "Location");
        fields.add(8, "Done");
        fields.add(9, "Due");
        fields.add(10, "Payed");
        fields.add(11, "Comments");
        fields.add(12, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe(""));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        fieldsVal.add(9, getListe(""));
        fieldsVal.add(10, getListe(""));
        fieldsVal.add(11, getListe(""));
        fieldsVal.add(12, getListe(""));
        
        return consultations;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
