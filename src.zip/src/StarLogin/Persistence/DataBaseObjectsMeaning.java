package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.ObjectsMeaning;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseObjectsMeaning extends DataBaseRecord
{
    /** Creates new DataBasePlanetInSign */
    public DataBaseObjectsMeaning(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "ObjectsMeaning";
    }

    public ObjectsMeaning getObjectsMeaning(byte objectID, byte typeID)
    {
        ObjectsMeaning objectsMeaning = new ObjectsMeaning();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM ObjectsMeaning WHERE ObjectID=" + objectID + " AND ObjectTypeID=" + typeID);
            while (rs.next())
            {
                objectsMeaning.setMeaning(rs.getString(1));
                objectsMeaning.setValue(rs.getDouble(2));
            }
            objectsMeaning.setObjectID(objectID);
            objectsMeaning.setObjectTypeID(typeID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return objectsMeaning;
        
    }
}
