package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Enum.OS;
import java.io.File;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConnection implements java.io.Serializable
{
    private Connection connection;
    private java.util.ResourceBundle bundle = MainClass.bundle;
    //private NetworkServerControl server;

    private void setDBSystemDir()
    {
        // Decide on the db system directory: <userhome>/starlog/
        //String userHomeDir = System.getProperty("user.home", ".");
        //String systemDir = userHomeDir;// "/.netbeans/6.7/derby";

        // Set the db system directory.
        System.setProperty("derby.system.home", ".");
    }
    
    private void testStarLog()
    {
        String starlog8 = new File("starlog8".concat(MainClass.langue)).getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
        //JOptionPane.showMessageDialog(new JFrame(), starlog8);
        File starlog8File = new File(starlog8);
        if (!starlog8File.exists() && !starlog8File.isDirectory())
        {
            if (OS.getOS() == OS.apple)
            {
                starlog8 = new File("/Applications/starlogin8/starlog8".concat(MainClass.langue)).getAbsolutePath();
                if (!starlog8File.exists() && !starlog8File.isDirectory())
                {
                    MainClass.setMessage(bundle.getString("starlog8absentFromAppDir").concat(" ").concat(starlog8), JOptionPane.WARNING_MESSAGE);
                }
                else
                {
                    MainClass.writelog(bundle.getString("msg_noConnection"));
                }
            }
            else
                MainClass.setMessage(bundle.getString("starlog8absentFromAppDir").concat(" ").concat(starlog8), JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            MainClass.writelog(bundle.getString("msg_noConnection"));
        }
    }
    
    /*private String searchDir(String dirToFind, File searchIn, SearchDirForm sdf)
    {
        File[] listOfFiles = searchIn.listFiles();
        if (listOfFiles == null)
            return "0";
        String dirtrouve = "0";
        while (dirtrouve.equals("0"))
        {
            for (int i=0; i<listOfFiles.length; i++)
            {
                if (listOfFiles[i].isDirectory())
                {
                    if (sdf != null)
                        sdf.setDirText(listOfFiles[i].getAbsolutePath());
                    if (listOfFiles[i].getName().toUpperCase().equals(dirToFind.toUpperCase()))
                    {
                        dirtrouve = listOfFiles[i].getAbsolutePath();
                        return dirtrouve;
                    }
                    else
                    {
                        dirtrouve = searchDir(dirToFind, listOfFiles[i], sdf);
                    }
                }
                else
                    dirtrouve = "0";
                if (!dirtrouve.equals("0"))
                    break;
            }
            return dirtrouve;
        }
        return dirtrouve;
    }*/

    /** Creates new DataBaseConnection */
    public DataBaseConnection(String sUrl, String sDriver, String sUser, String sPassword)
    {
        setDBSystemDir();
        
        //MainClass.writelog("enter DataBaseConnection");
        try
        {
            java.lang.Class.forName(sDriver).newInstance();
            MainClass.writelog(bundle.getString("msg_openingConnection"));
            connection = DriverManager.getConnection(sUrl, sUser, sPassword);

            if (connection == null)
            {
                testStarLog();
            }
            else
            {
                // Print all warnings
                for (SQLWarning warn = connection.getWarnings(); warn != null; warn = warn.getNextWarning())
                {
                    MainClass.writelog(bundle.getString("msg_SQLWarning"));
                    MainClass.writelog(bundle.getString("msg_State") + warn.getSQLState());
                    MainClass.writelog(bundle.getString("msg_Msg") + warn.getMessage());
                    MainClass.writelog(bundle.getString("msg_Error") + warn.getErrorCode());
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            MainClass.writelog(bundle.getString("msg_UnknownDriverClass"));
            MainClass.setMessage(ex.getMessage());
        }
        catch (IllegalAccessException ex)
        {
            MainClass.writelog(bundle.getString("msg_UnknownDriverClass"));
            MainClass.setMessage(ex.getMessage());
        }
        catch (InstantiationException ex)
        {
            MainClass.writelog(bundle.getString("msg_UnknownDriverClass"));
            MainClass.setMessage(ex.getMessage());
        }
        catch (SQLException ex)
        {
            testStarLog();

            // Loop through the SQL Exceptions
            while (ex != null)
            {
                MainClass.writelog(bundle.getString("msg_State") + ex.getSQLState());
                MainClass.writelog(bundle.getString("msg_Msg") + ex.getMessage());
                MainClass.writelog(bundle.getString("msg_Error") + ex.getErrorCode());

                ex = ex.getNextException();
            }
        }
    }

    public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException
    {
        if (connection == null)
            return null;
        Statement stmt;
        try
        {
            stmt = connection.createStatement(resultSetType, resultSetConcurrency);
            return stmt;
        }
        catch (SQLException ex)
        {
            MainClass.writelog(bundle.getString("msg_NoStatement"));

            // Loop through the SQL Exceptions
            while (ex != null)
            {
                MainClass.writelog(bundle.getString("msg_State") + ex.getSQLState());
                MainClass.writelog(bundle.getString("msg_Msg") + ex.getMessage());
                MainClass.writelog(bundle.getString("msg_Error") + ex.getErrorCode());

                ex = ex.getNextException();
            }
            return null;
        }
    }

    public Statement createStatement() throws SQLException
    {
        if (connection == null)
            return null;
        Statement stmt;
        try
        {
            stmt = connection.createStatement();
            return stmt;
        }
        catch (SQLException ex)
        {
            MainClass.writelog(bundle.getString("msg_NoStatement"));

            // Loop through the SQL Exceptions
            while (ex != null)
            {
                MainClass.writelog(bundle.getString("msg_State") + ex.getSQLState());
                MainClass.writelog(bundle.getString("msg_Msg") + ex.getMessage());
                MainClass.writelog(bundle.getString("msg_Error") + ex.getErrorCode());

                ex = ex.getNextException();
            }
            return null;
        }
    }

    public Connection GetConnection()
    {
        return connection;
    }

    public void close() throws SQLException
    {
        MainClass.writelog(bundle.getString("msg_closingConnection"));
        connection.close();
    }

    /*public boolean stopServer()
    {
        if (dataBaseKind.getKind() == DataBaseKind.Derby)
        {
            try
            {
                //server.logConnections(false);
                server.shutdown();
                return true;
            }
            catch (java.lang.Exception le)
            {
                MainClass.writelog(le);
                return false;
            }
        }
        else
        {
            return true;
        }
    }*/
}
