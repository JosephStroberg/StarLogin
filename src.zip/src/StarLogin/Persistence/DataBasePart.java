package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Part;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePart extends DataBaseRecord
{

    private String id;
    
    /** Creates new DataBasePart */
    public DataBasePart(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "Parts";
    }

    public Part getPart(String partID)
    {
        Part part = new Part();
        part.setId(partID);
        this.id = partID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Part, Ref, Plus, Minus, Comments FROM Parts WHERE ID=" + partID);
            while (rs.next())
            {
                part.setPart(rs.getString(1));
                part.setRef(rs.getByte(2));
                part.setPlus(rs.getByte(3));
                part.setMinus(rs.getByte(4));
                part.setComments(rs.getString(5));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        part.setRow(findRow());
        part.setRowNB(findRowNB());
        return part;
        
    }

    public Part getPartFrom(String ref, String plus, String minus)
    {
        Part part = new Part();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Part, Ref, Plus, Minus, Comments, ID FROM Parts WHERE Ref=" + ref + " AND Plus=" + plus + " AND Minus=" + minus);
            while (rs.next())
            {
                part.setPart(rs.getString(1));
                part.setRef(rs.getByte(2));
                part.setPlus(rs.getByte(3));
                part.setMinus(rs.getByte(4));
                part.setComments(rs.getString(5));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        part.setRow(findRow());
        part.setRowNB(findRowNB());
        return part;
        
    }

    public Part getPartFromName(String partName)
    {
        Part part = new Part();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, Ref, Plus, Minus, Comments FROM Parts WHERE Part='" + MainClass.replaceQuotes(partName) + "'");
            while (rs.next())
            {
                part.setId(new Integer(rs.getInt(1)).toString());
                part.setPart(partName);
                part.setRef(rs.getByte(2));
                part.setPlus(rs.getByte(3));
                part.setMinus(rs.getByte(4));
                part.setComments(rs.getString(5));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        part.setRow(findRow());
        part.setRowNB(findRowNB());
        return part;
        
    }
    
    public void setPart(Part part)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sPart = SQLString.processNull(part.getPart());
            byte ref = part.getRef();
            byte plus = part.getPlus();
            byte minus = part.getMinus();
            String sComments = SQLString.processNull(part.getComments());
            
            if (part.getAdding()==true)
            {
                query = "INSERT INTO Parts (Part, Ref, Plus, Minus, Comments) VALUES ('" + MainClass.replaceQuotes(sPart) + "', " + ref + ", " + plus + ", " + minus + ", '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                part.setId(newID);

                id = newID;
                int row = findRow();
                part.setRow(row);
                part.setRowNB(part.getRowNB() + 1);
                part.setAdding(false);
            }
            else
            {
                query = "UPDATE Parts SET Part='" + MainClass.replaceQuotes(sPart) + "', Ref=" + ref + ", Plus=" + plus + ", Minus=" + minus + ", Comments='" + MainClass.replaceQuotes(sComments) + "' WHERE ID=" + part.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);
            }
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Part part)
    {
        rRecord("parts", id);
        part.setRowNB(part.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("parts");
    }

    private int findRow()
    {
        return fRow("parts", id, "", "parts");
    }

    private int findRowNB()
    {
        return fRowNB("parts", "parts");
    }
}

