package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Consultation;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConsultation extends DataBaseRecord
{
    
    private String id;
    
    /** Creates new DataBaseConsultation */
    public DataBaseConsultation(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "Consultations";
    }
    
    public Consultation getConsultation(String consultationID)
    {
        Consultation consultation = new Consultation();
        consultation.setId(consultationID);
        this.id = consultationID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ClientID, ClientName, Services, Fee, ConsultationDate, ConsultationTime, Location, Done, Due, Payed, Comments, Picture FROM Consultations WHERE ID=" + consultationID);
            while (rs.next())
            {
                consultation.setClientID(rs.getInt(1));
                consultation.setClientName(rs.getString(2));
                consultation.setServices(rs.getString(3));
                consultation.setFee(rs.getString(4));
                consultation.setConsultationDate(rs.getString(5));
                consultation.setConsultationTime(rs.getString(6));
                consultation.setLocation(rs.getString(7));
                consultation.setDone(rs.getBoolean(8));
                consultation.setDue(rs.getString(9));
                consultation.setPayed(rs.getBoolean(10));
                consultation.setComments(rs.getString(11));
                Blob blob = rs.getBlob(12);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                consultation.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        consultation.setRow(findRow(consultationID));
        consultation.setRowNB(findRowNB());
        return consultation;
        
    }
    
    public void setConsultation(Consultation consultation)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            int clientID = consultation.getClientID();
            String sClientName = consultation.getClientName();
            String sServices = SQLString.processNull(consultation.getServices());
            String sFee = SQLString.processNull(consultation.getFee());
            String sConsultationDate = SQLString.processNull(consultation.getConsultationDate());
            String sConsultationTime = SQLString.processNull(consultation.getConsultationTime());
            String sLocation = SQLString.processNull(consultation.getLocation());
            byte bDone = AstronomyMaths.bool2byte(consultation.getDone());
            String sDue = SQLString.processNull(consultation.getDue());
            //boolean bPayed = consultation.getPayed();
            byte bPayed = AstronomyMaths.bool2byte(consultation.getPayed());
            String sComments = SQLString.processNull(consultation.getComments());
            //String imgIcon = SQLString.processNull(consultation.getPicture());
            ImageIcon imgIcon = consultation.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(imgIcon);
            if (consultation.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }
            if (consultation.getAdding()==true)
            {
                query = "INSERT INTO Consultations (ClientID, ClientName, Services, Fee, ConsultationDate, ConsultationTime, Location, Done, Due, Payed, Comments) VALUES ("
                + clientID + ", '" + MainClass.replaceQuotes(sClientName) + "', '" + MainClass.replaceQuotes(sServices) + "', '" + MainClass.replaceQuotes(sFee) + "', '" + sConsultationDate + "', '" + MainClass.replaceQuotes(sConsultationTime) + "', '" + MainClass.replaceQuotes(sLocation) + "', " + bDone + ", '" + MainClass.replaceQuotes(sDue) + "', " + bPayed + ", '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                consultation.setId(newID);

                id = newID;
                int row = findRow(newID);
                consultation.setRow(row);
                consultation.setRowNB(consultation.getRowNB() + 1);
                consultation.setAdding(false);
            }
            else
            {
                query = "UPDATE Consultations SET ClientID=" + clientID
                + ", ClientName='" + MainClass.replaceQuotes(sClientName)+ "'"
                + ", Services='" + MainClass.replaceQuotes(sServices)+ "'"
                + ", Fee='" + MainClass.replaceQuotes(sFee)+ "'"
                + ", ConsultationDate='" + MainClass.replaceQuotes(sConsultationDate)+ "'"
                + ", ConsultationTime='" + MainClass.replaceQuotes(sConsultationTime)+ "'"
                + ", Location='" + MainClass.replaceQuotes(sLocation)+ "'"
                + ", Done=" + bDone
                + ", Due='" + MainClass.replaceQuotes(sDue)+ "'"
                + ", Payed=" + bPayed
                + ", Comments='" + MainClass.replaceQuotes(sComments)+ "'"
                + " WHERE ID=" + consultation.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (imgIcon == null)
                {
                    statement.executeUpdate("UPDATE Consultations SET picture=null where id=" + consultation.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM consultations where id=" + consultation.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Consultation consultation)
    {
        rRecord("consultations", id);
        consultation.setRowNB(consultation.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("consultations");
    }

    private int findRow(String id)
    {
        return fRow("consultations", id, " ORDER BY ConsultationDate, ConsultationTime", "consultations");
    }

    private int findRowNB()
    {
        return fRowNB("consultations", "consultations");
    }
}

