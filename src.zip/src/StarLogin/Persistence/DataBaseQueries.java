package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.Data.Records;
import StarLogin.Systeme.QueryDescription;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 */
public class DataBaseQueries extends DataBaseRecords
{
    //private DefaultListModel queries = new DefaultListModel();
    private ArrayList rows;
    private ArrayList liste;
    private ArrayList sizes;
    //private java.util.ResourceBundle bundle = MainClass.bundle;
    private StarLoginManager sln = MainClass.starLoginManager;
    
    /** Creates a new instance of Queries */
    @SuppressWarnings("unchecked")
    public DataBaseQueries()
    {
        dataBase = sln.getConnection();
        setConnection(dataBase);
    }
    
    public QueryDescription getQuery(int qnb)
    {
        String sqlFrom;
        String sqlWhere;
        ArrayList fields;
        ArrayList columnNames;
        ArrayList types;
        QueryDescription query = null;
        int nb = 0;

        //Contacts
        if (qnb == 0)
        {
            Records clients = sln.getRecords("SELECT ID,FIRSTNAME,OTHERNAMES,ADDRESS,CITY,ZIPCODE,STATEPROVINCE,COUNTRY,AGE,GENDER,FAMILYSTATUS,OCCUPATIONS,RANK,MAINHOBBIES,RELIGION,BIRTHDATE,BIRTHTIME,BIRTHPLACE,NOTE,PHONE,TELBUREAU,CELL,COURRIEL,COMPAGNIE,ADRESSECOMP,VILLECOMP,PROVINCECOMP,PAYSCOMP,ZIPCOMP,TELCOMP,FAXCOMP,WEBCOMP,GROUPEID FROM clients ORDER BY OTHERNAMES,FIRSTNAME", "clients");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Clients"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Clients
        else if (qnb == 1)
        {
            Records clients = sln.getRecords("SELECT ID,FIRSTNAME,OTHERNAMES,ADDRESS,CITY,ZIPCODE,STATEPROVINCE,COUNTRY,AGE,GENDER,FAMILYSTATUS,OCCUPATIONS,RANK,MAINHOBBIES,RELIGION,BIRTHDATE,BIRTHTIME,BIRTHPLACE,NOTE,PHONE,TELBUREAU,CELL,COURRIEL,COMPAGNIE,ADRESSECOMP,VILLECOMP,PROVINCECOMP,PAYSCOMP,ZIPCOMP,TELCOMP,FAXCOMP,WEBCOMP FROM clients WHERE GROUPEID=1 ORDER BY OTHERNAMES,FIRSTNAME", "clients");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Clients"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Fournisseurs
        else if (qnb == 2)
        {
            Records clients = sln.getRecords("SELECT ID,FIRSTNAME,OTHERNAMES,ADDRESS,CITY,ZIPCODE,STATEPROVINCE,COUNTRY,AGE,GENDER,FAMILYSTATUS,OCCUPATIONS,RANK,MAINHOBBIES,RELIGION,BIRTHDATE,BIRTHTIME,BIRTHPLACE,NOTE,PHONE,TELBUREAU,CELL,COURRIEL,COMPAGNIE,ADRESSECOMP,VILLECOMP,PROVINCECOMP,PAYSCOMP,ZIPCOMP,TELCOMP,FAXCOMP,WEBCOMP FROM clients WHERE GROUPEID=2 ORDER BY OTHERNAMES,FIRSTNAME", "clients");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Clients"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Events
        else if (qnb == 3)
        {
            Records clients = sln.getRecords("SELECT ID,SURNAME,OTHERNAMES,ENTITYTYPE,EVENTTYPE,UTDATE,LOCALDATE,UTTIME,LOCAL_TIME,TIMELAG,PLACENAME,PLACELATITUDE,PLACELONGITUDE,SIGN,ASCENDANT,COMMENTS FROM events ORDER BY OTHERNAMES,SURNAME,EVENTTYPE", "events");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Events"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Rdv
        else if (qnb == 4)
        {
            Records clients = sln.getRecords("SELECT ID,CLIENTID,NOM_CLIENT,TEL_CLIENT,DATE_,DUREE,HEURE_DEBUT,HEURE_FIN,DESCRIPTION,STATUS_,RDVRECURID FROM rdv ORDER BY NOM_CLIENT,TEL_CLIENT", "rdv");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("RendezVouss"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Asteroids
        else if (qnb == 5)
        {
            Records clients = sln.getRecords("SELECT ID, ASTEROID, NUMERO, HMAGNITUDE, MEANANOMALY, ECCENTRICITY, PERIHELIONLONGITUDE, NORTHNODELONGITUDE, INCLINATION, SEMIMAJORAXIS, DAILYMOTION, EPOCH, COMMENTS FROM asteroids ORDER BY ASTEROID", "asteroids");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Asteroids"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Consultations
        else if (qnb == 6)
        {
            Records clients = sln.getRecords("SELECT ID, CLIENTID, CLIENTNAME, SERVICES, FEE, CONSULTATIONDATE, CONSULTATIONTIME, LOCATION, DONE, DUE, PAYED, COMMENTS FROM consultations ORDER BY CLIENTNAME,CONSULTATIONDATE", "consultations");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Consultations"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Comets
        else if (qnb == 7)
        {
            Records clients = sln.getRecords("SELECT ID, COMET, PERIHELIONDATE, PERIHELIONUA, ECCENTRICITY, PERIHELIONLONGITUDE, NORTHNODELONGITUDE, INCLINATION, SEMIMAJORAXIS, PERIOD, EPOCH, COMMENTS FROM comets ORDER BY COMET", "comets");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Comets"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Stars
        else if (qnb == 8)
        {
            Records clients = sln.getRecords("SELECT ID, HR, STARNAME, IDENTITE, RA, D, PROPERMOTIONRA, PROPERMOTIOND, MAGNITUDE, RADIALVELOCITY, DISTANCE, DISTERROR, LIGHT, COMMENTS FROM stars", "stars");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Stars"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Places
        else if (qnb == 9)
        {
            Records clients = sln.getRecords("SELECT ID, PLACENAME, PLACELATITUDE, PLACELONGITUDE, COMMENTS FROM places ORDER BY PLACENAME", "places");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Places"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Parts
        else if (qnb == 10)
        {
            Records clients = sln.getRecords("SELECT ID, PART, REF, PLUS, MINUS, COMMENTS FROM parts ORDER BY PART", "parts");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("ArabianParts"), sqlFrom, sqlWhere, fields, columnNames, types);
        }

        //Constellations
        else if (qnb == 11)
        {
            Records clients = sln.getRecords("SELECT ID, CONSTELLATION, TRANSLATION, ABBREVIATION, RACENTER, DCENTER, COMMENTS FROM constellations ORDER BY TRANSLATION", "constellations");
            sqlFrom = clients.getFrom();
            sqlWhere = clients.getWhere();
            fields = clients.getFields();
            columnNames = clients.getHeaders();
            types = clients.getTypes();
            sizes = clients.getSizes();
            query = new QueryDescription(nb, bundle.getString("Constellations"), sqlFrom, sqlWhere, fields, columnNames, types);
        }
        return query;
    }

    @SuppressWarnings("unchecked")
    public ArrayList getList(String strQuery)
    {
        liste = new ArrayList();
        try
        {
            //Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();

            ResultSet rs = statement.executeQuery(strQuery);

            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                liste.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            if (MainClass.mainForm == null)
                javax.swing.JOptionPane.showMessageDialog(null, ex.getMessage(), bundle.getString("ERREUR"), javax.swing.JOptionPane.ERROR_MESSAGE);
            else
               MainClass.setMessage(ex.getMessage());
            return null;
        }
        return liste;
    }

    @SuppressWarnings("unchecked")
    public String buildQuery(ArrayList fields, ArrayList headers, String from, String where, String group, String order, String having)
    {
        String query = "SELECT ";
        rows = new ArrayList();
        try
        {
            //Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();

            //construction de la requ�te � partir des champs
            for(int i=0; i<fields.size(); i++)
            {
                query = query + fields.get(i).toString() + " AS \"" + headers.get(i).toString() + "\", ";
            }
            query = query.substring(0, query.length() -2);
            query = query + from + where + group + having + order;

            ResultSet rs = statement.executeQuery(query);
            //ArrayList rows = clients.getRecords();

            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            if (MainClass.mainForm == null)
                javax.swing.JOptionPane.showMessageDialog(null, ex.getMessage(), bundle.getString("ERREUR"), javax.swing.JOptionPane.ERROR_MESSAGE);
            else
               MainClass.setMessage(ex.getMessage());
            return null;
        }
        return query;
    }

    public ArrayList getRows()
    {
        return rows;
    }
    
    public ArrayList getSizes()
    {
        return sizes;
    }
}
