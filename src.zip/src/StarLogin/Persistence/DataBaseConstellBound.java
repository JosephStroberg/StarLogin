package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.ConstellBound;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseConstellBound
{

    DataBaseConnection dataBase;
    
    /** Creates new DataBaseConstellBound */
    public DataBaseConstellBound(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public ConstellBound getConstellBound()
    {
        ConstellBound constellBound = new ConstellBound();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Move, RA, D FROM ConstellBound");
            ArrayList rows = constellBound.getConstellBound();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        return constellBound;
    }
}

