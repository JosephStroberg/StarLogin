package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Record;
import StarLogin.Systeme.QueryDescription;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 */
public class DataBaseRecord
{
    
    protected DataBaseConnection dataBase;
    protected java.util.ResourceBundle bundle = MainClass.bundle;
    private String id;
    
    //To save data in case of update (in order to update only the modified fields)
    private ArrayList valeurs;  //the actual values
    private String initVal[];   //the initial ones
    
    //field names
    private String champs[];

    //Data types
    private ArrayList types;

    //Requete de base
    private String query = "";

    //table name
    protected String tableName;

    //private String sqlSelect;
    private String sqlFrom;
    private String sqlOrderBy;
    //private String sqlWhere;
    private String sqlPartialWhere; //part of the WHERE clause of the query that doesn't contain the id filter giving the specific record
    //private String sqlGroupBy;
    //private String sqlHaving;

    /** Creates new DataBaseClient */
    public DataBaseRecord(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        types = new ArrayList();
    }
    
    public DataBaseRecord()
    {
        types = new ArrayList();
    }

    protected void setConnection(DataBaseConnection dataBaseConnect)
    {
        dataBase = dataBaseConnect;
    }

    //Retrieve the fields from the SELECT query
    @SuppressWarnings("unchecked")
    private String[] parseFields(String sql)
    {
        ArrayList chps = new ArrayList();
        int pos = sql.indexOf(StarLogin.Systeme.QueryDescription.STR_FROM);
        String fieldsPart = sql.substring(7, pos);

        while (fieldsPart.length()>0)
        {
            String champ;
            pos = fieldsPart.indexOf(",");
            if (fieldsPart.startsWith("if(") || fieldsPart.startsWith("date_format(") || fieldsPart.startsWith("time_format("))
            {
                int pos2 = fieldsPart.indexOf(")");
                if (pos2 > 0)
                {
                    pos = fieldsPart.indexOf(",", pos2 + 1);
                }
            }

            if (pos >= 0)
            {
                //extract a field from the rest of the query string
                champ = fieldsPart.substring(0, pos);
                fieldsPart = fieldsPart.substring(pos + 1);
                if (fieldsPart.startsWith(" "))
                {
                    fieldsPart = fieldsPart.substring(1);
                }
            }
            else
            {
                //the last field
                champ = fieldsPart;
                fieldsPart = "";
            }

            chps.add(champ);
        }
        int dim = chps.size();

        String champs2[] = new String[dim];
        for (int i=0; i<dim; i++)
        {
            champs2[i] = chps.get(i).toString();
        }
        return champs2;
    }

    //get the number i field value
    @SuppressWarnings("unchecked")
    private Object getValue(ResultSet rs, ResultSetMetaData rsdata, int i, boolean bNotEmpty)
    {
        Object value = null;
        i += 1;

        try
        {
            int typ = rsdata.getColumnType(i);
            switch(typ)
            {
                case Types.BINARY:
                case Types.CHAR:
                case Types.NCHAR:
                case Types.VARCHAR:
                case Types.VARBINARY:
                case Types.NVARCHAR:
                case Types.LONGVARCHAR:
                case Types.LONGNVARCHAR:
                case Types.LONGVARBINARY:
                    try
                    {
                        if (bNotEmpty)
                            value= removeNull(rs.getString(i));
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeString);
                    }
                    break;

                case Types.NCLOB:
                case Types.CLOB:
                case Types.BLOB:
                    //Blob imgblob = null;
                    if (bNotEmpty)
                    {
                        Blob blob = rs.getBlob(i);
                        javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                        //record.setPicture(icon);
                        /*try
                        {
                            imgblob= rs.getBlob(i);
                        }
                        catch (Exception ex)
                        {
                        }
                        finally
                        {
                            if (imgblob == null)
                                value = "";
                            else
                            {
                                // 
                                // Store the bytes of the blob into a byte array. 
                                //  
                                byte c[]=imgblob.getBytes(1, (int)imgblob.length());                  

                                // create an imageicon using that byte array.  
                                ImageIcon imgf=new ImageIcon(c,"image");  

                                imgblob.free(); //free the Blob resources  
                                // You can get the Image Object as follows.  
                                //Image img=imgf.getImage();     

                                value = imgf;
                            }

                            types.add(i-1, DataBaseRecords.typeIcon);
                        }*/
                        value = blob;
                    }
                    types.add(i-1, DataBaseRecords.typeIcon);
                    break;

                case Types.TINYINT:
                case Types.SMALLINT:
                case Types.INTEGER:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getInt(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeNumber);
                    }
                    break;

                case Types.BIGINT:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getLong(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeNumber);
                    }
                    break;

                case Types.FLOAT:
                    if (rs.next() && rs.getFetchSize() >= 0)
                        value= "" + rs.getFloat(i);
                    types.add(i-1, DataBaseRecords.typeNumber);
                    break;

                case Types.DECIMAL:
                case Types.DOUBLE:
                case Types.NUMERIC:
                case Types.REAL:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getDouble(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeNumber);
                    }
                    break;

                case Types.DATE:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getDate(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeDate);
                    }
                    break;

                case Types.TIME:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getTime(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeDate);
                    }
                    break;

                case Types.TIMESTAMP:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getTimestamp(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeDate);
                    }
                    break;

                case Types.BOOLEAN:
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getBoolean(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        if (value.equals(""))
                            value = "0";
                        types.add(i-1, DataBaseRecords.typeBool);
                    }
                    break;

                case Types.BIT://or string type?
                    try
                    {
                        if (bNotEmpty)
                            value= "" + rs.getByte(i);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeNumber);
                    }
                    break;

                default:
                    try
                    {
                        if (bNotEmpty)
                            value= removeNull(rs.getString(i));
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        types.add(i-1, DataBaseRecords.typeString);
                    }
                    break;
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return value;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Record getRecord(String sql, String tablName, String sqlWhereButID)
    {
        query = sql;
        tableName = tablName;

        //extract the different parts of the statement
        //sqlHaving = QueryDescription.getHavingPart(sql);
        //sqlGroupBy = QueryDescription.getGroupingPart(sql);
        //sqlWhere = QueryDescription.getWherePart(sql);
        sqlOrderBy = QueryDescription.getOrderPart(sql);
        sqlFrom = QueryDescription.getFromPart(sql);
        sqlPartialWhere = sqlWhereButID;

        //to save the fields for further code processing
        Record table = new Record();
        valeurs = table.getValues();

        //parse the fields
        champs = parseFields(query);
        
        try
        {
            //execute the query to get the records
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery(query);
            ResultSetMetaData rsdata = rs.getMetaData();
            while (rs.next())
            {
                //for all fields
                for (int i=0; i<champs.length; i++)
                {
                    //get the value of the field
                    boolean bNotEmpty = true;
                    Object oval = getValue(rs, rsdata, i, bNotEmpty);
                    valeurs.add(i, oval);
                    if (new Integer(types.get(i).toString()).intValue() == DataBaseRecords.typeIcon)
                    {
                        javax.swing.ImageIcon icon = BlobIconConv.blob2Icon((Blob)oval);
                        table.setPicture(icon);
                    }
                }
            }
            //close the result data set and statement
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        //save the initial values
        initVal = new String[valeurs.size()];
        for (int i=0; i<initVal.length; i++)
        {
            initVal[i] = null2String(valeurs.get(i));
        }

        //case of new record : no values
        if (valeurs.isEmpty())
        {
            //valeurs.add(0, "0");
            valeurs.add(0, "");
            types.add(DataBaseRecords.typeNumber);
            Statement statement;
            try
            {
                if (dataBase == null)
                    dataBase = MainClass.starLoginManager.getConnection();
                statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                boolean bNotEmpty = rs.next();
                ResultSetMetaData rsdata = rs.getMetaData();
                for (int i=1; i<champs.length; i++)
                {
                    //get the value of the field
                    //valeurs.add(i, "");
                    valeurs.add(i,getValue(rs, rsdata, i, bNotEmpty));
                }
            }
            catch (SQLException ex)
            {
                MainClass.setMessage(ex.getMessage());
            }
        }

        //set the id
        table.setId(null2String(valeurs.get(0)));    //the first field is always the id (or considered as)
        this.id = null2String(valeurs.get(0));

        //set the record number and number of rows for further processing
        //table.setRow(findRow());
        //table.setRowNB(findRowNB());
        
        //set the record number and number of rows for further processing
        if (sqlPartialWhere == null)
        {
            table.setRow(fRow(tableName, id, sqlOrderBy, sqlFrom));
            table.setRowNB(fRowNB(tableName, sqlFrom));
        }
        else
        {
            table.setRow(fRow(tableName, id, sqlOrderBy, sqlFrom, sqlPartialWhere));
            table.setRowNB(fRowNB(tableName, sqlFrom, sqlPartialWhere));
        }


        return table;
    }
    
    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
    
    private String processNull(Object value)
    {
        if (value==null)
        {
            return "null";
        }
        else
        {
            String valeur = value.toString();
            if(valeur.equals(""))
                return "null";
            else
                return valeur;
        }
    }

    //set the current record
    //we assume there is only one picture in the table (or none)
    public void setRecord(Record table)
    {
        String sql;
        Object value[] = new Object[champs.length];

        //get the values
        for (int i=0; i<champs.length; i++)
        {
            if (valeurs.get(i) == null)
                value[i] = "";
            else
                value[i] = valeurs.get(i);
        }
        
        try
        {
            Blob blob = null;
            String pictureFieldName = "";
            Statement statement;

            //create insert statement
            if (table.getAdding()==true)
            {
                statement = dataBase.createStatement();

                //field names
                sql = "INSERT INTO " + tableName + " (";

                for (int i=1; i<champs.length - 1; i++)
                {
                    if (new Integer(types.get(i).toString()).intValue() != DataBaseRecords.typeIcon)
                        sql = sql + champs[i] + ", ";
                }
                if (new Integer(types.get(champs.length - 1).toString()).intValue() != DataBaseRecords.typeIcon)
                    sql = sql + champs[champs.length - 1] + ") VALUES (";
                else
                {
                    sql = sql.substring(0, sql.length() - 2).concat(") VALUES (");
                }

                for (int i=1; i<champs.length - 1; i++)
                {
                    String sValue = processNull(value[i]);
                    if (new Integer(types.get(i).toString()).intValue() == DataBaseRecords.typeString)
                        sValue = MainClass.replaceQuotes(sValue);
                    
                    
                    int val2 = new Integer(types.get(i).toString()).intValue();
                    if (val2 == DataBaseRecords.typeString || val2 == DataBaseRecords.typeDate)
                        sql = sql + "'" + sValue + "', ";
                    else if (val2 == DataBaseRecords.typeNumber || val2 == DataBaseRecords.typeBool)
                        sql = sql + sValue + ", ";
                    else if (val2 == DataBaseRecords.typeIcon)
                    {
                        //ImageIcon imgIcon = (ImageIcon) value[i];
                        ImageIcon imgIcon = table.getPicture();
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                        pictureFieldName = champs[i];
                    }
                }
                int j = champs.length - 1;
                String sValue = processNull(value[j]);
                if (new Integer(types.get(j).toString()).intValue() == DataBaseRecords.typeString)
                    sValue = MainClass.replaceQuotes(sValue);
                int val2 = new Integer(types.get(j).toString()).intValue();
                if (val2 == DataBaseRecords.typeString || val2 == DataBaseRecords.typeDate)
                    sql = sql + "'" + sValue + "')";
                else if (val2 == DataBaseRecords.typeNumber || val2 == DataBaseRecords.typeBool)
                    sql = sql + sValue + ")";
                else if (val2 == DataBaseRecords.typeIcon)
                {
                    //ImageIcon imgIcon = (ImageIcon) value[j];
                    sql = sql.substring(0, sql.length() - 2).concat(")");
                    ImageIcon imgIcon = table.getPicture();
                    blob = BlobIconConvert.icon2Blob(imgIcon);
                    pictureFieldName = champs[j];
                }

                //null case
                sql = sql.replace("'null'", "null");

                //execute the query
                statement.executeUpdate(sql);

                //close the statement
                statement.close();

                //get the id of the new row
                /*String newID = getNewId();
                id = newID;
                table.setId(newID);

                //get the corresponding record number and the number of records
                int row = findRow();
                table.setRow(row);
                table.setRowNB(table.getRowNB() + 1);*/
                //get the id of the new row
                String newID = gNewId(tableName);
                id = newID;
                table.setId(newID);

                //get the corresponding record number and the number of records
                int row;
                
                if (sqlPartialWhere == null)
                {
                    row = fRow(tableName, id, sqlOrderBy, sqlFrom);
                }
                else
                {
                    row = fRow(tableName, id, sqlOrderBy, sqlFrom, sqlPartialWhere);
                }

                table.setRow(row);
                table.setRowNB(table.getRowNB() + 1);
                table.setAdding(false);
            }

            //create update statement
            else
            {
                statement = dataBase.createStatement();

                //get the values
                for (int i=0; i<champs.length; i++)
                {
                    value[i] = valeurs.get(i);
                }

                sql = "";

                //we don't update the id field (for i=0)
                for (int i=0; i<champs.length; i++)
                {
                    //we don't update the values that are not modified
                    if (initVal== null || initVal[i] == null || initVal[i].equals(value[i]) || (value[i]!= null && value[i].equals("null") && initVal[i].equals("")))
                        value[i] = "";

                    //modified values
                    else
                    {
                        int val = new Integer(types.get(i).toString()).intValue();

                        //string or date type
                        if (val == DataBaseRecords.typeString || val == DataBaseRecords.typeDate)
                        {
                            if (new Integer(types.get(i).toString()).intValue() == DataBaseRecords.typeString)
                                value[i] = MainClass.replaceQuotes(null2String(value[i]));
                            value[i] = " " + champs[i] + "='" + value[i] + "'";
                        }

                        //numeric type
                        else if (val == DataBaseRecords.typeNumber || val == DataBaseRecords.typeBool)
                            value[i] = " " + champs[i] + "=" + value[i];

                        else if (val == DataBaseRecords.typeIcon)
                        {
                            ImageIcon imgIcon = table.getPicture();
                            if (imgIcon != null)
                            {
                                File file = BlobIconConvert.image2File(imgIcon);
                                if (file != null)
                                {
                                    imgIcon = new ImageIcon(file.getAbsolutePath());
                                    blob = BlobIconConvert.icon2Blob(imgIcon);
                                }
                            }
                            pictureFieldName = champs[i];
                            if (blob == null)
                            {
                                statement.executeUpdate("UPDATE " + tableName + " SET " + champs[i] + "=null where id=" + table.getId());
                            }
                            value[i] = null;//to avoid keeping this in the normal update query (that must not contain blobs)
                            //the blob from picture is treated separately at the end of the function
                        }

                        //separate the fields
                        if (!sql.equals("") && val != DataBaseRecords.typeIcon)
                            value[i] = "," + value[i];
                    }
                    if (value[i]!= null)// && !value[i].equals("null"))
                        sql = sql + value[i];
                }
                sql = sql.trim();
                
                if (!sql.equals(""))
                {
                    sql = "UPDATE " + tableName + " SET " + sql + " WHERE ID=" + table.getId();

                    //null case
                    sql = sql.replace("'null'", "null");

                    //execute the query
                    statement.executeUpdate(sql);

                    //close the statement
                    statement.close();
                }
            }


            if (blob != null)
            {
                statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

                if (statement != null)
                {
                    ResultSet rs = statement.executeQuery("select id, " + pictureFieldName + " FROM " + tableName + " where id=" + table.getId());

                    if (rs != null)
                    {
                        if (rs.next())
                        {
                            rs.updateBlob("Picture", blob);
                            rs.updateRow();
                            rs.close();
                            statement.close();
                        }
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    //get the last id
    protected String gNewId(String tableName)
    {
        String strID = "0";
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT MAX(ID) FROM " + tableName);
            while (rs.next())
            {
                strID = String.valueOf(rs.getInt(1));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return strID;
    }

    //get the row having the current id
    protected int fRow(String tableName, String strID, String sqlOrderBy, String sqlFrom, String sqlPartialWhere)
    {
        int row = 0;

        try
        {
            boolean bFound = false;

            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            if (!sqlFrom.startsWith("FROM") && !sqlFrom.startsWith(" FROM"))
                sqlFrom = "FROM " + sqlFrom;
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            if (!tableName.contains("."))
                rs = statement.executeQuery("SELECT " + tableName.concat(".") + "ID " + sqlFrom + sqlPartialWhere + sqlOrderBy);
            else
                rs = statement.executeQuery("SELECT ID " + sqlFrom + sqlPartialWhere + sqlOrderBy);
            while (rs.next())
            {
                row += 1;
                String strId = rs.getString(1);
                if (strId.equals(strID))
                {
                    bFound = true;
                    break;
                }
            }
            if (bFound == false) row = 0;
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
           MainClass.setMessage(ex.getMessage());
        }
        return row;
    }
    
    protected int fRow(String tableName, String strID, String sqlOrderBy, String sqlFrom)
    {
        int row = 0;

        try
        {
            boolean bFound = false;

            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            if (!sqlFrom.startsWith("FROM") && !sqlFrom.startsWith(" FROM"))
                sqlFrom = "FROM " + sqlFrom;
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            if (!tableName.contains("."))
                rs = statement.executeQuery("SELECT " + tableName.concat(".") + "ID " + sqlFrom + sqlOrderBy);
            else
                rs = statement.executeQuery("SELECT ID " + sqlFrom + sqlOrderBy);
            while (rs.next())
            {
                row += 1;
                String strId = rs.getString(1);
                if (strId.equals(strID))
                {
                    bFound = true;
                    break;
                }
            }
            if (bFound == false) row = 0;
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
           MainClass.setMessage(ex.getMessage());
        }
        return row;
    }

    //get the number of rows
    protected int fRowNB(String tableName, String sqlFrom)
    {
        int r = 0;

        try
        {
            if (sqlFrom == null)
            {
                sqlFrom = tableName;
            }
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            if (!sqlFrom.startsWith("FROM") && !sqlFrom.startsWith(" FROM"))
                sqlFrom = "FROM " + sqlFrom;
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            if (!tableName.contains("."))
                rs = statement.executeQuery("SELECT Count(" + tableName + ".ID) " + sqlFrom);
            else
                rs = statement.executeQuery("SELECT Count(ID) " + sqlFrom);
            while (rs.next())
            {
                r = rs.getInt(1);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
           MainClass.setMessage(ex.getMessage());
        }
        return r;
    }
    
    protected int fRowNB(String tableName, String sqlFrom, String sqlPartialWhere)
    {
        int r = 0;

        try
        {
            if (sqlFrom == null)
            {
                sqlFrom = tableName;
            }
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            if (!sqlFrom.startsWith("FROM") && !sqlFrom.startsWith(" FROM"))
                sqlFrom = "FROM " + sqlFrom;
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            if (!tableName.contains("."))
                rs = statement.executeQuery("SELECT Count(" + tableName + ".ID) " + sqlFrom + sqlPartialWhere);
            else
                rs = statement.executeQuery("SELECT Count(ID) " + sqlFrom + sqlPartialWhere);
            while (rs.next())
            {
                r = rs.getInt(1);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
           MainClass.setMessage(ex.getMessage());
        }
        return r;
    }

    private String removeNull(String field)
    {
        if (field == null)
            return "";
        else
            return field;
    }
    
    protected void rRecord(String tableName, String id)
    {
        MainClass.starLoginManager.removeRecord(id, tableName);
    }
}



