package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Stars;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseStars extends DataBaseRecords
{
    /** Creates new DataBaseStars */
    public DataBaseStars(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public Stars getStars()
    {
        Stars stars = new Stars();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, HR, StarName, Identite, RA, D, ProperMotionRA, ProperMotionD, Magnitude, RadialVelocity, Distance, DistError, Light, Comments, Picture FROM Stars ORDER BY ID");
            ArrayList rows = stars.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();
            
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = stars.getHeaders();
        ArrayList fields = stars.getFields();
        ArrayList fieldsVal = stars.fieldsValues();
        
        columnNames.add(0, "_0");
        columnNames.add(1, "HR");
        columnNames.add(2, bundle.getString("StarName"));
        columnNames.add(3, bundle.getString("Identity"));
        columnNames.add(4, bundle.getString("RA"));
        columnNames.add(5, bundle.getString("D"));
        columnNames.add(6, bundle.getString("ProperMotionRA"));
        columnNames.add(7, bundle.getString("ProperMotionD"));
        columnNames.add(8, bundle.getString("Magnitude"));
        columnNames.add(9, bundle.getString("RadialVelocity"));
        columnNames.add(10, bundle.getString("Distance"));
        columnNames.add(11, bundle.getString("DistError"));
        columnNames.add(12, bundle.getString("Light"));
        columnNames.add(13, bundle.getString("Comments"));
        columnNames.add(14, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "HR");
        fields.add(2, "StarName");
        fields.add(3, "Identite");
        fields.add(4, "RA");
        fields.add(5, "D");
        fields.add(6, "ProperMotionRA");
        fields.add(7, "ProperMotionD");
        fields.add(8, "Magnitude");
        fields.add(9, "RadialVelocity");
        fields.add(10, "Distance");
        fields.add(11, "DistError");
        fields.add(12, "Light");
        fields.add(13, "Comments");
        fields.add(14, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe(""));
        fieldsVal.add(2, getListe("SELECT DISTINCT StarName FROM Stars WHERE StarName is not null AND StarName!='' ORDER BY StarName"));
        fieldsVal.add(3, getListe("SELECT Identite FROM Stars ORDER BY ID"));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        fieldsVal.add(9, getListe(""));
        fieldsVal.add(10, getListe(""));
        fieldsVal.add(11, getListe(""));
        fieldsVal.add(12, getListe(""));
        fieldsVal.add(13, getListe(""));
        fieldsVal.add(14, getListe(""));
        
        return stars;
    }
}
