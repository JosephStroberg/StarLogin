package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.FLatitude;
import StarLogin.Systeme.AstroCalc.FLongitude;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Event;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseEvent extends DataBaseRecord
{
    private String id;
    private String filter;
    
    /** Creates new DataBaseEvent */
    public DataBaseEvent(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "events";
    }
    
    public Event getEvent(String eventID, String filter)
    {
        Event event = new Event();
        event.setId(eventID);
        if (filter == null)
            filter = "";
        this.filter = filter;
        this.id = eventID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Surname, OtherNames, EntityType, EventType, UTDate, LocalDate, UTTime, Local_Time, TimeLag, PlaceName, PlaceLatitude, PlaceLongitude, Comments, Sign, Ascendant, Picture FROM Events WHERE ID=" + eventID + filter);
            while (rs.next())
            {
                event.setSurname(rs.getString(1));
                event.setOtherNames(rs.getString(2));
                event.setEntityType(rs.getString(3));
                event.setEventName(rs.getString(4));
                
                String sData = rs.getString(5);
                sData = MainClass.getFormatedDate(sData);
                event.setUtDate(sData);
                
                sData = rs.getString(6);
                sData = MainClass.getFormatedDate(sData);
                event.setLocalDate(sData);
                
                sData = rs.getString(7);
                sData = MainClass.getFormatedTime(sData);
                event.setUtTime(sData);
                
                sData = rs.getString(8);
                sData = MainClass.getFormatedTime(sData);
                event.setLocalTime(sData);
                
                event.setTimeLag(rs.getString(9));
                event.setPlace(rs.getString(10));
                
                sData = rs.getString(11);
                FLatitude flat = new FLatitude(sData);
                sData = flat.getLatitude();
                event.setLatitude(sData);
                
                sData = rs.getString(12);
                FLongitude flong = new FLongitude(sData);
                sData = flong.getLongitude();
                event.setLongitude(sData);
                
                event.setComments(rs.getString(13));
                event.setSign(rs.getString(14));
                event.setAscendant(rs.getString(15));
                Blob blob = rs.getBlob(16);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                event.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        event.setRow(findRow(eventID));
        event.setRowNB(findRowNB());
        return event;
        
    }
    
    public Event getEventFromNames(String surname, String otherNames, String eventType)
    {
        Event event = new Event();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Surname, OtherNames, EntityType, EventType, UTDate, LocalDate, UTTime, Local_Time, TimeLag, PlaceName, PlaceLatitude, PlaceLongitude, Comments, Sign, Ascendant, Picture, ID FROM Events WHERE Surname='" + MainClass.replaceQuotes(surname) + "' AND OtherNames='" + MainClass.replaceQuotes(otherNames) + "' AND EventType='" + MainClass.replaceQuotes(eventType) + "'");
            while (rs.next())
            {
                event.setSurname(rs.getString(1));
                event.setOtherNames(rs.getString(2));
                event.setEntityType(rs.getString(3));
                event.setEventName(rs.getString(4));
                event.setUtDate(rs.getString(5));
                event.setLocalDate(rs.getString(6));
                event.setUtTime(rs.getString(7));
                event.setLocalTime(rs.getString(8));
                event.setTimeLag(rs.getString(9));
                event.setPlace(rs.getString(10));
                event.setLatitude(rs.getString(11));
                event.setLongitude(rs.getString(12));
                event.setComments(rs.getString(13));
                event.setSign(rs.getString(14));
                event.setAscendant(rs.getString(15));
                Blob blob = rs.getBlob(16);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                event.setPicture(icon);
                event.setId(rs.getString(17));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        event.setRow(findRow(event.getId()));
        event.setRowNB(findRowNB());
        return event;
        
    }
    
    public void setEvent(Event event)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sSurname = SQLString.processNull(event.getSurname());
            String sOtherNames = SQLString.processNull(event.getOtherNames());
            String sEntityType = SQLString.processNull(event.getEntityType());
            String sEvent = SQLString.processNull(event.getEventName());
            String sLocalDate = SQLString.processNull(event.getLocalDate());
            String sUtDate = SQLString.processNull(event.getUtDate());
            String sLocalTime = SQLString.processNull(event.getLocalTime());
            String sUtTime = SQLString.processNull(event.getUtTime());
            String sTimeLag = SQLString.processNull(event.getTimeLag());
            String sPlace = SQLString.processNull(event.getPlace());
            String sLatitude = SQLString.processNull(event.getLatitude());
            String sLongitude = SQLString.processNull(event.getLongitude());
            String sComments = SQLString.processNull(event.getComments());
            String sSign = SQLString.processNull(event.getSign());
            /*if (sSign.length()<10)
            {
                String emptyString = "          ";
                sSign = sSign.concat(emptyString.substring(sSign.length()));
            }*/
            String sAscendant = SQLString.processNull(event.getAscendant());
            ImageIcon imgIcon = event.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(sPicture);
            if (event.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }
            sUtDate = FDate.fr2us(sUtDate);
            sLocalDate = FDate.fr2us(sLocalDate);
            sUtTime = FTime.set24(sUtTime);
            sLocalTime = FTime.set24(sLocalTime);
            
            if (event.getAdding()==true)
            {
                query = "INSERT INTO Events (Surname, OtherNames, EntityType, EventType, UTDate, LocalDate, UTTime, Local_Time, TimeLag, PlaceName, PlaceLatitude, PlaceLongitude, Comments, Sign, Ascendant) VALUES ("
                + "'" + MainClass.replaceQuotes(sSurname) + "', '" + MainClass.replaceQuotes(sOtherNames) + "', '" + MainClass.replaceQuotes(sEntityType) + "', '" + MainClass.replaceQuotes(sEvent) + "', '" + MainClass.replaceQuotes(sUtDate) + "', '" + MainClass.replaceQuotes(sLocalDate) + "', '" + MainClass.replaceQuotes(sUtTime) + "', '" + MainClass.replaceQuotes(sLocalTime) + "', '" + MainClass.replaceQuotes(sTimeLag) + "', '" + MainClass.replaceQuotes(sPlace) + "', '" + MainClass.replaceQuotes(sLatitude) + "', '" + MainClass.replaceQuotes(sLongitude) + "', '" + MainClass.replaceQuotes(sComments) + "', '" + MainClass.replaceQuotes(sSign) + "', '" + MainClass.replaceQuotes(sAscendant) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                event.setId(newID);

                id = newID;
                int row = findRow(newID);
                event.setRow(row);
                event.setRowNB(event.getRowNB() + 1);
                event.setAdding(false);
            }
            else
            {
                query = "UPDATE Events SET Surname='" + MainClass.replaceQuotes(sSurname)+ "', OtherNames='" + MainClass.replaceQuotes(sOtherNames)+ "', EntityType='" + MainClass.replaceQuotes(sEntityType)+ "', EventType='" + MainClass.replaceQuotes(sEvent)+ "', UTDate='" + MainClass.replaceQuotes(sUtDate)+ "', LocalDate='" + MainClass.replaceQuotes(sLocalDate)+ "', UTTime='" + MainClass.replaceQuotes(sUtTime)+ "', Local_Time='" + MainClass.replaceQuotes(sLocalTime)+ "', TimeLag='" + MainClass.replaceQuotes(sTimeLag)+ "', PlaceName='" + MainClass.replaceQuotes(sPlace)+ "', PlaceLatitude='" + MainClass.replaceQuotes(sLatitude)+ "', PlaceLongitude='" + MainClass.replaceQuotes(sLongitude)+ "', Comments='" + MainClass.replaceQuotes(sComments)+ "', Sign='" + MainClass.replaceQuotes(sSign)+ "', Ascendant='" + MainClass.replaceQuotes(sAscendant)+ "' WHERE ID=" + event.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (blob == null)
                {
                    statement.executeUpdate("UPDATE Events SET picture=null where id=" + event.getId());
                }
            }
            
            
            statement.close();
            
            //MainClass.testPlace(sPlace, sLatitude, sLongitude, null);
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);
            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM events where id=" + event.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Event event)
    {
        rRecord("events", id);
        event.setRowNB(event.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("events");
    }

    private int findRow(String id)
    {
        return fRow("events", id, " ORDER BY Surname, OtherNames, EventType", "events", " WHERE ID>0 " + filter);
    }

    private int findRowNB()
    {
        return fRowNB("events", "events", " WHERE ID>0 " + filter);
    }
}