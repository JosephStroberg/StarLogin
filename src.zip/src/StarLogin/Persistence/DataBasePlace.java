package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Place;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePlace extends DataBaseRecord
{
    private String id;
    
    /** Creates new DataBasePlace */
    public DataBasePlace(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "Places";
    }

    public Place getPlace(String placeID)
    {
        Place place = new Place();
        place.setId(placeID);
        this.id = placeID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT PlaceName, PlaceLatitude, PlaceLongitude, Comments, Picture FROM Places WHERE ID=" + placeID);
            while (rs.next())
            {
                place.setPlaceName(rs.getString(1));
                place.setPlaceLatitude(rs.getString(2));
                place.setPlaceLongitude(rs.getString(3));
                place.setComments(rs.getString(4));
                Blob blob = rs.getBlob(5);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                place.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        place.setRow(findRow());
        place.setRowNB(findRowNB());
        return place;
        
    }
    
    public void setPlace(Place place)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sPlaceName = place.getPlaceName();
            String sPlaceLatitude = place.getPlaceLatitude();
            String sPlaceLongitude = place.getPlaceLongitude();
            String sComments = SQLString.processNull(place.getComments());
            ImageIcon imgIcon = place.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(imgIcon);
            if (place.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }
            if (place.getAdding()==true)
            {
                query = "INSERT INTO Places (PlaceName, PlaceLatitude, PlaceLongitude, Comments) VALUES ('" + MainClass.replaceQuotes(sPlaceName) + "', '" + MainClass.replaceQuotes(sPlaceLatitude) + "', '" + MainClass.replaceQuotes(sPlaceLongitude) + "', '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                place.setId(newID);

                id = newID;
                int row = findRow();
                place.setRow(row);
                place.setRowNB(place.getRowNB() + 1);
                place.setAdding(false);
            }
            else
            {
                query = "UPDATE Places SET PlaceName='" + MainClass.replaceQuotes(sPlaceName) + "', PlaceLatitude='" + MainClass.replaceQuotes(sPlaceLatitude) + "', PlaceLongitude='" + MainClass.replaceQuotes(sPlaceLongitude) + "', Comments='" + MainClass.replaceQuotes(sComments) + "'WHERE ID=" + place.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (imgIcon == null)
                {
                    statement.executeUpdate("UPDATE Places SET picture=null where id=" + place.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM place where id=" + place.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Place place)
    {
        rRecord("places", id);
        place.setRowNB(place.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("places");
    }

    private int findRow()
    {
        return fRow("places", id, " ORDER BY PlaceName", "places");
    }

    private int findRowNB()
    {
        return fRowNB("places", "places");
    }
}

