package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Chart;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseChart extends DataBaseRecord
{
    private String id;
    
    /** Creates new DataBaseChart */
    public DataBaseChart(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "chart";
    }
    
    public Chart getChart(String chartID)
    {
        Chart chart = new Chart();
        chart.setId(chartID);
        this.id = chartID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT EventID, ChartType, CoordinatesSystem, HousesSystem, OtherPointType, OtherPointName, Header, Title, Configurations, Comments, Picture FROM chart WHERE ID=" + chartID);
            while (rs.next())
            {
                chart.setEventID(rs.getInt(1));
                chart.setChartType(rs.getByte(2));
                chart.setCoordinatesSystem(rs.getByte(3));
                chart.setHousesSystem(rs.getByte(4));
                chart.setOtherPointType(rs.getByte(5));
                chart.setOtherPointName(rs.getString(6));
                chart.setHeader(rs.getString(7));
                chart.setTitle(rs.getString(8));
                chart.setConfigurations(rs.getString(9));
                chart.setComments(rs.getString(10));
                Blob blob = rs.getBlob(11);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                chart.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        chart.setRow(findRow());
        chart.setRowNB(findRowNB());
        return chart;
        
    }
    
    public void setChart(Chart chart)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            int eventID = chart.getEventID();
            byte chartType = chart.getChartType();
            byte coordinatesSystem = chart.getCoordinatesSystem();
            byte housesSystem = chart.getHousesSystem();
            byte otherPointType = chart.getOtherPointType();
            String sOtherPointName = SQLString.processNull(chart.getOtherPointName());
            String sHeader = SQLString.processNull(chart.getHeader());
            String sTitle = SQLString.processNull(chart.getTitle());
            String sConfigurations = SQLString.processNull(chart.getConfigurations());
            String sComments = SQLString.processNull(chart.getComments());
            ImageIcon imgIcon = chart.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(imgIcon);
            if (chart.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }
            if (chart.getAdding()==true)
            {
                query = "INSERT INTO Chart (EventID, ChartType, CoordinatesSystem, HousesSystem, OtherPointType, OtherPointName, Header, Title, Configurations, Comments) VALUES ("
                + eventID + ", "
                + chartType + ", "
                + coordinatesSystem + ", "
                + housesSystem + ", "
                + otherPointType + ", '" + MainClass.replaceQuotes(sOtherPointName) + "', '" + MainClass.replaceQuotes(sHeader) + "', '" + MainClass.replaceQuotes(sTitle) + "', '" + MainClass.replaceQuotes(sConfigurations) + "', '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                chart.setId(newID);

                id = newID;
                int row = findRow();
                chart.setRow(row);
                chart.setRowNB(chart.getRowNB() + 1);
                chart.setAdding(false);
            }
            else
            {
                query = "UPDATE Chart SET EventID=" + eventID
                + ", ChartType=" + chartType
                + ", CoordinatesSystem=" + coordinatesSystem
                + ", HousesSystem=" + housesSystem
                + ", OtherPointType=" + otherPointType
                + ", OtherPointName='" + MainClass.replaceQuotes(sOtherPointName)+ "', Header='" + MainClass.replaceQuotes(sHeader)+ "', Title='" + MainClass.replaceQuotes(sTitle)+ "', Configurations='" + MainClass.replaceQuotes(sConfigurations)+ "', Comments='" + MainClass.replaceQuotes(sComments)+ "' WHERE ID=" + chart.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (imgIcon == null)
                {
                    statement.executeUpdate("UPDATE Chart SET picture=null where id=" + chart.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM asteroid where id=" + chart.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Chart chart)
    {
        rRecord("chart", id);
        chart.setRowNB(chart.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("chart");
    }

    private int findRow()
    {
        return fRow("chart", id, "", "chart");
    }

    private int findRowNB()
    {
        return fRowNB("chart", "chart");
    }
}
