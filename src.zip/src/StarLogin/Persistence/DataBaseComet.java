package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Comet;
import java.io.File;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseComet extends DataBaseRecord  {

    private String id;
    private String filter;
    
    /** Creates new DataBaseComet */
    public DataBaseComet(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "comets";
    }

    public Comet getComet(String cometID, String filter)
    {
        Comet comet = new Comet();
        comet.setId(cometID);
        if (filter == null)
            filter = "";
        this.filter = filter;
        this.id = cometID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Comet, PerihelionDate, PerihelionUA, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, Period, Epoch, Comments, Picture FROM Comets WHERE ID=" + cometID);
            while (rs.next())
            {
                comet.setCometName(rs.getString(1));
                comet.setPerihelionDate(rs.getString(2));
                comet.setPerihelionUA(rs.getDouble(3));
                comet.setEccentricity(rs.getDouble(4));
                comet.setPerihelionLongitude(rs.getDouble(5));
                comet.setNorthNodeLongitude(rs.getDouble(6));
                comet.setInclination(rs.getDouble(7));
                comet.setSemiMajorAxis(rs.getDouble(8));
                comet.setPeriod(rs.getDouble(9));
                comet.setEpoch(rs.getDouble(10));
                comet.setComments(rs.getString(11));
                Blob blob = rs.getBlob(12);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                comet.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        comet.setRow(findRow(cometID));
        comet.setRowNB(findRowNB());
        return comet;
        
    }
    
    public void setComet(Comet comet)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String sCometName = comet.getCometName();
            String perihelionDate = comet.getPerihelionDate();
            double perihelionUA = comet.getPerihelionUA();
            double eccentricity = comet.getEccentricity();
            double perihelionLongitude = comet.getPerihelionLongitude();
            double northNodeLongitude = comet.getNorthNodeLongitude();
            double inclination = comet.getInclination();
            double semiMajorAxis = comet.getSemiMajorAxis();
            double period = comet.getPeriod();
            double epoch = comet.getEpoch();
            String sComments = SQLString.processNull(comet.getComments());
            ImageIcon imgIcon = comet.getPicture();
            Blob blob = null;// = BlobIconConv.icon2Blob(imgIcon);
            if (comet.getAdding()==true)
            {
                blob = BlobIconConvert.icon2Blob(imgIcon);
                //pictureFieldName = champs[i];
            }
            else
            {
                if (imgIcon != null)
                {
                    File file = BlobIconConvert.image2File(imgIcon);
                    if (file != null)
                    {
                        imgIcon = new ImageIcon(file.getAbsolutePath());
                        blob = BlobIconConvert.icon2Blob(imgIcon);
                    }
                } 
            }            
            if (comet.getAdding()==true)
            {
                query = "INSERT INTO Comets (Comet, PerihelionDate, PerihelionUA, Eccentricity, PerihelionLongitude, NorthNodeLongitude, Inclination, SemiMajorAxis, Period, Epoch, Comments) VALUES ("
                + "'" + MainClass.replaceQuotes(sCometName) + "', '" + perihelionDate + "', " + perihelionUA + ", " + eccentricity + ", " + perihelionLongitude + ", " + northNodeLongitude + ", " + inclination + ", " + semiMajorAxis + ", " + period + ", " + epoch + ", '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                comet.setId(newID);

                id = newID;
                int row = findRow(newID);
                comet.setRow(row);
                comet.setRowNB(comet.getRowNB() + 1);
                comet.setAdding(false);
            }
            else
            {
                query = "UPDATE Comets SET Comet='" + MainClass.replaceQuotes(sCometName)+ "', PerihelionDate='" + perihelionDate
                + "', PerihelionUA=" + perihelionUA
                + ", Eccentricity=" + eccentricity
                + ", PerihelionLongitude=" + perihelionLongitude
                + ", NorthNodeLongitude=" + northNodeLongitude
                + ", Inclination=" + inclination
                + ", SemiMajorAxis=" + semiMajorAxis
                + ", Period=" + period
                + ", Epoch=" + epoch
                + ", Comments='" + MainClass.replaceQuotes(sComments)+ "' WHERE ID=" + comet.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (imgIcon == null)
                {
                    statement.executeUpdate("UPDATE Comets SET picture=null where id=" + comet.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM comets where id=" + comet.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Comet comet)
    {
        rRecord("comets", id);
        comet.setRowNB(comet.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("comets");
    }

    private int findRow(String id)
    {
        return fRow("comets", id, " ORDER BY Comet", "comets", " WHERE ID>0 " + filter);
    }

    private int findRowNB()
    {
        return fRowNB("comets", "comets", " WHERE ID>0 " + filter);
    }
}
