package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Services;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseServices extends DataBaseRecords
{
    //DataBaseConnection dataBase;
    
    /** Creates new DataBaseServices */
    public DataBaseServices(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Services getServices()
    {
        Services services = new Services();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, ServiceName, ServiceType, AverageDuration, AstrologicalTechniques, OtherTechniques, Rate, Repetitiveness, Comments FROM Services ORDER BY ServiceName");
            ArrayList rows = services.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = services.getHeaders();
        ArrayList fields = services.getFields();
        ArrayList fieldsVal = services.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("ServiceName"));
        columnNames.add(2, bundle.getString("ServiceType"));
        columnNames.add(3, bundle.getString("AverageDuration"));
        columnNames.add(4, bundle.getString("AstrologicalTechniques"));
        columnNames.add(5, bundle.getString("OtherTechniques"));
        columnNames.add(6, bundle.getString("Rate"));
        columnNames.add(7, bundle.getString("Repetitiveness"));
        columnNames.add(8, bundle.getString("Comments"));
        //columnNames.add(9, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "ServiceName");
        fields.add(2, "ServiceType");
        fields.add(3, "AverageDuration");
        fields.add(4, "AstrologicalTechniques");
        fields.add(5, "OtherTechniques");
        fields.add(6, "Rate");
        fields.add(7, "Repetitiveness");
        fields.add(8, "Comments");
        //fields.add(9, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe(""));
        fieldsVal.add(2, getListe("SELECT ServiceName FROM Services Where ServiceName is not null AND ServiceName!='' ORDER BY ServiceName"));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        fieldsVal.add(6, getListe(""));
        fieldsVal.add(7, getListe(""));
        fieldsVal.add(8, getListe(""));
        //fieldsVal.add(9, getListe(""));
        
        return services;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
