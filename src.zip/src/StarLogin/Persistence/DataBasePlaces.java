package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Places;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePlaces extends DataBaseRecords
{
    /** Creates new DataBasePlaces */
    public DataBasePlaces(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Places getPlaces()
    {
        Places places = new Places();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("select ID, PlaceName, PlaceLatitude, PlaceLongitude, Comments, Picture FROM Places ORDER BY PlaceName");
            ArrayList rows = places.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = places.getHeaders();
        ArrayList fields = places.getFields();
        ArrayList fieldsVal = places.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("Place"));
        columnNames.add(2, bundle.getString("Latitude"));
        columnNames.add(3, bundle.getString("Longitude"));
        columnNames.add(4, bundle.getString("Comments"));
        columnNames.add(5, bundle.getString("Picture"));
        fields.add(0, "ID");
        fields.add(1, "PlaceName");
        fields.add(2, "PlaceLatitude");
        fields.add(3, "PlaceLongitude");
        fields.add(4, "Comments");
        fields.add(5, "Picture");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT PlaceName FROM Places WHERE PlaceName is not null AND PlaceName!='' ORDER BY PlaceName"));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe(""));
        fieldsVal.add(4, getListe(""));
        fieldsVal.add(5, getListe(""));
        
        return places;
    }
    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
