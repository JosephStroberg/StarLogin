package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.PlanetInSign;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBasePlanetInSign extends DataBaseRecord  {

    /** Creates new DataBasePlanetInSign */
    public DataBasePlanetInSign(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "PlanetInSign";
    }

    public PlanetInSign getPlanetInSign(byte planetID, byte signID)
    {
        PlanetInSign planetInSign = new PlanetInSign();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM PlanetInSign WHERE ID=" + planetID + " AND S_I=" + signID);
            while (rs.next())
            {
                planetInSign.setMeaning(rs.getString(1));
                planetInSign.setValue(rs.getDouble(2));
            }
            planetInSign.setPlanetID(planetID);
            planetInSign.setSignID(signID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return planetInSign;
        
    }
}
