package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Relationships;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseRelationships extends DataBaseRecords
{
    /** Creates new DataBaseRelationships */
    public DataBaseRelationships(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    public Relationships getRelationships(byte planet1ID, byte planet2ID)
    {
        Relationships relationships = new Relationships();
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT Meaning, Value FROM Relationships WHERE ID1=" + planet1ID + " AND ID2=" + planet2ID);
            while (rs.next())
            {
                relationships.setMeaning(rs.getString(1));
                relationships.setValue(rs.getDouble(2));
            }
            relationships.setPlanet1ID(planet1ID);
            relationships.setPlanet2ID(planet2ID);
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return relationships;
        
    }
}
