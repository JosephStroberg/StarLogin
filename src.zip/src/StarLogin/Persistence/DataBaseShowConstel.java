package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.ShowConstel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseShowConstel extends DataBaseRecord
{
    /** Creates new DataBaseShowConstel */
    public DataBaseShowConstel(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
        tableName = "ShowConstel";
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public ShowConstel getShowConstel()
    {
        ShowConstel showConstel = new ShowConstel();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, Identite, RA, D, Constellation, Data FROM ShowConstel");
            ArrayList rows = showConstel.getShowConstel();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        return showConstel;
    }
}

