/*
 * DataBaseOptions.java
 *
 * Created on 30 juin 2003, 08:25
 */

package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Options;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseOptions extends DataBaseRecords {

    /** Creates new DataBaseOptions */
    public DataBaseOptions(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Options getOptions()
    {
        Options options = new Options();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ID, ConfigurationName, DefaultConfiguration, DefaultEvent, DefaultPlace FROM OptionsConfiguration ORDER BY ConfigurationName");
            ArrayList rows = options.getRecords();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        ArrayList columnNames = options.getHeaders();
        ArrayList fields = options.getFields();
        ArrayList fieldsVal = options.fieldsValues();
  
        columnNames.add(0, "_0");
        columnNames.add(1, bundle.getString("ConfigurationName"));
        columnNames.add(2, "_2");
        columnNames.add(3, "_3");
        columnNames.add(4, "_4");
        fields.add(0, "ID");
        fields.add(1, "ConfigurationName");
        fields.add(2, "DefaultConfiguration");
        fields.add(3, "DefaultEvent");
        fields.add(4, "DefaultPlace");
        fieldsVal.add(0, getListe(""));
        fieldsVal.add(1, getListe("SELECT ConfigurationName FROM OptionsConfiguration WHERE ConfigurationName is not null AND ConfigurationName!=''"));
        fieldsVal.add(2, getListe(""));
        fieldsVal.add(3, getListe("SELECT Surname || '; ' || OtherNames || '; ' || EventType AS Event FROM Events ORDER BY Surname, OtherNames, EventType"));
        fieldsVal.add(4, getListe("SELECT PlaceName FROM Places ORDER BY PlaceName"));
        
        return options;
    }

    
    /*private DefaultComboBoxModel fieldValues(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
        
        try
        {
            if (!query.equals(""))
            {
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                ArrayList rows = SQLString.processRows(rs);
                for (int i=0;i<rows.size();i++)
                {
                    ArrayList v = (ArrayList)rows.get(i);
                    comboModel.addElement(String.valueOf(v.get(0)));
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return comboModel;
    }*/
}
