package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.BlobIconConv;
import StarLogin.Systeme.Data.Star;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author  Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseStar extends DataBaseRecord 
{
    private String id;
    private String filter;
    
    /** Creates new DataBaseStar */
    public DataBaseStar(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "stars";
    }

    public Star getStar(String starID, String filter)
    {
        Star star = new Star();
        star.setId(starID);
        if (filter == null)
            filter = "";
        this.filter = filter;
        this.id = starID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT HR, StarName, Identite, RA, D, ProperMotionRA, ProperMotionD, Magnitude, RadialVelocity, Distance, DistError, Light, Comments, Picture FROM Stars WHERE ID=" + starID);
            while (rs.next())
            {
                star.setHR(rs.getInt(1));
                star.setStarName(rs.getString(2));
                star.setIdentity(rs.getString(3));
                star.setRA(rs.getDouble(4));
                star.setD(rs.getDouble(5));
                star.setProperMotionRA(rs.getDouble(6));
                star.setProperMotionD(rs.getDouble(7));
                star.setMagnitude(rs.getDouble(8));
                star.setRadialVelocity(rs.getDouble(9));
                star.setDistance(rs.getDouble(10));
                star.setDistError(rs.getDouble(11));
                star.setLight(rs.getString(12));
                star.setComments(rs.getString(13));
                Blob blob = rs.getBlob(14);
                javax.swing.ImageIcon icon = BlobIconConv.blob2Icon(blob);
                star.setPicture(icon);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        star.setRow(findRow(starID));
        star.setRowNB(findRowNB());
        return star;
        
    }
    
    public void setStar(Star star)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            int hr = star.getHR();
            String sStarName = SQLString.processNull(star.getStarName());
            String sIdentity = SQLString.processNull(star.getIdentity());
            double ra = star.getRA();
            double d = star.getD();
            double properMotionRA = star.getProperMotionRA();
            double properMotionD = star.getProperMotionD();
            double magnitude = star.getMagnitude();
            double radialVelocity = star.getRadialVelocity();
            double distance = star.getDistance();
            double distError = star.getDistError();
            String sLight = star.getLight();
            String sComments = SQLString.processNull(star.getComments());
            ImageIcon sPicture = star.getPicture();
            Blob blob = BlobIconConv.icon2Blob(sPicture);
            
            if (star.getAdding()==true)
            {
                query = "INSERT INTO Stars (HR, StarName, Identite, RA, D, ProperMotionRA, ProperMotionD, Magnitude, RadialVelocity, Distance, DistError, Light, Comments) VALUES (" + hr + ", '" + MainClass.replaceQuotes(sStarName) + "', '" + MainClass.replaceQuotes(sIdentity) + "', " + ra + ", " + d + ", " + properMotionRA + ", " + properMotionD + ", " + magnitude + ", " + radialVelocity + ", " + distance + ", " + distError + ", '" + MainClass.replaceQuotes(sLight) + "', '" + MainClass.replaceQuotes(sComments) + "')";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                star.setId(newID);

                id = newID;
                int row = findRow(newID);
                star.setRow(row);
                star.setRowNB(star.getRowNB() + 1);
                star.setAdding(false);
            }
            else
            {
                query = "UPDATE Stars SET HR=" + hr + ", StarName='" + MainClass.replaceQuotes(sStarName) + "', Identite='" + MainClass.replaceQuotes(sIdentity) + "', RA=" + ra + ", D=" + d + ", ProperMotionRA=" + properMotionRA + ", ProperMotionD=" + properMotionD + ", Magnitude=" + magnitude + ", RadialVelocity=" + radialVelocity + ", Distance=" + distance + ", DistError=" + distError + ", Light='" + MainClass.replaceQuotes(sLight) + "', Comments='" + MainClass.replaceQuotes(sComments) + "' WHERE ID=" + star.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                if (sPicture == null)
                {
                    statement.executeUpdate("UPDATE Stars SET picture=null where id=" + star.getId());
                }
            }
            statement.close();
            statement = dataBase.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_UPDATABLE);

            if (statement != null && blob != null)
            {
                ResultSet rs = statement.executeQuery("select id, Picture FROM stars where id=" + star.getId());

                if (rs != null)
                {
                    if (rs.next())
                    {
                        rs.updateBlob("Picture", blob);
                        rs.updateRow();
                        rs.close();
                        statement.close();
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public boolean removeRecord(Star star)
    {
        rRecord("stars", id);
        star.setRowNB(star.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("stars");
    }

    private int findRow(String id)
    {
        return fRow("stars", id, " ORDER BY ID", "stars", " WHERE ID>0 " + filter);
    }

    private int findRowNB()
    {
        return fRowNB("stars", "stars", " WHERE ID>0 " + filter);
    }
}

