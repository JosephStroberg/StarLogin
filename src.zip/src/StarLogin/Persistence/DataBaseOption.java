package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.Data.Option;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseOption extends DataBaseRecord
{
    
    private String id;
    
    /** Creates new DataBaseOption */
    public DataBaseOption(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        tableName = "OptionsConfiguration";
        //setConnection(dataBaseConnection);
    }
    
    public Option getOption(String optionID)
    {
        Option option = new Option();
        checkDefaultConfig(optionID);
        option.setId(optionID);
        this.id = optionID;
        
        try
        {
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery("SELECT ConfigurationName, Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, Gaia, Nodes, Cusps, Asteroids, Vulcan, Various, Fire, Earth, Air, Water, Neutral, Dynamic, Harmonic, ZodiacSize, SignSize, PlanetSize, CharacterSize, DefaultConfiguration, DefaultEvent, DefaultPlace, ShownSun, ShownMoon, ShownMercury, ShownVenus, ShownMars, ShownJupiter, ShownSaturn, ShownUranus, ShownNeptune, ShownPluto, ShownGaia, ShownNorthNode, ShownLilith, ShownEast, ShownZenith, ShownVertex, ShownVulcan, ShownOtherPoint, ShownCeres, ShownPallas, ShownJuno, ShownVesta, ShownChiron, TrueLilith, OtherPointType, OtherPointName, ColoredAspects, CoordSys, HouseSys, HousesCoords, SignsNames, LeftAsct, LimitMag, SymbolAspects, ViewStars, ViewAsteroids, ViewCoordinates, ViewStraightLines, ViewHouses, ViewConstellations, ViewShadedLines, ViewAspects, ViewBarycenter, Horizon, AspectsSun, AspectsMoon, AspectsMercury, AspectsVenus, AspectsMars, AspectsJupiter, AspectsSaturn, AspectsUranus, AspectsNeptune, AspectsPluto, AspectsGaia, AspectsNorthNode, AspectsLilith, AspectsEast, AspectsZenith, AspectsVertex, AspectsVulcan, AspectsOtherPoint, AspectsCeres, AspectsPallas, AspectsJuno, AspectsVesta, AspectsChiron, AspectsAS, AspectsMC, ShownAspect0, ShownAspect1, ShownAspect2, ShownAspect3, ShownAspect4, ShownAspect5, ShownAspect6, ShownAspect7, ShownAspect8, ShownAspect9, ShownAspect10, ShownAspect11, ShownAspect12, ShownAspect13, ShownAspect14, ShownAspect15, ShownAspect16, ShownAspect17, ColorAspect0, ColorAspect1, ColorAspect2, ColorAspect3, ColorAspect4, ColorAspect5, ColorAspect6, ColorAspect7, ColorAspect8, ColorAspect9, ColorAspect10, ColorAspect11, ColorAspect12, ColorAspect13, ColorAspect14, ColorAspect15, ColorAspect16, ColorAspect17, TypeAspect0, TypeAspect1, TypeAspect2, TypeAspect3, TypeAspect4, TypeAspect5, TypeAspect6, TypeAspect7, TypeAspect8, TypeAspect9, TypeAspect10, TypeAspect11, TypeAspect12, TypeAspect13, TypeAspect14, TypeAspect15, TypeAspect16, TypeAspect17, OtherAspectValue, OtherAspectName, OrbLightLight, OrbLightTell, OrbLightOtherInd, OrbLightColl, OrbLightVirtMax, OrbLightVirtMin, OrbTellTell, OrbTellOtherInd, OrbTellColl, OrbTellVirtMax, OrbTellVirtMin, OrbOtherIndOtherInd, OrbOtherIndColl, OrbOtherIndVirtMax, OrbOtherIndVirtMin, OrbCollColl, OrbCollVirtMax, OrbCollVirtMin, OrbVirtMaxVirtMax, OrbVirtMaxVirtMin, OrbVirtMinVirtMin, DivMin, DivConjuntion, DivSextil, DivSquare, DivTrine, DivOpposition, ChartSelectSingle, ChartKinds, ChartDir1Corresp, ChartDir2Corresp, ChartDirSCorresp, ChartDir1Degree, ChartDir2Day, ChartDirSDegree, ChartDir1SpaceKind, ChartDir2SpaceKind, ChartDirSSpaceKind, ChartReturnPrecess, ChartReturnPlaceID, ChartCyclePlaceID, ChartReturnPlanet, ChartCyclePlanet1, ChartCyclePlanet2, ChartCompositeNB, ChartHarmonicNB, BarySingleWeight, ChartCompositeFromAS FROM OptionsConfiguration WHERE ID=" + optionID);
            while (rs.next())
            {
                option.setConfigurationName(rs.getString(1));
                option.setSunColor(new Color(rs.getInt(2)));
                option.setMoonColor(new Color(rs.getInt(3)));
                option.setMercuryColor(new Color(rs.getInt(4)));
                option.setVenusColor(new Color(rs.getInt(5)));
                option.setMarsColor(new Color(rs.getInt(6)));
                option.setJupiterColor(new Color(rs.getInt(7)));
                option.setSaturnColor(new Color(rs.getInt(8)));
                option.setUranusColor(new Color(rs.getInt(9)));
                option.setNeptuneColor(new Color(rs.getInt(10)));
                option.setPlutoColor(new Color(rs.getInt(11)));
                option.setGaiaColor(new Color(rs.getInt(12)));
                option.setNodesColor(new Color(rs.getInt(13)));
                option.setCuspsColor(new Color(rs.getInt(14)));
                option.setAsteroidsColor(new Color(rs.getInt(15)));
                option.setVulcanColor(new Color(rs.getInt(16)));
                option.setVariousColor(new Color(rs.getInt(17)));
                option.setFireColor(new Color(rs.getInt(18)));
                option.setEarthColor(new Color(rs.getInt(19)));
                option.setAirColor(new Color(rs.getInt(20)));
                option.setWaterColor(new Color(rs.getInt(21)));
                option.setNeutralColor(new Color(rs.getInt(22)));
                option.setDynamicColor(new Color(rs.getInt(23)));
                option.setHarmonicColor(new Color(rs.getInt(24)));
                option.setZodiacSize(rs.getInt(25));
                option.setSignSize(rs.getInt(26));
                option.setPlanetSize(rs.getInt(27));
                option.setCharacterSize(rs.getInt(28));
                option.setDefaultConfiguration(rs.getBoolean(29));
                option.setDefaultEvent(String.valueOf(rs.getInt(30)));
                option.setDefaultPlace(String.valueOf(rs.getInt(31)));
                option.setShownSun(rs.getBoolean(32));
                option.setShownMoon(rs.getBoolean(33));
                option.setShownMercury(rs.getBoolean(34));
                option.setShownVenus(rs.getBoolean(35));
                option.setShownMars(rs.getBoolean(36));
                option.setShownJupiter(rs.getBoolean(37));
                option.setShownSaturn(rs.getBoolean(38));
                option.setShownUranus(rs.getBoolean(39));
                option.setShownNeptune(rs.getBoolean(40));
                option.setShownPluto(rs.getBoolean(41));
                option.setShownGaia(rs.getBoolean(42));
                option.setShownNorthNode(rs.getBoolean(43));
                option.setShownLilith(rs.getBoolean(44));
                option.setShownEast(rs.getBoolean(45));
                option.setShownZenith(rs.getBoolean(46));
                option.setShownVertex(rs.getBoolean(47));
                option.setShownVulcan(rs.getBoolean(48));
                option.setShownOtherPoint(rs.getBoolean(49));
                option.setShownCeres(rs.getBoolean(50));
                option.setShownPallas(rs.getBoolean(51));
                option.setShownJuno(rs.getBoolean(52));
                option.setShownVesta(rs.getBoolean(53));
                option.setShownChiron(rs.getBoolean(54));
                option.setTrueLilith(rs.getBoolean(55));
                option.setOtherPointType(rs.getByte(56));
                option.setOtherPointName(rs.getString(57));
                option.setColoredAspects(rs.getBoolean(58));
                option.setCoordSys(rs.getByte(59));
                option.setHouseSys(rs.getByte(60));
                option.setHousesCoords(rs.getBoolean(61));
                option.setSignsNames(rs.getBoolean(62));
                option.setLeftAsct(rs.getBoolean(63));
                option.setLimitMag(rs.getString(64));
                option.setSymbolAspects(rs.getBoolean(65));
                option.setViewStars(rs.getBoolean(66));
                option.setViewAsteroids(rs.getBoolean(67));
                option.setViewCoordinates(rs.getBoolean(68));
                option.setViewStraightLines(rs.getBoolean(69));
                option.setViewHouses(rs.getBoolean(70));
                option.setViewConstellations(rs.getBoolean(71));
                option.setViewShadedLines(rs.getBoolean(72));
                option.setViewAspects(rs.getBoolean(73));
                option.setViewBarycenter(rs.getBoolean(74));
                option.setHorizon(rs.getBoolean(75));
                option.setAspectsSun(rs.getBoolean(76));
                option.setAspectsMoon(rs.getBoolean(77));
                option.setAspectsMercury(rs.getBoolean(78));
                option.setAspectsVenus(rs.getBoolean(79));
                option.setAspectsMars(rs.getBoolean(80));
                option.setAspectsJupiter(rs.getBoolean(81));
                option.setAspectsSaturn(rs.getBoolean(82));
                option.setAspectsUranus(rs.getBoolean(83));
                option.setAspectsNeptune(rs.getBoolean(84));
                option.setAspectsPluto(rs.getBoolean(85));
                option.setAspectsGaia(rs.getBoolean(86));
                option.setAspectsNorthNode(rs.getBoolean(87));
                option.setAspectsLilith(rs.getBoolean(88));
                option.setAspectsEast(rs.getBoolean(89));
                option.setAspectsZenith(rs.getBoolean(90));
                option.setAspectsVertex(rs.getBoolean(91));
                option.setAspectsVulcan(rs.getBoolean(92));
                option.setAspectsOtherPoint(rs.getBoolean(93));
                option.setAspectsCeres(rs.getBoolean(94));
                option.setAspectsPallas(rs.getBoolean(95));
                option.setAspectsJuno(rs.getBoolean(96));
                option.setAspectsVesta(rs.getBoolean(97));
                option.setAspectsChiron(rs.getBoolean(98));
                option.setAspectsAS(rs.getBoolean(99));
                option.setAspectsMC(rs.getBoolean(100));
                option.setShownAspect0(rs.getBoolean(101));
                option.setShownAspect1(rs.getBoolean(102));
                option.setShownAspect2(rs.getBoolean(103));
                option.setShownAspect3(rs.getBoolean(104));
                option.setShownAspect4(rs.getBoolean(105));
                option.setShownAspect5(rs.getBoolean(106));
                option.setShownAspect6(rs.getBoolean(107));
                option.setShownAspect7(rs.getBoolean(108));
                option.setShownAspect8(rs.getBoolean(109));
                option.setShownAspect9(rs.getBoolean(110));
                option.setShownAspect10(rs.getBoolean(111));
                option.setShownAspect11(rs.getBoolean(112));
                option.setShownAspect12(rs.getBoolean(113));
                option.setShownAspect13(rs.getBoolean(114));
                option.setShownAspect14(rs.getBoolean(115));
                option.setShownAspect15(rs.getBoolean(116));
                option.setShownAspect16(rs.getBoolean(117));
                option.setShownAspect17(rs.getBoolean(118));
                option.setColorAspect0(new Color(rs.getInt(119)));
                option.setColorAspect1(new Color(rs.getInt(120)));
                option.setColorAspect2(new Color(rs.getInt(121)));
                option.setColorAspect3(new Color(rs.getInt(122)));
                option.setColorAspect4(new Color(rs.getInt(123)));
                option.setColorAspect5(new Color(rs.getInt(124)));
                option.setColorAspect6(new Color(rs.getInt(125)));
                option.setColorAspect7(new Color(rs.getInt(126)));
                option.setColorAspect8(new Color(rs.getInt(127)));
                option.setColorAspect9(new Color(rs.getInt(128)));
                option.setColorAspect10(new Color(rs.getInt(129)));
                option.setColorAspect11(new Color(rs.getInt(130)));
                option.setColorAspect12(new Color(rs.getInt(131)));
                option.setColorAspect13(new Color(rs.getInt(132)));
                option.setColorAspect14(new Color(rs.getInt(133)));
                option.setColorAspect15(new Color(rs.getInt(134)));
                option.setColorAspect16(new Color(rs.getInt(135)));
                option.setColorAspect17(new Color(rs.getInt(136)));
                option.setTypeAspect0(rs.getString(137));
                option.setTypeAspect1(rs.getString(138));
                option.setTypeAspect2(rs.getString(139));
                option.setTypeAspect3(rs.getString(140));
                option.setTypeAspect4(rs.getString(141));
                option.setTypeAspect5(rs.getString(142));
                option.setTypeAspect6(rs.getString(143));
                option.setTypeAspect7(rs.getString(144));
                option.setTypeAspect9(rs.getString(145));
                option.setTypeAspect9(rs.getString(146));
                option.setTypeAspect10(rs.getString(147));
                option.setTypeAspect11(rs.getString(148));
                option.setTypeAspect12(rs.getString(149));
                option.setTypeAspect13(rs.getString(150));
                option.setTypeAspect14(rs.getString(151));
                option.setTypeAspect15(rs.getString(152));
                option.setTypeAspect16(rs.getString(153));
                option.setTypeAspect17(rs.getString(154));
                option.setOtherAspectValue(rs.getString(155));
                option.setOtherAspectName(rs.getString(156));
                option.setOrbLightLight(rs.getString(157));
                option.setOrbLightTell(rs.getString(158));
                option.setOrbLightOtherInd(rs.getString(159));
                option.setOrbLightColl(rs.getString(160));
                option.setOrbLightVirtMax(rs.getString(161));
                option.setOrbLightVirtMin(rs.getString(162));
                option.setOrbTellTell(rs.getString(163));
                option.setOrbTellOtherInd(rs.getString(164));
                option.setOrbTellColl(rs.getString(165));
                option.setOrbTellVirtMax(rs.getString(166));
                option.setOrbTellVirtMin(rs.getString(167));
                option.setOrbOtherIndOtherInd(rs.getString(168));
                option.setOrbOtherIndColl(rs.getString(169));
                option.setOrbOtherIndVirtMax(rs.getString(170));
                option.setOrbOtherIndVirtMin(rs.getString(171));
                option.setOrbCollColl(rs.getString(172));
                option.setOrbCollVirtMax(rs.getString(173));
                option.setOrbCollVirtMin(rs.getString(174));
                option.setOrbVirtMaxVirtMax(rs.getString(175));
                option.setOrbVirtMaxVirtMin(rs.getString(176));
                option.setOrbVirtMinVirtMin(rs.getString(177));
                option.setDivMin(rs.getString(178));
                option.setDivConjuntion(rs.getString(179));
                option.setDivSextil(rs.getString(180));
                option.setDivSquare(rs.getString(181));
                option.setDivTrine(rs.getString(182));
                option.setDivOpposition(rs.getString(183));
                option.setChartSelectSingle(rs.getBoolean(184));
                option.setChartKinds(rs.getString(185));
                option.setChartDir1Corresp(rs.getString(186));
                option.setChartDir2Corresp(rs.getString(187));
                option.setChartDirSCorresp(rs.getString(188));
                option.setChartDir1Degree(rs.getString(189));
                option.setChartDir2Day(rs.getString(190));
                option.setChartDirSDegree(rs.getString(191));
                option.setChartDir1SpaceKind(new Byte(rs.getByte(192)).toString());
                option.setChartDir2SpaceKind(new Byte(rs.getByte(193)).toString());
                option.setChartDirSSpaceKind(new Byte(rs.getByte(194)).toString());
                option.setChartReturnPrecess(rs.getBoolean(195));
                option.setChartReturnPlaceID(String.valueOf(rs.getInt(196)));
                option.setChartCyclePlaceID(String.valueOf(rs.getInt(197)));
                option.setChartReturnPlanet(new Byte(rs.getByte(198)).toString());
                option.setChartCyclePlanet1(new Byte(rs.getByte(199)).toString());
                option.setChartCyclePlanet2(new Byte(rs.getByte(200)).toString());
                option.setChartCompositeNB(new Byte(rs.getByte(201)).toString());
                option.setChartHarmonicNB(new Byte(rs.getByte(202)).toString());
                option.setSingleWeight(rs.getBoolean(203));
                option.setChartCompositeFromAS(rs.getBoolean(204));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        option.setRow(findRow(optionID));
        option.setRowNB(findRowNB());
        return option;
        
    }
    
    public Option getDefaultOption()
    {
        Option option = new Option();
        checkDefaultConfig();
        
        try
        {
            Statement statement = dataBase.createStatement();
            if (statement == null)
                return null;
            ResultSet rs = statement.executeQuery("SELECT ConfigurationName, Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, Gaia, Nodes, Cusps, Asteroids, Vulcan, Various, Fire, Earth, Air, Water, Neutral, Dynamic, Harmonic, ZodiacSize, SignSize, PlanetSize, CharacterSize, DefaultConfiguration, DefaultEvent, DefaultPlace, ShownSun, ShownMoon, ShownMercury, ShownVenus, ShownMars, ShownJupiter, ShownSaturn, ShownUranus, ShownNeptune, ShownPluto, ShownGaia, ShownNorthNode, ShownLilith, ShownEast, ShownZenith, ShownVertex, ShownVulcan, ShownOtherPoint, ShownCeres, ShownPallas, ShownJuno, ShownVesta, ShownChiron, TrueLilith, OtherPointType, OtherPointName, ColoredAspects, CoordSys, HouseSys, HousesCoords, SignsNames, LeftAsct, LimitMag, SymbolAspects, ViewStars, ViewAsteroids, ViewCoordinates, ViewStraightLines, ViewHouses, ViewConstellations, ViewShadedLines, ViewAspects, ViewBarycenter, Horizon, AspectsSun, AspectsMoon, AspectsMercury, AspectsVenus, AspectsMars, AspectsJupiter, AspectsSaturn, AspectsUranus, AspectsNeptune, AspectsPluto, AspectsGaia, AspectsNorthNode, AspectsLilith, AspectsEast, AspectsZenith, AspectsVertex, AspectsVulcan, AspectsOtherPoint, AspectsCeres, AspectsPallas, AspectsJuno, AspectsVesta, AspectsChiron, AspectsAS, AspectsMC, ShownAspect0, ShownAspect1, ShownAspect2, ShownAspect3, ShownAspect4, ShownAspect5, ShownAspect6, ShownAspect7, ShownAspect8, ShownAspect9, ShownAspect10, ShownAspect11, ShownAspect12, ShownAspect13, ShownAspect14, ShownAspect15, ShownAspect16, ShownAspect17, ColorAspect0, ColorAspect1, ColorAspect2, ColorAspect3, ColorAspect4, ColorAspect5, ColorAspect6, ColorAspect7, ColorAspect8, ColorAspect9, ColorAspect10, ColorAspect11, ColorAspect12, ColorAspect13, ColorAspect14, ColorAspect15, ColorAspect16, ColorAspect17, TypeAspect0, TypeAspect1, TypeAspect2, TypeAspect3, TypeAspect4, TypeAspect5, TypeAspect6, TypeAspect7, TypeAspect8, TypeAspect9, TypeAspect10, TypeAspect11, TypeAspect12, TypeAspect13, TypeAspect14, TypeAspect15, TypeAspect16, TypeAspect17, OtherAspectValue, OtherAspectName, OrbLightLight, OrbLightTell, OrbLightOtherInd, OrbLightColl, OrbLightVirtMax, OrbLightVirtMin, OrbTellTell, OrbTellOtherInd, OrbTellColl, OrbTellVirtMax, OrbTellVirtMin, OrbOtherIndOtherInd, OrbOtherIndColl, OrbOtherIndVirtMax, OrbOtherIndVirtMin, OrbCollColl, OrbCollVirtMax, OrbCollVirtMin, OrbVirtMaxVirtMax, OrbVirtMaxVirtMin, OrbVirtMinVirtMin, DivMin, DivConjuntion, DivSextil, DivSquare, DivTrine, DivOpposition, ChartSelectSingle, ChartKinds, ChartDir1Corresp, ChartDir2Corresp, ChartDirSCorresp, ChartDir1Degree, ChartDir2Day, ChartDirSDegree, ChartDir1SpaceKind, ChartDir2SpaceKind, ChartDirSSpaceKind, ChartReturnPrecess, ChartReturnPlaceID, ChartCyclePlaceID, ChartReturnPlanet, ChartCyclePlanet1, ChartCyclePlanet2, ChartCompositeNB, ChartHarmonicNB, BarySingleWeight, ChartCompositeFromAS, ID FROM OptionsConfiguration WHERE DefaultConfiguration!=0");
            while (rs.next())
            {
                option.setConfigurationName(rs.getString(1));
                option.setSunColor(new Color(rs.getInt(2)));
                option.setMoonColor(new Color(rs.getInt(3)));
                option.setMercuryColor(new Color(rs.getInt(4)));
                option.setVenusColor(new Color(rs.getInt(5)));
                option.setMarsColor(new Color(rs.getInt(6)));
                option.setJupiterColor(new Color(rs.getInt(7)));
                option.setSaturnColor(new Color(rs.getInt(8)));
                option.setUranusColor(new Color(rs.getInt(9)));
                option.setNeptuneColor(new Color(rs.getInt(10)));
                option.setPlutoColor(new Color(rs.getInt(11)));
                option.setGaiaColor(new Color(rs.getInt(12)));
                option.setNodesColor(new Color(rs.getInt(13)));
                option.setCuspsColor(new Color(rs.getInt(14)));
                option.setAsteroidsColor(new Color(rs.getInt(15)));
                option.setVulcanColor(new Color(rs.getInt(16)));
                option.setVariousColor(new Color(rs.getInt(17)));
                option.setFireColor(new Color(rs.getInt(18)));
                option.setEarthColor(new Color(rs.getInt(19)));
                option.setAirColor(new Color(rs.getInt(20)));
                option.setWaterColor(new Color(rs.getInt(21)));
                option.setNeutralColor(new Color(rs.getInt(22)));
                option.setDynamicColor(new Color(rs.getInt(23)));
                option.setHarmonicColor(new Color(rs.getInt(24)));
                option.setZodiacSize(rs.getInt(25));
                option.setSignSize(rs.getInt(26));
                option.setPlanetSize(rs.getInt(27));
                option.setCharacterSize(rs.getInt(28));
                option.setDefaultConfiguration(rs.getBoolean(29));
                option.setDefaultEvent(String.valueOf(rs.getInt(30)));
                option.setDefaultPlace(String.valueOf(rs.getInt(31)));
                option.setShownSun(rs.getBoolean(32));
                option.setShownMoon(rs.getBoolean(33));
                option.setShownMercury(rs.getBoolean(34));
                option.setShownVenus(rs.getBoolean(35));
                option.setShownMars(rs.getBoolean(36));
                option.setShownJupiter(rs.getBoolean(37));
                option.setShownSaturn(rs.getBoolean(38));
                option.setShownUranus(rs.getBoolean(39));
                option.setShownNeptune(rs.getBoolean(40));
                option.setShownPluto(rs.getBoolean(41));
                option.setShownGaia(rs.getBoolean(42));
                option.setShownNorthNode(rs.getBoolean(43));
                option.setShownLilith(rs.getBoolean(44));
                option.setShownEast(rs.getBoolean(45));
                option.setShownZenith(rs.getBoolean(46));
                option.setShownVertex(rs.getBoolean(47));
                option.setShownVulcan(rs.getBoolean(48));
                option.setShownOtherPoint(rs.getBoolean(49));
                option.setShownCeres(rs.getBoolean(50));
                option.setShownPallas(rs.getBoolean(51));
                option.setShownJuno(rs.getBoolean(52));
                option.setShownVesta(rs.getBoolean(53));
                option.setShownChiron(rs.getBoolean(54));
                option.setTrueLilith(rs.getBoolean(55));
                option.setOtherPointType(rs.getByte(56));
                option.setOtherPointName(rs.getString(57));
                option.setColoredAspects(rs.getBoolean(58));
                option.setCoordSys(rs.getByte(59));
                option.setHouseSys(rs.getByte(60));
                option.setHousesCoords(rs.getBoolean(61));
                option.setSignsNames(rs.getBoolean(62));
                option.setLeftAsct(rs.getBoolean(63));
                option.setLimitMag(rs.getString(64));
                option.setSymbolAspects(rs.getBoolean(65));
                option.setViewStars(rs.getBoolean(66));
                option.setViewAsteroids(rs.getBoolean(67));
                option.setViewCoordinates(rs.getBoolean(68));
                option.setViewStraightLines(rs.getBoolean(69));
                option.setViewHouses(rs.getBoolean(70));
                option.setViewConstellations(rs.getBoolean(71));
                option.setViewShadedLines(rs.getBoolean(72));
                option.setViewAspects(rs.getBoolean(73));
                option.setViewBarycenter(rs.getBoolean(74));
                option.setHorizon(rs.getBoolean(75));
                option.setAspectsSun(rs.getBoolean(76));
                option.setAspectsMoon(rs.getBoolean(77));
                option.setAspectsMercury(rs.getBoolean(78));
                option.setAspectsVenus(rs.getBoolean(79));
                option.setAspectsMars(rs.getBoolean(80));
                option.setAspectsJupiter(rs.getBoolean(81));
                option.setAspectsSaturn(rs.getBoolean(82));
                option.setAspectsUranus(rs.getBoolean(83));
                option.setAspectsNeptune(rs.getBoolean(84));
                option.setAspectsPluto(rs.getBoolean(85));
                option.setAspectsGaia(rs.getBoolean(86));
                option.setAspectsNorthNode(rs.getBoolean(87));
                option.setAspectsLilith(rs.getBoolean(88));
                option.setAspectsEast(rs.getBoolean(89));
                option.setAspectsZenith(rs.getBoolean(90));
                option.setAspectsVertex(rs.getBoolean(91));
                option.setAspectsVulcan(rs.getBoolean(92));
                option.setAspectsOtherPoint(rs.getBoolean(93));
                option.setAspectsCeres(rs.getBoolean(94));
                option.setAspectsPallas(rs.getBoolean(95));
                option.setAspectsJuno(rs.getBoolean(96));
                option.setAspectsVesta(rs.getBoolean(97));
                option.setAspectsChiron(rs.getBoolean(98));
                option.setAspectsAS(rs.getBoolean(99));
                option.setAspectsMC(rs.getBoolean(100));
                option.setShownAspect0(rs.getBoolean(101));
                option.setShownAspect1(rs.getBoolean(102));
                option.setShownAspect2(rs.getBoolean(103));
                option.setShownAspect3(rs.getBoolean(104));
                option.setShownAspect4(rs.getBoolean(105));
                option.setShownAspect5(rs.getBoolean(106));
                option.setShownAspect6(rs.getBoolean(107));
                option.setShownAspect7(rs.getBoolean(108));
                option.setShownAspect8(rs.getBoolean(109));
                option.setShownAspect9(rs.getBoolean(110));
                option.setShownAspect10(rs.getBoolean(111));
                option.setShownAspect11(rs.getBoolean(112));
                option.setShownAspect12(rs.getBoolean(113));
                option.setShownAspect13(rs.getBoolean(114));
                option.setShownAspect14(rs.getBoolean(115));
                option.setShownAspect15(rs.getBoolean(116));
                option.setShownAspect16(rs.getBoolean(117));
                option.setShownAspect17(rs.getBoolean(118));
                option.setColorAspect0(new Color(rs.getInt(119)));
                option.setColorAspect1(new Color(rs.getInt(120)));
                option.setColorAspect2(new Color(rs.getInt(121)));
                option.setColorAspect3(new Color(rs.getInt(122)));
                option.setColorAspect4(new Color(rs.getInt(123)));
                option.setColorAspect5(new Color(rs.getInt(124)));
                option.setColorAspect6(new Color(rs.getInt(125)));
                option.setColorAspect7(new Color(rs.getInt(126)));
                option.setColorAspect8(new Color(rs.getInt(127)));
                option.setColorAspect9(new Color(rs.getInt(128)));
                option.setColorAspect10(new Color(rs.getInt(129)));
                option.setColorAspect11(new Color(rs.getInt(130)));
                option.setColorAspect12(new Color(rs.getInt(131)));
                option.setColorAspect13(new Color(rs.getInt(132)));
                option.setColorAspect14(new Color(rs.getInt(133)));
                option.setColorAspect15(new Color(rs.getInt(134)));
                option.setColorAspect16(new Color(rs.getInt(135)));
                option.setColorAspect17(new Color(rs.getInt(136)));
                option.setTypeAspect0(rs.getString(137));
                option.setTypeAspect1(rs.getString(138));
                option.setTypeAspect2(rs.getString(139));
                option.setTypeAspect3(rs.getString(140));
                option.setTypeAspect4(rs.getString(141));
                option.setTypeAspect5(rs.getString(142));
                option.setTypeAspect6(rs.getString(143));
                option.setTypeAspect7(rs.getString(144));
                option.setTypeAspect9(rs.getString(145));
                option.setTypeAspect9(rs.getString(146));
                option.setTypeAspect10(rs.getString(147));
                option.setTypeAspect11(rs.getString(148));
                option.setTypeAspect12(rs.getString(149));
                option.setTypeAspect13(rs.getString(150));
                option.setTypeAspect14(rs.getString(151));
                option.setTypeAspect15(rs.getString(152));
                option.setTypeAspect16(rs.getString(153));
                option.setTypeAspect17(rs.getString(154));
                option.setOtherAspectValue(rs.getString(155));
                option.setOtherAspectName(rs.getString(156));
                option.setOrbLightLight(rs.getString(157));
                option.setOrbLightTell(rs.getString(158));
                option.setOrbLightOtherInd(rs.getString(159));
                option.setOrbLightColl(rs.getString(160));
                option.setOrbLightVirtMax(rs.getString(161));
                option.setOrbLightVirtMin(rs.getString(162));
                option.setOrbTellTell(rs.getString(163));
                option.setOrbTellOtherInd(rs.getString(164));
                option.setOrbTellColl(rs.getString(165));
                option.setOrbTellVirtMax(rs.getString(166));
                option.setOrbTellVirtMin(rs.getString(167));
                option.setOrbOtherIndOtherInd(rs.getString(168));
                option.setOrbOtherIndColl(rs.getString(169));
                option.setOrbOtherIndVirtMax(rs.getString(170));
                option.setOrbOtherIndVirtMin(rs.getString(171));
                option.setOrbCollColl(rs.getString(172));
                option.setOrbCollVirtMax(rs.getString(173));
                option.setOrbCollVirtMin(rs.getString(174));
                option.setOrbVirtMaxVirtMax(rs.getString(175));
                option.setOrbVirtMaxVirtMin(rs.getString(176));
                option.setOrbVirtMinVirtMin(rs.getString(177));
                option.setDivMin(rs.getString(178));
                option.setDivConjuntion(rs.getString(179));
                option.setDivSextil(rs.getString(180));
                option.setDivSquare(rs.getString(181));
                option.setDivTrine(rs.getString(182));
                option.setDivOpposition(rs.getString(183));
                option.setChartSelectSingle(rs.getBoolean(184));
                option.setChartKinds(rs.getString(185));
                option.setChartDir1Corresp(rs.getString(186));
                option.setChartDir2Corresp(rs.getString(187));
                option.setChartDirSCorresp(rs.getString(188));
                option.setChartDir1Degree(rs.getString(189));
                option.setChartDir2Day(rs.getString(190));
                option.setChartDirSDegree(rs.getString(191));
                option.setChartDir1SpaceKind(new Byte(rs.getByte(192)).toString());
                option.setChartDir2SpaceKind(new Byte(rs.getByte(193)).toString());
                option.setChartDirSSpaceKind(new Byte(rs.getByte(194)).toString());
                option.setChartReturnPrecess(rs.getBoolean(195));
                option.setChartReturnPlaceID(String.valueOf(rs.getInt(196)));
                option.setChartCyclePlaceID(String.valueOf(rs.getInt(197)));
                option.setChartReturnPlanet(new Byte(rs.getByte(198)).toString());
                option.setChartCyclePlanet1(new Byte(rs.getByte(199)).toString());
                option.setChartCyclePlanet2(new Byte(rs.getByte(200)).toString());
                option.setChartCompositeNB(new Byte(rs.getByte(201)).toString());
                option.setChartHarmonicNB(new Byte(rs.getByte(202)).toString());
                option.setSingleWeight(rs.getBoolean(203));
                option.setChartCompositeFromAS(rs.getBoolean(204));
                option.setId(rs.getString(205));
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        option.setRow(findRow(option.getId()));
        option.setRowNB(findRowNB());
        return option;
    }
    
    private void checkDefaultConfig()
    {
        try
        {
            if (existingDefaultOptions() == 0)
            {
                Statement statement = dataBase.createStatement();
                /*if (dataBase.getDataBaseKind().getKind() == DataBaseKind.MySQL)
                {
                    ResultSet rsTemp = statement.executeQuery("SELECT Min(ID) FROM OptionsConfiguration");
                    String id0 = "0";
                    while (rsTemp.next())
                    {
                        id0 = String.valueOf(rsTemp.getInt(1));
                    }
                    
                    rsTemp.close();
                    statement.executeUpdate("UPDATE OptionsConfiguration SET DefaultConfiguration=-1 WHERE ID=" + id0);
                }
                else
                {*/
                statement.executeUpdate("UPDATE OptionsConfiguration SET DefaultConfiguration=-1 WHERE ID IN (SELECT Min(ID) FROM OptionsConfiguration)");
                //}
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    private void checkDefaultConfig(String strID)
    {
        try
        {
            if (existingDefaultOptions() == 0)
            {
                Statement statement = dataBase.createStatement();
                //if (dataBase.getDataBaseKind().getKind() == DataBaseKind.MySQL)
                //{
                //    statement.executeUpdate("UPDATE OptionsConfiguration SET DefaultConfiguration=1 WHERE ID=" + strID);
                //}
                //else
                //{
                    statement.executeUpdate("UPDATE OptionsConfiguration SET DefaultConfiguration=-1 WHERE ID=" + strID);
                //}
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    public void setOption(Option option)
    {
        String query;
        
        try
        {
            Statement statement = dataBase.createStatement();
            String chartReturnPlaceID = SQLString.processNull(option.getChartReturnPlaceID());
            String chartCyclePlaceID = SQLString.processNull(option.getChartCyclePlaceID());
            String defaultEvent = SQLString.processNull(option.getDefaultEvent());
            String defaultPlace = SQLString.processNull(option.getDefaultPlace());
            byte coordSys = option.getCoordSys();
            byte houseSys = option.getHouseSys();
            byte otherPointType = option.getOtherPointType();
            String chartReturnPlanet = SQLString.processNull(option.getChartReturnPlanet());
            String chartCyclePlanet1 = SQLString.processNull(option.getChartCyclePlanet1());
            String chartCyclePlanet2 = SQLString.processNull(option.getChartCyclePlanet2());
            String chartCompositeNB = SQLString.processNull(option.getChartCompositeNB());
            String chartHarmonicNB = SQLString.processNull(option.getChartHarmonicNB());
            String chartDir1SpaceKind = SQLString.processNull(option.getChartDir1SpaceKind());
            String chartDir2SpaceKind = SQLString.processNull(option.getChartDir2SpaceKind());
            String chartDirSSpaceKind = SQLString.processNull(option.getChartDirSSpaceKind());
            String otherPointName = SQLString.processNull(option.getOtherPointName());
            String configurationName = SQLString.processNull(option.getConfigurationName());
            int zodiacSize = option.getZodiacSize();
            int signSize = option.getSignSize();
            int planetSize = option.getPlanetSize();
            int characterSize = option.getCharacterSize();
            String typeAspect0 = SQLString.processNull(option.getTypeAspect0());
            String typeAspect1 = SQLString.processNull(option.getTypeAspect1());
            String typeAspect2 = SQLString.processNull(option.getTypeAspect2());
            String typeAspect3 = SQLString.processNull(option.getTypeAspect3());
            String typeAspect4 = SQLString.processNull(option.getTypeAspect4());
            String typeAspect5 = SQLString.processNull(option.getTypeAspect5());
            String typeAspect6 = SQLString.processNull(option.getTypeAspect6());
            String typeAspect7 = SQLString.processNull(option.getTypeAspect7());
            String typeAspect8 = SQLString.processNull(option.getTypeAspect8());
            String typeAspect9 = SQLString.processNull(option.getTypeAspect9());
            String typeAspect10 = SQLString.processNull(option.getTypeAspect10());
            String typeAspect11 = SQLString.processNull(option.getTypeAspect11());
            String typeAspect12 = SQLString.processNull(option.getTypeAspect12());
            String typeAspect13 = SQLString.processNull(option.getTypeAspect13());
            String typeAspect14 = SQLString.processNull(option.getTypeAspect14());
            String typeAspect15 = SQLString.processNull(option.getTypeAspect15());
            String typeAspect16 = SQLString.processNull(option.getTypeAspect16());
            String typeAspect17 = SQLString.processNull(option.getTypeAspect17());
            String otherAspectName = SQLString.processNull(option.getOtherAspectName());
            String chartKinds = SQLString.processNull(option.getChartKinds());
            int sunColor = option.getSunColor().getRGB();
            int moonColor = option.getMoonColor().getRGB();
            int mercuryColor = option.getMercuryColor().getRGB();
            int venusColor = option.getVenusColor().getRGB();
            int marsColor = option.getMarsColor().getRGB();
            int jupiterColor = option.getJupiterColor().getRGB();
            int saturnColor = option.getSaturnColor().getRGB();
            int uranusColor = option.getUranusColor().getRGB();
            int neptuneColor = option.getNeptuneColor().getRGB();
            int plutoColor = option.getPlutoColor().getRGB();
            int gaiaColor = option.getGaiaColor().getRGB();
            int nodesColor = option.getNodesColor().getRGB();
            int cuspsColor = option.getCuspsColor().getRGB();
            int optionsColor = option.getAsteroidsColor().getRGB();
            int vulcanColor = option.getVulcanColor().getRGB();
            int variousColor = option.getVariousColor().getRGB();
            int fireColor = option.getFireColor().getRGB();
            int earthColor = option.getEarthColor().getRGB();
            int airColor = option.getAirColor().getRGB();
            int waterColor = option.getWaterColor().getRGB();
            int neutralColor = option.getNeutralColor().getRGB();
            int dynamicColor = option.getDynamicColor().getRGB();
            int harmonicColor = option.getHarmonicColor().getRGB();
            int colorAspect0 = option.getColorAspect0().getRGB();
            int colorAspect1 = option.getColorAspect1().getRGB();
            int colorAspect2 = option.getColorAspect2().getRGB();
            int colorAspect3 = option.getColorAspect3().getRGB();
            int colorAspect4 = option.getColorAspect4().getRGB();
            int colorAspect5 = option.getColorAspect5().getRGB();
            int colorAspect6 = option.getColorAspect6().getRGB();
            int colorAspect7 = option.getColorAspect7().getRGB();
            int colorAspect8 = option.getColorAspect8().getRGB();
            int colorAspect9 = option.getColorAspect9().getRGB();
            int colorAspect10 = option.getColorAspect10().getRGB();
            int colorAspect11 = option.getColorAspect11().getRGB();
            int colorAspect12 = option.getColorAspect12().getRGB();
            int colorAspect13 = option.getColorAspect13().getRGB();
            int colorAspect14 = option.getColorAspect14().getRGB();
            int colorAspect15 = option.getColorAspect15().getRGB();
            int colorAspect16 = option.getColorAspect16().getRGB();
            int colorAspect17 = option.getColorAspect17().getRGB();
            byte defaultConfiguration = AstronomyMaths.bool2byte(option.getDefaultConfiguration());
            byte shownSun = AstronomyMaths.bool2byte(option.getShownSun());
            byte shownMoon = AstronomyMaths.bool2byte(option.getShownMoon());
            byte shownMercury = AstronomyMaths.bool2byte(option.getShownMercury());
            byte shownVenus = AstronomyMaths.bool2byte(option.getShownVenus());
            byte shownMars = AstronomyMaths.bool2byte(option.getShownMars());
            byte shownJupiter = AstronomyMaths.bool2byte(option.getShownJupiter());
            byte shownSaturn = AstronomyMaths.bool2byte(option.getShownSaturn());
            byte shownUranus = AstronomyMaths.bool2byte(option.getShownUranus());
            byte shownNeptune = AstronomyMaths.bool2byte(option.getShownNeptune());
            byte shownPluto = AstronomyMaths.bool2byte(option.getShownPluto());
            byte shownGaia = AstronomyMaths.bool2byte(option.getShownGaia());
            byte shownNorthNode = AstronomyMaths.bool2byte(option.getShownNorthNode());
            byte shownLilith = AstronomyMaths.bool2byte(option.getShownLilith());
            byte shownEast = AstronomyMaths.bool2byte(option.getShownEast());
            byte shownZenith = AstronomyMaths.bool2byte(option.getShownZenith());
            byte shownVertex = AstronomyMaths.bool2byte(option.getShownVertex());
            byte shownVulcan = AstronomyMaths.bool2byte(option.getShownVulcan());
            byte shownOtherPoint = AstronomyMaths.bool2byte(option.getShownOtherPoint());
            byte shownCeres = AstronomyMaths.bool2byte(option.getShownCeres());
            byte shownPallas = AstronomyMaths.bool2byte(option.getShownPallas());
            byte shownJuno = AstronomyMaths.bool2byte(option.getShownJuno());
            byte shownVesta = AstronomyMaths.bool2byte(option.getShownVesta());
            byte shownChiron = AstronomyMaths.bool2byte(option.getShownChiron());
            byte trueLilith = AstronomyMaths.bool2byte(option.getTrueLilith());
            byte coloredAspects = AstronomyMaths.bool2byte(option.getColoredAspects());
            byte housesCoords = AstronomyMaths.bool2byte(option.getHousesCoords());
            byte signsNames = AstronomyMaths.bool2byte(option.getSignsNames());
            byte leftAsct = AstronomyMaths.bool2byte(option.getLeftAsct());
            byte symbolAspects = AstronomyMaths.bool2byte(option.getSymbolAspects());
            byte viewStars = AstronomyMaths.bool2byte(option.getViewStars());
            byte viewAsteroids = AstronomyMaths.bool2byte(option.getViewAsteroids());
            byte viewCoordinates = AstronomyMaths.bool2byte(option.getViewCoordinates());
            byte viewStraightLines = AstronomyMaths.bool2byte(option.getViewStraightLines());
            byte viewHouses = AstronomyMaths.bool2byte(option.getViewHouses());
            byte viewConstellations = AstronomyMaths.bool2byte(option.getViewConstellations());
            byte viewShadedLines = AstronomyMaths.bool2byte(option.getViewShadedLines());
            byte viewAspects = AstronomyMaths.bool2byte(option.getViewAspects());
            byte viewBarycenter = AstronomyMaths.bool2byte(option.getViewBarycenter());
            byte horizon = AstronomyMaths.bool2byte(option.getHorizon());
            byte aspectsSun = AstronomyMaths.bool2byte(option.getAspectsSun());
            byte aspectsMoon = AstronomyMaths.bool2byte(option.getAspectsMoon());
            byte aspectsMercury = AstronomyMaths.bool2byte(option.getAspectsMercury());
            byte aspectsVenus = AstronomyMaths.bool2byte(option.getAspectsVenus());
            byte aspectsMars = AstronomyMaths.bool2byte(option.getAspectsMars());
            byte aspectsJupiter = AstronomyMaths.bool2byte(option.getAspectsJupiter());
            byte aspectsSaturn = AstronomyMaths.bool2byte(option.getAspectsSaturn());
            byte aspectsUranus = AstronomyMaths.bool2byte(option.getAspectsUranus());
            byte aspectsNeptune = AstronomyMaths.bool2byte(option.getAspectsNeptune());
            byte aspectsPluto = AstronomyMaths.bool2byte(option.getAspectsPluto());
            byte aspectsGaia = AstronomyMaths.bool2byte(option.getAspectsGaia());
            byte aspectsNorthNode = AstronomyMaths.bool2byte(option.getAspectsNorthNode());
            byte aspectsLilith = AstronomyMaths.bool2byte(option.getAspectsLilith());
            byte aspectsEast = AstronomyMaths.bool2byte(option.getAspectsEast());
            byte aspectsZenith = AstronomyMaths.bool2byte(option.getAspectsZenith());
            byte aspectsVertex = AstronomyMaths.bool2byte(option.getAspectsVertex());
            byte aspectsVulcan = AstronomyMaths.bool2byte(option.getAspectsVulcan());
            byte aspectsOtherPoint = AstronomyMaths.bool2byte(option.getAspectsOtherPoint());
            byte aspectsCeres = AstronomyMaths.bool2byte(option.getAspectsCeres());
            byte aspectsPallas = AstronomyMaths.bool2byte(option.getAspectsPallas());
            byte aspectsJuno = AstronomyMaths.bool2byte(option.getAspectsJuno());
            byte aspectsVesta = AstronomyMaths.bool2byte(option.getAspectsVesta());
            byte aspectsChiron = AstronomyMaths.bool2byte(option.getAspectsChiron());
            byte aspectsAS = AstronomyMaths.bool2byte(option.getAspectsAS());
            byte aspectsMC = AstronomyMaths.bool2byte(option.getAspectsMC());
            byte shownAspect0 = AstronomyMaths.bool2byte(option.getShownAspect0());
            byte shownAspect1 = AstronomyMaths.bool2byte(option.getShownAspect1());
            byte shownAspect2 = AstronomyMaths.bool2byte(option.getShownAspect2());
            byte shownAspect3 = AstronomyMaths.bool2byte(option.getShownAspect3());
            byte shownAspect4 = AstronomyMaths.bool2byte(option.getShownAspect4());
            byte shownAspect5 = AstronomyMaths.bool2byte(option.getShownAspect5());
            byte shownAspect6 = AstronomyMaths.bool2byte(option.getShownAspect6());
            byte shownAspect7 = AstronomyMaths.bool2byte(option.getShownAspect7());
            byte shownAspect8 = AstronomyMaths.bool2byte(option.getShownAspect8());
            byte shownAspect9 = AstronomyMaths.bool2byte(option.getShownAspect9());
            byte shownAspect10 = AstronomyMaths.bool2byte(option.getShownAspect10());
            byte shownAspect11 = AstronomyMaths.bool2byte(option.getShownAspect11());
            byte shownAspect12 = AstronomyMaths.bool2byte(option.getShownAspect12());
            byte shownAspect13 = AstronomyMaths.bool2byte(option.getShownAspect13());
            byte shownAspect14 = AstronomyMaths.bool2byte(option.getShownAspect14());
            byte shownAspect15 = AstronomyMaths.bool2byte(option.getShownAspect15());
            byte shownAspect16 = AstronomyMaths.bool2byte(option.getShownAspect16());
            byte shownAspect17 = AstronomyMaths.bool2byte(option.getShownAspect17());
            byte chartSelectSingle = AstronomyMaths.bool2byte(option.getChartSelectSingle());
            byte chartReturnPrecess = AstronomyMaths.bool2byte(option.getChartReturnPrecess());
            String limitMag = SQLString.processNull(option.getLimitMag());
            String orbLightLight = SQLString.processNull(option.getOrbLightLight());
            String orbLightTell = SQLString.processNull(option.getOrbLightTell());
            String orbLightOtherInd = SQLString.processNull(option.getOrbLightOtherInd());
            String orbLightColl = SQLString.processNull(option.getOrbLightColl());
            String orbLightVirtMax = SQLString.processNull(option.getOrbLightVirtMax());
            String orbLightVirtMin = SQLString.processNull(option.getOrbLightVirtMin());
            String orbTellTell = SQLString.processNull(option.getOrbTellTell());
            String orbTellOtherInd = SQLString.processNull(option.getOrbTellOtherInd());
            String orbTellColl = SQLString.processNull(option.getOrbTellColl());
            String orbTellVirtMax = SQLString.processNull(option.getOrbTellVirtMax());
            String orbTellVirtMin = SQLString.processNull(option.getOrbTellVirtMin());
            String orbOtherIndOtherInd = SQLString.processNull(option.getOrbOtherIndOtherInd());
            String orbOtherIndColl = SQLString.processNull(option.getOrbOtherIndColl());
            String orbOtherIndVirtMax = SQLString.processNull(option.getOrbOtherIndVirtMax());
            String orbOtherIndVirtMin = SQLString.processNull(option.getOrbOtherIndVirtMin());
            String orbCollColl = SQLString.processNull(option.getOrbCollColl());
            String orbCollVirtMax = SQLString.processNull(option.getOrbCollVirtMax());
            String orbCollVirtMin = SQLString.processNull(option.getOrbCollVirtMin());
            String orbVirtMaxVirtMax = SQLString.processNull(option.getOrbVirtMaxVirtMax());
            String orbVirtMaxVirtMin = SQLString.processNull(option.getOrbVirtMaxVirtMin());
            String orbVirtMinVirtMin = SQLString.processNull(option.getOrbVirtMinVirtMin());
            String divMin = SQLString.processNull(option.getDivMin());
            String divConjuntion = SQLString.processNull(option.getDivConjuntion());
            String divSextil = SQLString.processNull(option.getDivSextil());
            String divSquare = SQLString.processNull(option.getDivSquare());
            String divTrine = SQLString.processNull(option.getDivTrine());
            String divOpposition = SQLString.processNull(option.getDivOpposition());
            String otherAspectValue = SQLString.processNull(option.getOtherAspectValue());
            String chartDir1Corresp = SQLString.processNull(option.getChartDir1Corresp());
            String chartDir2Corresp = SQLString.processNull(option.getChartDir2Corresp());
            String chartDirSCorresp = SQLString.processNull(option.getChartDirSCorresp());
            String chartDir1Degree = SQLString.processNull(option.getChartDir1Degree());
            String chartDir2Day = SQLString.processNull(option.getChartDir2Day());
            String chartDirSDegree = SQLString.processNull(option.getChartDirSDegree());
            byte singleWeight = AstronomyMaths.bool2byte(option.getSingleWeight());
            byte chartCompositeFromAS = AstronomyMaths.bool2byte(option.getChartCompositeFromAS());
            
            //remove first the previous default configuration, if needed
            if (defaultConfiguration != 0)
            {
                removeDefaultOptions();
            }
            else if (existingDefaultOptions() == 0)
            {
                //if there is not an existing default configuration, set the current configuration as the default one
                defaultConfiguration = 0;
            }
            
            if (option.getAdding()==true)
            {
                query = "INSERT INTO OptionsConfiguration (ConfigurationName, Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, Gaia, Nodes, Cusps, Asteroids, Vulcan, Various, Fire, Earth, Air, Water, Neutral, Dynamic, Harmonic, ZodiacSize, SignSize, PlanetSize, CharacterSize, DefaultConfiguration, DefaultEvent, DefaultPlace, ShownSun, ShownMoon, ShownMercury, ShownVenus, ShownMars, ShownJupiter, ShownSaturn, ShownUranus, ShownNeptune, ShownPluto, ShownGaia, ShownNorthNode, ShownLilith, ShownEast, ShownZenith, ShownVertex, ShownVulcan, ShownOtherPoint, ShownCeres, ShownPallas, ShownJuno, ShownVesta, ShownChiron, TrueLilith, OtherPointType, OtherPointName, ColoredAspects, CoordSys, HouseSys, HousesCoords, SignsNames, LeftAsct, LimitMag, SymbolAspects, ViewStars, ViewAsteroids, ViewCoordinates, ViewStraightLines, ViewHouses, ViewConstellations, ViewShadedLines, ViewAspects, ViewBarycenter, BarySingleWeight, Horizon, AspectsSun, AspectsMoon, AspectsMercury, AspectsVenus, AspectsMars, AspectsJupiter, AspectsSaturn, AspectsUranus, AspectsNeptune, AspectsPluto, AspectsGaia, AspectsNorthNode, AspectsLilith, AspectsEast, AspectsZenith, AspectsVertex, AspectsVulcan, AspectsOtherPoint, AspectsCeres, AspectsPallas, AspectsJuno, AspectsVesta, AspectsChiron, AspectsAS, AspectsMC, ShownAspect0, ShownAspect1, ShownAspect2, ShownAspect3, ShownAspect4, ShownAspect5, ShownAspect6, ShownAspect7, ShownAspect8, ShownAspect9, ShownAspect10, ShownAspect11, ShownAspect12, ShownAspect13, ShownAspect14, ShownAspect15, ShownAspect16, ShownAspect17, ColorAspect0, ColorAspect1, ColorAspect2, ColorAspect3, ColorAspect4, ColorAspect5, ColorAspect6, ColorAspect7, ColorAspect8, ColorAspect9, ColorAspect10, ColorAspect11, ColorAspect12, ColorAspect13, ColorAspect14, ColorAspect15, ColorAspect16, ColorAspect17, TypeAspect0, TypeAspect1, TypeAspect2, TypeAspect3, TypeAspect4, TypeAspect5, TypeAspect6, TypeAspect7, TypeAspect8, TypeAspect9, TypeAspect10, TypeAspect11, TypeAspect12, TypeAspect13, TypeAspect14, TypeAspect15, TypeAspect16, TypeAspect17, OtherAspectValue, OtherAspectName, OrbLightLight, OrbLightTell, OrbLightOtherInd, OrbLightColl, OrbLightVirtMax, OrbLightVirtMin, OrbTellTell, OrbTellOtherInd, OrbTellColl, OrbTellVirtMax, OrbTellVirtMin, OrbOtherIndOtherInd, OrbOtherIndColl, OrbOtherIndVirtMax, OrbOtherIndVirtMin, OrbCollColl, OrbCollVirtMax, OrbCollVirtMin, OrbVirtMaxVirtMax, OrbVirtMaxVirtMin, OrbVirtMinVirtMin, DivMin, DivConjuntion, DivSextil, DivSquare, DivTrine, DivOpposition, ChartSelectSingle, ChartKinds, ChartDir1Corresp, ChartDir2Corresp, ChartDirSCorresp, ChartDir1Degree, ChartDir2Day, ChartDirSDegree, ChartDir1SpaceKind, ChartDir2SpaceKind, ChartDirSSpaceKind, ChartReturnPrecess, ChartReturnPlaceID, ChartCyclePlaceID, ChartReturnPlanet, ChartCyclePlanet1, ChartCyclePlanet2, ChartCompositeNB, ChartHarmonicNB, ChartCompositeFromAS) VALUES ('" + MainClass.replaceQuotes(configurationName) + "', " + sunColor + ", " + moonColor + ", " + mercuryColor + ", " + venusColor + ", " + marsColor + ", " + jupiterColor + ", " + saturnColor + ", " + uranusColor + ", " + neptuneColor + ", " + plutoColor + ", " + gaiaColor + ", " + nodesColor + ", " + cuspsColor + ", " + optionsColor + ", " + vulcanColor + ", " + variousColor + ", " + fireColor + ", " + earthColor + ", " + airColor + ", " + waterColor + ", " + neutralColor + ", " + dynamicColor + ", " + harmonicColor + ", " + zodiacSize + ", " + signSize + ", " + planetSize + ", " + characterSize + ", " + defaultConfiguration + ", " + defaultEvent + ", " + defaultPlace + ", " + shownSun + ", " + shownMoon + ", " + shownMercury + ", " + shownVenus + ", " + shownMars + ", " + shownJupiter + ", " + shownSaturn + ", " + shownUranus + ", " + shownNeptune + ", " + shownPluto + ", " + shownGaia + ", " + shownNorthNode + ", " + shownLilith + ", " + shownEast + ", " + shownZenith + ", " + shownVertex + ", " + shownVulcan + ", " + shownOtherPoint + ", " + shownCeres + ", " + shownPallas + ", " + shownJuno + ", " + shownVesta + ", " + shownChiron + ", " + trueLilith + ", " + otherPointType + ", '" + MainClass.replaceQuotes(otherPointName) + "', " + coloredAspects + ", " + coordSys + ", " + houseSys + ", " + housesCoords + ", " + signsNames + ", " + leftAsct + ", " + limitMag + ", " + symbolAspects + ", " + viewStars + ", " + viewAsteroids + ", " + viewCoordinates + ", " + viewStraightLines + ", " + viewHouses + ", " + viewConstellations + ", " + viewShadedLines + ", " + viewAspects + ", " + viewBarycenter + ", " + singleWeight + ", " + horizon + ", " + aspectsSun + ", " + aspectsMoon + ", " + aspectsMercury + ", " + aspectsVenus + ", " + aspectsMars + ", " + aspectsJupiter + ", " + aspectsSaturn + ", " + aspectsUranus + ", " + aspectsNeptune + ", " + aspectsPluto + ", " + aspectsGaia + ", " + aspectsNorthNode + ", " + aspectsLilith + ", " + aspectsEast + ", " + aspectsZenith + ", " + aspectsVertex + ", " + aspectsVulcan + ", " + aspectsOtherPoint + ", " + aspectsCeres + ", " + aspectsPallas + ", " + aspectsJuno + ", " + aspectsVesta + ", " + aspectsChiron + ", " + aspectsAS + ", " + aspectsMC + ", " + shownAspect0 + ", " + shownAspect1 + ", " + shownAspect2 + ", " + shownAspect3 + ", " + shownAspect4 + ", " + shownAspect5 + ", " + shownAspect6 + ", " + shownAspect7 + ", " + shownAspect8 + ", " + shownAspect9 + ", " + shownAspect10 + ", " + shownAspect11 + ", " + shownAspect12 + ", " + shownAspect13 + ", " + shownAspect14 + ", " + shownAspect15 + ", " + shownAspect16 + ", " + shownAspect17 + ", " + colorAspect0 + ", " + colorAspect1 + ", " + colorAspect2 + ", " + colorAspect3 + ", " + colorAspect4 + ", " + colorAspect5 + ", " + colorAspect6 + ", " + colorAspect7 + ", " + colorAspect8 + ", " + colorAspect9 + ", " + colorAspect10 + ", " + colorAspect11 + ", " + colorAspect12 + ", " + colorAspect13 + ", " + colorAspect14 + ", " + colorAspect15 + ", " + colorAspect16 + ", " + colorAspect17 + ", '" + typeAspect0 + "', '" + typeAspect1 + "', '" + typeAspect2 + "', '" + typeAspect3 + "', '" + typeAspect4 + "', '" + typeAspect5 + "', '" + typeAspect6 + "', '" + typeAspect7 + "', '" + typeAspect8 + "', '" + typeAspect9 + "', '" + typeAspect10 + "', '" + typeAspect11 + "', '" + typeAspect12 + "', '" + typeAspect13 + "', '" + typeAspect14 + "', '" + typeAspect15 + "', '" + typeAspect16 + "', '" + typeAspect17 + "', " + otherAspectValue + ", '" + MainClass.replaceQuotes(otherAspectName) + "', " + orbLightLight + ", " + orbLightTell + ", " + orbLightOtherInd + ", " + orbLightColl + ", " + orbLightVirtMax + ", " + orbLightVirtMin + ", " + orbTellTell + ", " + orbTellOtherInd + ", " + orbTellColl + ", " + orbTellVirtMax + ", " + orbTellVirtMin + ", " + orbOtherIndOtherInd + ", " + orbOtherIndColl + ", " + orbOtherIndVirtMax + ", " + orbOtherIndVirtMin + ", " + orbCollColl + ", " + orbCollVirtMax + ", " + orbCollVirtMin + ", " + orbVirtMaxVirtMax + ", " + orbVirtMaxVirtMin + ", " + orbVirtMinVirtMin + ", " + divMin + ", " + divConjuntion + ", " + divSextil + ", " + divSquare + ", " + divTrine + ", " + divOpposition + ", " + chartSelectSingle + ", '" + chartKinds + "', " + chartDir1Corresp + ", " + chartDir2Corresp + ", " + chartDirSCorresp + ", " + chartDir1Degree + ", " + chartDir2Day + ", " + chartDirSDegree + ", " + chartDir1SpaceKind + ", " + chartDir2SpaceKind + ", " + chartDirSSpaceKind + ", " + chartReturnPrecess + ", " + chartReturnPlaceID + ", " + chartCyclePlaceID + ", " + chartReturnPlanet + ", " + chartCyclePlanet1 + ", " + chartCyclePlanet2 + ", " + chartCompositeNB + ", " + chartHarmonicNB  + ", " + chartCompositeFromAS + ")";
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);

                String newID = getNewId();

                option.setId(newID);

                id = newID;
                int row = findRow(newID);
                option.setRow(row);
                option.setRowNB(option.getRowNB() + 1);
                option.setAdding(false);
            }
            else
            {
                query = "UPDATE OptionsConfiguration SET ConfigurationName='" + MainClass.replaceQuotes(configurationName) + "', Sun=" + sunColor + ", Moon=" + moonColor + ", Mercury=" + mercuryColor + ", Venus=" + venusColor + ", Mars=" + marsColor + ", Jupiter=" + jupiterColor + ", Saturn=" + saturnColor + ", Uranus=" + uranusColor + ", Neptune=" + neptuneColor + ", Pluto=" + plutoColor + ", Gaia=" + gaiaColor + ", Nodes=" + nodesColor + ", Cusps=" + cuspsColor + ", Asteroids=" + optionsColor + ", Vulcan=" + vulcanColor + ", Various=" + variousColor + ", Fire=" + fireColor + ", Earth=" + earthColor + ", Air=" + airColor + ", Water=" + waterColor + ", Neutral=" + neutralColor + ", Dynamic=" + dynamicColor + ", Harmonic=" + harmonicColor + ", ZodiacSize=" + zodiacSize + ", SignSize=" + signSize + ", PlanetSize=" + planetSize + ", CharacterSize=" + characterSize + ", DefaultConfiguration=" + defaultConfiguration + ", DefaultEvent=" + defaultEvent + ", DefaultPlace=" + defaultPlace + ", ShownSun=" + shownSun + ", ShownMoon=" + shownMoon + ", ShownMercury=" + shownMercury + ", ShownVenus=" + shownVenus + ", ShownMars=" + shownMars + ", ShownJupiter=" + shownJupiter + ", ShownSaturn=" + shownSaturn + ", ShownUranus=" + shownUranus + ", ShownNeptune=" + shownNeptune + ", ShownPluto=" + shownPluto + ", ShownGaia=" + shownGaia + ", ShownNorthNode=" + shownNorthNode + ", ShownLilith=" + shownLilith + ", ShownEast=" + shownEast + ", ShownZenith=" + shownZenith + ", ShownVertex=" + shownVertex + ", ShownVulcan=" + shownVulcan + ", ShownOtherPoint=" + shownOtherPoint + ", ShownCeres=" + shownCeres + ", ShownPallas=" + shownPallas + ", ShownJuno=" + shownJuno + ", ShownVesta=" + shownVesta + ", ShownChiron=" + shownChiron + ", TrueLilith=" + trueLilith + ", OtherPointType=" + otherPointType + ", OtherPointName='" + MainClass.replaceQuotes(otherPointName) + "', ColoredAspects=" + coloredAspects + ", CoordSys=" + coordSys + ", HouseSys=" + houseSys + ", HousesCoords=" + housesCoords + ", SignsNames=" + signsNames + ", LeftAsct=" + leftAsct + ", LimitMag=" + limitMag + ", SymbolAspects=" + symbolAspects + ", ViewStars=" + viewStars + ", ViewAsteroids=" + viewAsteroids + ", ViewCoordinates=" + viewCoordinates + ", ViewStraightLines=" + viewStraightLines + ", ViewHouses=" + viewHouses + ", ViewConstellations=" + viewConstellations + ", ViewShadedLines=" + viewShadedLines + ", ViewAspects=" + viewAspects + ", ViewBarycenter=" + viewBarycenter + ", BarySingleWeight=" + singleWeight + ", Horizon=" + horizon + ", AspectsSun=" + aspectsSun + ", AspectsMoon=" + aspectsMoon + ", AspectsMercury=" + aspectsMercury + ", AspectsVenus=" + aspectsVenus + ", AspectsMars=" + aspectsMars + ", AspectsJupiter=" + aspectsJupiter + ", AspectsSaturn=" + aspectsSaturn + ", AspectsUranus=" + aspectsUranus + ", AspectsNeptune=" + aspectsNeptune + ", AspectsPluto=" + aspectsPluto + ", AspectsGaia=" + aspectsGaia + ", AspectsNorthNode=" + aspectsNorthNode + ", AspectsLilith=" + aspectsLilith + ", AspectsEast=" + aspectsEast + ", AspectsZenith=" + aspectsZenith + ", AspectsVertex=" + aspectsVertex + ", AspectsVulcan=" + aspectsVulcan + ", AspectsOtherPoint=" + aspectsOtherPoint + ", AspectsCeres=" + aspectsCeres + ", AspectsPallas=" + aspectsPallas + ", AspectsJuno=" + aspectsJuno + ", AspectsVesta=" + aspectsVesta + ", AspectsChiron=" + aspectsChiron + ", ChartCompositeFromAS=" + chartCompositeFromAS + ", AspectsAS=" + aspectsAS + ", AspectsMC=" + aspectsMC + " WHERE ID=" + option.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);
                query = "UPDATE OptionsConfiguration SET ShownAspect0=" + shownAspect0 + ", ShownAspect1=" + shownAspect1 + ", ShownAspect2=" + shownAspect2 + ", ShownAspect3=" + shownAspect3 + ", ShownAspect4=" + shownAspect4 + ", ShownAspect5=" + shownAspect5 + ", ShownAspect6=" + shownAspect6 + ", ShownAspect7=" + shownAspect7 + ", ShownAspect8=" + shownAspect8 + ", ShownAspect9=" + shownAspect9 + ", ShownAspect10=" + shownAspect10 + ", ShownAspect11=" + shownAspect11 + ", ShownAspect12=" + shownAspect12 + ", ShownAspect13=" + shownAspect13 + ", ShownAspect14=" + shownAspect14 + ", ShownAspect15=" + shownAspect15 + ", ShownAspect16=" + shownAspect16 + ", ShownAspect17=" + shownAspect17 + ", ColorAspect0=" + colorAspect0 + ", ColorAspect1=" + colorAspect1 + ", ColorAspect2=" + colorAspect2 + ", ColorAspect3=" + colorAspect3 + ", ColorAspect4=" + colorAspect4 + ", ColorAspect5=" + colorAspect5 + ", ColorAspect6=" + colorAspect6 + ", ColorAspect7=" + colorAspect7 + ", ColorAspect8=" + colorAspect8 + ", ColorAspect9=" + colorAspect9 + ", ColorAspect10=" + colorAspect10 + ", ColorAspect11=" + colorAspect11 + ", ColorAspect12=" + colorAspect12 + ", ColorAspect13=" + colorAspect13 + ", ColorAspect14=" + colorAspect14 + ", ColorAspect15=" + colorAspect15 + ", ColorAspect16=" + colorAspect16 + ", ColorAspect17=" + colorAspect17 
                        + ", TypeAspect0='" + typeAspect0 + "', TypeAspect1='" + typeAspect1 + "', TypeAspect2='" + typeAspect2 + "', TypeAspect3='" + typeAspect3 + "', TypeAspect4='" + typeAspect4 + "', TypeAspect5='" + typeAspect5 + "', TypeAspect6='" + typeAspect6 + "', TypeAspect7='" + typeAspect7 + "', TypeAspect8='" + typeAspect8 + "', TypeAspect9='" + typeAspect9 + "', TypeAspect10='" + typeAspect10 + "', TypeAspect11='" + typeAspect11 + "', TypeAspect12='" + typeAspect12 + "', TypeAspect13='" + typeAspect13 + "', TypeAspect14='" + typeAspect14 + "', TypeAspect15='" + typeAspect15 + "', TypeAspect16='" + typeAspect16 + "', TypeAspect17='" + typeAspect17 + "', OtherAspectValue=" + otherAspectValue + ", OtherAspectName='" + MainClass.replaceQuotes(otherAspectName) + "', OrbLightLight=" + orbLightLight + ", OrbLightTell=" + orbLightTell + ", OrbLightOtherInd=" + orbLightOtherInd + ", OrbLightColl=" + orbLightColl + ", OrbLightVirtMax=" + orbLightVirtMax + ", OrbLightVirtMin=" + orbLightVirtMin + ", OrbTellTell=" + orbTellTell + ", OrbTellOtherInd=" + orbTellOtherInd + ", OrbTellColl=" + orbTellColl + ", OrbTellVirtMax=" + orbTellVirtMax + ", OrbTellVirtMin=" + orbTellVirtMin + ", OrbOtherIndOtherInd=" + orbOtherIndOtherInd + ", OrbOtherIndColl=" + orbOtherIndColl + ", OrbOtherIndVirtMax=" + orbOtherIndVirtMax + ", OrbOtherIndVirtMin=" + orbOtherIndVirtMin + ", OrbCollColl=" + orbCollColl + ", OrbCollVirtMax=" + orbCollVirtMax + ", OrbCollVirtMin=" + orbCollVirtMin + ", OrbVirtMaxVirtMax=" + orbVirtMaxVirtMax + ", OrbVirtMaxVirtMin=" + orbVirtMaxVirtMin + ", OrbVirtMinVirtMin=" + orbVirtMinVirtMin + ", DivMin=" + divMin + ", DivConjuntion=" + divConjuntion + ", DivSextil=" + divSextil + ", DivSquare=" + divSquare + ", DivTrine=" + divTrine + ", DivOpposition=" + divOpposition + ", ChartSelectSingle=" + chartSelectSingle + ", ChartKinds='" + chartKinds + "', ChartDir1Corresp=" + chartDir1Corresp + ", ChartDir2Corresp=" + chartDir2Corresp + ", ChartDirSCorresp=" + chartDirSCorresp + ", ChartDir1Degree=" + chartDir1Degree + ", ChartDir2Day=" + chartDir2Day + ", ChartDirSDegree=" + chartDirSDegree + ", ChartDir1SpaceKind=" + chartDir1SpaceKind + ", ChartDir2SpaceKind=" + chartDir2SpaceKind + ", ChartDirSSpaceKind=" + chartDirSSpaceKind + ", ChartReturnPrecess=" + chartReturnPrecess + ", ChartReturnPlaceID=" + chartReturnPlaceID + ", ChartCyclePlaceID=" + chartCyclePlaceID + ", ChartReturnPlanet=" + chartReturnPlanet + ", ChartCyclePlanet1=" + chartCyclePlanet1 + ", ChartCyclePlanet2=" + chartCyclePlanet2 + ", ChartCompositeNB=" + chartCompositeNB + ", ChartHarmonicNB=" + chartHarmonicNB + " WHERE ID=" + option.getId();
                query = query.replace("'null'", "null");
                statement.executeUpdate(query);
            }
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    private void removeDefaultOptions()
    {
        try
        {
            Statement statement = dataBase.createStatement();
            if (statement == null)
                return;
            statement.executeUpdate("UPDATE OptionsConfiguration SET DefaultConfiguration=0 WHERE DefaultConfiguration!=0");
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }
    
    private int existingDefaultOptions()
    {
        int r = 0;
        
        try
        {
            Statement statement = dataBase.createStatement();
            if (statement == null)
                return -1;
            ResultSet rs = statement.executeQuery("SELECT Count(ID) FROM OptionsConfiguration WHERE DefaultConfiguration!=0");
            while (rs.next())
            {
                r = rs.getInt(1);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return r;
    }

    public boolean removeRecord(Option option)
    {
        rRecord("optionsconfiguration", id);
        option.setRowNB(option.getRowNB() - 1);
        return true;
    }

    private String getNewId()
    {
        return gNewId("optionsconfiguration");
    }

    private int findRow(String id)
    {
        return fRow("optionsconfiguration", id, " ORDER BY ConfigurationName", "optionsconfiguration");
    }

    private int findRowNB()
    {
        return fRowNB("optionsconfiguration", "optionsconfiguration");
    }
}
