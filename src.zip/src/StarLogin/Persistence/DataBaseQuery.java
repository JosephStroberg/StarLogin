package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Query;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class DataBaseQuery extends DataBaseRecord
{
    /** Creates new DataBaseQuery */
    public DataBaseQuery(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
        //setConnection(dataBaseConnection);
    }

    //get the current record
    @SuppressWarnings("unchecked")
    public Query getQuery(String strQuery)
    {
        Query query = new Query();
        
        try
        {
            //Get all the fields
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery(strQuery);
            ArrayList rows = query.getQuery();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            
            ArrayList columnNames = query.getHeaders();
            ArrayList fields = query.getFields();
            ArrayList types = query.getTypes();
            
            for (int i=1; i<=colCount; i++)
            {
                String columnName = metaData.getColumnName(i);
                String columnLabel = metaData.getColumnLabel(i);
                columnNames.add(i-1, columnLabel);
                fields.add(i-1, columnName);
                int type = metaData.getColumnType(i);
                types.add(i-1, new Integer(type).toString());
            }
            rs.close();
            statement.close();
        }
        
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        
        return query;
    }
    
}
