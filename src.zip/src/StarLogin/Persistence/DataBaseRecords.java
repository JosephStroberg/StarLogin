package StarLogin.Persistence;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Records;
import java.sql.*;
import java.util.ArrayList;
import java.util.MissingResourceException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

/**
 *
 * @author Francois DESCHAMPS
 */
public class DataBaseRecords
{
    public static final String HDFORMAT="case when hour(HEURE_DEBUT)>12then case when hour(HEURE_DEBUT)-12<10then'0'||char(hour(HEURE_DEBUT)-12,2)else char(hour(HEURE_DEBUT)-12,2) end else case when hour(HEURE_DEBUT)<10then case when hour(HEURE_DEBUT)=0then'12'else'0'||char(hour(HEURE_DEBUT),2)end else char(hour(HEURE_DEBUT),2) end end||':'||case when minute(HEURE_DEBUT)<10then'0'||char(minute(HEURE_DEBUT),2)else char(minute(HEURE_DEBUT),2)end||':'||case when second(HEURE_DEBUT)<10then'0'||char(second(HEURE_DEBUT),2)else char(second(HEURE_DEBUT),2)end||' '||case when hour(HEURE_DEBUT)<12then'AM'else'PM'end AS HDEBUT";
    public static final String HFFORMAT="case when hour(HEURE_FIN)>12then case when hour(HEURE_FIN)-12<10then'0'||char(hour(HEURE_FIN)-12,2)else char(hour(HEURE_FIN)-12,2) end else case when hour(HEURE_FIN)<10then case when hour(HEURE_FIN)=0then'12'else'0'||char(hour(HEURE_FIN),2)end else char(hour(HEURE_FIN),2) end end||':'||case when minute(HEURE_FIN)<10then'0'||char(minute(HEURE_FIN),2)else char(minute(HEURE_FIN),2)end||':'||case when second(HEURE_FIN)<10then'0'||char(second(HEURE_FIN),2)else char(second(HEURE_FIN),2)end||' '||case when hour(HEURE_FIN)<12then'AM'else'PM'end AS HFIN";
    public static final String T2SURT1X="CASE WHEN T2SURT1=1 THEN 'X' ELSE '' END";
    protected DataBaseConnection dataBase;
    private String sqlFrom = "";
    private String sqlWhere = "";
    protected java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int typeString = 0;
    public static final int typeNumber = 1;
    public static final int typeDate = 2;
    public static final int typeBool = 3;
    public static final int typeIcon = 4;

    //field names
    private String champs[];

    /** Creates new DataBaseClients */
    public DataBaseRecords(DataBaseConnection dataBaseConnection)
    {
        dataBase = dataBaseConnection;
    }

    public DataBaseRecords()
    {
    }

    protected void setConnection(DataBaseConnection dataBaseConnect)
    {
        dataBase = dataBaseConnect;
    }

    //Retrieve the fields from the SELECT query
    @SuppressWarnings("unchecked")
    private void parseFields(String sql)
    {
        ArrayList chps = new ArrayList();
        String fieldsPart = sql;
        int pos = sql.indexOf(StarLogin.Systeme.QueryDescription.STR_FROM);
        if (pos>0)
            fieldsPart = sql.substring(7, pos);
        fieldsPart = fieldsPart.trim();

        while (fieldsPart.length()>0)
        {
            String champ;
            if (fieldsPart.startsWith(HDFORMAT))
            {
                champ = HDFORMAT;
                if (fieldsPart.length()>champ.length())
                    fieldsPart = fieldsPart.substring(champ.length()+1);
                else
                    fieldsPart = "";
                    
            }
            else if (fieldsPart.startsWith(HFFORMAT))
            {
                champ = HFFORMAT;
                if (fieldsPart.length()>champ.length())
                    fieldsPart = fieldsPart.substring(champ.length()+1);
                else
                    fieldsPart = "";
            }
            else if (fieldsPart.startsWith(T2SURT1X))
            {
                champ = T2SURT1X;
                if (fieldsPart.length()>champ.length())
                    fieldsPart = fieldsPart.substring(champ.length()+1);
                else
                    fieldsPart = "";
            }
            else
            {
                pos = fieldsPart.indexOf(",");
                
                if (pos >= 0)
                {
                    //extract a field from the rest of the query string
                    champ = fieldsPart.substring(0, pos);
                    fieldsPart = fieldsPart.substring(pos + 1);
                    if (fieldsPart.startsWith(" "))
                    {
                        fieldsPart = fieldsPart.substring(1);
                    }
                }
                else
                {
                    //the last field
                    champ = fieldsPart;
                    fieldsPart = "";
                }
                //champ = champ.trim();
            }

            chps.add(champ);
        }
        int dim = chps.size();
        champs = new String[dim];
        for (int i=0; i<dim; i++)
        {
            champs[i] = chps.get(i).toString();
        }
    }

    //get the number i field value
    private int getType(int typ)
    {
        switch(typ)
        {
            case Types.NCLOB:
            case Types.CLOB:
            case Types.BLOB:
                return DataBaseRecords.typeIcon;
                
            case Types.BINARY:
            case Types.CHAR:
            case Types.NCHAR:
            case Types.VARCHAR:
            case Types.VARBINARY:
            case Types.NVARCHAR:
            case Types.LONGVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.LONGVARBINARY:
                return DataBaseRecords.typeString;

            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
            case Types.BIGINT:
            case Types.FLOAT:
            case Types.DECIMAL:
            case Types.DOUBLE:
            case Types.NUMERIC:
            case Types.REAL:
            case Types.BIT://or string type?
                return DataBaseRecords.typeNumber;

            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
                return DataBaseRecords.typeDate;

            case Types.BOOLEAN:
                return DataBaseRecords.typeBool;

            default:
                return DataBaseRecords.typeString;
        }
    }

    @SuppressWarnings("unchecked")
    public Records getRecords(String sql, String tableName)
    {
        Records records = new Records();
        parseFields(sql);
        ArrayList types = records.getTypes();
        ArrayList columnNames = records.getHeaders();
        ArrayList fields = records.getFields();
        ArrayList sizes = records.getSizes();

        try
        {
            //Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            if (statement == null)
                return null;
            ResultSet rs = statement.executeQuery(sql);
            sqlFrom = StarLogin.Systeme.QueryDescription.getFromPart(sql);
            sqlWhere = StarLogin.Systeme.QueryDescription.getWherePart(sql);
            records.setFrom(sqlFrom);
            records.setWhere(sqlWhere);
            ArrayList rows = records.getRecords();

            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();
            for (int i = 1; i <= colCount; i++)
            {
                types.add(getType(metaData.getColumnType(i)));
                sizes.add(metaData.getColumnDisplaySize(i));
            }

        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }

        if (tableName.equals("X"))
        {
            for (int i=0; i<champs.length; i++)
            {
                int pos = champs[i].indexOf(" AS ");
                String str;
                String str2;
                if (pos>0)
                {
                    str = champs[i].substring(0, pos);
                    str2 = champs[i].substring(pos+4);
                    str2 = str2.replace("\"", "");
                    columnNames.add(i, str2);
                    fields.add(i, str);
                }
                else
                {
                    columnNames.add(i, champs[i]);
                    fields.add(i, champs[i]);
                }
            }
        }
        else
        {
            columnNames.add(0, "_");
            fields.add(0, champs[0]);
            for (int i=1; i<champs.length; i++)
            {
                String nomChamp = tableName + champs[i].replace(" ", "_");
                if (nomChamp.equals(tableName.concat(HDFORMAT.replace(" ", "_"))))
                    nomChamp = "HEUREDEBUT";
                else if (nomChamp.equals(tableName.concat(HFFORMAT.replace(" ", "_"))))
                    nomChamp = "HEUREFIN";
                else if (nomChamp.equals(tableName.concat(T2SURT1X.replace(" ", "_"))))
                    nomChamp = "T2SURT1X";
                String resource = champs[i];
                try
                {
                    resource = bundle.getString(nomChamp);
                }
                catch (MissingResourceException ex)
                {
                    MainClass.writelog(ex.getMessage());
                }
                columnNames.add(i, resource);
                fields.add(i, champs[i]);
            }
        }
        return records;
    }

    @SuppressWarnings("unchecked")
    public ArrayList getShortRecords(String sql, String tableName)
    {
        ArrayList rows = new ArrayList();
        try
        {
            //Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            ResultSetMetaData metaData = rs.getMetaData();
            int colCount = metaData.getColumnCount();
            while (rs.next())
            {
                ArrayList newRow = new ArrayList();
                for (int i = 1; i <= colCount; i++)
                {
                    newRow.add(rs.getObject(i));
                }
                rows.add(newRow);
            }
            rs.close();
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return null;
        }
        return rows;
    }

    public boolean checkRecord(String table, String sWhere)
    {
        boolean result = false;
        int id = -1;

        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT ID FROM ".concat(table).concat(sWhere));
            if (rs.next())
            {
                id = rs.getInt(1);
                result = true;
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return false;
        }
    }
    

    public String getStringFieldValue(String table, String fieldName, String sWhere)
    {
        String result = "-1";
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            if (statement == null)
            {
                MainClass.setMessage("Database statement is null.");
                return "";
            }
            ResultSet rs;
            rs = statement.executeQuery("SELECT " + fieldName.concat(" FROM ").concat(table).concat(sWhere));
            if (rs.next())
            {
                result = rs.getString(1);
            }
            if (result == null)
                result = "-1";
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            // Print all warnings
            String trace = "";
            StackTraceElement[] tel = ex.getStackTrace();
            for (int i=0; i<tel.length; i++)
            {
                trace = trace.concat("\n").concat(tel[i].toString());
            }

            MainClass.setMessage(ex.getMessage().concat("\n").concat(trace));
            return "";
        }
    }

    public int getIntFieldValue(String table, String fieldName, String sWhere)
    {
        int result = -1;
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT " + fieldName.concat(" FROM ").concat(table).concat(sWhere));
            if (rs.next())
            {
                result = rs.getInt(1);
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return -2;
        }
    }

    public String getMonetaryFieldValue(String table, String fieldName, String sWhere)
    {
        String result = "";
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT " + fieldName.concat(" FROM ").concat(table).concat(sWhere));
            if (rs.next())
            {
                double r = rs.getDouble(1);
                result = String.valueOf(r);
                int pos = result.indexOf(".");
                if (pos < 0)
                {
                    if (result.length()<=2)
                        result = "-0." +  result;
                    else
                        result = "-" + result + ".00";
                }
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return "";
        }
    }

    public String getMainFieldID_S(String table, String fieldName, String fieldValue)
    {
        String result = "-1";
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT ID FROM " + table + " WHERE " +  fieldName + "='" + fieldValue.replace("'", "''") + "'");
            if (rs.next())
            {
                result = rs.getString(1);
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return "";
        }
    }

    public String getMainFieldID_N(String table, String fieldName, String fieldValue)
    {
        String result = "-1";
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT ID FROM " + table + " WHERE " +  fieldName + "=" + fieldValue);
            if (rs.next())
            {
                result = rs.getString(1);
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return "";
        }
    }

    public String lookForField(String partialName, String fieldName, String table, String oldName, String sFilter, String sOrder)
    {
        if (partialName == null) return "";
        String result = "-1";
        try
        {
            // Get all the fields
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            ResultSet rs;
            if (oldName == null || oldName.equals(""))
            {
                rs = statement.executeQuery("SELECT " +  fieldName + " FROM " + table + " WHERE " + sFilter + " AND (" + fieldName + " Like '%" + partialName + "%' OR " +  fieldName + " Like '" + partialName + "%' OR " +  fieldName + " Like '%" + partialName + "') ORDER BY " + sOrder);
            }
            else
            {
                rs = statement.executeQuery("SELECT " +  fieldName + " FROM " + table + " WHERE " + sFilter + " AND (" +  fieldName + " Like '%" + partialName + "%' OR " +  fieldName + " Like '" + partialName + "%' OR " +  fieldName + " Like '%" + partialName + "') AND " + fieldName + ">'" + oldName + "' ORDER BY " + sOrder);
            }
            if (rs.next())
            {
                result = rs.getString(1);
            }
            rs.close();
            statement.close();
            return result;
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return "";
        }
    }

    public void removeFromID(String iD, String tableName)
    {
        try
        {
            if (dataBase == null)
                dataBase = MainClass.starLoginManager.getConnection();
            Statement statement = dataBase.createStatement();
            statement.executeUpdate("DELETE FROM " + tableName + " WHERE ID=" + iD);
            statement.close();
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
    }

    public DefaultComboBoxModel getListe(String query)
    {
        DefaultComboBoxModel comboModel = new DefaultComboBoxModel();

        try
        {
            if (!query.equals(""))
            {
                if (dataBase == null)
                    dataBase = MainClass.starLoginManager.getConnection();
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next())
                {
                    String value = rs.getString(1);
                    if (value == null)
                        value = "";
                    comboModel.addElement(value);//.toUpperCase());
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        return comboModel;
    }

    public DefaultListModel getListe2(String query)
    {
        DefaultListModel listModel = new DefaultListModel();

        try
        {
            if (!query.equals(""))
            {
                if (dataBase == null)
                    dataBase = MainClass.starLoginManager.getConnection();
                Statement statement = dataBase.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next())
                {
                    String value = rs.getString(1);
                    if (value == null)
                        value = "";
                    listModel.addElement(value);//.toUpperCase());
                }
                rs.close();
                statement.close();
            }
        }
        catch (SQLException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        return listModel;
    }
}
