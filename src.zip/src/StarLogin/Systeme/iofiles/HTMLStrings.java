/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package StarLogin.Systeme.iofiles;


import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Enum.AspectType;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.Systeme.Enum.Signs;
import java.awt.Color;

/**
 *
 * @author francoisdeschamps
 */
public class HTMLStrings
{
    private ChartElements chartElements;
    private String aspectKinds[][];
    private boolean bCenter = true;

    public HTMLStrings()
    {
    }

    public HTMLStrings(ChartElements chartElements, String aspectKinds[][])
    {
        this.chartElements = chartElements;
        this.aspectKinds = aspectKinds;
    }

    public void setCenter(boolean value)
    {
        bCenter = value;
    }

    private String rgb2Hex(Color color)
    {
        String hex = "#";
        String s0 = Integer.toHexString(color.getRed());
        if (s0.length() == 1)
        {
            hex = hex.concat("0");
        }
        hex = hex.concat(s0);
        s0 = Integer.toHexString(color.getGreen());
        if (s0.length() == 1)
        {
            hex = hex.concat("0");
        }
        hex = hex.concat(s0);
        s0 = Integer.toHexString(color.getBlue());
        if (s0.length() == 1)
        {
            hex = hex.concat("0");
        }
        hex = hex.concat(s0);
        return hex;
    }

    public String getHTMLPlanet(int i)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color='";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color='";
        }
        sH = sH.concat(rgb2Hex(chartElements.getPlanetColor(i)));
        sH = sH.concat("' face='starlogin' size='3'>");
        sH = sH.concat(Planets.getPlanetSymbol(i));
        sH = sH.concat("</td>");
        return sH;
    }

    public String getHTMLSign(int i)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color='";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color='";
        }
        switch(i)
        {
            case 0:
            case 4:
            case 8:sH = sH.concat(rgb2Hex(chartElements.getFireColor()));break;
            case 1:
            case 5:
            case 9:sH = sH.concat(rgb2Hex(chartElements.getEarthColor()));break;
            case 2:
            case 6:
            case 10:sH = sH.concat(rgb2Hex(chartElements.getAirColor()));break;
            case 3:
            case 7:
            case 11:sH = sH.concat(rgb2Hex(chartElements.getWaterColor()));break;
        }
        sH = sH.concat("' face='starlogin' size='3'>");
        sH = sH.concat(Signs.getSignSymbol(i));
        sH = sH.concat("</td>");
        return sH;
    }

    public String getHTMLSign2(int i)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<font color='";
        }
        else
        {
            sH = "<font color='";
        }
        switch(i)
        {
            case 0:
            case 4:
            case 8:sH = sH.concat(rgb2Hex(chartElements.getFireColor()));break;
            case 1:
            case 5:
            case 9:sH = sH.concat(rgb2Hex(chartElements.getEarthColor()));break;
            case 2:
            case 6:
            case 10:sH = sH.concat(rgb2Hex(chartElements.getAirColor()));break;
            case 3:
            case 7:
            case 11:sH = sH.concat(rgb2Hex(chartElements.getWaterColor()));break;
        }
        sH = sH.concat("' face='starlogin' size='3'>");
        sH = sH.concat(Signs.getSignSymbol(i));
        return sH;
    }

    public String getHTMLAspect(int i, int j)
    {

        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color='";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color='";
        }
        sH = sH.concat(rgb2Hex(AspectType.aspectKindColor(aspectKinds[i][j], chartElements)));
        sH = sH.concat("' face='starlogin' size='3'>");
        sH = sH.concat(aspectKinds[i][j]);
        sH = sH.concat("</font></td>");
        return sH;
    }

    public String getHTMLCaseDebut()
    {

        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b>";
        }
        else
        {
            sH = "<td style='text-align: left;'><b>";
        }
        return sH;
    }

    public String getHTMLCaseFin()
    {
        return "</td>";
    }

    public String processCR(String html)
    {
        html = html.replace("\r\n", "<br>");
        html = html.replace("\\r\\n", "<br>");
        return html;
    }

    public String getHTMLOther(Color color, String fontName, String textElement)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color='";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color='";
        }
        sH = sH.concat(rgb2Hex(color));
        sH = sH.concat("' face='");
        sH = sH.concat(fontName);
        sH = sH.concat("' size='3'>");
        sH = sH.concat(textElement);
        sH = sH.concat("</font></b></td>");
        return sH;
    }

    public String getHTMLOtherS(Color color, String fontName, String textElement, int size)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><font color='";
        }
        else
        {
            sH = "<td style='text-align: left;'><font color='";
        }
        sH = sH.concat(rgb2Hex(color));
        sH = sH.concat("' face='");
        sH = sH.concat(fontName);
        sH = sH.concat("' size='" + size + "'>");
        sH = sH.concat(textElement);
        sH = sH.concat("</font></td>");
        return sH;
    }

    public String getHTMLFont(Color color, String fontName, String textElement)
    {
        String sH = "<font color='";
        sH = sH.concat(rgb2Hex(color));
        sH = sH.concat("' face='");
        sH = sH.concat(fontName);
        sH = sH.concat("' size='3'>");
        sH = sH.concat(textElement);
        sH = sH.concat("</font>");
        return sH;
    }

    public String getHTMLFontS(Color color, String fontName, String textElement, int size)
    {
        String sH = "<font color='";
        sH = sH.concat(rgb2Hex(color));
        sH = sH.concat("' face='");
        sH = sH.concat(fontName);
        sH = sH.concat("' size='" + size + "'>");
        sH = sH.concat(textElement);
        sH = sH.concat("</font>");
        return sH;
    }

    public String getHTMLOther2(String textElement)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color=#000000 face='arial' size='3'>";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color=#000000 face='arial' size='3'>";
        }
        sH = sH.concat(textElement);
        sH = sH.concat("</font></b></td>");
        return sH;
    }

    public String getHTMLOther2S(String textElement, int size)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><font color=#000000 face='arial' size='" + size + "'>";
        }
        else
        {
            sH = "<td style='text-align: left;'><font color=#000000 face='arial' size='" + size + "'>";
        }
        sH = sH.concat(textElement);
        sH = sH.concat("</font></td>");
        return sH;
    }

    public String getHTMLOther2SB(String textElement, int size)
    {
        String sH;
        if (bCenter == true)
        {
            sH = "<td style='text-align: center;'><b><font color=#000000 face='arial' size='" + size + "'>";
        }
        else
        {
            sH = "<td style='text-align: left;'><b><font color=#000000 face='arial' size='" + size + "'>";
        }
        sH = sH.concat(textElement);
        sH = sH.concat("</font></b></td>");
        return sH;
    }

    

}
