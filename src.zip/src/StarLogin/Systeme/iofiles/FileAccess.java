/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package StarLogin.Systeme.iofiles;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Enum.OS;
import java.io.*;
import java.nio.CharBuffer;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author francoisdeschamps
 */
public class FileAccess
{
    
    public static String readFile(String fileName)
    {
        return readFile(fileName, "UTF8");
    }
    
    public static String readFile(String fileName, String charset)
    {
        String content = "";
        int buffersize = (int)(getFileSize(fileName) + 2);
        
        try
        {
            try
            {
                FileInputStream fis = new FileInputStream(fileName);
                InputStreamReader isr = new InputStreamReader(fis, charset);
                Reader r = new BufferedReader(isr);
                CharBuffer cb = CharBuffer.allocate(buffersize);
                try
                {
                    r.read(cb);
                }
                catch (IOException ex)
                {
                    MainClass.setMessage(ex.getMessage(), JOptionPane.ERROR_MESSAGE);
                }
                char[] buffer = cb.array();
                content = String.valueOf(buffer);
                try
                {
                    isr.close();
                    r.close();
                }
                catch (IOException ex)
                {
                    MainClass.setMessage(ex.getMessage(), JOptionPane.ERROR_MESSAGE);
                }
            }
            catch (FileNotFoundException ex)
            {
                MainClass.setMessage(ex.getMessage(), JOptionPane.ERROR_MESSAGE);
            }
        }
        catch (UnsupportedEncodingException ex)
        {
            MainClass.setMessage(ex.getMessage(), JOptionPane.ERROR_MESSAGE);
        }
        return content;
    }
    
    public static long getFileSize(String filename)
    {
        File fichier = new File(filename);
        if (fichier.isFile())
            return fichier.length();
        else
            return -1;
    }
    
    public static String readFile(String fileName, int buffersize)
    {
        String content = "";
        try
        {
            File serveurFile = new File(fileName);
            String absolutePath = new java.io.File("").getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
            //absolutePath = getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
            FileReader fr;
            if (fileName.contains(StarLogin.Systeme.Enum.OS.getSeparator()))
                fr = new FileReader(fileName);
            else
                fr = new FileReader(absolutePath + StarLogin.Systeme.Enum.OS.getSeparator() + serveurFile);
            CharBuffer cb = CharBuffer.allocate(buffersize);
            int size = 0;
            try
            {
                size = fr.read(cb);
                fr.close();
            }
            catch(java.io.IOException ex)
            {
                MainClass.setMessage(ex.getMessage());
            }
            char[] buffer = cb.array();
            /*for (int i=0; i<size; i++)
            {
                char c = cb.get(i);
                content = content.concat(String.valueOf(c));
            }*/
            content = String.valueOf(buffer);
        }
        catch(java.io.FileNotFoundException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        return content;
    }

    public static String readFile(String fileName, int buffersize, boolean bFileNotFoundMessage)
    {
        String content = "";
        try
        {
            String absolutePath = new java.io.File(fileName).getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
            FileReader fr;
            if (fileName.contains(StarLogin.Systeme.Enum.OS.getSeparator()))
                fr = new FileReader(fileName);
            else
                fr = new FileReader(absolutePath);
            CharBuffer cb = CharBuffer.allocate(buffersize);
            int size = 0;
            try
            {
                size = fr.read(cb);
                fr.close();
            }
            catch(java.io.IOException ex)
            {
               MainClass.setMessage(ex.getMessage());
            }
            for (int i=0; i<size; i++)
            {
                char c = cb.get(i);
                content = content + String.valueOf(c);
            }
        }
        catch(java.io.FileNotFoundException ex)
        {
            if (bFileNotFoundMessage)
               MainClass.setMessage(ex.getMessage());
        }
        return content;
    }
    
    public static void createDir(String dirName)
    {
        File file = new java.io.File(dirName);
        FileSystemView fsv = FileSystemView.getFileSystemView();
        if (fsv.isFileSystem(file))
        {
            file.mkdir();
        }
    }
    
    public static void deleteFile(String fileName)
    {
        File file = new java.io.File(fileName);
        file.delete();
    }

    public static boolean writeFile(String fileName, String content)
    {
        File file = new java.io.File(fileName);
        String absolutePath = file.getAbsolutePath().replace("/starlogin8.app/Contents/Resources/Java", "");
        FileSystemView fsv = FileSystemView.getFileSystemView();
        int pos = fileName.lastIndexOf(OS.getSeparator());
        if (pos>0)
            fileName = fileName.substring(0, pos);
        file = new java.io.File(fileName); 
        if (fsv.isFileSystem(file))
        {
            file.mkdir();
        }

        if (content == null)
            return false;
        FileWriter fw;
        try
        {
            fw = new FileWriter(absolutePath);
            fw.write(content);
            fw.close();
            return true;
        }
        catch (IOException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return false;
        }
    }
}


