package StarLogin.Systeme;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import StarLogin.IHM.DialogDoc;
import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.Data.ConstellationBoundaries;
import StarLogin.Systeme.Data.Part;
import StarLogin.Systeme.Enum.*;
import StarLogin.Systeme.iofiles.HTMLStrings;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JDialog;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

public class ChartResults
{
    //private static int windowNB = 0;
    private ChartElements chartElements;
    private String aspectKinds[][];
    private double aspectValues[][];
    private String relativeAspects[][];
    private short spire[][];
    private String sHtml;
    private int tableau_flag;
    //private DialogDoc docForm = new DialogDoc();
    private int chartsNB = 1;
    private HTMLDocument doc = new HTMLDocument();// docForm.getDocument();
    private ChartEvent chartEvent;
    private String sText = "&nbsp;";
    private AllCoord pos1 = new AllCoord();
    private AllCoord pos2 = new AllCoord();
    private double val_asp = 0.0;
    private double ci = 0.0;
    private double cj = 0.0;
    private double mi_point;
    private double aux1;
    private double aux2;
    private double partsAS[][] = new double[Planets.MC + 1][Planets.MC + 1];
    private double partsMC[][] = new double[Planets.MC + 1][Planets.MC + 1];
    private double midpoints[][] = new double[Planets.MC + 1][Planets.MC + 1];
    private ArrayList events = new ArrayList();                                           //events for both inner and outer charts
    private ArrayList positions = new ArrayList();                                        //positions for both inner and outer charts
    private StarLoginManager starLoginManager;
    private HTMLStrings htmlStrings;
    private java.util.ResourceBundle bundle = MainClass.bundle;

    public ChartResults(ChartElements chartElements, String aspectKinds[][], double aspectValues[][], String relativeAspects[][], short spire[][], ChartResultsKinds chartResultsKinds, int tableau_flag, StarLoginManager starLoginManager)
    {
        this.starLoginManager = starLoginManager;
        for (int i = 0; i <= Planets.MC; i++)
        {
            for (int j = 0; j <= Planets.MC; j++)
            {
                partsAS[i][j] = -999.0;
            }
        }
        for (int i = 0; i <= Planets.MC; i++)
        {
            for (int j = 0; j <= Planets.MC; j++)
            {
                partsMC[i][j] = -999.0;
            }
        }
        for (int i = 0; i <= Planets.MC; i++)
        {
            for (int j = 0; j <= Planets.MC; j++)
            {
                midpoints[i][j] = -999.0;
            }
        }
        this.chartElements = chartElements;
        this.aspectKinds = aspectKinds;
        htmlStrings = new HTMLStrings(chartElements, aspectKinds);
        this.aspectValues = aspectValues;
        this.relativeAspects = relativeAspects;
        this.spire = spire;
        this.tableau_flag = tableau_flag;

        events = chartElements.getChartEvents();                                           //events for both inner and outer charts
        positions = chartElements.getChartCoords();                                        //positions for both inner and outer charts

        if (events.size() != positions.size())
        {
            return;
        }

        String title = bundle.getString("ChartResults");

        chartEvent = (ChartEvent) events.get(0);
        pos1 = (AllCoord) positions.get(0);
        pos2 = new AllCoord();

        if (positions.size() > 1)
        {
            pos2 = (AllCoord) positions.get(1);
            chartsNB = 2;
        }

        //Header
        sHtml = "<p style='background-color: #FFE1C3;' align='center' width='75%'><b><font color='#C300FF' face='arial' size='5'>";
        sHtml = sHtml.concat(bundle.getString("ChartResults"));
        sHtml = sHtml.concat("</font></b>");
        
        sHtml = sHtml.concat("<p style=' align='center'><b><font color='#0000ff' face='arial' size='2'>");
        sHtml = sHtml.concat(chartElements.getChartHeader());
        sHtml = sHtml.concat("</font></b>");
        


        boolean[] selections = chartResultsKinds.getSelections();
        if (selections[ChartResultsKinds.aspects])
        {
            getAspects();
        }

        if (selections[ChartResultsKinds.aspectsValue])
        {
            getAspectsValue();
        }

        if (selections[ChartResultsKinds.relativeAspects])
        {
            getRelativeAspects();
        }

        if (selections[ChartResultsKinds.parallels])
        {
            getParallels();
        }

        if (selections[ChartResultsKinds.orbsOfParallels])
        {
            getOrbsOfParallels();
        }

        if (selections[ChartResultsKinds.midpoints])
        {
            getMidpoints();
        }

        if (selections[ChartResultsKinds.treeOfMidpoints])
        {
            if (selections[ChartResultsKinds.midpoints] == false)
            {
                prepareTreeOfMidpoints();
            }
            getTreeOfMidpoints();
        }

        if (selections[ChartResultsKinds.trueMidpoints])
        {
            getTrueMidpoints();
        }

        if (selections[ChartResultsKinds.treeOfTrueMidpoints])
        {
            if (selections[ChartResultsKinds.trueMidpoints] == false)
            {
                prepareTreeOfTrueMidpoints();
            }
            getTreeOfTrueMidpoints();
        }

        if (selections[ChartResultsKinds.arabianParts])
        {
            getArabianParts();
        }

        if (selections[ChartResultsKinds.treeOfArabianParts])
        {
            if (selections[ChartResultsKinds.arabianParts] == false)
            {
                prepareTreeOfArabianParts();
            }
            getTreeOfArabianParts();
        }

        if (selections[ChartResultsKinds.definedArabianParts])
        {
            getDefinedArabianParts();
        }

        if (selections[ChartResultsKinds.treeOfDefinedArabianParts])
        {
            if (selections[ChartResultsKinds.definedArabianParts] == false)
            {
                prepareTreeOfDefinedArabianParts();
            }
            getTreeOfDefinedArabianParts();
        }

        if (selections[ChartResultsKinds.distancesAndCoordinates])
        {
            getDistancesAndCoordinates();
        }

        if (selections[ChartResultsKinds.planetsPropetiesOfChart])
        {
            getPlanetsPropertiesOfChart();
        }
        Element firstElement = doc.getElement(doc.getDefaultRootElement(), StyleConstants.NameAttribute, HTML.Tag.BODY);
        try
        {
            HTMLEditorKit.Parser parser = new javax.swing.text.html.parser.ParserDelegator();
            doc.setParser(parser);
            sHtml = htmlStrings.processCR(sHtml);
            doc.setInnerHTML(firstElement, sHtml);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (java.io.IOException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        //docForm.resetUndo();
        //docForm.getTextPane().setSelectionStart(0);
        //docForm.getTextPane().setSelectionEnd(0);
        //docForm.setVisible(true);
        //docForm.setExtendedState(DialogDoc.MAXIMIZED_BOTH);
        DialogDoc docForm = new DialogDoc(new JDialog(), true, doc, title);
    }

    private void getAspects()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.aspects));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        sHtml = sHtml.concat(htmlStrings.getHTMLAspect(i, j));
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getAspectsValue()
    {
        if (chartElements.getChartKind() == ChartKind.local)
        {
            //Header
            sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
            sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.aspectsValue));
            sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

            //detail
            for (int i = 0; i <= Planets.MC; i++)
            {
                if (chartElements.getShownObject(i))
                {
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                }
            }
            sHtml = sHtml.concat("</tr>");
            for (int i = 0; i <= Planets.MC; i++)
            {
                if (chartElements.getShownObject(i))
                {
                    sHtml = sHtml.concat("<tr>");
                    for (int j = 0; j <= Planets.MC; j++)
                    {
                        if (chartElements.getShownObject(j))
                        {
                            if (j == 0)
                            {
                                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                            }
                            if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                            {
                                if (j == i)
                                {
                                    j += 1;
                                    if (j <= Planets.MC)
                                    {
                                        sHtml = sHtml.concat("<td>&nbsp;</td>");
                                    }
                                }
                                if (j > Planets.MC)
                                {
                                    break;
                                }
                            }

                            if (chartElements.getShownObject(j))
                            {
                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2:
                                        ci = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_1_2:
                                        ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2_1:
                                        ci = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                        cj = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                        break;
                                }
                                val_asp = AstronomyMaths.modulo(ci - cj, 360.0);
                                if (val_asp > 180.0)
                                {
                                    val_asp = 360.0 - val_asp;
                                }
                                String sText0 = new FDegree(val_asp).getShortDegree();
                                sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText0));
                            }
                        }
                    }
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }
        else
        {
            //Header
            sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
            sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.aspectsValue));
            sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

            //detail
            for (int i = 0; i <= Planets.MC; i++)
            {
                if (chartElements.getShownObject(i))
                {
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                }
            }
            sHtml = sHtml.concat("</tr>");
            for (int i = 0; i <= Planets.MC; i++)
            {
                if (chartElements.getShownObject(i))
                {
                    sHtml = sHtml.concat("<tr>");
                    for (int j = 0; j <= Planets.MC; j++)
                    {
                        if (chartElements.getShownObject(j))
                        {
                            if (j == 0)
                            {
                                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                            }
                            if (aspectKinds[i][j].equals(""))
                            {
                                if (j <= Planets.MC)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            else
                            {
                                sText = new FDegree(aspectValues[i][j]).getShortDegree();
                                sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                            }
                        }
                    }
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }
    }

    private void getRelativeAspects()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.relativeAspects));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        if (!relativeAspects[i][j].equals(""))
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                            sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(relativeAspects[i][j], chartElements), "starlogin", relativeAspects[i][j]));
                            sHtml = sHtml.concat("&nbsp;");
                            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "�" + spire[i][j]));
                            sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                        }
                        else
                        {
                            if (j <= Planets.MC)
                            {
                                sHtml = sHtml.concat("<td>&nbsp;</td>");
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getParallels()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.parallels));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j <= Planets.MC)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            //orb
                            double orbe;
                            if (i <= j)
                            {
                                orbe = AspectType.orbCalculation(i, j, AspectType.Inconjunct, chartElements);
                            }
                            else
                            {
                                orbe = AspectType.orbCalculation(j, i, AspectType.Inconjunct, chartElements);
                            }
                            orbe = Math.sqrt(Math.abs(orbe * 2.0 / 3.0));

                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;
                            }
                            val_asp = Math.abs(Math.abs(ci) - Math.abs(cj));
                            if (Math.abs(val_asp) <= orbe)
                            {
                                //parallels
                                if (AstronomyMaths.sgn(ci) == AstronomyMaths.sgn(cj))
                                {
                                    sText = new FDegree(ci).getShortDegree() + "\\\\" + new FDegree(cj).getShortDegree();
                                }
                                //antiparallels
                                else
                                {
                                    sText = new FDegree(ci).getShortDegree() + "\\^" + new FDegree(cj).getShortDegree();
                                }
                            }
                            else
                            {
                                sText = "&nbsp;";
                            }
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getOrbsOfParallels()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.orbsOfParallels));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j <= Planets.MC)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;
                            }
                            val_asp = Math.abs(Math.abs(ci) - Math.abs(cj));
                            sText = new FDegree(val_asp).getShortDegree();
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getMidpoints()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.midpoints));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j <= Planets.MC)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            mi_point = (ci + cj) / 2.0;
                            if (Math.abs(ci - cj) > 180.0)
                            {
                                mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                            }
                            midpoints[i][j] = mi_point;
                            sText = new FDegree(mi_point).getShortDegree();
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void prepareTreeOfMidpoints()
    {
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            mi_point = (ci + cj) / 2.0;
                            if (Math.abs(ci - cj) > 180.0)
                            {
                                mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                            }
                            midpoints[i][j] = mi_point;
                        }
                    }
                }
            }
        }
    }

    private void getTreeOfMidpoints()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfMidpoints));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = 0.0;
                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                {
                    position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                }

                //midpoints
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k <= Planets.MC; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double midpoint = midpoints[j][k];
                                if (midpoint != -999.0)
                                {
                                    double delta = AstronomyMaths.modulo(position1 - midpoint, 360.0);
                                    if (delta > 180.0)
                                    {
                                        delta = 360.0 - delta;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the midpoint
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", Planets.getPlanetSymbol(j)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", Planets.getPlanetSymbol(k)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta = AstronomyMaths.modulo(position2 - midpoint, 360.0);
                                        if (delta > 180.0)
                                        {
                                            delta = 360.0 - delta;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the midpoint
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", Planets.getPlanetSymbol(j)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", Planets.getPlanetSymbol(k)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");

        //reinitialize the array for tree of true midpoints
        for (int i = 0; i <= Planets.MC; i++)
        {
            for (int j = 0; j <= Planets.MC; j++)
            {
                midpoints[i][j] = -999.0;
            }
        }
    }

    private void getTrueMidpoints()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.trueMidpoints));
        sHtml = sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }

                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j <= Planets.MC)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;

                            //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                            //emplacement en ligne et colonne
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    //Calculation of the mid-point
                                    // aux1 = cos(ecart) et aux2 = cos(1/2 ecart)
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;
                            }

                            aux1 = AstronomyMaths.sinD(cj2) * AstronomyMaths.sinD(ci2) + AstronomyMaths.cosD(cj2) * AstronomyMaths.cosD(ci2) * AstronomyMaths.cosD(cj1 - ci1);
                            aux2 = Math.sqrt((1.0 + aux1) / 2.0);
                            double valeur;

                            //coordonnee 2 du mi-point
                            if (aux2 != 0)
                            {
                                valeur = AstronomyMaths.asinD(AstronomyMaths.sinD(cj2) * aux2 + (AstronomyMaths.sinD(ci2) - AstronomyMaths.sinD(cj2) * aux1) / 2.0 / aux2);
                            }
                            else
                            {
                                valeur = 0.0;
                            }

                            //coordonnee 1 du mi-point
                            if (aux2 != 0)
                            {
                                mi_point = ci1 + AstronomyMaths.asinD(AstronomyMaths.sinD(cj1 - ci1) * AstronomyMaths.cosD(ci2) / 2.0 / aux2 / AstronomyMaths.cosD(valeur));
                            }
                            else
                            {
                                mi_point = ci1 + 90.0;
                            }
                            mi_point = AstronomyMaths.modulo(mi_point, 360.0);
                            midpoints[i][j] = mi_point;
                            sText = new FDegree(mi_point).getShortDegree();
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void prepareTreeOfTrueMidpoints()
    {
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                            }
                            if (j > Planets.MC)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j))
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;

                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord2(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord2(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord2(chartElements.getCoordSys());
                                    break;
                            }

                            aux1 = AstronomyMaths.sinD(cj2) * AstronomyMaths.sinD(ci2) + AstronomyMaths.cosD(cj2) * AstronomyMaths.cosD(ci2) * AstronomyMaths.cosD(cj1 - ci1);
                            aux2 = Math.sqrt((1.0 + aux1) / 2.0);
                            double valeur;

                            //coordonnee 2 du mi-point
                            if (aux2 != 0)
                            {
                                valeur = AstronomyMaths.asinD(AstronomyMaths.sinD(cj2) * aux2 + (AstronomyMaths.sinD(ci2) - AstronomyMaths.sinD(cj2) * aux1) / 2.0 / aux2);
                            }
                            else
                            {
                                valeur = 0.0;
                            }

                            //coordonnee 1 du mi-point
                            if (aux2 != 0)
                            {
                                mi_point = ci1 + AstronomyMaths.asinD(AstronomyMaths.sinD(cj1 - ci1) * AstronomyMaths.cosD(ci2) / 2.0 / aux2 / AstronomyMaths.cosD(valeur));
                            }
                            else
                            {
                                mi_point = ci1 + 90.0;
                            }
                            mi_point = AstronomyMaths.modulo(mi_point, 360.0);
                            midpoints[i][j] = mi_point;
                        }
                    }
                }
            }
        }
    }

    private void getTreeOfTrueMidpoints()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfTrueMidpoints));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = 0.0;
                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                {
                    position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                }

                //midpoints
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k <= Planets.MC; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double midpoint = midpoints[j][k];
                                if (midpoint != -999.0)
                                {
                                    double delta = AstronomyMaths.modulo(position1 - midpoint, 360.0);
                                    if (delta > 180.0)
                                    {
                                        delta = 360.0 - delta;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the midpoint
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", Planets.getPlanetSymbol(j)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", Planets.getPlanetSymbol(k)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta = AstronomyMaths.modulo(position2 - midpoint, 360.0);
                                        if (delta > 180.0)
                                        {
                                            delta = 360.0 - delta;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the midpoint
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", Planets.getPlanetSymbol(j)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", Planets.getPlanetSymbol(k)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getArabianParts()
    {
        double part;

        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.arabianParts) + " / " + Planets.getPlanetName(Planets.AS));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>");

        //
        String sFortune = bundle.getString("Fortune");
        if (tableau_flag == Astrology.POS_2_1)
        {
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.blue, "arial", sFortune + " <br>= (" + sFortune + " 1 + " + sFortune + " 2) / 2"));
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
        }
        else if (tableau_flag == Astrology.POS_1_2)
        {
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.blue, "arial", sFortune + " <br>= (" + Planets.getPlanetName(Planets.AS) + " 1 + " + Planets.getPlanetName(Planets.AS) + " 2) / 2 <br>+ (" + Planets.getPlanetName(Planets.Sun) + " 1 + " + Planets.getPlanetName(Planets.Sun) + " 2) / 2 <br>- (" + Planets.getPlanetName(Planets.Moon) + " 1 + " + Planets.getPlanetName(Planets.Moon) + " 2) / 2"));
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
        }
        else
        {
            sHtml = sHtml.concat("<td>&nbsp;</td>");
        }

        //detail
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }

                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j < Planets.AS)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.AS)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j) && j < Planets.AS)
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;
                            double cAS1 = 0.0;
                            double cAS2 = 0.0;

                            //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                            //emplacement en ligne et colonne
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = cAS1;
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS1 = cAS2;
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    cAS1 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            if (tableau_flag == Astrology.POS_2_1)
                            {
                                double part1 = AstronomyMaths.modulo(cAS1 + ci1 - cj1, 360);
                                double part2 = AstronomyMaths.modulo(cAS2 + ci2 - cj2, 360);
                                mi_point = (part1 + part2) / 2.0;
                                if (Math.abs(part1 - part2) > 180.0)
                                {
                                    mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                }
                                part = mi_point;
                            }
                            else
                            {
                                double mi_pointAS = (cAS1 + cAS2) / 2.0;
                                if (Math.abs(cAS1 - cAS2) > 180.0)
                                {
                                    mi_pointAS = AstronomyMaths.modulo(mi_pointAS + 180.0, 360.0);
                                }
                                double mi_pointPlus = (ci1 + ci2) / 2.0;
                                if (Math.abs(ci1 - ci2) > 180.0)
                                {
                                    mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                }
                                double mi_pointMinus = (cj1 + cj2) / 2.0;
                                if (Math.abs(cj1 - cj2) > 180.0)
                                {
                                    mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                }
                                part = AstronomyMaths.modulo(mi_pointAS + mi_pointPlus - mi_pointMinus, 360);
                            }
                            partsAS[i][j] = part;
                            sText = new FDegree(part).getShortDegree();
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");


        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.arabianParts) + " / " + Planets.getPlanetName(Planets.MC));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }

                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                                if (j < Planets.AS)
                                {
                                    sHtml = sHtml.concat("<td>&nbsp;</td>");
                                }
                            }
                            if (j > Planets.AS)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j) && j < Planets.AS)
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;
                            double cMC1 = 0.0;
                            double cMC2 = 0.0;

                            //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                            //emplacement en ligne et colonne
                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = cMC1;
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC1 = cMC2;
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    cMC1 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            double mi_pointMC = (cMC1 + cMC2) / 2.0;
                            if (Math.abs(cMC1 - cMC2) > 180.0)
                            {
                                mi_pointMC = AstronomyMaths.modulo(mi_pointMC + 180.0, 360.0);
                            }
                            double mi_pointPlus = (ci1 + ci2) / 2.0;
                            if (Math.abs(ci1 - ci2) > 180.0)
                            {
                                mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                            }
                            double mi_pointMinus = (cj1 + cj2) / 2.0;
                            if (Math.abs(cj1 - cj2) > 180.0)
                            {
                                mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                            }
                            part = AstronomyMaths.modulo(mi_pointMC + mi_pointPlus - mi_pointMinus, 360);
                            partsMC[i][j] = part;
                            sText = new FDegree(part).getShortDegree();
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void prepareTreeOfArabianParts()
    {
        double part;

        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                            }
                            if (j >= Planets.AS)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j) && j < Planets.AS)
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;
                            double cAS1 = 0.0;
                            double cAS2 = 0.0;

                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = cAS1;
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS1 = cAS2;
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    cAS1 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    cAS2 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            if (tableau_flag == Astrology.POS_2_1)
                            {
                                double part1 = AstronomyMaths.modulo(cAS1 + ci1 - cj1, 360);
                                double part2 = AstronomyMaths.modulo(cAS2 + ci2 - cj2, 360);
                                mi_point = (part1 + part2) / 2.0;
                                if (Math.abs(part1 - part2) > 180.0)
                                {
                                    mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                }
                                part = mi_point;
                            }
                            else
                            {
                                double mi_pointAS = (cAS1 + cAS2) / 2.0;
                                if (Math.abs(cAS1 - cAS2) > 180.0)
                                {
                                    mi_pointAS = AstronomyMaths.modulo(mi_pointAS + 180.0, 360.0);
                                }
                                double mi_pointPlus = (ci1 + ci2) / 2.0;
                                if (Math.abs(ci1 - ci2) > 180.0)
                                {
                                    mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                }
                                double mi_pointMinus = (cj1 + cj2) / 2.0;
                                if (Math.abs(cj1 - cj2) > 180.0)
                                {
                                    mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                }
                                part = AstronomyMaths.modulo(mi_pointAS + mi_pointPlus - mi_pointMinus, 360);
                            }
                            partsAS[i][j] = part;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            if (j == i)
                            {
                                j += 1;
                            }
                            if (j >= Planets.AS)
                            {
                                break;
                            }
                        }

                        if (chartElements.getShownObject(j) && j < Planets.AS)
                        {
                            double ci1 = 0.0;
                            double ci2 = 0.0;
                            double cj1 = 0.0;
                            double cj2 = 0.0;
                            double cMC1 = 0.0;
                            double cMC2 = 0.0;

                            switch (tableau_flag)
                            {
                                case Astrology.POS_1:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = cMC1;
                                    break;

                                case Astrology.POS_2:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = ci1;
                                    cj2 = cj1;
                                    cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC1 = cMC2;
                                    break;

                                case Astrology.POS_1_2:
                                    ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    break;

                                case Astrology.POS_2_1:
                                    ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                    cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                    ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                    cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                    cMC1 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    cMC2 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                    break;
                            }
                            double mi_pointMC = (cMC1 + cMC2) / 2.0;
                            if (Math.abs(cMC1 - cMC2) > 180.0)
                            {
                                mi_pointMC = AstronomyMaths.modulo(mi_pointMC + 180.0, 360.0);
                            }
                            double mi_pointPlus = (ci1 + ci2) / 2.0;
                            if (Math.abs(ci1 - ci2) > 180.0)
                            {
                                mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                            }
                            double mi_pointMinus = (cj1 + cj2) / 2.0;
                            if (Math.abs(cj1 - cj2) > 180.0)
                            {
                                mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                            }
                            part = AstronomyMaths.modulo(mi_pointMC + mi_pointPlus - mi_pointMinus, 360);
                            partsMC[i][j] = part;
                        }
                    }
                }
            }
        }
    }

    private void getTreeOfArabianParts()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfArabianParts) + " / " + Planets.getPlanetName(Planets.AS));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                //double orb = 1.0 / chartElements.getDivMin();

                //midpoints
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k < Planets.AS; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double part = partsAS[j][k];
                                if (part != -999.0)
                                {
                                    double delta = AstronomyMaths.modulo(position1 - part, 360.0);
                                    if (delta > 180.0)
                                    {
                                        delta = 360.0 - delta;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the part
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(Planets.AS), "starlogin", Planets.getPlanetSymbol(Planets.AS)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", "+" + Planets.getPlanetSymbol(j)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", "-" + Planets.getPlanetSymbol(k)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta = AstronomyMaths.modulo(position2 - part, 360.0);
                                        if (delta > 180.0)
                                        {
                                            delta = 360.0 - delta;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the part
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(Planets.AS), "starlogin", Planets.getPlanetSymbol(Planets.AS)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", "+" + Planets.getPlanetSymbol(j)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", "-" + Planets.getPlanetSymbol(k)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");

        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfArabianParts) + " / " + Planets.getPlanetName(Planets.MC));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = 0.0;
                if (chartsNB == 2)
                {
                    position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                }

                //midpoints
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k < Planets.AS; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double part = partsMC[j][k];
                                if (part != -999.0)
                                {
                                    double delta = AstronomyMaths.modulo(position1 - part, 360.0);
                                    if (delta > 180.0)
                                    {
                                        delta = 360.0 - delta;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the part
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(Planets.MC), "starlogin", Planets.getPlanetSymbol(Planets.MC)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", "+" + Planets.getPlanetSymbol(j)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", "-" + Planets.getPlanetSymbol(k)));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta = AstronomyMaths.modulo(position2 - part, 360.0);
                                        if (delta > 180.0)
                                        {
                                            delta = 360.0 - delta;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                delta = Math.abs(delta - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the part
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(Planets.MC), "starlogin", Planets.getPlanetSymbol(Planets.MC)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(j), "starlogin", "+" + Planets.getPlanetSymbol(j)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(chartElements.getPlanetColor(k), "starlogin", "-" + Planets.getPlanetSymbol(k)));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");

        //reinitialize the array for tree of defined arabian parts
        for (int i = 0; i < Planets.AS; i++)
        {
            for (int j = 0; j < Planets.AS; j++)
            {
                partsAS[i][j] = -999.0;
            }
        }
        for (int i = 0; i < Planets.AS; i++)
        {
            for (int j = 0; j < Planets.AS; j++)
            {
                partsMC[i][j] = -999.0;
            }
        }
    }

    private void getDefinedArabianParts()
    {
        double part;

        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.definedArabianParts) + " / " + Planets.getPlanetName(Planets.AS));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>");

        //
        String sFortune = bundle.getString("Fortune");
        if (tableau_flag == Astrology.POS_2_1)
        {
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.blue, "arial", sFortune + " <br>= (" + sFortune + " 1 + " + sFortune + " 2) / 2"));
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
        }
        else if (tableau_flag == Astrology.POS_1_2)
        {
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
            sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.blue, "arial", sFortune + " <br>= (" + Planets.getPlanetName(Planets.AS) + " 1 + " + Planets.getPlanetName(Planets.AS) + " 2) / 2 <br>+ (" + Planets.getPlanetName(Planets.Sun) + " 1 + " + Planets.getPlanetName(Planets.Sun) + " 2) / 2 <br>- (" + Planets.getPlanetName(Planets.Moon) + " 1 + " + Planets.getPlanetName(Planets.Moon) + " 2) / 2"));
            sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
        }
        else
        {
            sHtml = sHtml.concat("<td>&nbsp;</td>");
        }

        //detail
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        Part p = starLoginManager.getPartFrom(new Integer(Planets.AS).toString(), new Integer(i).toString(), new Integer(j).toString());
                        String sPart = p.getPart();
                        if (!sPart.equals(""))
                        {
                            if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                            {
                                if (j == i)
                                {
                                    j += 1;
                                    if (j <= Planets.MC)
                                    {
                                        sHtml = sHtml.concat("<td>&nbsp;</td>");
                                    }
                                }
                                if (j > Planets.MC)
                                {
                                    break;
                                }
                            }

                            if (chartElements.getShownObject(j) && j <= Planets.MC)
                            {
                                double ci1 = 0.0;
                                double ci2 = 0.0;
                                double cj1 = 0.0;
                                double cj2 = 0.0;
                                double cAS1 = 0.0;
                                double cAS2 = 0.0;

                                //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                                //emplacement en ligne et colonne
                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = cAS1;
                                        break;

                                    case Astrology.POS_2:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS1 = cAS2;
                                        break;

                                    case Astrology.POS_1_2:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2_1:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        cAS1 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        break;
                                }
                                if (tableau_flag == Astrology.POS_2_1)
                                {
                                    double part1 = AstronomyMaths.modulo(cAS1 + ci1 - cj1, 360.0);
                                    double part2 = AstronomyMaths.modulo(cAS2 + ci2 - cj2, 360.0);
                                    mi_point = (part1 + part2) / 2.0;
                                    if (Math.abs(part1 - part2) > 180.0)
                                    {
                                        mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                    }
                                    part = mi_point;
                                }
                                else
                                {
                                    double mi_pointAS = (cAS1 + cAS2) / 2.0;
                                    if (Math.abs(cAS1 - cAS2) > 180.0)
                                    {
                                        mi_pointAS = AstronomyMaths.modulo(mi_pointAS + 180.0, 360.0);
                                    }
                                    double mi_pointPlus = (ci1 + ci2) / 2.0;
                                    if (Math.abs(ci1 - ci2) > 180.0)
                                    {
                                        mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                    }
                                    double mi_pointMinus = (cj1 + cj2) / 2.0;
                                    if (Math.abs(cj1 - cj2) > 180.0)
                                    {
                                        mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                    }
                                    part = AstronomyMaths.modulo(mi_pointAS + mi_pointPlus - mi_pointMinus, 360);
                                }
                                sText = new FDegree(part).getShortDegree();
                                sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                                partsAS[i][j] = part;
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");


        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.definedArabianParts) + " / " + Planets.getPlanetName(Planets.MC));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
            }
        }
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (j == 0)
                        {
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                        }
                        Part p = starLoginManager.getPartFrom(new Integer(Planets.MC).toString(), new Integer(i).toString(), new Integer(j).toString());
                        String sPart = p.getPart();
                        if (!sPart.equals(""))
                        {
                            if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                            {
                                if (j == i)
                                {
                                    j += 1;
                                    if (j <= Planets.MC)
                                    {
                                        sHtml = sHtml.concat("<td>&nbsp;</td>");
                                    }
                                }
                                if (j > Planets.MC)
                                {
                                    break;
                                }
                            }

                            if (chartElements.getShownObject(j) && j <= Planets.MC)
                            {
                                double ci1 = 0.0;
                                double ci2 = 0.0;
                                double cj1 = 0.0;
                                double cj2 = 0.0;
                                double cMC1 = 0.0;
                                double cMC2 = 0.0;

                                //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                                //emplacement en ligne et colonne
                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = cMC1;
                                        break;

                                    case Astrology.POS_2:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC1 = cMC2;
                                        break;

                                    case Astrology.POS_1_2:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2_1:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        cMC1 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        break;
                                }
                                if (tableau_flag == Astrology.POS_2_1)
                                {
                                    double part1 = AstronomyMaths.modulo(cMC1 + ci1 - cj1, 360.0);
                                    double part2 = AstronomyMaths.modulo(cMC2 + ci2 - cj2, 360.0);
                                    mi_point = (part1 + part2) / 2.0;
                                    if (Math.abs(part1 - part2) > 180.0)
                                    {
                                        mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                    }
                                    part = mi_point;
                                }
                                else
                                {
                                    double mi_pointMC = (cMC1 + cMC2) / 2.0;
                                    if (Math.abs(cMC1 - cMC2) > 180.0)
                                    {
                                        mi_pointMC = AstronomyMaths.modulo(mi_pointMC + 180.0, 360.0);
                                    }
                                    double mi_pointPlus = (ci1 + ci2) / 2.0;
                                    if (Math.abs(ci1 - ci2) > 180.0)
                                    {
                                        mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                    }
                                    double mi_pointMinus = (cj1 + cj2) / 2.0;
                                    if (Math.abs(cj1 - cj2) > 180.0)
                                    {
                                        mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                    }
                                    part = AstronomyMaths.modulo(mi_pointMC + mi_pointPlus - mi_pointMinus, 360);
                                }
                                sText = new FDegree(part).getShortDegree();
                                sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "starlogin", sText));
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void prepareTreeOfDefinedArabianParts()
    {
        double part;

        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        Part p = starLoginManager.getPartFrom(new Integer(Planets.AS).toString(), new Integer(i).toString(), new Integer(j).toString());
                        String sPart = p.getPart();
                        if (!sPart.equals(""))
                        {
                            if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                            {
                                if (j == i)
                                {
                                    j += 1;
                                }
                                if (j > Planets.MC)
                                {
                                    break;
                                }
                            }

                            if (chartElements.getShownObject(j))
                            {
                                double ci1 = 0.0;
                                double ci2 = 0.0;
                                double cj1 = 0.0;
                                double cj2 = 0.0;
                                double cAS1 = 0.0;
                                double cAS2 = 0.0;

                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = cAS1;
                                        break;

                                    case Astrology.POS_2:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS1 = cAS2;
                                        break;

                                    case Astrology.POS_1_2:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        cAS1 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2_1:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        cAS1 = pos2.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        cAS2 = pos1.get(Planets.AS).getCoord1(chartElements.getCoordSys());
                                        break;
                                }
                                if (tableau_flag == Astrology.POS_2_1)
                                {
                                    double part1 = AstronomyMaths.modulo(cAS1 + ci1 - cj1, 360.0);
                                    double part2 = AstronomyMaths.modulo(cAS2 + ci2 - cj2, 360.0);
                                    mi_point = (part1 + part2) / 2.0;
                                    if (Math.abs(part1 - part2) > 180.0)
                                    {
                                        mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                    }
                                    part = mi_point;
                                }
                                else
                                {
                                    double mi_pointAS = (cAS1 + cAS2) / 2.0;
                                    if (Math.abs(cAS1 - cAS2) > 180.0)
                                    {
                                        mi_pointAS = AstronomyMaths.modulo(mi_pointAS + 180.0, 360.0);
                                    }
                                    double mi_pointPlus = (ci1 + ci2) / 2.0;
                                    if (Math.abs(ci1 - ci2) > 180.0)
                                    {
                                        mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                    }
                                    double mi_pointMinus = (cj1 + cj2) / 2.0;
                                    if (Math.abs(cj1 - cj2) > 180.0)
                                    {
                                        mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                    }
                                    part = AstronomyMaths.modulo(mi_pointAS + mi_pointPlus - mi_pointMinus, 360);
                                }
                                partsAS[i][j] = part;
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < Planets.AS; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        Part p = starLoginManager.getPartFrom(new Integer(Planets.MC).toString(), new Integer(i).toString(), new Integer(j).toString());
                        String sPart = p.getPart();
                        if (!sPart.equals(""))
                        {
                            if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                            {
                                if (j == i)
                                {
                                    j += 1;
                                }
                                if (j > Planets.MC)
                                {
                                    break;
                                }
                            }

                            if (chartElements.getShownObject(j))
                            {
                                double ci1 = 0.0;
                                double ci2 = 0.0;
                                double cj1 = 0.0;
                                double cj2 = 0.0;
                                double cMC1 = 0.0;
                                double cMC2 = 0.0;

                                //si les deux astres dont on cherche le mi-point sont selectionnes dans les options
                                //emplacement en ligne et colonne
                                switch (tableau_flag)
                                {
                                    case Astrology.POS_1:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = cMC1;
                                        break;

                                    case Astrology.POS_2:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = ci1;
                                        cj2 = cj1;
                                        cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC1 = cMC2;
                                        break;

                                    case Astrology.POS_1_2:
                                        ci1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        cMC1 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        break;

                                    case Astrology.POS_2_1:
                                        ci1 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                                        cj1 = pos2.get(j).getCoord1(chartElements.getCoordSys());
                                        ci2 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                                        cj2 = pos1.get(j).getCoord1(chartElements.getCoordSys());
                                        cMC1 = pos2.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        cMC2 = pos1.get(Planets.MC).getCoord1(chartElements.getCoordSys());
                                        break;
                                }
                                if (tableau_flag == Astrology.POS_2_1)
                                {
                                    double part1 = AstronomyMaths.modulo(cMC1 + ci1 - cj1, 360.0);
                                    double part2 = AstronomyMaths.modulo(cMC2 + ci2 - cj2, 360.0);
                                    mi_point = (part1 + part2) / 2.0;
                                    if (Math.abs(part1 - part2) > 180.0)
                                    {
                                        mi_point = AstronomyMaths.modulo(mi_point + 180.0, 360.0);
                                    }
                                    part = mi_point;
                                }
                                else
                                {
                                    double mi_pointMC = (cMC1 + cMC2) / 2.0;
                                    if (Math.abs(cMC1 - cMC2) > 180.0)
                                    {
                                        mi_pointMC = AstronomyMaths.modulo(mi_pointMC + 180.0, 360.0);
                                    }
                                    double mi_pointPlus = (ci1 + ci2) / 2.0;
                                    if (Math.abs(ci1 - ci2) > 180.0)
                                    {
                                        mi_pointPlus = AstronomyMaths.modulo(mi_pointPlus + 180.0, 360.0);
                                    }
                                    double mi_pointMinus = (cj1 + cj2) / 2.0;
                                    if (Math.abs(cj1 - cj2) > 180.0)
                                    {
                                        mi_pointMinus = AstronomyMaths.modulo(mi_pointMinus + 180.0, 360.0);
                                    }
                                    part = AstronomyMaths.modulo(mi_pointMC + mi_pointPlus - mi_pointMinus, 360);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void getTreeOfDefinedArabianParts()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfDefinedArabianParts) + " / " + Planets.getPlanetName(Planets.AS));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = 0.0;
                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                {
                    position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                }

                //parts
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k < Planets.AS; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double part = partsAS[j][k];
                                if (part != -999.0)
                                {
                                    double delta0 = AstronomyMaths.modulo(position1 - part, 360.0);
                                    if (delta0 > 180.0)
                                    {
                                        delta0 = 360.0 - delta0;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            double delta = Math.abs(delta0 - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the part
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", new Integer(new FDegree(delta).getMinute()).toString() + "'"));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                Part p = starLoginManager.getPartFrom(new Integer(Planets.AS).toString(), new Integer(j).toString(), new Integer(k).toString());
                                                String sPart = p.getPart();
                                                if (!sPart.equals(""))
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.black, "arial", sPart));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                break;
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta0 = AstronomyMaths.modulo(position2 - part, 360.0);
                                        if (delta0 > 180.0)
                                        {
                                            delta0 = 360.0 - delta0;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                double delta = Math.abs(delta0 - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the part
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", new Integer(new FDegree(delta).getMinute()).toString() + "'"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    Part p = starLoginManager.getPartFrom(new Integer(Planets.AS).toString(), new Integer(j).toString(), new Integer(k).toString());
                                                    String sPart = p.getPart();
                                                    if (!sPart.equals(""))
                                                    {
                                                        sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.black, "arial", sPart));
                                                    }
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");

        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.treeOfDefinedArabianParts) + " / " + Planets.getPlanetName(Planets.MC));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                //.setFontFamily(s, "starlogin");
                sHtml = sHtml.concat("<tr>");
                sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));

                //planet position
                double position1 = pos1.get(i).getCoord1(chartElements.getCoordSys());
                double position2 = 0.0;
                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                {
                    position2 = pos2.get(i).getCoord1(chartElements.getCoordSys());
                }

                //midpoints
                for (int j = 0; j < Planets.AS; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        for (int k = 0; k < Planets.AS; k++)
                        {
                            if (chartElements.getShownObject(k))
                            {
                                double part = partsMC[j][k];
                                if (part != -999.0)
                                {
                                    double delta0 = AstronomyMaths.modulo(position1 - part, 360.0);
                                    if (delta0 > 180.0)
                                    {
                                        delta0 = 360.0 - delta0;
                                    }
                                    for (int l = 0; l <= AspectType.getLast(); l++)
                                    {
                                        if (chartElements.getShownAspect(l))
                                        {
                                            double delta = Math.abs(delta0 - AspectType.getAspectValue(l, chartElements));

                                            //if there is a close aspect between the object and the part
                                            if (delta < 1.0)
                                            {
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "1"));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", new Integer(new FDegree(delta).getMinute()).toString() + "'"));
                                                sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                Part p = starLoginManager.getPartFrom(new Integer(Planets.MC).toString(), new Integer(j).toString(), new Integer(k).toString());
                                                String sPart = p.getPart();
                                                if (!sPart.equals(""))
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.black, "arial", sPart));
                                                }
                                                sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                break;
                                            }
                                        }
                                    }
                                    if (chartsNB == 2 && tableau_flag != Astrology.POS_1 && tableau_flag != Astrology.POS_2)
                                    {
                                        delta0 = AstronomyMaths.modulo(position1 - part, 360.0);
                                        if (delta0 > 180.0)
                                        {
                                            delta0 = 360.0 - delta0;
                                        }
                                        for (int l = 0; l <= AspectType.getLast(); l++)
                                        {
                                            if (chartElements.getShownAspect(l))
                                            {
                                                double delta = Math.abs(delta0 - AspectType.getAspectValue(l, chartElements));

                                                //if there is a close aspect between the object and the part
                                                if (delta < 1.0)
                                                {
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseDebut());
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", "2"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.BLACK, "starlogin", new Integer(new FDegree(delta).getMinute()).toString() + "'"));
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLFont(AspectType.aspectKindColor(AspectType.getAspectSymbol(l), chartElements), "starlogin", AspectType.getAspectSymbol(l)));
                                                    Part p = starLoginManager.getPartFrom(new Integer(Planets.MC).toString(), new Integer(j).toString(), new Integer(k).toString());
                                                    String sPart = p.getPart();
                                                    if (!sPart.equals(""))
                                                    {
                                                        sHtml = sHtml.concat(htmlStrings.getHTMLFont(Color.black, "arial", sPart));
                                                    }
                                                    sHtml = sHtml.concat(htmlStrings.getHTMLCaseFin());
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                sHtml = sHtml.concat("</tr>");
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private void getDistancesAndCoordinates()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.distancesAndCoordinates));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //Detail
        for (int i = 0; i < chartsNB; i++)
        {
            AllCoord pos;
            if (i == 0)
            {
                pos = pos1;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("<td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("InnerChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr><td>&nbsp;</td>");
                }
            }
            else
            {
                pos = pos2;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("</table><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td><td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("OuterChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr><td>&nbsp;</td>");
                }
            }
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }
            
            //get coordinates and distances information
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.TropicGeoLong)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.TropicHelioLong)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.SiderGeoLong)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.SiderHelioLong)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.GeoLat)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.HelioLat)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.GeoDistance)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.HelioDistance)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.RightAscension)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.Declination)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.Azimuth)));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Coordinate.getCoordinateName(Coordinate.Altitude)));
            sHtml = sHtml.concat("</tr>");
            for (int j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                if (j <= Planets.MC)
                {
                    Coord planet = (Coord) coords.get(j);
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(Planets.getPlanetName(j, chartElements)));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getTropicGeoLong()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getTropicHelioLong()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getSiderGeoLong()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getSiderHelioLong()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getGeoLat()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getHelioLat()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new Double(AstronomyMaths.getRnd(planet.getGeoDist(), 3)).toString()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new Double(AstronomyMaths.getRnd(planet.getHelioDist(), 3)).toString()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getRA()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getDecl()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getAz()).getShortDegree()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther2(new FDegree(planet.getAlt()).getShortDegree()));
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }
    }

    private void getPlanetsPropertiesOfChart()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.planetsPropetiesOfChart));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //Detail
        for (int i = 0; i < chartsNB; i++)
        {
            AllCoord pos;
            if (i == 0)
            {
                pos = pos1;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("<td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("InnerChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr><td>&nbsp;</td>");
                }
            }
            else
            {
                pos = pos2;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("</table><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td><td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("OuterChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr><td>&nbsp;</td>");
                }
            }
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }
            
            //get astrological information
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Sign")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Element")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Angle")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Decan")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Constellation")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("ZodiacalConstellation")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Dignity")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("Direction")));
            sHtml = sHtml.concat(htmlStrings.getHTMLOther2(bundle.getString("House")));
            sHtml = sHtml.concat("</tr>");
            for (int j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                if (j <= Planets.MC)
                {
                    Coord planet = (Coord) coords.get(j);

                    //get the sign
                    double aux_coord = planet.getTropicGeoLong();
                    int sign = (int) (aux_coord / 30.0);

                    //get the constellation
                    ConstellationBoundaries constellationBoundaries = starLoginManager.getConstellationBoundaries();
                    ConstelsCalc constelsCalc = new ConstelsCalc();
                    String constel = constelsCalc.findConstell(planet.getRA() * AstronomyMaths.PI_SUR_CENT80, planet.getDecl() * AstronomyMaths.PI_SUR_CENT80, (double) chartEvent.getYear(), constellationBoundaries);

                    //get the zodiacal constellation
                    double ecart;
                    String zodConstel = "";
                    for (int k = 0; k <= ZodConstels.getLast(); k++)
                    {
                        double cTime = chartEvent.getCTime();
                        ecart = AstronomyMaths.mod(aux_coord - ZodConstels.getConstelBoundary(k, cTime) + 360.0, 360.0);
                        double delta_constel = AstronomyMaths.mod(ZodConstels.getConstelBoundary(AstronomyMaths.mod(k + 1, 13), cTime) - ZodConstels.getConstelBoundary(k, cTime), 360.0);

                        if (ecart < delta_constel)
                        {
                            zodConstel = MainForm.zodConstelName[k];
                            break;
                        }
                    }

                    String sDignity = Rulers.dignityCalculation(j, sign);
                    String sDirection = planet.getRetroString(planet.getRetro());

                    //get the house
                    String sHouse = "";
                    if (j < Planets.AS)
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        break;
                                    }
                                }
                            }
                        }
                        else if (tableau_flag == Astrology.POS_1_2 || tableau_flag == Astrology.POS_2_1)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    //Write the astrological elements
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(j));
                    Color signColor = Color.black;
                    switch (AstronomyMaths.modulo(sign, 4))
                    {
                        case 0:
                            signColor = chartElements.getFireColor();
                            break;
                        case 1:
                            signColor = chartElements.getEarthColor();
                            break;
                        case 2:
                            signColor = chartElements.getAirColor();
                            break;
                        case 3:
                            signColor = chartElements.getWaterColor();
                            break;
                    }
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(signColor, "arial", MainForm.signName[sign]));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(signColor, "arial", Signs.getElement(sign)));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", Signs.getAngle(sign)));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", new Integer((int) (AstronomyMaths.modulo(aux_coord, 30.0) / 10.0 + 1.0)).toString()));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", constel));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", zodConstel));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", sDignity));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", sDirection));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", sHouse));
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }
    }
}
