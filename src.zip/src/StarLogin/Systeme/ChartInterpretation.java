package StarLogin.Systeme;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
//import StarLogin.Systeme.ChartElements;
import StarLogin.IHM.DialogDoc;
import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.AstroCalc.*;
import StarLogin.Systeme.Data.*;
import StarLogin.Systeme.Enum.*;
import StarLogin.Systeme.iofiles.HTMLStrings;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JDialog;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

public class ChartInterpretation
{
    private static int windowNB = 0;
    private ChartElements chartElements;
    private String aspectKinds[][];
    private int tableau_flag;
    //private DialogDoc docForm = new DialogDoc();
    private int chartsNB = 1;
    private HTMLDocument doc = new HTMLDocument();//) docForm.getDocument();
    private ChartEvent chartEvent;
    private AllCoord pos1 = new AllCoord();
    private AllCoord pos2 = new AllCoord();
    private ArrayList events = new ArrayList();                                           //events for both inner and outer charts
    private ArrayList positions = new ArrayList();                                        //positions for both inner and outer charts
    private PlanetInSign planetInSign;
    private PlanetInHouse planetInHouse;
    private PlanetInZodConstel planetInZodConstel;
    private Relationships relationships;
    private ObjectsMeaning objectsMeaning;
    private StarLoginManager starLoginManager;
    private String sHtml;
    private HTMLStrings htmlStrings;
    private java.util.ResourceBundle bundle = MainClass.bundle;

    /** Creates a new instance of ChartInterpretation */
    public ChartInterpretation(ChartElements chartElements, String aspectKinds[][], int tableau_flag, StarLoginManager starLoginManager)
    {
        this.starLoginManager = starLoginManager;
        this.chartElements = chartElements;
        this.aspectKinds = aspectKinds;
        htmlStrings = new HTMLStrings(chartElements, aspectKinds);
        htmlStrings.setCenter(false);
        this.tableau_flag = tableau_flag;

        events = chartElements.getChartEvents();                                           //events for both inner and outer charts
        positions = chartElements.getChartCoords();                                        //positions for both inner and outer charts

        if (events.size() != positions.size())
        {
            return;
        }

        windowNB += 1;
        String title = bundle.getString("InterpretationOfChart");

        chartEvent = (ChartEvent) events.get(0);
        pos1 = (AllCoord) positions.get(0);
        pos2 = new AllCoord();

        if (positions.size() > 1)
        {
            pos2 = (AllCoord) positions.get(1);
            chartsNB = 2;
        }

        //Header
        sHtml = "<p style='background-color: #FFE1C3;' align='center' width='75%'><b><font color='#C300FF' face='arial' size='5'>";
        sHtml = sHtml.concat(bundle.getString("InterpretationOfChart"));
        sHtml = sHtml.concat("</font></b>");


        sHtml = sHtml.concat("<p style=' align='center'><b><font color='#0000ff' face='arial' size='2'>");
        sHtml = sHtml.concat(chartElements.getChartHeader());
        sHtml = sHtml.concat("</font></b>");


        getAspects();
        getOtherElements();
        Element firstElement = doc.getElement(doc.getDefaultRootElement(), StyleConstants.NameAttribute, HTML.Tag.BODY);
        try
        {
            HTMLEditorKit.Parser parser = new javax.swing.text.html.parser.ParserDelegator();
            doc.setParser(parser);
            sHtml = htmlStrings.processCR(sHtml);
            doc.setInnerHTML(firstElement, sHtml);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (java.io.IOException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }

        //docForm.resetUndo();
        //docForm.getTextPane().setSelectionStart(0);
        //docForm.getTextPane().setSelectionEnd(0);
        //docForm.setVisible(true);
        //docForm.setExtendedState(DialogDoc.MAXIMIZED_BOTH);
        DialogDoc docForm = new DialogDoc(new JDialog(), true, doc, title);
    }

    private void getAspects()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(ChartResultsKinds.getName(ChartResultsKinds.aspects));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td>&nbsp;</td>");

        //detail
        sHtml = sHtml.concat("</tr>");
        for (int i = 0; i <= Planets.MC; i++)
        {
            if (chartElements.getShownObject(i))
            {
                for (int j = 0; j <= Planets.MC; j++)
                {
                    if (chartElements.getShownObject(j))
                    {
                        if (!aspectKinds[i][j].equals(""))
                        {
                            sHtml = sHtml.concat("<tr>");
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(i));
                            sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(j));
                            relationships = starLoginManager.getRelationships((byte) i, (byte) j);
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", null2String(relationships.getMeaning())));
                            sHtml = sHtml.concat(htmlStrings.getHTMLAspect(i, j));
                            int aspect = AspectType.getAspectNBFromSymbol(aspectKinds[i][j]);
                            objectsMeaning = starLoginManager.getObjectsMeaning((byte) aspect, (byte) 1);
                            sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", null2String(objectsMeaning.getMeaning())));
                            sHtml = sHtml.concat("</tr>");
                        }
                    }
                }
            }
        }
        sHtml = sHtml.concat("</table>");
    }

    private String null2String(String value)
    {
        if (value == null)
        {
            return "";
        }
        else
        {
            return value;
        }
    }

    private void getOtherElements()
    {
        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(bundle.getString("Sign"));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>");

        for (int i = 0; i < chartsNB; i++)
        {
            AllCoord pos;
            if (i == 0)
            {
                pos = pos1;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("<td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("InnerChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            else
            {
                pos = pos2;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("</table><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("OuterChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }

            //get astrological information
            for (int j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                if (j <= Planets.MC)
                {
                    Coord planet = (Coord) coords.get(j);

                    //get the sign
                    double aux_coord = planet.getTropicGeoLong();
                    int sign = (int) (aux_coord / 30.0);

                    //Write the astrological elements
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(j));
                    Color signColor = Color.black;
                    switch (AstronomyMaths.modulo(sign, 4))
                    {
                        case 0:
                            signColor = chartElements.getFireColor();
                            break;
                        case 1:
                            signColor = chartElements.getEarthColor();
                            break;
                        case 2:
                            signColor = chartElements.getAirColor();
                            break;
                        case 3:
                            signColor = chartElements.getWaterColor();
                            break;
                    }
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(signColor, "starlogin", Signs.getSignSymbol(sign)));
                    planetInSign = starLoginManager.getPlanetInSign((byte) j, (byte) sign);
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", null2String(planetInSign.getMeaning())));
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }


        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(bundle.getString("ZodiacalConstellation"));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>");

        for (int i = 0; i < chartsNB; i++)
        {
            AllCoord pos;
            if (i == 0)
            {
                pos = pos1;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("<td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("InnerChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            else
            {
                pos = pos2;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("</table><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("OuterChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }

            //get astrological information
            for (int j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                if (j <= Planets.MC)
                {
                    Coord planet = (Coord) coords.get(j);
                    double aux_coord = planet.getTropicGeoLong();

                    //get the zodiacal constellation
                    double ecart;
                    String zodConstel = "";
                    int contelNB = 0;
                    for (int k = 0; k <= ZodConstels.getLast(); k++)
                    {
                        double cTime = chartEvent.getCTime();
                        ecart = AstronomyMaths.mod(aux_coord - ZodConstels.getConstelBoundary(k, cTime) + 360.0, 360.0);
                        double delta_constel = AstronomyMaths.mod(ZodConstels.getConstelBoundary(AstronomyMaths.mod(k + 1, 13), cTime) - ZodConstels.getConstelBoundary(k, cTime), 360.0);

                        if (ecart < delta_constel)
                        {
                            zodConstel = MainForm.zodConstelName[k];
                            contelNB = k;
                            break;
                        }
                    }

                    //Write the astrological elements
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(j));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.black, "arial", zodConstel));
                    planetInZodConstel = starLoginManager.getPlanetInZodConstel((byte) j, (byte) contelNB);
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", null2String(planetInZodConstel.getMeaning())));
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }


        //Header
        sHtml = sHtml.concat("<p style='background-color: #C3C3FF;' align='center' width='50%'><b><font color='#000080' face='arial' size='4'>");
        sHtml = sHtml.concat(bundle.getString("House"));
        sHtml = sHtml.concat("</font></b><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>");

        for (int i = 0; i < chartsNB; i++)
        {
            AllCoord pos;
            if (i == 0)
            {
                pos = pos1;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("<td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("InnerChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            else
            {
                pos = pos2;
                if (chartsNB == 2)
                {
                    sHtml = sHtml.concat("</table><table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td><p style='background-color: #C3C3FF;' align='center'><b><font color='#0000ff' face='arial' size='3'>");
                    sHtml = sHtml.concat(bundle.getString("OuterChart"));
                    sHtml = sHtml.concat("</font></b></tr><tr>");
                }
            }
            ArrayList coords = pos.getCoords();
            if (coords == null || coords.size() < 1)
            {
                return;
            }

            //get astrological information
            for (int j = 0; j < coords.size() - 1; j++)     //We don't save the position of the barycenter (the last element)
            {
                if (j <= Planets.MC)
                {
                    Coord planet = (Coord) coords.get(j);
                    double aux_coord = planet.getTropicGeoLong();
                    double ecart;
                    int houseNB = 0;

                    //get the house
                    String sHouse = "";
                    if (j < Planets.AS)
                    {
                        if (tableau_flag == Astrology.POS_1 || tableau_flag == Astrology.POS_2)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        houseNB = k;
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos1.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos1.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        houseNB = k;
                                        break;
                                    }
                                }
                            }
                        }
                        else if (tableau_flag == Astrology.POS_1_2 || tableau_flag == Astrology.POS_2_1)
                        {
                            for (int k = 0; k <= Cusp.House12; k++)
                            {
                                int kk = k + Planets.MC + 1;
                                ecart = AstronomyMaths.mod(planet.getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0);
                                if (k == Cusp.House12)
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((Planets.MC + 1))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        houseNB = k;
                                        break;
                                    }
                                }
                                else
                                {
                                    if (ecart < AstronomyMaths.mod(((Coord) pos2.get((k + Planets.MC + 2))).getTropicGeoLong() - ((Coord) pos2.get(kk)).getTropicGeoLong(), 360.0))
                                    {
                                        sHouse = MainForm.houseName[k];
                                        houseNB = k;
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    //Write the astrological elements
                    sHtml = sHtml.concat(htmlStrings.getHTMLPlanet(j));
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.black, "arial", sHouse));
                    planetInHouse = starLoginManager.getPlanetInHouse((byte) j, (byte) houseNB);
                    sHtml = sHtml.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", null2String(planetInHouse.getMeaning())));
                    sHtml = sHtml.concat("</tr>");
                }
            }
            sHtml = sHtml.concat("</table>");
        }
    }
}
