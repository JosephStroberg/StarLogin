package StarLogin.Systeme;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFormattedTextField.*;
import java.text.ParseException;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class FormattedTextVerifier extends InputVerifier
{
    
    /** Creates a new instance of FormatedTextVerifier */
    public FormattedTextVerifier()
    {
    }
    
    public boolean verify(JComponent input)
    {
        if (input instanceof JFormattedTextField)
        {
            JFormattedTextField ftf = (JFormattedTextField)input;
            AbstractFormatter formatter = ftf.getFormatter();
            if (formatter != null)
            {
                String text = ftf.getText();
                try
                {
                    formatter.stringToValue(text);
                    return true;
                }
                catch (ParseException pe)
                {
                    return false;
                }
            }
        }
        return true;
    }
    public boolean shouldYieldFocus(JComponent input)
    {
        return verify(input);
    }
    
}
