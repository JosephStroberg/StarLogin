package StarLogin.Systeme.AstroCalc;

import java.lang.Math;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class AstronomyMaths extends java.lang.Object
{
    // number of hours in a century
    public static final double HOUR_PER_CENTURY = 876600.0;
    
    // number of days in a century
    public static final double DAY_PER_CENTURY = 36525.0;
    
    //Julian Day on January, 01 1900 at noon
    public static final double JD_1900 = 2415020.0;
    
    // Sidereal time/ UT one
    public static final double ST_ON_UT = 1.00273790932;
    
    //Astronomical unit (Sun-Earth average distance)
    public static final double ASTRONOMICAL_UNIT = 149597900000.0;
    
    //Sun gravitational constant
    public static final double HELIO_GRAVITATION_CONSTANT = 132712438000000000000.0;
    
    //Pi and values from Pi
    public static final double PI = 3.1415926535897932384626433832795;
    public static final double PI_SUR_CENT80 = 0.017453292519943295769236907684886;
    public static final double CENT80_SUR_PI = 57.295779513082320876798154814105;
    
    private static double epsilon = 0.000000000001;
    
    public static final double LUNE_SYNODIQUE = 29.53058868;
    
    // get the Earth obliquity
    // Input:	nJS: Julian Date in centuries, from 1/1/1900
    //			nNN: Mean ascendant lunar node in decimal degrees
    public static double getObliquity(double nJS, double nNN)
    {
        return 23.4522944 - 0.0130125 * nJS - Math.pow(0.000001638 * nJS, 2.0) + Math.pow(0.000000503 * nJS, 3.0) + 0.00256 * cosD(nNN);
    }
    
    public static byte bool2byte(boolean x)
    {
        if (x == true)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
    
    // Calculation of the geocentric nLong of the mean ascendant lunar node
    // Input:	nJS: Julian Date in centuries, from 1/1/1900
    public static double getNN(double nJS)
    {
        return modulo(259.18327 - 1934.142 * nJS, 360.0);
    }
    
    // get the Julian Date from a Gregorian one
    public static double gregorianToJulian(long day, long month, long year)
    {
        double jj;
        long x, mm;
        
        mm = (long)month;
        if (month < 3)
        {
            year -= 1;
            mm += 12;
        }
        // TODO: verify the result of the "(long)" cast
        jj = (long)(365.25 * year) + (long)(30.6001 * (mm + 1)) + day + 1720994.5;
        if (year + month / 100 + day / 10000 > 1582.10145)
        {
            x = (long)(year / 100);
            jj = jj + 2.0 - x + (double)(x / 4);
        }
        return jj;
    }
    
    // get Gregorian date from Julian Date
    // return:	Gregorian date in a string "DD.MMYYYY" (day, month and year)
    public static double julianToGregorian(double day)
    {
        double j1, f, j, m, a, s;
        long z, aa, al, b, c, nD, e;
        
        m = 0.0;
        a = 0.0;
        j1 = day + 0.5;
        z = (long)(j1);
        f = j1 - z; //give the time
        if (z < 2299161)
            aa = z;
        else
        {
            al = (long)((z - 1867216.25) / 36524.25);
            aa = z + 1 + al - (long)(al / 4);
        }
        b = aa + 1524;
        c = (long)(((double)b - 122.1) / 365.25);
        nD = (long)(365.25 * (double)c);
        e = (long)((double)(b - nD) / 30.6001);
        j = (double)(b - nD) - (double)(long)(30.6001 * (double)e) + f; //day + time/24
        if (e < 13.5)
        {
            m = (double)(e - 1);
        }
        else if (e > 13.5)
        {
            m = (double)(e - 13);
        }
        if (m > 2.5)
        {
            a = (double)c - 4716.0;
        }
        else if (m < 2.5)
        {
            a = (double)c - 4715.0;
        }
        return a + m/100.0 + j/10000.0 + epsilon;
    }
    
    // get the geocentric latitude of a planet
    public static double getGeoLat(double nHelioDist, double nGeoDist, double nHelioLat)
    {
        if (nGeoDist == 0.0)
            return 0.0;
        else
            return Math.asin(nHelioDist / nGeoDist * sinD(nHelioLat)) * CENT80_SUR_PI;
    }
    
    // get the geocentric longitude of a planet
    public static double getGeoLong(double nEarthSunDist, double nHelioDist, double nHelioLat, double nHelioLong, double nSunLong)
    {
        double nGeoLong, angle;
        
        angle = nHelioDist * cosD(nHelioLat) * sinD((nHelioLong - nSunLong)) / (nEarthSunDist + nHelioDist * cosD(nHelioLat) * cosD((nHelioLong - nSunLong)));
        nGeoLong = modulo(nSunLong + atnD(angle), 360.0);
        if ((nHelioDist > nEarthSunDist) && (Math.abs(nGeoLong - nHelioLong) < 270.0) && (Math.abs(nGeoLong - nHelioLong) > 90.0) && ((Math.abs(nGeoLong - nSunLong) < 90.0) || (Math.abs(nGeoLong - nSunLong) > 270.0))) nGeoLong = modulo(nGeoLong - 180.0, 360.0);
        return nGeoLong;
    }
    
    // Calculation of the rayon local exact (au relief pres) en un lieu de latitude donnee
    public static double getGeoidRadius(double nGeoLat)
    {
        double demi_a, demi_b;
        
        demi_a = 6378.14;		// km
        demi_b = 6356.755;		// km
        return demi_a * demi_b / Math.sqrt(Math.pow(demi_a * sinD(nGeoLat), 2.0) + Math.pow(demi_b * cosD(nGeoLat), 2.0));
    }
    
    // Converting sidereal time to UT one
    public static double LSTToUT(double hour, double nLong, double tsg0)
    {
        hour = hour + nLong / 15.0;
        hour = hour - tsg0;
        if (hour < 0.0)
            hour = hour + 24.0;
        else if (hour > 24.0)
            hour = hour - 24.0;
        return hour / ST_ON_UT;
    }
    
    // Converting UT time to sidereal one
    public static double UTToLST(double hour, double tsg0, double nLong)
    {
        return modulo(ST_ON_UT * hour + tsg0 - nLong / 15.0, 24.0);
    }
    
    // Calculation of angle between to places in latitude
    public static double getLatDist(double nLat1, double nLat2)
    {
        double nDist;
        
        nDist = Math.abs(nLat2 - nLat1);
        if (nDist > 180.0) nDist = 360.0 - nDist;
        return nDist;
    }
    
    // Calculation of angle between to places in longitude
    public static double getLongDist(double nLong1, double nLong2)
    {
        double nDist;
        
        nDist = Math.abs(nLong2 - nLong1);
        if (nDist > 180) nDist = 360 - nDist;
        return nDist;
    }
    
    // get the distance between a planet and the Earth
    public static double getGeoDist(double nEarthSunDist, double nHelioDist, double nHelioLat, double nHelioLong, double nSunLong)
    {
        return Math.sqrt(nEarthSunDist * nEarthSunDist + nHelioDist * nHelioDist + 2.0 * nEarthSunDist * nHelioDist * cosD(nHelioLat) * cosD((nHelioLong - nSunLong)));
    }
    
    // Calculation the angle between two places
    public static double getAngleDist(double nLat1, double nLat2, double nLong1, double nLong2)
    {
        double aux;
        
        aux = sinD(nLat1) * sinD(nLat2) + cosD(nLat1) * cosD(nLat2) * cosD((nLong1 - nLong2));
        
        // 180*long((1-aux)/2) permet d'ajouter 180� quand aux vaut -1
        return Math.abs(acosD(aux)) + 180.0 * (double)(long)((1 - aux) / 2.0);
    }
    
    // Calculation of the local sidereal time for the event
    public static double getLST(double nCTime, double nPlaceLong, double nPlaceLat)
    {
        double nJD;	// Julian day
        double tsg0;
        double nUTH;
        double nLST;
        
        // Calculation of the Greenwich sidereal time at midnight
        tsg0 = getGMT0(nCTime);
        
        // Calculation of the local mean sidereal time
        nJD = getJD(nCTime);
        nUTH = frac(nJD + 0.5) * 24.0;
        nLST = UTToLST(nUTH, tsg0, nPlaceLong);
        return nLST;
    }
    
    // Calculation of the Century time from the Julian Day
    public static double getCTime(double nJD)
    {
        return (nJD - JD_1900) / DAY_PER_CENTURY;
    }
    
    // Calculation of the Julian Day from the Century time
    public static double getJD(double nCTime)
    {
        return nCTime * DAY_PER_CENTURY + JD_1900;
    }
    
    // Calculation of the Greenwich sidereal mean time at Midnight
    public static double getGMT0(double nCTime)
    {
        double t;
        
        t = 6.6460655556 + (8640184.542 * (nCTime) + 0.0929 * (nCTime) * (nCTime)) / 3600.0;
        t = modulo(t, 24.0);      // resultat en heures decimales
        if (t < 0.0) t += 24.0;
        return t;
    }
    
    // Calculation of the angle in a place (number 2) from two other places
    public static double placeAngle(double nLat1, double nLat2, double nLat3, double nLong1, double nLong2, double nLong3)
    {
        // ecarts en nLong entre les trois lieux pris deux � deux in degrees
        double L12, L23;//, L31;
        // ecarts en latitude entre les trois lieux pris deux � deux in degrees
        double lat12, lat23;//, lat31;
        // distances angulaires entre les lieux pris deux � deux in degrees
        double d12, d23, d31;
        // auxiliary variable
        double aux;
        //////////////////////////////////////////////////////////////////////
        
        
        // calcul des ecarts en nLong utiles
        L12 = getLongDist(nLong1, nLong2);
        L23 = getLongDist(nLong2, nLong3);
        
        // calcul des ecarts en latitude utiles
        lat12 = getLatDist(nLat1, nLat2);
        lat23 = getLatDist(nLat2, nLat3);
        
        // calcul des distances angulaires
        d12 = getAngleDist(nLat1, nLat2, nLong1, nLong2);
        d23 = getAngleDist(nLat2, nLat3, nLong2, nLong3);
        d31 = getAngleDist(nLat3, nLat1, nLong3, nLong1);
        
        // calcul de l// angle au lieu considere
        aux = sinD(d12) * sinD(d31);
        if (aux != 0.0)
        {
            aux = (cosD(d23) - cosD(d12) * cosD(d31)) / aux;
            if (Math.abs(aux) > 1.0)
            {
                if (aux > 1.0)
                    aux = 0.0;
                else
                    aux = 180.0;
            }
            else
                aux = acosD(aux);
        }
        return aux;
    }
    
    // Calculation of the right ascension of a planet
    public static double getRA(double nObliq, double nLat, double nLong)
    {
        double x;
        
        if (Math.abs(nLong) == 90.0)
            x = 90.0 * sgn(sinD(nLong));
        else
            x = atnD((cosD(nObliq) * sinD(nLong) - sinD(nObliq) * tanD(nLat)) / cosD(nLong));
        
        if (cosD(nLong) < 0.0) x += 180.0;
        return modulo(x, 360.0);
    }
    
    // Calculation of the right ascension of a planet
    public static double getLongitude(double nObliq, double nD, double nRA)
    {
        double x;
        
        
        if (Math.abs(nRA) == 90.0)
            x = 90.0 * sgn(sinD(nRA));
        else
            x = atnD((cosD(nObliq) * sinD(nRA) + sinD(nObliq) * tanD(nD)) / cosD(nRA));
        
        if (cosD(nRA) < 0.0) x += 180.0;
        return modulo(x, 360.0);
    }
    
    // Calculation of the corrected heliocentric nLong
    public static double getCorHelioLong(double nHelioLong, double noeud_lunaire)
    {
        return nHelioLong - 0.004722 * sinD(noeud_lunaire);
    }
    
    // get the heliocentric latitude of a planet
    public static double getHelioLat(double nHelioLat)
    {
        double x;
        
        x = modulo(nHelioLat / 3600.0, 360.0);
        return x - 360.0 * (double)(long)(x / 180.0 - 0.000000001);
    }
    
    // Calculation of the altitude of a planet
    public static double getAltitude(double nLat, double nD, double nRA, double nLST)
    {
        return asinD(sinD(nLat) * sinD(nD) + cosD(nLat) * cosD(nD) * cosD((15.0 * nLST - nRA)));
    }
    
    // Calculation of the declination of a planet
    public static double getDeclination(double nObliq, double nLat, double nLong)
    {
        return Math.asin(cosD(nObliq) * sinD(nLat) + sinD(nObliq) * cosD(nLat) * sinD(nLong)) * CENT80_SUR_PI;
    }
    
    // Calculation of the Azimuth of a planet
    public static double getAzimuth(double nPlaceLat, double nD, double nRA, double nLST)
    {
        double x, h, aux;
        
        h = modulo((15.0 * nLST - nRA), 360.0);
        if (tanD(nPlaceLat) == tanD(nD) * cosD(h))
            x = 90.0 * sgn(cosD(h));
        else
        {
            aux = sinD(nPlaceLat) * cosD(h) - tanD(nD) * cosD(nPlaceLat);
            x = atnD(sinD(h) / aux) + 90.0 * (1.0 + sgn(aux));
        }
        x = modulo(x, 360.0);
        return x;
    }
    
    public static double getAyanamsa(double nCTime)
    {
        //(5029.0966" during a century   ;   without nutation)
        return 22.4704583333 + 5029.0966 / 3600.0 * nCTime;
    }
    
    public static double getUTHFromCTime(double nCTime)
    {
        double nJD;
        nJD = nCTime * DAY_PER_CENTURY + JD_1900;
        return frac(nJD - 0.5) * 24.0 + 12.0;	//TODO: verify
    }
    
    public static double getJDFromCTime(double nCTime)
    {
        double nJD;
        nJD = nCTime * DAY_PER_CENTURY + JD_1900;
        return (int)(nJD - 0.5) + 0.5;	//TODO: verify
    }
    
    // get the cosine of an angle in degrees
    public static double cosD(double x)
    {
        return Math.cos(x * PI_SUR_CENT80);
    }
    
    // get the sine of an angle in degrees
    public static double sinD(double x)
    {
        return Math.sin(x * PI_SUR_CENT80);
    }
    
    //
    public static double tan_(double x)
    {
        if (Math.abs(modulo(x, Math.PI / 2.0) - Math.PI / 2.0) < 1E-16)
            return 9E+20 * sgn(x);
        else
            return Math.tan(x);
    }
    
    // tan in degrees
    public static double tanD(double x)
    {
        return tan_(x * PI_SUR_CENT80);
    }
    
    // get the remainder of number (double) divided by another one
    public static double modulo(double x, double y)
    {
        if (y == 0.0)
        {
            return 0.0;
        }
        else
        {
            return x - Math.floor(x / y) * y;
        }
    }
    public static long modulo(long x, long y)
    {
        if (y == 0)
        {
            return 0;
        }
        else
        {
            return x - (x / y) * y;
        }
    }
    public static int modulo(int x, int y)
    {
        if (y == 0)
        {
            return 0;
        }
        else
        {
            return x - (x / y) * y;
        }
    }
    
    //like modulo (but quicker) if we are sure that y is always positive and x is between -y and +2*y :
    public static double mod(double x, double y)
    {
        if (x < 0.0)
        {
            return x + y;
        }
        else if (x >= y)
        {
            return x - y;
        }
        else
        {
            return x;
        }
    }
    public static long mod(long x, long y)
    {
        if (x < 0)
        {
            return x + y;
        }
        else if (x >= y)
        {
            return x - y;
        }
        else
        {
            return x;
        }
    }
    public static int mod(int x, int y)
    {
        if (x < 0)
        {
            return x + y;
        }
        else if (x >= y)
        {
            return x - y;
        }
        else
        {
            return x;
        }
    }
    
    // get the sign of a number
    public static double sgn(double x)
    {
        if (x == 0.0)
            return x;
        else
            return x / Math.abs(x);
    }
    
    // get the fractional part of a number
    public static double frac(double x)
    {
        double s = sgn(x);
        return x - Math.floor(Math.abs(x)) * s;
    }
    
    // Convert sexagesimal degrees to decimal degrees
    public static double getDecimalDegrees(double x)
    {
        long a, b, s;
        
        a = 100;
        b = 60;
        s = (long)sgn(x);
        x = Math.abs(x);
        x = (double)((long)x) + (double)((long)(a * frac(x) + epsilon)) / b + frac(a * frac(x) + epsilon) * a / b / b;
        
        return (double)s * x;
    }
    
    // Convert decimal degrees to sexagesimal degrees
    public static double getSexagesimalDegrees(double x)
    {
        double epsilon;
        long a, b, s;
        
        epsilon = 0.000000000001;
        a = 60;
        b = 100;
        s = (long)sgn(x);
        x = Math.abs(x);
        x = (double)((long)x) + (double)((long)(a * frac(x) + epsilon)) / b + frac(a * frac(x) + epsilon) * a / b / b;
        // To avoid getting x�y'60" or x�60'y":
        if (frac(100.0 * x) >= 0.595) x = (double)(long)x + (double)((long)(frac(x + 0.00405 + epsilon) * 100)) / 100;
        if (frac(x) >= 0.59595) x = (double)((long)x + (long)(frac(x) + 0.40405 + epsilon));
        
        return (double)s * x;
    }
    
    // atan in degrees
    public static double atnD(double x)
    {
        return Math.atan(x) * CENT80_SUR_PI;
    }
    
    public static double atn_Div(double x, double y)
    {
        if (y == 0.0)
        {
            return 90.0 * sgn(x) * sgn(y);
        }
        else
        {
            return atnD(x/y);
        }
    }
    
    // acos in degrees
    public static double acosD(double x)
    {
        if (x > 1.0)
            x=1.0;
        else
        {
            if (x < -1.0)
                x = -1.0;
        }
        x = Math.acos(x) * CENT80_SUR_PI;
        
        return x;
    }
    
    // asin in degrees
    public static double asinD(double x)
    {
        if (x > 1.0)
            x=1.0;
        else
        {
            if (x < -1.0)
                x = -1.0;
        }
        x = Math.asin(x) * CENT80_SUR_PI;
        return x;
    }
    
    // Rounding sexagesimal numbers
    public static double getSexaRnd(double x, int i)
    {
        double rnd;
        double div;
        long s;
        
        s = (long)sgn(x);
        x = Math.abs(x);
        if (i == 1)
            i = 2;
        else
            if (i == 3) i = 4;
        
        switch (i)
        {
            case 0:
                rnd = (double)((long)(x + 0.699999999999999));
                break;
                
            case 2:
                rnd = (double)((long)(frac(x)*100.0 + 0.699999999999999));
                if (rnd >= 60.0)
                    rnd = 1 + (double)((long)(x));
                else
                    rnd = rnd / 100.0 + (double)((long)(x));
                break;
                
            default:
                div = Math.pow(10.0, (double)i);
                rnd = (double)((long)(div * x)) / div;
        }
        return (double)s * rnd;
    }
    
    // Rounding decimal numbers
    public static double getRnd(double x, long i)
    {
        long s;
        double div;
        
        s = (long)sgn(x);
        x = Math.abs(x);
        div = Math.pow(10.0, (double)i);
        return (double)s * (double)((long)(div * x + 0.5)) / div;
    }

    public static int getWeekDay(String sDate)
    {
        if (sDate == null || sDate.equals(""))
        {
            return -1;
        }
        else
        {
            FDate fDate = new FDate(sDate);
            long y = fDate.getYear();
            long m = fDate.getMonth();
            long d = fDate.getDay();
            double jd = AstronomyMaths.gregorianToJulian(d, m, y);
            int weekDay = (int) AstronomyMaths.modulo(jd + 1.5, 7);
            return weekDay;
        }
    }
}
