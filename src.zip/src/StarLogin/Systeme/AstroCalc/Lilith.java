/*
 * Lilith.java
 *
 * Created on 7 ao�t 2003, 07:15
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Lilith
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    private double mMoonGeoDist;
    private double mMoonGeoLat;
    private double mMoonHelioDist;
    private double mMoonTropicGeoLong;
    private double mMoonNodeTropicGeoLong;
    private boolean trueLilith;
    
    /** Creates new Lilith */
    public Lilith(ChartEvent chartEvent, boolean trueLilith)
    {
        this.chartEvent = chartEvent;
        this.trueLilith = trueLilith;
    }
    
    public void setTrueSunLongitude(double value)
    {
        mTrueSunLongitude = value;
    }
    
    public void setMoonNodeTropicGeoLong(double value)
    {
        mMoonNodeTropicGeoLong = value;
    }
    
    public void setSunEarthDist(double value)
    {
        mSunEarthDist = value;
    }
    
    public void setMoonGeoDist(double value)
    {
        mMoonGeoDist = value;
    }
    
    public void setMoonGeoLat(double value)
    {
        mMoonGeoLat = value;
    }
    
    public void setMoonHelioDist(double value)
    {
        mMoonHelioDist = value;
    }
    
    public void setMoonTropicGeoLong(double value)
    {
        mMoonTropicGeoLong = value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        double ll = 270.435378 + 481267.880862 * mCTime;
        double ml = 296.095334 + 477198.867586 * mCTime;
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(ll - ml - 180.0, 360.0));
        mCoord.setHelioLat(0.0);
        mCoord.setHelioDist(0.0);

        //Case of true Lilith
        if (trueLilith == true)
        {
            double t = mCTime - 1.0; //minus 1 because of the Year 2000 origin
            double mTropicHelioLong = mCoord.getTropicHelioLong() - 15.5 * AstronomyMaths.sinD(101.0 + 413335.0 * t) - 9.6 * AstronomyMaths.sinD(326.0 - 63864.0 * t) - 2.7 * AstronomyMaths.sinD(135.0 + 477199.0 * t) + 2.6 * AstronomyMaths.sinD(67.0 + 349472.0 * t) + 2.1 * AstronomyMaths.sinD(201.0 + 826671.0 * t) + 1.5 * AstronomyMaths.sinD(11.0 + 1367733.0 * t);
            mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong, 360.0));
        }

        mCoord.setTropicGeoLong(mCoord.getTropicHelioLong());
        if (AstronomyMaths.sinD(mMoonTropicGeoLong - mMoonNodeTropicGeoLong) == 0.0)
        {
            mCoord.setGeoLat(90.0 * AstronomyMaths.sgn(AstronomyMaths.tanD(mMoonGeoLat) * AstronomyMaths.sinD(mCoord.getTropicGeoLong() - mMoonNodeTropicGeoLong)));
        }
        else
        {
            mCoord.setGeoLat(AstronomyMaths.atnD(AstronomyMaths.tanD(mMoonGeoLat) * AstronomyMaths.sinD(mCoord.getTropicGeoLong() - mMoonNodeTropicGeoLong) / AstronomyMaths.sinD(mMoonTropicGeoLong - mMoonNodeTropicGeoLong)));
        }
        mCoord.setGeoDist(mMoonGeoDist);
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
