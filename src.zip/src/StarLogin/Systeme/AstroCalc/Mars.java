/*
 * Mars.java
 *
 * Created on 6 ao�t 2003, 09:09
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Mars
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Mars */
    public Mars(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Mars;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + (38451.0  + 37.0  * mCTime) * AstronomyMaths.sinD(m[mNumber]) + (2238.0  + 4.0  * mCTime) * AstronomyMaths.sinD(2.0  * m[mNumber]) + 181.0  * AstronomyMaths.sinD(3.0  * m[mNumber]) + 17.0  * AstronomyMaths.sinD(4.0  * m[mNumber]) - 52.0  * AstronomyMaths.sinD(2.0  * u[mNumber]) - 22.0  * AstronomyMaths.cosD(m[mNumber] - 2.0  * m[Planets.Jupiter]) - 19.0  * AstronomyMaths.sinD(m[mNumber] - m[Planets.Jupiter]);
        mTropicHelioLong = mTropicHelioLong + 17.0  * AstronomyMaths.cosD(m[mNumber] - m[Planets.Jupiter]) - 16.0  * AstronomyMaths.cosD(2 * (m[mNumber] - m[Planets.Jupiter])) + 13.0  * AstronomyMaths.cosD(m[Planets.Sun] - 2.0  * m[mNumber]) - 10.0  * (AstronomyMaths.sinD(m[mNumber] - 2.0  * u[mNumber]) + AstronomyMaths.sinD(m[mNumber] + 2.0  * u[mNumber])) + 7.0  * (AstronomyMaths.cosD(m[Planets.Sun] - m[mNumber]) - AstronomyMaths.cosD(2.0  * m[Planets.Sun] - 3.0  * m[mNumber]));
        mTropicHelioLong = mTropicHelioLong - 5.0  * (AstronomyMaths.sinD(m[Planets.Venus] - 3.0  * m[mNumber]) + AstronomyMaths.sinD(m[Planets.Sun] - m[mNumber]) + AstronomyMaths.sinD(m[Planets.Sun] - 2.0  * m[mNumber])) + 4.0  * (AstronomyMaths.cosD(m[Planets.Jupiter]) - AstronomyMaths.cosD(2.0  * (m[Planets.Sun] - 2.0  * m[mNumber]))) + 3.0  * (AstronomyMaths.cosD(m[Planets.Venus] - 3.0  * m[mNumber]) + AstronomyMaths.sinD(2.0  * (m[mNumber] - m[Planets.Jupiter])));
        mCoord.setHelioLat(6603.0  * AstronomyMaths.sinD(u[mNumber]) + 622.0  * AstronomyMaths.sinD(m[mNumber] - u[mNumber]) + 615.0  * AstronomyMaths.sinD(m[mNumber] + u[mNumber]) + 64.0  * AstronomyMaths.sinD(2.0  * m[mNumber] + u[mNumber]));
        mCoord.setHelioDist(1.53031 - 0.1417 * AstronomyMaths.cosD(m[mNumber]) - 0.0066 * AstronomyMaths.cosD(2.0  * m[mNumber]) - 0.00047 * AstronomyMaths.cosD(3.0  * m[mNumber]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
