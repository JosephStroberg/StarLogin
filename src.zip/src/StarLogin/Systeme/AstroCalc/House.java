package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Enum.*;

import java.util.ArrayList;

public class House
{
    private double mSunDecl;            //WARNING: needs to be set for Albategnius houses, so set it before calling CalculMaisons
    private double mSunGeoLong;         //WARNING: needs to be set for Solar houses, so set it before calling CalculMaisons
    private double mMoonNNodeGeoLong;   //WARNING: needs to be set for Nodal houses, so set it before calling CalculMaisons
    
    /** Creates new House */
    public House()
    {
    }
    
    public void setSunDecl(double data)
    {
        mSunDecl = data;
    }
    
    public void setMoonNNodeGeoLong(double data)
    {
        mMoonNNodeGeoLong = data;
    }
    
    public void setSunGeoLong(double data)
    {
        mSunGeoLong = data;
    }
    
    //calculation of the cups for Abenragel
    private double getAbenragel(double asLongitude, double hvernal, double latitude, double obliquity, int cusp)
    {
        double semiDayArcAS;
        double semiNightArcAS;
        double h = 0.0;
        double declAS;
        double domitude;
        double x;
        
        declAS = Math.asin(AstronomyMaths.sinD(asLongitude) * Math.sin(obliquity));
        semiNightArcAS = AstronomyMaths.acosD(Math.tan(latitude) * Math.tan(declAS));
        semiDayArcAS = 180.0 - semiNightArcAS;
        
        switch (cusp)
        {
            case Cusp.House1 : h = AstronomyMaths.mod(180.0 + semiNightArcAS, 360.0);break;
            case Cusp.House2 : h = AstronomyMaths.mod(180.0 + 2.0 / 3.0 * semiNightArcAS, 360.0);break;
            case Cusp.House3 : h = AstronomyMaths.mod(180.0 + 1.0 / 3.0 * semiNightArcAS, 360.0);break;
            case Cusp.House4 : h = 180.0;break;
            case Cusp.House5 : h = -1.0 / 3.0 * semiDayArcAS;break;
            case Cusp.House6 : h = -2.0 / 3.0 * semiDayArcAS;break;
            case Cusp.House7 : h = semiNightArcAS;break;
            case Cusp.House8 : h = 2.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House9 : h = 1.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House10 : h = 0.0;break;
            case Cusp.House11 : h = AstronomyMaths.mod(180.0 - 1.0 / 3.0 * semiDayArcAS, 360.0);break;
            case Cusp.House12 : h = AstronomyMaths.mod(180.0 - 2.0 / 3.0 * semiDayArcAS, 360.0);
        }
        
        if ( AstronomyMaths.sinD(h) == 0.0 )
        {
            domitude = AstronomyMaths.PI / 2.0;
        }
        else
        {
            domitude = Math.atan((Math.tan(latitude) * Math.tan(declAS) + AstronomyMaths.cosD(h)) / AstronomyMaths.sinD(h));
        }
        x = Math.cos(obliquity) * Math.sin(hvernal + domitude) + Math.sin(obliquity) * Math.cos(domitude) * Math.tan(latitude);
        x = AstronomyMaths.mod(AstronomyMaths.atnD(-Math.cos(hvernal + domitude) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
        if ( cusp >= Cusp.House4 && cusp <= Cusp.House10 )
        {
            x = AstronomyMaths.mod(x + 180.0, 360.0);
        }
        return x;
    }
    
    //calculation of the cusps for "two hours" houses system
    private double getBiHoraire(double hvernal, double obliquity, int cusp)
    {
        double ad = AstronomyMaths.mod(AstronomyMaths.CENT80_SUR_PI * hvernal + 30.0 * AstronomyMaths.mod(cusp - 9, 12), 360.0);
        return AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(ad) / Math.cos(obliquity))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(ad))), 360.0);
    }
    
    //calculation of the cups fore Wiesel
    private double getWiesel(double asLongitude, double obliquity, int cusp)
    {
        double ad = AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(asLongitude) * Math.cos(obliquity))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(asLongitude))) + 30 * cusp, 360.0);
        return AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(ad) / Math.cos(obliquity))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(ad))), 360.0);
    }
    
    //calculation of the cusps for ancient
    private double getAntique(double asLongitude, int cusp)
    {
        return AstronomyMaths.mod(getMaternusAS(asLongitude, cusp) - 15.0, 360.0);
    }
    
    //calculation of the cusps for zodiacal
    private double getZodiacale(double asLongitude, int cusp)
    {
        return AstronomyMaths.mod(((double)(int)(asLongitude / 30.0) + cusp) * 30, 360.0);
    }
    
    //calculation of the cusps for harmonic
    private double getHarmonique(double asLongitude, double mcLongitude, int cusp)
    {
        double majorArc;
        double length;
        double angle;
        
        majorArc = AstronomyMaths.mod(asLongitude - mcLongitude, 360.0);
        angle = AstronomyMaths.atnD(1.0 / (180.0 / majorArc - 1));
        length = (90.0 - majorArc / 2.0) * Math.sqrt(2.0) * AstronomyMaths.sinD(angle);
        
        switch (cusp)
        {
            case Cusp.House1 : return asLongitude;
            case Cusp.House2 : return asLongitude + length / 2.0 / AstronomyMaths.sinD(angle + 75.0);
            case Cusp.House3 : return AstronomyMaths.mod(mcLongitude - length / 2.0 / AstronomyMaths.sinD(angle + 15.0) + 180.0, 360.0);
            case Cusp.House4 : return AstronomyMaths.mod(mcLongitude + 180.0, 360.0);
            case Cusp.House5 : return AstronomyMaths.mod(mcLongitude + length / 2.0 / AstronomyMaths.sinD(angle + 75.0) + 180.0, 360.0);
            case Cusp.House6 : return AstronomyMaths.mod(asLongitude - length / 2.0 / AstronomyMaths.sinD(angle + 15.0) + 180.0, 360.0);
            case Cusp.House7 : return AstronomyMaths.mod(asLongitude + 180.0, 360.0);
            case Cusp.House8 : return AstronomyMaths.mod(asLongitude + length / 2.0 / AstronomyMaths.sinD(angle + 75.0) + 180.0, 360.0);
            case Cusp.House9 : return mcLongitude - length / 2.0 / AstronomyMaths.sinD(angle + 15.0);
            case Cusp.House10 : return mcLongitude;
            case Cusp.House11 : return mcLongitude + length / 2.0 / AstronomyMaths.sinD(angle + 75.0);
            case Cusp.House12 : return asLongitude - length / 2.0 / AstronomyMaths.sinD(angle + 15.0);
        }
        return 0.0;
    }
    
    //calculation of the cusps for equatoriale diisogone
    private double getEquatorialeDiisogone(double asLongitude, double mcLongitude, double hvernal, double obliquity, int cusp)
    {
        double ad = 0.0;
        double adAS;
        double arc_eq_AS_MC;
        double arc_eq_MC_DS;
        
        hvernal = AstronomyMaths.CENT80_SUR_PI * hvernal;
        adAS = AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(asLongitude) * Math.cos(obliquity)) + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(asLongitude))), 360.0);
        arc_eq_AS_MC = AstronomyMaths.mod(adAS - hvernal, 360.0);
        arc_eq_MC_DS = 180.0 - arc_eq_AS_MC;
        
        switch (cusp)
        {
            case Cusp.House1 : ad = adAS;break;
            case Cusp.House2 : ad = AstronomyMaths.mod(adAS + arc_eq_MC_DS  / 3.0, 360.0);break;
            case Cusp.House3 : ad = AstronomyMaths.mod(adAS  + 2.0 *  arc_eq_MC_DS  / 3.0, 360.0);break;
            case Cusp.House4 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0);break;
            case Cusp.House5 : ad = AstronomyMaths.mod(hvernal + 180 + arc_eq_AS_MC  / 3.0, 360.0);break;
            case Cusp.House6 : ad = AstronomyMaths.mod(hvernal + 180  + 2.0 *  arc_eq_AS_MC  / 3.0, 360.0);break;
            case Cusp.House7 : ad = AstronomyMaths.mod(adAS + 180.0, 360.0);break;
            case Cusp.House8 : ad = AstronomyMaths.mod(adAS + 180 + arc_eq_MC_DS  / 3.0, 360.0);break;
            case Cusp.House9 : ad = AstronomyMaths.mod(adAS + 180  + 2.0 *  arc_eq_MC_DS  / 3.0, 360.0);break;
            case Cusp.House10 : ad = hvernal;break;
            case Cusp.House11 : ad = AstronomyMaths.mod(hvernal + arc_eq_AS_MC  / 3.0, 360.0);break;
            case Cusp.House12 : ad = AstronomyMaths.mod(hvernal  + 2.0 *  arc_eq_AS_MC  / 3.0, 360.0);
        }
        return AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(ad) / Math.cos(obliquity)) + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(ad))), 360.0);
    }
    
    //calculation of the cups for bissectrices
    private double getBissectrices(double asLongitude, double mcLongitude, int cusp)
    {
        double majorArc;
        double a;
        double b;
        double alpha;
        double beta;
        
        majorArc = AstronomyMaths.mod(asLongitude - mcLongitude, 360.0);
        if ( majorArc == 180.0 )
        {
            b = 0.0;
            a = 180.0;
        }
        else if ( majorArc == 0.0 )
        {
            a = 0.0;
            b = 180.0;
        }
        else
        {
            b = Math.sqrt(2.0) / (1.0 + AstronomyMaths.tanD(majorArc / 2.0));
            a = b * AstronomyMaths.tanD(majorArc / 2.0);
        }
        alpha = AstronomyMaths.asinD(AstronomyMaths.sinD(majorArc / 2.0) / Math.sqrt((12.0 + 3.0 * b*b - a*a) / 8.0));
        beta = AstronomyMaths.asinD(AstronomyMaths.cosD(majorArc / 2.0) / Math.sqrt((12.0 + 3.0 * a*a - b*b) / 8.0));
        
        switch (cusp)
        {
            case Cusp.House1 : return asLongitude;
            case Cusp.House2 : return AstronomyMaths.mod(asLongitude + beta, 360.0);
            case Cusp.House3 : return AstronomyMaths.mod(mcLongitude - beta + 180.0, 360.0);
            case Cusp.House4 : return AstronomyMaths.mod(mcLongitude + 180.0, 360.0);
            case Cusp.House5 : return AstronomyMaths.mod(mcLongitude + alpha + 180.0, 360.0);
            case Cusp.House6 : return AstronomyMaths.mod(asLongitude - alpha + 180.0, 360.0);
            case Cusp.House7 : return AstronomyMaths.mod(asLongitude + 180.0, 360.0);
            case Cusp.House8 : return AstronomyMaths.mod(asLongitude + beta + 180.0, 360.0);
            case Cusp.House9 : return AstronomyMaths.mod(mcLongitude - beta, 360.0);
            case Cusp.House10 : return mcLongitude;
            case Cusp.House11 : return AstronomyMaths.mod(mcLongitude + alpha, 360.0);
            case Cusp.House12 : return AstronomyMaths.mod(asLongitude - alpha, 360.0);
        }
        return 0.0;
    }
    
    //calculation of the cusps for graduelle
    private double getGraduelle(double asLongitude, double mcLongitude, int cusp)
    {
        double majorArc;
        double length;
        double a;
        double r;
        
        majorArc = AstronomyMaths.mod(asLongitude - mcLongitude, 360.0);
        r = Math.pow((180.0 - majorArc) / majorArc, 1.0 / 3.0);
        a = majorArc * (r - 1.0) / 2.0 / (r*r*r - 1.0);
        
        switch (cusp)
        {
            case Cusp.House1 : return asLongitude;
            case Cusp.House2 : return asLongitude + a * (r*r*r + r*r*r*r);
            case Cusp.House3 : return asLongitude + a * (r*r*r + r*r*r*r)  + 2.0 *  a * r*r*r*r*r;
            case Cusp.House4 : return AstronomyMaths.mod(mcLongitude + 180.0, 360.0);
            case Cusp.House5 : return AstronomyMaths.mod(mcLongitude + a * (r + r*r) + 180.0, 360.0);
            case Cusp.House6 : return AstronomyMaths.mod(mcLongitude + a * (r + r*r)  + 2.0 *  a + 180.0, 360.0);
            case Cusp.House7 : return AstronomyMaths.mod(asLongitude + 180.0, 360.0);
            case Cusp.House8 : return AstronomyMaths.mod(asLongitude + a * (r*r*r + r*r*r*r) + 180.0, 360.0);
            case Cusp.House9 : return AstronomyMaths.mod(asLongitude + a * (r*r*r + r*r*r*r) + 2.0 * a * r*r*r*r*r + 180.0, 360.0);
            case Cusp.House10 : return mcLongitude;
            case Cusp.House11 : return mcLongitude + a * (r + r*r);
            case Cusp.House12 : return mcLongitude + a * (r + r*r) + 2.0 * a;
        }
        return 0.0;
    }
    
    //calculation of the cusps for zenithal
    private double getZenitaleHorizontale(double hvernal, double latitude, double obliquity, int cusp)
    {
        hvernal = AstronomyMaths.mod(hvernal + AstronomyMaths.PI, 2 * AstronomyMaths.PI);
        latitude = AstronomyMaths.PI / 2.0 - latitude;
        return AstronomyMaths.mod(getCampanus(hvernal, latitude, obliquity, cusp) + 180.0, 360.0);
    }
    
    //calculation of the cusps for solar
    private double getSolaire(int cusp)
    {
        return AstronomyMaths.mod(30 * cusp + mSunGeoLong, 360.0);
    }
    
    //calculation of the cusps for nodal
    private double getNodale(int cusp)
    {
        return AstronomyMaths.mod(30 * cusp + mMoonNNodeGeoLong, 360.0);
    }
    
    //Calculation of the cusp for Maternus/AS
    public double getMaternusAS(double asLongitude, int cusp)
    {
        return AstronomyMaths.mod(asLongitude + cusp * 30, 360.0);
    }
    
    //Calculation of the cusp for Porphyre
    private double getPorphyre(double asLongitude, double mcLongitude, int cusp)
    {
        double arc_tiers_ASC_FC;
        double arc_tiers_FC_DS;
        
        arc_tiers_ASC_FC = AstronomyMaths.mod(mcLongitude - asLongitude - 180, 360.0) / 3.0;
        arc_tiers_FC_DS = AstronomyMaths.mod(asLongitude - mcLongitude, 360.0) / 3.0;
        
        switch (cusp)
        {
            case Cusp.House1 : return AstronomyMaths.mod(asLongitude, 360.0);
            case Cusp.House7 : return AstronomyMaths.mod(asLongitude + 180.0, 360.0);
            case Cusp.House10 : return AstronomyMaths.mod(mcLongitude, 360.0);
            case Cusp.House4 : return AstronomyMaths.mod(mcLongitude + 180.0, 360.0);
            case Cusp.House2 : return AstronomyMaths.mod(asLongitude + arc_tiers_ASC_FC, 360.0);
            case Cusp.House3 : return AstronomyMaths.mod(asLongitude  + 2.0 *  arc_tiers_ASC_FC, 360.0);
            case Cusp.House5 : return AstronomyMaths.mod(mcLongitude - 180 + arc_tiers_FC_DS, 360.0);
            case Cusp.House6 : return AstronomyMaths.mod(mcLongitude - 180  + 2.0 *  arc_tiers_FC_DS, 360.0);
            case Cusp.House8 : return AstronomyMaths.mod(asLongitude + 180 + arc_tiers_ASC_FC, 360.0);
            case Cusp.House9 : return AstronomyMaths.mod(asLongitude + 180  + 2.0 *  arc_tiers_ASC_FC, 360.0);
            case Cusp.House11 : return AstronomyMaths.mod(mcLongitude + arc_tiers_FC_DS, 360.0);
            case Cusp.House12 : return AstronomyMaths.mod(mcLongitude  + 2.0 *  arc_tiers_FC_DS, 360.0);
        }
        return 0.0;
    }
    
    //calculation of the cups fore Regiomontanus
    private double getRegiomontanus(double hvernal, double latitude, double obliquity, int cusp)
    {
        double angle = AstronomyMaths.PI / 6.0 * cusp;
        double aux = Math.sin(hvernal + angle) * Math.cos(obliquity) + Math.sin(obliquity) * Math.tan(latitude) * Math.cos(angle);
        
        if ( aux == 0.0 )
        {
            return -90.0 * AstronomyMaths.sgn(Math.cos(hvernal + angle));
        }
        else
        {
            double x = 1.0 / aux;
            return AstronomyMaths.mod(AstronomyMaths.atnD(-Math.cos(hvernal + angle) * x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
        }
    }
    
    //calculation of the cups for Alcabitius
    private double getAlcabitius(double asLongitude, double hvernal, double latitude, double obliquity, int cusp)
    {
        double semiDayArcAS;
        double semiNightArcAS;
        double ad = 0.0;
        double declAS;
        
        declAS = Math.asin(AstronomyMaths.sinD(asLongitude) * Math.sin(obliquity));
        semiNightArcAS = AstronomyMaths.acosD(Math.tan(latitude) * Math.tan(declAS));
        semiDayArcAS = 180.0 - semiNightArcAS;
        hvernal = hvernal * AstronomyMaths.CENT80_SUR_PI;
        
        switch (cusp)
        {
            case Cusp.House1 : ad = hvernal + semiDayArcAS;break;
            case Cusp.House2 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) - 2.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House3 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) - 1.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House4 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0);break;
            case Cusp.House5 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + 1.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House6 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + 2.0 / 3.0 * semiNightArcAS;break;
            case Cusp.House7 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + semiNightArcAS;break;
            case Cusp.House8 : ad = hvernal - 2.0 / 3.0 * semiDayArcAS;break;
            case Cusp.House9 : ad = hvernal - 1.0 / 3.0 * semiDayArcAS;break;
            case Cusp.House10 : ad = hvernal;break;
            case Cusp.House11 : ad = hvernal + 1.0 / 3.0 * semiDayArcAS;break;
            case Cusp.House12 : ad = hvernal + 2.0 / 3.0 * semiDayArcAS;
        }
        return AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(ad) / Math.cos(obliquity))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(ad))), 360.0);
    }
    
    //calculation of the cups fore Campanus
    public double getCampanus(double hvernal, double latitude, double obliquity, int cusp)
    {
        double angle = AstronomyMaths.PI / 6.0 * cusp;
        double x = 1.0 / ((Math.sin(angle) * Math.cos(hvernal) + Math.cos(angle) * Math.sin(hvernal) * Math.cos(latitude)) * Math.cos(obliquity) + Math.sin(obliquity) * Math.sin(latitude) * Math.cos(angle));
        return AstronomyMaths.mod(AstronomyMaths.atnD((Math.sin(angle) * Math.sin(hvernal) - Math.cos(angle) * Math.cos(hvernal) * Math.cos(latitude)) * x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
    }
    
    //calculation of the cups for//Albategnius
    private double getAlbategnius(double hvernal, double latitude, double obliquity, int cusp)
    {
        double semiDayArcSun;
        double semiNightArcSun;
        double ad = 0.0;
        double declSun;
        
        declSun = mSunDecl;
        semiNightArcSun = AstronomyMaths.acosD(Math.tan(latitude) * AstronomyMaths.tanD(declSun));
        semiDayArcSun = 180 - semiNightArcSun;
        hvernal = hvernal * AstronomyMaths.CENT80_SUR_PI;
        
        switch (cusp)
        {
            case Cusp.House1 : ad = hvernal + semiDayArcSun;break;
            case Cusp.House2 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) - 2.0 / 3.0 * semiNightArcSun;break;
            case Cusp.House3 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) - 1.0 / 3.0 * semiNightArcSun;break;
            case Cusp.House4 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0);break;
            case Cusp.House5 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + 1.0 / 3.0 * semiNightArcSun;break;
            case Cusp.House6 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + 2.0 / 3.0 * semiNightArcSun;break;
            case Cusp.House7 : ad = AstronomyMaths.mod(hvernal + 180.0, 360.0) + semiNightArcSun;break;
            case Cusp.House8 : ad = hvernal - 2.0 / 3.0 * semiDayArcSun;break;
            case Cusp.House9 : ad = hvernal - 1.0 / 3.0 * semiDayArcSun;break;
            case Cusp.House10 : ad = hvernal;break;
            case Cusp.House11 : ad = hvernal + 1.0 / 3.0 * semiDayArcSun;break;
            case Cusp.House12 : ad = hvernal + 2.0 / 3.0 * semiDayArcSun;break;
        }
        
        return AstronomyMaths.mod(AstronomyMaths.atnD(AstronomyMaths.tanD(ad) / Math.cos(obliquity))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(ad))), 360.0);
    }
    
    //calculation of the cups fore Koch
    private double getKoch(double hvernal, double latitude, double obliquity, int cusp)
    {
        double semiDayArcMC;
        double Az;
        double x;
        
        semiDayArcMC = AstronomyMaths.acosD(-Math.sin(hvernal) * Math.tan(obliquity) * Math.tan(latitude));
        hvernal = hvernal * AstronomyMaths.CENT80_SUR_PI;
        
        switch (cusp)
        {
            case Cusp.House1:
                Az = hvernal;
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House2:
                Az = AstronomyMaths.mod(hvernal + semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House3:
                Az = AstronomyMaths.mod(hvernal  + 2.0 *  semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House4:
                Az = AstronomyMaths.mod(hvernal + semiDayArcMC, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House5:
                Az = AstronomyMaths.mod(hvernal - 2 * semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x) + 180  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House6:
                Az = AstronomyMaths.mod(hvernal - semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x) + 180  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House7:
                Az = hvernal;
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x) + 180  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House8:
                Az = AstronomyMaths.mod(hvernal + semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x) + 180  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House9:
                Az = AstronomyMaths.mod(hvernal  + 2.0 *  semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x) + 180  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House10:
                Az = AstronomyMaths.mod(hvernal - semiDayArcMC, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House11:
                Az = AstronomyMaths.mod(hvernal - 2.0 * semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
            case Cusp.House12:
                Az = AstronomyMaths.mod(hvernal - semiDayArcMC  / 3.0, 360.0);
                x = Math.tan(latitude) * Math.sin(obliquity) + Math.cos(obliquity) * AstronomyMaths.sinD(Az);
                return AstronomyMaths.mod(AstronomyMaths.atnD(-AstronomyMaths.cosD(Az) / x)  + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0);
                
        }
        return 0.0;
    }
    
    //Calculation of the cusp for Maternus/MC
    private double getMaternusMC(double mcLongitude, int cusp)
    {
        return AstronomyMaths.mod(mcLongitude + (cusp + 3) * 30, 360.0);
    }
    
    //calculation of the cups fore Placidus
    private double getPlacidus(double asLongitude, double mcLongitude, double hvernal, double latitude, double obliquity, int cusp)
    {
        double l;
        double old_l;
        double x;
        
        //principe du calcul :
        //angle horaire H=0 pour le Milieu du Ciel
        //angle horaire H=abs(atn(sqr(Cos(latitude)^2/sin(declinaison)^2-1)/Sin(latitude))) pour le descendant
        //H=cusp/3*(angle horaire de l//AS) pour les pointes intermediaires entre MC et DS
        //angle horaire H=-abs(atn(sqr(Cos(latitude)^2/sin(declinaison)^2-1)/Sin(latitude))) pour l//ascendant
        if ( Math.abs(latitude) >= AstronomyMaths.PI / 2.0 - obliquity - 0.00000001 )
        {
            if ( cusp == 0 )
            {
                return asLongitude;
            }
            else if ( cusp == Cusp.House6 )
            {
                return AstronomyMaths.mod(asLongitude + 180.0, 360.0);
            }
            else if ( cusp > 0 && cusp < Cusp.House6 )
            {
                return AstronomyMaths.mod(mcLongitude + 180.0, 360.0);
            }
        }
        else
        {
            if ( AstronomyMaths.modulo(cusp, 3) == 0 )
            {
                switch (cusp)
                {
                    case 0 : return asLongitude;
                    case 6 : return asLongitude + 180.0;
                    case 3 : return mcLongitude - 180.0;
                    case 9 : return mcLongitude;
                }
            }
            else
            {
                l = hvernal;
                old_l = l + AstronomyMaths.PI / 2.0;
                while (AstronomyMaths.mod(Math.abs(l - old_l), AstronomyMaths.PI) > 0.000001)
                {
                    old_l = l;
                    if ( Math.abs(l) < 0.000000000001 )
                    {
                        x = AstronomyMaths.PI / 2.0;
                    }
                    else
                    {
                        if ( latitude != 0.0 )
                        {
                            x = Math.cos(latitude) / Math.sin(obliquity) / Math.sin(l);
                            if ( Math.abs(x) < 1.0 )
                            {
                                return 0.0;
                            }
                            x = Math.sqrt(x*x - 1.0) / Math.sin(latitude) * AstronomyMaths.sgn(AstronomyMaths.tanD(mcLongitude - asLongitude));
                            x = AstronomyMaths.mod(Math.atan(x), AstronomyMaths.PI);
                        }
                        else
                        {
                            x = AstronomyMaths.PI / 2.0;
                        }
                        x = hvernal - (3.0 - AstronomyMaths.mod(cusp, 6.0)) / 3.0 * (x * (1.0 - (double)(int)(AstronomyMaths.mod(cusp, 6.0) / 4.0)) + AstronomyMaths.mod(AstronomyMaths.PI - x, AstronomyMaths.PI) * (double)(int)(AstronomyMaths.mod(cusp, 6.0) / 4.0));
                        if ( Math.abs(Math.abs(x) - AstronomyMaths.PI / 2.0) < 0.00000001 )
                        {
                            l = AstronomyMaths.PI / 2.0;
                        }
                        else
                        {
                            l = Math.atan(Math.tan(x) / Math.cos(obliquity)) + AstronomyMaths.PI / 2.0 * (1.0 - AstronomyMaths.sgn(Math.cos(x)));
                        }
                    }
                }
                if ( cusp > 6 )
                {
                    l = l + AstronomyMaths.PI;
                }
                return AstronomyMaths.mod(l * AstronomyMaths.CENT80_SUR_PI - 180.0, 360.0);
            }
        }
        return 0.0;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public void cuspsCalculation(ChartElements chartElements)
    {
        ChartEvent ev = (ChartEvent)chartElements.getChartEvents().get(0);
        AllCoord mCusps;
        if (chartElements.getChartCoords() == null || chartElements.getChartCoords().size() == 0)
        {
            mCusps = new AllCoord();
            ArrayList positions = new ArrayList();
            positions.add(mCusps);
            chartElements.setChartCoords(positions);
        }
        else
        {
            mCusps = (AllCoord)chartElements.getChartCoords().get(0);
        }
        int houseSys = chartElements.getHouseSys();
        int i;
        //cusps
        double m[] = new double[14];
        //micheaven
        double mc;
        //auxiliary variable
        double angle;
        //vernal point
        double hgamma;
        //latitude
        double latitude;
        //inclination of the equator on the ecliptic in degrees
        double obliquity;
        //latitude of the cusps in degrees
        double latH[] = new double[14];
        //declinaison of the cusps
        double declH[] = new double[14];
        //right ascension of the cusps
        double raH[] = new double[14];
        //azimut of the cusps
        double azH[] = new double[14];
        //hauteur of the cusps
        double altH[] = new double[14];
        Coord c = new Coord();
        //=========================================================================
        
        hgamma = 15.0 * ev.getLST() * AstronomyMaths.PI_SUR_CENT80;
        
        //Domifications ne supportant pas les latitudes polaires
        if ((houseSys == HouseSystem.Placidus) || (houseSys == HouseSystem.Albategnius) || (houseSys == HouseSystem.Alcabitius) || (houseSys == HouseSystem.Abenragel) || (houseSys == HouseSystem.Koch) )
        {
            if ( Math.abs(ev.getPlaceLat()) > 90.0 - ev.getObliquity() )
            {
                houseSys = HouseSystem.Campanus;
                chartElements.setHouseSys(houseSys);
            }
        }
        
        latitude = ev.getPlaceLat() * AstronomyMaths.PI_SUR_CENT80;
        obliquity = ev.getObliquity() * AstronomyMaths.PI_SUR_CENT80;
        
        //AllC de l//Ascendant et du Milieu du Ciel
        m[Cusp.Ascendant] = getCampanus(hgamma, latitude, obliquity, Cusp.House1);
        m[Cusp.Midheaven] = getCampanus(hgamma, latitude, obliquity, Cusp.House10);
        
        for (i=0; i<=Cusp.House12; i++)
        {
            switch(houseSys)
            {
                case HouseSystem.Placidus : m[i] = getPlacidus(m[Cusp.Ascendant], m[Cusp.Midheaven], hgamma, latitude, obliquity, i);break;
                case HouseSystem.Campanus : m[i] = getCampanus(hgamma, latitude, obliquity, i);break;
                case HouseSystem.Regiomontanus : m[i] = getRegiomontanus(hgamma, latitude, obliquity, i);break;
                case HouseSystem.Porphyre : m[i] = getPorphyre(m[Cusp.Ascendant], m[Cusp.Midheaven], i);break;
                case HouseSystem.MaternusAs : m[i] = getMaternusAS(m[Cusp.Ascendant], i);break;
                case HouseSystem.MaternusMC : m[i] = getMaternusMC(m[Cusp.Midheaven], i);break;
                case HouseSystem.Koch : m[i] = getKoch(hgamma, latitude, obliquity, i);break;
                case HouseSystem.Albategnius : m[i] = getAlbategnius(hgamma, latitude, obliquity, i);break;
                case HouseSystem.Alcabitius : m[i] = getAlcabitius(m[Cusp.Ascendant], hgamma, latitude, obliquity, i);break;
                case HouseSystem.Abenragel : m[i] = getAbenragel(m[Cusp.Ascendant], hgamma, latitude, obliquity, i);break;
                case HouseSystem.TwoHours : m[i] = getBiHoraire(hgamma, obliquity, i);break;
                case HouseSystem.Wiesel : m[i] = getWiesel(m[Cusp.Ascendant], obliquity, i);break;
                case HouseSystem.Ancient : m[i] = getAntique(m[Cusp.Ascendant], i);break;
                case HouseSystem.Zodiacal : m[i] = getZodiacale(m[Cusp.Ascendant], i);break;
                case HouseSystem.Bazchenoff : m[i] = getHarmonique(m[Cusp.Ascendant], m[Cusp.Midheaven], i);break;
                case HouseSystem.ColinEvans : m[i] = getGraduelle(m[Cusp.Ascendant], m[Cusp.Midheaven], i);break;
                case HouseSystem.Zenithal : m[i] = getZenitaleHorizontale(hgamma, latitude, obliquity, i);break;
                case HouseSystem.Solar : m[i] = getSolaire(i);break;
                case HouseSystem.Nodal : m[i] = getNodale(i);break;
                case HouseSystem.EquatorialRegular : m[i] = getEquatorialeDiisogone(m[Cusp.Ascendant], m[Cusp.Midheaven], hgamma, obliquity, i);break;
                case HouseSystem.SemiAngular : m[i] = getBissectrices(m[Cusp.Ascendant], m[Cusp.Midheaven], i);break;
                default : m[i] = 0.0;
            }
        }
        
        //cusps in other coordinates
        for (i=0; i<=Cusp.Midheaven; i++)
        {
            latH[i] = 0.0;
            raH[i] = AstronomyMaths.atnD(Math.cos(obliquity) * AstronomyMaths.tanD(m[i]))  + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(m[i])));
            declH[i] = AstronomyMaths.asinD(Math.sin(obliquity) * AstronomyMaths.sinD(m[i]));
            c.setDecl(declH[i]);
            c.setRA(raH[i]);
            azH[i] = c.azFromEquatorial(ev.getPlaceLat(), ev.getLST());
            altH[i] = c.altFromEquatorial(ev.getPlaceLat(), ev.getLST());
            
            if ( i < Cusp.Ascendant )
            {
                int ii = i + Planets.MC + 1;
                mCusps.get(ii).setSiderGeoLong(m[i] - ev.getAyanamsa());
                mCusps.get(ii).setDecl(declH[i]);
                mCusps.get(ii).setRA(raH[i]);
                mCusps.get(ii).setAz(azH[i]);
                mCusps.get(ii).setAlt(altH[i]);
                mCusps.get(ii).setTropicGeoLong(m[i]);
                mCusps.get(ii).setGeoLat(0.0);
                mCusps.get(ii).setTropicHelioLong(m[i]);
                mCusps.get(ii).setSiderHelioLong(m[i] - ev.getAyanamsa());
                mCusps.get(ii).setGeoDist(0.0);
                mCusps.get(ii).setHelioDist(0.0);
            }
        }
        
        mCusps.get(Planets.AS).setSiderGeoLong(m[Cusp.Ascendant] - ev.getAyanamsa());
        mCusps.get(Planets.AS).setDecl(declH[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setRA(raH[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setAz(azH[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setAlt(altH[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setTropicGeoLong(m[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setGeoLat(0.0);
        mCusps.get(Planets.AS).setTropicHelioLong(m[Cusp.Ascendant]);
        mCusps.get(Planets.AS).setSiderHelioLong(m[Cusp.Ascendant] - ev.getAyanamsa());
        mCusps.get(Planets.AS).setGeoDist(0.0);
        mCusps.get(Planets.AS).setHelioDist(0.0);
        
        mCusps.get(Planets.MC).setSiderGeoLong(m[Cusp.Midheaven] - ev.getAyanamsa());
        mCusps.get(Planets.MC).setDecl(declH[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setRA(raH[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setAz(azH[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setAlt(altH[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setTropicGeoLong(m[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setGeoLat(0.0);
        mCusps.get(Planets.MC).setTropicHelioLong(m[Cusp.Midheaven]);
        mCusps.get(Planets.MC).setSiderHelioLong(m[Cusp.Midheaven] - ev.getAyanamsa());
        mCusps.get(Planets.MC).setGeoDist(0.0);
        mCusps.get(Planets.MC).setHelioDist(0.0);
        
        return;
    }
}
