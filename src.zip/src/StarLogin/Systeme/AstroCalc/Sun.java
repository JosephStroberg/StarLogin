package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Sun
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mTrueSunLongitude;
    private double mSunLongitude;
    private double mSunEarthDist;
    private double mEarthExcentricity;
    //private double mPlaceLong;
    //private double mJDay;
    
    /** Creates new Sun */
    public Sun(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public double getTrueSunLongitude()
    {
        return mTrueSunLongitude;
    }
    
    public double getSunLongitude()
    {
        return mSunLongitude;
    }
    
    public double getSunEarthDist()
    {
        return mSunEarthDist;
    }
    
    public double getEarthExcentricity()
    {
        return mEarthExcentricity;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Sun;
        mTSL = chartEvent.getLST();
        double mMoonNNode = chartEvent.getMeanNN();
        double mObliquity = chartEvent.getObliquity();
        
        mCoord.setGeoLat(0.0);
        mTrueSunLongitude = l[mNumber] + ((6910.0 - 17.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) + 72.0 * AstronomyMaths.sinD(2.0 * m[mNumber]) - 7.0 * AstronomyMaths.cosD(m[mNumber] - m[Planets.Jupiter]) + 6.0 * AstronomyMaths.sinD(l[Planets.Moon] - l[mNumber]) + 5.0 * (AstronomyMaths.sinD(4.0 * m[mNumber] - 8.0 * m[Planets.Mars] + m[Planets.Jupiter]) - AstronomyMaths.cosD(2.0 * (m[mNumber] - m[Planets.Venus]))) + 4.0 * (AstronomyMaths.cosD(4.0 * m[mNumber] - 8.0 * m[Planets.Mars] + m[Planets.Jupiter]) - AstronomyMaths.sinD(m[mNumber] - m[Planets.Venus])) + 3.0 * (AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Venus])) - AstronomyMaths.sinD(m[Planets.Jupiter]) - AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Jupiter])))) / 3600.0;
        mTrueSunLongitude = AstronomyMaths.modulo(mTrueSunLongitude, 360.0);
        mCoord.setTropicGeoLong(AstronomyMaths.modulo(mTrueSunLongitude - 0.00569 - 0.004722222 * AstronomyMaths.sinD(mMoonNNode), 360.0));
        mSunLongitude = mCoord.getTropicGeoLong();
        mEarthExcentricity = Math.pow(0.01675104 - 0.0000418 * mCTime - 0.000000126 * mCTime, 2.0);
        mCoord.setGeoDist(1.0000002 * (1.0 + 0.5 * Math.pow(mEarthExcentricity, 2.0) * (1.0 - AstronomyMaths.cosD(2.0 * m[mNumber])) - (mEarthExcentricity - 0.375 * Math.pow(mEarthExcentricity, 3.0)) * AstronomyMaths.cosD(m[mNumber]) - 0.375 * Math.pow(mEarthExcentricity, 3.0) * AstronomyMaths.cosD(3.0 * m[mNumber])));
        mSunEarthDist = mCoord.getGeoDist();
        mCoord.setDecl(AstronomyMaths.asinD(AstronomyMaths.sinD(mObliquity) * AstronomyMaths.sinD(mCoord.getTropicGeoLong())));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setTropicHelioLong(mCoord.getTropicGeoLong()); //(cas Philippe) ou bien : longitude_helio(soleil) = 0
        mCoord.setHelioLat(0.0);
        mCoord.setHelioDist(0.0);           
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
    
}
