package StarLogin.Systeme.AstroCalc;

import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Enum.AspectType;
import StarLogin.Systeme.Enum.ChartKind;
import StarLogin.Systeme.Enum.Planets;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class AspectsCalc
{
    
    private String aspectKinds[][]= new String[Planets.MC + 1][Planets.MC + 1];         //aspects kinds
    private double aspectValues[][]= new double[Planets.MC + 1][Planets.MC + 1];        //Value of aspects
    private String relativeAspects[][]= new String[Planets.MC + 1][Planets.MC + 1];     //relative aspects values
    private short spire[][]= new short[Planets.MC + 1][Planets.MC + 1];                 //spiral number in relative aspects values
    
    /** Creates a new instance of AspectsCalc */
    public AspectsCalc()
    {
    }
    
    public String[][] getAspectsKinds()
    {
        return aspectKinds;
    }
    
    public double[][] getAspectsValues()
    {
        return aspectValues;
    }
    
    public String[][] getRelativeAspects()
    {
        return relativeAspects;
    }
    
    public short[][] getSpires()
    {
        return spire;
    }
    
    //=========================================================================
    //Calculation of aspects existant entre les astres et points du ciel pris deux � deux
    //input :
    //=========================================================================
    public void aspectsCalculation(int tableau_flag, AllCoord pos1, AllCoord pos2, ChartElements chartElements, int chartKind)
    {
        double orbe;
        double ecart = 0.0;
        double orbe_rel;
        double ecart_rel;
        //indices
        int i;
        int j;
        int k;
        //ecart Soleil-Ascendant
        double ecart_Soleil_AS = 0.0;
        //current coordinates
        double coord1[] = new double[Planets.MC + 1];
        double coord2[] = new double[Planets.MC + 1];
        //ecart en valeur absolue
        //double ecart = 0.0;
        int sens = tableau_flag;
        //==================================
        
        for (i = 0; i <= Planets.MC; i++)
        {
            for (j = 0; j <= Planets.MC; j++)
            {
                relativeAspects[i][j] = "";
                spire[i][j] = 1;
                aspectKinds[i][j] = "";
            }
            coord1[i] = pos1.get(i).getCoord1(chartElements.getCoordSys());
            coord2[i] = pos2.get(i).getCoord1(chartElements.getCoordSys());
        }
        
        //ecart Soleil-Ascendant pour les aspects relatifs
        //NOTE : l'aspect relatif est l'aspect calcule relativement � l'ecart
        //       Soleil-Ascendant qui est considere comme une opposition
        switch(sens)
        {
            case Astrology.POS_1 : ecart_Soleil_AS = Math.abs(coord1[Planets.Sun] - coord1[Planets.AS]); break;
            case Astrology.POS_2 : ecart_Soleil_AS = Math.abs(coord2[Planets.Sun] - coord2[Planets.AS]); break;
            case Astrology.POS_1_2 : ecart_Soleil_AS = Math.abs(coord1[Planets.Sun] - coord2[Planets.AS]); break;
            case Astrology.POS_2_1 : ecart_Soleil_AS = Math.abs(coord2[Planets.Sun] - coord1[Planets.AS]); break;
        }
        
        ecart_Soleil_AS = AstronomyMaths.modulo(ecart_Soleil_AS, 360.0);
        if (ecart_Soleil_AS > 180.0)
        {
            ecart_Soleil_AS = 360.0 - ecart_Soleil_AS;
        }
        for (i = 0; i <= Planets.MC; i++)
        {
            if ( i >= Planets.Pluto && chartKind == ChartKind.projective ) break;
            if ( (chartElements.getShownObject(i)) && (chartElements.getAspectsObject(i)) )
            {
                for (j = 0; j <= Planets.MC; j++)
                {
                    if ( j >= Planets.Pluto && chartKind == ChartKind.projective ) break;
                    if ( (chartElements.getShownObject(j)) && (chartElements.getAspectsObject(j)) )
                    {
                        if ( i == j && (sens == Astrology.POS_1 || sens == Astrology.POS_2) )
                        {
                            j += 1;
                            if ( j > Planets.MC ) break;
                            
                            while(!((chartElements.getShownObject(j)) && (chartElements.getAspectsObject(j))))
                            {
                                j += 1;
                                if ( j > Planets.MC ) break;
                            }
                            if ( j > Planets.MC ) break;
                        }
                        
                        //ecart angulaire entre les deux astres
                        switch(sens)
                        {
                            case Astrology.POS_1 : ecart = coord1[i] - coord1[j]; break;
                            case Astrology.POS_2 : ecart = coord2[i] - coord2[j]; break;
                            case Astrology.POS_1_2 : ecart = coord1[i] - coord2[j]; break;
                            case Astrology.POS_2_1 : ecart = coord2[i] - coord1[j]; break;
                        }
                        
                        //set the angle elements in pos1 and pos2
                        //ecart = ecart;
                        
                        ecart = AstronomyMaths.modulo(ecart, 360.0);
                        if (ecart > 180.0)
                        {
                            ecart = 360.0 - ecart;
                        }
                        //ecart = (double)(int)(ecart * 1000.0) / 1000.0;
                        aspectValues[i][j] = ecart;
                        
                        //End of this calculation
                        //ecart = Math.abs(ecart);
                        //ecart = Math.abs(ecart - 360.0 * (double)(int)(ecart / 180.0));
                        
                        //cas des aspects relatifs
                        if ( ecart_Soleil_AS == 0.0 )
                        {
                            spire[i][j] = 0;
                            ecart_rel = 0.0;
                        }
                        else
                        {
                            ecart_rel = ecart;
                            spire[i][j] = (short)(ecart_rel / 2.0 / ecart_Soleil_AS + 1.0);
                            ecart_rel = Math.abs(ecart_rel - 2.0 * ecart_Soleil_AS * (double)(int)(ecart_rel / ecart_Soleil_AS));
                            ecart_rel = AstronomyMaths.frac(ecart_rel / ecart_Soleil_AS) * 180.0;
                        }
                        
                        //relative aspect
                        for (k = 0; k <= AspectType.lastAspect; k++)
                        {
                            //orbe de l'aspect
                            if ( i <= j )
                            {
                                orbe = AspectType.orbCalculation(i, j, k, chartElements);
                            }
                            else
                            {
                                orbe = AspectType.orbCalculation(j, i, k, chartElements);
                            }
                            
                            //modification de l'orbe pour les aspects relatifs
                            orbe_rel = orbe * ecart_Soleil_AS / 180.0;
                            
                            //diminution de l'orbe en cas de comparaison de cartes
                            //(pour diminuer le nombre d'aspects affiches)
                            if ( (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.transit) )
                            {
                                orbe_rel = orbe_rel / 3.0;
                            }
                            
                            //relative aspect value
                            if ( (orbe_rel >= 0) && (Math.abs(ecart_rel - AspectType.getAspectValue(k, chartElements)) <= orbe_rel) )
                            {
                                FDegree flng = new FDegree(ecart_rel);
                                relativeAspects[i][j] = FDegree.formatDegree((int)AstronomyMaths.getRnd(ecart_rel,  0)) + " " + AspectType.getAspectSymbol(k);
                                break;
                            }
                        }
                        
                        //normal aspects
                        for (k = 0; k <= AspectType.lastAspect; k++)
                        {
                            //orbe de l'aspect
                            if ( i <= j )
                            {
                                orbe = AspectType.orbCalculation(i, j, k, chartElements);
                            }
                            else
                            {
                                orbe = AspectType.orbCalculation(j, i, k, chartElements);
                            }
                            
                            //diminution de l'orbe en cas de comparaison de cartes
                            //(pour diminuer le nombre d'aspects affiches)
                            if ( (chartKind == ChartKind.symbolicDir) || (chartKind == ChartKind.secondaryDir) || (chartKind == ChartKind.primaryDir) || (chartKind == ChartKind.transit) )
                            {
                                orbe = orbe / 3.0;
                            }
                            
                            //normal aspect value
                            if ( (orbe >= 0) && (Math.abs(ecart - AspectType.getAspectValue(k, chartElements)) <= orbe) )
                            {
                                aspectKinds[i][j] = AspectType.getAspectSymbol(k);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
}
