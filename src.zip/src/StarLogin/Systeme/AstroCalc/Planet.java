package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
//import StarLogin.Systeme.AstroCalc.ChartEvent;
//import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;

public class Planet
{
    private double mPlaceLat;
    private double mPlaceLong;
    private double mCTime;
    private int mNumber;
    private double mObliquity;
    private Coord mCoord = new Coord();
    private String mPlanetName;
    private double mTSL;
    private double mJDay;
    private double mMoonNNode;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    private double mSunLongitude;
    private double mEarthExcentricity;  //eccentricity of the Earth
    private ChartEvent chartEvent;
    private boolean trueLilith;
    
    
    /** Creates new Planet */
    public Planet(ChartEvent chartEvent, boolean trueLilith)
    {
        this.chartEvent = chartEvent;
        this.trueLilith = trueLilith;
    }
    
    public double getEarthExcentricity()
    {
        return mEarthExcentricity;
    }
    
    public double getTrueSunLongitude()
    {
        return mTrueSunLongitude;
    }
    
    public double getSunEarthDist()
    {
        return mSunEarthDist;
    }
    
    public double getMoonNNode()
    {
        return mMoonNNode;
    }
    
    public double getJDay()
    {
        return mJDay;
    }
    
    public double getTSL()
    {
        return mTSL;
    }
    
    public String getPlanetName()
    {
        return mPlanetName;
    }
    
    public Coord getCoordinates()
    {
        return mCoord;
    }
    
    public double getObliquity()
    {
        return mObliquity;
    }
    
    public double getNumber()
    {
        return mNumber;
    }
    
    public double getCTime()
    {
        return mCTime;
    }
    
    public double getPlaceLong()
    {
        return mPlaceLong;
    }
    
    public double getPlaceLat()
    {
        return mPlaceLat;
    }
    
    //Calculation of the position of a planet for the considered event
    public Coord getObjPosition(int planet)
    {
        Sun sun = new Sun(chartEvent);
        Moon moon = new Moon(chartEvent);
        Mercury mercury = new Mercury(chartEvent);
        Venus venus = new Venus(chartEvent);
        Mars mars = new Mars(chartEvent);
        Jupiter jupiter = new Jupiter(chartEvent);
        Saturn saturn = new Saturn(chartEvent);
        Uranus uranus = new Uranus(chartEvent);
        Neptune neptune = new Neptune(chartEvent);
        Pluto pluto = new Pluto(chartEvent);
        Gaia gaia = new Gaia(chartEvent);
        NorthNode northNode = new NorthNode(chartEvent);
        Lilith lilith = new Lilith(chartEvent, trueLilith);
        East east = new East(chartEvent);
        Vertex vertex = new Vertex(chartEvent);
        Zenith zenith = new Zenith(chartEvent);
        Vulcan vulcan = new Vulcan(chartEvent);
        Coord mAuxCoords = new Coord();
        
        //mean longitude
        double l[]=
        {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        //mean anomaly
        double m[]=
        {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        //argument of the latitude
        double u[]=
        {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        //=======================================================
        
        mCTime = chartEvent.getCTimeH();
        //calculation of the planetary coordinates
        for (int i = 0; i <= Planets.Pluto; i++)
        {
            l[i] = AstronomyMaths.modulo(MainClass.astrobj[i].getMeanLong0() + mCTime * MainClass.astrobj[i].getMeanLong1(), 360.0);
            m[i] = AstronomyMaths.modulo(MainClass.astrobj[i].getMeanAnomal0() + mCTime * MainClass.astrobj[i].getMeanAnomal1(), 360.0);
            u[i] = AstronomyMaths.modulo(MainClass.astrobj[i].getArgLat0() + mCTime * MainClass.astrobj[i].getArgLat1(), 360.0);
        }
        
        mNumber = planet;
        mPlaceLat = chartEvent.getPlaceLat();
        mPlaceLong = chartEvent.getPlaceLong();
        mJDay = chartEvent.getJD();
        mPlanetName = MainForm.planetName[planet];
        mTSL = chartEvent.getLST();
        mMoonNNode = chartEvent.getMeanNN();
        mObliquity = chartEvent.getObliquity();
        
        switch (mNumber)
        {
            case Planets.Sun:
                mCoord = sun.getObjPosition(l,m,u);
                break;
                
            case Planets.Moon:
                mAuxCoords = sun.getObjPosition(l,m,u);
                moon.setSunEarthDist(sun.getSunEarthDist());
                moon.setSunLongitude(sun.getSunLongitude());
                mCoord = moon.getObjPosition(l,m,u);
                break;
                
            case Planets.Mercury:
                mAuxCoords = sun.getObjPosition(l,m,u);
                mercury.setSunEarthDist(sun.getSunEarthDist());
                mercury.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = mercury.getObjPosition(l,m,u);
                break;
                
            case Planets.Venus:
                mAuxCoords = sun.getObjPosition(l,m,u);
                venus.setSunEarthDist(sun.getSunEarthDist());
                venus.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = venus.getObjPosition(l,m,u);
                break;
                
            case Planets.Mars:
                mAuxCoords = sun.getObjPosition(l,m,u);
                mars.setSunEarthDist(sun.getSunEarthDist());
                mars.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = mars.getObjPosition(l,m,u);
                break;
                
            case Planets.Jupiter:
                mAuxCoords = sun.getObjPosition(l,m,u);
                jupiter.setSunEarthDist(sun.getSunEarthDist());
                jupiter.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = jupiter.getObjPosition(l,m,u);
                break;
                
            case Planets.Saturn:
                mAuxCoords = sun.getObjPosition(l,m,u);
                saturn.setSunEarthDist(sun.getSunEarthDist());
                saturn.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = saturn.getObjPosition(l,m,u);
                break;
                
            case Planets.Uranus:
                mAuxCoords = sun.getObjPosition(l,m,u);
                uranus.setSunEarthDist(sun.getSunEarthDist());
                uranus.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = uranus.getObjPosition(l,m,u);
                break;
                
            case Planets.Neptune:
                mAuxCoords = sun.getObjPosition(l,m,u);
                neptune.setSunEarthDist(sun.getSunEarthDist());
                neptune.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = neptune.getObjPosition(l,m,u);
                break;
                
            case Planets.Pluto:
                mAuxCoords = sun.getObjPosition(l,m,u);
                pluto.setSunEarthDist(sun.getSunEarthDist());
                pluto.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = pluto.getObjPosition(l,m,u);
                break;
                
            case Planets.Gaia:
                mAuxCoords = sun.getObjPosition(l,m,u);
                gaia.setSunEarthDist(sun.getSunEarthDist());
                gaia.setSunLongitude(sun.getSunLongitude());
                mCoord = gaia.getObjPosition(l,m,u);
                break;
                
            case Planets.NorthNode:
                mAuxCoords = sun.getObjPosition(l,m,u);
                northNode.setSunEarthDist(sun.getSunEarthDist());
                northNode.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = northNode.getObjPosition(l,m,u);
                break;
                
            case Planets.Lilith:
                mAuxCoords = sun.getObjPosition(l,m,u);
                lilith.setSunEarthDist(sun.getSunEarthDist());
                lilith.setTrueSunLongitude(sun.getTrueSunLongitude());
                mAuxCoords = moon.getObjPosition(l,m,u);
                lilith.setMoonGeoDist(moon.getGeoDist());
                lilith.setMoonGeoLat(moon.getGeoLat());
                lilith.setMoonHelioDist(moon.getHelioDist());
                lilith.setMoonTropicGeoLong(moon.getTropicGeoLong());
                mAuxCoords = northNode.getObjPosition(l,m,u);
                lilith.setMoonNodeTropicGeoLong(northNode.getTropicGeoLong());
                mCoord = lilith.getObjPosition(l,m,u);
                break;
                
            case Planets.East:
                mAuxCoords = sun.getObjPosition(l,m,u);
                east.setSunEarthDist(sun.getSunEarthDist());
                east.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = east.getObjPosition(l,m,u);
                break;
                
            case Planets.Zenith:
                mAuxCoords = sun.getObjPosition(l,m,u);
                zenith.setSunEarthDist(sun.getSunEarthDist());
                zenith.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = zenith.getObjPosition(l,m,u);
                break;
                
            case Planets.Vertex:
                mAuxCoords = sun.getObjPosition(l,m,u);
                vertex.setSunEarthDist(sun.getSunEarthDist());
                vertex.setTrueSunLongitude(sun.getTrueSunLongitude());
                mCoord = vertex.getObjPosition(l,m,u);
                break;
                
            case Planets.Vulcan:
                mAuxCoords = sun.getObjPosition(l,m,u);
                vulcan.setSunEarthDist(sun.getSunEarthDist());
                vulcan.setSunLongitude(sun.getSunLongitude());
                mCoord = vulcan.getObjPosition(l,m,u);
                break;
                
            default:
                break;
        }
        return mCoord;
    }
}
