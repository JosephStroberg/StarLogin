package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class RiseSetMeridian
{
    private String meridianTime;
    private String riseTime;
    private String setTime;
    private String risePosition;
    private String setPosition;
    
    /** Creates a new instance of RiseSetMeridian */
    public RiseSetMeridian()
    {
    }
    
    public String getMeridianTime()
    {
        return meridianTime;
    }
    
    public String getRiseTime()
    {
        return riseTime;
    }
    
    public String getSetTime()
    {
        return setTime;
    }
    
    public String getRisePosition()
    {
        return risePosition;
    }
    
    public String getSetPosition()
    {
        return setPosition;
    }
    
    public void setMeridianTime(String sData)
    {
        meridianTime = sData;
    }
    
    public void setRiseTime(String sData)
    {
        riseTime = sData;
    }
    
    public void setSetTime(String sData)
    {
        setTime = sData;
    }
    
    public void setRisePosition(String sData)
    {
        risePosition = sData;
    }
    
    public void setSetPosition(String sData)
    {
        setPosition = sData;
    }
    
}
