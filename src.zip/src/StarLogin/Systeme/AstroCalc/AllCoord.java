package StarLogin.Systeme.AstroCalc;

//import StarLogin.Systeme.AstroCalc.Coord;
import StarLogin.Systeme.Enum.Planets;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class AllCoord
{
    private ArrayList allCoord;
    private int index;
    
    /** Creates new AllCoord */
    //get the current record
    @SuppressWarnings("unchecked")
    public AllCoord()
    {
        allCoord = new ArrayList();
        for (int i=0; i<=Planets.getLast(); i++)
        {
            Coord coord = new Coord();
            allCoord.add(coord);
        }
    }
    
    public AllCoord cloneCoords()
    {
        AllCoord allC = new AllCoord();
        for (int i=0; i<=Planets.getLast(); i++)
        {
            allC.set(this.get(i), i);
        }
        return allC;
    }
    
    public ArrayList getCoords()
    {
        return allCoord;
    }
    
    public Coord get(int index)
    {
        return (Coord)allCoord.get(index);//.elementAt(index);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public void set(Coord coord, int index)
    {
        allCoord.set(index, coord);//.setElementAt(coord, index);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public void set(double Ayanamsa, double Az, double Alt, double RA, double Decl, double GeoDist, double GeoLat, double SiderGeoLong, double TropicGeoLong, double HelioDist, double HelioLat, double SiderHelioLong, double TropicHelioLong, double x, double y, double z, double Radius, double Theta, double Phi, int retro, int index)
    {
        Coord coord = new Coord();
        
        coord.setAyanamsa(Ayanamsa);
        coord.setAz(Az);
        coord.setAlt(Alt);
        coord.setRA(RA);
        coord.setDecl(Decl);
        coord.setGeoDist(GeoDist);
        coord.setGeoLat(GeoLat);
        coord.setSiderGeoLong(SiderGeoLong);
        coord.setTropicGeoLong(TropicGeoLong);
        coord.setHelioDist(HelioDist);
        coord.setHelioLat(HelioLat);
        coord.setSiderHelioLong(SiderHelioLong);
        coord.setTropicHelioLong(TropicHelioLong);
        coord.setX(x);
        coord.setY(y);
        coord.setZ(z);
        coord.setRadius(Radius);
        coord.setTheta(Theta);
        coord.setPhi(Phi);
        coord.setRetro(retro);
        allCoord.set(index, coord);// .setElementAt(coord, index);
    }
}
