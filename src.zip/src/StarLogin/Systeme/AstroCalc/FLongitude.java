package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public final class FLongitude
{
    private String longitude = "";
    private String shortLongitude = "";
    private int degree = 0;
    private int minute = 0;
    private int second = 0;
    private double decimalDegree = 0.0;
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    private String signe = "";
    
    /** Creates new FLongitude */
    public FLongitude()
    {
    }
    
    public FLongitude(String sData)
    {
        if (sData.startsWith("-"))
        {
            signe = "-";
            sData = sData.substring(1);
        }
        else if (sData.startsWith(" "))
        {
            signe = " ";
            sData = sData.substring(1);
        }
        else
            signe = " ";
        longitude = sData;
        decimalDegree = longitude2DecimalDegree(longitude);
        longitude = formatLongitude(degree, minute, second);
        shortLongitude = formatLongitude(degree, minute);
    }
    
    public FLongitude(double lng)
    {
        if (lng<0)
        {
            signe = "-";
            lng *= -1;
        }
        else
            signe = " ";
        decimalDegree = lng;
        degree = (int)lng;
        double aux = (lng - (double)degree)*60.0;
        minute = (int)Math.abs(aux);
        aux = (Math.abs(aux) - (double)minute)*60.0;
        second = (int)Math.abs(aux);
        longitude = formatLongitude(degree, minute, second);
        shortLongitude = formatLongitude(degree, minute);
    }
    
    public FLongitude(int d, int m, int s)
    {
        if (d<0)
        {
            signe = "-";
            d *= -1;
        }
        else
            signe = " ";
        longitude = formatLongitude(d, m, s);
        decimalDegree = longitude2DecimalDegree(longitude);
        shortLongitude = formatLongitude(d, m);
    }
    
    public int longitude2Degree(String sLong)
    {
        decimalDegree = longitude2DecimalDegree(sLong);
        return degree;
    }
    
    public int longitude2Minute(String sLong)
    {
        decimalDegree = longitude2DecimalDegree(sLong);
        return minute;
    }
    
    public int longitude2Second(String sLong)
    {
        decimalDegree = longitude2DecimalDegree(sLong);
        return second;
    }
    
    public double longitude2DecimalDegree(String sLong)
    {
        sLong = sLong.trim();
        longitude = sLong;
        if (sLong.length()<1) return 0.0;
        
        try
        {
            //get the degree
            int pos = sLong.indexOf(bundle.getString("dg"));
            if (pos>=0)
            {
                degree = new Integer(sLong.substring(0,pos)).intValue();
                sLong = sLong.substring(pos+1);
            }
            else
            {
                if (sLong.length()>1)
                {
                    degree = new Integer(sLong.substring(0,2)).intValue();
                }
                else if (sLong.length()>0)
                {
                    degree = new Integer(sLong).intValue();
                }
                else
                {
                    degree = 0;
                }
                sLong="";
            }
            
            //get the minutes
            pos = sLong.indexOf("'");
            if (pos>=0)
            {
                minute = new Integer(sLong.substring(0,pos)).intValue();
                sLong = sLong.substring(pos+1);
            }
            else
            {
                if (sLong.length()>1)
                {
                    minute = new Integer(sLong.substring(0,2)).intValue();
                }
                else if (sLong.length()>0)
                {
                    minute = new Integer(sLong).intValue();
                }
                else
                {
                    minute = 0;
                }
                sLong="";
            }
            
            //get the seconds
            pos = sLong.indexOf("\"");
            if (pos>=0)
            {
                second = new Integer(sLong.substring(0,pos)).intValue();
            }
            else
            {
                if (sLong.length()>1)
                {
                    second = new Integer(sLong.substring(0,2)).intValue();
                }
                else if (sLong.length()>0)
                {
                    second = new Integer(sLong).intValue();
                }
                else
                {
                    second = 0;
                }
            }
            
            if (second >= 60)
            {
                second -= 60;
                minute += 1;
            }
            if (minute >= 60)
            {
                minute -= 60;
                degree += 1;
            }
            if (degree >= 180)
            {
                degree = 180;
                minute = 0;
                second = 0;
            }
            else if (degree <= -180)
            {
                degree = -180;
                minute = 0;
                second = 0;
            }
            longitude = signe.concat(formatLongitude(degree, minute, second));
            decimalDegree = (double)degree + (double)minute/60.0 + (double)second/3600.0;
            if (signe.equals("-"))
                decimalDegree = -decimalDegree;
            return decimalDegree;
        }
        catch(java.lang.NumberFormatException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return 0.0;
        }
    }
    
    public String formatLongitude(int d, int m, int s)
    {
        if (s >= 60)
        {
            s -= 60;
            m += 1;
        }
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 180)
        {
            d = 180;
            m = 0;
            s = 0;
        }
        else if (d <= -180)
        {
            d = -180;
            m = 0;
            s = 0;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = "00"+sD;
        else if (d>=10 && d<100) sD = "0" +sD;
        //if (d>=0 && d<10) sD = " 00"+sD;
        //else if (d>=10 && d<100) sD = " 0" +sD;
        //else if (d>=100) sD = " " +sD;
        //else if (d>-10) sD = "-00"+sD.replace("-", "");
        //else if (d>-100) sD = "-0"+sD.replace("-", "");
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;
        String sS = String.valueOf(s);
        if (s<10) sS = "0"+sS;

        degree = d;
        minute = m;
        second = s;
        longitude = signe+sD+bundle.getString("dg")+sM+"'"+sS+"\"";
        return longitude;
    }
    
    public static String formatLongitude(int d, int m)
    {
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 180)
        {
            d = 180;
            m = 0;
        }
        else if (d <= -180)
        {
            d = -180;
            m = 0;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = " 00"+sD;
        else if (d>=10 && d<100) sD = " 0" +sD;
        else if (d>=100) sD = " " +sD;
        else if (d>-10) sD = "-00"+sD.replace("-", "");
        else if (d>-100) sD = "-0"+sD.replace("-", "");
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;

        return sD+bundle.getString("dg")+sM+"'";
    }
    
    public static String formatLongitude(int d)
    {
        if (d >= 180)
        {
            d = 180;
        }
        else if (d <= -180)
        {
            d = -180;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = " 00"+sD;
        else if (d>=10 && d<100) sD = " 0" +sD;
        else if (d>=100) sD = " " +sD;
        else if (d>-10) sD = "-00"+sD.replace("-", "");
        else if (d>-100) sD = "-0"+sD.replace("-", "");

        return sD+bundle.getString("dg");
    }
    
    public int getDegree()
    {
        return degree;
    }
    
    public double getDecimalDegree()
    {
        return decimalDegree;
    }
    
    public int getMinute()
    {
        return minute;
    }
    
    public int getSecond()
    {
        return second;
    }
    
    public String getLongitude()
    {
        return longitude;
    }
    
    public String getShortLongitude()
    {
        return shortLongitude;
    }
    
    public void setDegree(int data)
    {
        degree = data;
    }
    
    public void setMinute(int data)
    {
        minute = data;
    }
    
    public void setSecond(int data)
    {
        second = data;
    }
    
    public void setLongitude(String data)
    {
        longitude = data;
    }
    
    public void setDecimalDegree(double data)
    {
        decimalDegree = data;
    }
    
}
