package StarLogin.Systeme.AstroCalc;

import java.awt.Color;
import java.util.ArrayList;

import StarLogin.Systeme.Data.Stars;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.Systeme.Enum.ChartKind;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class StarsCalc
{
    private Stars stars;
    private ChartEvent chartEvent;
    private ArrayList nom_etoile = new ArrayList();               //nom de l'etoile consideree
    private ArrayList magnitude = new ArrayList();                //magnitude[star] apparente de l'etoile consideree
    private ArrayList azimut = new ArrayList();                   //azimut de l'etoile
    private ArrayList hauteur = new ArrayList();                  //hauteur de l'etoile sur l'horizon local
    private ArrayList long_star = new ArrayList();                //first coordinate of a star
    private ArrayList couleur = new ArrayList();                   //color of the star
    
    /** Creates a new instance of StarsCalc */
    public StarsCalc(Stars stars)
    {
        this.stars = stars;
        //this.chartEvent = chartEvent;
    }
    
    public ArrayList getNames()
    {
        return nom_etoile;
    }
    
    public ArrayList getMagnitudes()
    {
        return magnitude;
    }
    
    public ArrayList getAzimuts()
    {
        return azimut;
    }
    
    public ArrayList getAltitudes()
    {
        return hauteur;
    }
    
    public ArrayList getColors()
    {
        return couleur;
    }
    
    public ArrayList getLongitudes()
    {
        return long_star;
    }
    
    public Color getStarColorFromSC(String strSC)
    {
        strSC = strSC.substring(0, 1).toLowerCase();
        if (strSC.equals("o")) return new Color(210, 180, 255);
        else if (strSC.equals("b")) return new Color(200, 200, 255);
        else if (strSC.equals("a")) return new Color(180, 228, 255);
        else if (strSC.equals("f")) return new Color(180, 255, 255);
        else if (strSC.equals("g")) return new Color(255, 255, 180);
        else if (strSC.equals("k")) return new Color(255, 210, 180);
        else if (strSC.equals("m")) return new Color(255, 200, 200);
        else return new Color(195, 195, 195);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public void starsPosition(int chartKind, double limitMag, boolean bOtherSide, ChartElements chartElements)
    {
        double aux;
        //identite de l'etoile
        String identite;
        //Right ascension de l'etoile consideree
        double ad;
        //declinaison de l'etoile consideree
        double d;
        //Julian Day correspondant � l'annee de reference (2000.0)
        double jj_ref;
        //temps seculaire de reference
        double tps_ref;
        //date seculaire par rapport � l'annee de reference
        double date_seculaire;
        //auxiliary variables
        double rr;
        double rj;
        double u1;
        double u2;
        double u3;
        //date seculaire
        double jour_seculaire;
        //obliquity
        double Obliquity;
        //Julian Day
        double jour_julien;
        //Sun and mean lunar ascendant node longitudes
        double longitude_soleil;
        double noeud_asct;
        
        //numero d 'etoile
        int star;
        
        double ayanamsa = 0.0;
        Coord c = new Coord();
        ChartEvent chartEvent0 = (ChartEvent)chartElements.getChartEvents().get(0);
        Planet p = new Planet(chartEvent0, chartElements.getTrueLilith());
        double az = 0.0;
        double h = 0.0;
        double mag = 0.0;
        Color color = Color.BLACK;
        //=================================================
        
        //annee de reference convertie en Julian Day
        jj_ref = AstronomyMaths.gregorianToJulian(1, 1, 2000);
        
        //temps seculaire de reference
        tps_ref = (jj_ref - 2415020.0) / AstronomyMaths.DAY_PER_CENTURY;
        
        //temps seculaire par rapport � l'annee de reference
        jour_seculaire = chartEvent0.getCTimeH(); //  chartEvent.CTime + heure_TU / HEURES_PAR_SIECLE
        date_seculaire = jour_seculaire - tps_ref;
        
        longitude_soleil = p.getObjPosition(Planets.Sun).getTropicGeoLong();
        noeud_asct = p.getObjPosition(Planets.NorthNode).getTropicGeoLong();
        Obliquity = chartEvent0.getObliquity();
        jour_julien = chartEvent0.getJD();
        ayanamsa = AstronomyMaths.getAyanamsa(jour_seculaire);
        
        //lecture des coordonnees des etoiles dans la base de donnees
        star = 0;
        
        ArrayList vSC = stars.getRecords();
        if (vSC == null || vSC.size() == 0) return;
        for (int i = 0; i < vSC.size(); i++)
        {
            ArrayList v = (ArrayList)vSC.get(i);
            Double dblMag = new Double(String.valueOf(v.get(8)));
            mag = dblMag.doubleValue();
            
            //si la magnitude de l'etoile est inferieure ou egale � la magnitude limite
            if ( mag <= limitMag )
            {
                identite = String.valueOf(v.get(3));
                nom_etoile.add(v.get(2));
                if ( v.get(2) == null ) nom_etoile.set(star, identite);
                ad = new java.lang.Double(String.valueOf(v.get(4))).doubleValue();
                d = new java.lang.Double(String.valueOf(v.get(5))).doubleValue();
                String light = String.valueOf(v.get(12));
                if ( light == null || light.equals("") )
                {
                    color = Color.GRAY;
                }
                else
                {
                    color = getStarColorFromSC(light);
                }
                magnitude.add(dblMag); 
                couleur.add(new Integer(color.getRGB()));
                
                if ( chartKind == ChartKind.local )
                {
                    //EFFET DE LA PRECESSION
                    aux = date_seculaire * AstronomyMaths.PI_SUR_CENT80;
                    rr = 0.640457952975 * aux;
                    rj = 0.556617038814 * aux;
                    u1 = Math.cos(d) * Math.sin(ad + rr);
                    aux = Math.cos(d) * Math.cos(ad + rr);
                    u2 = Math.cos(rj) * aux - Math.sin(rj) * Math.sin(d);
                    u3 = Math.sin(rj) * aux + Math.cos(rj) * Math.sin(d);
                    
                    if ( Math.abs(u3) > 0.9 )
                    {
                        d = AstronomyMaths.acosD(Math.sqrt(u1 * u1 + u2 * u2)) * AstronomyMaths.sgn(u3);
                    }
                    else
                    {
                        d = AstronomyMaths.asinD(u3);
                    }
                    ad = (rr + Math.atan(u1 / u2)) * AstronomyMaths.CENT80_SUR_PI;
                    
                    if ( u2 < 0.0 ) ad = ad + 180.0;
                    if ( ad < 0.0 ) ad = ad + 360.0;
                    c.setDecl(d);
                    c.setRA(ad);
                    az = c.azFromEquatorial(chartEvent0.getPlaceLat(), chartEvent0.getLST());
                    h = c.altFromEquatorial(chartEvent0.getPlaceLat(), chartEvent0.getLST());
                    
                    if ( bOtherSide == true )
                    {
                        az = AstronomyMaths.mod(-az + 180.0, 360.0);
                        h = -h;
                    }
                    azimut.add(new Double(az));
                    hauteur.add(new Double(h));
                }
                else
                {
                    azimut.add(new Double(0.0));
                    hauteur.add(new Double(0.0));
                }
                Coord coord = Astronomy.starCoordinates(ad, d, Astronomy.CALCUL_SIMPLIFIE, 0.0, 0.0, 0.0, chartElements);
                long_star.add(new Double(coord.getCoord1(chartElements.getCoordSys())));
                star += 1;
            }
        }
    }
}
