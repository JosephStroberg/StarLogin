package StarLogin.Systeme.AstroCalc;

import java.util.ArrayList;

import StarLogin.Systeme.Data.ConstellationBoundaries;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ConstelsCalc
{
    private double rightAscension = 0.0;
    private double declination = 0.0;
    
    public ConstelsCalc()
    {
    }
    
    ////------------------------------------------
    ////      HERGET PRECESSION, SEE P. 9 OF PUBL. CINCINNATI OBS. NO. 24
    //// INPUT=  RA1 AND DEC1 MEAN PLACE, IN RADIANS, FOR EPOCH1, IN YEARS A.D.
    //// OUTPUT= RA2 AND DEC2 MEAN PLACE, IN RADIANS, FOR EPOCH2, IN YEARS A.D.
    ////------------------------------------------
    private void hgtPrc2(double ra1, double dec1, double epoch1, double epoch2)
    {
        double ra2 = 0.0;
        double dec2 = 0.0;
        final double cdr = 0.017453292519943;
        double ep1 = 0.0;
        double ep2 = 0.0;
        double x1[] = new double[3];
        double x2[] = new double[3];
        double r[][] = new double[3][3];
        double t;
        double st;
        double a;
        double b;
        double c;
        double csr = 0.0;
        double SinA;
        double SinB;
        double SinC;
        double CosA;
        double CosB;
        double CosC;
        int i;
        int j;
        
        //Compute input direction cosines
        a = Math.cos(dec1);
        x1[0] = a * Math.cos(ra1);
        x1[1] = a * Math.sin(ra1);
        x1[2] = Math.sin(dec1);
        
        //Set up rotation matrix (R)
        if ( !(ep1 == epoch1 && ep2 == epoch2) )
        {
            ep1 = epoch1;
            ep2 = epoch2;
            csr = cdr / 3600.0;
        }
        t = 0.001 * (ep2 - ep1);
        st = 0.001 * (ep1 - 1900.0);
        a = csr * t * (23042.53 + st * (139.75 + 0.06 * st) + t * (30.23 - 0.27 * st + 18.0 * t));
        b = csr * t * t * (79.27 + 0.66 * st + 0.32 * t) + a;
        c = csr * t * (20046.85 - st * (85.33 + 0.37 * st) + t * (-42.67 - 0.37 * st - 41.8 * t));
        SinA = Math.sin(a);
        SinB = Math.sin(b);
        SinC = Math.sin(c);
        CosA = Math.cos(a);
        CosB = Math.cos(b);
        CosC = Math.cos(c);
        r[0][0] = CosA * CosB * CosC - SinA * SinB;
        r[0][1] = -CosA * SinB - SinA * CosB * CosC;
        r[0][2] = -CosB * SinC;
        r[1][0] = SinA * CosB + CosA * SinB * CosC;
        r[1][1] = CosA * CosB - SinA * SinB * CosC;
        r[1][2] = -SinB * SinC;
        r[2][0] = CosA * SinC;
        r[2][1] = -SinA * SinC;
        r[2][2] = CosC;
        
        //Perform the rotation to get the direction cosines at epoch2 */
        for (i = 0; i < 3; i ++)
        {
            x2[i] = 0.0;
            for (j = 0; j < 3; j++)
            {
                x2[i] = x2[i] + r[i][j] * x1[j];
            }
        }
        ra2 = Math.atan(x2[1] / x2[0]) + AstronomyMaths.PI / 2.0 * (1 - AstronomyMaths.sgn(Math.sin(x2[0])));
        
        if ( (ra2 < 0) ) ra2 = 6.28318530717948 + ra2;
        dec2 = Math.asin(x2[2]);
        rightAscension = ra2;
        declination = dec2;
    }
    
    //-------------------------------------------------------
    // PROGRAM TO FIND CONSTELLATION NAME FROM A POSITION
    // THE FIRST RECORD IN THE DATA SET MUST BE THE EQUINOX FOR THE POSITIONS IN THE FORMAT XXXX.X
    // THE REMAINING RECORDS MUST BE THE POSITION IN HOURS AND DECIMALS OF
    // AN HOUR FOLLOWED BY THE DECLINATION IN DEGREES AND FRACTIONS OF A DEGREE IN THE FORMAT: F7.4,F8.4
    // THE OUTPUT WILL REPEAT THE POSITION ENTERED AND GIVE THE THREE LETTER ABBREVIATION OF THE CONSTELLATION IN WHICH IT IS LOCATED
    //-------------------------------------------------------
    public String findConstell(double starRA, double starD, double annee, ConstellationBoundaries constellationBoundaries)
    {
        //Dim Con As New VB6.FixedLengthString(1)
        //Const CONVH = 0.26179938779915
        //Const CONVD = 0.01745329251994
        final double PI2 = 6.28318530717948;

        //PRECESS POSITION TO 1875.0 EQUINOX
        hgtPrc2(starRA, starD, annee, 1875.0);
        double ra2 = rightAscension;
        double dec2 = declination;
        //ec = HgtPrc(starRA, starD, annee, 1875)
        if ( (ra2 < 0.0) ) ra2 = ra2 + PI2;
        if ( (ra2 >= PI2) ) ra2 = ra2 - PI2;

        //FIND CONSTELLATION SUCH THAT THE DECLINATION ENTERED IS HIGHER THAN
        //THE LOWER BOUNDARY OF THE CONSTELLATION WHEN THE UPPER AND LOWER
        //Right ASCENSIONS FOR THE CONSTELLATION BOUND THE ENTERED Right ASCENSION
        ArrayList vSC = constellationBoundaries.getRecords();
        if ((vSC == null) || (vSC.size() == 0)) return "";
        for (int i = 0; i < vSC.size(); i++)
        {
            ArrayList v = (ArrayList)vSC.get(i);
            double raLaw = new java.lang.Double(String.valueOf(v.get(1))).doubleValue();
            double raUp = new java.lang.Double(String.valueOf(v.get(2))).doubleValue();
            double decl = new java.lang.Double(String.valueOf(v.get(3))).doubleValue();
            String constel = String.valueOf(v.get(4));
            if ((decl <= dec2) && (raLaw <= ra2) && (raUp > ra2))
            {
                return constel;
            }
        }
        return "";
    }
}
