package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Vertex
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Vertex */
    public Vertex(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        if (mPlaceLat == 0.0)
        {
            mCoord.setTropicHelioLong(AstronomyMaths.atnD(1.0 / AstronomyMaths.tanD(15.0 * mTSL) / AstronomyMaths.cosD(mObliquity)) - 90.0 * (1.0 + AstronomyMaths.sgn(AstronomyMaths.cosD(15.0 * mTSL))));
            mCoord.setRA(15 * mTSL);
        }
        else
        {
            double x = AstronomyMaths.sinD(mObliquity) / AstronomyMaths.tanD(mPlaceLat) - AstronomyMaths.cosD(mObliquity) * AstronomyMaths.sinD(15.0 * mTSL);
            mCoord.setTropicHelioLong(AstronomyMaths.modulo(AstronomyMaths.atnD(AstronomyMaths.cosD(mTSL * 15.0) / x) + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0));
            mCoord.setRA(AstronomyMaths.modulo(AstronomyMaths.atnD(AstronomyMaths.cosD(mTSL * 15.0) / (AstronomyMaths.tanD(mObliquity) / AstronomyMaths.tanD(mPlaceLat) - AstronomyMaths.sinD(15.0 * mTSL))) + 90.0 * (1.0 + AstronomyMaths.sgn(x)), 360.0));
        }
        mCoord.setHelioLat(0.0);
        mCoord.setHelioDist(0.0);
        mCoord.setTropicGeoLong(mCoord.getTropicHelioLong());
        mCoord.setGeoLat(0.0);
        mCoord.setGeoDist(0.0);
        mCoord.setDecl(AstronomyMaths.atnD(AstronomyMaths.tanD(mObliquity) * AstronomyMaths.sinD(mCoord.getRA())));
        mCoord.setAz(-90.0);
        mCoord.setAlt(AstronomyMaths.asinD(AstronomyMaths.sinD(mPlaceLat) * AstronomyMaths.sinD(mCoord.getDecl())));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
