package StarLogin.Systeme.AstroCalc;

import java.util.ArrayList;
import java.lang.Math;

import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Data.Stars;
import StarLogin.Systeme.Enum.CoordSystem;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Astronomy extends java.lang.Object
{
    public static final byte CALCUL_SIMPLIFIE = 0;
    public static final byte CALCUL_COMPLET = 1;
    public static final String ALL_S = "toutes";
    
    //valeur d'un unite astronomique en metres
    public static final double UNITE_ASTRO = 149597900000.0;
    
    //Earth radius in AU
    public static final double EARTH_RADIUS = 4.26352327075E-05;
    
    //valeur d'un parsec en metres
    public static final double PARSEC = 3.085678E+16;
    
    //valeur d'une annee-lumiere en metres
    public static final double ANNEE_LUM = 9.48621E+15;
    
    public static String getStarName(String identity, ArrayList stars)
    {
        String identite = "";
        
        if (stars == null || stars.size() == 0) return identity;
        for (int i = 0; i < stars.size(); i++)
        {
            ArrayList v = (ArrayList)stars.get(i);
            identite = v.get(3).toString();
            if (identite.equals(identity))
            {
                if (v.get(2) != null)
                {
                    return String.valueOf(v.get(2));
                }
                break;
            }
        }
        return identity;
    }
    
    //Calculation of stars positions
    public static void starPosition(ChartElements chartElements, ArrayList stars)
    {
        //identity of the star
        String identite;
        //visual magnitude of the star
        double magnitude;
        //Right ascension of the star
        double ad;
        //declination of the star
        double d;
        //distance of the star au Soleil
        double dist;
        //coordinates of the star in the considered system
        double coord1;
        double coord2;
        //=====================================================================
        
        String starName = chartElements.getOtherPointName().trim();
        
        if (stars == null || stars.size() == 0) return;
        for (int i = 0; i < stars.size(); i++)
        {
            ArrayList v = (ArrayList)stars.get(i);
            
            identite = v.get(3).toString();
            magnitude = new java.lang.Double(String.valueOf(v.get(8))).doubleValue();
            
            //si la magnitude of the star est inferieure ou egale � la magnitude limite
            //ou si nom est egal au nom of the star cherchee
            //----------------------------------------------------------------------------
            if ( identite.equals(starName) )
            {
                //get other needed information
                ad = new java.lang.Double(String.valueOf(v.get(4))).doubleValue();
                d = new java.lang.Double(String.valueOf(v.get(5))).doubleValue();
                dist = new java.lang.Double(null2Zero(String.valueOf(v.get(10)))).doubleValue();
                
                //Coordinates of the star
                Coord coord = starCoordinates(ad, d, Astronomy.CALCUL_COMPLET, 0.0, 0.0, dist, chartElements);
                coord1 = coord.getCoord1(chartElements.getCoordSys());
                coord2 = coord.getCoord2(chartElements.getCoordSys());
                
                AllCoord allCoord = (AllCoord)chartElements.getChartCoords().get(0);
                allCoord.set(coord, Planets.OtherPoint);
                return;
            }
        }
        return;
    }
    
    //=========================================================================
    //Calculation of coordonnees of the star dans le systeme courant, en fonction
    //de son Ascension Droite et de sa Declinaison
    //input:  ad              : ascension droite of the star in degrees
    //        d               : declinaison             "
    //        nature_calcul   : calcul simplifie (seulement la precession)
    //                          ou complet (precession+nutation+mouvement propre)
    //        mvt_ad          : mouvement propre en ascension droite of the star consideree
    //        mvt_d           : mouvement propre en declinaison of the star consideree
    //        dist            : distance of the star au Soleil
    //output: coord1          : premiere coordonnee of the star dans le systeme considere
    //        coord2          : seconde      "              "              "        "
    //=========================================================================
    public static Coord starCoordinates(double ad, double d, byte nature_calcul, double mvt_ad, double mvt_d, double dist, ChartElements chartElements)
    {
        //auxiliary variables
        double rr;
        double rj;
        double u1;
        double u2;
        double u3;
        double ca1;
        double ca2;
        double cd1;
        double cd2;
        double v1;
        double v2;
        double x;
        double aux;
        //Julian Day correspondant � l'annee de reference (2000.0)
        double jj_ref;
        //temps seculaire de reference
        double tps_ref;
        //date seculaire par rapport � l'annee de reference
        double date_seculaire;
        //longitude (geocentrique) of the star
        double lng;
        //longitude heliocentrique of the star
        double l_helio;
        //latitude (geocentrique) of the star
        double lat;
        //heliocentric latitude of the star
        double lat_helio;
        //azimut of the star
        double Az;
        //hauteur of the star sur l//horizon local
        double ha;
        //distance to the Sun
        double helioDist;
        
        Coord coord = new Coord();
        ChartEvent chartEvent = (ChartEvent)chartElements.getChartEvents().get(0);
        Planet planet = new Planet(chartEvent, chartElements.getTrueLilith());
        Coord sunCoord = planet.getObjPosition(Planets.Sun);
        double longitude_soleil = sunCoord.getTropicGeoLong();
        double earthSunDist = sunCoord.getHelioDist();
        
        //=====================================================================
        //calculs prealables
        //=====================================================================
        //annee de reference convertie en Julian Day
        jj_ref = AstronomyMaths.gregorianToJulian(1, 1, 2000);
        //temps seculaire de reference
        tps_ref = (jj_ref - 2415020) / AstronomyMaths.DAY_PER_CENTURY;
        //temps seculaire par rapport � l//annee de reference
        date_seculaire = chartEvent.getCTimeH() - tps_ref;
        
        //EFFET DE LA PRECESSION
        aux = date_seculaire * AstronomyMaths.PI_SUR_CENT80;
        rr = 0.640457952975 * aux;
        rj = 0.556617038814 * aux;
        u1 = Math.cos(d) * Math.sin(ad + rr);
        aux = Math.cos(d) * Math.cos(ad + rr);
        u2 = Math.cos(rj) * aux - Math.sin(rj) * Math.sin(d);
        u3 = Math.sin(rj) * aux + Math.cos(rj) * Math.sin(d);
        
        if ( Math.abs(u3) > 0.9 )
        {
            d = Math.acos(Math.sqrt(u1 * u1 + u2 * u2)) * AstronomyMaths.sgn(u3);
        }
        else
        {
            d = Math.asin(u3);
        }
        ad = (rr + Math.atan(u1 / u2));
        
        if ( u2 < 0.0 ) ad = ad + AstronomyMaths.PI;
        if ( ad < 0.0 ) ad = ad + 2 * AstronomyMaths.PI;
        
        //en cas de calcul complet
        if ( nature_calcul == CALCUL_COMPLET )
        {
            //EFFET NUTATION
            v1 = -0.000478611126838 * AstronomyMaths.sinD(chartEvent.getMeanNN());
            v2 = 0.000255833103977 * AstronomyMaths.cosD(chartEvent.getMeanNN());
            u1 = Math.sin(ad);
            u2 = Math.cos(ad);
            u3 = Math.tan(d);
            ca1 = v1 * (0.9174 + 0.3979 * u1 * u3) - v2 * u2 * u3;
            cd1 = v1 * 0.3979 * u2 + v2 * u1;
            
            //EFFET ABERRATION ANNUELLE
            ca2 = -0.000569166647992 * (0.9174 * u2 * AstronomyMaths.cosD(longitude_soleil) + u1 * AstronomyMaths.sinD(longitude_soleil) / Math.cos(d));
            cd2 = -0.000569166647992 * (0.3979 * Math.cos(d) * AstronomyMaths.cosD(longitude_soleil) + u2 * Math.sin(d) * AstronomyMaths.sinD(longitude_soleil) - 0.9174 * u1 * Math.sin(d) * AstronomyMaths.cosD(longitude_soleil));
            
            //EFFET MOUVEMENT PROPRE (� verifier)
            //(mvt_ad et mvt_d sont exprimes en degres par an)
            aux = mvt_ad * date_seculaire * 100.0 * AstronomyMaths.PI_SUR_CENT80;
            ad = ad + aux;
            d = d + aux;
            
            ad = ad + ca1 + ca2;
            d = d + cd1 + cd2;
        }
        
        d = d * AstronomyMaths.CENT80_SUR_PI;
        ad = ad * AstronomyMaths.CENT80_SUR_PI;
        
        //calcul de la longitude of the star
        if ( u2 == 0.0 )
        {
            lng = ad;
        }
        else
        {
            x = AstronomyMaths.sinD(chartEvent.getObliquity()) * u3 + AstronomyMaths.cosD(chartEvent.getObliquity()) * u1;
            lng = AstronomyMaths.modulo(AstronomyMaths.atnD(x / u2) + 90.0 * (1 - AstronomyMaths.sgn(u2)), 360.0);
        }
        
        if ( dist == 0.0 )
        {
            l_helio = lng;
        }
        else
        {
            //R=1 divise par dist car distances exprimees ici en annees lumiere
            l_helio = lng + 2.0 * AstronomyMaths.atnD(1.0 / 2.0 / dist * AstronomyMaths.sinD(lng - longitude_soleil));
        }
        //calcul de la latitude of the star et des autres coordonnees
        //pour les divers systemes de coordonnees possibles)
        lat = AstronomyMaths.asinD(AstronomyMaths.cosD(chartEvent.getObliquity()) * AstronomyMaths.sinD(d) - AstronomyMaths.sinD(chartEvent.getObliquity()) * AstronomyMaths.cosD(d) * u1);
        lat_helio = lat;
        
        coord.setTropicHelioLong(l_helio);
        coord.setHelioLat(lat_helio);
        //helioDist = dist / UNITE_ASTRO * ANNEE_LUM;
        coord.setHelioDist(dist);
        coord.setTropicGeoLong(lng);
        coord.setGeoLat(lat);
        coord.setGeoDist(dist);
        coord.setRA(ad);
        coord.setDecl(d);
        coord.setAz(coord.azFromEquatorial(chartEvent.getPlaceLat(), chartEvent.getLST()));
        coord.setAlt(coord.altFromEquatorial(chartEvent.getPlaceLat(), chartEvent.getLST()));
        coord.setSiderGeoLong(coord.getTropicGeoLong() - chartEvent.getAyanamsa());
        coord.setSiderHelioLong(coord.getSiderHelioLong() - chartEvent.getAyanamsa());
        return coord;
    }
    
    public static String firstPartOfStarName(String strS)
    {
        //position of a character in a string
        int lngPos;
        int p;
        strS = strS.trim();
        
        lngPos = strS.indexOf(".");
        p = strS.indexOf(",");
        
        if ( p > 0 ) lngPos = Math.min(lngPos, p);
        p = strS.indexOf(" ");
        
        if ( p > 0 ) lngPos = Math.min(lngPos, p);
        
        if ( lngPos > 0 )
        {
            return strS.substring(0, lngPos);
        }
        else
        {
            return strS;
        }
    }
    
    private static String null2Zero(String value)
    {
        if (value.equals("null") || value == null)
        {
            return "0";
        }
        else
        {
            return value;
        }
    }
    
}
