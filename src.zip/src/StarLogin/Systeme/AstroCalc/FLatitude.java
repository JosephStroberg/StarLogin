package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public final class FLatitude
{
    
    private String latitude = "";
    private int degree = 0;
    private int minute = 0;
    private int second = 0;
    private double decimalDegree = 0.0;
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    private String signe = "";
    
    /** Creates new FLatitude */
    public FLatitude()
    {
    }
    
    public FLatitude(String sData)
    {
        if (sData.startsWith("-"))
        {
            signe = "-";
            sData = sData.substring(1);
        }
        else if (sData.startsWith(" "))
        {
            signe = " ";
            sData = sData.substring(1);
        }
        else
            signe = " ";
        latitude = sData;
        decimalDegree = latitude2DecimalDegree(latitude);
        latitude = formatLatitude(degree, minute, second);
    }
    
    public FLatitude(double lat)
    {
        if (lat<0)
        {
            signe = "-";
            lat *= -1;
        }
        else
            signe = " ";
        decimalDegree = lat;
        degree = (int)lat;
        double aux = (lat - (double)degree)*60.0;
        minute = (int)Math.abs(aux);
        aux = (aux - (double)minute)*60.0;
        second = (int)Math.abs(aux);
        latitude = formatLatitude(degree, minute, second);
    }
    
    public FLatitude(int d, int m, int s)
    {
        if (d<0)
        {
            signe = "-";
            d *= -1;
        }
        else
            signe = " ";
        latitude = formatLatitude(d, m, s);
        decimalDegree = latitude2DecimalDegree(latitude);
    }
    
    public int latitude2Degree(String sLat)
    {
        decimalDegree = latitude2DecimalDegree(sLat);
        return degree;
    }
    
    public int latitude2Minute(String sLat)
    {
        decimalDegree = latitude2DecimalDegree(sLat);
        return minute;
    }
    
    public int latitude2Second(String sLat)
    {
        decimalDegree = latitude2DecimalDegree(sLat);
        return second;
    }
    
    public double latitude2DecimalDegree(String sLat)
    {
        sLat = sLat.trim();
        latitude = sLat;
        if (sLat.length()<1) return 0.0;
        
        try
        {
            //get the degree
            int pos = sLat.indexOf(bundle.getString("dg"));
            if (pos>=0)
            {
                degree = new Integer(sLat.substring(0,pos)).intValue();
                sLat = sLat.substring(pos+1);
            }
            else
            {
                if (sLat.length()>1)
                {
                    degree = new Integer(sLat.substring(0,2)).intValue();
                }
                else if (sLat.length()>0)
                {
                    degree = new Integer(sLat).intValue();
                }
                else
                {
                    degree = 0;
                }
                sLat="";
            }
            
            //get the minutes
            pos = sLat.indexOf("'");
            if (pos>=0)
            {
                minute = new Integer(sLat.substring(0,pos)).intValue();
                sLat = sLat.substring(pos+1);
            }
            else
            {
                if (sLat.length()>1)
                {
                    minute = new Integer(sLat.substring(0,2)).intValue();
                }
                else if (sLat.length()>0)
                {
                    minute = new Integer(sLat).intValue();
                }
                else
                {
                    minute = 0;
                }
                sLat="";
            }
            
            //get the seconds
            pos = sLat.indexOf("\"");
            if (pos>=0)
            {
                second = new Integer(sLat.substring(0,pos)).intValue();
            }
            else
            {
                if (sLat.length()>1)
                {
                    second = new Integer(sLat.substring(0,2)).intValue();
                }
                else if (sLat.length()>0)
                {
                    second = new Integer(sLat).intValue();
                }
                else
                {
                    second = 0;
                }
            }
            
            if (second >= 60)
            {
                second -= 60;
                minute += 1;
            }
            if (minute >= 60)
            {
                minute -= 60;
                degree += 1;
            }
            if (degree >= 90)
            {
                degree = 90;
                minute = 0;
                second = 0;
            }
            else if (degree <= -90)
            {
                degree = -90;
                minute = 0;
                second = 0;
            }
            latitude = signe.concat(formatLatitude(degree, minute, second));
            decimalDegree = (double)degree + (double)minute/60.0 + (double)second/3600.0;
            if (signe.equals("-"))
                decimalDegree = -decimalDegree;
            return decimalDegree;
        }
        catch(java.lang.NumberFormatException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return 0.0;
        }
    }
    
    public String formatLatitude(int d, int m, int s)
    {
        if (s >= 60)
        {
            s -= 60;
            m += 1;
        }
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 90)
        {
            d = 90;
            m = 0;
            s = 0;
        }
        else if (d <= -90)
        {
            d = -90;
            m = 0;
            s = 0;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = "0"+sD;
        //if (d>=0 && d<10) sD = " 0"+sD;
        //else if (d>=10) sD = " " +sD;
        //else if (d>-10) sD = "-0"+sD.replace("-", "");
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;
        String sS = String.valueOf(s);
        if (s<10) sS = "0"+sS;

        degree = d;
        minute = m;
        second = s;
        latitude = signe+sD+bundle.getString("dg")+sM+"'"+sS+"\"";
        return latitude;
    }
    
    public static String formatLatitude(int d, int m, String signe)
    {
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 90)
        {
            d = 90;
            m = 0;
        }
        else if (d <= -90)
        {
            d = -90;
            m = 0;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = " 0"+sD;
        else if (d>=10) sD = " " +sD;
        else if (d>-10) sD = "-0"+sD.replace("-", "");
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;

        return signe+sD+bundle.getString("dg")+sM+"'00\"";
    }
    
    public static String formatLatitude(int d)
    {
        if (d >= 90)
        {
            d = 90;
        }
        else if (d <= -90)
        {
            d = -90;
        }
        String sD = new Integer(d).toString();
        if (d>=0 && d<10) sD = " 0"+sD;
        else if (d>=10) sD = " " +sD;
        else if (d>-10) sD = "-0"+sD.replace("-", "");

        return sD+bundle.getString("dg")+"00'00\"";
    }
    
    public int getDegree()
    {
        return degree;
    }
    
    public double getDecimalDegree()
    {
        return decimalDegree;
    }
    
    public int getMinute()
    {
        return minute;
    }
    
    public int getSecond()
    {
        return second;
    }
    
    public String getLatitude()
    {
        return latitude;
    }
    
    public void setDegree(int data)
    {
        degree = data;
    }
    
    public void setMinute(int data)
    {
        minute = data;
    }
    
    public void setSecond(int data)
    {
        second = data;
    }
    
    public void setLatitude(String data)
    {
        latitude = data;
    }
    
    public void setDecimalDegree(double data)
    {
        decimalDegree = data;
    }
    
}
