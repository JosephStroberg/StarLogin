package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import StarLogin.IHM.DialogDoc;
import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Enum.Planets;
import java.awt.Color;
import javax.swing.JDialog;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.html.HTMLDocument;

public class ProgressedMoon
{
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    public ProgressedMoon(ChartEvent ev, int sysCoord)
    {
        process(ev, sysCoord);
    }
    
    private void process(ChartEvent ev, int sysCoord)
    {
        double noeud_ascendant_moyen_lunaire;
        double jour_seculaire;
        //age maximal considere
        final int AGE_MAX_ = 120;
        //aucune lunaison
        final int AUCUNE_LUNAISON = -1;
        //indices
        int i;
        int j;
        int k;
        int m;
        //ecarts Lune-Soleil
        double delta[] = new double[AGE_MAX_ + 4];
        //difference entre deux ecarts successifs, en valeur absolue
        double ecart;
        //angle correspondant � une phase lunaire, resultat du polynome de Lagrange:
        //6 * p = -t * (t - 1) * (t - 2) * delta[i - 1]
        //        + 3 * (t + 1) * (t - 1) * (t - 2) * delta[i]
        //        - 3 * t * (t + 1) * (t - 2) * delta[i + 1]
        //        + t * (t - 1) * (t + 1) * delta[i + 2], pour trouver la date t
        int p;
        //date cherchee en nombre de journees depuis celle of the event
        double t;
        //sauvegarde de la date lors d'une iteration
        double old_t;
        //difference entre le resultat reel cherche et le resultat trouve � l'iteration consideree
        double dif;
        //auxiliary variables
        double aux = 0.0;
        double a = 0.0;
        double b = 0.0;
        double c;
        double aux2;
        //discriminant d'une equation du second degre
        double discriminant;
        //mauvais resultat dans la determination du temps
        final int BAD_RESULT = -1;
        //auxiliary string
        String strS;
        //heure
        double heure_;
        //jours juliens
        double jj;
        //ayanamsa
        double Ayanamsa;
        
        String sDocument = ev.getEvent().getLocalDate() + " - " + ev.getEvent().getLocalTime() + "\r\n\r\n" + bundle.getString("ProgressedMoon") + "\r\n";
        
        //calcul des ephemerides lunaires et solaires jusqu'� 120 ans
        //dans le coordinates system considere, mais debut � -1 et FIN � +122
        //pour pouvoir interpoler suivant des polyn�mes de Lagrange
        ev.addTime2CTimeH(-24.0);
        Planet pl = new Planet(ev, false);
        for (i = 0; i < AGE_MAX_ + 3; i++)
        {
            //calcul des ecarts Lune-Soleil
            delta[i] = AstronomyMaths.modulo(pl.getObjPosition(Planets.Moon).getCoord1(sysCoord) - pl.getObjPosition(Planets.Sun).getCoord1(sysCoord), 360.0);
            ev.addTime2CTimeH(24.0);
            pl = new Planet(ev, false);
        }
        delta[AGE_MAX_ + 3] = AstronomyMaths.modulo(pl.getObjPosition(Planets.Moon).getCoord1(sysCoord) - pl.getObjPosition(Planets.Sun).getCoord1(sysCoord), 360.0);
        
        String sDocumentDetail = "";
        
        //recherche des phases lunaires
        for (i = 1; i<=AGE_MAX_ + 1; i++)
        {
            ecart = AstronomyMaths.modulo(Math.abs(delta[i + 1] - delta[i] - 360.0 * (double)(int)((delta[i + 1] - delta[i]) / 180.0)), 360.0);
            //cas de la nouvelle lune
            if ( (delta[i + 1] < ecart) && (delta[i] >= 360.0 - ecart) )
            {
                p = 360;
            }
            else if ( (delta[i + 1] < ecart + 90.0) && (delta[i] >= 90.0 - ecart) )
            {
                p = 90;
            }
            else if ( (delta[i + 1] < ecart + 180.0) && (delta[i] >= 180.0 - ecart) )
            {
                p = 180;
            }
            else if ( (delta[i + 1] < ecart + 270.0) && (delta[i] >= 270.0 - ecart) )
            {
                p = 270;
            }
            else
            {
                p = AUCUNE_LUNAISON;
            }
            
            if ( p != AUCUNE_LUNAISON )
            {
                if ( delta[i] == (double)p )
                {
                    t = 0.0;
                }
                else
                {
                    aux = 6.0 * ((double)p - delta[i]);
                    t = 360.0 * (int)((double)p / 360.0);
                    a = -1.0 * delta[i - 1] + 3.0 * (delta[i] - delta[i + 1] - t) + delta[i + 2] + t;
                    b = 3.0 * (delta[i - 1] - 2.0 * delta[i] + delta[i + 1] + t);
                    c = -2.0 * delta[i - 1] - 3.0 * delta[i] + 6.0 * (delta[i + 1] + t) - delta[i + 2] - t;
                    dif = 999.0;
                    old_t = 999.0;
                    t = (p - delta[i]) / ecart;
                    m = 0;
                    
                    while (dif > 0.0000001 && m < 20)
                    {
                        m += 1;
                        //cas d'une equation du second degre
                        if ( c == 0.0 )
                        {
                            if ( b == 0.0 )
                            {
                                if ( a <= 0.0 )
                                {
                                    t = BAD_RESULT;
                                }
                                else
                                {
                                    t = Math.pow(aux / a, 1.0 / 3.0);
                                }
                            }
                            else
                            {
                                t = (aux - a * t*t*t) / 3 / b;
                                if ( t < 0 )
                                {
                                    t = BAD_RESULT;
                                }
                                else
                                {
                                    t = Math.sqrt(t);
                                }
                            }
                        }
                        else
                        {
                            t = (aux - a * t*t*t + 3 * b * t*t) / c;
                        }
                        dif = Math.abs(t - old_t);
                        old_t = t;
                        
                        if ( t == BAD_RESULT || Math.abs(t) > 1.0E+20 )
                        {
                            break;
                        }
                    }
                }
                
                if ( t < 0 || t > 1 )
                {
                    //recherche des autres racines
                    if ( t != BAD_RESULT )
                    {
                        discriminant = (a * t + 3 * b) * (a * t + 3 * b) - 4 * a * aux / t;
                        if ( discriminant < 0.0 )
                        {
                            t = BAD_RESULT;
                        }
                        else
                        {
                            //premiere racine
                            aux = (-(a * t + 3 * b) - Math.sqrt(discriminant)) / 2.0 / a;
                            if ( aux < 0.0 || aux > 1.0 )
                            {
                                //seconde racine
                                aux = (-(a * t + 3 * b) + Math.sqrt(discriminant)) / 2.0 / a;
                                if ( aux < 0.0 || aux > 1.0 )
                                {
                                    //on prend l'extrapolation linaire au lieu de Lagrange
                                    t = (p - delta[i]) / ecart;
                                }
                                else
                                {
                                    t = aux;
                                }
                            }
                            else
                            {
                                t = aux;
                            }
                        }
                    }
                }
                
                //resultat final
                //--------------
                switch(p)
                {
                    case 360 : strS = bundle.getString("NewMoon"); break;
                    case 90 : strS = bundle.getString("FirstQuarter"); break;
                    case 180 : strS = bundle.getString("FullMoon"); break;
                    case 270 : strS = bundle.getString("LastQuarter"); break;
                    default: strS ="";
                }
                
                strS = strS + "\t:  ";
                
                //affichage des resultats
                if ( t == BAD_RESULT )
                {
                    strS = strS + "?";
                }
                else
                {
                    t += i - 1;
                    //un jour = un an, � convertir en temps seculaire, donne le Julian Day:
                    jj = (ev.getCTime() + ev.getTime() / AstronomyMaths.HOUR_PER_CENTURY + t / 100.0) * AstronomyMaths.DAY_PER_CENTURY + 2415020.0;
                    //ne mettre la ligne suivante que si une grande precision est garantie
                    //heure_ = CInt(Frac(jj - 0.5) * 24)
                    jj = (int)(jj - 0.5) + 0.5;
                    double date = AstronomyMaths.julianToGregorian(jj);
                    strS = strS + new FDate(date).getFormatedDate();
                }
                sDocumentDetail = sDocumentDetail + strS + "\r\n";
            }
        }
        
        
        //DialogDoc DialogDoc = new DialogDoc();
        //windowNB += 1;
        //DialogDoc.setTitle(bundle.getString("ProgressedMoon") + " - " + windowNB);
        //DefaultStyledDocument doc = DialogDoc.getDocument();
        String title = bundle.getString("ProgressedMoon");
        HTMLDocument doc = new HTMLDocument();//(HTMLDocument) docForm.getDocument();

        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        Style sicon = styles.addStyle(null, null);
        
        try
        {
            //Header
            StyleConstants.setLineSpacing(s, 0.0f);
            StyleConstants.setFontFamily(s, "arial");
            StyleConstants.setAlignment(s, StyleConstants.ALIGN_CENTER);
            doc.insertString(doc.getLength(), " \n", s);
            StyleConstants.setFontSize(s, 16);
            StyleConstants.setBold(s, true);
            StyleConstants.setForeground(s, new Color(195, 0, 255));
            StyleConstants.setBackground(s, new Color(255, 225, 195));
            doc.insertString(doc.getLength(), bundle.getString("ProgressedMoon"), s);
            StyleConstants.setAlignment(s, StyleConstants.ALIGN_LEFT);
            StyleConstants.setFontSize(s, 12);
            
            StyleConstants.setBackground(s, Color.WHITE);
            StyleConstants.setForeground(s, Color.BLACK);
            doc.insertString(doc.getLength(), "\n\n", s);
            doc.insertString(doc.getLength(), sDocument, s);
            
            //detail
            StyleConstants.setBold(s, false);
            doc.insertString(doc.getLength(), sDocumentDetail, s);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        //DialogDoc.resetUndo();
        //DialogDoc.getTextPane().setSelectionStart(0);
        //DialogDoc.getTextPane().setSelectionEnd(0);
        //DialogDoc.setVisible(true);
        //DialogDoc.setExtendedState(DialogDoc.MAXIMIZED_BOTH);
        DialogDoc docForm = new DialogDoc(new JDialog(), true, doc, title);
    }
}