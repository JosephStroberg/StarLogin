/*
 * Saturn.java
 *
 * Created on 7 ao�t 2003, 07:08
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Saturn
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Saturn */
    public Saturn(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Saturn;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mHelioLat;
        double mHelioDist;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + 2507.0 + 5014.0 * mCTime + (23043.0 - 142.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) - (114.0 + 229.0 * mCTime) * AstronomyMaths.cosD(m[mNumber]) + (60.0 * mCTime - 2689.0) * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]) + (1177.0 + 101.0 * mCTime) * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]) + (22.0 * mCTime - 12.0) * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) + (802.0 - 11.0 * mCTime) * AstronomyMaths.sinD(2.0 * m[mNumber]);
        mTropicHelioLong = mTropicHelioLong - (7.0 + 17.0 * mCTime) * AstronomyMaths.cosD(2.0 * m[mNumber]) - (70.0 + 3.0 * mCTime) * AstronomyMaths.cosD(2.0 * l[mNumber]) + (67.0 - 3.0 * mCTime) * AstronomyMaths.sinD(2.0 * l[mNumber]) + (425.0 + 2.0 * mCTime) * AstronomyMaths.sinD(m[Planets.Jupiter] - 2.0 * m[mNumber]) + (3.0 * mCTime - 153.0) * AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) + (28.0 + 4.0 * mCTime) * AstronomyMaths.cosD(m[Planets.Jupiter] - 3.0 * m[mNumber]) + (19.0 - 6.0 * mCTime) * AstronomyMaths.sinD(4.0 * m[Planets.Jupiter] - 10.0 * m[mNumber]);
        mTropicHelioLong = mTropicHelioLong + (20.0 + 6.0 * mCTime) * AstronomyMaths.cosD(4.0 * m[Planets.Jupiter] - 10.0 * m[mNumber]) + (3.0 * mCTime - 826.0) * AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) + (66.0 + 6.0 * mCTime) * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) + 41.0 * AstronomyMaths.sinD(m[Planets.Jupiter] - 3.0 * m[mNumber]) + 39.0 * AstronomyMaths.sinD(3.0 * m[mNumber]) + 31.0 * (AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) + AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - m[mNumber]))) - 29.0 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 3.0 * m[mNumber]) - 28.0 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 6.0 * m[mNumber] + 3.0 * m[Planets.Uranus]);
        mTropicHelioLong = mTropicHelioLong - 22.0 * AstronomyMaths.sinD(m[mNumber] - 3.0 * m[Planets.Uranus]) + 20.0 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 3.0 * m[mNumber]) + 19.0 * AstronomyMaths.cosD(2.0 * m[mNumber] - 3.0 * m[Planets.Uranus]) - 16.0 * AstronomyMaths.cosD(m[mNumber] - 3.0 * m[Planets.Uranus]) + 12.0 * (AstronomyMaths.cosD(m[Planets.Jupiter]) - AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Uranus]))) - 11.0 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]) + 10.0 * (AstronomyMaths.sinD(2.0 * m[mNumber] - 3.0 * m[Planets.Uranus]) + AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - m[mNumber])));
        mTropicHelioLong = mTropicHelioLong + 9.0 * AstronomyMaths.sinD(4.0 * m[Planets.Jupiter] - 9.0 * m[mNumber]) + 8.0 * (AstronomyMaths.cosD(2.0 * l[mNumber] - m[mNumber]) - AstronomyMaths.sinD(m[mNumber] - 2 * m[Planets.Uranus]) - AstronomyMaths.cosD(2 * l[mNumber] + m[mNumber]) + AstronomyMaths.cosD(m[mNumber] - m[Planets.Uranus]) - AstronomyMaths.sinD(2.0 * l[mNumber] - m[mNumber])) + 7.0 * (AstronomyMaths.sinD(2.0 * l[mNumber] + m[mNumber]) - AstronomyMaths.cosD(m[Planets.Jupiter] - 2.0 * m[mNumber]));
        mTropicHelioLong = mTropicHelioLong + 5.0 * (AstronomyMaths.sinD(3.0 * m[Planets.Jupiter] - 4.0 * m[mNumber]) + AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]) - AstronomyMaths.sinD(3.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]) - AstronomyMaths.cosD(3.0 * (m[Planets.Jupiter] - m[mNumber])) - AstronomyMaths.cosD(3.0 * (m[mNumber] - m[Planets.Uranus]))) + 3.0 * (AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 6.0 * m[mNumber] + 3.0 * m[Planets.Uranus]) + AstronomyMaths.cosD(3.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]) + AstronomyMaths.cosD(4.0 * m[Planets.Jupiter] - 9.0 * m[mNumber]) + AstronomyMaths.sinD(3.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) + AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - m[mNumber]) + AstronomyMaths.sinD(m[Planets.Jupiter] - 4.0 * m[mNumber]));
        mTropicHelioLong = mTropicHelioLong + 4.0 * (AstronomyMaths.sinD(3.0 * (m[Planets.Jupiter] - m[mNumber])) + AstronomyMaths.sinD(3.0 * m[Planets.Jupiter] - 5.0 * m[mNumber])) + 2.0 * (AstronomyMaths.cosD(3.0 * (m[mNumber] - m[Planets.Uranus])) + AstronomyMaths.sinD(4.0 * m[mNumber]) - AstronomyMaths.cosD(3.0 * m[Planets.Jupiter] - 4.0 * m[mNumber]) - AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - m[mNumber]) - AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber] + 3.0 * m[Planets.Uranus]) + AstronomyMaths.cosD(m[Planets.Jupiter] - 4.0 * m[mNumber]) + AstronomyMaths.cosD(4.0 * m[Planets.Jupiter] - 11.0 * m[mNumber]) - AstronomyMaths.sinD(m[mNumber] - m[Planets.Uranus]));
        mHelioLat = 185.0 - 10.0 * mCTime + (8297.0 + 18.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) + (79.0 * mCTime - 3346.0) * AstronomyMaths.cosD(m[mNumber]) + (462.0 - 4.0 * mCTime) * AstronomyMaths.sinD(2.0 * m[mNumber]) - 189.0 * AstronomyMaths.cosD(2.0 * m[mNumber]) - 71.0 * AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) + 46.0 * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) - 45.0 * AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) + 29.0 * AstronomyMaths.sinD(3.0 * m[mNumber]) - 20.0 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 3.0 * m[mNumber]) - 14.0 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]);
        mHelioLat = mHelioLat - 11.0 * AstronomyMaths.cosD(3.0 * m[mNumber]) + 9.0 * AstronomyMaths.sinD(m[Planets.Jupiter] - 3.0 * m[mNumber]) + 8.0 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) - 6.0 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 3.0 * m[mNumber]) + 5.0 * (AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]) - AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]));
        mCoord.setHelioLat(mHelioLat + 4.0 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]) + 3.0 * (AstronomyMaths.cosD(m[Planets.Jupiter] - 3.0 * m[mNumber]) - AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]) + mCTime * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) + AstronomyMaths.sinD(m[Planets.Jupiter] - 2.0 * m[mNumber])) + 2.0 * (AstronomyMaths.sinD(4.0 * m[mNumber]) - AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - m[mNumber]))));
        mHelioDist = 9.55774 - 0.00028 * mCTime + (0.00328 * mCTime - 0.53252) * AstronomyMaths.cosD(m[mNumber]) - 0.01878 * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 2.0 * m[mNumber])) - 0.01482 * AstronomyMaths.cosD(2.0 * m[mNumber]) + 0.00817 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) - 0.00539 * AstronomyMaths.cosD(m[Planets.Jupiter] - 2.0 * m[mNumber]) - AstronomyMaths.sinD(m[mNumber]) * (0.00225 + 0.00524 * mCTime);
        mHelioDist = mHelioDist + 0.00349 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]) + 0.00347 * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) + 0.00149 * AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 3.0 * m[mNumber])) + 0.0002 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 7.0 * m[mNumber]);
        mCoord.setHelioDist(mHelioDist - 0.00126 * AstronomyMaths.cosD(2 * (m[Planets.Jupiter] - m[mNumber])) + 0.00104 * AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]) + 0.00101 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 5.0 * m[mNumber]) + 0.00098 * AstronomyMaths.cosD(m[Planets.Jupiter] - 3.0 * m[mNumber]) - 0.00073 * AstronomyMaths.cosD(2.0 * m[Planets.Jupiter] - 3.0 * m[mNumber]) - 0.00062 * AstronomyMaths.cosD(3.0 * m[mNumber]) + 0.00042 * AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 3.0 * m[Planets.Uranus]) + 0.00041 * AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - m[mNumber])) + 0.0004 * (AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 2.0* m[mNumber])) - AstronomyMaths.sinD(m[Planets.Jupiter] - 3.0 * m[mNumber])) - 0.00023 * AstronomyMaths.sinD(m[Planets.Jupiter]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
