/*
 * Coord.java
 *
 * Created on 18 mars 2003, 12:41
 */

package StarLogin.Systeme.AstroCalc;

import StarLogin.Systeme.Enum.CoordSystem;
import StarLogin.Systeme.Enum.Coordinate;
import StarLogin.Systeme.Enum.Retro;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Coord
{
    //local variables to hold property value(s)
    private double mAz;
    private double mAlt;
    private double mRA;
    private double mDecl;
    private double mGeoDist;
    private double mGeoLat;
    private double mSiderGeoLong;
    private double mTropicGeoLong;
    private double mHelioDist;
    private double mHelioLat;
    private double mSiderHelioLong;
    private double mTropicHelioLong;
    private double mX;
    private double mY;
    private double mZ;
    private double mRadius;
    private double mTheta;
    private double mPhi;
    private double mAyanamsa;
    private int mRetro;
    
    public int getRetro()
    {
        return mRetro;
    }
    
    public void setRetro(int Value)
    {
        mRetro = Value;
    }
    
    public double getPhi()
    {
        return mPhi;
    }
    
    public void setPhi(double Value)
    {
        mPhi = Value;
    }
    
    public double getTheta()
    {
        return mTheta;
    }
    
    public void setTheta(double Value)
    {
        mTheta = Value;
    }
    
    public double getRadius()
    {
        return mRadius;
    }
    
    public void setRadius(double Value)
    {
        mRadius = Value;
    }
    
    public double getZ()
    {
        return mZ;
    }
    
    public void setZ(double Value)
    {
        mZ = Value;
    }
    
    public double getY()
    {
        return mY;
    }
    
    public void setY(double Value)
    {
        mY = Value;
    }
    
    public double getX()
    {
        return mX;
    }
    
    public void setX(double Value)
    {
        mX = Value;
    }
    
    public double getTropicHelioLong()
    {
        return mTropicHelioLong;
    }
    
    public void setTropicHelioLong(double Value)
    {
        mTropicHelioLong = Value;
    }
    
    public double getSiderHelioLong()
    {
        return mSiderHelioLong;
    }
    
    public void setSiderHelioLong(double Value)
    {
        mSiderHelioLong = Value;
    }
    
    public double getHelioLat()
    {
        return mHelioLat;
    }
    
    public void setHelioLat(double Value)
    {
        mHelioLat = Value;
    }
    
    public double getHelioDist()
    {
        return mHelioDist;
    }
    
    public void setHelioDist(double Value)
    {
        mHelioDist = Value;
    }
    
    public double getTropicGeoLong()
    {
        return mTropicGeoLong;
    }
    
    public void setTropicGeoLong(double Value)
    {
        mTropicGeoLong = Value;
    }
    
    public double getSiderGeoLong()
    {
        return mSiderGeoLong;
    }
    
    public void setSiderGeoLong(double Value)
    {
        mSiderGeoLong = Value;
    }
    
    public double getGeoLat()
    {
        return mGeoLat;
    }
    
    public void setGeoLat(double Value)
    {
        mGeoLat = Value;
    }
    
    public double getGeoDist()
    {
        return mGeoDist;
    }
    
    public void setGeoDist(double Value)
    {
        mGeoDist = Value;
    }
    
    public double getDecl()
    {
        return mDecl;
    }
    
    public void setDecl(double Value)
    {
        mDecl = Value;
    }
    
    public double getRA()
    {
        return mRA;
    }
    
    public void setRA(double Value)
    {
        mRA = Value;
    }
    
    public double getAlt()
    {
        return mAlt;
    }
    
    public void setAlt(double Value)
    {
        mAlt = Value;
    }
    
    public double getAz()
    {
        return mAz;
    }
    
    public void setAz(double Value)
    {
        mAz = Value;
    }
    
    public double getAyanamsa()
    {
        return mAyanamsa;
    }
    
    public void setAyanamsa(double Value)
    {
        mAyanamsa = Value;
    }
    
    public void setCoord1(int SystemID, double value)
    {
        switch (SystemID)
        {
            case CoordSystem.HelioNormal : mTropicHelioLong = value;
            case CoordSystem.Ecliptic : mTropicGeoLong = value;
            case CoordSystem.Tropical : mTropicGeoLong = value;
            case CoordSystem.Sidereal : mTropicGeoLong = value + mAyanamsa;
            case CoordSystem.Equatorial : mRA = value;
            case CoordSystem.Local : mAz = value;
            case CoordSystem.HelioSidereal : mTropicHelioLong = value + mAyanamsa;
            case CoordSystem.Cartesian : mX = value;
            case CoordSystem.Spherical : mTheta = value;
            case CoordSystem.Domitudes : mAlt = value;
            default : ;
        }
    }
    
    //get the first coordinate
    public double getCoord1(int SystemID)
    {
        switch (SystemID)
        {
            case CoordSystem.HelioNormal : return mTropicHelioLong;
            case CoordSystem.Ecliptic : return mTropicGeoLong;
            case CoordSystem.Tropical : return mTropicGeoLong;
            case CoordSystem.Sidereal : return mTropicGeoLong - mAyanamsa;
            case CoordSystem.Equatorial : return mRA;
            case CoordSystem.Local : return mAz;
            case CoordSystem.HelioSidereal : return mTropicHelioLong - mAyanamsa;
            case CoordSystem.Cartesian : return mX;
            case CoordSystem.Spherical : return mTheta;
            case CoordSystem.Domitudes : return mAlt;
            default : return 0;
        }
    }
    
    //get the second coordinate
    public double getCoord2(int SystemID)
    {
        switch (SystemID)
        {
            case CoordSystem.HelioNormal : return mHelioLat;
            case CoordSystem.HelioSidereal : return mHelioLat;
            case CoordSystem.Ecliptic : return mGeoLat;
            case CoordSystem.Tropical : return mDecl;
            case CoordSystem.Sidereal : return mDecl;
            case CoordSystem.Equatorial : return mDecl;
            case CoordSystem.Local : return mAlt;
            case CoordSystem.Cartesian : return mY;
            case CoordSystem.Spherical : return mPhi;
            case CoordSystem.Domitudes : return mAz;
            default : return 0;
        }
    }
    
    //get the third coordinate
    public double getCoord3(int SystemID)
    {
        switch (SystemID)
        {
            case CoordSystem.HelioNormal : return mHelioDist;
            case CoordSystem.HelioSidereal : return mHelioDist;
            case CoordSystem.Ecliptic : return mGeoDist;
            case CoordSystem.Tropical : return mGeoDist;
            case CoordSystem.Sidereal : return mGeoDist;
            case CoordSystem.Equatorial : return mGeoDist;
            case CoordSystem.Local : return mGeoDist;
            case CoordSystem.Cartesian : return mZ;
            case CoordSystem.Spherical : return mRadius;
            case CoordSystem.Domitudes : return mGeoDist;
            default : return 0;
        }
    }
    
    //NAME OF COORDINATES SYSTEMS
    public String systemName(int SystemID)
    {
        return CoordSystem.getCoordSystemName(SystemID);
    }
    
    //NAME OF COORDINATES
    public String coordName(int coordinate)
    {
        return Coordinate.getCoordinateName(coordinate);
    }
    
    //Calculation of the right ascension of a planet from ecliptic coordinates
    //input : obliquity : inclination of the equator on the ecliptic
    public double raFromEcliptic(double Obliquity)
    {
        return AstronomyMaths.getRA(Obliquity, mGeoLat, mTropicGeoLong);
    }
    
    //Calculation of the declination of a planet from ecliptic coordinates
    //input : obliquity : inclination of the equator on the ecliptic
    public double declFromEcliptic(double Obliquity)
    {
        return AstronomyMaths.getDeclination(Obliquity, mGeoLat, mTropicGeoLong);
    }
    
    //Calculation of the right ascension of a planet from equatorial coordinates
    //input : obliquity : inclination of the equator on the ecliptic
    public double longFromEquatorial(double Obliquity)
    {
        return AstronomyMaths.getLongitude(Obliquity, mDecl, mRA);
    }
    
    //Calculation of the corrected heliocentric longitude
    public double correctedHelioLong(double MoonNode)
    {
        return AstronomyMaths.getCorHelioLong(mTropicHelioLong, MoonNode);
    }
    
    //Calculation of the altitude of a planet from equatorial coordinates
    //input : latitude : geographical latitude of the place
    //        tsl      : local sidereal time
    public double altFromEquatorial(double Latitude, double TSL)
    {
        return AstronomyMaths.getAltitude(Latitude, mDecl, mRA, TSL);
    }
    
    //Calculation of the Azimuth of a planet from equatorial coordinates
    //input : latitude : geographical latitude of the place
    //        tsl      : local sidereal time
    public double azFromEquatorial(double Latitude, double TSL)
    {
        return AstronomyMaths.getAzimuth(Latitude, mDecl, mRA, TSL);
    }
    
    //get the geocentric latitude of a planet
    public double latHelio2Geo()
    {
        return AstronomyMaths.getGeoLat(mHelioDist, mGeoDist, mHelioLat);
    }
    
    //get the geocentric longitude of a planet
    //input : EarthSunDist : distance between the Earth and the Sun
    //        SunLong      : geocentric longitude of theSun
    public double longHelio2Geo(double EarthSunDist, double SunLong)
    {
        return AstronomyMaths.getGeoLong(EarthSunDist, mHelioDist, mHelioLat, mTropicHelioLong, SunLong);
    }
    
    //get the distance between a planet and the Earth
    public double distHelio2Geo(double EarthSunDist, double SunLong)
    {
        return AstronomyMaths.getGeoDist(EarthSunDist, mHelioDist, mHelioLat, mTropicHelioLong, SunLong);
    }
    
    public String getRetroString(int retro)
    {
        return Retro.getRetroString(retro);
    }
    
    public int setRetro(String retro)
    {
        if (retro.equals("R"))
            return Retro.Retro;
        else
        {
            if (retro.equals("S"))
                return Retro.Static;
            else
                return Retro.Null;
        }
    }
    
    /** Creates new Coord */
    public Coord()
    {
        mAz = 0.0;
        mAlt = 0.0;
        mRA = 0.0;
        mDecl = 0.0;
        mGeoDist = 0.0;
        mGeoLat = 0.0;
        mSiderGeoLong = 0.0;
        mTropicGeoLong = 0.0;
        mHelioDist = 0.0;
        mHelioLat = 0.0;
        mSiderHelioLong = 0.0;
        mTropicHelioLong = 0.0;
        mX = 0.0;
        mY = 0.0;
        mZ = 0.0;
        mRadius = 0.0;
        mTheta = 0.0;
        mPhi = 0.0;
        mAyanamsa = 0.0;
        mRetro = 0;
    }
    
}
