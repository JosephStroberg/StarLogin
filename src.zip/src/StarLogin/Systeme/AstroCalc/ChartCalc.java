package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartCalc
{
    
    /** Creates a new instance of ChartCalc */
    public ChartCalc()
    {
    }
    
}
