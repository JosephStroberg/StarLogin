/*
 * Mercury.java
 *
 * Created on 6 ao�t 2003, 07:57
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Mercury
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Mercury */
    public Mercury(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Mercury;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mHelioLat;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + (84378 + 8.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) + 10733.0 * AstronomyMaths.sinD(2.0 * m[mNumber]) + 1892.0 * AstronomyMaths.sinD(3.0 * m[mNumber]) + 381.0 * AstronomyMaths.sinD(4.0 * m[mNumber]) + 83.0 * Math.sin(AstronomyMaths.PI / 36.0 * m[mNumber]) + 19.0 * Math.sin(AstronomyMaths.PI / 30.0 * m[mNumber]) - 646.0 * AstronomyMaths.sinD(2.0 * u[mNumber]);
        mTropicHelioLong = mTropicHelioLong - 306.0 * AstronomyMaths.sinD(m[mNumber] - 2.0 * u[mNumber]) - 274.0 * AstronomyMaths.sinD(m[mNumber] + 2.0 * u[mNumber]) - 92.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] + u[mNumber])) - 28.0 * AstronomyMaths.sinD(3.0 * m[mNumber] + 2.0 * u[mNumber]) + 25.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] - u[mNumber])) - 9.0 * AstronomyMaths.sinD(2.0 * (2.0 * m[mNumber] + u[mNumber])) + 7.0 * AstronomyMaths.cosD(2.0 * m[mNumber] - 5.0 * m[Planets.Venus]);
        mCoord.setHelioDist(0.39528 - 0.07834 * AstronomyMaths.cosD(m[mNumber]) - 0.00795 * AstronomyMaths.cosD(2.0 * m[mNumber]) - 0.00121 * AstronomyMaths.cosD(3.0 * m[mNumber]) - 0.00022 * AstronomyMaths.cosD(4.0 * m[mNumber]));
        mHelioLat = 24134.0 * AstronomyMaths.sinD(u[mNumber]) - 10.0 * AstronomyMaths.sinD(3.0 * u[mNumber]) + 5180.0 * AstronomyMaths.sinD(m[mNumber] - u[mNumber]) + 4910.0 * AstronomyMaths.sinD(m[mNumber] + u[mNumber]) + 1124.0 * AstronomyMaths.sinD(2.0 * m[mNumber] + u[mNumber]) + 271.0 * AstronomyMaths.sinD(3.0 * m[mNumber] + u[mNumber]) + 132.0 * AstronomyMaths.sinD(2.0 * m[mNumber] - u[mNumber]);
        mCoord.setHelioLat(mHelioLat + 67.0 * AstronomyMaths.sinD(4.0 * m[mNumber] + u[mNumber]) + 18.0 * AstronomyMaths.sinD(3.0 * m[mNumber] - u[mNumber]) + 17.0 * AstronomyMaths.sinD(5.0 * m[mNumber] + u[mNumber]) - 9.0 * AstronomyMaths.sinD(m[mNumber] - 3.0 * u[mNumber]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
