package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class AsteroidsCalc
{
    
    /** Creates a new instance of AsteroidsCalc */
    public AsteroidsCalc()
    {
    }
    
}
