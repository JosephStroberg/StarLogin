package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Moon
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunLongitude;
    private double mSunEarthDist;
    private double mGeoDist;
    private double mHelioDist;
    private double mGeoLat;
    private double mTropicGeoLong;
    
    /** Creates new Moon */
    public Moon(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setSunLongitude(double Value)
    {
        mSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public double getGeoDist()
    {
        return mGeoDist;
    }
    
    public double getGeoLat()
    {
        return mGeoLat;
    }
    
    public double getHelioDist()
    {
        return mHelioDist;
    }
    
    public double getTropicGeoLong()
    {
        return mTropicGeoLong;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Moon;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        
        //Mean longitude of the Moon
        double ll = 270.435378 + 481267.880862 * mCTime;
        //Mean anomaly of the Moon
        double ml = 296.095334 + 477198.867586 * mCTime;
        //angular distance between the mean Moon and the north node
        double f = 11.254075 + 483202.018685 * mCTime;
        //Moon mean elongation
        double d = 350.738975 + 445267.111345 * mCTime;
        //longitude of the north node
        double om = 259.181303 - 1934.137823 * mCTime;

        mTropicGeoLong = ll * 3600.0 + 22640 * AstronomyMaths.sinD(ml) - 4586.0 * AstronomyMaths.sinD(ml - 2.0 * d) + 2370.0 * AstronomyMaths.sinD(2.0 * d) + 769.0 * AstronomyMaths.sinD(2.0 * ml) - 668.0 * AstronomyMaths.sinD(m[Planets.Sun]) - 412.0 * AstronomyMaths.sinD(2.0 * f) - 212.0 * AstronomyMaths.sinD(2.0 * (ml - d)) - 206.0 * AstronomyMaths.sinD(ml - 2.0 * d + m[Planets.Sun]);
        mTropicGeoLong = mTropicGeoLong + 192.0 * AstronomyMaths.sinD(ml + 2.0 * d) + 165.0 * AstronomyMaths.sinD(2.0 * d - m[Planets.Sun]) + 148.0 * AstronomyMaths.sinD(ml - m[Planets.Sun]) - 125.0 * AstronomyMaths.sinD(d) - 110.0 * AstronomyMaths.sinD(ml + m[Planets.Sun]) - 55.0 * AstronomyMaths.sinD(2.0 * (f - d)) - 45.0 * AstronomyMaths.sinD(ml + 2.0 * f) + 40.0 * AstronomyMaths.sinD(ml - 2.0 * f);
        mTropicGeoLong = mTropicGeoLong - 38.0 * AstronomyMaths.sinD(ml - 4.0 * d) + 36.0 * AstronomyMaths.sinD(3.0 * ml) - 31.0 * AstronomyMaths.sinD(2.0 * (ml - 2.0 * d)) + 28.0 * AstronomyMaths.sinD(ml - 2.0 * d - m[Planets.Sun]) - 24.0 * AstronomyMaths.sinD(2.0 * d + m[Planets.Sun]) + 19.0 * AstronomyMaths.sinD(ml - d) + 18.0 * AstronomyMaths.sinD(d + m[Planets.Sun]) + 15.0 * AstronomyMaths.sinD(ml + 2.0 * d - m[Planets.Sun]);
        mTropicGeoLong = mTropicGeoLong + 14.0 * (AstronomyMaths.sinD(2.0 * (ml + d)) + AstronomyMaths.sinD(4.0 * d)) - 13.0 * AstronomyMaths.sinD(3.0 * ml - 2.0 * d) + (4.0 * mCTime - 11.0) * AstronomyMaths.sinD(ml + 16.0 * l[Planets.Sun] - 18.0 * l[Planets.Venus]) + 10.0 * AstronomyMaths.sinD(2.0 * ml - m[Planets.Sun]) + 9.0 * (AstronomyMaths.sinD(ml - 2.0 * (f + d)) - AstronomyMaths.sinD(2.0 * (ml - d) + m[Planets.Sun])) + (9.0 + 4.0 * mCTime) * AstronomyMaths.cosD(ml + 16.0 * l[Planets.Sun] - 18.0 * l[Planets.Venus]);
        mTropicGeoLong = mTropicGeoLong + 8.0 * (AstronomyMaths.sinD(2.0 * (d - m[Planets.Sun])) - AstronomyMaths.sinD(ml + d) - AstronomyMaths.sinD(2.0 * ml + m[Planets.Sun])) + 7.0 * (AstronomyMaths.sinD(om) - AstronomyMaths.sinD(2.0 * m[Planets.Sun]) - AstronomyMaths.sinD(ml + 2.0 * (m[Planets.Sun] - d))) - 6.0 * (AstronomyMaths.sinD(ml + 2.0 * (d - f)) + AstronomyMaths.sinD(2.0 * (f + d))) - 4.0 * (AstronomyMaths.sinD(ml + m[Planets.Sun] - 4.0 * d) + AstronomyMaths.sinD(2.0 * (ml + f)));
        mTropicGeoLong = mTropicGeoLong + 3.0 * (AstronomyMaths.sinD(ml - 3.0 * d) - AstronomyMaths.sinD(ml + m[Planets.Sun] + 2.0 * d) - AstronomyMaths.sinD(m[Planets.Sun] + 2.0 * ml - 4.0 * d) + AstronomyMaths.sinD(ml - 2.0 * m[Planets.Sun]) + AstronomyMaths.sinD(ml - 2.0 * (d + m[Planets.Sun]))) + 2.0 * (AstronomyMaths.sinD(ml + 4.0 * d) - AstronomyMaths.sinD(2.0 * (ml - d) - m[Planets.Sun]) - AstronomyMaths.sinD(2.0 * (f - d) + m[Planets.Sun]) + AstronomyMaths.sinD(4.0 * ml) + AstronomyMaths.sinD(4.0 * d - m[Planets.Sun]) + AstronomyMaths.sinD(2.0 * ml - d));
        mTropicGeoLong = AstronomyMaths.modulo(mTropicGeoLong / 3600.0, 360.0);
        mCoord.setTropicGeoLong(mTropicGeoLong);
        mGeoLat = 18461.0 * AstronomyMaths.sinD(f) + 1010.0 * AstronomyMaths.sinD(ml + f) + 1000.0 * AstronomyMaths.sinD(ml - f) - 624.0 * AstronomyMaths.sinD(f - 2.0 * d) - 199.0 * AstronomyMaths.sinD(ml - f - 2.0 * d) - 167.0 * AstronomyMaths.sinD(ml + f - 2.0 * d) + 117.0 * AstronomyMaths.sinD(f + 2.0 * d) + 62.0 * AstronomyMaths.sinD(2.0 * ml + f) + 33.0 * AstronomyMaths.sinD(ml - f + 2.0 * d);
        mGeoLat = mGeoLat + 32.0 * AstronomyMaths.sinD(2.0 * ml - f) - 30.0 * AstronomyMaths.sinD(f - 2.0 * d + m[Planets.Sun]) - 16.0 * AstronomyMaths.sinD(2.0 * (ml - d) + f) + 15.0 * AstronomyMaths.sinD(ml + f + 2.0 * d) + 12.0 * AstronomyMaths.sinD(f - 2.0 * d - m[Planets.Sun]) - 9.0 * AstronomyMaths.sinD(ml - f - 2.0 * d + m[Planets.Sun]) + 8.0 * (AstronomyMaths.sinD(f + 2.0 * d - m[Planets.Sun]) - AstronomyMaths.sinD(f + om));
        mGeoLat = mGeoLat + 7.0 * (AstronomyMaths.sinD(ml + f - m[Planets.Sun]) - AstronomyMaths.sinD(ml + f - 2.0 * d + m[Planets.Sun]) - AstronomyMaths.sinD(ml + f - 4.0 * d)) + 6.0 * (AstronomyMaths.sinD(ml - f - m[Planets.Sun]) - AstronomyMaths.sinD(f + m[Planets.Sun]) - AstronomyMaths.sinD(3.0 * f)) + 5.0 * (AstronomyMaths.sinD(f - m[Planets.Sun]) - AstronomyMaths.sinD(ml + f + m[Planets.Sun]) - AstronomyMaths.sinD(f + d) - AstronomyMaths.sinD(ml - f + m[Planets.Sun]) + AstronomyMaths.sinD(f - d));
        mGeoLat = mGeoLat + 4.0 * (AstronomyMaths.sinD(3.0 * ml + f) - AstronomyMaths.sinD(f - 4.0 * d)) + 3.0 * (AstronomyMaths.sinD(ml - 3.0 * f) - AstronomyMaths.sinD(ml - f - 4.0 * d)) + 2.0 * (AstronomyMaths.sinD(2.0 * (ml + d) - f) - AstronomyMaths.sinD(2.0 * ml - f - 4.0 * d) - AstronomyMaths.sinD(3.0 * f - 2.0 * d) + AstronomyMaths.sinD(ml - f + 2.0 * d - m[Planets.Sun]) + AstronomyMaths.sinD(2.0 * (ml - d) - f) + AstronomyMaths.sinD(3.0 * ml - f));
        mGeoLat = AstronomyMaths.getHelioLat(mGeoLat);
        mCoord.setGeoLat(mGeoLat);
        mGeoDist = 60.36298 - 3.27746 * AstronomyMaths.cosD(ml) - 0.57994 * AstronomyMaths.cosD(ml - 2.0 * d) - 0.46357 * AstronomyMaths.cosD(2.0 * d) - 0.08904 * AstronomyMaths.cosD(2.0 * ml) + 0.03865 * AstronomyMaths.cosD(2.0 * (ml - d)) - 0.03237 * AstronomyMaths.cosD(2.0 * d - m[Planets.Sun]) - 0.02688 * AstronomyMaths.cosD(ml + 2.0 * d) - 0.02358 * AstronomyMaths.cosD(ml - 2.0 * d + m[Planets.Sun]) - 0.0203 * AstronomyMaths.cosD(ml - m[Planets.Sun]) + 0.00249 * AstronomyMaths.cosD(3.0 * ml - 2.0 * d);
        mGeoDist = mGeoDist + 0.01719 * AstronomyMaths.cosD(d) + 0.01671 * AstronomyMaths.cosD(ml + m[Planets.Sun]) + 0.01247 * AstronomyMaths.cosD(ml - 2.0 * f) + 0.00704 * AstronomyMaths.cosD(m[Planets.Sun]) + 0.00529 * AstronomyMaths.cosD(2.0 * d + m[Planets.Sun]) - 0.00524 * AstronomyMaths.cosD(ml - 4.0 * d) + 0.00398 * AstronomyMaths.cosD(ml - 2.0 * d - m[Planets.Sun]) - 0.00366 * AstronomyMaths.cosD(3.0 * ml) - 0.00295 * AstronomyMaths.cosD(2.0 * ml - 4.0 * d) - 0.00263 * AstronomyMaths.cosD(d + m[Planets.Sun]);
        mGeoDist = mGeoDist - 0.00221 * AstronomyMaths.cosD(ml + 2.0 * d - m[Planets.Sun]) + 0.00185 * AstronomyMaths.cosD(2.0 * (f - d)) - 0.00161 * AstronomyMaths.cosD(2.0 * (d - m[Planets.Sun])) + 0.00147 * AstronomyMaths.cosD(ml + 2.0 * (f - d)) - 0.00142 * AstronomyMaths.cosD(4.0 * d) + 0.00139 * AstronomyMaths.cosD(2.0 * (ml - d) + m[Planets.Sun]) - 0.00118 * AstronomyMaths.cosD((ml - 4.0 * d) + m[Planets.Sun]) - 0.00116 * AstronomyMaths.cosD(2.0 * (ml + d)) - 0.0011 * AstronomyMaths.cosD(2.0 * ml - m[Planets.Sun]);
        mGeoDist = mGeoDist * 6378.14 / 149597900.0;
        mCoord.setGeoDist(mGeoDist);
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mSunLongitude - 180.0, 360.0)); //Cas Philippe: mCoord.TropicGeoLong
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setTropicHelioLong(mCoord.getTropicGeoLong()); //(cas Philippe) ou bien : longitude_helio(soleil) = 0
        mCoord.setHelioLat(0.0);
        mHelioDist = Math.sqrt(mSunEarthDist * mSunEarthDist + mCoord.getGeoDist() * mCoord.getGeoDist() + 2.0 * mSunEarthDist * mCoord.getGeoDist() * AstronomyMaths.cosD(mCoord.getTropicHelioLong() - mSunLongitude));
        mCoord.setHelioDist(mHelioDist);
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
