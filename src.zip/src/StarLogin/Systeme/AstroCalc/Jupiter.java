/*
 * Jupiter.java
 *
 * Created on 7 ao�t 2003, 07:06
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Jupiter
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Jupiter */
    public Jupiter(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Jupiter;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mHelioDist;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + 2511.0 + 5023.0 * mCTime + (19934.0 + 68.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) - (37.0 + 74.0 * mCTime) * AstronomyMaths.cosD(m[mNumber]) + (601.0 + 3 * mCTime) * AstronomyMaths.sinD(2.0 * m[mNumber]) + (1093.0 - 19.0 * mCTime) * AstronomyMaths.cosD(2.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - (479.0 + 43.0 * mCTime) * AstronomyMaths.sinD(2.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - 185.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Saturn])) + (137.0 - 2.0 * mCTime) * AstronomyMaths.sinD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]);
        mTropicHelioLong = mTropicHelioLong - 131.0 * AstronomyMaths.sinD(m[mNumber] - 2.0 * m[Planets.Saturn]) + 79.0 * AstronomyMaths.cosD(m[mNumber] - m[Planets.Saturn]) - 76.0 * AstronomyMaths.cosD(2.0 * (m[mNumber] - m[Planets.Saturn])) + 66.0 * AstronomyMaths.cosD(2.0 * m[mNumber] - 3.0 * m[Planets.Saturn]) + 63.0 * AstronomyMaths.cosD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) + 53.0 * AstronomyMaths.cosD(m[mNumber] - 5.0 * m[Planets.Saturn]) + 49.0 * AstronomyMaths.sinD(2.0 * m[mNumber] - 3.0 * m[Planets.Saturn]) + 25.0 * (AstronomyMaths.sinD(2.0 * l[mNumber]) + AstronomyMaths.sinD(3.0 * m[mNumber])) - (23.0 + 2.0 * mCTime) * AstronomyMaths.sinD(m[mNumber] - 5.0 * m[Planets.Saturn]);
        mTropicHelioLong = mTropicHelioLong + 17.0 * (AstronomyMaths.cosD(2.0 * (m[mNumber] - 2.0 * m[Planets.Saturn])) + AstronomyMaths.cosD(3.0 * (m[mNumber] - m[Planets.Saturn]))) - 14.0 * AstronomyMaths.sinD(m[mNumber] - m[Planets.Saturn]) - 13.0 * (AstronomyMaths.PI_SUR_CENT80 * (3.0 * m[mNumber] - 4.0 * m[Planets.Saturn])) + 9.0 * (AstronomyMaths.cosD(m[Planets.Saturn]) - AstronomyMaths.cosD(2.0 * l[mNumber]) - AstronomyMaths.sinD(m[Planets.Saturn]) - AstronomyMaths.sinD(3.0 * m[mNumber] - 2.0 * m[Planets.Saturn]) + AstronomyMaths.sinD(4.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) + AstronomyMaths.sinD(2.0 * m[mNumber] - 6.0 * m[Planets.Saturn] + 3.0 * m[Planets.Uranus])) - 8.0 * AstronomyMaths.cosD(4.0 * m[mNumber] - 10.0 * m[Planets.Saturn]);
        mTropicHelioLong = mTropicHelioLong + 7.0 * (AstronomyMaths.cosD(3.0 * m[mNumber] - 4.0 * m[Planets.Saturn]) - AstronomyMaths.cosD(m[mNumber] - 3.0 * m[Planets.Saturn]) - AstronomyMaths.sinD(4.0 * m[mNumber] - 10.0 * m[Planets.Saturn]) - AstronomyMaths.sinD(m[mNumber] - 3.0 * m[Planets.Saturn])) + 6.0 * (AstronomyMaths.cosD(4.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - AstronomyMaths.sinD(3.0 * (m[mNumber] - m[Planets.Saturn]))) + 5.0 * AstronomyMaths.cosD(2.0 * m[Planets.Saturn]) + 4.0 * (AstronomyMaths.cosD(2.0 * m[mNumber] - m[Planets.Saturn]) - AstronomyMaths.sinD(4.0 * (m[mNumber] - m[Planets.Saturn])) - AstronomyMaths.cosD(3.0 * m[Planets.Saturn]) - AstronomyMaths.cosD(3.0 * m[mNumber] - 2.0 * m[Planets.Saturn]) - mCTime * AstronomyMaths.cosD(2.0 * m[mNumber]));
        mTropicHelioLong = mTropicHelioLong + 3.0 * (Math.cos(AstronomyMaths.PI / 36.0 * m[Planets.Saturn]) + Math.cos(AstronomyMaths.PI / 36.0 * (m[mNumber] - 2.0 * m[Planets.Saturn])) + AstronomyMaths.sinD(2.0 * m[Planets.Saturn])) + 2.0 * (AstronomyMaths.sinD(2.0 * l[mNumber] + m[mNumber]) - AstronomyMaths.sinD(2.0 * l[mNumber] - m[mNumber]));
        mCoord.setHelioLat((21.0 * mCTime - 4692.0) * AstronomyMaths.cosD(m[mNumber]) + (259.0 + 30.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) + 227.0 * (1.0 - AstronomyMaths.cosD(2.0 * m[mNumber])) + 16.0 * AstronomyMaths.sinD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - 13.0 * AstronomyMaths.sinD(m[mNumber] - 5.0 * m[Planets.Saturn]) + 12.0 * (AstronomyMaths.sinD(2.0 * m[mNumber]) - AstronomyMaths.cosD(3.0 * m[mNumber])) + 7.0 * AstronomyMaths.cosD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - 5.0 * AstronomyMaths.cosD(m[mNumber] - 5.0 * m[Planets.Saturn]));
        mHelioDist = 5.20883 - (0.25122 + 0.00084 * mCTime) * AstronomyMaths.cosD(m[mNumber]) - (0.00046 + 0.00091 * mCTime) * AstronomyMaths.sinD(m[mNumber]) - 0.00604 * AstronomyMaths.cosD(2.0 * m[mNumber]) + 0.0026 * AstronomyMaths.cosD(2.0 * (m[mNumber] - m[Planets.Saturn])) - 0.0017 * AstronomyMaths.cosD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) - 0.0016 * AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Saturn])) + 0.00069 * AstronomyMaths.sinD(2.0 * m[mNumber] - 3.0 * m[Planets.Saturn]) - 0.00067 * AstronomyMaths.sinD(m[mNumber] - 5.0 * m[Planets.Saturn]);
        mCoord.setHelioDist(mHelioDist + 0.00066 * AstronomyMaths.sinD(3.0 * m[mNumber] - 5.0 * m[Planets.Saturn]) + 0.00063 * AstronomyMaths.sinD(m[mNumber] - m[Planets.Saturn]) - 0.00051 * AstronomyMaths.cosD(2.0 * m[mNumber] - 3.0 * m[Planets.Saturn]) - 0.00029 * AstronomyMaths.cosD(m[mNumber] - 5.0 * m[Planets.Saturn]) + 0.00027 * AstronomyMaths.cosD(m[mNumber] - 2.0 * m[Planets.Saturn]) - 0.00022 * AstronomyMaths.cosD(3.0 * m[mNumber]) - 0.00021 * AstronomyMaths.sinD(2.0 * m[mNumber] - 5.0 * m[Planets.Saturn]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
