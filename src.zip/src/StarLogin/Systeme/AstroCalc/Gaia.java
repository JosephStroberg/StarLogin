/*
 * Gaia.java
 *
 * Created on 7 ao�t 2003, 07:12
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Gaia
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mSunLongitude;
    
    /** Creates new Gaia */
    public Gaia(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setSunLongitude(double Value)
    {
        mSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mSunLongitude - 180.0, 360.0));
        mCoord.setHelioLat(0.0);
        mCoord.setHelioDist(mSunEarthDist);
        mCoord.setTropicGeoLong(mCoord.getTropicHelioLong()); //(misuse)
        mCoord.setGeoLat(0.0);
        mCoord.setGeoDist(0.0);
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
