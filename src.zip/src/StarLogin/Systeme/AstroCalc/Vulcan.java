package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Vulcan
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mSunLongitude;
    
    /** Creates new Vulcan */
    public Vulcan(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setSunLongitude(double Value)
    {
        mSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        double mJD = chartEvent.getJD();
        double mUTH = chartEvent.getTime();
        mCoord.setHelioDist(0.1373);
        mCoord.setTropicHelioLong( AstronomyMaths.modulo(AstronomyMaths.frac((mJD + mUTH / 24.0 - (2417751.5 + 20.65 / 24.0)) / 18.5842061837) * 360.0 + 273.109166666667, 360.0));
        mCoord.setHelioLat(0.0);
        mCoord.setTropicGeoLong(AstronomyMaths.modulo(mSunLongitude - AstronomyMaths.asinD(AstronomyMaths.sinD(mSunLongitude - mCoord.getTropicHelioLong()) * mCoord.getHelioDist() / Math.sqrt(1.0 + mCoord.getHelioDist() * mCoord.getHelioDist())), 360.0));
        mCoord.setGeoLat(0.0);
        mCoord.setGeoDist(Math.sqrt(1 + mCoord.getHelioDist() * mCoord.getHelioDist()));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
