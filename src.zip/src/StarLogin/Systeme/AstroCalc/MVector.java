package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class MVector
{
    private double mvarX;
    private double mvarY;
    private double mvarZ;
    
    /** Creates a new instance of MVector */
    public MVector()
    {
    }
    
    public MVector(double x, double y, double z)
    {
        mvarX = x;
        mvarY = y;
        mvarZ = z;
    }
    
    public double getZ()
    {
        return mvarZ;
    }
    private void setZ(double value)
    {
        mvarZ = value;
    }
    
    public double getY()
    {
        return mvarY;
    }
    private void setY(double value)
    {
        mvarY = value;
    }
    
    public double getX()
    {
        return mvarX;
    }
    private void setX(double value)
    {
        mvarX = value;
    }
    
    public MVector AddArrayLists(MVector v1, MVector v2)
    {
        MVector v = new MVector();
        v.setX(v1.getX() + v2.getX());
        v.setY(v1.getY() + v2.getY());
        v.setZ(v1.getZ() + v2.getZ());
        return v;
    }
    
    public double CrossArrayLists(MVector v1, MVector v2)
    {
        return v1.getX() * v2.getX() + v1.getY() * v2.getY() + v1.getZ() * v2.getZ();
    }
    
    public MVector ArrayListProduct(MVector v1, MVector v2)
    {
        MVector v = new MVector();
        v.setX(v1.getY() * v2.getZ() - v2.getY() * v1.getZ());
        v.setY(v1.getZ() * v2.getX() - v2.getZ() * v1.getX());
        v.setZ(v1.getX() * v2.getY() - v2.getX() * v1.getY());
        return v;
    }
    
    public double NormArrayList(MVector v)
    {
        return Math.sqrt(CrossArrayLists(v, v));
    }
    
    //Angle between two ArrayLists in degrees
    public double AngleArrayListsD(MVector v1, MVector v2)
    {
        double dblDenomin = NormArrayList(v1) * NormArrayList(v2);
        if ( dblDenomin != 0 )
        {
            return AstronomyMaths.acosD(CrossArrayLists(v1, v2) / dblDenomin);
        }
        else
        {
            return 0;
        }
    }
    
    //Angle between two ArrayLists in radians
    public double AngleArrayLists(MVector v1, MVector v2)
    {
        double dblDenomin = NormArrayList(v1) * NormArrayList(v2);
        if ( dblDenomin != 0 )
        {
            return Math.acos(CrossArrayLists(v1, v2) / dblDenomin);
        }
        else
        {
            return 0;
        }
    }
    
    //Rotation around z Axis
    public MVector RotatC3(MVector v, double angle)
    {
        MVector v2 = new MVector();
        v2.setX(v.getX() * Math.cos(angle) - v.getY() * Math.sin(angle));
        v2.setY(v.getY() * Math.cos(angle) + v.getX() * Math.sin(angle));
        v2.setZ(v.getZ());
        return v2;
    }
    
    //Rotation around x Axis
    public MVector RotatC1(MVector v, double angle)
    {
        MVector v2 = new MVector();
        v2.setX(v.getX());
        v2.setY(v.getY() * Math.cos(angle) - v.getZ() * Math.sin(angle));
        v2.setZ(v.getZ() * Math.cos(angle) + v.getY() * Math.sin(angle));
        return v2;
    }
    
    //Rotation around y Axis
    public MVector RotatC2(MVector v, double angle)
    {
        MVector v2 = new MVector();
        v2.setX(v.getX() * Math.cos(angle) + v.getZ() * Math.sin(angle));
        v2.setY(v.getY());
        v2.setZ(v.getZ() * Math.cos(angle) - v.getX() * Math.sin(angle));
        return v2;
    }
}
