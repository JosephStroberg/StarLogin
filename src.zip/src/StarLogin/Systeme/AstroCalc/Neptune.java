/*
 * Neptune.java
 *
 * Created on 7 ao�t 2003, 07:10
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Neptune
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Neptune */
    public Neptune(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Neptune;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + (3523.0 + 4.0 * mCTime * (mCTime - 1.0)) * AstronomyMaths.sinD(m[mNumber]) - 50.0 * AstronomyMaths.sinD(2.0 * u[mNumber]) - 43.0 * mCTime * AstronomyMaths.cosD(m[mNumber]) + 29.0 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) + 19.0 * AstronomyMaths.sinD(2.0 * m[mNumber]) - 18.0 * AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]);
        mTropicHelioLong = mTropicHelioLong + 13.0 * (AstronomyMaths.cosD(m[Planets.Saturn] - m[mNumber]) + AstronomyMaths.sinD(m[Planets.Saturn] - m[mNumber])) + 9.0 * (AstronomyMaths.cosD(2.0 * (m[Planets.Uranus] - m[mNumber])) - AstronomyMaths.sinD(2.0 * m[Planets.Uranus] - 3.0 * m[mNumber])) - 5.0 * AstronomyMaths.cosD(2.0 * m[Planets.Uranus] - 3.0 * m[mNumber]) + 4.0 * AstronomyMaths.cosD(m[Planets.Uranus] - 2.0 * m[mNumber]);
        mCoord.setHelioLat((6404.0 - 33.0 * mCTime) * AstronomyMaths.sinD(u[mNumber]) + 55.0 * (AstronomyMaths.sinD(m[mNumber] + u[mNumber]) + AstronomyMaths.sinD(m[mNumber] - u[mNumber])));
        mCoord.setHelioDist(30.07175 - 0.25701 * AstronomyMaths.cosD(m[mNumber]) - 0.00787 * AstronomyMaths.cosD(2.0 * (l[Planets.Uranus] - l[mNumber]) - m[Planets.Uranus]) + 0.00409 * AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]) - 0.00314 * mCTime * AstronomyMaths.sinD(m[mNumber]) + 0.0025 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) - 0.00194 * AstronomyMaths.sinD(m[Planets.Saturn] - m[mNumber]) + 0.00185 * AstronomyMaths.cosD(m[Planets.Saturn] - m[mNumber]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
