package StarLogin.Systeme.AstroCalc;

import StarLogin.Systeme.AstroCalc.Coord;
import StarLogin.Systeme.AstroCalc.Planet;
import StarLogin.Systeme.Data.Comet;
import StarLogin.Systeme.Data.Asteroid;
import StarLogin.Systeme.ChartElements;
import StarLogin.StarLoginManager;
import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Enum.Planets;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class CometAsteroid
{
    private ChartElements chartElements;
    
    /** Creates a new instance of CometAsteroid */
    public CometAsteroid(ChartElements chartElements)
    {
        this.chartElements = chartElements;
    }
    
    public String getAsteroidIDFromName(String asteroidName, ArrayList asteroids)
    {
        String id = "";
        //ArrayList asteroids = starLoginManager.getAsteroids().getAsteroids();
        if (asteroids == null || asteroids.size() == 0) return "";
        for (int i = 0; i < asteroids.size(); i++)
        {
            ArrayList v = (ArrayList)asteroids.get(i);
            String nom = String.valueOf(v.get(1));
            id = v.get(0).toString();
            if (nom.equals(asteroidName))
            {
                break;
            }
        }
        return id;
    }
    
    public String getCometIDFromName(String cometName, ArrayList comets)
    {
        String id = "";
        //ArrayList comets = starLoginManager.getComets().getComets();
        if (comets == null || comets.size() == 0) return "";
        for (int i = 0; i < comets.size(); i++)
        {
            ArrayList v = (ArrayList)comets.get(i);
            String nom = String.valueOf(v.get(1));
            id = v.get(0).toString();
            if (nom.equals(cometName))
            {
                break;
            }
        }
        return id;
    }
    
    public String getAsteroidID(int asteroid)
    {
        switch(asteroid)
        {
            case Planets.Ceres: return "2785";
            case Planets.Pallas: return "5551";
            case Planets.Juno: return "4255";
            case Planets.Vesta: return "6996";
            case Planets.Chiron: return "2853";
            default : return "";
        }
    }
    
    //Calculation of a Comet position
    public Coord calculateComet(Comet comet)
    {
        ArrayList chartEvents = chartElements.getChartEvents();
        ChartEvent evt = (ChartEvent)chartEvents.get(0);
        
        //Comet elements
        double excentricite;
        double perihelie;
        double demi_axe;
        double argument_peri;
        double anomalie_moyenne;
        double anomalie_vraie;
        double anomalie_excentrique;
        double longitude_noeud;
        double inclinaison;
        double periode;
        double moyen_mouvement;
        double mouvement_journalier;
        String date_peri;
        double heure_peri;
        
        //time
        double jj_ref;
        //perihelion date
        double CTime_peri; // As Object
        //date of reference
        double CTime_ref;
        //heure
        double heure;
        
        //COORDONNEES de la COMETE
        //========================
        double argument;
        
        //COORDONNEES DIVERSES
        //====================
        double longitude_geo_soleil;
        double latitude_geo_soleil;
        double distance_terre_soleil;
        double distance;
        
        //VARIABLES DIVERSES
        //==================
        String description_position;
        int lngPos;
        double aux;
        double h;
        double jj;
        double CTime2;
        double rayon_geo;
        
        Coord coord = new Coord();
        //=====================================================================
        
        //LECTURE DES ELEMENTS DE LA COMETE
        //Comet comet = starLoginManager.getComet(cometID);
        
        String nom = comet.getCometName();
        date_peri = comet.getPerihelionDate();
        perihelie = comet.getPerihelionUA();
        excentricite = comet.getEccentricity();
        argument_peri = comet.getPerihelionLongitude();
        longitude_noeud = comet.getNorthNodeLongitude();
        inclinaison = comet.getInclination();
        demi_axe = comet.getSemiMajorAxis() * AstronomyMaths.ASTRONOMICAL_UNIT;
        periode = comet.getPeriod();
        if (comet.getEpoch()==0.0)
        {
            jj_ref = 2415020;
        }
        else
        {
            jj_ref = comet.getEpoch();
        }
        
        if ( demi_axe == 0 )
        {
            demi_axe = perihelie / (1 - excentricite);
        }
        
        //derived elements
        periode = AstronomyMaths.PI * 2.0 * Math.sqrt(demi_axe * demi_axe * demi_axe / AstronomyMaths.HELIO_GRAVITATION_CONSTANT);
        periode = periode / AstronomyMaths.HOUR_PER_CENTURY * 100.0 / 3600.0;
        demi_axe = demi_axe / AstronomyMaths.ASTRONOMICAL_UNIT;
        moyen_mouvement = AstronomyMaths.PI / periode * 2.0;
        
        //date time calculation
        CTime_ref = (jj_ref - 2415020.0) / AstronomyMaths.DAY_PER_CENTURY;
        
        //perihelion date
        heure_peri = 0.0;
        lngPos = date_peri.indexOf(".");
        
        /*if ( lngPos > 0 )
        {
            //determination de l'heure
            heure_peri = new Double(date_peri.substring(date_peri.length() - lngPos + 1)).doubleValue() * 24.0;
            //elimination de la partie heure de l'expression de la date
            date_peri = date_peri.substring(0, lngPos);
        }*/
        ArrayList result = new ArrayList();
        result = getDateFromReversedStringDate(date_peri);
        if (result.size()!=4) return null;
        long j = new Long(result.get(0).toString()).longValue();
        long m = new Long(result.get(1).toString()).longValue();
        long a = new Long(result.get(2).toString()).longValue();
        heure_peri = new Double(result.get(3).toString()).doubleValue();
        CTime_peri = (AstronomyMaths.gregorianToJulian(j, m, a) + heure_peri / 24.0 - jj_ref) / AstronomyMaths.DAY_PER_CENTURY;
        
        //POSITION DU SOLEIL
        Planet p = new Planet(evt, false);
        Coord c = p.getObjPosition(Planets.Sun);
        longitude_geo_soleil = c.getTropicGeoLong();
        latitude_geo_soleil = c.getGeoLat();
        distance_terre_soleil = c.getGeoDist();
        
        //POSITION DE LA COMETE
        //=====================
        //temps seculaire rectif (ie pour le ramener � la date de reference pour le calcul
        //de la position des cometes
        CTime2 = (evt.getCTime() - CTime_ref);
        
        //CALCUL DES ANOMALIES
        //anomalie moyenne
        anomalie_moyenne = moyen_mouvement * (CTime2 - CTime_peri) * AstronomyMaths.HOUR_PER_CENTURY * 3600.0;
        
        //anomalie excentrique
        anomalie_excentrique = anomalie_moyenne;
        aux = anomalie_moyenne + excentricite * Math.sin(anomalie_excentrique);
        
        while (Math.abs(aux - anomalie_excentrique)/anomalie_excentrique > 0.000000000001)
        {
            anomalie_excentrique = aux;
            aux = anomalie_moyenne + excentricite * Math.sin(anomalie_excentrique);
        }
        anomalie_excentrique = anomalie_excentrique * AstronomyMaths.CENT80_SUR_PI;
        
        //anomalie vraie
        if ( anomalie_excentrique == 180.0 )
        {
            anomalie_vraie = 180.0;
        }
        else
        {
            anomalie_vraie = 2 * AstronomyMaths.atnD(Math.sqrt((1.0 + excentricite) / (1.0 - excentricite)) * AstronomyMaths.tanD(anomalie_excentrique / 2.0));
        }
        
        //argument de la comete
        argument = AstronomyMaths.modulo(anomalie_vraie + argument_peri, 360.0);
        
        //COORDONNEES HELIOCENTRIQUES
        //heliocentric latitude
        coord.setHelioLat(AstronomyMaths.asinD(AstronomyMaths.sinD(inclinaison) * AstronomyMaths.sinD(argument)));
        
        //longitude heliocentrique
        if ( Math.abs(argument) == 90.0 )
        {
            aux = 90.0 * AstronomyMaths.sgn(argument);
        }
        else
        {
            aux = AstronomyMaths.atnD(AstronomyMaths.cosD(inclinaison) * AstronomyMaths.tanD(argument)) + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(argument)));
        }
        coord.setTropicHelioLong(longitude_noeud + aux);
        
        //longitude heliocentrique corrigee
        coord.setTropicHelioLong(AstronomyMaths.modulo(coord.correctedHelioLong(evt.getMeanNN()), 360.0));
        
        //DISTANCES
        //distance de la comete au Soleil
        coord.setHelioDist(demi_axe * (1.0 - excentricite * AstronomyMaths.cosD(anomalie_excentrique)));
        
        //distance terre-comete
        coord.setGeoDist(coord.distHelio2Geo(distance_terre_soleil, longitude_geo_soleil));
        
        //POSITION DANS D'AUTRES SYSTEMES DE COORDONNEES
        //conversion eventuelle dans les autres systemes de coordonnees
        coord.setTropicGeoLong(coord.longHelio2Geo(distance_terre_soleil, longitude_geo_soleil));
        coord.setGeoLat(coord.latHelio2Geo());
        coord.setRA(coord.raFromEcliptic(evt.getObliquity()));
        coord.setDecl(coord.declFromEcliptic(evt.getObliquity()));
        coord.setAz(AstronomyMaths.modulo(coord.azFromEquatorial(evt.getPlaceLat(), evt.getLST()), 360.0));
        coord.setAlt(coord.altFromEquatorial(evt.getPlaceLat(), evt.getLST()));
        coord.setSiderGeoLong(coord.getTropicGeoLong() - evt.getAyanamsa());
        coord.setSiderHelioLong(coord.getTropicHelioLong() - evt.getAyanamsa());
        return coord;
    }
    
    //=========================================================================
    //Calculation of an Asteroid position
    //=========================================================================
    public Coord calculateAsteroid(Asteroid asteroid)
    {
        ArrayList chartEvents = chartElements.getChartEvents();
        ChartEvent evt = (ChartEvent)chartEvents.get(0);
        
        //ELEMENTS l'ASTEROiDE
        //====================
        double excentricite;
        double demi_axe;
        double argument_peri;
        double anomalie_moyenne;
        double anomalie_vraie;
        double anomalie_excentrique;
        double longitude_noeud;
        double inclinaison;
        double moyen_mouvement;
        double mouvement_journalier;
        double periode;
        
        //DATES
        //=====
        String date_peri;
        double heure_peri;
        double jj_ref;
        double CTime_peri;
        double CTime_ref;
        
        //COORDONNEES de l'ASTEROiDE
        //==========================
        double argument;
        
        //COORDONNEES DIVERSES
        //====================
        double longitude_geo_soleil;
        double latitude_geo_soleil;
        double distance_terre_soleil;
        double distance;
        
        //VARIABLES DIVERSES
        //==================
        String description_position;
        int lngPos;
        double aux;
        long jour_=0;
        long mois=0;
        long annee=0;
        double h;
        double jj;
        double tps2;
        double rayon_geo;
        
        Coord coord = new Coord();
        //=====================================================================
        
        //LECTURE DES ELEMENTS DE L'ASTEROIDE
        //Asteroid asteroid = starLoginManager.getAsteroid(asteroidID);
        String nom = asteroid.getAsteroidName();
        anomalie_moyenne = asteroid.getMeanAnomaly() * AstronomyMaths.PI_SUR_CENT80;
        excentricite = asteroid.getEccentricity();
        argument_peri = asteroid.getPerihelionLongitude();
        longitude_noeud = asteroid.getNorthNodeLongitude();
        inclinaison = asteroid.getInclination();
        demi_axe = asteroid.getSemiMajorAxis() * AstronomyMaths.ASTRONOMICAL_UNIT;
        mouvement_journalier = asteroid.getDailyMotion();
        jj_ref = asteroid.getEpoch();
        if ( demi_axe == 0.0 )
        {
            //le demi grand axe est calcule � partir du moyen mouvement suivant la relation
            //demi grand axe = (Constante de gravitation * Masse Soleil / moyen mouvement^2)^(1/3)
            //o� moyen mouvement = mouvement journalier * PI_SUR_CENT80 / 24 / 3600
            demi_axe = 148159029927.0 / Math.pow(mouvement_journalier, 2.0 / 3.0);
        }
        
        //ELEMENTS DERIVES
        //================
        periode = AstronomyMaths.PI * Math.sqrt(demi_axe * demi_axe * demi_axe / AstronomyMaths.HELIO_GRAVITATION_CONSTANT) * 2.0;
        demi_axe = demi_axe / AstronomyMaths.ASTRONOMICAL_UNIT;
        moyen_mouvement = AstronomyMaths.PI / periode * 2.0;
        
        //CALCULS DE TEMPS
        //================
        CTime_ref = (jj_ref - 2415020) / AstronomyMaths.DAY_PER_CENTURY;
        
        //POSITION DU SOLEIL
        //=====================================================================
        //calcul de la position du Soleil au temps seculaire
        Planet p = new Planet(evt, false);
        Coord c = p.getObjPosition(Planets.Sun);
        longitude_geo_soleil = c.getTropicGeoLong();
        latitude_geo_soleil = c.getGeoLat();
        distance_terre_soleil = c.getGeoDist();
        
        //POSITION DE L'ASTEROIDE
        //=======================
        //temps seculaire rectif (ie pour le ramener � la date de reference pour le calcul de la position des cometes
        tps2 = (evt.getCTimeH() - CTime_ref);
        
        //CALCUL DES ANOMALIES
        //anomalie moyenne
        anomalie_moyenne = anomalie_moyenne + moyen_mouvement * tps2 * AstronomyMaths.HOUR_PER_CENTURY * 3600.0;
        
        //anomalie excentrique
        anomalie_excentrique = anomalie_moyenne;
        aux = anomalie_moyenne + excentricite * Math.sin(anomalie_excentrique);
        
        while (Math.abs(aux - anomalie_excentrique) > 0.000000000001)
        {
            anomalie_excentrique = aux;
            aux = anomalie_moyenne + excentricite * Math.sin(anomalie_excentrique);
        }
        anomalie_excentrique = anomalie_excentrique * AstronomyMaths.CENT80_SUR_PI;
        
        //anomalie vraie
        if ( anomalie_excentrique == 180.0 )
        {
            anomalie_vraie = 180.0;
        }
        else
        {
            anomalie_vraie = AstronomyMaths.atnD(Math.sqrt((1.0 + excentricite) / (1.0 - excentricite)) * AstronomyMaths.tanD(anomalie_excentrique / 2.0)) * 2.0;
        }
        
        //argument de la comete ou de l'asteroide
        argument = AstronomyMaths.modulo(anomalie_vraie + argument_peri, 360.0);
        
        //COORDONNEES HELIOCENTRIQUES
        //heliocentric latitude
        coord.setHelioLat(AstronomyMaths.asinD(AstronomyMaths.sinD(inclinaison) * AstronomyMaths.sinD(argument)));
        
        //longitude heliocentrique
        
        if ( Math.abs(argument) == 90.0 )
        {
            aux = 90.0 * AstronomyMaths.sgn(argument);
        }
        else
        {
            aux = AstronomyMaths.atnD(AstronomyMaths.cosD(inclinaison) * AstronomyMaths.tanD(argument)) + 90.0 * (1.0 - AstronomyMaths.sgn(AstronomyMaths.cosD(argument)));
        }
        coord.setTropicHelioLong(longitude_noeud + aux);
        
        //longitude heliocentrique corrigee
        coord.setTropicHelioLong(AstronomyMaths.modulo(coord.correctedHelioLong(evt.getMeanNN()), 360.0));
        
        //DISTANCES
        //distance de la comete ou de l'asteroide au Soleil
        coord.setHelioDist(demi_axe * (1.0 - excentricite * AstronomyMaths.cosD(anomalie_excentrique)));
        
        //distance terre-comete
        coord.setGeoDist(coord.distHelio2Geo(distance_terre_soleil, longitude_geo_soleil));
        
        //POSITION DANS D'AUTRES SYSTEMES DE COORDONNEES
        //conversion eventuelle dans les autres systemes de coordonnees
        coord.setTropicGeoLong(coord.longHelio2Geo(distance_terre_soleil, longitude_geo_soleil));
        coord.setGeoLat(coord.latHelio2Geo());
        coord.setRA(coord.raFromEcliptic(evt.getObliquity()));
        coord.setDecl(coord.declFromEcliptic(evt.getObliquity()));
        coord.setAz(AstronomyMaths.modulo(coord.azFromEquatorial(evt.getPlaceLat(), evt.getLST()), 360.0));
        coord.setAlt(coord.altFromEquatorial(evt.getPlaceLat(), evt.getLST()));
        coord.setSiderGeoLong(coord.getTropicGeoLong() - evt.getAyanamsa());
        coord.setSiderHelioLong(coord.getTropicHelioLong() - evt.getAyanamsa());
        return coord;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList getDateFromReversedStringDate(String strS_date)
    {
        ArrayList result = new ArrayList();
        
        strS_date = strS_date.replace(" ", "");
        strS_date = strS_date.replace("-", "/");
        int pos1 = strS_date.indexOf("/");
        int pos2 = strS_date.indexOf("/", pos1+1);
        int pos3 = strS_date.length();
        long j;
        long m;
        Long annee;
        Long mois;
        Long jour;
        
        if (strS_date.length() == 0)
        {
            annee = new Long(0);
            mois = new Long(0);
            jour = new Long(0);
        }
        
        //give the year
        if (pos1 >= 0)
        {
            annee = new Long(strS_date.substring(0, pos1));
        }
        else
        {
            annee = new Long(0);
        }
        
        //give the month
        if (pos2 > pos1)
        {
            m = new Long(strS_date.substring(pos1+1, pos2)).longValue();
            if (m < 1) m = 1;
            if (m > 12) m = 12;
        }
        else
        {
            m = 1;
        }
        mois = new Long(m);
        
        double time = 0.0;
        //give the day
        if (pos3 > pos2 +1)
        {
            double value = new Double(strS_date.substring(pos2+1)).doubleValue();
            time = AstronomyMaths.frac(value) * 24.0;
            j = (long)value;
            if (j < 1) j = 1;
            if (j > 31) j = 31;
        }
        else
        {
            j = 1;
        }
        jour = new Long(j);
        result.add(jour);
        result.add(mois);
        result.add(annee);
        result.add(new Double(time));
        return result;
    }
}
