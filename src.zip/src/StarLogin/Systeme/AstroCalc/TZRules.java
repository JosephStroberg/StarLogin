package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */

public class TZRules
{
    //constants
    public static final byte FirstTime = 0;
    public static final byte SecondTime = 1;
    public static final byte UT2LOCAL = 0;
    public static final byte LOCAL2UT = 1;
    
    //local variables
    private double jj;
    private double jjc;
    private double placeLat;
    private double placeLong;
    private String strRegion;
    private String strCountry;
    private double delta;
    private double dblTimeLag;
    private long y;
    private String strPlace;
    private double time;
    
    //to localize close to a boundary;
    private final double noLatitude = 999.0;
    private final double noLongitude = noLatitude;
    private final byte leftSide = 0;
    private final byte rightSide = 1;
    private final byte uncertain = 2;
    
    public TZRules(DateTimeEvent event)
    {
        strRegion = event.getRegion().toLowerCase();
        strCountry = event.getCountry().toLowerCase();
        strPlace = event.getPlace().toLowerCase();
        FDate fd = new FDate(event.getUtDate());
        long day = fd.getDay();
        long month = fd.getMonth();
        y = fd.getYear();
        jj = AstronomyMaths.gregorianToJulian(day, month, y);
        placeLat = event.getPlaceLat();
        placeLong = event.getPlaceLong();
        time = new FTime(event.getUtTime()).getDecimalHour();
        String sTimeLag = event.getTimeLag();
        if ((sTimeLag == null) || (sTimeLag.equals("")))
        {
            dblTimeLag = 0.0;
        }
        else
        {
            dblTimeLag = new Double(sTimeLag).doubleValue();
        }
    }
    
    public void setTimeLag(double data)
    {
        dblTimeLag = data;
    }
    
    //In which country is a place from a boundary;
    private short boundarySide(int nb_points, double placeLat[], double longitude[], double y, double x)
    {
        short nb_gauche;
        short nb_seg;
        short i;
        double aux;
        double[] seg_lat1 = new double[nb_points];
        double[] seg_long1 = new double[nb_points];
        double[] seg_lat2 = new double[nb_points];
        double[] seg_long2 = new double[nb_points];
        
/*ReDim Preserve placeLat(nb_points - 1);
ReDim Preserve longitude(nb_points - 1);
ReDim seg_lat1(nb_points - 2);
ReDim seg_long1(nb_points - 2);
ReDim seg_lat2(nb_points - 2);
ReDim seg_long2(nb_points - 2)*/
        
        //initialize;
        nb_gauche = 0;
        nb_seg = 0;
        for(i=0; i<=nb_points-2; i++)
        {
            seg_lat1[i] = noLatitude;
            seg_long1[i] = noLongitude;
            seg_lat2[i] = noLatitude;
            seg_long2[i] = noLongitude;
        }
        
        //determining the segments at the considered placeLat;
        for(i=0; i<=nb_points-2; i++)
        {
            if ((placeLat[i] <= y && placeLat[i+1] >= y) || (placeLat[i] >= y && placeLat[i+1] <= y));
            {
                seg_lat1[nb_seg] = placeLat[i];
                seg_long1[nb_seg] = longitude[i];
                seg_lat2[nb_seg] = placeLat[i+1];
                seg_long2[nb_seg] = longitude[i+1];
                nb_seg += 1;
            }
        }
        if (nb_seg < 1)
        {
            return uncertain;
        }
        
        //determining the segments on the left side of the considered point;
        for (i = 0; i <= nb_seg - 1; i++)
        {
            if (seg_lat2[i] == seg_lat1[i])
            {
                if (x <= seg_long1[i] && x <= seg_long2[i]);
                {
                    nb_gauche += 1;
                }
            }
            else
            {
                aux = (seg_long2[i] - seg_long1[i]) / (seg_lat2[i] - seg_lat1[i]);
                if (x <= (y - seg_lat1[i]) * aux + seg_long1[i])
                {
                    
                    //the case when two segments are joinded at the point placeLat is passed;
                    if (i == 0)
                    {
                        if (nb_seg > 1)
                        {
                            if ((seg_lat1[i+1] != seg_lat2[i]) || (seg_long1[i+1] != seg_long2[i]) || (seg_lat1[i+1] != y) || (AstronomyMaths.sgn((y - seg_lat1[i]) * (y - seg_lat2[i+1])) <= 0))
                            {
                                nb_gauche += 1;
                            }
                        }
                        else
                        {
                            nb_gauche += 1;
                        }
                    }
                    else
                    {
                        if ((seg_lat1[i] != seg_lat2[i-1]) || (seg_long1[i] != seg_long2[i-1]) || (seg_lat1[i] != y))
                        {
                            nb_gauche += 1;
                        }
                    }
                }
            }
        }
        
        //if (the number of segments is even, then the point is on the left of the frontier;
        if (nb_gauche - (nb_gauche / 2) * 2 == 0)
        {
            return leftSide;
        }
        else
        {
            return rightSide;
        }
    }
    
    //In which country (Germany or France) is the considered place during the german occupation between 1914 and 1917;
    private short GermanFrenchBoudary1914_1917(double placeLat, double placeLong)
    {
        double l[] =
        {50.75,50.4833333333333,50.1666666666667,50.05,49.9,49.6333333333333,49.4333333333333,49.3833333333333,49.1666666666667,49.05,48.9333333333333,48.8,48.7,48.75,48.7,48.8,49.2166666666667,49.2,48.9,48.8,48.8833333333333,48.6666666666667,48.5833333333333,48.5,48.35,48.25,48.05,47.9166666666667,47.8166666666667,47.6333333333333};
        double lo[] =
        {-0.172222222222222,-0.172222222222222,-0.15,-0.141111111111111,-0.147777777777778,-0.14888888888888,-0.15,-0.155555555555556,-0.152222222222222,-0.167777777777778,-0.188888888888889,-0.204444444444444,-0.248888888888889,-0.28,-0.306666666666667,-0.335555555555556,-0.344444444444444,-0.366666666666667,-0.37,-0.37,-0.4,-0.422222222222222,-0.427777777777778,-0.433333333333333,-0.442222222222222,-0.455555555555556,-0.466666666666667,-0.47,-0.471111111111111,-0.476666666666667};
        return boundarySide(30, l, lo, placeLat, placeLong);
    }
    
    //In which country (Germany or France) is the considered place during the german occupation in 1940;
    private short GermanFrenchBoudary1940(double placeLat, double placeLong)
    {
        double l[] =
        {43.1833333333333,43.1333333333333,43.3333333333333,43.4,43.4333333333333,43.4833333333333,43.65,43.75,43.8666666666667,44.0333333333333,44.1333333333333,44.3,44.4333333333333,44.5666666666667,44.7,44.7833333333333,44.85,45.0,45.2333333333333,45.45,45.7333333333333,45.8,45.9,46.1333333333333,46.2833333333333,46.5833333333333,46.75,47.05,47.1333333333333,47.3,47.2666666666667,47.2333333333333,47.25,47.2333333333333,47.2,47.0833333333333,47.0333333333333,47.0,46.9166666666667,46.8833333333333,46.8333333333333,46.5666666666667,45.4833333333333,45.4,46.6333333333333,46.6833333333333,46.7166666666667,46.7833333333333,46.8833333333333,46.9666666666667,46.9833333333333,46.9,46.8333333333333,46.9333333333333,46.7166666666667,46.5666666666667,46.5166666666667,46.51667,46.1,46.05,55.0};
        double lo[] =
        {0.0888888888888889,0.08,0.0677777777777778,0.0622222222222222,0.0588888888888889,0.0511111111111111,0.0388888888888889,0.0355555555555556,0.0311111111111111,0.02,0.0166666666666667,0.0144444444444444,0.0133333333333333,0.0122222222222222,0.00222222222222222,0.00222222222222222,-0.00666666666666667,-0.0133333333333333,-0.0244444444444444,-0.0288888888888889,-0.0277777777777777,-0.0288888888888889,-0.0266666666666667,-0.0311111111111111,-0.344444444444444,-0.0433333333333333,-0.05,-0.0566666666666667,-0.0544444444444444,-0.07,-0.0911111111111111,-0.103333333333333,-0.108888888888889,-0.123333333333333,-0.134444444444444,-0.142222222222222,-0.158888888888889,-0.172222222222222,-0.194444444444444,-0.202222222222222,-0.197777777777778,-0.22,-0.223333333333333,-0.274444444444444,-0.293333333333333,-0.294444444444444,-0.301111111111111,-0.323333333333333,-0.334444444444444,-0.361111111111111,-0.373333333333333,-0.384444444444444,-0.38,-0.38001,-0.392222222222222,-0.396666666666667,-0.401111111111111,-0.368888888888889,-0.387777777777778,-0.38778,-1.0};
        return boundarySide(61, l, lo, placeLat, placeLong);
    }
    
    //In which country (Germany or France) is the considered place during the german occupation;
    private short GermanFrenchBoudary1918(double placeLat , double placeLong)
    {
        double l[] =
        {47.55,47.6333333333333,47.6666666666667,47.8166666666667,47.95,48.0333333333333,48.1666666666667,48.25,48.2666666666667,48.35,48.45,48.5166666666667,48.6166666666667,48.6666666666667,48.7666666666667,48.8166666666667,48.8833333333333,49,49.1166666666667,49.25,49.3333333333333,49.3666666666667,49.45};
        double lo[] =
        {-0.474444444444444,-0.468888888888889,-0.47,-0.457777777777778,-0.462222222222222,-0.467777777777778,-0.472222222222222,-0.476666666666667,-0.477777777777778,-0.473333333333333,-0.467777777777778,-0.466666666666667,-0.464444444444444,-0.455555555555556,-0.434444444444444,-0.426666666666667,-0.413333333333333,-0.4,-0.422222222222222,-0.403333333333333,-0.4,-0.396666666666667,-0.393333333333333};
        return boundarySide(23, l, lo, placeLat, placeLong);
    }
    
    //Calculation of the "Muslim local hour - local hour" time-lag from the Muslim local hour;
    public double muslimLocalTime2Lag(double placeLong)
    {
        double setTime;
        double localTime;
        double muslimLocalTime;
        double riseTime;
        double timeLag;
        String sRisePosition="";
        String sSetTime="";
        String sRiseTime="";
        String sCrossMeridianTime="";
        String sSetPosition="";
         /*Dim AllC As New AllCoords();
         Dim ev As New SEvent();
         MainClass.ev.Init();
          
         //calculation of the Sun rise and set hours for the considered place;
         timeLag = LeverCoucherAstre(astrologie.ePlanets.SOLEIL, AllC, ev, sCrossMeridianTime, sRiseTime, sSetTime, sRisePosition, sSetPosition, Coords.Syst.TROPICALES, True);
          */
        FTime rt = new FTime(sRiseTime);
        riseTime = rt.getDecimalHour() - placeLong/15;
        FTime st = new FTime(sSetTime);
        setTime = st.getDecimalHour() - placeLong/15;
        
        //numerical value of the Muslim local hour;
        muslimLocalTime = time;
        
        //numerical value of the local hour;
        if (muslimLocalTime < 12)
        {
            localTime = AstronomyMaths.modulo(AstronomyMaths.modulo(riseTime - setTime, 24) / 12 * muslimLocalTime + setTime, 24);
        }
        else
        {
            localTime = AstronomyMaths.modulo((setTime - riseTime) / 12 * (muslimLocalTime - 12) + riseTime, 24);
        }
        
        //time-lag between local time and Muslim local time;
        return muslimLocalTime - localTime;
    }
    
    //Calculation of the "local hour - Muslim local hour" time-lag, from the local hour;
    public double localTime2MuslimLag(double placeLong)
    {
        double setTime;
        double localTime;
        double muslimLocalTime;
        double riseTime;
        double timeLag;
        String sRisePosition="";
        String sSetTime="";
        String sRiseTime="";
        String sCrossMeridianTime="";
        String sSetPosition="";
         /*Dim AllC As New AllCoords();
         Dim ev As New SEvent();
         MainClass.ev.Init();
          
         //calculation of the Sun rise and set hours for the considered place;
         timeLag = LeverCoucherAstre(astrologie.ePlanets.SOLEIL, AllC, ev, sCrossMeridianTime, sRiseTime, sSetTime, sRisePosition, sSetPosition, Coords.Syst.TROPICALES, True);
          */
        FTime rt = new FTime(sRiseTime);
        riseTime = rt.getDecimalHour() - placeLong/15;
        FTime st = new FTime(sSetTime);
        setTime = st.getDecimalHour() - placeLong/15;
        
        //numerical value of the local hour;
        localTime = AstronomyMaths.modulo(time - placeLong / 15, 24);
        
        //numerical value of the Muslim local hour;
        if ((localTime < riseTime) || (localTime > setTime))
        {
            muslimLocalTime = AstronomyMaths.modulo(AstronomyMaths.modulo(localTime - setTime, 24) / AstronomyMaths.modulo(riseTime - setTime, 24) * 12, 24);
        }
        else
        {
            muslimLocalTime = AstronomyMaths.modulo((localTime - riseTime) / (setTime - riseTime) * 12 + 12, 24);
        }
        
        //time-lag between local hour et Muslim local hour;
        return localTime - muslimLocalTime;
    }
    
    //Calculation of the Julian Day for the first day having a given name, in the considered month ;
    public double julianDate4DayMonth(long firstDay, long mois, long year, int nDegDay)
    {
        double jjAux = AstronomyMaths.gregorianToJulian(firstDay, mois, year);
        long n = (long)AstronomyMaths.modulo(jjAux + 1.5 - nDegDay, 7);
        return jjAux + AstronomyMaths.modulo(7 - n, 7);
    }
    
    private void deltaAfriqueSud()
    {
        //Natal province;
        if (strRegion.indexOf("natal") >= 0)
        {
            if (jjc >= 2412136.5 && jjc < 2413072.5)
            {
                dblTimeLag = -2.06666666666667;
            }
            else if (jjc >= 2413072.5)
            {
                dblTimeLag = -2;
            }
        }
        
        //other provinces (Transvaal, Le Cap, Orange);
        else
        {
            if (jjc >= 2412136.5 && jjc < 2416174.5)
            {
                dblTimeLag = -1.5;
            }
            else if (jjc >= 2416174.5)
            {
                dblTimeLag = -2;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2430622.58333333 && jjc < 2430804.58333333) || (jjc >= 2430986.58333333 && jjc < 2431168.58333333))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaAlgerie()
    {
        if (jjc >= 2411806.5 && jjc < 2419106.5)
        {
            //longitude of Paris;
            dblTimeLag = -0.155555555555556;
        }
        else if ((jjc >= 2419106.5 && jjc < 2429684.58333333) || (jjc >= 2432100.5 && jjc < 2435501.5) || (jjc >= 2438133.5 && jjc < 2443438.45833333) || (jjc >= 2444173.45833333 && jjc < 2444725.5))
        {
            dblTimeLag = 0;
        }
        else if ((jjc >= 2429684.58333333 && jjc < 2432100.5) || (jjc >= 2435501.5 && jjc < 2438133.5) || (jjc >= 2443438.45833333 && jjc < 2444173.45833333) || (jjc >= 2444725.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421029.45833333 && jjc < 2421138.5) || (jjc >= 2421312.45833333 && jjc < 2421509.5) || (jjc >= 2421662.45833333 && jjc < 2421873.5) || (jjc >= 2422019.45833333 && jjc < 2422237.5) || (jjc >= 2422369.45833333 && jjc < 2422621.5) || (jjc >= 2422763.45833333 && jjc < 2422862.5) || (jjc >= 2429518.45833333 && jjc < 2429586.5) || (jjc >= 2431714.58333333 && jjc < 2432100.58333333) || (jjc >= 2441067.45833333 && jjc < 2441221.5) || (jjc >= 2443270.45833333 && jjc < 2443438.5))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2431182.58333333 && jjc < 2431371.58333333) || (jjc >= 2431547.58333333 && jjc < 2431714.58333333))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaAllemagneEst()
    {
        //(simplification)
        if (jjc < 2431456.5)
        {
            deltaAllemagneOuest();
        }
        else if (jjc >= 2412554.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2431547.58333333 && jjc < 2431599.58333333) || (jjc >= 2431722.625 && jjc < 2431777.58333333) || (jjc >= 2431924.58333333 && jjc < 2432100.58333333) || (jjc >= 2432281.58333333 && jjc < 2432316.58333333) || (jjc >= 2432365.625 && jjc < 2432463.58333333) || (jjc >= 2432659.625 && jjc < 2432827.58333333) || (jjc >= 2433016.625 && jjc < 2433191.58333333) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((jjc >= 2431599.58333333 && jjc < 2431722.625) || (jjc >= 2432316.58333333 && jjc < 2432365.625))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1981 && y<=1990) && ((jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24)))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && ((jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24)))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaAngleterre()
    {
        //if (((strPlace.indexOf("�cosse") >= 0 || strPlace.indexOf("ecosse") >= 0 || strPlace.indexOf("scotland") >= 0scotland", 1) > 0) && (jjc >= 2409204.5 || jjc >= 2421004.58333333)) || (jjc >= 2407716.0))
        if (((strPlace.indexOf("�cosse") >= 0 || strPlace.indexOf("ecosse") >= 0 || strPlace.indexOf("scotland") >= 0) && (jjc >= 2409204.5)) || (jjc >= 2407716.0))
        {
            dblTimeLag = 0;
        }
        
        //daylight-saving time (simplification);
        if ((jjc >= 2421004.58333333 && jjc < 2421137.625) || (jjc >= 2421326.58333333 && jjc < 2421488.625) || (jjc >= 2421676.58333333 && jjc < 2421866.625) || (jjc >= 2422047.58333333 && jjc < 2422230.625) || (jjc >= 2422411.58333333 && jjc < 2422622.625) || (jjc >= 2422782.58333333 && jjc < 2422965.625) || (jjc >= 2423139.58333333 && jjc < 2423335.625) || (jjc >= 2423531.58333333 && jjc < 2423678.625) || (jjc >= 2423895.58333333 && jjc < 2424049.625) || (jjc >= 2429369.58333333 && jjc < 2429586.625) || (jjc >= 2429684.58333333 && jjc < 2431735.58333333) || (jjc >= 2431924.58333333 && jjc < 2432099.625) || (jjc >= 2432260.58333333 && jjc < 2432288.58333333) || (jjc >= 2432407.58333333 && jjc < 2432491.58333333) || (jjc >= 2432624.58333333 && jjc < 2432855.625) || (jjc >= 2433009.58333333 && jjc < 2433219.625) || (jjc >= 2439904.58333333 && jjc < 2441255.625))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2430118.58333333 && jjc < 2430216.625) || (jjc >= 2430454.58333333 && jjc < 2430580.625) || (jjc >= 2430818.58333333 && jjc < 2430951.625) || (jjc >= 2431182.58333333 && jjc < 2431350.625) || (jjc >= 2431547.58333333 && jjc < 2431651.625) || (jjc >= 2432288.58333333 && jjc < 2432407.625))
        {
            dblTimeLag = -2;
        }
        else if (y>= 1925 && y <= 1938)
        {
            if ((y == 1927 || y == 1930 || y == 1933 || y == 1938) && (jjc >= julianDate4DayMonth(8, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(2, 10, y, 0) + 3 / 24))
            {
                dblTimeLag = -1;
            }
            else if (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(2, 10, y, 0) + 3 / 24)
            {
                dblTimeLag = -1;
            }
        }
        else if ((y>= 1950 && y <= 1952) && (jjc >= julianDate4DayMonth(14, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(21, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
        else if (y>= 1953 && y <= 1960)
        {
            if ((y == 1954 || y == 1957 || y == 1960) && (jjc >= julianDate4DayMonth(8, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 3 / 24))
            {
                dblTimeLag = -1;
            }
            else if (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 3 / 24)
            {
                dblTimeLag = -1;
            }
        }
        else if ((y>= 1961 && y <= 1963) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(23, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
        
        else if ((y>= 1964 && y <= 1980) && (y < 1968 || y > 1972) && (jjc >= julianDate4DayMonth(16, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(23, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(23, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -1;
        }
    }
    
    private void deltaBelgique()
    {
        if ((jjc >= 2407715.5 && jjc < 2412220.0))
        {
            dblTimeLag = -0.29;
        }
        else if ((jjc >= 2412220.0 && jjc < 2420367.5) || (jjc >= 2421852.5 && jjc < 2429684.58333333))
        {
            dblTimeLag = 0;
        }
        else if ((jjc >= 2420367.5 && jjc < 2421852.5) || (jjc >= 2429684.58333333))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421137.54166667) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2421698.58333333 && jjc < 2421852.625) || (jjc >= 2429769.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431350.625) || (jjc >= 2431547.58333333 && jjc < 2431714.625) || (jjc >= 2443236.58333333 && jjc < 2443411.625) || (jjc >= 2443600.58333333 && jjc < 2443782.625) || (jjc >= 2443964.58333333 && jjc < 2444146.625))
        {
            dblTimeLag = -2;
        }
        else if ((jjc >= 2422019.45833333 && jjc < 2422236.5) || (jjc >= 2422369.45833333 && jjc < 2422621.5) || (jjc >= 2422763.45833333 && jjc < 2422988.5) || (jjc >= 2423139.45833333 && jjc < 2423335.5) || (jjc >= 2423531.45833333 && jjc < 2423699.5) || (jjc >= 2423874.45833333 && jjc < 2424063.5) || (jjc >= 2424245.45833333 && jjc < 2424427.5) || (jjc >= 2424623.45833333 && jjc < 2424791.5) || (jjc >= 2424980.45833333 && jjc < 2425155.5) || (jjc >= 2425351.45833333 && jjc < 2425526.625) || (jjc >= 2425722.58333333 && jjc < 2425890.625) || (jjc >= 2426079.58333333 && jjc < 2426254.625) || (jjc >= 2426450.58333333 && jjc < 2426618.625) || (jjc >= 2426830.58333333 && jjc < 2426982.625) || (jjc >= 2427157.58333333 && jjc < 2427353.625) || (jjc >= 2427535.58333333 && jjc < 2427717.625) || (jjc >= 2427892.58333333 && jjc < 2428081.625) || (jjc >= 2428277.58333333 && jjc < 2428445.625) || (jjc >= 2428627.58333333 && jjc < 2428809.625) || (jjc >= 2429015.58333333 && jjc < 2429173.625) || (jjc >= 2429369.58333333 && jjc < 2429586.625))
        {
            dblTimeLag = -1;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaDanemark()
    {
        if ((jjc >= 2412829.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420998.45833333 && jjc < 2421137.5) || (jjc >= 2429764.5 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431682.625) || (jjc >= 2431941.58333333 && jjc < 2432064.625) || (jjc >= 2432309.58333333 && jjc < 2432407.625) || (jjc >= 2432680.58333333 && jjc < 2432771.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaIrak(byte sens, short i)
    {
        if (jjc < 2411368.5)
        {
            if (sens == UT2LOCAL)
            {
                if (i == 0)
                {
                    dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                }
            }
            else
            {
                if (i == 0)
                {
                    dblTimeLag -= muslimLocalTime2Lag(placeLong);
                }
            }
        }
        else if (jjc < 2421594.5)
        {
            dblTimeLag = -2.96222222222222;
        }
        else
        {
            dblTimeLag = -3;
        }
        
        //daylight-saving time
        if ((jjc >= 2445090.5 && jjc < 2445243.5) || (jjc >= 2445424.5 && jjc < 2445608.5))
        {
            dblTimeLag = -4;
        }
        else if ((y>= 1984) && (jjc >= AstronomyMaths.gregorianToJulian(1, 4, y) && jjc < AstronomyMaths.gregorianToJulian(1, 10, y)))
        {
            dblTimeLag = -4;
        }
    }
    
    private void deltaIran(byte sens, short i)
    {
        if (jjc < 2420863.5)
        {
            if (sens == UT2LOCAL)
            {
                if (i == 0)
                {
                    dblTimeLag = localTime2MuslimLag(placeLong);//+ dblTimeLag;
                }
            }
            else
            {
                if (i == 0)
                {
                    dblTimeLag = -muslimLocalTime2Lag(placeLong);
                }
            }
        }
        else if (jjc < 2431821.5)
        {
            dblTimeLag = -3.42888888888889;
        }
        else if ((jjc < 2443448.5) || (jjc >= 2443874.5))
        {
            dblTimeLag = -3.5;
        }
        else
        {
            dblTimeLag = -4;
        }
        
        //daylight-saving time
        if (jjc >= 2443588.5 && jjc < 2443802.5)
        {
            dblTimeLag = -5;
        }
        else if ((jjc >= 2443953.5 && jjc < 2444135.5) || (jjc >= 2444319.5 && jjc < 2444505.5))
        {
            dblTimeLag = -4.5;
        }
    }
    
    private void deltaIrlande()
    {
        //(simplification)
        if ((jjc >= 2407715.5 && jjc < 2421004.58333333))
        {
            dblTimeLag = 0.416666666666667;
        }
        else if ((jjc >= 2421004.58333333 && jjc < 2421137.5))
        {
            dblTimeLag = -0.583333333333333;
        }
        else if ((jjc >= 2421137.5 && jjc < 2439904.5) || (jjc >= 2441255.5))
        {
            dblTimeLag = 0;
        }
        else if ((jjc >= 2439904.5 && jjc < 2441255.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421326.58333333 && jjc < 2421488.625) || (jjc >= 2421676.58333333 && jjc < 2421866.625) || (jjc >= 2422047.58333333 && jjc < 2422230.625) || (jjc >= 2422411.58333333 && jjc < 2422622.625) || (jjc >= 2422782.58333333 && jjc < 2422965.625) || (jjc >= 2423139.58333333 && jjc < 2423335.625) || (jjc >= 2423531.58333333 && jjc < 2423678.625) || (jjc >= 2423888.58333333 && jjc < 2424049.625) || (jjc >= 2429369.58333333 && jjc < 2429586.625) || (jjc >= 2429684.58333333 && jjc < 2432099.625) || (jjc >= 2432260.58333333 && jjc < 2432491.625) || (jjc >= 2432659.58333333 && jjc < 2432855.625) || (jjc >= 2433009.58333333 && jjc < 2433219.625) || (jjc >= 2438476.58333333 && jjc < 2438693.625))
        {
            dblTimeLag = -1;
        }
        else if (y>= 1925 && y <= 1938)
        {
            if (y == 1927 || y == 1928 || y == 1930 || (y >= 1933 && y <= 1935) || y == 1938)
            {
                if ((y == 1928 || y == 1934) && (jjc >= AstronomyMaths.gregorianToJulian(22, 4, y) + 2 / 24 && jjc < AstronomyMaths.gregorianToJulian(7, 10, y) + 3 / 24))
                {
                    dblTimeLag = -1;
                }
                else if (jjc >= julianDate4DayMonth(8, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 6) + 1 + 3 / 24)
                {
                    dblTimeLag = -1;
                }
            }
            else if (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 6) + 1 + 3 / 24)
            {
                dblTimeLag = -1;
            }
        }
        else if ((y>= 1950 && y <= 1952) && (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(21, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
        else if (y>= 1953 && y <= 1960)
        {
            if ((y == 1954 || y == 1957 || y == 1960) && (jjc >= julianDate4DayMonth(8, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 3 / 24))
            {
                dblTimeLag = -1;
            }
            else if (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 3 / 24)
            {
                dblTimeLag = -1;
            }
        }
        else if ((y>= 1961 && y <= 1963) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
        else if ((y>= 1965 && y <= 1980) && ((y < 1968 || y > 1971) && ((jjc >= julianDate4DayMonth(15, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(22, 10, y, 6) + 1 + 3 / 24))))
        {
            dblTimeLag = -1;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(22, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -1;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -1;
        }
    }
    
    private void deltaEgypte()
    {
        if (jjc >= 2415293.5)
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2429825.5 && jjc < 2429903.5) || (jjc >= 2430099.5 && jjc < 2430253.5) || (jjc >= 2430450.5 && jjc < 2430659.5) || (jjc >= 2430815.5 && jjc < 2431029.5) || (jjc >= 2431561.5 && jjc < 2431760.5) || (jjc >= 2435968.5 && jjc < 2436112.5) || (jjc >= 2436324.5 && jjc < 2436477.5))
        {
            dblTimeLag = -3;
        }
        else if ((y>= 1959 && y <= 1965) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) + 1 / 24 && jjc < AstronomyMaths.gregorianToJulian(30, 9, y) + 3 / 24))
        {
            dblTimeLag = -3;
        }
        else if ((y>= 1967 && y <= 1985) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) + 1 / 24 && jjc < AstronomyMaths.gregorianToJulian(1, 10, y) + 3 / 24))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaEspagne()
    {
        //(simplification)
        if ((jjc >= 2415385.5 && jjc < 2429704.5))
        {
            dblTimeLag = 0;
        }
        else if (jjc >= 2429704.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421699.45833333 && jjc < 2421873.5) || (jjc >= 2422055.5 && jjc < 2422238.5) || (jjc >= 2423892.45833333 && jjc < 2424063.5) || (jjc >= 2424623.45833333 && jjc < 2424791.5) || (jjc >= 2424980.45833333 && jjc < 2425155.5) || (jjc >= 2425351.45833333 && jjc < 2425526.5) || (jjc >= 2425722.45833333 && jjc < 2425891.5) || (jjc >= 2428676.45833333 && jjc < 2428809.5) || (jjc >= 2428934.45833333 && jjc < 2429173.5) || (jjc >= 2429369.45833333 && jjc < 2429544.5) || (jjc >= 2433037.45833333 && jjc < 2433191.54166667) || (jjc >= 2442864.45833333 && jjc < 2443047.5) || (jjc >= 2443235.45833333 && jjc < 2443411.54166667))
        {
            dblTimeLag = - 1;
        }
        
        //Republican zone (simplified frontier)
        if ((dblTimeLag < 0.466666666666667 && placeLat > 43 && strPlace.indexOf("oviedo") < 0) || (dblTimeLag < 0.366666666666667 && placeLat < 4.75 && strPlace.indexOf("grenade") < 0 && strPlace.indexOf("teruel") < 0) || dblTimeLag < 0.04)
        {
            if ((jjc >= 2429019.45833333 && jjc < 2429174.5))
            {
                dblTimeLag = -2;
            }
            else if ((jjc >= 2429174.45833333 && jjc < 2429351.5))
            {
                dblTimeLag = -1;
            }
            else if ((jjc >= 2429351.45833333 && jjc < 2429369.5))
            {
                dblTimeLag = 0;
            }
        }
        
        //whole
        else if ((y>= 1943 && y <= 1944) && (jjc >= julianDate4DayMonth(15, 4, y, 6) + 23 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0)))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1945 && y <= 1946) && (jjc >= julianDate4DayMonth(8, 4, y, 6) + 23 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0)))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1974 && y <= 1975) && (jjc >= julianDate4DayMonth(8, 4, y, 6) + 23 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0)))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1978 && y <= 1980) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaGhana()
    {
        if (jjc >= 2421594.5)
        {
            dblTimeLag = 0;
        }
        
        //daylight-saving time
        else if ((y>= 1932 && y <= 1944) && (jjc >= AstronomyMaths.gregorianToJulian(1, 9, y) && jjc < AstronomyMaths.gregorianToJulian(31, 12, y)))
        {
            dblTimeLag = -0.333333333333333;
        }
        else if ((y>= 1945 && y <= 1951) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) && jjc < AstronomyMaths.gregorianToJulian(31, 12, y)))
        {
            dblTimeLag = -1;
        }
        else if ((y>= 1952 && y <= 1957) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) && jjc < AstronomyMaths.gregorianToJulian(31, 12, y)))
        {
            dblTimeLag = -0.5;
        }
    }
    
    private void deltaGuyana()
    {
        if (jjc >= 2409176.5 && jjc < 2419218.5)
        {
            //meridian of Georgetown;
            dblTimeLag = 3.87777777777778;
        }
        else if (jjc >= 2419218.5 && jjc < 2432551.5)
        {
            dblTimeLag = 4;
        }
        else if (jjc >= 2432551.5 && jjc < 2442624.5)
        {
            dblTimeLag = 3.75;
        }
        else if (jjc >= 2442624.5)
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaGrece()
    {
        if ((jjc >= 2413450.5 && jjc < 2421072.5))
        {
            dblTimeLag = -1.58222222222222;
        }
        else if ((jjc >= 2421072.5 && jjc < 2430114.5))
        {
            dblTimeLag = -2;
        }
        else if (jjc >= 2430114.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2426450.5 && jjc < 2426618.5) || (jjc >= 2426894.5 && jjc < 2426951.5) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431365.625 && jjc < 2431395.5) || (jjc >= 2434194.5 && jjc < 2434317.5) || (jjc >= 2442515.5 && jjc < 2442711.5) || (jjc >= 2442879.5 && jjc < 2443001.5) || (jjc >= 2443236.58333333 && jjc < 2443411.625) || (jjc >= 2443600.58333333 && jjc < 2443782.625) || (jjc >= 2443964.58333333 && jjc < 2444135.625) || (jjc >= 2444335.58333333 && jjc < 2444509.625))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaIslande()
    {
        if ((jjc >= 2392010.5 && jjc < 2417941.5))
        {
            dblTimeLag = 1.46444444444444;
        }
        else if ((jjc >= 2417941.5 && jjc < 2439953.58333333))
        {
            dblTimeLag = 1;
        }
        else if (jjc >= 2439953.58333333)
        {
            dblTimeLag = 0;
        }
        
        //daylight-saving time
        if ((jjc >= 2421279.58333333 && jjc < 2421526.58333333) || (jjc >= 2421644.58333333 && jjc < 2421912.58333333) || (jjc >= 2422008.58333333 && jjc < 2422277.58333333) || (jjc >= 2430055.58333333 && jjc < 2430177.58333333) || (jjc >= 2430426.58333333 && jjc < 2430542.58333333))
        {
            dblTimeLag = 0;
        }
        else if ((y>= 1943 && y <= 1946) && (jjc >= julianDate4DayMonth(1, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(22, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1947 && y <= 1967) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(22, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaIsra�l()
    {
        if (jjc >= 2421229.5)
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2429684.58333333 && jjc < 2430724.58333333) || (jjc >= 2432795.5 && jjc < 2432856.5) || (jjc >= 2433037.5 && jjc < 2433221.5) || (jjc >= 2433372.5 && jjc < 2433525.5) || (jjc >= 2433737.5 && jjc < 2433919.5) || (jjc >= 2434122.5 && jjc < 2434283.5) || (jjc >= 2434479.5 && jjc < 2434633.5) || (jjc >= 2434906.5 && jjc < 2434997.5) || (jjc >= 2435270.5 && jjc < 2435361.5) || (jjc >= 2435627.5 && jjc < 2435746.5) || (jjc >= 2435956.5 && jjc < 2436103.5) || (jjc >= 2442235.5 && jjc < 2442333.5) || (jjc >= 2442579.5 && jjc < 2442670.5) || (jjc >= 2445826.5 && jjc < 2446001.5) || (jjc >= 2446190.5 && jjc < 2446365.5) || (jjc >= 2446533.5 && jjc < 2446729.5))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(24, 4, y, 0) && jjc < julianDate4DayMonth(25, 10, y, 0)))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaItalie()
    {
        if ((jjc >= 2402866.5 && jjc < 2422690.5))
        {
            if ( (strPlace.indexOf("sicile") >= 0) || (strPlace.indexOf("sicily") >= 0))
            {
                dblTimeLag = -0.892222222222222;
            }
            else if ((strPlace.indexOf("sardaigne") >= 0) || (strPlace.indexOf("sardain") >= 0))
            {
                dblTimeLag = -0.608888888888889;
            }
            else
            {
                dblTimeLag = -0.833333333333333;
            }
        }
        else if (jjc >= 2422690.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421018.5 && jjc < 2421137.5) || (jjc >= 2421319.5 && jjc < 2421501.5) || (jjc >= 2421662.5 && jjc < 2421872.5) || (jjc >= 2422019.5 && jjc < 2422236.5) || (jjc >= 2422404.5 && jjc < 2422586.5) || (jjc >= 2429795.5 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431715.5) || (jjc >= 2431896.58333333 && jjc < 2432099.625) || (jjc >= 2432260.58333333 && jjc < 2432463.625) || (jjc >= 2432610.58333333 && jjc < 2432827.625) || (jjc >= 2440373.5 && jjc < 2440492.5) || (jjc >= 2440737.5 && jjc < 2440856.5) || (jjc >= 2441836.5 && jjc < 2441955.54166667) || (jjc >= 2442564.5 && jjc < 2442683.54166667) || (jjc >= 2442928.5 && jjc < 2443047.54166667) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1966 && y <= 1968) && (jjc >= julianDate4DayMonth(22, 5, y, 0) && jjc < julianDate4DayMonth(22, 9, y, 0)))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1971 && y <= 1979) && ((y != 1973 && y != 1975 && y != 1976)&& (jjc >= julianDate4DayMonth(22, 5, y, 0) && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 1 / 24)))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaNiger()
    {
        if (jjc >= 2419402.5 && jjc < 2427494.5)
        {
            //East part (estimation);
            if (dblTimeLag < -0.75)
            {
                dblTimeLag = -1;
            }
            
            //West part (estimation)
            else if (dblTimeLag > -0.35)
            {
                dblTimeLag = 1;
            }
            
            //Central part (estimation);
            else
            {
                dblTimeLag = 0;
            }
        }
        else if (jjc >= 2427494.5 && jjc < 2436934.5)
        {
            if (dblTimeLag <= -0.35)
            {
                dblTimeLag = 0;
            }
            else
            {
                dblTimeLag = 1;
            }
        }
        else if ((jjc >= 2436934.5) && ((strRegion.indexOf("agadez") >= 0) || (strRegion.indexOf("bilmo") >= 0) || (strRegion.indexOf("zinder") >= 0) || (strRegion.indexOf("madama") >= 0) || (strRegion.indexOf("niguigmi") >= 0)))
        {
            dblTimeLag = 1;
        }
    }
    
    private void deltaNorvege()
    {
        if ((jjc >= 2413314.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421005.45833333 && jjc < 2421137.54166667) || (jjc >= 2429852.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431729.625) || (jjc >= 2438875.58333333 && jjc < 2439022.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1959 && y <= 1964) && (jjc >= julianDate4DayMonth(15, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(15, 9, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaPaysBas()
    {
        //(simplification)
        if ((jjc >= 2418429.5 && jjc < 2428715.5))
        {
            dblTimeLag = -0.293333333333333;
        }
        else if ((jjc >= 2428715.5 && jjc < 2429766.5))
        {
            dblTimeLag = -0.333333333333333;
        }
        else if (jjc >= 2429766.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.58333333 && jjc < 2421138.625) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2423170.58333333 && jjc < 2423335.625) || (jjc >= 2423571.58333333 && jjc < 2423699.625) || (jjc >= 2423874.58333333 && jjc < 2424063.625) || (jjc >= 2424306.58333333 && jjc < 2424427.625) || (jjc >= 2426849.58333333 && jjc < 2426982.625) || (jjc >= 2428675.58333333 && jjc < 2428809.625) || (jjc >= 2429765.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431714.625) || (jjc >= 2443236.58333333 && jjc < 2443411.625) || (jjc >= 2443600.58333333 && jjc < 2443782.625) || (jjc >= 2443964.58333333 && jjc < 2444146.625) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1918 && y <= 1921) && (jjc >= julianDate4DayMonth(1, 4, y, 1) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 1) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1926 && y <= 1939) && (y != 1932 && y != 1937) && (jjc >= AstronomyMaths.gregorianToJulian(15, 3, y) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaPortugal()
    {
        if ((jjc >= 2409176.5 && jjc < 2419402.5))
        {
            dblTimeLag = 0.608888888888889;
        }
        else if (jjc >= 2419402.5)
        {
            dblTimeLag = 0;
        }
        
        //daylight-saving time
        if ((jjc >= 2421032.45833333 && jjc < 2421168.54166667) || (jjc >= 2421654.45833333 && jjc < 2421881.5) || (jjc >= 2422384.45833333 && jjc < 2422612.5) || (jjc >= 2423892.45833333 && jjc < 2424063.5) || (jjc >= 2424623.45833333 && jjc < 2424791.5) || (jjc >= 2425351.45833333 && jjc < 2425526.5) || (jjc >= 2425722.45833333 && jjc < 2425890.5) || (jjc >= 2426450.45833333 && jjc < 2426618.5) || (jjc >= 2426800.45833333 && jjc < 2426982.5) || (jjc >= 2427535.45833333 && jjc < 2427717.5) || (jjc >= 2427892.45833333 && jjc < 2428081.5) || (jjc >= 2428277.45833333 && jjc < 2428445.5) || (jjc >= 2428627.45833333 && jjc < 2428809.5) || (jjc >= 2429015.45833333 && jjc < 2429173.5) || (jjc >= 2429369.45833333 && jjc < 2429586.5) || (jjc >= 2429684.45833333 && jjc < 2429952.5) || (jjc >= 2430090.45833333 && jjc < 2430273.5) || (jjc >= 2430433.45833333 && jjc < 2430475.5))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2430600.45833333 && jjc < 2430663.5) || (jjc >= 2430797.45833333 && jjc < 2430832.5) || (jjc >= 2430965.45833333 && jjc < 2431028.5) || (jjc >= 2431161.45833333 && jjc < 2431203.5) || (jjc >= 2431329.45833333 && jjc < 2431392.5) || (jjc >= 2431525.45833333 && jjc < 2431567.5) || (jjc >= 2431693.45833333 && jjc < 2431756.5) || (jjc >= 2431917.45833333 && jjc < 2432099.5) || (jjc >= 2439218.58333333 && jjc < 2443047.54166667) || (jjc >= 2443229.5 && jjc < 2443411.54166667) || (jjc >= 2443600.54166667 && jjc < 2443782.58333333) || (jjc >= 2443964.54166667 && jjc < 2444146.58333333) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2430475.45833333 && jjc < 2430600.5) || (jjc >= 2430832.45833333 && jjc < 2430965.5) || (jjc >= 2431203.45833333 && jjc < 2431329.5) || (jjc >= 2431567.45833333 && jjc < 2431693.5))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1947 && y <= 1965) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaSuede()
    {
        if ((jjc >= 24073135.5 && jjc < 2415020.54166667))
        {
            dblTimeLag = -1.00388888888889;
        }
        else if ((jjc >= 2415020.54166667 && jjc < 24.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421137.54166667) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaAutriche()
    {
        //(simplification)
        if ((jjc >= 2412554.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421137.54166667) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2421698.58333333 && jjc < 2421852.625) || (jjc >= 2422419.58333333 && jjc < 2422580.625) || (jjc >= 2429720.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431777.625) || (jjc >= 2431924.58333333 && jjc < 2432100.625) || (jjc >= 2432281.58333333 && jjc < 2432463.625) || (jjc >= 2432659.58333333 && jjc < 2432827.625) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981 && y <=1990)  && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaFrance()
    {
        double lat = placeLat;
        double lon = placeLong;
        
        //occupation allemande pendant les guerres;
        
        //(avec quelques approximations pour les dates et frontieres);
        if (((jjc >= 2404558.0 && jjc < 2421909.0)) && ((GermanFrenchBoudary1918(lat, lon / 15) == rightSide) || ((GermanFrenchBoudary1914_1917(lat, lon / 15) == rightSide) && (jjc >= 2420391.0))))
        {
            deltaAllemagneOuest();
        }
        else if ((jjc >= 2429803.0 && jjc < 2430666.0) && (GermanFrenchBoudary1940(lat, lon / 15) == rightSide))
        {
            deltaAllemagneOuest();
        }
        else if (jjc >= 2411806.5 && jjc < 2419106.5)
        {
            dblTimeLag = -0.155833333333333;
        }
        else if (jjc >= 2419106.5 && jjc < 2429684.58333333)
        {
            dblTimeLag = 0;
        }
        else if (jjc >= 2429684.58333333)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2421029.45833333 && jjc < 2421138.5) || (jjc >= 2421312.45833333 && jjc < 2421509.5) || (jjc >= 2421662.45833333 && jjc < 2421873.5) || (jjc >= 2422019.45833333 && jjc < 2422237.5) || (jjc >= 2422369.45833333 && jjc < 2422621.5) || (jjc >= 2422763.45833333 && jjc < 2422988.5) || (jjc >= 2423139.45833333 && jjc < 2423335.5) || (jjc >= 2423566.45833333 && jjc < 2423699.5) || (jjc >= 2423874.45833333 && jjc < 2424063.5) || (jjc >= 2424245.45833333 && jjc < 2424427.5) || (jjc >= 2424623.45833333 && jjc < 2424791.5) || (jjc >= 2424980.45833333 && jjc < 2425155.5) || (jjc >= 2425351.45833333 && jjc < 2425526.5) || (jjc >= 2425722.45833333 && jjc < 2425890.5) || (jjc >= 2426079.45833333 && jjc < 2426254.5) || (jjc >= 2426450.45833333 && jjc < 2426618.5) || (jjc >= 2426800.45833333 && jjc < 2426982.5) || (jjc >= 2427157.45833333 && jjc < 2427353.5) || (jjc >= 2427535.45833333 && jjc < 2427717.5) || (jjc >= 2427892.45833333 && jjc < 2428081.5) || (jjc >= 2428460.45833333 && jjc < 2428445.5) || (jjc >= 2428627.45833333 && jjc < 2428809.5) || (jjc >= 2428984.45833333 && jjc < 2429173.5) || (jjc >= 2429369.45833333 && jjc < 2429586.5))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2430119.45833333 && jjc < 2430273.5) || (jjc >= 2430427.5 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431371.54166667) || (jjc >= 2431547.58333333 && jjc < 2431714.625))
        {
            dblTimeLag = -2;
        }
        else if ((jjc >= 2442865.54166667 && jjc < 2443047.54166667) || (jjc >= 2443236.58333333 && jjc < 2443411.625) || (jjc >= 2443600.58333333 && jjc < 2443782.625) || (jjc >= 2443964.58333333 && jjc < 2444146.625) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981 && y <=1996) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1997) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaAlaska()
    {
        if ((jjc >= 2415241.5 && jjc < 2439819.5))
        {
            //4 zones (+8h from +11h);
            dblTimeLag = (double)(int)(dblTimeLag);
        }
        else if ((jjc >= 2439819.5 && jjc < 2445637.58333333))
        {
            //3 zones (+9h from +11h);
            dblTimeLag = (double)(int)(dblTimeLag + 1 / 3);
        }
        else if (jjc >= 2445637.58333333)
        {
            dblTimeLag = 9;
        }
        
        //daylight-saving time
        if ((jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1969 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaArgentine()
    {
        if (jjc >= 2413133.5 && jjc < 2422445.5)
        {
            //meridian of Cordoba;
            dblTimeLag = 4.28333333333333;
        }
        else if (jjc >= 2422445.5)
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2426311.5 && jjc < 2426432.5) || (jjc >= 2426629.5 && jjc < 2426767.5) || (jjc >= 2429811.5 && jjc < 2430159.5) || (jjc >= 2430937.5 && jjc < 2431880.5) || (jjc >= 2432094.5 && jjc < 2438303.5) || (jjc >= 2438378.5 && jjc < 2438455.5) || (jjc >= 2438683.5 && jjc < 2438820.5) || (jjc >= 2439048.5 && jjc < 2439185.5) || (jjc >= 2439413.5 && jjc < 2439581.5) || (jjc >= 2439764.5 && jjc < 2439953.5) || (jjc >= 2440135.5 && jjc < 2440317.5) || (jjc >= 2440499.5 && jjc < 2440681.5) || (jjc >= 2442070.5 && jjc < 2442168.5) || (jjc >= 2442326.5 && jjc < 2442508.5) || (jjc >= 2442690.5 && jjc < 2442872.5) || (jjc >= 2443054.5 && jjc < 2443236.5))
        {
            dblTimeLag = 3;
        }
        else if ((y>= 1932 && y <= 1940) && (jjc >= AstronomyMaths.gregorianToJulian(1, 11, y) && jjc < AstronomyMaths.gregorianToJulian(1, 3, y + 1)))
        {
            dblTimeLag = 3;
        }
    }
    private void deltaArizona()
    {
        if ((jjc >= 2409133.0 && jjc < 2431521.5))
        {
            dblTimeLag = (double)(int)(dblTimeLag + 2 / 3);
        }
        else if (jjc >= 2431521.5)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2439610.58333333 && jjc < 2439792.58333333))
        {
            dblTimeLag -= 1;
        }
    }
    private void deltaArkansas()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaBelize()
    {
        if (jjc >= 2419493.5 && jjc < 2441834.5)
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2441834.5)
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        else if ((y>= 1918 && y <= 1966) && (jjc >= julianDate4DayMonth(2, 10, y, 0) && jjc < julianDate4DayMonth(9, 2, y + 1, 0)))
        {
            dblTimeLag = 5.5;
        }
        else if ((y>= 1974 && y <= 1978) && (jjc >= julianDate4DayMonth(8, 10, y, 0) && jjc < julianDate4DayMonth(9, 2, y + 1, 0)))
        {
            dblTimeLag = 3;
        }
        else if ((y>= 1979 && y <= 1981) && (jjc >= julianDate4DayMonth(1, 10, y, 0) && jjc < julianDate4DayMonth(9, 2, y + 1, 0)))
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaBresil()
    {
        if (jjc >= 2420133.5)
        {
            dblTimeLag = (double)(int)dblTimeLag;
        }
        else if ((jjc >= 2430725.5 && jjc < 2431090.5) && ((strRegion.indexOf("amaps") >= 0) || (strRegion.indexOf("guapore") >= 0) || (strRegion.indexOf("grio branco") >= 0)))
        {
            dblTimeLag += 1;
        }
        else if ((jjc >= 2431090.5 && jjc < 2432196.5) && ((strRegion.indexOf("ignasu") >= 0) || (strRegion.indexOf("ponte pora") >= 0)))
        {
            dblTimeLag += 1;
        }
        
        //daylight-saving time
        if ((jjc >= 2426617.95833333 && jjc < 2426798.5) || (jjc >= 2426983.5 && jjc < 2427163.5) || (jjc >= 2433251.5 && jjc < 2433387.5) || (jjc >= 2433616.5 && jjc < 2433737.5) || (jjc >= 2433981.5 && jjc < 2434103.5) || (jjc >= 2438372.5 && jjc < 2438454.5) || (jjc >= 2438791.5 && jjc < 2438851.5) || (jjc >= 2439095.5 && jjc < 2439216.5) || (jjc >= 2439430.5 && jjc < 2439550.5) || (jjc >= 2439795.5 && jjc < 2439916.5) || (jjc >= 2446371.5 && jjc < 2446490.5))
        {
            dblTimeLag -= 1;
        }
        else if ((jjc >= 2438325.5 && jjc < 2438454.5) && ((strRegion.indexOf("espirito santo") >= 0) || (strRegion.indexOf("guanabara") >= 0) || (strRegion.indexOf("minas gerais") >= 0) || (strRegion.indexOf("rio de janeiro") >= 0) || (strRegion.indexOf("sau paulo") >= 0)))
        {
            dblTimeLag += 1;
        }
    }
    private void deltaBulgarie()
    {
        //(rough estimate);
        if ((jjc >= 2412006.5 && jjc < 2429903.5) || (jjc >= 2431167.5))
        {
            dblTimeLag = -2;
        }
        else if ((jjc >= 2429903.5 && jjc < 2431167.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2430399.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431777.625))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1979 && y <= 1982) && (jjc >= julianDate4DayMonth(1, 4, y, 6) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1983) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaCalifornie()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 8;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333) || (jjc >= 2437419.58333333 && jjc < 2437565.58333333))
        {
            dblTimeLag = 7;
        }
        else if ((y>= 1950 && y <= 1960) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
        else if ((y>=1962 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
    }
    
    private void deltaCarolineNord()
    {
        if ((jjc >= 2409133.0 && jjc < 2432456.58333333))
        {
            if (dblTimeLag < 5.50333333333333)
            {
                dblTimeLag = 5;
            }
            else
            {
                dblTimeLag = 6;
            }
        }
        else if ((jjc >= 2432456.58333333))
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaCarolineSud()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaColorado()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 6;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 6;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 6;
        }
        else if ((strPlace.indexOf("denver") >= 0) && ((jjc >= 2422411.58333333 && jjc < 2422628.58333333) || (jjc >= 2422775.58333333 && jjc < 2423196.58333333)))
        {
            dblTimeLag = 6;
        }
    }
    
    private void deltaConnecticut()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431821.5) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2429012.58333333 && jjc < 2429173.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1939 && y <= 1986) && (y != 1974 && y != 1975 && (y < 1942 || y > 1945)) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if (((strPlace.indexOf("hartford") >= 0) || (strPlace.indexOf("new britain") >= 0) || (strPlace.indexOf("new london") >= 0) || (strPlace.indexOf("putnam") >= 0)) && ((jjc >= 2422411.58333333 && jjc < 2422418.58333333) || (jjc >= 2422775.58333333 && jjc < 2422814.58333333)))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaDakotaNord()
    {
        if ((jjc >= 2409133.0 && jjc < 2425917.5) || (jjc >= 2426372.5 && jjc < 2431728.5) || (jjc >= 2439819.5))
        {
            dblTimeLag = (double)(int)(dblTimeLag + 0.065);//estimate
        }
        else if ((jjc >= 2425917.5 && jjc < 2426372.5) || (jjc >= 2431728.5 && jjc < 2439819.5))
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaDakotaSud()
    {
        if ((jjc >= 2409133.0))
        {
            if (dblTimeLag < 6.68888888888889)
            {
                dblTimeLag = 6;
            }
            else
            {
                dblTimeLag = 7;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaDelaware()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333) || (jjc >= 2435221.58333333 && jjc < 2435375.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1956 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        if (strPlace.indexOf("dover") >= 0)
        {
            if ((jjc >= 2422411.58333333) && (jjc < 2422628.58333333))
            {
                dblTimeLag = 4;
            }
            else if ((y>= 1921 && y <= 1954) && (y < 1942 || y > 1945) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 4;
            }
        }
    }
    
    private void deltaDistrictColumbia()
    {
        if (jjc >= 2409249.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2423176.58333333 && jjc < 2423301.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2432316.58333333 && jjc < 2432449.58333333) || (jjc >= 2432673.58333333 && jjc < 2432820.58333333) || (jjc >= 2433030.58333333 && jjc < 2433184.58333333) || (jjc >= 2433375.58333333 && jjc < 2433548.58333333) || (jjc >= 2434478.58333333 && jjc < 2434647.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1951 && y <= 1955) && (y != 1953) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1956 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaFinlande()
    {
        if ((jjc >= 2407777.5 && jjc < 2422810.5))
        {
            dblTimeLag = -1.66666666666667;
        }
        else if ((jjc >= 2422810.5))
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2430450.58333333 && jjc < 2430635.5) || (jjc >= 2444683.58333333 && jjc < 2444874.5))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1982) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaFloride()
    {
        if (jjc >= 2411153.0)
        {
            if (dblTimeLag < 5.65555555555556)
            {
                dblTimeLag = 5;
            }
            else
            {
                dblTimeLag = 6;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaGeorgie()
    {
        if ((strPlace.indexOf("atlanta") >= 0) && (jjc >= 2410637.5) || (strPlace.indexOf("savannah") >= 0) && (jjc >= 2410721.5) || (strPlace.indexOf("brunswick") >= 0) && (jjc >= 2410758.5))
        {
            dblTimeLag = 5;
        }
        else if ((dblTimeLag > 5.6) && (jjc >= 2416115.5))
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2430321.5)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaHawaii()
    {
        if ((jjc >= 2415021 && jjc < 2432344.58333333))
        {
            dblTimeLag = 10.5;
        }
        else if (jjc >= 1032344.58333333)
        {
            dblTimeLag = 10;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2427192.58333333 && jjc < 2427193.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag = 9.5;
        }
    }
    
    private void deltaHongKong()
    {
        if (jjc >= 2413559.5)
        {
            dblTimeLag = -8;
        }
        
        //daylight-saving time
        if ((jjc >= 2431930.58333333 && jjc < 2432155.58333333) || (jjc >= 2432288.58333333 && jjc < 2432549.58333333) || (jjc >= 2432673.58333333 && jjc < 2432855.58333333) || (jjc >= 2434472.58333333 && jjc < 2434682.58333333) || (jjc >= 2434822.58333333 && jjc < 2435046.58333333) || (jjc >= 2446554.58333333 && jjc < 2446687.58333333))
        {
            dblTimeLag = -9;
        }
        else if ((y>= 1949 && y <= 1952) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -9;
        }
        else if ((y>= 1955 && y <= 1964) && (jjc >= julianDate4DayMonth(18, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 11, y, 0) + 2 / 24))
        {
            dblTimeLag = -9;
        }
        else if ((y>= 1965 && y <= 1977) && (jjc >= julianDate4DayMonth(16, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(16, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -9;
        }
        else if ((y>= 1978 && y <= 1980) && (jjc >= julianDate4DayMonth(15, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(15, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = -9;
        }
    }
    
    private void deltaHongrie()
    {
        if ((jjc >= 2412006.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421137.54166667) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2430092.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431577.58333333 && jjc < 2431762.625) || (jjc >= 2431910.58333333 && jjc < 2432099.625) || (jjc >= 2432281.58333333 && jjc < 2432463.625) || (jjc >= 2432645.58333333 && jjc < 2432827.625) || (jjc >= 2433016.58333333 && jjc < 2433191.625) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1954 && y <= 1955) && (jjc >= AstronomyMaths.gregorianToJulian(23, 5, y) && jjc < julianDate4DayMonth(1, 10, y, 0)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1956 && y <= 1957) && (jjc >= julianDate4DayMonth(1, 6, y, 0) && jjc < julianDate4DayMonth(24, 9, y, 0)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaIdaho()
    {
        if ((jjc >= 2411153.0 && jjc < 2422110.58333333))
        {
            dblTimeLag = 8;
        }
        else if ((dblTimeLag < 7.46666666666667 && jjc >= 2422110.58333333))
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaInde()
    {
        if (jjc >= 2411368.5)
        {
            dblTimeLag = -5.35333333333333;
        }
        if ((jjc >= 2417027.5) && (strPlace.indexOf("calcutta") < 0) && (strPlace.indexOf("goa") < 0))
        {
            dblTimeLag = -5.5;
        }
        if ((jjc >= 2422324.5) && (strPlace.indexOf("birmanie") >= 0))
        {
            dblTimeLag = -6.5;
        }
        if ((jjc >= 2430268.5) && (strPlace.indexOf("calcutta") >= 0))
        {
            dblTimeLag = -5.5;
        }
        
        //daylight-saving time
        if ((jjc >= 2430299.5 && jjc < 2430494.5) || (strPlace.indexOf("assam") >= 0) || (strPlace.indexOf("bengale") >= 0) || (strPlace.indexOf("bihar") >= 0))
        {
            dblTimeLag = -6.5;
        }
        if ((jjc >= 2430603.5 && jjc < 2431743.5))
        {
            dblTimeLag = -6.5;
        }
        if ((strPlace.indexOf("bengale") >= 0) && (jjc >= 2431743.5 && jjc < 2432429.5))
        {
            dblTimeLag = -6.5;
        }
    }
    
    private void deltaIllinois()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>= 1959 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaIndiana()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>= 1976 && y <= 1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaIowa()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2438910.58333333 && jjc < 2439009.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaKansas()
    {
        if ((jjc >= 2409133.0 && jjc >= 2439819.5))
        {
            if (dblTimeLag < 6.66666666666667)
            {
                dblTimeLag = 6;
            }
            else
            {
                dblTimeLag = 7;
            }
        }
        else if (jjc >= 2439819.5)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaKentucky()
    {
        if ((jjc >= 2409133.0 && jjc < 2422324.5))
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2422324.5)//approximate
        {
            if (dblTimeLag < 5.5)
            {
                dblTimeLag = 5;
            }
            else
            {
                dblTimeLag = 6;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2430111.58333333) && ((jjc < 2430238.58333333) && (strPlace.indexOf("brodhead") >= 0)) || ((jjc < 2430250.58333333) && (strPlace.indexOf("irvine") >= 0)) || ((jjc < 2430265.58333333) && ((strPlace.indexOf("lexington") >= 0) || (strPlace.indexOf("midway") >= 0) || (strPlace.indexOf("millersburg") >= 0) || (strPlace.indexOf("paris") >= 0) || (strPlace.indexOf("taylorsville") >= 0) || (strPlace.indexOf("winchester") >= 0))) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaLiban(byte sens, short i)
    {
        if (jjc < 2407715.5)
        {
            if (sens == UT2LOCAL)
            {
                if (i == 0)
                {
                    dblTimeLag += localTime2MuslimLag(placeLong);
                }
            }
            else
            {
                if (i == 0)
                {
                    dblTimeLag -= muslimLocalTime2Lag(placeLong);
                }
            }
        }
        else
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2422411.5 && jjc < 2422622.5) || (jjc >= 2422782.5 && jjc < 2422965.5) || (jjc >= 2423139.5 && jjc < 2423335.5) || (jjc >= 2423531.5 && jjc < 2423678.5) || (jjc >= 2441490.5 && jjc < 2441591.5) || (jjc >= 2443628.5 && jjc < 2443781.5) || (jjc >= 2446551.5 && jjc < 2446719.5))
        {
            dblTimeLag = -3;
        }
        else if ((y>= 1957 && y <= 1977) && (y < 1962 || y > 1972) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) && jjc < AstronomyMaths.gregorianToJulian(1, 10, y)))
        {
            dblTimeLag = -3;
        }
        else if ((y>= 1984 && y <= 1985) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) && jjc < AstronomyMaths.gregorianToJulian(15, 10, y)))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaLouisianne()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || ((jjc >= 2431939.58333333 && jjc < 2432092.58333333) && ((strPlace.indexOf("new orleans") >= 0) || (strPlace.indexOf("nouvelle orl�ans") >= 0) || (strPlace.indexOf("nouvelle orleans") >= 0) || (strPlace.indexOf("kenner") >= 0))) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaLybie()
    {
        if ((jjc >= 2422324.5 && jjc < 2436204.5) && (jjc >= 2444970.5))
        {
            dblTimeLag = -1;
        }
        else if (jjc >= 2436204.5 && jjc < 2444970.5)
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2433933.58333333 && jjc < 2434012.5) || (jjc >= 2434659.58333333 && jjc < 2434743.5) || (jjc >= 2435380.5 && jjc < 2435473.5))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1982) && (jjc >= AstronomyMaths.gregorianToJulian(1, 4, y) && jjc < AstronomyMaths.gregorianToJulian(1, 10, y)))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaMaine()
    {
        if (jjc >= 2410273.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1955 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaMaroc()
    {
        //distinction between French Morocco and Spanish one;
        if ((strRegion.indexOf("mellila") >= 0) && (jjc > 2415385.5))
        {
            dblTimeLag = 0;
        }
        else if (jjc >= 2415020.5 && jjc < 2420085.5)
        {
            dblTimeLag = 0.5;
        }
        else if (jjc >= 2420085.5)
        {
            dblTimeLag = 0;
        }
        
        //daylight-saving time
        if ((strRegion.indexOf("mellila") < 0) && ((jjc >= 2429518.45833333 && jjc < 2429586.5) || (jjc >= 2429684.5 && jjc < 2431777.5) || (jjc >= 2433443.5 && jjc < 2433583.54166667)))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2439644.5 && jjc < 2439764.5) || (jjc >= 2442221.5 && jjc < 2442291.5) || (jjc >= 2442900.5 && jjc < 2442991.5) || (jjc >= 2443264.5 && jjc < 2443414.5) || (jjc >= 2443661.5 && jjc < 2443724.5) || (jjc >= 2444025.5 && jjc < 2444088.5))
        {
            dblTimeLag = -1;
        }
    }
    
    private void deltaMaryland()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1959 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaMassachusetts()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2429012.58333333 && jjc < 2429172.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1918 && y <= 1920) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1921 && y <= 1953) && (y != 1938 && (y < 1942 || y > 1945)) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1954 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaMichigan()
    {
        //(simplification)
        if ((jjc >= 2409803.0 && jjc < 2430000.0))
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2430000.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaMinnesota()
    {
        if (jjc >= 2415442.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || ((jjc >= 2431938.58333333 && jjc < 2432092.58333333) && (strPlace.indexOf("duluth") >= 0)) || (jjc >= 2435956.58333333 && jjc < 2436138.58333333) || (jjc >= 2436320.58333333 && jjc < 2436448.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>= 1959 && y <= 1965) && (jjc >= julianDate4DayMonth(22, 5, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(2, 9, y, 2) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaMississipi()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430206.58333333 && jjc < 2430399.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaMissouri()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaMontana()
    {
        if ((jjc >= 2409133.0 && jjc < 2416846.58333333))
        {
            if (dblTimeLag < 7.5)
            {
                dblTimeLag = 7;
            }
            else
            {
                dblTimeLag = 8;
            }
        }
        else if ((jjc >= 2416846.58333333))
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaNebraska()
    {
        //(simplification)
        if (jjc >= 2409133.0)
        {
            if (dblTimeLag < 6.66666666666667)
            {
                dblTimeLag = 6;
            }
            else
            {
                dblTimeLag = 7;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaNevada()
    {
        //(simplification)
        if ((jjc >= 2409133.0 && jjc < 2439126.5))
        {
            if ((strPlace.indexOf("caliente") >= 0))
            {
                dblTimeLag = 7;
            }
            else
            {
                dblTimeLag = 8;
            }
        }
        else if ((jjc >= 2439126.5))
        {
            if (dblTimeLag < 7.62333333333333)
            {
                dblTimeLag = 7;
            }
            else
            {
                dblTimeLag = 8;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1950 && y <= 1961) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1962 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaNewHampshire()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2428664.58333333 && jjc < 2428802.58333333) || (jjc >= 2429012.58333333 && jjc < 2429173.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1939 && y <= 1953) && (y < 1942 || y > 1945) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1954 && y <= 1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaNewJersey()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>= 1946 && y <= 1954) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1955 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaNewYork()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2422411.58333333 && jjc < 2422628.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1955 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaNouveauMexique()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 6;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 6;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 6;
        }
    }
    
    private void deltaNouvelleZelande()
    {
        if ((jjc >= 2403638.5 && jjc < 2430238.58333333))
        {
            dblTimeLag = -11.5;
        }
        else if (jjc >= 2430238.58333333)
        {
            dblTimeLag = -12;
        }
        
        //daylight-saving time
        if ((jjc >= 2425190.58333333 && jjc < 2425309.58333333))
        {
            dblTimeLag = -12.5;
        }
        else if ((y>= 1928 && y <= 1932) && (jjc >= julianDate4DayMonth(8, 10, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(15, 3, y + 1, 0) + 2 / 24))
        {
            dblTimeLag = -12;
        }
        else if ((y>= 1933 && y <= 1940) && (jjc >= julianDate4DayMonth(1, 9, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 4, y + 1, 0) + 2 / 24))
        {
            dblTimeLag = -12;
        }
        else if ((jjc >= 2442354.58333333 && jjc < 2442466.58333333))
        {
            dblTimeLag = -13;
        }
        else if ((y>= 1975) && (jjc >= julianDate4DayMonth(25, 10, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 3, y + 1, 0) + 2 / 24))
        {
            dblTimeLag = -13;
        }
    }
    
    private void deltaOhio()
    {
        //(simplification)
        if ((jjc >= 2412555.0 && jjc < 2428438.5833333333))
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2428438.5833333333)
        {
            dblTimeLag = 5;
        }
        else if ((jjc >= 2420253.50069444) && (strPlace.indexOf("cleveland") >= 0))
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaOklahoma()
    {
        //(simplification)
        if ((jjc >= 2409133.0 && jjc < 2422752.5))
        {
            if (dblTimeLag >= 6.66666666666667 && dblTimeLag <= 6.86666666666667)
            {
                dblTimeLag = 7;
            }
            else
            {
                dblTimeLag = 6;
            }
        }
        else
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || ((jjc >= 2437812.58333333 && jjc < 2437981.58333333) && (strPlace.indexOf("bartlesville") >= 0)) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaOregon()
    {
        //(simplification)
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 8;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 7;
        }
        else if ((y>=1963 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
    }
    
    private void deltaPennsylvanie()
    {
        if ((jjc >= 2410272.5) && (strPlace.indexOf("pittsburgh") >= 0) || (jjc >= 2410376.5) && (strPlace.indexOf("erie") < 0) || (jjc >= 2410453.5) && (strPlace.indexOf("erie") >= 0))
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1965 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaPologne()
    {
        //(rough estimate before 1915);
        if ((jjc >= 2420724.5 && jjc < 2421852.5) || (jjc >= 2423229.5))
        {
            dblTimeLag = -1;
        }
        else if ((jjc >= 2421852.5 && jjc < 2423229.5))
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.5 && jjc < 2421137.5) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2429803.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431367.625) || (jjc >= 2431574.5 && jjc < 2431760.5) || (jjc >= 2431924.5 && jjc < 2432070.5) || (jjc >= 2432309.5 && jjc < 2432463.5) || (jjc >= 2432659.5 && jjc < 2432827.5) || (jjc >= 2435991.54166667 && jjc < 2436110.58333333) || (jjc >= 2436292.54166667 && jjc < 2436474.58333333) || (jjc >= 2436719.54166667 && jjc < 2436845.58333333) || (jjc >= 2437027.54166667 && jjc < 2437209.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1918 && y <=1919) && (jjc >= AstronomyMaths.gregorianToJulian(15, 4, y) + 2 / 24 && jjc < AstronomyMaths.gregorianToJulian(16, 9, y) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1961 && y <=1964) && (jjc >= julianDate4DayMonth(25, 5, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1977 && y <=1980) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaPortoRico()
    {
        if (jjc >= 2414742.0)
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaRhodeIsland()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2429012.58333333 && jjc < 2429172.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1923 && y <=1954) && (y != 1938 && (y < 1942 || y > 1945)) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1955 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 4;
        }
    }
    
    private void deltaTchecoslovaquie()
    {
        if ((jjc >= 2411733.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421136.54166667) || (jjc >= 2421334.58333333 && jjc < 2421488.625) || (jjc >= 2421698.58333333 && jjc < 2421852.625) || (jjc >= 2429720.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431714.625) || (jjc >= 2431722.58333333 && jjc < 2431729.625) || (jjc >= 2431946.58333333 && jjc < 2432099.625) || (jjc >= 2432277.58333333 && jjc < 2432463.625) || (jjc >= 2432659.58333333 && jjc < 2432827.625) || (jjc >= 2433016.58333333 && jjc < 2433191.625) || (jjc >= 2443964.58333333 && jjc < 2444146.54166667) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1981) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaTennessee()
    {
        //(simplification)
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        else if (jjc >= 2431821.5)
        {
            if (dblTimeLag >= 5.68777777777778)
            {
                dblTimeLag = 6;
            }
            else
            {
                dblTimeLag = 5;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || ((jjc >= 2422411.58333333 && jjc < 2422628.58333333) && (strPlace.indexOf("nashville") < 0)) || ((jjc >= 2429761.58333333 && jjc < 2429901.58333333) && (strPlace.indexOf("nashville") < 0)) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaTexas()
    {
        //(simplification)
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        else if (((strPlace.indexOf("el paso") >= 0) || (strPlace.indexOf("pecos") >= 0)) || (jjc >= 2422749.5))
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2430196.5 && jjc < 2430268.5) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaTunisie()
    {
        if (jjc >= 2408213.5 && jjc < 2419104.5)
        {
            //meridian of Paris;
            dblTimeLag = -0.155833333333333;
        }
        else if (jjc >= 2419104.5)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2429369.45833333 && jjc < 2429586.5) || (jjc >= 2429684.45833333 && jjc < 2429907.5) || (jjc >= 2430427.5 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431371.54166667) || (jjc >= 2431547.58333333 && jjc < 2431714.625) || (jjc >= 2443264.5 && jjc < 2443411.625))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaTurquie()
    {
        //simplification;
        if (jjc >= 2415020.5)
        {
            dblTimeLag = -2;
        }
        else  if (jjc >= 2443796.5 && jjc < 2446431.5)
        {
            dblTimeLag = -3;
        }
        
        //daylight-saving time
        if (((jjc >= 2420984.5 && jjc < 2421137.5) && (strRegion.indexOf("istanbul") >= 0)) || (jjc >= 2422411.5 && jjc < 2422622.5) || (jjc >= 2422782.5 && jjc < 2422965.5) || (jjc >= 2423141.5 && jjc < 2423335.5) || (jjc >= 2423918.5 && jjc < 2424059.5) || (jjc >= 2424271.5 && jjc < 2424424.5) || (jjc >= 2429964.5 && jjc < 2430258.5) || (jjc >= 2430450.5 && jjc < 2430663.5) || (jjc >= 2431547.5 && jjc < 2431736.5) || (jjc >= 2431972.5 && jjc < 2432094.5) || (jjc >= 2432285.5 && jjc < 2433191.5) || (jjc >= 2433390.5 && jjc < 2433562.5) || (jjc >= 2433758.5 && jjc < 2433927.5) || (jjc >= 2437860.5 && jjc < 2437945.5) || (jjc >= 2438530.5 && jjc < 2438669.5) || (jjc >= 2441836.54166667 && jjc < 2441990.625) || (jjc >= 2442137.58333333 && jjc < 2442354.70833333) || (jjc >= 2442501.5 && jjc < 2442711.5) || (jjc >= 2442930.5 && jjc < 2443082.5) || (jjc >= 2445546.5 && jjc < 2445609.5) || (jjc >= 2446519.5 && jjc < 2446701.5))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1947 && y <=1948) && (jjc >= julianDate4DayMonth(15, 4, y, 0) && jjc < julianDate4DayMonth(2, 10, y, 0)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1970 && y <=1972) && (jjc >= julianDate4DayMonth(2, 5, y, 0) && jjc < julianDate4DayMonth(2, 10, y, 0)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1977 && y <=1978) && (jjc >= julianDate4DayMonth(1, 4, y, 0) && jjc < julianDate4DayMonth(15, 10, y, 0)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1979 && y <=1980) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 3 / 24 && jjc < julianDate4DayMonth(8, 10, y, 1)))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1981 && y <=1982) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 3 / 24 && jjc < julianDate4DayMonth(8, 10, y, 1)))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaURSS()
    {
        //(not accurate);
        if ((jjc >= 2411368.5) && (jjc < 2423342.5))
        {
            if (strRegion.indexOf("riga") >= 0)
            {
                dblTimeLag = -1.60888888888889;
            }
            else if(strRegion.indexOf("leningrad") >= 0)
            {
                dblTimeLag = -2.02777777777778;
            }
            else if(strRegion.indexOf("mosco") >= 0)
            {
                dblTimeLag = -2.51333333333333;
            }
            else if(strRegion.indexOf("irkoutsk") >= 0 || strRegion.indexOf("irkutsk") >= 0)
            {
                dblTimeLag = -6.95;
            }
            else if(strRegion.indexOf("vladivostok") >= 0)
            {
                dblTimeLag = -8.79222222222222;
            }
        }
        
        //(rough estimate timezones)
        else if (jjc >= 2426342.5)
        {
            dblTimeLag = (double)(int)(dblTimeLag) - 1;
            if ((strRegion.indexOf("mosco") >= 0) || (strRegion.indexOf("saint-petersb") >= 0) || (strRegion.indexOf("saint petersb") >= 0) || (strRegion.indexOf("st. petersb") >= 0) || (strRegion.indexOf("st-petersb") >= 0) || (strRegion.indexOf("volgograd") >= 0))
            {
                dblTimeLag = -3;
            }
            else if((strRegion.indexOf("caucase") >= 0) || (strRegion.indexOf("baku") >= 0) || (strRegion.indexOf("bakou") >= 0) || (strRegion.indexOf("tbilissi") >= 0))
            {
                dblTimeLag = -4;
            }
            else if((strRegion.indexOf("sverdlovsk") >= 0) || (strRegion.indexOf("ekaterinb") >= 0))
            {
                dblTimeLag = -5;
            }
            else if(strRegion.indexOf("omsk") >= 0)
            {
                dblTimeLag = -6;
            }
            else if((strRegion.indexOf("norilsk") >= 0) || (strRegion.indexOf("novosibirsk") >= 0))
            {
                dblTimeLag = -7;
            }
            else if((strRegion.indexOf("irkoustsk") >= 0) || (strRegion.indexOf("irkustsk") >= 0))
            {
                dblTimeLag = -8;
            }
            else if((strRegion.indexOf("iakoutsk") >= 0) || (strRegion.indexOf("yakutsk") >= 0) || (strRegion.indexOf("yakoutsk") >= 0))
            {
                dblTimeLag = -9;
            }
            else if(strRegion.indexOf("vladivostok") >= 0)
            {
                dblTimeLag = -10;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421332.5 && jjc < 2421745.5) || (jjc >= 2426143.5 && jjc < 2426342.5))
        {
            if (dblTimeLag >= -3)
            {
                dblTimeLag = -3;
            }
            else if (dblTimeLag >= -4)
            {
                dblTimeLag = -4;
            }
        }
        else if ((jjc >= 2421745.5 && jjc < 2421959.5))
        {
            if (dblTimeLag >= -3)
            {
                dblTimeLag = -4;
            }
            else if (dblTimeLag >= -5)
            {
                dblTimeLag = -5;
            }
        }
    }
    
    private void deltaUruguay()
    {
        if (jjc >= 2414168.5 && jjc < 2422445.5)
        {
            //meridian of Montevideo;
            dblTimeLag = 3.75;
        }
        else if (jjc >= 2422445.5 && jjc < 2433730.5)
        {
            dblTimeLag = 3.5;
        }
        else if (jjc > 2433730.5)
        {
            dblTimeLag = 3;
        }
        
        //daylight-saving time
        else if ((y>=1923 && y <=1925) && (jjc >= AstronomyMaths.gregorianToJulian(2, 10, y) && jjc < AstronomyMaths.gregorianToJulian(1, 4, y + 1)))
        {
            dblTimeLag = 3;
        }
        else if ((jjc >= 2427374.5 && jjc < 2427528.5) || (jjc >= 2427738.5 && jjc < 2427893.5))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1935 && y <=1939) && (jjc >= julianDate4DayMonth(25, 10, y, 0) && jjc < julianDate4DayMonth(25, 3, y + 1, 0)))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1940 && y <=1950) && (jjc >= julianDate4DayMonth(1, 11, y, 0) && jjc < julianDate4DayMonth(25, 3, y + 1, 0)))
        {
            dblTimeLag = 3;
        }
        else if ((jjc >= 2441225.5 && jjc < 2441544.5) || (jjc >= 2441591.5 && jjc < 2441745.5) || (jjc >= 2441956.5 && jjc < 2442109.5) || (jjc >= 2442321.5 && jjc < 2442473.5) || (jjc >= 2443052.5 && jjc < 2443208.5) || (jjc >= 2443481.5 && jjc < 2443599.5) || (jjc >= 2443845.5 && jjc < 2443936.5) || (jjc >= 2444147.5 && jjc < 2444302.5))
        {
            dblTimeLag = 2;
        }
    }
    
    private void deltaUtah()
    {
        
        //(simplification)
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1966 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaVermont()
    {
        if (jjc >=2409133.0)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1955 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaVirginie()
    {
        if (jjc >= 2409133.0)
        {
            if (dblTimeLag >= 5.51777777777778)
            {
                dblTimeLag = 6;
            }
            else
            {
                dblTimeLag = 5;
            }
        }
        else if (jjc >= 2432186.5)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaVirginieOccidentale()
    {
        if (jjc >= 2410454.0)
        {
            dblTimeLag = 5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1963 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaWashington()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 8;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2437419.58333333 && jjc < 2437566.58333333) || (jjc >= 2437783.58333333 && jjc < 2437937.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1963 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaWisconsin()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1957 && y <=1964) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1965 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaWyoming()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaAlabama()
    {
        if (jjc >= 2409133.0)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421683.58333333 && jjc < 2421893.58333333) || (jjc >= 2422047.58333333 && jjc < 2422257.58333333) || (jjc >= 2430196.5 && jjc < 2430268.5) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333) || (jjc >= 2442053.58333333 && jjc < 2442347.58333333) || (jjc >= 2442466.58333333 && jjc < 2442711.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1967 && y <=1986) && (y != 1974 && y != 1975) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaAllemagneOuest()
    {
        //(simplification)
        if (((jjc >= 2412189.5 && jjc < 2412554.5) && ((strPlace.indexOf("baden") >= 0) || (strPlace.indexOf("bayern") >= 0) || (strPlace.indexOf("rheinland-pfalz") >= 0) || (strPlace.indexOf("w�rtemberg") >= 0))) || (jjc >= 2412554.5))
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.45833333 && jjc < 2421137.54166667) || (jjc >= 2421333.58333333 && jjc < 2421488.625) || (jjc >= 2421698.58333333 && jjc < 2421852.625) || (jjc >= 2429720.58333333 && jjc < 2430665.625) || (jjc >= 2430812.58333333 && jjc < 2431001.625) || (jjc >= 2431183.58333333 && jjc < 2431365.625) || (jjc >= 2431547.58333333 && jjc < 2431714.625) || (jjc >= 2431722.58333333 && jjc < 2431777.625) || (jjc >= 2431924.58333333 && jjc < 2432100.625) || (jjc >= 2432281.58333333 && jjc < 2432316.625) || (jjc >= 2432365.625 && jjc < 2432463.625) || (jjc >= 2432659.58333333 && jjc < 2432827.625) || (jjc >= 2433016.58333333 && jjc < 2433191.625) || (jjc >= 2444335.58333333 && jjc < 2444510.625))
        {
            dblTimeLag = -2;
        }
        if ((jjc >= 2431599.58333333 && jjc < 2431722.625) || (jjc >= 2432316.625 && jjc < 2432365.625))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1981 && y <=1990) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 9, y, 6) + 1 + 3 / 24))
        {
            dblTimeLag = -2;
        }
        else if ((y>=1991) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 3 / 24))
        {
            dblTimeLag = -2;
        }
    }
    
    private void deltaMexique()
    {
        if ((jjc >= 2423055.5) && ((strPlace.indexOf("campeche") >= 0) || (strPlace.indexOf("chiapas") >= 0) || (strPlace.indexOf("oaxaca") >= 0) || (strPlace.indexOf("quintana roo") >= 0) || (strPlace.indexOf("tabasco") >= 0) || (strPlace.indexOf("tamaulipas") >= 0) || (strPlace.indexOf("veracruz") >= 0) || (strPlace.indexOf("yucatan") >= 0)))
        {
            dblTimeLag = 6;
        }
        else if ((strPlace.indexOf("mexico") >= 0) || (strPlace.indexOf("district federal") >= 0) || (strPlace.indexOf("federal district") >= 0) || (strPlace.indexOf("aguascalientes") >= 0) || (strPlace.indexOf("chihuahua") >= 0) || (strPlace.indexOf("cohahuila") >= 0) || (strPlace.indexOf("colima") >= 0) || (strPlace.indexOf("durango") >= 0) || (strPlace.indexOf("guanajuato") >= 0) || (strPlace.indexOf("guerrero") >= 0) || (strPlace.indexOf("hidalgo") >= 0) || (strPlace.indexOf("jalisco") >= 0) || (strPlace.indexOf("michoacan") >= 0) || (strPlace.indexOf("morelos") >= 0) || (strPlace.indexOf("nayarit") >= 0) || (strPlace.indexOf("nuevo leon") >= 0) || (strPlace.indexOf("puebla") >= 0) || (strPlace.indexOf("queretaro") >= 0) || (strPlace.indexOf("san luis potosi") >= 0) || (strPlace.indexOf("sinaloa") >= 0) || (strPlace.indexOf("sonora") >= 0) || (strPlace.indexOf("tlaxcala") >= 0) || (strPlace.indexOf("zacatecas") >= 0))
        {
            if ((jjc >= 2423055.5 && jjc < 2425042.5) || (jjc >= 2426295.5 && jjc < 2426463.5) || (jjc >= 2426615.5 && jjc < 2426797.5) || (((strPlace.indexOf("sinaloa") >= 0) || (strPlace.indexOf("sinaloa") >= 0) || (strPlace.indexOf("sonora") >= 0)) && (jjc >= 2430450.5 && jjc < 2432930.5)))
            {
                dblTimeLag = 7;
            }
            else if ((jjc >= 2425042.5 && jjc < 2426295.5) || (jjc >= 2426463.5 && jjc < 2426615.5) || (jjc >= 2426797.5))
            {
                dblTimeLag = 6;
            }
            else if (((strPlace.indexOf("nayarit") >= 0) || (strPlace.indexOf("sinaloa") >= 0) || (strPlace.indexOf("sonora") >= 0)) && (jjc >= 2432930.5))
            {
                dblTimeLag = 8;
            }
        }
        else if (strPlace.indexOf("baja california") >= 0)
        {
            if ((jjc >= 2423055.5 && jjc >= 2425042.5) || (jjc >= 2426295.5 && jjc >= 2430450.5) || (jjc >= 2432930.5))
            {
                dblTimeLag = 8;
            }
            else if ((jjc >= 2425042.5 && jjc >= 2426295.5) || (jjc >= 2430450.5 && jjc >= 2432930.5))
            {
                dblTimeLag = 7;
            }
        }
        
        //daylight-saving time
        if (((strPlace.indexOf("mexico") >= 0) || (strPlace.indexOf("district federal") >= 0) || (strPlace.indexOf("federal district") >= 0)) && ((jjc >= 2429299.5 && jjc >= 2429439.5) || (jjc >= 2429972.5 && jjc >= 2430085.5) || (jjc >= 2431074.5 && jjc >= 2431211.5) || (jjc >= 2433324.5 && jjc >= 2433492.5)))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaSyrie( byte sens, short i)
    {
        if (jjc < 2421959.5)
        {
            if (sens == UT2LOCAL)
            {
                if (i == 0)
                {
                    dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                }
            }
            else
            {
                if (i == 0)
                {
                    dblTimeLag -= muslimLocalTime2Lag(placeLong);
                }
            }
        }
        else
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2422411.5 && jjc < 2422622.5) || (jjc >= 2422782.5 && jjc < 2422965.5) || (jjc >= 2423139.5 && jjc < 2423335.5) || (jjc >= 2423531.5 && jjc < 2423678.5) || (jjc >= 2437783.58333333 && jjc < 2437938.58333333) || (jjc >= 2439239.58333333 && jjc < 2439399.58333333) || (jjc >= 2446477.5 && jjc < 2446722.5))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1964 && y <=1978) && (y != 1965 && y != 1966) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) + 2 / 24 && jjc < AstronomyMaths.gregorianToJulian(1, 10, y) + 2 / 24))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1963 && y <=1965) && (y != 1964) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) + 2 / 24 && jjc < AstronomyMaths.gregorianToJulian(30, 9, y) + 2 / 24))
        {
            dblTimeLag = -3;
        }
        else if ((y>=1983 && y <=1984) && (jjc >= AstronomyMaths.gregorianToJulian(1, 5, y) + 2 / 24 && jjc < AstronomyMaths.gregorianToJulian(15, 10, y) + 2 / 24))
        {
            dblTimeLag = -3;
        }
    }
    
    private void deltaTanzanie()
    {
        //Zanzibar island;
        if (strRegion.indexOf("zanzibar") >= 0)
        {
            if (jjc >= 2426342.5 && jjc < 2429629.5)
            {
                dblTimeLag = -2.5;
            }
            else if (jjc >= 2429629.5)
            {
                dblTimeLag = -3;
            }
            
            //Tanganyika;
        }
        else
        {
            if (jjc >= 2426342.5 && jjc < 2432551.5)
            {
                dblTimeLag = -3;
            }
            else if (jjc >= 2432551.5 && jjc < 2437300.5)
            {
                dblTimeLag = -2.75;
            }
            else if (jjc >= 2437300.5)
            {
                dblTimeLag = -3;
            }
        }
    }
    
    private void deltaTasmanie()
    {
        if (jjc >= 2413437.5)
        {
            dblTimeLag = -10;
        }
        
        //daylight-saving time
        if ((jjc >= 2421137.58333333 && jjc < 2421312.58333333) || (jjc >= 2421529.58333333 && jjc < 2421655.58333333) || (jjc >= 2421893.58333333 && jjc < 2422019.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333) || (jjc >= 2439764.58333333 && jjc < 2439946.58333333) || (jjc >= 2440156.58333333 && jjc < 2440289.58333333) || (jjc >= 2440520.58333333 && jjc < 2440653.58333333) || (jjc >= 2440884.58333333 && jjc < 2441024.58333333) || (jjc >= 2441255.58333333 && jjc < 2441374.58333333))
        {
            dblTimeLag = -11;
        }
        else if ((y>=1972) && (jjc >= julianDate4DayMonth(25, 10, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 3, y + 1, 0) + 2 / 24))
        {
            dblTimeLag = -11;
        }
    }
    
    private void deltaAlberta()
    {
        if (jjc>= 2417454.5)
        {
            dblTimeLag = 7;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421892.58333333) || (jjc >= 2422061.58333333 && jjc < 2422105.58333333))
        {
            dblTimeLag = 6;
        }
        else if (strPlace.indexOf("edmonton") >= 0)
        {
            if ((jjc >= 2422439.58333333 && jjc < 2422628.58333333))
            {
                dblTimeLag = 6;
            }
            else if ((y>=1921 && y <=1923) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
            else if ((jjc >= 2430399.58333333 && jjc < 2431709.58333333))
            {
                dblTimeLag = 6;
            }
        }
        if ((strPlace.indexOf("edmonton") >= 0) || (strPlace.indexOf("calgary") >= 0) || (strPlace.indexOf("medicine hat") >= 0))
        {
            if ((jjc >= 2432302.58333333 && jjc < 2432455.58333333))
            {
                dblTimeLag = 6;
            }
            else if ((y>=1972 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
            else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
        }
    }
    
    private void deltaChili()
    {
        if (jjc >= 2422140.5 && jjc < 2425337.5)
        {
            //meridian of Santiago;
            dblTimeLag = 4.71111111111111;
        }
        else if (jjc >= 2425337.5 && jjc < 2432322.5)
        {
            dblTimeLag = 5;
        }
        else if (jjc >= 2432322.5)
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2421837.5 && jjc < 2422141.5) || (jjc >= 2422202.5 && jjc < 2422415.5))
        {
            dblTimeLag = 3.71111111111111;
        }
        else if ((y>=1928 && y <=1931) && (jjc >= AstronomyMaths.gregorianToJulian(1, 9, y) && jjc < AstronomyMaths.gregorianToJulian(1, 4, y + 1)))
        {
            dblTimeLag = 4;
        }
        else if ((jjc >= 2440162.5 && jjc < 2440310.5) || (jjc >= 2440548.5 && jjc < 2440674.5) || (jjc >= 2440870.5 && jjc < 2441024.5) || (jjc >= 2441234.5 && jjc < 2441388.5) || (jjc >= 2441605.5 && jjc < 2441752.5) || (jjc >= 2441955.5 && jjc < 2442300.5))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1974) && (jjc >= julianDate4DayMonth(9, 10, y, 0) && jjc < AstronomyMaths.gregorianToJulian(9, 3, y + 1)))
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaChine()
    {
        //(simplification)
        if (jjc >= 2416115.5)
        {
            dblTimeLag = -8;
        }
        if ((strRegion.indexOf("mandchourie") >= 0))
        {
            if ((jjc >= 2416480.5 && jjc < 2425246.5))// || (jjc >= 24......5)) ???? to verify
            {
                dblTimeLag = -9;
            }
            else if ((jjc >= 2425246.5 && jjc < 2426707.5))
            {
                dblTimeLag = -8.5;
            }
            else
            {
                dblTimeLag = -8;
            }
        }
        else if ((strRegion.indexOf("mongoli") >= 0) && (jjc >= 2433282.5))
        {
            dblTimeLag = -7;
        }
        else if ((strRegion.indexOf("tibet") >= 0) || (strRegion.indexOf("sin kiang") >= 0))
        {
            if ((jjc >= 2425246.5 && jjc < 2438761.5))
            {
                dblTimeLag = -5.5;
            }
            else if ((jjc >= 2438761.5))
            {
                if ((strRegion.indexOf("tibet") >= 0) || (strRegion.indexOf("sin kiang oriental") >= 0))
                {
                    dblTimeLag = -6;
                }
                else
                {
                    dblTimeLag = -5;
                }
            }
        }
    }
    
    private void deltaColombieBritanique()
    {
        if (jjc >= 2417454.5)
        {
            dblTimeLag = 8;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421897.58333333) || (jjc >= 2422047.58333333 && jjc < 2422258.5))
        {
            dblTimeLag = 7;
        }
        else if (strPlace.indexOf("victoria") >= 0)
        {
            if ((jjc >= 2422810.58333333 && jjc < 2422963.5) || (jjc >= 2423174.58333333 && jjc < 2423329.5) || (jjc >= 2423545.58333333 && jjc < 2423671.58333333) || (jjc >= 2430182.5 && jjc < 2430265.5) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333))
            {
                dblTimeLag = 7;
            }
        }
        else if ((strPlace.indexOf("victoria") >= 0) || (strPlace.indexOf("vancouver") >= 0))
        {
            if ((jjc >= 2431938.58333333 && jjc < 2432092.58333333))
            {
                dblTimeLag = 7;
            }
            else if ((y>=1947 && y <=1961) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 7;
            }
        }
        else if ((y>=1962 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 7;
        }
    }
    
    private void deltaMalaisie()
    {
        if ((jjc >= 2417027.5 && jjc < 2427073.5))
        {
            dblTimeLag = -7;
        } else if((jjc >= 2427073.5 && jjc < 2430238.5))
        {
            dblTimeLag = -7.33333333333333;
        } else if((jjc >= 2430238.5 && jjc < 2430405.5) || (jjc >= 2431713.5 && jjc < 2444970.5))
        {
            dblTimeLag = -7.5;
        } else if((jjc >= 2430405.5 && jjc < 2431713.5))
        {
            dblTimeLag = -9;
        } else if((jjc >= 2444970.5))
        {
            dblTimeLag = -8;
        }
    }
    
    private void deltaManitoba()
    {
        if (jjc >= 2409132.5)
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421897.58333333) || (jjc >= 2430399.58333333 && jjc < 2431712.58333333))
        {
            dblTimeLag = 5;
        }
        else if (strPlace.indexOf("winnipeg") >= 0)
        {
            if ((jjc >= 2420970.58333333 && jjc < 2421130.58333333) || (jjc >= 2421364.58333333 && jjc < 2421494.58333333) || (jjc >= 2422810.58333333 && jjc < 2422943.58333333) || (jjc >= 2428669.58333333 && jjc < 2428802.58333333) || (jjc >= 2431976.58333333 && jjc < 2432106.58333333) || (jjc >= 2432302.58333333 && jjc < 2432456.58333333) || (jjc >= 2432715.58333333 && jjc < 2432820.58333333))
            {
                dblTimeLag = 5;
            }
            else if ((y>=1946 && y <=1960) && (y != 1959) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 5;
            }
            else if ((y>=1959 && y <=1966) && (y != 1960) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag = 5;
            }
        }
        else if ((y>=1967 && y <=1986) && (y != 1969))
        {
            if ((jjc >= 2440338.58333333 && jjc < 2440471.58333333))
            {
                dblTimeLag = 5;
            }
            else if (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24)
            {
                dblTimeLag = 5;
            }
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 5;
        }
    }
    
    private void deltaNouvelleBrunswick()
    {
        if ((jjc >= 2409065.5 && jjc < 2415849.5))
        {
            dblTimeLag = 5;
        }
        else if ((jjc >= 2415849.5))
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421896.58333333) || (jjc >= 2430399.58333333 && jjc < 2430846.58333333))
        {
            dblTimeLag = 3;
        }
        if ((jjc >= 2431712.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag = 5;
        }
        else if ((y>=1966 && y <=1971) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 0.0166666666666667 / 24))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1972) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaTerreNeuve()
    {
        if (jjc >= 2409132.5)
        {
            dblTimeLag = 3.5;
        }
        
        //daylight-saving time
        if ((jjc >= 2421390.375 && jjc < 2421502.41666667) || (jjc >= 2429862.45833333 && jjc < 2429811.5) || (jjc >= 2429874.45833333 && jjc < 2429937.5) || (jjc >= 2430126.45833333 && jjc < 2430301.5) || (jjc >= 2430419.58333333 && jjc < 2431734.58333333))
        {
            dblTimeLag = 2.5;
        }
        if ((jjc >= 2429811.45833333 && jjc < 2429874.5))
        {
            dblTimeLag = 1.5;
        }
        else if ((y>=1918 && y <=1934) && (jjc >= julianDate4DayMonth(1, 5, y, 0) + 22 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 23 / 24))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1935 && y <=1939) && (jjc >= julianDate4DayMonth(8, 5, y, 0) + 23 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 1))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1946 && y <=1949) && (jjc >= julianDate4DayMonth(8, 5, y, 0) + 23 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 1))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1950 && y <=1959) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 23 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 1))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1960 && y <=1971) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 && jjc < julianDate4DayMonth(25, 10, y, 0) + 0.0166666666666667))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1972 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 2.5;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 2.5;
        }
    }
    
    private void deltaTerritoiresNordOuest()
    {
        if (jjc >= 2409132.5)
        {
            if (dblTimeLag < 4.53333333333333)
            {
                dblTimeLag = 4;
            }
            else if (dblTimeLag < 5.66666666666667)
            {
                dblTimeLag = 5;
            }
            else if (dblTimeLag < 6.8)
            {
                dblTimeLag = 6;
            }
            else if (dblTimeLag < 8)
            {
                dblTimeLag = 7;
            }
            else
            {
                dblTimeLag = 8;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421892.58333333) || (jjc >= 2430399.58333333 && jjc < 2431709.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1980 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaNouvelleEcosse()
    {
        if (jjc >= 2409284.5)
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2420984.5 && jjc < 2421110.5) || (jjc >= 2421722.58333333 && jjc < 2421896.58333333) || (jjc >= 2430399.58333333 && jjc < 2431709.58333333))
        {
            dblTimeLag = 3;
        }
        if (strPlace.indexOf("halifax") >= 0)
        {
            if ((jjc >= 2422043.5 && jjc < 2422258.5) || (jjc >= 2422453.5 && jjc < 2422565.5) || (jjc >= 2422811.5 && jjc < 2422937.5) || (jjc >= 2423174.5 && jjc < 2423300.5) || (jjc >= 2423545.5 && jjc < 2423676.5) || (jjc >= 2423909.5 && jjc < 2424055.5) || (jjc >= 2424273.5 && jjc < 2424405.5) || (jjc >= 2424651.5 && jjc < 2424770.5) || (jjc >= 2425001.5 && jjc < 2425148.5) || (jjc >= 2425379.5 && jjc < 2425498.5) || (jjc >= 2425743.5 && jjc < 2425855.5) || (jjc >= 2426107.5 && jjc < 2426233.5) || (jjc >= 2426464.5 && jjc < 2426611.5) || (jjc >= 2426828.5 && jjc < 2426975.5) || (jjc >= 2427192.5 && jjc < 2427339.5) || (jjc >= 2427556.5 && jjc < 2427710.5))
            {
                dblTimeLag = 3;
            }
            else if ((y>= 1935 && y <= 1941) && (jjc >= julianDate4DayMonth(1, 5, y, 0) && jjc < julianDate4DayMonth(24, 9, y, 0)))
            {
                dblTimeLag = 3;
            }
            else if ((y>= 1946 && y <= 1956) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 3;
            }
            else if ((y>= 1957 && y <= 1958) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag = 3;
            }
        }
        else if ((y>= 1962 && y <= 1971) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 0.0166666666666667 / 24))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1972 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaOntario()
    {
        if (jjc >= 2409132.5)
        {
            if (dblTimeLag < 6)
            {
                dblTimeLag = 5;
            }
            else
            {
                dblTimeLag = 6;
            }
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421893.58333333) || (jjc >= 2429747.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag -= 1;
        }
        else if (strPlace.indexOf("toronto") >= 0)
        {
            if ((jjc >= 2422048.45833333 && jjc < 2422257.5) || (jjc >= 2422446.58333333 && jjc < 2422593.5) || (jjc >= 2422824.58333333 && jjc < 2422948.58333333) || (jjc >= 2423188.58333333 && jjc < 2423314.58333333) || (jjc >= 2423552.58333333 && jjc < 2423671.58333333) || (jjc >= 2425001.58333333 && jjc < 2425148.58333333) || (jjc >= 2425729.50069444 && jjc < 2425883.50069444) || (jjc >= 2426828.58333333 && jjc < 2426975.58333333) || (jjc >= 2427192.58333333 && jjc < 2427346.58333333) || (jjc >= 2431938.58333333 && jjc < 2432092.58333333) || (jjc >= 2432302.50069444 && jjc < 2432456.50069444) || (jjc >= 2432666.50069444 && jjc < 2432820.50069444))
            {
                dblTimeLag -= 1;
            }
            else if ((y>= 1924 && y <= 1926) && (jjc >= julianDate4DayMonth(1, 5, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(17, 9, y, 0) + 2 / 24))
            {
                dblTimeLag -= 1;
            }
            else if ((y>= 1928 && y <= 1939) && (y != 1929 && y != 1932 && y != 1933) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag -= 1;
            }
            else if ((y>= 1949 && y <= 1956) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag -= 1;
            }
            else if ((y>= 1957 && y <= 1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag -= 1;
            }
            else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
            {
                dblTimeLag -= 1;
            }
        }
    }
    
    private void deltaPrinceEdouard()
    {
        if (jjc >= 2409132.5)
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2421722.58333333 && jjc < 2421897.58333333) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag = 3;
        }
        else if ((strPlace.indexOf("charlottetown") >= 0) && ((jjc >= 2431936.58333333 && jjc < 2432092.58333333) || (jjc >= 2432308.58333333 && jjc < 2432455.58333333)))
        {
            dblTimeLag = 3;
        }
        else if ((y>= 1962 && y <= 1971) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 0.0166666666666667 / 24))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1972 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 3;
        }
        else if ((y>=1987) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 3;
        }
    }
    
    private void deltaQuebec()
    {
        if (jjc >= 2409132.5)
        {
            if (dblTimeLag < 4.53333333333333)
            {
                dblTimeLag = 4;
            }
            else
            {
                dblTimeLag = 5;
            }
        }
        else if ((jjc >= 2440517.5) && ((dblTimeLag >= 4.2 && dblTimeLag < 4.53333333333333)))
        {
            dblTimeLag = 4;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421897.58333333) || (jjc >= 2429747.50069444 && jjc < 2431728.58333333))
        {
            dblTimeLag -= 1;
        }
        else if ((jjc >= 2422048.60416667 && jjc < 2422256.60416667) || (jjc >= 2422446.60416667 && jjc < 2422600.58333333) || (jjc >= 2422810.58333333 && jjc < 2422964.58333333) || (jjc >= 2423174.58333333 && jjc < 2423328.58333333) || (jjc >= 2423552.58333333 && jjc < 2423692.58333333) || (jjc >= 2423923.58333333 && jjc < 2424056.58333333))
        {
            if ((strPlace.indexOf("montr�al") >= 0) || (strPlace.indexOf("montreal") >= 0))
            {
                dblTimeLag -= 1;
            }
        }
        else if ((y>= 1925 && y <= 1927) && (jjc >= julianDate4DayMonth(1, 5, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
        {
            if ((strPlace.indexOf("montr�al") >= 0) || (strPlace.indexOf("montreal") >= 0))
            {
                dblTimeLag -= 1;
            }
        }
        else if ((y>= 1928 && y <= 1956) && (y < 1940 || y > 1945))
        {
            if ((jjc >= 2433030.50069444 && jjc < 2433219.50069444) || (jjc >= 2433401.50069444 && jjc < 2433583.50069444))
            {
                if (((strPlace.indexOf("qu�bec") >= 0) || (strPlace.indexOf("quebec") >= 0) || (strPlace.indexOf("montreal") >= 0) || (strPlace.indexOf("montreal") >= 0) && (y == 1949 || y == 1950)))
                {
                    dblTimeLag -= 1;
                }
            }
            else if (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 0.0166666666666667 / 24)
            {
                dblTimeLag -= 1;
            }
        }
        else if( (y>= 1957 && y <= 1968) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 0.0166666666666667 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 0.0166666666666667 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1969 && y <= 1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaRoumanie()
    {
        if ((jjc >= 2412006.5 && jjc < 2426546.5))
        {
            dblTimeLag = -1.74111111111111;
        }
        else if ((jjc >= 2426546.5))
        {
            dblTimeLag = -2;
        }
        
        //daylight-saving time
        if ((jjc >= 2426849.5 && jjc < 2426982.54166667) || (jjc >= 2429720.5 && jjc < 2430665.625) || (jjc >= 2444020.5 && jjc < 2444146.54166667))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1933 && y <= 1939) && (jjc >= julianDate4DayMonth(2, 4, y, 0) && jjc < julianDate4DayMonth(1, 10, y, 0) + 1 / 24))
        {
            dblTimeLag -= 1;
        }
        else if ((y>= 1980 && y <= 1982) && (jjc >= julianDate4DayMonth(1, 4, y, 0) && jjc < julianDate4DayMonth(24, 9, y, 0) + 1 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaSaskatchewan()
    {
        if (jjc >= 2409176.5)
        {
            dblTimeLag = 7;
        }
        else if (((jjc >= 2417211.5) && (strPlace.indexOf("arcole") >= 0 || strPlace.indexOf("broadview") >= 0 || strPlace.indexOf("esteran") >= 0 || strPlace.indexOf("salkoate") >= 0)) || ((jjc >= 2421594.5) && (strPlace.indexOf("yorkton") >= 0)) || ((jjc >= 2435839.5) && (strPlace.indexOf("canora") >= 0 || strPlace.indexOf("humboldt") >= 0 || strPlace.indexOf("kelvington") >= 0)) || ((jjc >= 2436569.5) && (strPlace.indexOf("weyburn") >= 0)) || ((jjc >= 2437300.5) && (strPlace.indexOf("moose jaw") >= 0 || strPlace.indexOf("regina") >= 0)) || ((jjc >= 2437665.5) && (strPlace.indexOf("saskatoon east") >= 0)) || ((jjc >= 2439126.5) && (strPlace.indexOf("melfort") >= 0 || strPlace.indexOf("prince albert") >= 0 || strPlace.indexOf("outlook") >= 0 || strPlace.indexOf("swift current") >= 0 || strPlace.indexOf("tisdale") >= 0)) || ((jjc >= 2439491.5) && (strPlace.indexOf("herbert") >= 0)) || ((jjc >= 2440587.5) && (strPlace.indexOf("blaine lake") >= 0 || strPlace.indexOf("parkland") >= 0 || strPlace.indexOf("saskatoon west") >= 0 || strPlace.indexOf("shaunavon") >= 0 || strPlace.indexOf("wood river") >= 0)) || ((jjc >= 2441683.5) && (strPlace.indexOf("gull lake") >= 0)))
        {
            dblTimeLag = 6;
        }
        else if (((jjc >= 2442048.5) && (strPlace.indexOf("eston-elrose") >= 0 || strPlace.indexOf("rosetown") >= 0)) || ((jjc >= 2442413.5) && (strPlace.indexOf("eastend") >= 0 || strPlace.indexOf("kindersley") >= 0)) || ((jjc >= 2443144.5) && (strPlace.indexOf("battleford") >= 0 || strPlace.indexOf("meadow lake") >= 0 || strPlace.indexOf("northern lakes") >= 0 || strPlace.indexOf("northern lights") >= 0)) || ((jjc >= 2443509.5) && (strPlace.indexOf("biggar") >= 0)) || ((jjc >= 2444239.5) && (strPlace.indexOf("kerrobert") >= 0 || strPlace.indexOf("leader") >= 0 || strPlace.indexOf("turtleford") >= 0 || strPlace.indexOf("wilke") >= 0)) || ((jjc >= 2445335.5) && (strPlace.indexOf("maple creek") >= 0)) || ((jjc >= 2445700.5) && (strPlace.indexOf("paynton") >= 0)))
        {
            dblTimeLag = 6;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421893.58333333) || (jjc >= 2430399.58333333 && jjc < 2431712.58333333))
        {
            dblTimeLag = 6;
        }
        if (strPlace.indexOf("regina") >= 0)
        {
            if ((jjc >= 2420248.54166667 && jjc < 2420437.54166667) || (jjc >= 2422054.54166667 && jjc < 2422264.54166667) || (jjc >= 2422418.54166667 && jjc < 2422635.54166667) || (jjc >= 2422782.54166667 && jjc < 2422964.54166667) || (jjc >= 2428361.58333333 && jjc < 2428452.58333333))
            {
                dblTimeLag = 6;
            }
            else if ((y>= 1915 && y <= 1917) && (jjc >= julianDate4DayMonth(1, 4, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(1, 11, y, 0) + 1 / 24))
            {
                dblTimeLag = 6;
            }
            else if ((y>= 1922 && y <= 1933) && (y != 1927) && (jjc >= julianDate4DayMonth(1, 5, y, 0) + 1 / 24 && jjc < julianDate4DayMonth(1, 10, y, 0) + 1 / 24))
            {
                dblTimeLag = 6;
            }
            else if ((y>= 1937 && y <= 1941) && (jjc >= julianDate4DayMonth(8, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(8, 10, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
            else if ((jjc >= 2431938.58333333 && jjc < 2432106.58333333) || (jjc >= 2435933.58333333 && jjc < 2436110.58333333) || (jjc >= 2436296.58333333 && jjc < 2436474.58333333) || (jjc >= 2436660.58333333 && jjc < 2436838.58333333))
            {
                dblTimeLag = 6;
            }
            else if ((y>= 1947 && y <= 1956) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
        }
        else if (strPlace.indexOf("saskatoon") >= 0)
        {
            if ((jjc >= 2431938.58333333 && jjc < 2432106.58333333) || (jjc >= 2435933.58333333 && jjc < 2436110.58333333) || (jjc >= 2436296.58333333 && jjc < 2436474.58333333) || (jjc >= 2436660.58333333 && jjc < 2436838.58333333))
            {
                dblTimeLag = 6;
            }
            else if ((y>= 1947 && y <= 1956) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 2 / 24))
            {
                dblTimeLag = 6;
            }
            else if  (jjc >= 2437048.58333333 && jjc < 2437202.58333333)
            {
                dblTimeLag = 6;
            }
        }
    }
    
    private void deltaYougoslavie()
    {
        //(rough estimate);
        if ((strRegion.indexOf("serbi") >= 0) && (jjc >= 2409176.5) || jjc >= 2421746.0)
        {
            dblTimeLag = -1;
        }
        
        //daylight-saving time
        if ((jjc >= 2430103.58333333 && jjc < 2430665.625) || (jjc >= 2430811.58333333 && jjc < 2431000.625) || (jjc >= 2431182.58333333 && jjc < 2431364.625) || (jjc >= 2431581.58333333 && jjc < 2431714.625))
        {
            dblTimeLag = -2;
        }
        else if ((y>= 1983) && (jjc >= julianDate4DayMonth(25, 3, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 0) + 3 / 24))
        {
            dblTimeLag -= 1;
        }
    }
    
    private void deltaYukon()
    {
        if (jjc >= 2415251.5)
        {
            dblTimeLag = 9;
        }
        else if (((jjc >= 2439638.5) && (dblTimeLag < 9.2)) || ((jjc >= 2441317.5) && (dblTimeLag >= 9.2)))
        {
            dblTimeLag = 8;
        }
        
        //daylight-saving time
        if ((jjc >= 2421697.58333333 && jjc < 2421897.58333333) || (jjc >= 2422103.58333333 && jjc < 2422262.5) || (jjc >= 2430399.58333333 && jjc < 2431728.58333333))
        {
            dblTimeLag = 8;
        }
        else if ((y>=1980 && y <=1986) && (jjc >= julianDate4DayMonth(24, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 8;
        }
        else if ((y>=1987) &&  (jjc >= julianDate4DayMonth(1, 4, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(25, 10, y, 0) + 2 / 24))
        {
            dblTimeLag = 8;
        }
    }
    
    private void deltaGroenland()
    {
        if (jjc >= 2421072.5)
        {
            dblTimeLag = (double)(int)(dblTimeLag);//four zones (+1h, +2h, +3h et +4h)
        }
    }
    
    //Calculation of the time-lag between the UT hour and the local hour
    //(time-lag = UT hour - local hour)
    public double calculateTimeLag(byte sens, short appel, double oldTimeLag)
    {
        //byte n;
        
        //(the first modification is an estimate from the longitude of the place
        // the second one -- for i=1 -- is theoretically more accurate)
        for (byte i = 0; i <= appel; i++)
        {
            //the calculation is direct from local to UT
            //(delta=0 and calculation for i=0 only)
            if (i == 1 && sens == LOCAL2UT)
            {
                break;
            }
            if (sens == LOCAL2UT)
            {
                delta = 0.0;
            }
            else
            {
                delta = dblTimeLag / 24.0;
                dblTimeLag = oldTimeLag;
            }
            jjc = jj - delta;
            
            //Calculation of the time-lag from the country name and the (Julian) date
            //AFRICA
            if (strCountry.indexOf("algeri") >= 0 || strCountry.equals("alg�rie"))
            {
                deltaAlgerie();
            }
            
            else if (strCountry.equals("angola"))
            {
                if (jjc >= 2412098.5 && jjc < 2419182.5)
                {
                    //meridian of Luanda (13�15' East);
                    dblTimeLag = -0.883333333333333;
                }
                else if (jjc >= 2419182.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("b�nin") || strCountry.equals("benin"))
            {
                if (jjc >= 2421959.5 && jjc < 2427494.5)
                {
                    dblTimeLag = 0.0;
                }
                else if (jjc >= 2427494.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("bostwana"))
            {
                if (jjc >= 2412136.5 && jjc < 2416174.5)
                {
                    dblTimeLag = -1.5;
                }
                else if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
                
                //daylight-saving time
                if (jjc >= 2430986.58333333 && jjc < 2431168.58333333)
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if(strCountry.equals("burundi") || strCountry.equals("urundi"))
            {
                if (jjc >= 2411368.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.equals("cameroun") || strCountry.equals("cameroon"))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("r�publique centrafricaine") || strCountry.equals("centrafrique") || strCountry.equals("central african republic") || strCountry.equals("car") || strCountry.equals("c.a.r."))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("congo"))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("cote d'ivoire") || strCountry.equals("c�te d'ivoire") || strCountry.equals("ivory coast"))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("djibouti") || strCountry.equals("french somali coast") || strCountry.equals("jibuti"))
            {
                if (jjc >= 2419218.5)
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("egypt") || strCountry.equals("�gypte"))
            {
                {
                    deltaEgypte();
                }
            }
            
            else if (strCountry.equals("�thiopie") || strCountry.indexOf("ethiopi") >= 0)
            {
                if (jjc >= 2411368.5 && jjc < 2428297.5)
                {
                    //meridian of Addis Abeba;
                    dblTimeLag = -2.58333333333333;
                }
                else if (jjc >= 2428297.5)
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("gabon") || strCountry.equals("gabun"))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.indexOf("gambi") >= 0)
            {
                if (jjc >= 2419402.5 && jjc < 2427803.5)
                {
                    //meridian of Banjul;
                    dblTimeLag = 1.1;
                }
                else if (jjc >= 2427803.5 && jjc < 2438395.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc > 2438395.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("ghana"))
            {
                deltaGhana();
            }
            
            else if (strCountry.equals("guin�e-bissau") || strCountry.equals("guinee-bissau") || strCountry.equals("guin�e bissau") || strCountry.equals("guinee bissau"))
            {
                if (jjc >= 2419182.5 && jjc < 2442413.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc >= 2442413.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("guin�e �quatoriale") || strCountry.equals("guinee equatoriale") || strCountry.equals("equatorial guinea"))
            {
                if (jjc >= 2419402.5 && jjc < 2438378.5)
                {
                    dblTimeLag = 0.0;
                }
                else if (jjc >= 2438378.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("guin�e") || strCountry.equals("guinee") || strCountry.equals("guinea"))
            {
                if (jjc >= 2419402.5 && jjc < 2427494.5)
                {
                    dblTimeLag = 0.0;
                }
                else if (jjc >= 2427494.5 && jjc < 2436934.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc >= 2436934.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("haute-volta") || strCountry.equals("haute volta") || strCountry.equals("burkina fasso") || strCountry.equals("burkina") || strCountry.equals("..."))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if(strCountry.equals("kenya") || strCountry.equals("k�nya"))
            {
                if ((jjc >= 2425427.5 && jjc < 2425977.5) || (jjc >= 24.5))
                {
                    dblTimeLag = -3.0;
                }
                else if (jjc >= 2425977.5 && jjc < 2428534.5)
                {
                    dblTimeLag = 2.5;
                }
                else if (jjc >= 2428534.5 && jjc < 2432186.5)
                {
                    dblTimeLag = -2.75;
                }
            }
            
            else if (strCountry.equals("lesotho") || strCountry.equals("l�sotho"))
            {
                if (jjc >= 2412136.5 && jjc < 2416174.5)
                {
                    dblTimeLag = -1.5;
                }
                else if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
                
                //daylight-saving time
                if (jjc >= 2430986.58333333 && jjc < 2431168.58333333)
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("liberia") || strCountry.equals("lib�ria"))
            {
                if ((jjc >= 2408446.5 && jjc < 2422018.5) || (jjc >= 2426707.5 && jjc < 2442048.5))
                {
                    //meridian of Monrovia;
                    dblTimeLag = 0.72;
                }
                else if (jjc >= 2422018.5 && jjc < 2426707.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc >= 2442048.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.indexOf("liby") >= 0)
            {
                deltaLybie();
            }
            
            else if (strCountry.equals("madagascar"))
            {
                if (jjc >= 2419218.5)
                {
                    dblTimeLag = -3.0;
                }
                
                //daylight-saving time
                if (jjc >= 2434801.45833333 && jjc < 2434892)
                {
                    dblTimeLag = -4.0;
                }
            }
            
            else if (strCountry.equals("malawi"))
            {
                if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.equals("mali"))
            {
                if (jjc >= 2419402.5 && jjc < 2432917.5)
                {
                    //case of the Mali at the East of Niger (7�30' East is an estimate);
                    if (dblTimeLag < -0.5)
                    {
                        dblTimeLag = 0.0;
                    }
                    else
                    {
                        dblTimeLag = 1.0;
                    }
                }
                else if (jjc >= 2432917.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("maroc") || strCountry.equals("morocco"))
            {
                deltaMaroc();
            }
            
            else if (strCountry.indexOf("mauritani") >= 0)
            {
                if (jjc >= 2419402.5 && jjc < 2432917.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc >= 2432917.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("mozambique") || strCountry.equals("mo�ambique"))
            {
                if (jjc >= 2415020.5 && jjc < 2416174.5)
                {
                    //meridian of Mozambique;
                    dblTimeLag = -2.71666666666667;
                }
                else if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.indexOf("namibi") >= 0)
            {
                if (jjc >= 2412136.5 && jjc < 2416174.5)
                {
                    dblTimeLag = -1.5;
                }
                else if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2430622.58333333 && jjc < 2430804.58333333) || (jjc >= 2430986.58333333 && jjc < 2431168.58333333))
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("niger"))
            {
                deltaNiger();
            }
            
            else if (strCountry.equals("nigeria") || strCountry.equals("nig�ria"))
            {
                if (jjc >= 2422202.5 && jjc < 2424881.5)
                {
                    dblTimeLag = -0.5;
                }
                else if (jjc >= 2424881.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("ouganda") || strCountry.equals("uganda"))
            {
                if (jjc >= 2425977.5 && jjc < 2428899.5)
                {
                    dblTimeLag = -2.5;
                }
                else if (jjc >= 2428899.5 && jjc < 2432917.5)
                {
                    dblTimeLag = -2.75;
                }
                else if (jjc >= 2432917.5)
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("rwanda") || strCountry.equals("ruanda"))
            {
                if (jjc >= 2427954.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.equals("s�n�gal") || strCountry.equals("senegal"))
            {
                if (jjc >= 2419402.5 && jjc < 2432917.5)
                {
                    dblTimeLag = 1.0;
                }
                else if (jjc >= 2432917.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.equals("sierra leone"))
            {
                if (jjc >= 2415020.5 && jjc < 2419919.5)
                {
                    //meridian of Freetown;
                    dblTimeLag = 0.885555555555556;
                }
                else if (jjc >= 2419919.5 && jjc < 2438395.5)
                {
                    dblTimeLag = 1.0;
                }
                else if(jjc >= 2438395.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.indexOf("somali") >= 0)
            {
                //British part (estimate);
                if (placeLat > 8)
                {
                    if (jjc >= 2426342.5)
                    {
                        dblTimeLag = -2.48333333333333;
                    }
                }
                
                //Italian part
                else
                {
                    if (jjc >= 2412768.5)
                    {
                        dblTimeLag = -3.0;
                    }
                    else if (jjc >= 2439126.5)
                    {
                        dblTimeLag = -3.0;
                    }
                }
            }
            
            else if (strCountry.equals("soudan") || strCountry.equals("sudan"))
            {
                if (jjc >= 2426342.5)
                {
                    dblTimeLag = -2.0;
                }
                
                //daylight-saving time
                if (jjc >= 2440707.5 && jjc < AstronomyMaths.gregorianToJulian(15, 10, 1970))
                {
                    dblTimeLag = -3.0;
                }
                else if ((y>= 1971) && (jjc >= julianDate4DayMonth(24, 4, y, 0) && jjc < AstronomyMaths.gregorianToJulian(15, 10, y)))
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.equals("afrique du sud") || strCountry.equals("r�publique sud africaine") || strCountry.equals("republique sud africaine") || strCountry.equals("republique sud-africaine") || strCountry.equals("republique sud-africaine") || strCountry.equals("republic of south africa") || strCountry.equals("south africa"))
            {
                deltaAfriqueSud();
            }
            
            else if (strCountry.equals("swaziland"))
            {
                if (jjc >= 2412136.5 && jjc < 2416174.5)
                {
                    dblTimeLag = -1.5;
                }
                else if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2430622.58333333 && jjc < 2430804.58333333) || (jjc >= 2430986.58333333 && jjc < 2431168.58333333))
                {
                    dblTimeLag = -3.0;
                }
            }
            
            else if (strCountry.indexOf("tanzani") >= 0)
            {
                deltaTanzanie();
            }
            
            else if (strCountry.equals("tchad") || strCountry.equals("chad"))
            {
                if (jjc >= 2419402.5)
                {
                    dblTimeLag = -1.0;
                }
            }
            
            else if (strCountry.equals("togo"))
            {
                if (jjc >= 2412464.5)
                {
                    dblTimeLag = 0.0;
                }
            }
            
            else if (strCountry.indexOf("tunisi") >= 0)
            {
                deltaTunisie();
            }
            
            else if (strCountry.equals("za�re") || strCountry.equals("zaire"))
            {
                if (jjc >= 2414237.5)
                {
                    dblTimeLag = -1.0;
                }
                
                //East provinces (Kasai, Katanga et Kivu;
                if ((jj == 2422439.5) && ((strRegion.indexOf("kasai") >= 0) || (strRegion.indexOf("katanga") >= 0) || (strRegion.indexOf("kivu") >= 0)))
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.indexOf("zambi") >= 0)
            {
                if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            else if (strCountry.equals("zimbabwe") || strCountry.equals("rhod�sie") || strCountry.indexOf("rhodesi") >= 0)
            {
                if (jjc >= 2416174.5)
                {
                    dblTimeLag = -2.0;
                }
            }
            
            //SOUTH-AMERICA;
            else if (strCountry.equals("argentin"))
            {
                deltaArgentine();
            }
            
            else if (strCountry.equals("b�lize") || strCountry.equals("belize") || strCountry.equals("honduras britanique"))
            {
                deltaBelize();
            }
            
            else if (strCountry.indexOf("bolivi") >= 0)
            {
                if (jjc >= 2423420.5 && jjc < 2426787.5)
                {
                    dblTimeLag = 4.55;
                }
                else if (jjc >= 2426787.5)
                {
                    dblTimeLag = 4.0;
                }
                
                //daylight-saving time
                if (jjc >= 2426629.5 && jjc < 2426787.5)
                {
                    dblTimeLag = 3.55;
                }
            }
            
            else if (strCountry.equals("br�sil") || strCountry.equals("bresil") || strCountry.equals("brazil"))
            {
                deltaBresil();
            }
            
            else if (strCountry.equals("chili") || strCountry.equals("chile"))
            {
                deltaChili();
            }
            
            else if (strCountry.indexOf("colombi") >= 0)
            {
                if (jjc >= 2409248.5 && jjc < 2420459.5)
                {
                    //meridian of Bogota;
                    dblTimeLag = 4.93888888888889;
                }
                else if (jjc >= 2420459.5)
                {
                    dblTimeLag = 5.0;
                }
            }
            
            else if (strCountry.equals("costa-rica") || strCountry.equals("costa rica"))
            {
                if (jjc >= 2422704.5)
                {
                    dblTimeLag = 6.0;
                }
                
                //daylight-saving time
                if (jjc >= 2443929.5 && jjc < 2444027.5)
                {
                    dblTimeLag = 5;
                }
            }
            
            else if (strCountry.equals("el salvador"))
            {
                if (jjc >= 2422690.5)
                {
                    dblTimeLag = 6.0;
                }
            }
            
            else if (strCountry.equals("�quateur") || strCountry.equals("equateur") || strCountry.equals("ecuador"))
            {
                if (jjc >= 2426342.5)
                {
                    dblTimeLag = 5.0;
                }
            }
            
            else if (strCountry.equals("guadeloupe") || strCountry.equals("guadalupe"))
            {
                if (jjc >= 2419195.5)
                {
                    dblTimeLag = 4.0;
                }
            }
            
            else if (strCountry.equals("guatemala"))
            {
                if (jjc >= 2420045.5)
                {
                    dblTimeLag = 6.0;
                }
            }
            
            else if (strCountry.equals("guyane anglaise") || strCountry.equals("british guiana") || strCountry.equals("guiana"))
            {
                deltaGuyana();
            }
            
            else if (strCountry.equals("guyane fran�aise") || strCountry.equals("french guiana") || strCountry.equals("guyane"))
            {
                if (jjc >= 2419218.5 && jjc < 2439764.5)
                {
                    dblTimeLag = 4.0;
                }
                else if (jjc >= 2439764.5)
                {
                    dblTimeLag = 3.0;
                }
            }
            
            else if (strCountry.equals("guyane hollandaise") || strCountry.equals("dutch guiana") || strCountry.equals("surinam"))
            {
                if (jjc >= 2419218.5 && jjc < 2431729.5)
                {
                    //meridian of Paramaribo;
                    dblTimeLag = 3.68333333333333;
                }
                else if (jjc >= 2431729.5 && jjc < 2445974.5)
                {
                    dblTimeLag = 3.5;
                }
                else if (jjc > 2445974.5)
                {
                    dblTimeLag = 3.0;
                }
            }
            
            else if (strCountry.equals("ha�ti") || strCountry.equals("haiti"))
            {
                if (jjc >= 2421252.5)
                {
                    dblTimeLag = 5.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2445462.5 && jjc < 2445637.5) || (jjc >= 2445819.5 && jjc < 2446001.5) || (jjc >= 2446152.5 && jjc < 2446365.5))
                {
                    dblTimeLag = 4;
                }
            }
            
            else if (strCountry.equals("honduras"))
            {
                if (jjc >= 2422690.5)
                {
                    dblTimeLag = 6.0;
                }
            }
            
            else if (strCountry.equals("martinique"))
            {
                if (jjc >= 2419157.5)
                {
                    dblTimeLag = 4.0;
                }
            }
            
            else if (strCountry.equals("mexique") || strCountry.equals("mexico"))
            {
                deltaMexique();
            }
            
            else if (strCountry.equals("nicaragua"))
            {
                if ((jjc >= 2427614.5 && jjc < 2441803.5) || (jjc >= 2442459.5))
                {
                    dblTimeLag = 6.0;
                }
                else if (jjc >= 2441803.5 && jjc < 2442459.5)
                {
                    dblTimeLag = 5;
                }
                
                //daylight-saving time
                if ((jjc >= 2443957.5 && jjc < 2444048.5) || (jjc >= 2444314.5 && jjc < 2444409.5))
                {
                    dblTimeLag = 5.0;
                }
                else if ((y>= 1981 && y <= 1985) && (jjc >= julianDate4DayMonth(11, 3, y, 0) && jjc < julianDate4DayMonth(24, 6, y, 0)))
                {
                    dblTimeLag = 5.0;
                }
            }
            
            else if (strCountry.equals("panama"))
            {
                if (jjc >= 2418053.5)
                {
                    dblTimeLag = 5.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2445462.5 && jjc < 2445637.5) || (jjc >= 2445819.5 && jjc < 2446001.5) || (jjc >= 2446152.5 && jjc < 2446365.5))
                {
                    dblTimeLag = 4.0;
                }
            }
            
            else if (strCountry.equals("paraguay"))
            {
                if (jjc >= 2426623.5)
                {
                    dblTimeLag = 4.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2442686.5 && jjc < 2442851.5))
                {
                    dblTimeLag = 3;
                }
                else if ((y>= 1976) && (jjc >= AstronomyMaths.gregorianToJulian(1, 10, y) && jjc < AstronomyMaths.gregorianToJulian(1, 4, y + 1)))
                {
                    dblTimeLag = 3.0;
                }
            }
            
            else if (strCountry.equals("p�rou") || strCountry.equals("perou") || strCountry.equals("peru"))
            {
                if (jjc >= 2418137.5)
                {
                    dblTimeLag = 5.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2428899.5 && jjc < 2428989.5) || (jjc >= 2429166.5 && jjc < 2429348.5) || (jjc >= 2429530.5 && jjc < 2429712.5))
                {
                    dblTimeLag = 4;
                }
                else if ((y>= 1941 && y <= 1950) && (jjc >= AstronomyMaths.gregorianToJulian(1, 1, y) && jjc < AstronomyMaths.gregorianToJulian(1, 4, y + 1)))
                {
                    dblTimeLag = 4.0;
                }
            }
            
            else if (strCountry.equals("uruguay"))
            {
                deltaUruguay();
            }
            
            else if (strCountry.equals("venezuela") || strCountry.equals("v�n�zuela"))
            {
                if (jjc >= 2411368.5 && jjc < 2419452.5)
                {
                    //meridian of Caracas;
                    dblTimeLag = 4.46666666666667;
                }
                else if (jjc >= 2419452.5 && jjc < 2438761.5)
                {
                    dblTimeLag = 4.5;
                }
                else if (jjc > 2438761.5)
                {
                    dblTimeLag = 4.0;
                }
            }
            
            //OCEANIA;
            else if (strCountry.indexOf("australi") >= 0)
            {
                if (strRegion.equals("capitale federale") || strRegion.equals("capitale federale") || strRegion.equals("capital territory") || strRegion.equals("nouvelles galles du sud") || strRegion.equals("new south wales") || strRegion.equals("victoria"))
                {
                    if (jjc >= 2413225.5)
                    {
                        dblTimeLag = -10.0;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2421229.54166667 && jjc < 2421312.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333))
                    {
                        dblTimeLag = -11.0;
                    }
                    else if ((y>= 1971) && (jjc >= julianDate4DayMonth(25, 10, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 3, y + 1, 0) + 2.0 / 24.0))
                    {
                        dblTimeLag = -11.0;
                    }
                }
                else if (strRegion.equals("australie septentrionale") || strRegion.equals("northern territory"))
                {
                    if ((jjc >= 2413225.5 && jjc < 2414775.5))
                    {
                        dblTimeLag = -9.0;
                    }
                    else if (jjc >= 2414775.5)
                    {
                        dblTimeLag = -9.5;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2421229.54166667 && jjc < 2421312.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333))
                    {
                        dblTimeLag = -10.5;
                    }
                }
                else if (strRegion.equals("queensland"))
                {
                    if (jjc >= 2413225.5)
                    {
                        dblTimeLag = -10.0;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2421229.54166667 && jjc < 2421312.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333) || (jjc >= 2441255.58333333 && jjc < 2441374.58333333))
                    {
                        dblTimeLag = -11.0;
                    }
                }
                else if (strRegion.equals("australie m�ridionale") || strRegion.equals("australie meridionale") || strRegion.equals("south australia"))
                {
                    if ((jjc >= 2413225.5 && jjc < 2414775.5))
                    {
                        dblTimeLag = -9.0;
                    }
                    else if (jjc >= 2414775.5)
                    {
                        dblTimeLag = -9.5;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2421229.54166667 && jjc < 2421312.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333) || (jjc >= 2441255.58333333 && jjc < 2441374.58333333))
                    {
                        dblTimeLag = -11.0;
                    }
                    else if ((y>=1972) && (jjc >= julianDate4DayMonth(25, 10, y, 0) + 2 / 24 && jjc < julianDate4DayMonth(1, 3, y + 1, 0) + 2 / 24))
                    {
                        dblTimeLag = -11.0;
                    }
                }
                else if (strCountry.indexOf("tasmani") >= 0)
                {
                    deltaTasmanie();
                }
                else if (strRegion.equals("australie occidentale") || strRegion.equals("western australia"))
                {
                    if (jjc >= 2413528.5)
                    {
                        dblTimeLag = -8.0;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2421229.54166667 && jjc < 2421312.58333333) || (jjc >= 2430360.58333333 && jjc < 2430447.58333333) || (jjc >= 2430629.58333333 && jjc < 2430811.58333333) || (jjc >= 2431000.58333333 && jjc < 2431175.58333333))
                    {
                        dblTimeLag = -9.0;
                    }
                }
            }
            else if (strCountry.indexOf("tasmani") >= 0)
            {
                deltaTasmanie();
            }
            
            else if (strCountry.equals("nouvelle z�lande") || strCountry.equals("nouvelle zelande") || strCountry.equals("nouvelle-z�lande") || strCountry.equals("nlle zelande") || strCountry.equals("nlle-zelande") || strCountry.equals("nlle-zelande") || strCountry.equals("nouvelle-zelande") || strCountry.equals("new zealand") || strCountry.equals("nz") || strCountry.equals("n-z"))
            {
                deltaNouvelleZelande();
            }
            
            //NORTH-AMERICA;
            else if (strCountry.equals("alberta"))
            {
                deltaAlberta();
            }
            else if (strCountry.equals("colombie britanique") || strCountry.equals("british columbia"))
            {
                deltaColombieBritanique();
            }
            else if (strCountry.equals("manitoba"))
            {
                deltaManitoba();
            }
            else if (strCountry.equals("nouvelle brunswick") || strCountry.equals("nouveau brunswick") || strCountry.equals("new brunswick"))
            {
                deltaNouvelleBrunswick();
            }
            else if (strCountry.equals("terre-neuve") || strCountry.equals("terre neuve") || strCountry.equals("newfoundland"))
            {
                deltaTerreNeuve();
            }
            else if (strCountry.equals("territoires du nord") || strCountry.equals("northwest territories") || strCountry.equals("territoires du nord ouest") || strCountry.equals("territoires du nord-ouest"))
            {
                deltaTerritoiresNordOuest();
            }
            else if (strCountry.equals("nouvelle �cosse") || strCountry.equals("nouvelle ecosse") || strCountry.equals("nova scotia"))
            {
                deltaNouvelleEcosse();
            }
            else if (strCountry.equals("ontario"))
            {
                deltaOntario();
            }
            else if (strCountry.equals("�le du prince edouard") || strCountry.equals("ile du prince edouard") || strCountry.equals("prince edouard island"))
            {
                deltaPrinceEdouard();
            }
            else if (strCountry.equals("qu�bec") || strCountry.equals("quebec"))
            {
                deltaQuebec();
            }
            else if (strCountry.equals("saskatchewan"))
            {
                deltaSaskatchewan();
            }
            else if (strCountry.equals("yukon") || strCountry.equals("yukon territory"))
            {
                deltaYukon();
            }
            else if (strCountry.equals("gro�nland") || strCountry.equals("groenland"))
            {
                deltaGroenland();
            }
            
            else if (strCountry.equals("canada"))
            {
                if (strRegion.equals("alberta"))
                {
                    deltaAlberta();
                }
                else if (strRegion.equals("colombie britanique") || strRegion.equals("british columbia"))
                {
                    deltaColombieBritanique();
                }
                else if (strRegion.equals("manitoba"))
                {
                    deltaManitoba();
                }
                else if (strRegion.equals("nouvelle brunswick") || strRegion.equals("nouveau brunswick") || strRegion.equals("new brunswick"))
                {
                    deltaNouvelleBrunswick();
                }
                else if (strRegion.equals("terre-neuve") || strRegion.equals("terre neuve") || strRegion.equals("newfoundland"))
                {
                    deltaTerreNeuve();
                }
                else if (strRegion.equals("territoires du nord") || strRegion.equals("northwest territories") || strRegion.equals("territoires du nord ouest") || strRegion.equals("territoires du nord-ouest"))
                {
                    deltaTerritoiresNordOuest();
                }
                else if (strRegion.equals("nouvelle �cosse") || strRegion.equals("nouvelle ecosse") || strRegion.equals("nova scotia"))
                {
                    deltaNouvelleEcosse();
                }
                else if (strRegion.equals("ontario") || strRegion.equals(""))
                {
                    deltaOntario();
                }
                else if (strRegion.equals("�le du prince edouard") || strRegion.equals("ile du prince edouard") || strRegion.equals("prince edouard island"))
                {
                    deltaPrinceEdouard();
                }
                else if (strRegion.equals("qu�bec") || strRegion.equals("quebec"))
                {
                    deltaQuebec();
                }
                else if (strRegion.equals("saskatchewan"))
                {
                    deltaSaskatchewan();
                }
                else if (strRegion.equals("yukon") || strRegion.equals("yukon territory"))
                {
                    deltaYukon();
                }
                else if (strRegion.equals("gro�nland") || strRegion.equals("groenland"))
                {
                    deltaGroenland();
                }
                else
                {
                    deltaQuebec();
                }
            }
            
            else if (strCountry.equals("�tats unis") || strCountry.equals("etats-unis") || strCountry.equals("�tats-unis") || strCountry.equals("etats unis") || strCountry.equals("usa") || strCountry.equals("united states of america") || strCountry.equals("u.s.a."))
            {
                if (strRegion.equals("alabama") || strRegion.equals("al"))
                {
                    deltaAlabama();
                }
                else if (strRegion.equals("alaska") || strRegion.equals("ak"))
                {
                    deltaAlaska();
                }
                else if (strRegion.equals("arizona") || strRegion.equals("az"))
                {
                    deltaArizona();
                }
                else if (strRegion.equals("arkansas") || strRegion.equals("ar"))
                {
                    deltaArkansas();
                }
                else if (strRegion.equals("californie") || strRegion.equals("california") || strRegion.equals("ca"))
                {
                    deltaCalifornie();
                }
                else if (strRegion.equals("caroline du nord") || strRegion.equals("north carolina") || strRegion.equals("nc"))
                {
                    deltaCarolineNord();
                }
                else if (strRegion.equals("caroline du sud") || strRegion.equals("south carolina") || strRegion.equals("sc"))
                {
                    deltaCarolineSud();
                }
                else if (strRegion.equals("colorado") || strRegion.equals("co"))
                {
                    deltaColorado();
                }
                else if (strRegion.equals("connecticut") || strRegion.equals("ct"))
                {
                    deltaConnecticut();
                }
                else if (strRegion.equals("dakota du nord") || strRegion.equals("north dakota") || strRegion.equals("nd"))
                {
                    deltaDakotaNord();
                }
                else if (strRegion.equals("dakota du sud") || strRegion.equals("south dakota") || strRegion.equals("sd"))
                {
                    deltaDakotaSud();
                }
                else if (strRegion.equals("delaware") || strRegion.equals("de"))
                {
                    deltaDelaware();
                }
                else if (strRegion.equals("district of columbia") || strRegion.equals("dc"))
                {
                    deltaDistrictColumbia();
                }
                else if (strRegion.equals("floride") || strRegion.equals("florida") || strRegion.equals("fl"))
                {
                    deltaFloride();
                }
                else if (strRegion.equals("georgie") || strRegion.equals("georgie") || strRegion.equals("georgia") || strRegion.equals("ga"))
                {
                    deltaGeorgie();
                }
                else if (strRegion.equals("hawaii") || strRegion.equals("hi"))
                {
                    deltaHawaii();
                }
                else if (strRegion.equals("idaho") || strRegion.equals("id"))
                {
                    deltaIdaho();
                }
                else if (strRegion.equals("illinois") || strRegion.equals("il"))
                {
                    deltaIllinois();
                }
                else if (strRegion.equals("indiana") || strRegion.equals("in"))
                {
                    deltaIndiana();
                }
                else if (strRegion.equals("iowa") || strRegion.equals("ia"))
                {
                    deltaIowa();
                }
                else if (strRegion.equals("kansas") || strRegion.equals("ks"))
                {
                    deltaKansas();
                }
                else if (strRegion.equals("kentucky") || strRegion.equals("ky") || strRegion.equals("ke"))
                {
                    deltaKentucky();
                }
                else if (strRegion.equals("louisiana") || strRegion.equals("louisianne") || strRegion.equals("la"))
                {
                    deltaLouisianne();
                }
                else if (strRegion.equals("maine") || strRegion.equals("me"))
                {
                    deltaMaine();
                }
                else if (strRegion.equals("maryland") || strRegion.equals("md"))
                {
                    deltaMaryland();
                }
                else if (strRegion.equals("massachusetts") || strRegion.equals("ma"))
                {
                    deltaMassachusetts();
                }
                else if (strRegion.equals("michigan") || strRegion.equals("mi"))
                {
                    deltaMichigan();
                }
                else if (strRegion.equals("minnesota") || strRegion.equals("mn"))
                {
                    deltaMinnesota();
                }
                else if (strRegion.equals("mississipi") || strRegion.equals("ms"))
                {
                    deltaMississipi();
                }
                else if (strRegion.equals("missouri") || strRegion.equals("mo"))
                {
                    deltaMissouri();
                }
                else if (strRegion.equals("montana") || strRegion.equals("mt"))
                {
                    deltaMontana();
                }
                else if (strRegion.equals("nebraska") || strRegion.equals("ne"))
                {
                    deltaNebraska();
                }
                else if (strRegion.equals("nevada") || strRegion.equals("nv"))
                {
                    deltaNevada();
                }
                else if (strRegion.equals("new hampshire") || strRegion.equals("nh"))
                {
                    deltaNewHampshire();
                }
                else if (strRegion.equals("new jersey") || strRegion.equals("nj"))
                {
                    deltaNewJersey();
                }
                else if (strRegion.equals("new york") || strRegion.equals("ny"))
                {
                    deltaNewYork();
                }
                else if (strRegion.equals("nouveau mexique") || strRegion.equals("nm"))
                {
                    deltaNouveauMexique();
                }
                else if (strRegion.equals("ohio") || strRegion.equals("oh"))
                {
                    deltaOhio();
                }
                else if (strRegion.equals("oklahoma") || strRegion.equals("ok"))
                {
                    deltaOklahoma();
                }
                else if (strRegion.equals("oregon") || strRegion.equals("or"))
                {
                    deltaOregon();
                }
                else if (strRegion.equals("pennsylvania") || strRegion.equals("pennsylvanie") || strRegion.equals("pa"))
                {
                    deltaPennsylvanie();
                }
                else if (strRegion.equals("porto rico") || strRegion.equals("porto-rico") || strRegion.equals("puerto rico"))
                {
                    deltaPortoRico();
                }
                else if (strRegion.equals("rhode island") || strRegion.equals("ri"))
                {
                    deltaRhodeIsland();
                }
                else if (strRegion.equals("tennessee") || strRegion.equals("tn"))
                {
                    deltaTennessee();
                }
                else if (strRegion.equals("texas") || strRegion.equals("tx"))
                {
                    deltaTexas();
                }
                else if (strRegion.equals("utah") || strRegion.equals("ut"))
                {
                    deltaUtah();
                }
                else if (strRegion.equals("vermont") || strRegion.equals("vt"))
                {
                    deltaVermont();
                }
                else if (strRegion.equals("virginie") || strRegion.equals("virginia") || strRegion.equals("va"))
                {
                    deltaVirginie();
                }
                else if (strRegion.equals("virginie occidentale") || strRegion.equals("west virginia") || strRegion.equals("wv"))
                {
                    deltaVirginieOccidentale();
                }
                else if (strRegion.equals("washington") || strRegion.equals("wa"))
                {
                    deltaWashington();
                }
                else if (strRegion.equals("wisconsin") || strRegion.equals("wi"))
                {
                    deltaWisconsin();
                }
                else if (strRegion.equals("wyoming") || strRegion.equals("wy"))
                {
                    deltaWyoming();
                }
            }
            
            else if (strCountry.equals("alabama") || strCountry.equals("al"))
            {
                deltaAlabama();
            }
            else if (strCountry.equals("alaska") || strCountry.equals("ak"))
            {
                deltaAlaska();
            }
            else if (strCountry.equals("arizona") || strCountry.equals("az"))
            {
                deltaArizona();
            }
            else if (strCountry.equals("arkansas") || strCountry.equals("ar"))
            {
                deltaArkansas();
            }
            else if (strCountry.equals("californie") || strCountry.equals("california") || strCountry.equals("ca"))
            {
                deltaCalifornie();
            }
            else if (strCountry.equals("caroline du nord") || strCountry.equals("north carolina") || strCountry.equals("nc"))
            {
                deltaCarolineNord();
            }
            else if (strCountry.equals("caroline du sud") || strCountry.equals("south carolina") || strCountry.equals("sc"))
            {
                deltaCarolineSud();
            }
            else if (strCountry.equals("colorado") || strCountry.equals("co"))
            {
                deltaColorado();
            }
            else if (strCountry.equals("connecticut") || strCountry.equals("ct"))
            {
                deltaConnecticut();
            }
            else if (strCountry.equals("dakota du nord") || strCountry.equals("north dakota") || strCountry.equals("nd"))
            {
                deltaDakotaNord();
            }
            else if (strCountry.equals("dakota du sud") || strCountry.equals("south dakota") || strCountry.equals("sd"))
            {
                deltaDakotaSud();
            }
            else if (strCountry.equals("delaware") || strCountry.equals("de"))
            {
                deltaDelaware();
            }
            else if (strCountry.equals("district of columbia") || strCountry.equals("dc"))
            {
                deltaDistrictColumbia();
            }
            else if (strCountry.equals("floride") || strCountry.equals("florida") || strCountry.equals("fl"))
            {
                deltaFloride();
            }
            else if (strCountry.equals("georgie") || strCountry.equals("georgie") || strCountry.equals("georgia") || strCountry.equals("ga"))
            {
                deltaGeorgie();
            }
            else if (strCountry.equals("hawaii") || strCountry.equals("hi"))
            {
                deltaHawaii();
            }
            else if (strCountry.equals("idaho") || strCountry.equals("id"))
            {
                deltaIdaho();
            }
            else if (strCountry.equals("illinois") || strCountry.equals("il"))
            {
                deltaIllinois();
            }
            else if (strCountry.equals("indiana") || strCountry.equals("in"))
            {
                deltaIndiana();
            }
            else if (strCountry.equals("iowa") || strCountry.equals("ia"))
            {
                deltaIowa();
            }
            else if (strCountry.equals("kansas") || strCountry.equals("ks"))
            {
                deltaKansas();
            }
            else if (strCountry.equals("kentucky") || strCountry.equals("ky") || strCountry.equals("ke"))
            {
                deltaKentucky();
            }
            else if (strCountry.equals("louisiana") || strCountry.equals("louisianne") || strCountry.equals("la"))
            {
                deltaLouisianne();
            }
            else if (strCountry.equals("maine") || strCountry.equals("me"))
            {
                deltaMaine();
            }
            else if (strCountry.equals("maryland") || strCountry.equals("md"))
            {
                deltaMaryland();
            }
            else if (strCountry.equals("massachusetts") || strCountry.equals("ma"))
            {
                deltaMassachusetts();
            }
            else if (strCountry.equals("michigan") || strCountry.equals("mi"))
            {
                deltaMichigan();
            }
            else if (strCountry.equals("minnesota") || strCountry.equals("mn"))
            {
                deltaMinnesota();
            }
            else if (strCountry.equals("mississipi") || strCountry.equals("ms"))
            {
                deltaMississipi();
            }
            else if (strCountry.equals("missouri") || strCountry.equals("mo"))
            {
                deltaMissouri();
            }
            else if (strCountry.equals("montana") || strCountry.equals("mt"))
            {
                deltaMontana();
            }
            else if (strCountry.equals("nebraska") || strCountry.equals("ne"))
            {
                deltaNebraska();
            }
            else if (strCountry.equals("nevada") || strCountry.equals("nv"))
            {
                deltaNevada();
            }
            else if (strCountry.equals("new hampshire") || strCountry.equals("nh"))
            {
                deltaNewHampshire();
            }
            else if (strCountry.equals("new jersey") || strCountry.equals("nj"))
            {
                deltaNewJersey();
            }
            else if (strCountry.equals("new york") || strCountry.equals("ny"))
            {
                deltaNewYork();
            }
            else if (strCountry.equals("nouveau mexique") || strCountry.equals("nm") || strCountry.equals("new mexico"))
            {
                deltaNouveauMexique();
            }
            else if (strCountry.equals("ohio") || strCountry.equals("oh"))
            {
                deltaOhio();
            }
            else if (strCountry.equals("oklahoma") || strCountry.equals("ok"))
            {
                deltaOklahoma();
            }
            else if (strCountry.equals("oregon") || strCountry.equals("or"))
            {
                deltaOregon();
            }
            else if (strCountry.equals("pennsylvania") || strCountry.equals("pennsylvanie") || strCountry.equals("pa"))
            {
                deltaPennsylvanie();
            }
            else if (strCountry.equals("porto rico") || strCountry.equals("porto-rico") || strCountry.equals("puerto rico"))
            {
                deltaPortoRico();
            }
            else if (strCountry.equals("rhode island") || strCountry.equals("ri"))
            {
                deltaRhodeIsland();
            }
            else if (strCountry.equals("tennessee") || strCountry.equals("tn"))
            {
                deltaTennessee();
            }
            else if (strCountry.equals("texas") || strCountry.equals("tx"))
            {
                deltaTexas();
            }
            else if (strCountry.equals("utah") || strCountry.equals("ut"))
            {
                deltaUtah();
            }
            else if (strCountry.equals("vermont") || strCountry.equals("vt"))
            {
                deltaVermont();
            }
            else if (strCountry.equals("virginie") || strCountry.equals("virginia") || strCountry.equals("va"))
            {
                deltaVirginie();
            }
            else if (strCountry.equals("virginie occidentale") || strCountry.equals("west virginia") || strCountry.equals("wv"))
            {
                deltaVirginieOccidentale();
            }
            else if (strCountry.equals("washington") || strCountry.equals("wa"))
            {
                deltaWashington();
            }
            else if (strCountry.equals("wisconsin") || strCountry.equals("wi"))
            {
                deltaWisconsin();
            }
            else if (strCountry.equals("wyoming") || strCountry.equals("wy"))
            {
                deltaWyoming();
            }
            
            //EUROPE;
            else if (strCountry.equals("allemagne") || strCountry.equals("germany") || strCountry.equals("rfa") || strCountry.equals("f.r.g.") || strCountry.equals("federal republic of germany") || strCountry.equals("r.f.a.") || strCountry.equals("frg") || strCountry.equals("west germany") || strCountry.equals("allemagne de l'ouest") || strCountry.equals("rda") || strCountry.equals("r.d.a.") || strCountry.equals("allemagne de l'est") || strCountry.equals("east germany") || strCountry.indexOf("allemagne")>=0 || strCountry.indexOf("germany")>=0 )
            {
                if (strCountry.equals("rfa") || strCountry.equals("f.r.g.") || strCountry.equals("federal") || strCountry.equals("r.f.a.") || strCountry.equals("frg") || strCountry.indexOf("west")>=0 || strCountry.indexOf("ouest")>=0)
                {
                    deltaAllemagneOuest();
                }
                else if (strCountry.equals("rda") || strCountry.equals("r.d.a.") || strCountry.indexOf("east")>=0 || strCountry.indexOf("est")>=0)
                {
                    deltaAllemagneEst();
                }
                else
                {
                    deltaAllemagneOuest();
                }
            }
            else if (strCountry.equals("angleterre") || strCountry.equals("royaume uni") || strCountry.equals("grande bretagne") || strCountry.equals("royaume-uni") || strCountry.equals("england") || strCountry.equals("grande-bretagne") || strCountry.equals("gb") || strCountry.equals("uk") || strCountry.equals("united kingdom") || strCountry.equals("ecosse") || strCountry.equals("ecosse") || strCountry.equals("scotland"))
            {
                deltaAngleterre();
            }
            else if (strCountry.equals("autriche") || strCountry.equals("austria"))
            {
                deltaAutriche();
            }
            else if (strCountry.equals("belgique") || strCountry.equals("belgium"))
            {
                deltaBelgique();
            }
            else if (strCountry.equals("acores") || strCountry.equals("a�ores") || strCountry.equals("azores"))
            {
                dblTimeLag = -1.0;
            }
            else if (strCountry.equals("danemark") || strCountry.equals("denmark"))
            {
                deltaDanemark();
            }
            else if (strCountry.equals("eire") || strCountry.equals("irlande") || strCountry.equals("irish republic") || strCountry.equals("ireland"))
            {
                deltaIrlande();
            }
            else if (strCountry.equals("espagne") || strCountry.equals("spain"))
            {
                deltaEspagne();
            }
            else if (strCountry.equals("france"))
            {
                deltaFrance();
            }
            else if (strCountry.equals("gr�ce") || strCountry.equals("grece") || strCountry.equals("greece"))
            {
                deltaGrece();
            }
            else if (strCountry.equals("islande") || strCountry.equals("iceland"))
            {
                deltaIslande();
            }
            else if (strCountry.equals("italie") || strCountry.equals("italy") || strCountry.equals("sicile") || strCountry.equals("sardaigne"))
            {
                deltaItalie();
            }
            else if (strCountry.equals("norv�ge") || strCountry.equals("norvege") || strCountry.equals("norway"))
            {
                deltaNorvege();
            }
            else if (strCountry.equals("pays-bas") || strCountry.equals("pays bas") || strCountry.equals("hollande") || strCountry.equals("the netherlands") || strCountry.equals("netherland") || strCountry.equals("the netherland") || strCountry.equals("netherlands"))
            {
                deltaPaysBas();
            }
            else if (strCountry.equals("portugal"))
            {
                deltaPortugal();
            }
            else if (strCountry.equals("su�de") || strCountry.equals("sweden"))
            {
                deltaSuede();
            }
            else if (strCountry.equals("albanie") || strCountry.equals("albania"))
            {
                //(rough estimate);
                if (jjc >= 2420133.5)
                {
                    dblTimeLag = -1.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2429720.58333333 && jjc < 2431001.625))
                {
                    dblTimeLag = -2.0;
                }
                else if ((y>= 1972) && (jjc >= julianDate4DayMonth(1, 5, y, 6) + 2 / 24 && jjc < julianDate4DayMonth(24, 9, y, 6) + 3.0 / 24.0))
                {
                    dblTimeLag = -2.0;
                }
            }
            else if(strCountry.equals("bulgarie") || strCountry.equals("bulgaria"))
            {
                deltaBulgarie();
            }
            else if (strCountry.equals("finlande") || strCountry.equals("finland"))
            {
                deltaFinlande();
            }
            else if (strCountry.equals("hongrie") || strCountry.equals("hungary"))
            {
                deltaHongrie();
            }
            else if (strCountry.equals("pologne") || strCountry.equals("poland"))
            {
                deltaPologne();
            }
            else if (strCountry.equals("roumanie") || strCountry.equals("romania"))
            {
                deltaRoumanie();
            }
            else if (strCountry.equals("tch�coslovaquie") || strCountry.equals("tchecoslovaquie") || strCountry.equals("czechoslovakia") || strCountry.equals("slovaquie") || strCountry.equals("slovakia"))
            {
                deltaTchecoslovaquie();
            }
            else if (strCountry.equals("union sovi�tique") || strCountry.equals("union sovietique") || strCountry.equals("urss") || strCountry.equals("ussr") || strCountry.equals("u.r.s.s.") || strCountry.equals("u.s.s.r.") || strCountry.equals("soviet union") || strCountry.equals("russie") || strCountry.equals("russia"))
            {
                deltaURSS();
            }
            else if (strCountry.equals("yougoslavie") || strCountry.equals("yugoslavia"))
            {
                deltaYougoslavie();
            }
            else if (strCountry.equals("suisse") || strCountry.equals("switzerland"))
            {
                //(?);
                dblTimeLag = 0.0;
            }
            
            //ASIA;
            else if (strCountry.equals("arabie s�oudite") || strCountry.equals("arabie saoudite") || strCountry.equals("arabie seoudite") || strCountry.equals("saudi arabia"))
            {
                if ((jjc < 2431820.5))
                {
                    if (sens == UT2LOCAL)
                    {
                        if (i == 0)
                        {
                            dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                        }
                    }
                    else
                    {
                        if (i == 0)
                        {
                            dblTimeLag -= muslimLocalTime2Lag(placeLong);
                        }
                    }
                }
                else if ((jjc < 2442413.5 && dblTimeLag < -3.0))
                {
                    dblTimeLag = -4.0;
                }
                else
                {
                    dblTimeLag = -3.0;
                }
            }
            else if (strCountry.equals("iran") || strCountry.equals("perse"))
            {
                deltaIran(sens, i);
            }
            else if (strCountry.equals("irak") || strCountry.equals("iraq"))
            {
                deltaIrak(sens, i);
            }
            else if (strCountry.equals("israel") || strCountry.equals("isra�l"))
            {
                deltaIsra�l();
            }
            else if (strCountry.equals("jordanie") || strCountry.equals("jordan"))
            {
                if (jjc < 2426342.5)
                {
                    if (sens == UT2LOCAL)
                    {
                        if (i == 0)
                        {
                            dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                        }
                    }
                    else
                    {
                        if (i == 0)
                        {
                            dblTimeLag -= muslimLocalTime2Lag(placeLong);
                        }
                    }
                }
                else
                {
                    dblTimeLag = -2.0;
                }
            }
            else if (strCountry.equals("koweit") || strCountry.equals("al kuwayt"))
            {
                if (jjc < 2433282.5)
                {
                    if (sens == UT2LOCAL)
                    {
                        if (i == 0)
                        {
                            dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                        }
                    }
                    else
                    {
                        if (i == 0)
                        {
                            dblTimeLag -= muslimLocalTime2Lag(placeLong);
                        }
                    }
                }
                else
                {
                    dblTimeLag = -3.0;
                }
            }
            else if(strCountry.equals("liban") || strCountry.equals("lebanon"))
            {
                deltaLiban(sens, i);
            }
            else if (strCountry.equals("oman") || strCountry.equals("uman"))
            {
                if (jjc < 2431821.5)
                {
                    if (sens == UT2LOCAL)
                    {
                        if (i == 0)
                        {
                            dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                        }
                    }
                    else
                    {
                        if (i == 0)
                        {
                            dblTimeLag -= muslimLocalTime2Lag(placeLong);
                        }
                    }
                }
                else
                {
                    dblTimeLag = -4.0;
                }
            }
            else if (strCountry.equals("abu dhabi") || strCountry.equals("abou dhabi"))
            {
                dblTimeLag = -4.0;
            }
            else if (strCountry.equals("qatar"))
            {
                if (jjc < 2407715.5)
                {
                    if (sens == UT2LOCAL)
                    {
                        if (i == 0)
                        {
                            dblTimeLag = localTime2MuslimLag(placeLong) + dblTimeLag;
                        }
                    }
                    else
                    {
                        if (i == 0)
                        {
                            dblTimeLag -= muslimLocalTime2Lag(placeLong);
                        }
                    }
                }
                else
                {
                    if (jjc < 2442413.5)
                    {
                        dblTimeLag = -4.0;
                    }
                    else
                    {
                        dblTimeLag = -3.0;
                    }
                }
            }
            else if (strCountry.equals("syrie") || strCountry.equals("syria"))
            {
                deltaSyrie(sens, i);
            }
            else if (strCountry.equals("turquie") || strCountry.equals("turkey"))
            {
                deltaTurquie();
            }
            else if (strCountry.equals("y�men") || strCountry.equals("yemen"))
            {
                //(simplification)
                if (jjc >= 2426342.5)
                {
                    dblTimeLag = -3.0;
                }
                
                //daylight-saving time
                if ((strRegion.indexOf("aden") >= 0))
                {
                    if ((jjc >= 2429684.58333333 && jjc < 2431735.58333333) || (jjc >= 2431924.58333333 && jjc < 2432099.58333333) || (jjc >= 2432260.58333333 && jjc < 2432491.58333333) || (jjc >= 2432624.58333333 && jjc < 2432855.58333333) || (jjc >= 2433009.58333333 && jjc < 2433219.58333333))
                    {
                        dblTimeLag = -4;
                    }
                }
            }
            else if (strCountry.equals("afghanistan"))
            {
                //(simplification)
                if (jjc >= 2431456.5)
                {
                    dblTimeLag = -4.5;
                }
            }
            else if (strCountry.equals("birmanie") || strCountry.equals("burma"))
            {
                if (jjc >= 2417027.5)
                {
                    dblTimeLag = -6.5;
                }
            }
            else if (strCountry.equals("chine") || strCountry.equals("china"))
            {
                deltaChine();
            }
            
            else if (strCountry.equals("cor�e") || strCountry.equals("corea") || strCountry.equals("coree") || strCountry.equals("korea"))
            {
                if ((jjc >= 2416815.5 && jjc < 2425246.5) || (jjc >= 2426707.5))
                {
                    dblTimeLag = -9;
                }
                else if ((jjc >= 2425246.5 && jjc < 2426707.5))
                {
                    dblTimeLag = -8.5;
                }
                if ((strRegion.indexOf("south corea") >= 0) || (strRegion.indexOf("coree du sud") >= 0) || (strRegion.indexOf("cor�e du sud") >= 0))
                {
                    if ((jjc >= 2434821.5 && jjc < 2437521.5))
                    {
                        dblTimeLag = -8.5;
                    }
                    
                    //daylight-saving time
                    if ((jjc >= 2437055.5 && jjc < 2437190.5))
                    {
                        dblTimeLag = -9.5;
                    }
                }
            }
            
            else if (strCountry.equals("japon") || strCountry.equals("japan") || strCountry.equals("nippon"))
            {
                if (jjc >= 2410099.5)
                {
                    dblTimeLag = -9.0;
                }
                
                //daylight-saving time
                if ((jjc >= 2432673.5 && jjc < 2432805.5) || (jjc >= 2433009.5 && jjc < 2433169.5) || (jjc >= 2433408.5 && jjc < 2433533.5) || (jjc >= 2433772.5 && jjc < 2433897.5))
                {
                    dblTimeLag = -10.0;
                }
            }
            else if (strCountry.equals("hong-kong") || strCountry.equals("hong kong"))
            {
                deltaHongKong();
            }
            else if (strCountry.equals("inde") || strCountry.equals("india"))
            {
                deltaInde();
            }
            else if (strCountry.equals("indochine") || strCountry.equals("indo-china"))
            {
                if ((jjc >= 2417392.5 && jjc < 2419157.5))
                {
                    dblTimeLag = -7.11666666666667;
                }
                else if ((jjc >= 2419157.5 && jjc < 2430725.5) || (jjc >= 2431528.5 && jjc < 2432992.5))
                {
                    dblTimeLag = -7.0;
                }
                else if ((jjc >= 2430725.5 && jjc < 2431528.5) || (jjc >= 2432992.5))
                {
                    dblTimeLag = -8.0;
                }
            }
            else if (strCountry.equals("nord viet-nam") || strCountry.equals("north viet-nam") || strCountry.equals("laos") || strCountry.equals("cambodge") || strCountry.equals("cambogia"))
            {
                if (jjc >= 2435839.5)
                {
                    dblTimeLag = -7.0;
                }
            }
            else if (strCountry.equals("sud viet-nam") || strCountry.equals("south viet-nam"))
            {
                if (jjc >= 2435839.5)
                {
                    dblTimeLag = -8.0;
                }
                            /*if ((jjc >= 2442778.5) && ((strCountry.indexOf("sud viet-nam") < 0) || (strCountry.indexOf("south viet-nam") < 0)))
                            {
                                dblTimeLag = -7.0;
                            }*/  //?????
            }
            else if (strCountry.equals("malaisie") || strCountry.equals("malaysia") || strCountry.equals("singapour") || strCountry.equals("singapore"))
            {
                deltaMalaisie();
            }
            
            else if (strCountry.equals("pakistan"))
            {
                //(rough estimate);
                deltaInde();
                if ((jjc >= 2432412.5 && jjc < 2433919.5))
                {
                    dblTimeLag = -6.5;
                }
                else if ((jjc >= 2433919.5))
                {
                    dblTimeLag = -6.0;
                }
            }
            
            else if (strCountry.equals("tha�lande") || strCountry.equals("thailande"))
            {
                if ((jjc >= 2422415.5 && jjc < 2432992.5) || (jjc >= 2435839.5))
                {
                    dblTimeLag = -7.0;
                }
                else if ((jjc >= 2432992.5 && jjc < 2435839.5))
                {
                    dblTimeLag = -8.0;
                }
            }
            else if (strCountry.equals("solomon") || strCountry.equals("salomon") || strCountry.equals("new caledonia") || strCountry.equals("nlle caledonie") || strCountry.equals("nouvelle caledonie") || strCountry.equals("nlle caledonie") || strCountry.equals("nouvelle caledonie"))
            {
                dblTimeLag = -11.0;
            }
            else if (strCountry.equals("fiji") || strCountry.equals("fidji") || strCountry.equals("marshall") || strCountry.equals("kamchatka"))
            {
                dblTimeLag = -12.0;
            }
            else if (strCountry.equals("samoa") || strCountry.equals("midway"))
            {
                dblTimeLag = 11.0;
            }
            else if (strCountry.equals("taipei") || strCountry.equals("formose") || strCountry.equals("taiwan") || strCountry.equals("t'ai-wan") || strCountry.equals("taiwan") || strCountry.equals("t'ai-wan"))
            {
                dblTimeLag = -8.0;
            }
            else if (strCountry.equals("sri lanka"))
            {
                dblTimeLag = -6.0;
            }
            else if (strCountry.equals("guam") || strCountry.equals("nouvelle guin�e") || strCountry.equals("nlle guin�e") || strCountry.equals("nouvelle guinee") || strCountry.equals("nlle guinee") || strCountry.equals("nouvelle-guin�e") || strCountry.equals("nlle-guin�e") || strCountry.equals("nouvelle-guinee") || strCountry.equals("nlle-guinee") || strCountry.equals("new guinea") || strCountry.equals("new-guinea"))
            {
                dblTimeLag = -10.0;
            }
            else if (strCountry.equals("n�pal, nepal") || strCountry.equals("sikkim") || strCountry.equals("bhoutan") || strCountry.equals("bhutan") || strCountry.equals("bangladesh"))
            {
                dblTimeLag = -6.0;
            }
            /*else
            {
            }*/
        }
        return dblTimeLag;
    }
}