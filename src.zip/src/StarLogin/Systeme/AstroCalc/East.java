/*
 * East.java
 *
 * Created on 7 ao�t 2003, 07:15
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class East
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new East */
    public East(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        if (AstronomyMaths.sinD(mTSL * 15.0) == 0)
        {
            mCoord.setTropicHelioLong(270.0);
        }
        else
        {
            mCoord.setTropicHelioLong(AstronomyMaths.modulo(-AstronomyMaths.atnD(AstronomyMaths.cosD(mObliquity) / AstronomyMaths.tanD(mTSL * 15.0)) + 90.0 * (1.0 + AstronomyMaths.sgn(AstronomyMaths.sinD(mTSL * 15.0))), 360.0));
        }
        mCoord.setHelioLat(AstronomyMaths.atnD(-AstronomyMaths.tanD(mObliquity) * AstronomyMaths.sinD(mTSL * 15.0)));
        mCoord.setHelioDist(0.0);
        mCoord.setTropicGeoLong(mCoord.getTropicHelioLong());
        mCoord.setGeoLat(mCoord.getHelioLat());
        mCoord.setGeoDist(0.0);
        mCoord.setRA(mTSL * 15.0 + 90.0);
        mCoord.setDecl(0.0);
        mCoord.setAz(270.0);
        mCoord.setAlt(0.0);
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
