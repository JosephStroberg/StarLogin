package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public final class FDegree
{
    private String deg = "";
    private String shortDegree = "";
    private int degree = 0;
    private int minute = 0;
    private int second = 0;
    private double decimalDegree = 0.0;
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    private String signe = "";
    
    /** Creates new FDegree */
    public FDegree()
    {
    }
    
    public FDegree(String sData)
    {
        if (sData.startsWith("-"))
        {
            signe = "-";
            sData = sData.substring(1);
        }
        else if (sData.startsWith(" "))
        {
            signe = " ";
            sData = sData.substring(1);
        }
        else
            signe = " ";
        deg = sData;
        decimalDegree = longitude2DecimalDegree(deg);
        shortDegree = formatDegree(degree, minute);
        deg = formatDegree(degree, minute, second);
    }
    
    public FDegree(double lng)
    {
        if (lng<0)
        {
            signe = "-";
            lng *= -1;
        }
        else
            signe = " ";
        decimalDegree = lng;
        degree = (int)lng;
        double aux = (lng - (double)degree)*60.0;
        minute = (int)Math.abs(aux);
        aux = (Math.abs(aux) - (double)minute)*60.0;
        second = (int)Math.abs(aux);
        shortDegree = formatDegree(degree, minute);
        deg = formatDegree(degree, minute, second);
    }
    
    public FDegree(int d, int m, int s)
    {
        if (d<0)
        {
            signe = "-";
            d *= -1;
        }
        else
            signe = " ";
        shortDegree = formatDegree(d, m);
        deg = formatDegree(d, m, s);
        decimalDegree = longitude2DecimalDegree(deg);
    }
    
    public int longitude2Degree(String sDegree)
    {
        decimalDegree = longitude2DecimalDegree(sDegree);
        return degree;
    }
    
    public int longitude2Minute(String sDegree)
    {
        decimalDegree = longitude2DecimalDegree(sDegree);
        return minute;
    }
    
    public int longitude2Second(String sDegree)
    {
        decimalDegree = longitude2DecimalDegree(sDegree);
        return second;
    }
    
    public double longitude2DecimalDegree(String sDegree)
    {
        deg = sDegree;
        if (sDegree.length()<1) return 0.0;
        
        try
        {
            //get the degree
            int pos = sDegree.indexOf(bundle.getString("dg"));
            if (pos>=0)
            {
                degree = new Integer(sDegree.substring(0,pos)).intValue();
                sDegree = sDegree.substring(pos+1);
            }
            else
            {
                if (sDegree.length()>1)
                {
                    degree = new Integer(sDegree.substring(0,2)).intValue();
                }
                else if (sDegree.length()>0)
                {
                    degree = new Integer(sDegree).intValue();
                }
                else
                {
                    degree = 0;
                }
                sDegree="";
            }
            
            //get the minutes
            pos = sDegree.indexOf("'");
            if (pos>=0)
            {
                minute = new Integer(sDegree.substring(0,pos)).intValue();
                sDegree = sDegree.substring(pos+1);
            }
            else
            {
                if (sDegree.length()>1)
                {
                    minute = new Integer(sDegree.substring(0,2)).intValue();
                }
                else if (sDegree.length()>0)
                {
                    minute = new Integer(sDegree).intValue();
                }
                else
                {
                    minute = 0;
                }
                sDegree="";
            }
            
            //get the seconds
            pos = sDegree.indexOf("\"");
            if (pos>=0)
            {
                second = new Integer(sDegree.substring(0,pos)).intValue();
            }
            else
            {
                if (sDegree.length()>1)
                {
                    second = new Integer(sDegree.substring(0,2)).intValue();
                }
                else if (sDegree.length()>0)
                {
                    second = new Integer(sDegree).intValue();
                }
                else
                {
                    second = 0;
                }
            }
            if (second >= 60)
            {
                second -= 60;
                minute += 1;
            }
            if (minute >= 60)
            {
                minute -= 60;
                degree += 1;
            }
            if (degree >= 360)
            {
                degree = 360;
                minute = 0;
                second = 0;
            }
            else if (degree <= -360)
            {
                degree = -360;
                minute = 0;
                second = 0;
            }
            deg = signe.concat(formatDegree(degree, minute, second));
            decimalDegree = (double)degree + (double)minute/60.0 + (double)second/3600.0;
            if (signe.equals("-"))
                decimalDegree = -decimalDegree;
            return decimalDegree;
        }
        catch(java.lang.NumberFormatException ex)
        {
            MainClass.setMessage(ex.getMessage());
            return 0.0;
        }
    }
    
    public String formatDegree(int d, int m, int s)
    {
        if (s >= 60)
        {
            s -= 60;
            m += 1;
        }
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 360)
        {
            d = 360;
            m = 0;
            s = 0;
        }
        else if (d <= -360)
        {
            d = -360;
            m = 0;
            s = 0;
        }
        String sD = new Integer(d).toString();
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;
        String sS = String.valueOf(s);
        if (s<10) sS = "0"+sS;

        degree = d;
        minute = m;
        second = s;
        deg = signe+sD+bundle.getString("dg")+sM+"'"+sS+"\"";
        return deg;
    }
    
    public static String formatDegree(int d, int m)
    {
        if (m >= 60)
        {
            m -= 60;
            d += 1;
        }
        if (d >= 360)
        {
            d = 360;
            m = 0;
        }
        else if (d <= -360)
        {
            d = -360;
            m = 0;
        }
        String sD = new Integer(d).toString();
        String sM = String.valueOf(m);
        if (m<10) sM = "0"+sM;

        return sD+bundle.getString("dg")+sM+"'";
    }
    
    public static String formatDegree(int d)
    {
        if (d >= 360)
        {
            d = 360;
        }
        else if (d <= -360)
        {
            d = -360;
        }
        String sD = new Integer(d).toString();

        return sD+bundle.getString("dg");
    }
    
    public int getDegree()
    {
        return degree;
    }
    
    public double getDecimalDegree()
    {
        return decimalDegree;
    }
    
    public int getMinute()
    {
        return minute;
    }
    
    public int getSecond()
    {
        return second;
    }
    
    public String getSDegree()
    {
        return deg;
    }
    
    public String getShortDegree()
    {
        return shortDegree;
    }
    
    public void setDegree(int data)
    {
        degree = data;
    }
    
    public void setMinute(int data)
    {
        minute = data;
    }
    
    public void setSecond(int data)
    {
        second = data;
    }
    
    public void setSDegree(String data)
    {
        deg = data;
    }
    
    public void setDecimalDegree(double data)
    {
        decimalDegree = data;
    }
    
}
