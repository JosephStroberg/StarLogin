/*
 * Uranus.java
 *
 * Created on 7 ao�t 2003, 07:09
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Uranus
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Uranus */
    public Uranus(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Uranus;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + 32.0 * mCTime * mCTime + (19397.0 + 110.0 * mCTime - 9.0 * mCTime * mCTime) * AstronomyMaths.sinD(m[mNumber]) + (570.0 + 7.0 * mCTime) * AstronomyMaths.sinD(2.0 * m[mNumber]) - (536.0 * mCTime + 12.0 * (1.0 + mCTime * mCTime)) * AstronomyMaths.cosD(m[mNumber]) + 143.0 * AstronomyMaths.sinD(m[Planets.Saturn] - 2.0 * m[mNumber]) + (102.0 - 7.0 * mCTime) * AstronomyMaths.sinD(m[Planets.Saturn] - 3.0 * m[mNumber]) + (76.0 + 7.0 * mCTime) * AstronomyMaths.cosD(m[Planets.Saturn] - 3.0 * m[mNumber]) - 49.0 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) - 30.0 * mCTime * AstronomyMaths.cosD(2.0 * m[mNumber]);
        mTropicHelioLong = mTropicHelioLong + 29.0 * (AstronomyMaths.sinD(2.0 * m[Planets.Jupiter] - 6.0 * m[Planets.Saturn] + 3.0 * m[mNumber]) + AstronomyMaths.cosD(2.0 * (m[mNumber] - m[Planets.Neptune]))) - 28.0 * AstronomyMaths.cosD(m[mNumber] - m[Planets.Neptune]) + 23.0 * AstronomyMaths.sinD(3.0 * m[mNumber]) - 21.0 * AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]) + 20.0 * AstronomyMaths.sinD(m[mNumber] - m[Planets.Neptune]) + (20.0 + 8.0 * mCTime) * AstronomyMaths.cosD(m[Planets.Saturn] - 2.0 * m[mNumber]) - 19.0 * AstronomyMaths.cosD(m[Planets.Saturn] - m[mNumber]) + 17.0 * AstronomyMaths.sinD(2.0 * m[mNumber] - 3.0 * m[Planets.Neptune]) + 14.0 * AstronomyMaths.sinD(3.0 * (m[mNumber] - m[Planets.Neptune])) + 13.0 * AstronomyMaths.sinD(m[Planets.Saturn] - m[mNumber]);
        mTropicHelioLong = mTropicHelioLong + 10.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] - m[Planets.Neptune])) + 9.0 * (AstronomyMaths.cosD(2.0 * m[mNumber] - 3.0 * m[Planets.Neptune]) - AstronomyMaths.sinD(2.0 * u[mNumber])) + 6.0 * (AstronomyMaths.sinD(2.0 * (m[Planets.Jupiter] - 3.0 * m[Planets.Saturn] + m[mNumber])) + AstronomyMaths.cosD(2.0 * (m[Planets.Jupiter] - 3.0 * m[Planets.Saturn] + m[mNumber]))) + 5.0 * AstronomyMaths.sinD(m[Planets.Saturn] - 4.0 * m[mNumber]) + 4.0 * (AstronomyMaths.cosD(3.0 * (m[mNumber] - m[Planets.Neptune])) - AstronomyMaths.sinD(3.0 * m[mNumber] - 4.0 * m[Planets.Neptune])) - 3.0 * AstronomyMaths.cosD(m[Planets.Neptune]) - 2.0 * AstronomyMaths.sinD(m[Planets.Neptune]);
        mCoord.setHelioLat(2775.0 * AstronomyMaths.sinD(u[mNumber]) + 131.0 * AstronomyMaths.sinD(m[mNumber] - u[mNumber]) + 130.0 * AstronomyMaths.sinD(m[mNumber] + u[mNumber]));
        mCoord.setHelioDist(19.21216 - (0.90154 + 0.00508 * mCTime) * AstronomyMaths.cosD(m[mNumber]) - mCTime * (0.02488 * AstronomyMaths.sinD(m[mNumber]) + 0.00103 * AstronomyMaths.sinD(2.0 * m[mNumber])) - 0.02121 * AstronomyMaths.cosD(2.0 * m[mNumber]) - 0.00585 * AstronomyMaths.cosD(m[Planets.Saturn] - 2.0 * m[mNumber]) - 0.00451 * AstronomyMaths.cosD(m[Planets.Jupiter] - m[mNumber]) + 0.00336 * AstronomyMaths.sinD(m[Planets.Saturn] - m[mNumber]) + 0.00198 * AstronomyMaths.sinD(m[Planets.Jupiter] - m[mNumber]) + 0.00118 * AstronomyMaths.cosD(m[Planets.Saturn] - 3.0 * m[mNumber]) + 0.00107 * AstronomyMaths.sinD(m[Planets.Saturn] - 2.0 * m[mNumber]) - 0.00081 * AstronomyMaths.cosD(3.0 * (m[mNumber] - m[Planets.Neptune])));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
