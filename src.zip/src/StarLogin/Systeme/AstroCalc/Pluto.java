/*
 * Pluto.java
 *
 * Created on 7 ao�t 2003, 07:11
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Pluto
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Pluto */
    public Pluto(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Pluto;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mTropicHelioLong;
        double mMoonNNode = chartEvent.getMeanNN();
        
        mTropicHelioLong = l[mNumber] * 3600.0 + (101577.0 + 200.0 * mCTime + 227.0 * mCTime * mCTime) * AstronomyMaths.sinD(m[mNumber]) + 15517.0 * AstronomyMaths.sinD(2.0 * m[mNumber]) - 3593.0 * AstronomyMaths.sinD(2.0 * u[mNumber]) + 3414.0 * AstronomyMaths.sinD(3.0 * m[mNumber]) - 2201.0 * AstronomyMaths.sinD(m[mNumber] - 2.0 * u[mNumber]) - 1871.0 * AstronomyMaths.sinD(m[mNumber] + 2.0 * u[mNumber]);
        mTropicHelioLong = mTropicHelioLong + 839.0 * AstronomyMaths.sinD(4.0 * m[mNumber]) - 757.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] + u[mNumber])) - 285.0 * AstronomyMaths.sinD(3.0 * m[mNumber] + 2.0 * u[mNumber]) + 218.0 * AstronomyMaths.sinD(2.0 * (m[mNumber] - u[mNumber]));
        mCoord.setHelioLat(57726.0 * AstronomyMaths.sinD(u[mNumber]) + 15257.0 * AstronomyMaths.sinD(m[mNumber] - u[mNumber]) + 14102.0 * AstronomyMaths.sinD(m[mNumber] + u[mNumber]) + 3870.0 * AstronomyMaths.sinD(2.0 * m[mNumber] + u[mNumber]) + 1138.0 * AstronomyMaths.sinD(3.0 * m[mNumber] + u[mNumber]) + 472.0 * AstronomyMaths.sinD(2.0 * m[mNumber] - u[mNumber]) + 353.0 * AstronomyMaths.sinD(4.0 * m[mNumber] + u[mNumber]) - 144.0 * AstronomyMaths.sinD(m[mNumber] - 3.0 * u[mNumber]) - 119.0 * AstronomyMaths.sinD(3.0 * u[mNumber]) - 111.0 * AstronomyMaths.sinD(m[mNumber] + 3.0 * u[mNumber]));
        mCoord.setHelioDist(40.74638 - 9.58235 * AstronomyMaths.cosD(m[mNumber]) - 1.16703 * AstronomyMaths.cosD(2.0 * m[mNumber]) - 0.22649 * AstronomyMaths.cosD(3.0 * m[mNumber]) - 0.04996 * AstronomyMaths.cosD(4.0 * m[mNumber]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mTropicHelioLong / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
