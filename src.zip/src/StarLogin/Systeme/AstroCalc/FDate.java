package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public final class FDate
{
    private String date;
    private String dateUS;
    private long day;
    private long month;
    private long year;
    private String signe = "";
    
    /** Creates new FDate */
    public FDate()
    {
        day = 1;
        month = 1;
        year = 0;
        date = "";
    }
    
    public FDate(String sData)
    {
        if (sData.equals("") || sData.equals("  /  /    ") || sData.equals("   /  /    ") || sData.equals("  /  /     ") || sData.equals("    -  -  ") || sData.equals("     -  -  ") || (sData == null))
        {
            sData = MainClass.SDATE_1900;
        }
        
        if (sData.contains(" ")||sData.startsWith("-")||sData.contains("/-"))
        {
            if (sData.contains(" "))
            {
                signe = " ";
                sData = sData.replace(" ", "");
            }
            else
            {
                signe = "-";
                if (sData.startsWith("-"))
                    sData = sData.substring(1);
                else
                    sData = sData.replace("/-", "/");
            }
        }
        String syear;
        String smonth;
        String sday;
        
        if (sData.contains("/"))
        {
            syear = sData.substring(6);
            smonth = sData.substring(3, 5);
            sday = sData.substring(0, 2);
        }
        else
        {
            syear = sData.substring(0, 4);
            smonth = sData.substring(5, 7);
            sday = sData.substring(8);
        }
        year = Long.valueOf(syear).longValue();
        month = Long.valueOf(smonth).longValue();
        day = Long.valueOf(sday).longValue();
        date = formatDate(day, month, year, signe);
        dateUS = formatDateUS(day, month, year, signe);
    }
    
    public String getFormatedDate()
    {
        if (MainClass.dateType == MainClass.DATEFR)
            return date;
        else
            return dateUS;
    }
    
    public FDate(double data)
    {
        year = (long)data;
        data = data - (double)year + 0.000000001;
        data = data * 100;
        month = (long)data;
        data = data - (double)month + 0.000000001;
        data = data * 100;
        day = (long)data;
        date = formatDate(day, month, year, signe);
        dateUS = formatDateUS(day, month, year, signe);
    }
    
    /*public FDate(long d, long m, long y)
    {
        day = d;
        month = m;
        year = y;
        date = formatDate(d, m, y, signe);
        dateUS = formatDateUS(d, m, y, signe);
    }*/
    
    public FDate(long d, long m, long y, String signe)
    {
        this.signe = signe;
        day = d;
        month = m;
        year = y;
        date = formatDate(d, m, y, signe);
        dateUS = formatDateUS(d, m, y, signe);
    }
    
    public long date2Day(String sData)
    {
        String sday;
        if (sData.contains("/"))
            sday = sData.substring(0, 2);
        else
            sday = sData.substring(8);
        int jour = Integer.valueOf(sday).intValue();
        return jour;
    }
    
    public long date2Month(String sData)
    {
        String smonth;
        if (sData.contains("/"))
            smonth = sData.substring(3, 5);
        else
            smonth = sData.substring(5, 7);
        int mois = Integer.valueOf(smonth).intValue();
        return mois;
    }
    
    public long date2Year(String sData)
    {
        String syear;
        if (sData.contains("/"))
            syear = sData.substring(6);
        else
            syear = sData.substring(0, 4);
        int annee = Integer.valueOf(syear).intValue();
        return annee;
    }
    
    public Date getDate2()
    {
        GregorianCalendar gc = new GregorianCalendar((int)year, (int)month-1, (int)day);
        Date dt = gc.getTime();
        return dt;
    }

    
    public String formatDate(double d)  //date under the form yyyy.mmdd comming from AstronomyMaths.julianToGregorian
    {
        if (month > 12)
        {
            month = 12;
        }
        if (day > 31)
        {
            day = 31;
        }
        else if (month == 2 && day > 29)
        {
            day = 29;
        }
        else if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30)
        {
            day = 30;
        }
        if (d<0)
        {
            signe = "-";
            d *= -1;
        }
        year = (long)d;
        double aux = (d - (double)year) * 100.0;
        month = (long)aux;
        aux = (aux - (double)month) * 100.0;
        day = (long)aux;
        return formatDate(day, month, year, signe);
    }
    
    public static String formatDate(long d, long m, long y, String signe)
    {
        String sYear;
        String sMonth;
        String sDay;
        
        if (m > 12)
        {
            m = 12;
        }
        if (d > 31)
        {
            d = 31;
        }
        else if (m == 2 && d > 29)
        {
            d = 29;
        }
        else if ((m == 4 || m == 6 || m == 9 || m == 11) && d > 30)
        {
            d = 30;
        }
        
        sYear = String.valueOf(y);
        sDay = String.valueOf(d);
        sMonth = String.valueOf(m);

        if (y<10) 
            sYear = "000" + sYear;
        else if (y<100) 
            sYear = "00" + sYear;
        else if (y<1000) 
            sYear = "0" + sYear;
        if (d<10) sDay = "0" + sDay;
        if (m<10) sMonth = "0" + sMonth;
        
        return signe.concat(sDay).concat("/").concat(sMonth).concat("/").concat(sYear);
    }
    
    public long getDay()
    {
        return day;
    }
    
    public long getMonth()
    {
        return month;
    }
    
    public String getSigne()
    {
        return signe;
    }
    
    public long getYear()
    {
        return year;
    }
    
    public String getDate()
    {
        return date;
    }

    public String getDateUS()
    {
        return dateUS;
    }
    
    public void setDay(long data)
    {
        day = data;
    }
    
    public void setMonth(long data)
    {
        month = data;
    }
    
    public void setYear(long data)
    {
        year = data;
    }
    
    public void setDate(String data)
    {
        date = data;
    }
    //date courante formatee US
    public static String curUsFormDate()
    {
        String date = MainClass.starLoginManager.getStringFieldValue("fenetre", "CURRENT_DATE", " WHERE ID=1");
        return date;
    }
    
    public static String curUsFormDateTime()
    {
        //get the time zone plus daylight saving time
        TimeZone timeZone = TimeZone.getDefault();
        //int timz = timeZone.getRawOffset() + timeZone.getDSTSavings();
        //double dblTZ = (double) timz / 3600000.0;

        //get the current date on the system
        GregorianCalendar gc = new GregorianCalendar(timeZone);
        int y = gc.get(Calendar.YEAR);
        int m = 1 + gc.get(Calendar.MONTH);
        int d = gc.get(Calendar.DAY_OF_MONTH);
        int h = gc.get(Calendar.HOUR_OF_DAY);
        int mn = gc.get(Calendar.MINUTE);
        int s = gc.get(Calendar.SECOND);
        FTime ft = new FTime(h,mn,s);
        return formatDateUS(d,m,y,"").concat("/").concat(ft.formatTime(h, m, s));
    }
    
    //date courante formatee FR
    public static String curFrFormDate()
    {
        String date = MainClass.starLoginManager.getStringFieldValue("fenetre", "CURRENT_DATE", " WHERE ID=1");
        return us2fr(date);
    }
    
    public static String fr2us(String sDate)
    {
        if (!sDate.contains("/"))
            return sDate;
        
        if (sDate.equals(""))
            return MainClass.SDATE_2000;
        
        String sgn = "";
        if (sDate.contains(" ")||sDate.contains("-"))
        {
            if (sDate.contains(" "))
                sgn = " ";
            else
                sgn = "-";
            sDate = sDate.replace(" ", "").replace("-", "");
        }
        
        int pos = sDate.indexOf("/");
        String annee = "2000";
        String mois = "01";
        String jour = "01";
        
        if (pos == 2)
        {
            jour = sDate.substring(0, pos);
            sDate = sDate.substring(pos + 1);
            pos = sDate.indexOf("/");
            if (pos == 2)
            {
                mois = sDate.substring(0, pos);
                annee = sDate.substring(pos + 1);
            }
        }
        return sgn.concat(annee).concat("-").concat(mois).concat("-").concat(jour);
    }
    
    public static String us2fr(String sDate)
    {
        if (sDate.contains("/"))
            return sDate;
        
        if (sDate.equals(""))
            return "01/01/2000";
        
        String sgn = "";
        if (sDate.startsWith(" ")||sDate.startsWith("-"))
        {
            sgn = sDate.substring(0, 1);
            sDate = sDate.substring(1);
        }
        
        int pos = sDate.indexOf("-");
        String annee = "2000";
        String mois = "01";
        String jour = "01";
        
        if (pos == 4)
        {
            annee = sDate.substring(0, pos);
            sDate = sDate.substring(pos + 1);
            pos = sDate.indexOf("-");
            if (pos == 2)
            {
                mois = sDate.substring(0, pos);
                jour = sDate.substring(pos + 1);
            }
        }
        return sgn.concat(jour).concat("/").concat(mois).concat("/").concat(annee);
    }

    public static String formatDateUS(long d, long m, long y, String signe)
    {
        String sYear;
        String sMonth;
        String sDay;

        if (m > 12)
        {
            m = 12;
        }
        else if (m < 1)
            m = 1;

        if (d > 31)
        {
            d = 31;
        }
        else if ((m == 2) && (d > 29))
        {
            d = 29;
        }
        else if (((m == 4) || (m == 6) || (m == 9) || (m == 11)) && (d > 30))
        {
            d = 30;
        }
        else if (d < 1)
            d = 1;

        sYear = String.valueOf(y);
        sDay = String.valueOf(d);
        sMonth = String.valueOf(m);

        if (y<10) 
            sYear = "000" + sYear;
        else if (y<100) 
            sYear = "00" + sYear;
        else if (y<1000) 
            sYear = "0" + sYear;
        if (d<10) sDay = "0" + sDay;
        if (m<10) sMonth = "0" + sMonth;
        
        return signe.concat(sYear).concat("-").concat(sMonth).concat("-").concat(sDay);
    }

    public static String formatDate2(long d, long m, long y)
    {
        String sYear;
        String sMonth;
        String sDay;

        if (m > 12)
        {
            m = 12;
        }

        if (d > 31)
        {
            d = 31;
        }
        else if ((m == 2) && (d > 29))
        {
            d = 29;
        }
        else if (((m == 4) || (m == 6) || (m == 9) || (m == 11)) && (d > 30))
        {
            d = 30;
        }

        sYear = String.valueOf(y);
        sDay = String.valueOf(d);

        if (d < 10)
        {
            sDay = "0" + sDay;
        }

        sMonth = String.valueOf(m);

        if (m < 10)
        {
            sMonth = "0" + sMonth;
        }

        return sYear.concat(sMonth).concat(sDay);
    }
}
