package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Enum.CalendarsKinds;
import StarLogin.Systeme.Enum.LocalDateFormat;
import StarLogin.Systeme.Enum.Months;
import StarLogin.Systeme.Enum.USWeekDays;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */

//For the Jewish calendar in this module (original code in C):
//CopyRight 1993-1995, Scott E. Lee, all Right$$s reserved.
//Permission granted to use, copy, modify, distribute and sell so long as
//the above copyRight and this permission statement are retained in all copies.
public class Calendars
{
    
    //For the Jewish calendar in this module (original code in C):
    //CopyRight 1993-1995, Scott E. Lee, all Right$$s reserved.
    //Permission granted to use, copy, modify, distribute && sell so long as
    //the above copyRight && this permission statement are retained in all copies.
    private final int HALAKIM_PER_HOUR = 1080;
    private final int HALAKIM_PER_DAY = 25920;
    private final int HALAKIM_PER_LUNAR_CYCLE = 765433; //(29 * HALAKIM_PER_DAY) + 13753
    private final int HALAKIM_PER_METONIC_CYCLE = HALAKIM_PER_LUNAR_CYCLE * (12 * 19 + 7);
    private final int SDN_OFFSET = 347999; //347997
    private final double NEW_MOON_OF_CREATION = 31524.0;
    private final int NOON = 18 * HALAKIM_PER_HOUR;
    private final int AM3_11_20 = (9 * HALAKIM_PER_HOUR) + 204;
    private final int AM9_32_43 = (15 * HALAKIM_PER_HOUR) + 589;
    
    private int monthsPerYear[] = new int[19];
    private int yearOffset[] = new int[19];
    //------------------------------------------------------
    
    private int num_row;
    private String valeur;
    
    //CONSTANTS
    private final int MAYA_ORIGIN = 584283;
    
    private final int PREMIER_CALENDRIER = 0;
    private final int DERNIER_CALENDRIER = 18;
    private String calendrier[] = new String[DERNIER_CALENDRIER+1];
    
    //calendar parameters
    private int J0[] = new int[DERNIER_CALENDRIER+1];
    private int y[] = new int[DERNIER_CALENDRIER+1];
    private int j[] = new int[DERNIER_CALENDRIER+1];
    private int m[] = new int[DERNIER_CALENDRIER+1];
    private int n[] = new int[DERNIER_CALENDRIER+1];
    private int r[] = new int[DERNIER_CALENDRIER+1];
    private int p[] = new int[DERNIER_CALENDRIER+1];
    private int q[] = new int[DERNIER_CALENDRIER+1];
    private int v[] = new int[DERNIER_CALENDRIER+1];
    private int u[] = new int[DERNIER_CALENDRIER+1];
    private double s[] = new double[DERNIER_CALENDRIER+1];
    private double t[] = new double[DERNIER_CALENDRIER+1];
    private double w[] = new double[DERNIER_CALENDRIER+1];
    private String calendarName[][] = new String[DERNIER_CALENDRIER+1][15];
    private String mayaDay[] = new String[20];
    private String mayaMonth[] = new String[19];
    
    /** Creates a new instance of Calendars */
    public Calendars()
    {
        for (int i=0; i <= DERNIER_CALENDRIER; i++)
        {
            for (int ii = 0; ii <= 14; ii++)
            {
                calendarName[i][ii] = "";
            }
        }
        
        //maya
        mayaDay[0] = "Ahau";
        mayaDay[1] = "Imix";
        mayaDay[2] = "Ik";
        mayaDay[3] = "Akeal";
        mayaDay[4] = "Kan";
        mayaDay[5] = "Chicchen";
        mayaDay[6] = "Cimi";
        mayaDay[7] = "Manik";
        mayaDay[8] = "Lamat";
        mayaDay[9] = "Moluc";
        mayaDay[10] = "Oc";
        mayaDay[11] = "Chuen";
        mayaDay[12] = "Eb";
        mayaDay[13] = "Ben";
        mayaDay[14] = "Ix";
        mayaDay[15] = "Men";
        mayaDay[16] = "ib";
        mayaDay[17] = "Cabran";
        mayaDay[18] = "Einab";
        mayaDay[19] = "Cauac";
        
        mayaMonth[0] = "Pop";
        mayaMonth[1] = "Uo";
        mayaMonth[2] = "Zip";
        mayaMonth[3] = "Zotz";
        mayaMonth[4] = "Tzec";
        mayaMonth[5] = "Xul";
        mayaMonth[6] = "Yaxkin";
        mayaMonth[7] = "Mol";
        mayaMonth[8] = "Chen";
        mayaMonth[9] = "Yax";
        mayaMonth[10] = "Zac";
        mayaMonth[11] = "Ceh";
        mayaMonth[12] = "Mac";
        mayaMonth[13] = "Kankin";
        mayaMonth[14] = "Muan";
        mayaMonth[15] = "Pax";
        mayaMonth[16] = "Kayab";
        mayaMonth[17] = "Cumhu";
        mayaMonth[18] = "Uayeb";
        
        //jewish
        calendarName[CalendarsKinds.ISRAELITE][1] = "Tishri";
        calendarName[CalendarsKinds.ISRAELITE][2] = "Heshvan";
        calendarName[CalendarsKinds.ISRAELITE][3] = "Kislev";
        calendarName[CalendarsKinds.ISRAELITE][4] = "Tevet";
        calendarName[CalendarsKinds.ISRAELITE][5] = "Shevat";
        calendarName[CalendarsKinds.ISRAELITE][6] = "AdarI";
        calendarName[CalendarsKinds.ISRAELITE][7] = "AdarII";
        calendarName[CalendarsKinds.ISRAELITE][8] = "Nisan";
        calendarName[CalendarsKinds.ISRAELITE][9] = "Iyyar";
        calendarName[CalendarsKinds.ISRAELITE][10] = "Sivan";
        calendarName[CalendarsKinds.ISRAELITE][11] = "Tammuz";
        calendarName[CalendarsKinds.ISRAELITE][12] = "Av";
        calendarName[CalendarsKinds.ISRAELITE][13] = "Elul";
        
        //muslim
        for (int i = CalendarsKinds.ISLAMIQUE1 ; i <= CalendarsKinds.ISLAMIQUE4; i++)
        {
            calendarName[i][1] = "Moharram";
            calendarName[i][2] = "Safar";
            calendarName[i][3] = "Rabi I";
            calendarName[i][4] = "Rabi II";
            calendarName[i][5] = "Djoumada I";
            calendarName[i][6] = "Djoumada II";
            calendarName[i][7] = "Radjad";
            calendarName[i][8] = "Sa'abar";
            calendarName[i][9] = "Ramadan";
            calendarName[i][10] = "Sawal";
            calendarName[i][11] = "Dzou'l kada";
            calendarName[i][12] = "Dzou'l hidja";
        }
        
        //French republican
        calendarName[CalendarsKinds.REPUBLICAIN][1] = "Vendemiaire";
        calendarName[CalendarsKinds.REPUBLICAIN][2] = "Brumaire";
        calendarName[CalendarsKinds.REPUBLICAIN][3] = "Frimaire";
        calendarName[CalendarsKinds.REPUBLICAIN][4] = "Nivose";
        calendarName[CalendarsKinds.REPUBLICAIN][5] = "Pluviose";
        calendarName[CalendarsKinds.REPUBLICAIN][6] = "Ventose";
        calendarName[CalendarsKinds.REPUBLICAIN][7] = "Germinal";
        calendarName[CalendarsKinds.REPUBLICAIN][8] = "Floreal";
        calendarName[CalendarsKinds.REPUBLICAIN][9] = "Prairial";
        calendarName[CalendarsKinds.REPUBLICAIN][10] = "Messidor";
        calendarName[CalendarsKinds.REPUBLICAIN][11] = "Thermidor";
        calendarName[CalendarsKinds.REPUBLICAIN][12] = "Fructidor";
        
        //Egyptian
        calendarName[CalendarsKinds.EGYPTIEN][1] = "Thoth";
        calendarName[CalendarsKinds.EGYPTIEN][2] = "Paophi";
        calendarName[CalendarsKinds.EGYPTIEN][3] = "Athyr";
        calendarName[CalendarsKinds.EGYPTIEN][4] = "Choxxx";
        calendarName[CalendarsKinds.EGYPTIEN][5] = "Tybi";
        calendarName[CalendarsKinds.EGYPTIEN][6] = "Mechir";
        calendarName[CalendarsKinds.EGYPTIEN][7] = "Phanenoth";
        calendarName[CalendarsKinds.EGYPTIEN][8] = "Pharmouti";
        calendarName[CalendarsKinds.EGYPTIEN][9] = "Pachon";
        calendarName[CalendarsKinds.EGYPTIEN][10] = "Paynee";
        calendarName[CalendarsKinds.EGYPTIEN][11] = "Epiphi";
        calendarName[CalendarsKinds.EGYPTIEN][12] = "Mesori";
        
        //Egyptian
        calendarName[CalendarsKinds.COPTE][1] = "Tout";
        calendarName[CalendarsKinds.COPTE][2] = "Babah";
        calendarName[CalendarsKinds.COPTE][3] = "Hatour";
        calendarName[CalendarsKinds.COPTE][4] = "Keihak";
        calendarName[CalendarsKinds.COPTE][5] = "Toubah";
        calendarName[CalendarsKinds.COPTE][6] = "Amchir";
        calendarName[CalendarsKinds.COPTE][7] = "Barmahat";
        calendarName[CalendarsKinds.COPTE][8] = "Barmoudah";
        calendarName[CalendarsKinds.COPTE][9] = "Bachnas";
        calendarName[CalendarsKinds.COPTE][10] = "Bou'nah";
        calendarName[CalendarsKinds.COPTE][11] = "Abib";
        calendarName[CalendarsKinds.COPTE][12] = "Masari";
        
        //gregorian
        for (int i = CalendarsKinds.JULIEN1 ; i <= CalendarsKinds.GREGORIEN; i++)
        {
            for (int ii = 0 ; ii<12; ii++)
            {
                calendarName[i][ii+1] = Months.getMonthName(ii);
            }
        }
        
        //Persian
        calendarName[CalendarsKinds.PERSE][1] = "farvardin";
        calendarName[CalendarsKinds.PERSE][2] = "ordibehesht";
        calendarName[CalendarsKinds.PERSE][3] = "khordad";
        calendarName[CalendarsKinds.PERSE][4] = "tir";
        calendarName[CalendarsKinds.PERSE][5] = "mordad";
        calendarName[CalendarsKinds.PERSE][6] = "shahrivar";
        calendarName[CalendarsKinds.PERSE][7] = "mehr";
        calendarName[CalendarsKinds.PERSE][8] = "Aban";
        calendarName[CalendarsKinds.PERSE][9] = "Azar";
        calendarName[CalendarsKinds.PERSE][10] = "day";
        calendarName[CalendarsKinds.PERSE][11] = "bahman";
        calendarName[CalendarsKinds.PERSE][12] = "esf&+";
        
        //calendar parameters
        //-------------------
        J0[CalendarsKinds.EGYPTIEN] = 1448638;
        y[CalendarsKinds.EGYPTIEN] = 3968;
        j[CalendarsKinds.EGYPTIEN] = 47;
        m[CalendarsKinds.EGYPTIEN] = 1;
        n[CalendarsKinds.EGYPTIEN] = 13;
        r[CalendarsKinds.EGYPTIEN] = 1;
        p[CalendarsKinds.EGYPTIEN] = 365;
        q[CalendarsKinds.EGYPTIEN] = 0;
        v[CalendarsKinds.EGYPTIEN] = 0;
        u[CalendarsKinds.EGYPTIEN] = 1;
        s[CalendarsKinds.EGYPTIEN] = 30;
        t[CalendarsKinds.EGYPTIEN] = 0;
        w[CalendarsKinds.EGYPTIEN] = 0;
        
        J0[CalendarsKinds.ARMENIEN] = 1922868;
        y[CalendarsKinds.ARMENIEN] = 5268;
        j[CalendarsKinds.ARMENIEN] = 317;
        m[CalendarsKinds.ARMENIEN] = 1;
        n[CalendarsKinds.ARMENIEN] = 13;
        r[CalendarsKinds.ARMENIEN] = 1;
        p[CalendarsKinds.ARMENIEN] = 365;
        q[CalendarsKinds.ARMENIEN] = 0;
        v[CalendarsKinds.ARMENIEN] = 0;
        u[CalendarsKinds.ARMENIEN] = 1;
        s[CalendarsKinds.ARMENIEN] = 30;
        t[CalendarsKinds.ARMENIEN] = 0;
        w[CalendarsKinds.ARMENIEN] = 0;
        
        J0[CalendarsKinds.IEZDEJERD] = 1952068;
        y[CalendarsKinds.IEZDEJERD] = 5348;
        j[CalendarsKinds.IEZDEJERD] = 317;
        m[CalendarsKinds.IEZDEJERD] = 1;
        n[CalendarsKinds.IEZDEJERD] = 13;
        r[CalendarsKinds.IEZDEJERD] = 1;
        p[CalendarsKinds.IEZDEJERD] = 365;
        q[CalendarsKinds.IEZDEJERD] = 0;
        v[CalendarsKinds.IEZDEJERD] = 0;
        u[CalendarsKinds.IEZDEJERD] = 1;
        s[CalendarsKinds.IEZDEJERD] = 30;
        t[CalendarsKinds.IEZDEJERD] = 0;
        w[CalendarsKinds.IEZDEJERD] = 0;
        
        J0[CalendarsKinds.PERSE] = 1952063;
        y[CalendarsKinds.PERSE] = 5348;
        j[CalendarsKinds.PERSE] = 77;
        m[CalendarsKinds.PERSE] = 10;
        n[CalendarsKinds.PERSE] = 13;
        r[CalendarsKinds.PERSE] = 1;
        p[CalendarsKinds.PERSE] = 365;
        q[CalendarsKinds.PERSE] = 0;
        v[CalendarsKinds.PERSE] = 0;
        u[CalendarsKinds.PERSE] = 1;
        s[CalendarsKinds.PERSE] = 30;
        t[CalendarsKinds.PERSE] = 0;
        w[CalendarsKinds.PERSE] = 0;
        
        J0[CalendarsKinds.ALEXANDRE] = -284654;
        y[CalendarsKinds.ALEXANDRE] = -780;
        j[CalendarsKinds.ALEXANDRE] = 124;
        m[CalendarsKinds.ALEXANDRE] = 1;
        n[CalendarsKinds.ALEXANDRE] = 12;
        r[CalendarsKinds.ALEXANDRE] = 4;
        p[CalendarsKinds.ALEXANDRE] = 1461;
        q[CalendarsKinds.ALEXANDRE] = 0;
        v[CalendarsKinds.ALEXANDRE] = 3;
        u[CalendarsKinds.ALEXANDRE] = 1;
        s[CalendarsKinds.ALEXANDRE] = 30;
        t[CalendarsKinds.ALEXANDRE] = 0;
        w[CalendarsKinds.ALEXANDRE] = 0;
        
        J0[CalendarsKinds.ETHIOPIEN] = 1724221;
        y[CalendarsKinds.ETHIOPIEN] = 4720;
        j[CalendarsKinds.ETHIOPIEN] = 124;
        m[CalendarsKinds.ETHIOPIEN] = 1;
        n[CalendarsKinds.ETHIOPIEN] = 12;
        r[CalendarsKinds.ETHIOPIEN] = 4;
        p[CalendarsKinds.ETHIOPIEN] = 1461;
        q[CalendarsKinds.ETHIOPIEN] = 0;
        v[CalendarsKinds.ETHIOPIEN] = 3;
        u[CalendarsKinds.ETHIOPIEN] = 1;
        s[CalendarsKinds.ETHIOPIEN] = 30;
        t[CalendarsKinds.ETHIOPIEN] = 0;
        w[CalendarsKinds.ETHIOPIEN] = 0;
        
        J0[CalendarsKinds.COPTE] = 1825030;
        y[CalendarsKinds.COPTE] = 4996;
        j[CalendarsKinds.COPTE] = 124;
        m[CalendarsKinds.COPTE] = 1;
        n[CalendarsKinds.COPTE] = 12;
        r[CalendarsKinds.COPTE] = 4;
        p[CalendarsKinds.COPTE] = 1461;
        q[CalendarsKinds.COPTE] = 0;
        v[CalendarsKinds.COPTE] = 3;
        u[CalendarsKinds.COPTE] = 1;
        s[CalendarsKinds.COPTE] = 30;
        t[CalendarsKinds.COPTE] = 0;
        w[CalendarsKinds.COPTE] = 0;
        
        J0[CalendarsKinds.MACEDONIEN] = 1607709;
        y[CalendarsKinds.MACEDONIEN] = 4405;
        j[CalendarsKinds.MACEDONIEN] = 1401;
        m[CalendarsKinds.MACEDONIEN] = 7;
        n[CalendarsKinds.MACEDONIEN] = 12;
        r[CalendarsKinds.MACEDONIEN] = 4;
        p[CalendarsKinds.MACEDONIEN] = 1461;
        q[CalendarsKinds.MACEDONIEN] = 0;
        v[CalendarsKinds.MACEDONIEN] = 3;
        u[CalendarsKinds.MACEDONIEN] = 5;
        s[CalendarsKinds.MACEDONIEN] = 153;
        t[CalendarsKinds.MACEDONIEN] = 2;
        w[CalendarsKinds.MACEDONIEN] = 2;
        
        J0[CalendarsKinds.SYRIEN] = 1607739;
        y[CalendarsKinds.SYRIEN] = 4405;
        j[CalendarsKinds.SYRIEN] = 1401;
        m[CalendarsKinds.SYRIEN] = 6;
        n[CalendarsKinds.SYRIEN] = 12;
        r[CalendarsKinds.SYRIEN] = 4;
        p[CalendarsKinds.SYRIEN] = 1461;
        q[CalendarsKinds.SYRIEN] = 0;
        v[CalendarsKinds.SYRIEN] = 3;
        u[CalendarsKinds.SYRIEN] = 5;
        s[CalendarsKinds.SYRIEN] = 153;
        t[CalendarsKinds.SYRIEN] = 2;
        w[CalendarsKinds.SYRIEN] = 2;
        
        J0[CalendarsKinds.JULIEN1] = 1704622;
        y[CalendarsKinds.JULIEN1] = 4712;
        j[CalendarsKinds.JULIEN1] = 329;
        m[CalendarsKinds.JULIEN1] = 3;
        n[CalendarsKinds.JULIEN1] = 12;
        r[CalendarsKinds.JULIEN1] = 3;
        p[CalendarsKinds.JULIEN1] = 1096;
        q[CalendarsKinds.JULIEN1] = 1;
        v[CalendarsKinds.JULIEN1] = 1;
        u[CalendarsKinds.JULIEN1] = 5;
        s[CalendarsKinds.JULIEN1] = 153;
        t[CalendarsKinds.JULIEN1] = 2;
        w[CalendarsKinds.JULIEN1] = 2;
        
        J0[CalendarsKinds.JULIEN2] = 1718505;
        y[CalendarsKinds.JULIEN2] = 4716;
        j[CalendarsKinds.JULIEN2] = 221;
        m[CalendarsKinds.JULIEN2] = 3;
        n[CalendarsKinds.JULIEN2] = 12;
        r[CalendarsKinds.JULIEN2] = 1;
        p[CalendarsKinds.JULIEN2] = 365;
        q[CalendarsKinds.JULIEN2] = 0;
        v[CalendarsKinds.JULIEN2] = 0;
        u[CalendarsKinds.JULIEN2] = 5;
        s[CalendarsKinds.JULIEN2] = 153;
        t[CalendarsKinds.JULIEN2] = 2;
        w[CalendarsKinds.JULIEN2] = 2;
        
        J0[CalendarsKinds.JULIEN_ROMAIN] = 1721424;
        y[CalendarsKinds.JULIEN_ROMAIN] = 4716;
        j[CalendarsKinds.JULIEN_ROMAIN] = 1401;
        m[CalendarsKinds.JULIEN_ROMAIN] = 3;
        n[CalendarsKinds.JULIEN_ROMAIN] = 12;
        r[CalendarsKinds.JULIEN_ROMAIN] = 4;
        p[CalendarsKinds.JULIEN_ROMAIN] = 1461;
        q[CalendarsKinds.JULIEN_ROMAIN] = 0;
        v[CalendarsKinds.JULIEN_ROMAIN] = 3;
        u[CalendarsKinds.JULIEN_ROMAIN] = 5;
        s[CalendarsKinds.JULIEN_ROMAIN] = 153;
        t[CalendarsKinds.JULIEN_ROMAIN] = 2;
        w[CalendarsKinds.JULIEN_ROMAIN] = 2;
        
        J0[CalendarsKinds.GREGORIEN] = 1721426;
        y[CalendarsKinds.GREGORIEN] = 4716;
        j[CalendarsKinds.GREGORIEN] = 1401;
        m[CalendarsKinds.GREGORIEN] = 3;
        n[CalendarsKinds.GREGORIEN] = 12;
        r[CalendarsKinds.GREGORIEN] = 4;
        p[CalendarsKinds.GREGORIEN] = 1461;
        q[CalendarsKinds.GREGORIEN] = 0;
        v[CalendarsKinds.GREGORIEN] = 3;
        u[CalendarsKinds.GREGORIEN] = 5;
        s[CalendarsKinds.GREGORIEN] = 153;
        t[CalendarsKinds.GREGORIEN] = 2;
        w[CalendarsKinds.GREGORIEN] = 2;
        
        J0[CalendarsKinds.ISLAMIQUE1] = 1948439;
        y[CalendarsKinds.ISLAMIQUE1] = 5519;
        j[CalendarsKinds.ISLAMIQUE1] = 7665;
        m[CalendarsKinds.ISLAMIQUE1] = 1;
        n[CalendarsKinds.ISLAMIQUE1] = 12;
        r[CalendarsKinds.ISLAMIQUE1] = 30;
        p[CalendarsKinds.ISLAMIQUE1] = 10631;
        q[CalendarsKinds.ISLAMIQUE1] = 14;
        v[CalendarsKinds.ISLAMIQUE1] = 15;
        u[CalendarsKinds.ISLAMIQUE1] = 2;
        s[CalendarsKinds.ISLAMIQUE1] = 59.02;
        t[CalendarsKinds.ISLAMIQUE1] = 1.02;
        w[CalendarsKinds.ISLAMIQUE1] = 0.2;
        
        J0[CalendarsKinds.ISLAMIQUE2] = 1948439;
        y[CalendarsKinds.ISLAMIQUE2] = 5519;
        j[CalendarsKinds.ISLAMIQUE2] = 7665;
        m[CalendarsKinds.ISLAMIQUE2] = 1;
        n[CalendarsKinds.ISLAMIQUE2] = 12;
        r[CalendarsKinds.ISLAMIQUE2] = 30;
        p[CalendarsKinds.ISLAMIQUE2] = 10631;
        q[CalendarsKinds.ISLAMIQUE2] = 15;
        v[CalendarsKinds.ISLAMIQUE2] = 14;
        u[CalendarsKinds.ISLAMIQUE2] = 2;
        s[CalendarsKinds.ISLAMIQUE2] = 59.02;
        t[CalendarsKinds.ISLAMIQUE2] = 1.02;
        w[CalendarsKinds.ISLAMIQUE2] = 0.2;
        
        J0[CalendarsKinds.ISLAMIQUE3] = 1948440;
        y[CalendarsKinds.ISLAMIQUE3] = 5519;
        j[CalendarsKinds.ISLAMIQUE3] = 7664;
        m[CalendarsKinds.ISLAMIQUE3] = 1;
        n[CalendarsKinds.ISLAMIQUE3] = 12;
        r[CalendarsKinds.ISLAMIQUE3] = 30;
        p[CalendarsKinds.ISLAMIQUE3] = 10631;
        q[CalendarsKinds.ISLAMIQUE3] = 14;
        v[CalendarsKinds.ISLAMIQUE3] = 15;
        u[CalendarsKinds.ISLAMIQUE3] = 2;
        s[CalendarsKinds.ISLAMIQUE3] = 59.02;
        t[CalendarsKinds.ISLAMIQUE3] = 1.02;
        w[CalendarsKinds.ISLAMIQUE3] = 0.2;
        
        J0[CalendarsKinds.ISLAMIQUE4] = 1948440;
        y[CalendarsKinds.ISLAMIQUE4] = 5519;
        j[CalendarsKinds.ISLAMIQUE4] = 7664;
        m[CalendarsKinds.ISLAMIQUE4] = 1;
        n[CalendarsKinds.ISLAMIQUE4] = 12;
        r[CalendarsKinds.ISLAMIQUE4] = 30;
        p[CalendarsKinds.ISLAMIQUE4] = 10631;
        q[CalendarsKinds.ISLAMIQUE4] = 15;
        v[CalendarsKinds.ISLAMIQUE4] = 14;
        u[CalendarsKinds.ISLAMIQUE4] = 2;
        s[CalendarsKinds.ISLAMIQUE4] = 59.02;
        t[CalendarsKinds.ISLAMIQUE4] = 1.02;
        w[CalendarsKinds.ISLAMIQUE4] = 0.2;
        
        J0[CalendarsKinds.REPUBLICAIN] = 2375840;
        y[CalendarsKinds.REPUBLICAIN] = 6504;
        j[CalendarsKinds.REPUBLICAIN] = 111;
        m[CalendarsKinds.REPUBLICAIN] = 1;
        n[CalendarsKinds.REPUBLICAIN] = 13;
        r[CalendarsKinds.REPUBLICAIN] = 4;
        p[CalendarsKinds.REPUBLICAIN] = 1461;
        q[CalendarsKinds.REPUBLICAIN] = 0;
        v[CalendarsKinds.REPUBLICAIN] = 3;
        u[CalendarsKinds.REPUBLICAIN] = 1;
        s[CalendarsKinds.REPUBLICAIN] = 30;
        t[CalendarsKinds.REPUBLICAIN] = 0;
        w[CalendarsKinds.REPUBLICAIN] = 0;
        
        //Jewish:
        monthsPerYear[0] = 12;
        monthsPerYear[1] = 12;
        monthsPerYear[2] = 13;
        monthsPerYear[3] = 12;
        monthsPerYear[4] = 12;
        monthsPerYear[5] = 13;
        monthsPerYear[6] = 12;
        monthsPerYear[7] = 13;
        monthsPerYear[8] = 12;
        monthsPerYear[9] = 12;
        monthsPerYear[10] = 13;
        monthsPerYear[11] = 12;
        monthsPerYear[12] = 12;
        monthsPerYear[13] = 13;
        monthsPerYear[14] = 12;
        monthsPerYear[15] = 12;
        monthsPerYear[16] = 13;
        monthsPerYear[17] = 12;
        monthsPerYear[18] = 13;
        
        yearOffset[0] = 0;
        yearOffset[1] = 12;
        yearOffset[2] = 24;
        yearOffset[3] = 37;
        yearOffset[4] = 49;
        yearOffset[5] = 61;
        yearOffset[6] = 74;
        yearOffset[7] = 86;
        yearOffset[8] = 99;
        yearOffset[9] = 111;
        yearOffset[10] = 123;
        yearOffset[11] = 136;
        yearOffset[12] = 148;
        yearOffset[13] = 160;
        yearOffset[14] = 173;
        yearOffset[15] = 185;
        yearOffset[16] = 197;
        yearOffset[17] = 210;
        yearOffset[18] = 222;
    }
    
    
    
    //=====================================================================
    //conversion from a date to Julian Days
    //input  : c1 : number of the initial calendar
    //         j1 : day in the initial calendar
    //         m1 : month in the initial calendar
    //         a1 : year in the initial calendar
    //return      : corresponding Julian Day
    //=====================================================================
    public double calendrier1VersJulien(int c1, int j1, int m1, int a1)
    {
        //year
        int a2;
        //month
        int m2;
        //day
        int j2;
        //Julian Day
        double jj;
        //=====================================================================
        
        if (c1 == CalendarsKinds.ISRAELITE)
        {
            return jewishToSdn(a1, m1, j1);
        }
        
        else if (c1 != CalendarsKinds.MAYA_LONG && c1 != CalendarsKinds.MAYA_TH)
        {
            a2 = a1 + y[c1] - (int)((n[c1] + m[c1] - 1 - m1) / n[c1]);
            m2 = m1 - m[c1] - n[c1] * (int)((m1 - m[c1]) / n[c1]);
            j2 = j1 - 1;
            
            //Calculation of the Julian Day
            jj = (int)((p[c1] * a2 + q[c1]) / r[c1]) + (int)((s[c1] * m2 + t[c1]) / u[c1]) + j2 - j[c1];
            
            if (c1 == CalendarsKinds.GREGORIEN)
            {
                jj = jj - (int)(0.75 * (int)((a2 + 184) / 100)) + 38;
            }
            return jj;
        }
        return -9999.0;
    }
    
    //=====================================================================
    //conversion from Julian Day to a given calendar
    //input  : c2 : number of the calendar
    //input  : jj : Julian Day
    //return      : date in the given calendar
    //=====================================================================
    public String julienVersCalendrier2(int c2, double jj)
    {
        //year
        int a2=0;
        //month
        int m2=0;
        //day
        int j2=0;
        //auxiliary variable
        double aux;
        
        int maya_day;
        int mj;
        int mk;
        int mj1;
        int mj2;
        int mj3;
        int mj4;
        int baktun;
        int katun;
        int tun;
        int uinal;
        int kin;
        int x;
        String strg;
        
        if (c2 == CalendarsKinds.ISRAELITE)
        {
            ArrayList result = sdnToJewish((int)(jj));
            if (result!=null)
            {
                a2 = ((Integer)result.get(0)).intValue();
                m2 = ((Integer)result.get(1)).intValue();
                j2 = ((Integer)result.get(2)).intValue();
                
                if (MainClass.dateType == MainClass.DATEFR)
                {
                    return "" + j2 + " / " + m2 + "(" + calendarName[c2][m2] + ") / " + a2;
                }
                else
                {
                    return "" + a2 + " - " + m2 + "(" + calendarName[c2][m2] + ") - " + j2;
                }
            }
        }
        
        else if (c2 == CalendarsKinds.MAYA_LONG)
        {
            //Tzolkin && Haab
            maya_day = (int)jj - MAYA_ORIGIN;
            mj = AstronomyMaths.modulo(maya_day, 260);
            if (mj < 0) mj += 260;
            mk = AstronomyMaths.modulo(maya_day, 365);
            if (mk < 0) mk += 365;
            
            if (mk < 17) mk += 365;
            mj1 = AstronomyMaths.modulo(mj, 13);
            mj2 = AstronomyMaths.modulo(mj, 20);
            mj3 = (mk - 17) / 20;
            mj4 = mk - 20 * mj3 - 17;
            
            if (mj1 > 9) mj1 -= 13;
            //dates_calendriers.Row = CalendarsKinds.MAYA_TH + 1;
            
            //Long Cycle
            baktun = maya_day / 144000;
            x = maya_day - 144000 * baktun;
            katun = x / 7200;
            x = x - 7200 * katun;
            tun = x / 360;
            x = x - 360 * tun;
            uinal = x / 20;
            kin = x - 20 * uinal;
            strg = new Integer(mj1 + 4).toString() + " " + mayaDay[mj2] + " " + mj4 + " " + mayaMonth[mj3]+ "\r\n" + baktun + " baktun. " + katun + " katun. " + tun + " tun. " + uinal + " uinal. " + kin + " kin";
            
            return strg;
        }
        
        else if (c2 != CalendarsKinds.MAYA_TH)
        {
            //calculation of the date in the given calendar
            j2 = (int)jj + j[c2];
            
            if (c2 == CalendarsKinds.GREGORIEN)
            {
                j2 = j2 + (int)(0.75 * (int)((jj + 68569) / 36524.25)) - 38;
            }
            aux = r[c2] * j2 + v[c2];
            a2 = (int)(aux / p[c2]);
            aux = (int)((aux - p[c2] * a2) / r[c2]);
            aux = u[c2] * aux + w[c2];
            m2 = (int)(aux / s[c2]);
            j2 = (int)((aux - s[c2] * m2) / u[c2]);
            j2 = j2 + 1;
            aux = m2 + m[c2] - 1;
            m2 = 1 + (int)aux - n[c2] * (int)(aux / n[c2]);
            a2 = a2 - y[c2] + (int)((n[c2] + m[c2] - 1 - m2) / n[c2]);
        
            if ((c2 >= CalendarsKinds.ARMENIEN && c2 <= CalendarsKinds.SYRIEN) && (c2 != CalendarsKinds.COPTE) && (c2 != CalendarsKinds.PERSE))
            {
                if (MainClass.dateType == MainClass.DATEFR)
                {
                    return new Integer(m2).toString() + " / " + j2 + " / " + a2;
                }
                else
                {
                    return  a2 + " - " + m2 + " - " + new Integer(j2).toString();
                }
            }
            else if (c2 != CalendarsKinds.MAYA_LONG && c2 != CalendarsKinds.MAYA_TH)
            {
                if (MainClass.dateType == MainClass.DATEFR)
                {
                    return "" + j2 + " / " + m2 + "(" + calendarName[c2][m2] + ") / " + a2;
                }
                else
                {
                    return "" + a2 + " - " + m2 + "(" + calendarName[c2][m2] + ") - " + j2;
                }
            }
        }
        return "";
    }
    
    //Conversion form Maya Long Cycle to Julian Days
    public double mayaLongToJulian(int baktun, int katun, int tun, int uinal, int kin)
    {
        //Julian Day
        double jj;
        
        jj = kin + 20 * uinal + 360 * tun + 7200 * katun + 144000 * baktun;
        return jj + MAYA_ORIGIN;
    }
    
    //=====================================================================
    // Given the year within the 19 year metonic cycle && the time of a molad
    // (new moon) which starts that year, this routine will calculate what day
    // will be the actual start of the year (Tishri 1 or Rosh Ha-Shanah).  This
    // first day of the year will be the day of the molad unless one of 4 rules
    // (called dehiyyot) delays it.  These 4 rules can delay the start of the
    // year by as much as 2 days.
    //=====================================================================
    private int tishri1(int metonicYear, int moladDay, int moladHalakim)
    {
        int dow;
        boolean leapYear;
        boolean lastWasLeapYear;
        int tsh1;
        
        tsh1 = moladDay;
        dow = AstronomyMaths.modulo(tsh1, 7);
        leapYear = (metonicYear == 2 || metonicYear == 5 || metonicYear == 7 || metonicYear == 10 || metonicYear == 13 || metonicYear == 16 || metonicYear == 18);
        lastWasLeapYear = (metonicYear == 3 || metonicYear == 6 || metonicYear == 8 || metonicYear == 11 || metonicYear == 14 || metonicYear == 17 || metonicYear == 0);
        
        // Apply rules 2, 3 and 4.
        if ((moladHalakim >= NOON) || ((!leapYear) && dow == USWeekDays.TUESDAY && moladHalakim >= AM3_11_20) || (lastWasLeapYear && dow == USWeekDays.MONDAY && moladHalakim >= AM9_32_43))
        {
            tsh1 += 1;
            dow += 1;
            if (dow == 7) dow = 0;
        }
        
        // Apply rule 1 after the others because it can cause an additional delay of one day.
        if (dow == USWeekDays.WEDNESDAY || dow == USWeekDays.FRIDAY || dow == USWeekDays.SUNDAY) tsh1 += 1;
        
        return tsh1;
    }
    
    //=====================================================================
    // Given a metonic cycle number, calculate the date && time of the molad
    // (new moon) that starts that cycle.  Since the length of a metonic cycle
    // is a constant, this is a simple calculation, except that it requires an
    // intermediate value which is bigger that 32 bits.  Because this
    // intermediate value only needs 36 to 37 bits && the other numbers are
    // constants, the process has been reduced to just a few steps.
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList moladOfMetonicCycle(int metonicCycle)
    {
        double r;
        ArrayList result = new ArrayList();
        
        // Start with the time of the first molad after creation.
        r = NEW_MOON_OF_CREATION;
        int pMoladDay = (int)((r + (double)(metonicCycle) * (double)(HALAKIM_PER_METONIC_CYCLE)) / (double)(HALAKIM_PER_DAY) - 0.5);
        int pMoladHalakim = (int)AstronomyMaths.modulo(r + (double)(metonicCycle) * (double)(HALAKIM_PER_METONIC_CYCLE), (double)(HALAKIM_PER_DAY));
        result.add(new Integer(pMoladDay));
        result.add(new Integer(pMoladHalakim));
        return result;
    }
    
    //=====================================================================
    // Given a day number, find the molad of Tishri (the new moon at the start
    // of a year) which is closest to that day number.  It's not really the
    // *closest* molad that we want here.  if the input day is in the first two
    // months, we want the molad at the start of the year.  if the input day is
    // in the fourth to last months, we want the molad at the end of the year.
    // if the input day is in the third month, it doesn't matter which molad is
    // returned, because both will be required.  This type of "rounding" allows
    // us to avoid calculating the length of the year in most cases.
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList findTishriMolad(int inputDay)
    {
        int metonicCycle=0;
        int metonicYear=0;
        int moladDay=0;
        int moladHalakim=0;
        
        // Estimate the metonic cycle number.  Note that this may be an under
        // estimate because there are 6939.6896 days in a metonic cycle not
        // 6940, but it will never be an over estimate.  The loop below will
        // correct for any error in this estimate.
        metonicCycle = (int)(((double)inputDay + 310.0) / 6940.0 - 0.5);
        
        // Calculate the time of the starting molad for this metonic cycle.
        ArrayList result = moladOfMetonicCycle(metonicCycle);
        if (result!=null)
        {
            moladDay = ((Integer)result.get(0)).intValue();
            moladHalakim = ((Integer)result.get(1)).intValue();
        }
        
        // if the above was an under estimate, increment the cycle number until
        // the correct one is found.  For modern dates this loop is about 98.6%
        // likely to not execute, even once, because the above estimate is really quite close.
        while (moladDay < inputDay - 6940 + 310)
        {
            metonicCycle += 1;
            moladHalakim += HALAKIM_PER_METONIC_CYCLE;
            moladDay += (int)((double)moladHalakim / (double)HALAKIM_PER_DAY - 0.5);
            moladHalakim = AstronomyMaths.modulo(moladHalakim, HALAKIM_PER_DAY);
        }
        
        // Find the molad of Tishri closest to this date.
        for (metonicYear = 0 ; metonicYear <= 17; metonicYear++)
        {
            if (moladDay > inputDay - 74)
            {
                break;
            }
            moladHalakim += HALAKIM_PER_LUNAR_CYCLE * monthsPerYear[metonicYear];
            moladDay += (int)((double)moladHalakim / (double)HALAKIM_PER_DAY - 0.5);
            moladHalakim = AstronomyMaths.modulo(moladHalakim, HALAKIM_PER_DAY);
        }
        result = new ArrayList();
        result.add(new Integer(metonicCycle));
        result.add(new Integer(metonicYear));
        result.add(new Integer(moladDay));
        result.add(new Integer(moladHalakim));
        return result;
    }
    
    //=====================================================================
    // Given a year, find the number of the first day of that year and the date
    // and time of the starting molad.
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList findStartOfYear(int year)
    {
        int pMetonicCycle = (year - 1) / 19;
        int pMetonicYear = AstronomyMaths.modulo(year - 1, 19);
        ArrayList result = moladOfMetonicCycle(pMetonicCycle);
        int moladDay = ((Integer)result.get(0)).intValue();
        int moladHalakim = ((Integer)result.get(1)).intValue();
        result = new ArrayList();
        int pMoladHalakim = moladHalakim + HALAKIM_PER_LUNAR_CYCLE * yearOffset[pMetonicYear];
        int pMoladDay = moladDay + (int)((double)pMoladHalakim / (double)HALAKIM_PER_DAY - 0.5);
        pMoladHalakim = AstronomyMaths.modulo(pMoladHalakim, HALAKIM_PER_DAY);
        int ptishri1 = tishri1(pMetonicYear, pMoladDay, pMoladHalakim);
        result.add(new Integer(pMetonicCycle));
        result.add(new Integer(pMetonicYear));
        result.add(new Integer(pMoladDay));
        result.add(new Integer(pMoladHalakim));
        result.add(new Integer(ptishri1));
        return result;
    }
    
    //=====================================================================
    // Given a serial day number (SDN), find the corresponding year, month &&
    // day in the Jewish calendar.  The three output values will always be
    // modified.  if the input SDN is before the first day of year 1, they will
    // all be set to zero, otherwise *pYear will be > 0; *pMonth will be in the
    // range 1 to 13 inclusive; *pDay will be in the range 1 to 30 inclusive.
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList sdnToJewish(int sdn)
    {
        int inputDay;
        int day;
        int halakim;
        int metonicCycle;
        int metonicYear;
        int tsh1;
        int tishri1After;
        int yearLength;
        int pYear;
        int pMonth;
        int pDay;
        
        if (sdn <= SDN_OFFSET)
        {
            return null;
        }
        inputDay = sdn - SDN_OFFSET;
        
        ArrayList result = findTishriMolad(inputDay);
        metonicCycle = ((Integer)result.get(0)).intValue();
        metonicYear = ((Integer)result.get(1)).intValue();
        day = ((Integer)result.get(2)).intValue();
        halakim = ((Integer)result.get(3)).intValue();
        
        result = new ArrayList();
        tsh1 = tishri1(metonicYear, day, halakim);
        
        if (inputDay >= tsh1)
        {
            // It found Tishri 1 at the start of the year.
            pYear = metonicCycle * 19 + metonicYear + 1;
            
            if (inputDay < tsh1 + 59)
            {
                if (inputDay < tsh1 + 30)
                {
                    pMonth = 1;
                    pDay = inputDay - tsh1 + 1;
                }
                else
                {
                    pMonth = 2;
                    pDay = inputDay - tsh1 - 29;
                }
                result.add(new Integer(pYear));
                result.add(new Integer(pMonth));
                result.add(new Integer(pDay));
                return result;
            }
            
            // We need the length of the year to figure this out, so find Tishri 1 of the next year.
            halakim = halakim + HALAKIM_PER_LUNAR_CYCLE * monthsPerYear[metonicYear];
            day = day + (int)(halakim / HALAKIM_PER_DAY - 0.5);
            halakim = AstronomyMaths.modulo(halakim, HALAKIM_PER_DAY);
            tishri1After = tishri1(AstronomyMaths.modulo(metonicYear + 1, 19), day, halakim);
        }
        else
        {
            // It found Tishri 1 at the end of the year.
            pYear = metonicCycle * 19 + metonicYear;
            
            if (inputDay >= tsh1 - 177)
            {
                // It is one of the last 6 months of the year.
                if (inputDay > tsh1 - 30)
                {
                    pMonth = 13;
                    pDay = inputDay - tsh1 + 30;
                }
                else if (inputDay > tsh1 - 60)
                {
                    pMonth = 12;
                    pDay = inputDay - tsh1 + 60;
                }
                else if (inputDay > tsh1 - 89)
                {
                    pMonth = 11;
                    pDay = inputDay - tsh1 + 89;
                }
                else if (inputDay > tsh1 - 119)
                {
                    pMonth = 10;
                    pDay = inputDay - tsh1 + 119;
                }
                else if (inputDay > tsh1 - 148)
                {
                    pMonth = 9;
                    pDay = inputDay - tsh1 + 148;
                }
                else
                {
                    pMonth = 8;
                    pDay = inputDay - tsh1 + 178;
                }
                result.add(new Integer(pYear));
                result.add(new Integer(pMonth));
                result.add(new Integer(pDay));
                return result;
            }
            else
            {
                if (monthsPerYear[AstronomyMaths.modulo(pYear - 1, 19)] == 13 )
                {
                    pMonth = 7;
                    pDay = inputDay - tsh1 + 207;
                    
                    if (pDay > 0)
                    {
                        result.add(new Integer(pYear));
                        result.add(new Integer(pMonth));
                        result.add(new Integer(pDay));
                        return result;
                    }
                    pMonth = pMonth - 1;
                    pDay = pDay + 30;
                    
                    if (pDay > 0)
                    {
                        result.add(new Integer(pYear));
                        result.add(new Integer(pMonth));
                        result.add(new Integer(pDay));
                        return result;
                    }
                    pMonth = pMonth - 1;
                    pDay = pDay + 30;
                }
                else
                {
                    pMonth = 6;
                    pDay = inputDay - tsh1 + 207;
                    
                    if (pDay > 0)
                    {
                        result.add(new Integer(pYear));
                        result.add(new Integer(pMonth));
                        result.add(new Integer(pDay));
                        return result;
                    }
                    pMonth = pMonth - 1;
                    pDay = pDay + 30;
                }
                
                if (pDay > 0)
                {
                    result.add(new Integer(pYear));
                    result.add(new Integer(pMonth));
                    result.add(new Integer(pDay));
                    return result;
                }
                pMonth = pMonth - 1;
                pDay = pDay + 29;
                
                if (pDay > 0)
                {
                    result.add(new Integer(pYear));
                    result.add(new Integer(pMonth));
                    result.add(new Integer(pDay));
                    return result;
                }
                
                // We need the length of the year to figure this out, so find Tishri 1 of this year.
                tishri1After = tsh1;
                result = findTishriMolad(day - 365);
                metonicCycle = ((Integer)result.get(0)).intValue();
                metonicYear = ((Integer)result.get(1)).intValue();
                day = ((Integer)result.get(2)).intValue();
                halakim = ((Integer)result.get(3)).intValue();
                tsh1 = tishri1(metonicYear, day, halakim);
            }
        }
        
        yearLength = tishri1After - tsh1;
        day = inputDay - tsh1 - 29;
        result = new ArrayList();
        
        if (yearLength == 355 || yearLength == 385)
        {
            // Heshvan has 30 days
            if (day <= 30)
            {
                pMonth = 2;
                pDay = day;
                result.add(new Integer(pYear));
                result.add(new Integer(pMonth));
                result.add(new Integer(pDay));
                return result;
            }
            day = day - 30;
        }
        else
        {
            // Heshvan has 29 days
            if (day <= 29)
            {
                pMonth = 2;
                pDay = day;
                result.add(new Integer(pYear));
                result.add(new Integer(pMonth));
                result.add(new Integer(pDay));
                return result;
            }
            day = day - 29;
        }
        
        // It has to be Kislev.
        pMonth = 3;
        pDay = day;
        
        result.add(new Integer(pYear));
        result.add(new Integer(pMonth));
        result.add(new Integer(pDay));
        return result;
    }
    
    //=====================================================================
    // Given a year, month && day in the Jewish calendar, find the
    // corresponding serial day number (SDN).  Zero is returned when the input
    // date is detected as invalid.  The return value will be > 0 for all valid
    // dates, but there are some invalid dates that will return a positive
    // value.  ; verify that a date is valid, convert it to SDN && then back
    // && compare with the original.
    //=====================================================================
    private int jewishToSdn(int year, int month, int day)
    {
        int sdn;
        int metonicCycle;
        int metonicYear;
        int tsh1;
        int tishri1After;
        int moladDay;
        int moladHalakim;
        int yearLength;
        int lengthOfAdarIAndII;
        ArrayList result;
        
        if (year <= 0 || day <= 0 || day > 30) return 0;
        
        switch(month)
        {
            // It is Tishri or Heshvan - don't need the year length.
            case 1:
            case 2:
                result = findStartOfYear(year);
                metonicCycle = ((Integer)result.get(0)).intValue();
                metonicYear = ((Integer)result.get(1)).intValue();
                moladDay = ((Integer)result.get(2)).intValue();
                moladHalakim = ((Integer)result.get(3)).intValue();
                tsh1 = ((Integer)result.get(4)).intValue();
                if (month == 1)
                {
                    sdn = tsh1 + day - 1;
                }
                else
                {
                    sdn = tsh1 + day + 29;
                }
                break;
                
                // It is Kislev - must find the year length.
            case 3:
                // Find the start of the year.
                result = findStartOfYear(year);
                metonicCycle = ((Integer)result.get(0)).intValue();
                metonicYear = ((Integer)result.get(1)).intValue();
                moladDay = ((Integer)result.get(2)).intValue();
                moladHalakim = ((Integer)result.get(3)).intValue();
                tsh1 =((Integer)result.get(4)).intValue();
                
                // Find the end of the year.
                moladHalakim = moladHalakim + HALAKIM_PER_LUNAR_CYCLE * monthsPerYear[metonicYear];
                moladDay = moladDay + (int)((double)moladHalakim / (double)HALAKIM_PER_DAY - 0.5);
                moladHalakim = AstronomyMaths.modulo(moladHalakim, HALAKIM_PER_DAY);
                tishri1After = tishri1(AstronomyMaths.modulo(metonicYear + 1, 19), moladDay, moladHalakim);
                
                yearLength = tishri1After - tsh1;
                if (yearLength == 355 || yearLength == 385)
                {
                    sdn = tsh1 + day + 59;
                }
                else
                {
                    sdn = tsh1 + day + 58;
                }
                break;
                
                // It is Tevet, Shevat or Adar I - don't need the year length.
            case 4:
            case 5:
            case 6:
                result = findStartOfYear(year + 1);
                metonicCycle = ((Integer)result.get(0)).intValue();
                metonicYear = ((Integer)result.get(1)).intValue();
                moladDay = ((Integer)result.get(2)).intValue();
                moladHalakim = ((Integer)result.get(3)).intValue();
                tishri1After = ((Integer)result.get(4)).intValue();
                if (monthsPerYear[AstronomyMaths.modulo(year - 1, 19)] == 12)
                {
                    lengthOfAdarIAndII = 29;
                }
                else
                {
                    lengthOfAdarIAndII = 59;
                }
                
                if (month == 4)
                {
                    sdn = tishri1After + day - lengthOfAdarIAndII - 237;
                }
                else if (month == 5)
                {
                    sdn = tishri1After + day - lengthOfAdarIAndII - 208;
                }
                else
                {
                    sdn = tishri1After + day - lengthOfAdarIAndII - 178;
                }
                break;
                
                // It is Adar II or later - don't need the year length.
            default:
                result = findStartOfYear(year + 1);
                metonicCycle = ((Integer)result.get(0)).intValue();
                metonicYear = ((Integer)result.get(1)).intValue();
                moladDay = ((Integer)result.get(2)).intValue();
                moladHalakim = ((Integer)result.get(3)).intValue();
                tishri1After = ((Integer)result.get(4)).intValue();
                switch(month)
                {
                    case 7 : sdn = tishri1After + day - 207;break;
                    case 8 : sdn = tishri1After + day - 178;break;
                    case 9 : sdn = tishri1After + day - 148;break;
                    case 10 : sdn = tishri1After + day - 119;break;
                    case 11 : sdn = tishri1After + day - 89;break;
                    case 12 : sdn = tishri1After + day - 60;break;
                    case 13 : sdn = tishri1After + day - 30;break;
                    default: return 0;
                }
                break;
        }
        return sdn + SDN_OFFSET;
    }
}
