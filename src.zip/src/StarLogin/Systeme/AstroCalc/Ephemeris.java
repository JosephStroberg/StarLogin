package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import StarLogin.Systeme.Enum.Planets;

import java.util.ArrayList;

public class Ephemeris
{
    private ChartEvent ev;
    private int deltaJJ;
    private int step;
    
    /** Creates a new instance of Ephemeris */
    public Ephemeris(ChartEvent ev, int deltaJJ, int step)
    {
        this.ev = ev;
        this.deltaJJ = deltaJJ;
        this.step = step;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public ArrayList getAllCoordinates()
    {
        //begin the previous day or period (day * step)
        ev.addTime2CTimeH(-24.0 * step);
        Planet pl = new Planet(ev, true);
        
        ArrayList result = new ArrayList();
        AllCoord allCoord;
        
        for (int i = 0; i < deltaJJ; i++)
        {
            allCoord = new AllCoord();
            for (int j = 0; j <= Planets.Chiron; j++)
            {
                allCoord.set(pl.getObjPosition(j), j);
            }
            result.add(allCoord);
            ev.addTime2CTimeH(24.0 * step);
            pl = new Planet(ev, true);
        }
        allCoord = new AllCoord();
        result.add(allCoord);
        return result;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public ArrayList getAllCoordinates(int lastPlanet)
    {
        //begin the previous day or period (day * step)
        ev.addTime2CTimeH(-24.0 * step);
        Planet pl = new Planet(ev, true);
        
        ArrayList result = new ArrayList();
        AllCoord allCoord;
        
        for (int i = 0; i < deltaJJ; i++)
        {
            allCoord = new AllCoord();
            for (int j = 0; j <= lastPlanet; j++)
            {
                allCoord.set(pl.getObjPosition(j), j);
            }
            result.add(allCoord);
            ev.addTime2CTimeH(24.0 * step);
            pl = new Planet(ev, true);
        }
        allCoord = new AllCoord();
        result.add(allCoord);
        return result;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public ArrayList getCoordinates(int planet)
    {
        //begin the previous day or period (day * step)
        ev.addTime2CTimeH(-24.0 * step);
        Planet pl = new Planet(ev, true);
        
        ArrayList result = new ArrayList();
        AllCoord allCoord;
        
        for (int i = 0; i < deltaJJ; i++)
        {
            allCoord = new AllCoord();
            allCoord.set(pl.getObjPosition(planet), planet);
            result.add(allCoord);
            ev.addTime2CTimeH(24.0 * step);
            pl = new Planet(ev, true);
        }
        allCoord = new AllCoord();
        result.add(allCoord);
        return result;
    }
}
