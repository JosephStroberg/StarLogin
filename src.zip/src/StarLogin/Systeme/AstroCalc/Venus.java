package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import java.lang.Math.*;

import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.Enum.Planets;
import StarLogin.IHM.MainClass;

public class Venus
{
    private double mPlaceLat;
    private double mCTime;
    private int mNumber;
    private Coord mCoord = new Coord();
    private double mTSL;
    private ChartEvent chartEvent;
    private double mSunEarthDist;
    private double mTrueSunLongitude;
    
    /** Creates new Venus */
    public Venus(ChartEvent chartEvent)
    {
        this.chartEvent = chartEvent;
    }
    
    public void setTrueSunLongitude(double Value)
    {
        mTrueSunLongitude = Value;
    }
    
    public void setSunEarthDist(double Value)
    {
        mSunEarthDist = Value;
    }
    
    public Coord getObjPosition(double l[], double m[], double u[])
    {
        mPlaceLat = chartEvent.getPlaceLat();
        mCTime = chartEvent.getCTimeH();
        mNumber = Planets.Venus;
        mTSL = chartEvent.getLST();
        double mObliquity = chartEvent.getObliquity();
        double mMoonNNode = chartEvent.getMeanNN();
        
        mCoord.setTropicHelioLong(l[mNumber] * 3600.0 + (2814.0 - 20.0 * mCTime) * AstronomyMaths.sinD(m[mNumber]) + 12.0 * AstronomyMaths.sinD(2.0 * m[mNumber]) - 181.0 * AstronomyMaths.sinD(2.0 * u[mNumber]) - 10.0 * AstronomyMaths.cosD(2.0 * (m[Planets.Sun] - m[mNumber])) + 7.0 * AstronomyMaths.cosD(3.0 * (m[Planets.Sun] - m[mNumber])));
        mCoord.setHelioLat(12215.0 * AstronomyMaths.sinD(u[mNumber]) + 166.0 * AstronomyMaths.cosD(u[mNumber]) * AstronomyMaths.sinD(m[mNumber]));
        mCoord.setHelioDist(0.72335 - 0.00493 * AstronomyMaths.cosD(m[mNumber]));
        mCoord.setTropicHelioLong(AstronomyMaths.modulo(mCoord.getTropicHelioLong() / 3600.0, 360.0));
        mCoord.setTropicHelioLong(mCoord.correctedHelioLong(mMoonNNode));
        mCoord.setHelioLat(AstronomyMaths.getHelioLat(mCoord.getHelioLat()));
        mCoord.setGeoDist(mCoord.distHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setGeoLat(mCoord.latHelio2Geo());
        mCoord.setTropicGeoLong(mCoord.longHelio2Geo(mSunEarthDist, mTrueSunLongitude));
        mCoord.setDecl(mCoord.declFromEcliptic(mObliquity));
        mCoord.setRA(mCoord.raFromEcliptic(mObliquity));
        mCoord.setAlt(mCoord.altFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAz(mCoord.azFromEquatorial(mPlaceLat, mTSL));
        mCoord.setAyanamsa(AstronomyMaths.getAyanamsa(mCTime));
        mCoord.setSiderGeoLong(mCoord.getTropicGeoLong() - mCoord.getAyanamsa());
        mCoord.setSiderHelioLong(mCoord.getTropicHelioLong() - mCoord.getAyanamsa());

        return mCoord;
    }
}
