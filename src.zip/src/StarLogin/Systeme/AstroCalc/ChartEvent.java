package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.Data.Event;
import StarLogin.Systeme.Enum.ChartKind;
import StarLogin.Systeme.Enum.CoordSystem;
import StarLogin.Systeme.Enum.HouseSystem;


/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartEvent
{
    private java.util.ResourceBundle bundle = MainClass.bundle;
    private final String LONG_S = " : Longitude ";
    private final String LAT_S = "; Latitude ";
    private String surname;
    private String otherNames;
    private String eventName;
    private String localDate;
    private String utDate;
    private String localTime;
    private String utTime;
    private String place;
    private String latitude;
    private String longitude;
    private String header;
    private double lst;
    private double gst0;
    private double jd;
    private double cTime;
    private double cTimeH;
    private double meanNN;
    private double obliquity;
    private double ayanamsa;
    private double placeLong;
    private double placeLat;
    private double time;
    private long month;
    private long day;
    private long year;
    private Event event;
    
    /** Creates new ChartEvent */
    public ChartEvent(Event event)
    {
        header = "";
        surname = event.getSurname();
        otherNames = event.getOtherNames();
        eventName = event.getEventName();
        localDate = event.getLocalDate();
        utDate = event.getUtDate();
        localTime = event.getLocalTime();
        utTime = event.getUtTime();
        place = event.getPlace();
        latitude = event.getLatitude();
        longitude = event.getLongitude();
        this.event = event;
        
        //decimal time
        FTime ft = new FTime(utTime);
        time = ft.getDecimalHour();
        
        //day, month and year
        FDate fd = new FDate(utDate);
        day = fd.getDay();
        month = fd.getMonth();
        year = fd.getYear();
        
        //place latitude and longitude
        placeLat = new FLatitude(latitude).getDecimalDegree();
        placeLong = new FLongitude(longitude).getDecimalDegree();
        
        //astronomical data from UT time and date
        jd = AstronomyMaths.gregorianToJulian(day, month, year);
        cTime = AstronomyMaths.getCTime(jd);
        gst0 = AstronomyMaths.getGMT0(cTime);
        lst = AstronomyMaths.UTToLST(time, gst0, placeLong);
        cTimeH = cTime + time / AstronomyMaths.HOUR_PER_CENTURY;
        meanNN = AstronomyMaths.getNN(cTimeH);
        obliquity = AstronomyMaths.getObliquity(cTimeH, meanNN);
        ayanamsa = AstronomyMaths.getAyanamsa(cTimeH);
    }
    
    public ChartEvent cloneEvent()
    {
        Event evt = event.cloneEvent(event);
        evt.setLatitude(latitude);
        evt.setLocalDate(localDate);
        evt.setLocalTime(localTime);
        evt.setLongitude(longitude);
        evt.setPlace(place);
        evt.setUtDate(utDate);
        evt.setUtTime(utTime);
        evt.setEventName(eventName);
        evt.setOtherNames(otherNames);
        evt.setSurname(surname);
        return new ChartEvent(evt);
    }
    
    public Event getEvent()
    {
        return event;
    }
    
    /*public void setEvent(Event data)
    {
        event = data;
    }*/
    
    public String getHeader()
    {
        return header;
    }
    
    public void setHeader(String sData)
    {
        header = sData;
    }
    
    public void setPlace(String data)
    {
        place = data;
        event.setPlace(data);
    }
    
    public double getLST()
    {
        return lst;
    }
    
    public double getTSG0()
    {
        return gst0;
    }
    
    public double getCTime()
    {
        return cTime;
    }
    
    public double getCTimeH()
    {
        return cTimeH;
    }
    
    public void setCTimeH(double data)
    {
        cTimeH = data;
    }
    
    public double getMeanNN()
    {
        return meanNN;
    }
    
    public double getObliquity()
    {
        return obliquity;
    }
    
    public double getAyanamsa()
    {
        return ayanamsa;
    }
    
    public void setAyanamsa(double data)
    {
        ayanamsa = data;
    }
    
    public long getMonth()
    {
        return month;
    }
    
    public long getDay()
    {
        return day;
    }
    
    public long getYear()
    {
        return year;
    }
    
    public double getPlaceLat()
    {
        return placeLat;
    }
    
    public void setPlaceLat(double data)
    {
        FLatitude flat = new FLatitude(data);
        placeLat = data;
        latitude = flat.getLatitude();
        event.setLatitude(latitude);
    }
    
    public double getPlaceLong()
    {
        return placeLong;
    }
    
    public void setPlaceLong(double data)
    {
        FLongitude flong = new FLongitude(data);
        placeLong = data;
        longitude = flong.getLongitude();
        event.setLongitude(longitude);
    }
    
    public double getTime()
    {
        return time;
    }
    
    public double getJD()
    {
        return jd;
    }

    private String null2String(String sVal)
    {
        if (sVal == null)
        {
            return "";
        }
        else
        {
            return sVal;
        }
    }
    
    //=========================================================================
    //Calculation of the local sidereal time and determination of the header
    //for the considered event
    //input : entete: either empty string if the hearder already exists, or the header
    //=========================================================================
    public String makeEventHeader(int flag_chart, int sys_coord, int domif)
    {
        header = null2String(surname) + " " + null2String(otherNames) + "\r\n" + null2String(eventName) + " " + bundle.getString("at")+" " + null2String(localTime) + " " + bundle.getString("on")+" " + null2String(localDate) + " (" + null2String(utDate) + " " + bundle.getString("at")+" " + null2String(utTime) + " " + bundle.getString("UT)") + "\r\n";
        if (flag_chart == ChartKind.local)
        {
            header = header + place + LONG_S + longitude + LAT_S + latitude + "\r\n" + CoordSystem.getCoordSystemName(sys_coord);
        }
        else
        {
            header = header + place + LONG_S + longitude + LAT_S + latitude + "\r\n" + CoordSystem.getCoordSystemName(sys_coord) + " - " + HouseSystem.getHouseSystemName(domif);
        }
        
        header = header + "\r\n" + ChartKind.getChartKindName(flag_chart);
        return header;
    }
    
    public double getTimeLag()
    {
        if (event.getTimeLag() == null || event.getTimeLag().equals("")) return 0.0;
        return new Double(event.getTimeLag()).doubleValue();
    }
    
    public String getShortHeader()
    {
        String header0 = surname + " " + otherNames + "\r\n" + eventName + " " + bundle.getString("at")+" " + localTime + " " + bundle.getString("on")+" " + localDate + "\r\n";
        header0 = header0 + place + LONG_S + longitude + LAT_S + latitude + "\r\n";
        //header = header0;
        return header0;
    }
    
    public String add2Header(String entete)
    {
        if (!entete.equals("")) header = header + "\r\n" + entete;
        return header;
    }
    
    public String getDateTime()
    {
        return localDate + " " + localTime;
    }
    
    public String getDate()
    {
        return localDate;
    }
    
    public void addTime2CTimeH(double t)
    {
        cTimeH += t / AstronomyMaths.HOUR_PER_CENTURY;
        meanNN = AstronomyMaths.getNN(cTimeH);
        obliquity = AstronomyMaths.getObliquity(cTimeH, meanNN);
        ayanamsa = AstronomyMaths.getAyanamsa(cTimeH);
        jd = AstronomyMaths.getJDFromCTime(cTimeH);
        cTime = AstronomyMaths.getCTime(jd);
        gst0 = AstronomyMaths.getGMT0(cTime);
        time = AstronomyMaths.modulo(time + t, 24.0);
        lst = AstronomyMaths.UTToLST(time, gst0, placeLong);
        utTime = new FTime(time).getTime();
        
        //ut date
        double date = AstronomyMaths.julianToGregorian(jd);
        FDate fd = new FDate(date);
        day = fd.getDay();
        month = fd.getMonth();
        year = fd.getYear();
        
        //local date and time
        event = new Event();
        event.setLatitude(latitude);
        event.setLongitude(longitude);
        event.setPlace(place);
        utDate = fd.getFormatedDate();
        event.setUtDate(utDate);
        //utTime = new FTime(time).getTime();
        event.setUtTime(utTime);
        event.localTimeCalculation(TZRules.FirstTime);
        localDate = event.getLocalDate();
        localTime = event.getLocalTime();
        
        //other information to keep
        //event.setAscendant(this.getEvent().getAscendant());
        event.setComments(this.getEvent().getComments());
        event.setEntityType(this.getEvent().getEntityType());
        event.setEventName(this.getEvent().getEventName());
        event.setOtherNames(this.getEvent().getOtherNames());
        //event.setSign(this.getEvent().getSign());
        event.setSurname(this.getEvent().getSurname());
    }
    
    public void deduceValues(String sPlace, double lat, double lng, double time, String date)
    {
        place = sPlace;
        
        //Getting the place data
        placeLong = lng;
        placeLat = lat;
        longitude = new FLongitude(lng).getLongitude();
        latitude = new FLatitude(lat).getLatitude();
        
        //day, month and year
        FDate fd = new FDate(date);
        day = fd.getDay();
        month = fd.getMonth();
        year = fd.getYear();
        
        //local date and time
        Event event0 = new Event();
        event0.setLatitude(latitude);
        event0.setLongitude(longitude);
        event0.setPlace(place);
        utDate = fd.getFormatedDate();
        event0.setUtDate(utDate);
        utTime = new FTime(time).getTime();
        event0.setUtTime(utTime);
        event0.localTimeCalculation(TZRules.FirstTime);
        localDate = event0.getLocalDate();
        localTime = event0.getLocalTime();
        
        //astronomical data from UT time and date
        jd = AstronomyMaths.gregorianToJulian(day, month, year);
        cTime = AstronomyMaths.getCTime(jd);
        gst0 = AstronomyMaths.getGMT0(cTime);
        lst = AstronomyMaths.UTToLST(time, gst0, placeLong);
        cTimeH = cTime + time / AstronomyMaths.HOUR_PER_CENTURY;
        meanNN = AstronomyMaths.getNN(cTimeH);
        obliquity = AstronomyMaths.getObliquity(cTimeH, meanNN);
        ayanamsa = AstronomyMaths.getAyanamsa(cTimeH);
        event = event0;
        //MainClass.event = event0;
    }
}
