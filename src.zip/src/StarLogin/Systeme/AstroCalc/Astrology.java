package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;
import StarLogin.StarLoginManager;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.Data.Asteroid;
import StarLogin.Systeme.Data.Comet;
import StarLogin.Systeme.Data.Event;
import StarLogin.Systeme.Data.Part;
import StarLogin.Systeme.Enum.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Astrology extends java.lang.Object
{
    private java.util.ResourceBundle bundle = MainClass.bundle;
    
    //CONSTANTS
    public static final byte CALCUL = 0;
    public static final byte NON_CALCUL = 1;
    
    //chart(s) taken into account for aspects (1, 2, 1-2 or 2-1)
    public static final int POS_1 = 4;
    public static final int POS_2 = 5;
    public static final int POS_1_2 = 6;
    public static final int POS_2_1 = 7;
    
    //relative or normal aspects
    public static final byte ASPECTS_NORMAUX = 0;
    public static final byte ASPECTS_RELATIFS = 1;
    
    //various
    public static final byte PREMIERE_DOMIF = 0;
    public static final byte DERNIERE_DOMIF = 20;
    public static final byte LAST_NORM_DOMIF = 16;
    public static final byte PREMIER_ASTRE_CYCLE = Planets.Jupiter;
    public static final byte DERNIER_ASTRE_CYCLE = 7;
    public static final byte NB_ASTRES_CYCLE = DERNIER_ASTRE_CYCLE;
    public static final String DONTFILLIN = "X";
    private ChartElements chartElements;                                     //positions for both inner and outer charts
    private StarLoginManager starLoginManager;
    
    public Astrology(StarLoginManager starLoginManager)
    {
        this.starLoginManager = starLoginManager;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    public Astrology(ChartElements chartElements, ChartEvent chartEvent, int chartKind, StarLoginManager starLoginManager)
    {
        this.starLoginManager = starLoginManager;
        this.chartElements = chartElements;
        ArrayList chartEvents = new ArrayList();
        String header = chartElements.getChartHeader();
        chartElements.setChartKind(chartKind);
        boolean bNoHeader = false;
        
        switch(chartKind)
        {
            case ChartKind.normal:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                }
                chartCalculation(chartElements);
                
                //save AS and Sign of corresponding event
                Event event = chartEvent.getEvent();
                if (event != null && ((event.getSign()==null||event.getSign().equals(""))||(event.getAscendant()==null||event.getAscendant().equals(""))) && !event.getEventName().contains("?"))
                {
                    ArrayList positions = chartElements.getChartCoords();
                    AllCoord pos1 = (AllCoord)positions.get(0);
                    double as = pos1.get(Planets.AS).getTropicGeoLong();
                    int ias = (int)(as/30);
                    if (ias == 12)
                        ias = 0;
                    double sign = pos1.get(Planets.Sun).getTropicGeoLong();
                    int isign = (int)(sign/30);
                    if (isign == 12)
                        isign = 11;
                    String sas = Signs.getSignName(ias);
                    String ssign = Signs.getSignName(isign);
                    event.setAdding(false);
                    if (event.getSign()==null||event.getSign().equals(""))
                        event.setSign(ssign);
                    if (event.getAscendant()==null||event.getAscendant().equals(""))
                        event.setAscendant(sas);
                    starLoginManager.setEvent(event);
                }
                break;
                
            case ChartKind.local:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                }
                chartCalculation(chartElements);
                break;
                
            case ChartKind.symbolicDir:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header(bundle.getString("Age_")
                    + chartElements.getDirSAge() + " "
                    + bundle.getString("WithCorrespondance")
                    + " " + chartElements.getChartDirSCorresp() + " "
                    + bundle.getString("DegreeEquals")
                    + " " + chartElements.getChartDirSDegree() + " " + getStepKindName(chartElements.getChartDirSSpaceKind()));
                }
                chartCalculation(chartElements);
                directionsAndTransitsProcessing();
                break;
                
            case ChartKind.primaryDir:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header(bundle.getString("Age_")
                    + chartElements.getDir1Age() + " "
                    + bundle.getString("WithCorrespondance")
                    + " " + chartElements.getChartDir1Corresp() + " "
                    + bundle.getString("DegreeEquals")
                    + " " + chartElements.getChartDir1Degree() + " " + getStepKindName(chartElements.getChartDir1SpaceKind()));
                }
                chartCalculation(chartElements);
                directionsAndTransitsProcessing();
                break;
                
            case ChartKind.secondaryDir:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header(bundle.getString("Age_")
                    + chartElements.getDir2Age() + " "
                    + bundle.getString("WithCorrespondance")
                    + " " + chartElements.getChartDir2Corresp() + " "
                    + bundle.getString("DayEquals")
                    + " " + chartElements.getChartDir2Day() + " " + getStepKindName(chartElements.getChartDir2SpaceKind()));
                }
                chartCalculation(chartElements);
                directionsAndTransitsProcessing();
                break;
                
            case ChartKind.transit:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header("Date :  " + chartElements.getTransitsDate());
                }
                chartCalculation(chartElements);
                directionsAndTransitsProcessing();
                break;
                
            case ChartKind.revolution:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header(makeRevolCycleHeader(false));
                    bNoHeader = true;
                }
                chartCalculation(chartElements);
                revolutionsProcessing();
                if (chartEvents.size() <= 1) return;
                ChartEvent chartEventRevol = (ChartEvent)chartEvents.get(1);
                if (bNoHeader)
                {
                    chartEvent.add2Header(chartEventRevol.getDateTime());
                }
                break;
                
            case ChartKind.cycle:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    chartEvent.add2Header(makeRevolCycleHeader(true));
                    bNoHeader = true;
                }
                chartCalculation(chartElements);
                cycleProcessing();
                if (chartEvents.size() <= 1) return;
                ChartEvent chartEventCycle = (ChartEvent)chartEvents.get(1);
                if (bNoHeader)
                {
                    chartEvent.add2Header(chartEventCycle.getDateTime());
                }
                break;
                
            case ChartKind.synastry:
                if (chartElements.getChartEvents().size()>1)
                {
                    header = makeCompSynHeader();
                    ChartEvent chEvSyn = (ChartEvent)(chartElements.getChartEvents().get(0));
                    chEvSyn.setHeader(header);
                }
                else
                {
                    MainClass.setMessage(bundle.getString("PreciserEvents4Synastry"), JOptionPane.WARNING_MESSAGE);
                }
                break;
                
            case ChartKind.composite:
                if (chartElements.getChartEvents().size()>1)
                {
                    header = makeCompSynHeader();
                    ChartEvent chEvComp = (ChartEvent)(chartElements.getChartEvents().get(0));
                    chEvComp.setHeader(header);
                    compositeProcessing();
                }
                else
                {
                    MainClass.setMessage(bundle.getString(""), JOptionPane.WARNING_MESSAGE);
                }
                break;
                
            case ChartKind.free:
                header = CoordSystem.getCoordSystemName(chartElements.getCoordSys());// + " - " + HouseSystem.getHouseSystemName(chartElements.getHouseSys());
                chartEvent.setHeader(header);
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                break;
                
            case ChartKind.harmonic:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    bNoHeader = true;
                }
                chartCalculation(chartElements);
                int harmoVal = chartElements.getChartHarmonicNB();
                String str = bundle.getString("Harmonic") + " " + harmoVal;
                if (bNoHeader)
                {
                    chartEvent.add2Header(str);
                }
                ArrayList allCoords = chartElements.getChartCoords();
                AllCoord allCoord = harmonicCalculation(harmoVal, (AllCoord)allCoords.get(0));
                allCoords = new ArrayList();
                allCoords.add(allCoord);
                chartElements.setChartCoords(allCoords);
                break;
                
            case ChartKind.seed:
                chartElements.setHouseSys(HouseSystem.MaternusAs);
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                }
                seedProcessing();
                break;
                
            case ChartKind.projective:
                chartEvents.add(chartEvent);
                chartElements.setChartEvents(chartEvents);
                if (header.equals(""))
                {
                    header = chartEvent.makeEventHeader(chartKind, chartElements.getCoordSys(), chartElements.getHouseSys());
                    bNoHeader = true;
                }
                chartCalculation(chartElements);
                projectiveProcessing();
                chartEvents = chartElements.getChartEvents();
                if (chartEvents.size() < 2) return;
                ChartEvent eventInside = (ChartEvent)chartEvents.get(1);
                if (bNoHeader)
                {
                    chartEvent.add2Header(MainForm.planetName[Planets.Neptune] + " -> " + eventInside.getEvent().getLocalDate() + " " + eventInside.getEvent().getLocalTime());
                }
                break;
                
            default: break;
        }
        
        if (chartElements.getViewBarycenter())
        {
            barycenterProcessing(chartElements, (AllCoord)chartElements.getChartCoords().get(0));
        }
    }
    
    public static String getPlanetaryConfigs(String aspectKinds[][])
    {
        int i;
        int j;
        int k;
        int l;
        int m;
        int n;
        String strResult = "";
        int a1;
        int a2;
        int a3;
        int a4;
        int a5;
        int a6;
        int a7;
        int a8;
        int a9;
        int a10;
        int a11;
        int a12;
        int a13;
        int a14;
        int a15;
        boolean bConfigs[] = new boolean[Configs.getLast()+1];
        for (i = 0; i <= Configs.getLast(); i++)
        {
            bConfigs[i] = false;
        }
        
        for ( i = 0; i <= Planets.MC; i++)
        {
            for ( j = 0; j <= Planets.MC; j++)
            {
                if (!aspectKinds[i][j].equals(""))
                {
                    a1 = AspectType.getAspectNBFromSymbol(aspectKinds[i][j]);
                    for ( k = 0; k <= Planets.MC; k++)
                    {
                        if (!aspectKinds[i][k].equals("") && !aspectKinds[j][k].equals(""))
                        {
                            a2 = AspectType.getAspectNBFromSymbol(aspectKinds[i][k]);
                            a3 = AspectType.getAspectNBFromSymbol(aspectKinds[j][k]);
                            if ( a1 == AspectType.Sextile && a2 == AspectType.Sextile && a3 == AspectType.Trine )
                                bConfigs[0] = true;
                            else if ( a1 == AspectType.Trine && a2 == AspectType.Trine && a3 == AspectType.Trine )
                                bConfigs[1] = true;
                            else if ( a1 == AspectType.Square && a2 == AspectType.Square && a3 == AspectType.Opposition )
                                bConfigs[2] = true;
                            else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile )
                                bConfigs[3] = true;
                            
                            for ( l = 0; l <= Planets.MC; l++)
                            {
                                if (!aspectKinds[i][l].equals("") && !aspectKinds[j][l].equals("") && !aspectKinds[k][l].equals(""))
                                {
                                    a4 = AspectType.getAspectNBFromSymbol(aspectKinds[i][l]);
                                    a5 = AspectType.getAspectNBFromSymbol(aspectKinds[j][l]);
                                    a6 = AspectType.getAspectNBFromSymbol(aspectKinds[k][l]);
                                    if ( a1 == AspectType.Sextile && a2 == AspectType.Square && (a3 == AspectType.Inconjunct || a4 == AspectType.SemiSextile) && a5 == AspectType.Square && a6 == AspectType.Sextile )
                                        bConfigs[4] = true;
                                    else if ( a1 == AspectType.Opposition && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Sextile )
                                        bConfigs[5] = true;
                                    else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Opposition && a4 == AspectType.Inconjunct && a5 == AspectType.Sextile )
                                        bConfigs[6] = true;
                                    else if ( a1 == AspectType.Sextile && a2 == AspectType.Opposition && a3 == AspectType.Trine && a4 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Trine )
                                        bConfigs[7] = true;
                                    else if ( a1 == AspectType.Square && a2 == AspectType.Opposition && a3 == AspectType.Square && a4 == AspectType.Square && a5 == AspectType.Opposition && a6 == AspectType.Square )
                                        bConfigs[8] = true;
                                    else if ( a1 == AspectType.Trine && a2 == AspectType.Square && a3 == AspectType.SemiSextile && a5 == AspectType.Square && a6 == AspectType.Sextile )
                                        bConfigs[9] = true;
                                    else if ( a2 == AspectType.Trine && a3 == AspectType.Square && a4 == AspectType.Square && a5 == AspectType.Trine && a6 == AspectType.Inconjunct )
                                        bConfigs[10] = true;
                                    else if ( a1 == AspectType.SemiSextile && a2 == AspectType.Opposition && a3 == AspectType.Inconjunct && a4 == AspectType.Inconjunct && a5 == AspectType.Opposition && a6 == AspectType.SemiSextile )
                                        bConfigs[11] = true;
                                    else if ( a1 == AspectType.Trine && a2 == AspectType.Opposition && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Opposition && a6 == AspectType.Trine )
                                        bConfigs[12] = true;
                                    else if ( a2 == AspectType.Inconjunct && a3 == AspectType.Trine && a4 == AspectType.Trine && a5 == AspectType.Inconjunct && a6 == AspectType.Square )
                                        bConfigs[13] = true;
                                    else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Inconjunct && a6 == AspectType.Square )
                                        bConfigs[14] = true;
                                    else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Trine && a5 == AspectType.Trine && a6 == AspectType.Square )
                                        bConfigs[15] = true;
                                    else if ( a1 == AspectType.Conjunction && a3 == AspectType.Conjunction && a6 == AspectType.Conjunction && i != j && i != k && i != l && j != k && j != l && k != l )
                                        bConfigs[25] = true;
                                    
                                    for ( m = 0; m <= Planets.MC; m++)
                                    {
                                        if (!aspectKinds[i][m].equals("") && !aspectKinds[j][m].equals("") && !aspectKinds[k][m].equals("") && !aspectKinds[l][m].equals(""))
                                        {
                                            a7 = AspectType.getAspectNBFromSymbol(aspectKinds[i][m]);
                                            a8 = AspectType.getAspectNBFromSymbol(aspectKinds[j][m]);
                                            a9 = AspectType.getAspectNBFromSymbol(aspectKinds[k][m]);
                                            a10 = AspectType.getAspectNBFromSymbol(aspectKinds[l][m]);
                                            if ( a1 == AspectType.Opposition && a3 == AspectType.SemiSextile && a4 == AspectType.Square && a5 == AspectType.Square && a6 == AspectType.Sextile && (a8 == AspectType.Inconjunct || a2 == AspectType.Inconjunct) && a9 == AspectType.Trine && a10 == AspectType.Sextile )
                                                bConfigs[16] = true;
                                            else if ( a1 == AspectType.Opposition && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Square && a5 == AspectType.Square && a6 == AspectType.SemiSextile && a7 == AspectType.Sextile && a8 == AspectType.Trine && a9 == AspectType.Sextile && a10 == AspectType.SemiSextile )
                                                bConfigs[17] = true;
                                            else if ( a1 == AspectType.Sextile && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Trine && a5 == AspectType.Opposition && a6 == AspectType.Trine && a7 == AspectType.Sextile && a8 == AspectType.Trine && a9 == AspectType.Opposition && a10 == AspectType.Sextile )
                                                bConfigs[18] = true;
                                            else if ( a1 == AspectType.Sextile && a3 == AspectType.Square && (a2 == AspectType.Inconjunct || a4 == AspectType.Inconjunct) && (a5 == AspectType.Inconjunct || a9 == AspectType.Inconjunct) && a6 == AspectType.Sextile && a7 == AspectType.Sextile && a8 == AspectType.Trine && a10 == AspectType.Square )
                                                bConfigs[19] = true;
                                            else if ( a1 == AspectType.Trine && a2 == AspectType.Square && a4 == AspectType.Sextile && a5 == AspectType.Sextile && a6 == AspectType.SemiSextile && a8 == AspectType.Square && a9 == AspectType.Sextile && a10 == AspectType.SemiSextile )
                                                bConfigs[20] = true;
                                            else if ( a1 == AspectType.Trine && (a2 == AspectType.Inconjunct || a4 == AspectType.Inconjunct) && a5 == AspectType.Square && a6 == AspectType.Sextile && a7 == AspectType.Trine && a8 == AspectType.Trine && a9 == AspectType.Square && (a3 == AspectType.SemiSextile || a10 == AspectType.SemiSextile) )
                                                bConfigs[21] = true;
                                            else if ( a1 == AspectType.Square && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Sextile && a7 == AspectType.Square && a8 == AspectType.Opposition && a9 == AspectType.Trine && a10 == AspectType.Sextile )
                                                bConfigs[22] = true;
                                            else if ( a1 == AspectType.Conjunction && a3 == AspectType.Conjunction && a6 == AspectType.Conjunction && (a7 == AspectType.Opposition || a8 == AspectType.Opposition || a9 == AspectType.Opposition || a10 == AspectType.Opposition) && i != j && i != k && i != l && j != k && j != l && k != l )
                                                bConfigs[26] = true;
                                            
                                            for ( n = 0; n <= Planets.MC; n++)
                                            {
                                                if (!aspectKinds[i][n].equals("") && !aspectKinds[j][n].equals("") && !aspectKinds[k][n].equals("") && !aspectKinds[l][n].equals("") && !aspectKinds[m][n].equals(""))
                                                {
                                                    a11 = AspectType.getAspectNBFromSymbol(aspectKinds[i][n]);
                                                    a12 = AspectType.getAspectNBFromSymbol(aspectKinds[j][n]);
                                                    a13 = AspectType.getAspectNBFromSymbol(aspectKinds[k][n]);
                                                    a14 = AspectType.getAspectNBFromSymbol(aspectKinds[l][n]);
                                                    a15 = AspectType.getAspectNBFromSymbol(aspectKinds[m][n]);
                                                    if ( a1 == AspectType.Sextile && a2 == AspectType.Inconjunct && a3 == AspectType.Square && a4 == AspectType.Opposition && a5 == AspectType.Trine && a6 == AspectType.SemiSextile && a7 == AspectType.Square && a8 == AspectType.Inconjunct && a9 == AspectType.Trine && a10 == AspectType.Square && a11 == AspectType.SemiSextile && a12 == AspectType.Square && a13 == AspectType.Opposition && a14 == AspectType.Inconjunct && a15 == AspectType.Sextile )
                                                        bConfigs[23] = true;
                                                    else if ( a1 == AspectType.Sextile && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Opposition && a5 == AspectType.Trine && a6 == AspectType.Sextile && a7 == AspectType.Trine && a8 == AspectType.Opposition && a9 == AspectType.Trine && a10 == AspectType.Sextile && a11 == AspectType.Sextile && a12 == AspectType.Trine && a13 == AspectType.Opposition && a14 == AspectType.Trine && a15 == AspectType.Sextile )
                                                        bConfigs[24] = true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        for ( i = 0; i <= Configs.getLast(); i++)
        {
            if ( bConfigs[i] )
            {
                if (strResult.equals(""))
                {
                    strResult = Configs.getConfigName(i);
                }
                else
                {
                    strResult = strResult + ", " + Configs.getConfigName(i);
                }
            }
        }
        //progressConfig.closeForm();
        return strResult;
    }
    
    private String getStepKindName(int stepKind)
    {
        switch(stepKind)
        {
            case 0 : return bundle.getString("year");
            case 1 : return bundle.getString("month");
            case 2 : return bundle.getString("week");
            default: return "";
        }
    }
    
    //=========================================================================
    //Conversion de la longitude d'un astre en strS indiquant la position
    //en degres sexagesimaux dans un signe, et eventuellement le nom du signe
    //input : coordonnee : longitude de l'astre in decimal degrees
    //        astre      : numero de l'astre
    //        option_    : option d'affichage (avec ou sans le nom du signe in the string)
    //        cas        : distinction entre le cas des astres (pour le Soleil) et celui de l'ascendant
    //return             : strS indiquant la position dans le signe
    //=========================================================================
    public static String positionInSign(double coordonnee, byte option_, ChartElements chartElements)
    {
        double lngPos;
        int sysCoord = chartElements.getCoordSys();
        int signe;
        String strS;
        int chartKind = chartElements.getChartKind();
        ChartEvent chartEvent = (ChartEvent)(chartElements.getChartEvents().get(0));
        
        //if we are not in local or equatorial coordinates
        if ((chartKind != ChartKind.local) && (sysCoord != CoordSystem.Equatorial) && (sysCoord != CoordSystem.Local))
        {
            lngPos = AstronomyMaths.modulo(coordonnee, 30.0);
            signe = (int)(coordonnee / 30.0);
            strS = new FDegree(lngPos).getShortDegree();
            if ((option_ == CALCUL) || (chartElements.getSignsNames() == true))
            {
                strS = strS + " " + MainForm.signName[signe];
            }
        }
        else
        {
            strS = new FDegree(coordonnee).getShortDegree();
        }
        
        return strS;
    }

    public static void houseCalc(ChartElements chartElements)
    {
        House h = new House();
        int hSys = chartElements.getHouseSys();
        AllCoord pos1 = (AllCoord)(chartElements.getChartCoords()).get(0); 
        if (hSys == HouseSystem.Nodal)
        {
            h.setMoonNNodeGeoLong(pos1.get(Planets.NorthNode).getTropicGeoLong());
        }
        else if (hSys == HouseSystem.Albategnius)
        {
            h.setSunDecl(pos1.get(Planets.Sun).getDecl());
        }
        else if (hSys == HouseSystem.Solar)
        {
            h.setSunGeoLong(pos1.get(Planets.Sun).getTropicGeoLong());
        }
        h.cuspsCalculation(chartElements);
    }
    
    //Calculation of the barycentre entre les astres principaux selectionnes
    public static void barycenterProcessing(ChartElements chartElements, AllCoord pos1)
    {
        double c;
        //nombre d'astres selectionnes dans les options
        //int nb_astres = 0;
        //poids total des astres
        double poids_total = 0.0;
        //poids d'un astre
        double poids;
        //rayon du cercle interieur du zodiaque
        double radius;
        //angle of the barycenter
        double angle;
        //distances
        double distance_x = 0.0;
        double distance_y = 0.0;
        //=====================================================================
        
        //Calculation of the total weight and of the barycenter distance
        for (int i=0; i<= Planets.Chiron; i++)
        {
            if ( chartElements.getShownObject(i) == true )
            {
                //nb_astres += 1;
                
                if ( chartElements.getSingleWeight() == false )
                {
                    poids = AspectType.orbCalculation(i, i, AspectType.Conjunction, chartElements);
                }
                else
                {
                    poids = 1.0;
                }
                poids_total += poids;
                c = pos1.get(i).getCoord1(chartElements.getCoordSys());
                distance_x += poids * AstronomyMaths.cosD(c);
                distance_y += poids * AstronomyMaths.sinD(c);
            }
        }
        
        //autres resultats pour le positionnement du barycentre
        //-----------------------------------------------------
        //distance par rapport au centre projetee sur x
        distance_x /= poids_total;
        
        //distance par rapport au centre projetee sur y
        distance_y /= poids_total;
        
        //calcul de l'angle pour les positions 1
        angle = AstronomyMaths.modulo(AstronomyMaths.atn_Div(distance_y, distance_x) - 90.0 * (1 - AstronomyMaths.sgn(distance_x)), 360.0);
        
        //Calculation of the radius for the positions 1
        radius = java.lang.Math.sqrt(distance_x * distance_x + distance_y * distance_y);
        
        //update pos1
        pos1.get(Planets.Barycenter).setRadius(radius);
        pos1.get(Planets.Barycenter).setTheta(angle);
    }
    
    //Calculation of la carte composite entre deux ou plusieurs cartes du ciel
    
    //get the current record
    @SuppressWarnings("unchecked")
    private void compositeProcessing()
    {
        ArrayList events = chartElements.getChartEvents();
        ArrayList positions = chartElements.getChartCoords();
        if (events.size() != chartElements.getChartCompositeNB() && positions.size() != events.size()) return;
        
        AllCoord pos[] = new AllCoord[positions.size()];
        AllCoord pos2 = new AllCoord();
        ChartEvent ev[] = new ChartEvent[events.size()];
        ChartElements chartElements2;
        
        //calculate the chart elements for each one
        for (int k = 0; k< events.size(); k++)
        {
            AllCoord newCoord = (AllCoord)positions.get(k);
            if (newCoord == null)
            {
                ev[k] = (ChartEvent)events.get(k);
                chartElements2 = chartElements.cloneInitElements();
                ArrayList events2 = new ArrayList();
                events2.add(ev[k]);
                chartElements2.setChartEvents(events2);
                chartCalculation(chartElements2);
                //ArrayList positions2 = chartElements.getChartCoords();
                int chartKind = chartElements2.getChartKind();
                ArrayList positions2 = chartElements2.getChartCoords();
                pos[k] = (AllCoord)positions2.get(0);
            }
            else
            {
                pos[k] = newCoord;
            }
        }
        
        //cosinus et sinus de barycentre de la coordonnee1 de chaque astre
        double cos_bary[][] = new double[Planets.getLast()][6];
        double sin_bary[][] = new double[Planets.getLast()][6];
        //angle du barycentre de la coordonnee1 de chaque astre
        double angle[][] = new double[Planets.getLast()][6];
        final int GEO_TROPIC = 0;
        final int GEO_SIDER = 1;
        final int RA_ = 2;
        final int AZ_ = 3;
        final int HELIO_TROPIC = 4;
        final int HELIO_SIDER = 5;
        int nb_event = 1;
        //=====================================================================
        
        //passage a la domification identique/AS ou MC (suivant l'option cochee dans la feuille)
        if ( chartElements.getChartCompositeFromAS() == true )
        {
            chartElements.setHouseSys(HouseSystem.MaternusAs);
        }
        else
        {
            chartElements.setHouseSys(HouseSystem.MaternusMC);
        }
        
        //Keep coordinates
        //----------------
        for( int i=0; i<Planets.getLast(); i++)
        {
            pos2.set(pos[0].get(i), i);
            pos2.get(i).setRetro(0);
            cos_bary[i][GEO_TROPIC] = AstronomyMaths.cosD(pos[0].get(i).getTropicGeoLong());
            sin_bary[i][GEO_TROPIC] = AstronomyMaths.sinD(pos[0].get(i).getTropicGeoLong());
            cos_bary[i][GEO_SIDER] = AstronomyMaths.cosD(pos[0].get(i).getSiderGeoLong());
            sin_bary[i][GEO_SIDER] = AstronomyMaths.sinD(pos[0].get(i).getSiderGeoLong());
            cos_bary[i][HELIO_TROPIC] = AstronomyMaths.cosD(pos[0].get(i).getTropicHelioLong());
            sin_bary[i][HELIO_TROPIC] = AstronomyMaths.sinD(pos[0].get(i).getTropicHelioLong());
            cos_bary[i][HELIO_SIDER] = AstronomyMaths.cosD(pos[0].get(i).getSiderHelioLong());
            sin_bary[i][HELIO_SIDER] = AstronomyMaths.sinD(pos[0].get(i).getSiderHelioLong());
            cos_bary[i][RA_] = AstronomyMaths.cosD(pos[0].get(i).getRA());
            sin_bary[i][RA_] = AstronomyMaths.sinD(pos[0].get(i).getRA());
            cos_bary[i][AZ_] = AstronomyMaths.cosD(pos[0].get(i).getAz());
            sin_bary[i][AZ_] = AstronomyMaths.sinD(pos[0].get(i).getAz());
        }
        
        //tant que le nombre d'evenements restant � rentrer est inferieur au nombre souhaite au depart
        while (nb_event < chartElements.getChartCompositeNB())
        {
            //pour chaque astre i, on ajoute sa coordonnee 1
            //a la somme de celles du meme astre pour les evenements precedents
            //et on fait de meme pour la coordonnee 2
            //-----------------------------------------------------------------
            for( int i=0; i<Planets.getLast(); i++)
            {
                pos2.get(i).setSiderGeoLong(pos[nb_event].get(i).getSiderGeoLong() + pos2.get(i).getSiderGeoLong());
                pos2.get(i).setDecl(pos[nb_event].get(i).getDecl() + pos2.get(i).getDecl());
                pos2.get(i).setRA(pos[nb_event].get(i).getRA() + pos2.get(i).getRA());
                pos2.get(i).setAz(pos[nb_event].get(i).getAz() + pos2.get(i).getAz());
                pos2.get(i).setAlt(pos[nb_event].get(i).getAlt() + pos2.get(i).getAlt());
                pos2.get(i).setTropicGeoLong(pos[nb_event].get(i).getTropicGeoLong() + pos2.get(i).getTropicGeoLong());
                pos2.get(i).setGeoLat(pos[nb_event].get(i).getGeoLat() + pos2.get(i).getGeoLat());
                pos2.get(i).setHelioLat(pos[nb_event].get(i).getHelioLat() + pos2.get(i).getHelioLat());
                pos2.get(i).setTropicHelioLong(pos[nb_event].get(i).getTropicHelioLong() + pos2.get(i).getTropicHelioLong());
                pos2.get(i).setSiderHelioLong(pos[nb_event].get(i).getSiderHelioLong() + pos2.get(i).getSiderHelioLong());
                pos2.get(i).setGeoDist(pos[nb_event].get(i).getGeoDist() + pos2.get(i).getGeoDist());
                pos2.get(i).setHelioDist(pos[nb_event].get(i).getHelioDist() + pos2.get(i).getHelioDist());
                cos_bary[i][GEO_TROPIC] = cos_bary[i][GEO_TROPIC] + AstronomyMaths.cosD(pos[nb_event].get(i).getTropicGeoLong());
                sin_bary[i][GEO_TROPIC] = sin_bary[i][GEO_TROPIC] + AstronomyMaths.sinD(pos[nb_event].get(i).getTropicGeoLong());
                cos_bary[i][GEO_SIDER] = cos_bary[i][GEO_SIDER] + AstronomyMaths.cosD(pos[nb_event].get(i).getSiderGeoLong());
                sin_bary[i][GEO_SIDER] = sin_bary[i][GEO_SIDER] + AstronomyMaths.sinD(pos[nb_event].get(i).getSiderGeoLong());
                cos_bary[i][HELIO_TROPIC] = cos_bary[i][HELIO_TROPIC] + AstronomyMaths.cosD(pos[nb_event].get(i).getTropicHelioLong());
                sin_bary[i][HELIO_TROPIC] = sin_bary[i][HELIO_TROPIC] + AstronomyMaths.sinD(pos[nb_event].get(i).getTropicHelioLong());
                cos_bary[i][HELIO_SIDER] = cos_bary[i][HELIO_SIDER] + AstronomyMaths.cosD(pos[nb_event].get(i).getSiderHelioLong());
                sin_bary[i][HELIO_SIDER] = sin_bary[i][HELIO_SIDER] + AstronomyMaths.sinD(pos[nb_event].get(i).getSiderHelioLong());
                cos_bary[i][RA_] = cos_bary[i][RA_] + AstronomyMaths.cosD(pos[nb_event].get(i).getRA());
                sin_bary[i][RA_] = sin_bary[i][RA_] + AstronomyMaths.sinD(pos[nb_event].get(i).getRA());
                cos_bary[i][AZ_] = cos_bary[i][AZ_] + AstronomyMaths.cosD(pos[nb_event].get(i).getAz());
                sin_bary[i][AZ_] = sin_bary[i][AZ_] + AstronomyMaths.sinD(pos[nb_event].get(i).getAz());
            }
            
            //incrementation du nombre d'evenements traites
            nb_event += 1;
        }
        
        //moyenne des coordonnees 1 et 2 de chaque astre plus ASCT_ et MC
        //sur l'ensemble des evenements et angle du barycentre
        //correspondant pour correction eventuelle de la coordonnee
        for( int i=0; i<Planets.getLast(); i++)
        {
            pos2.get(i).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(i).getSiderGeoLong() / nb_event, 360.0));
            pos2.get(i).setDecl(pos2.get(i).getDecl() / nb_event);
            pos2.get(i).setRA(AstronomyMaths.modulo(pos2.get(i).getRA() / nb_event, 360.0));
            pos2.get(i).setAz(AstronomyMaths.modulo(pos2.get(i).getAz() / nb_event, 360.0));
            pos2.get(i).setAlt(pos2.get(i).getAlt() / nb_event);
            pos2.get(i).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(i).getTropicGeoLong() / nb_event, 360.0));
            pos2.get(i).setGeoLat(pos2.get(i).getGeoLat() / nb_event);
            pos2.get(i).setHelioLat(pos2.get(i).getHelioLat() / nb_event);
            pos2.get(i).setTropicHelioLong(AstronomyMaths.modulo(pos2.get(i).getTropicHelioLong() / nb_event, 360.0));
            pos2.get(i).setSiderHelioLong(AstronomyMaths.modulo(pos2.get(i).getSiderHelioLong() / nb_event, 360.0));
            pos2.get(i).setGeoDist(pos2.get(i).getGeoDist() / nb_event);
            pos2.get(i).setHelioDist(pos2.get(i).getHelioDist() / nb_event);
            
            angle[i][GEO_TROPIC] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][GEO_TROPIC], cos_bary[i][GEO_TROPIC]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][GEO_TROPIC])), 360.0);
            pos2.get(i).setTropicGeoLong(pos2.get(i).getTropicGeoLong() + 360.0 / nb_event * ((angle[i][GEO_TROPIC] - pos2.get(i).getTropicGeoLong()) / 360.0 * nb_event));
            
            angle[i][GEO_SIDER] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][GEO_SIDER], cos_bary[i][GEO_SIDER]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][GEO_SIDER])), 360.0);
            pos2.get(i).setSiderGeoLong(pos2.get(i).getSiderGeoLong() + 360.0 / nb_event * ((angle[i][GEO_SIDER] - pos2.get(i).getSiderGeoLong()) / 360.0 * nb_event));
            
            angle[i][HELIO_TROPIC] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][HELIO_TROPIC], cos_bary[i][HELIO_TROPIC]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][HELIO_TROPIC])), 360.0);
            pos2.get(i).setTropicHelioLong(pos2.get(i).getTropicHelioLong() + 360.0 / nb_event * ((angle[i][HELIO_TROPIC] - pos2.get(i).getTropicHelioLong()) / 360.0 * nb_event));
            
            angle[i][HELIO_SIDER] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][HELIO_SIDER], cos_bary[i][HELIO_SIDER]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][HELIO_SIDER])), 360.0);
            pos2.get(i).setSiderHelioLong(pos2.get(i).getSiderHelioLong() + 360.0 / nb_event * ((angle[i][HELIO_SIDER] - pos2.get(i).getSiderHelioLong()) / 360.0 * nb_event));
            
            angle[i][RA_] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][RA_], cos_bary[i][RA_]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][RA_])), 360.0);
            pos2.get(i).setRA(pos2.get(i).getRA() + 360.0 / nb_event * ((angle[i][RA_] - pos2.get(i).getRA()) / 360.0 * nb_event));
            
            angle[i][AZ_] = AstronomyMaths.modulo(AstronomyMaths.atn_Div(sin_bary[i][AZ_], cos_bary[i][AZ_]) + 90.0 * (1 - AstronomyMaths.sgn(cos_bary[i][AZ_])), 360.0);
            pos2.get(i).setAz(pos2.get(i).getAz() + 360.0 / nb_event * ((angle[i][AZ_] - pos2.get(i).getAz()) / 360.0 * nb_event));
        }
        
        //special case of the houses
        for (int i = 0; i< Cusp.House12; i++)
        {
            if ( chartElements.getChartCompositeFromAS() == true )
            {
                pos2.get(Planets.MC + i + 1).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(Planets.AS).getSiderGeoLong() + 30.0 * i, 360.0));
                pos2.get(Planets.MC + i + 1).setRA(AstronomyMaths.modulo(pos2.get(Planets.AS).getRA() + 30.0 * i, 360.0));
                pos2.get(Planets.MC + i + 1).setAz(AstronomyMaths.modulo(pos2.get(Planets.AS).getAz() + 30.0 * i, 360.0));
                pos2.get(Planets.MC + i + 1).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(Planets.AS).getTropicGeoLong() + 30.0 * i, 360.0));
                pos2.get(Planets.MC + i + 1).setTropicHelioLong(AstronomyMaths.modulo(pos2.get(Planets.AS).getTropicHelioLong() + 30.0 * i, 360.0));
                pos2.get(Planets.MC + i + 1).setSiderHelioLong(AstronomyMaths.modulo(pos2.get(Planets.AS).getSiderHelioLong() + 30.0 * i, 360.0));
                
            }
            else
            {
                pos2.get(Planets.MC + i + 1).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(Planets.MC).getSiderGeoLong() + (i + 3) * 30.0, 360.0));
                pos2.get(Planets.MC + i + 1).setRA(AstronomyMaths.modulo(pos2.get(Planets.MC).getRA() + (i + 3) * 30.0, 360.0));
                pos2.get(Planets.MC + i + 1).setAz(AstronomyMaths.modulo(pos2.get(Planets.MC).getAz() + (i + 3) * 30.0, 360.0));
                pos2.get(Planets.MC + i + 1).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(Planets.MC).getTropicGeoLong() + (i + 3) * 30.0, 360.0));
                pos2.get(Planets.MC + i + 1).setTropicHelioLong(AstronomyMaths.modulo(pos2.get(Planets.MC).getTropicHelioLong() + (i + 3) * 30.0, 360.0));
                pos2.get(Planets.MC + i + 1).setSiderHelioLong(AstronomyMaths.modulo(pos2.get(Planets.MC).getSiderHelioLong() + (i + 3) * 30.0, 360.0));
            }
        }
        
        //set the new coordinates
        pos[0] = new AllCoord();
        positions = new ArrayList();
        positions.add(pos2);
        positions.add(pos[0]);
        chartElements.setChartCoords(positions);
    }
    
    private double getStepKindMultiplier(int stepKind)
    {
        switch(stepKind)
        {
            case 0 : return 1.0;
            case 1 : return 12.0;
            case 2 : return 52.0;
            default: return 0.0;
        }
    }
    
    //Calculation of directions and transits
    //get the current record
    @SuppressWarnings("unchecked")
    private void directionsAndTransitsProcessing()
    {
        ArrayList events = chartElements.getChartEvents();
        ArrayList positions = chartElements.getChartCoords();
        if (positions.size() != events.size()) return;
        
        ArrayList positions2;// = new ArrayList();
        AllCoord pos1 = (AllCoord)positions.get(0);
        AllCoord pos2 = new AllCoord();
        ChartEvent ev1 = (ChartEvent)events.get(0);
        ChartEvent ev2 = ev1.cloneEvent();
        ArrayList events2;// = new ArrayList();
        ChartElements chartElements2 = chartElements.cloneInitElements();
        
        //age
        double age;
        //Right ascension et declinaison pour le calcul des directions primaires
        double alpha;
        double delta;
        //auxiliary variable
        double aux;
        //=====================================================================
        
        //directions secondaires ou symboliques
        if (chartElements.getChartKind() == ChartKind.secondaryDir || chartElements.getChartKind() == ChartKind.symbolicDir)
        {
            //Get the nouvelle date d'apres l'age rentre
            if (chartElements.getChartKind() == ChartKind.secondaryDir)
            {
                //(la nouvelle date est egale � l'ancienne augmentee d'un nombre de jours egal au nombre de l'age
                age = chartElements.getChartDir2Corresp() * chartElements.getDir2Age() * getStepKindMultiplier(chartElements.getChartDir2SpaceKind()) / chartElements.getChartDir2Day();
                //Calculation of the local sidereal time pour la nouvelle date
                ev2.addTime2CTimeH(age * 24.0);
            }
            else
            {
                age = chartElements.getChartDirSCorresp() * chartElements.getDirSAge() * getStepKindMultiplier(chartElements.getChartDirSSpaceKind()) / chartElements.getChartDirSDegree();
            }
            events2 = new ArrayList();
            events2.add(ev2);
            chartElements2.setChartEvents(events2);
            
            //calcul des donnees relatives � la carte du ciel of the event pour la nouvelle date
            chartCalculation(chartElements2);
            positions2 = chartElements2.getChartCoords();
            pos2 = (AllCoord)positions2.get(0);
            
            //calcul des nouvelles coordonnees des astres
            //and get the first chart coordinates from pos_save1
            for( int i=0; i<Planets.getLast(); i++)
            {
                if (chartElements.getChartKind() == ChartKind.symbolicDir)
                {
                    pos2.get(i).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(i).getSiderGeoLong() + age, 360.0));
                    pos2.get(i).setDecl(pos2.get(i).getDecl());
                    pos2.get(i).setRA(AstronomyMaths.modulo(pos2.get(i).getRA() + age, 360.0));
                    pos2.get(i).setAz(AstronomyMaths.modulo(pos2.get(i).getAz() + age, 360.0));
                    pos2.get(i).setAlt(pos2.get(i).getAlt());
                    pos2.get(i).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(i).getTropicGeoLong() + age, 360.0));
                    pos2.get(i).setGeoLat(pos2.get(i).getGeoLat());
                    pos2.get(i).setHelioLat(pos2.get(i).getHelioLat());
                    pos2.get(i).setTropicHelioLong(AstronomyMaths.modulo(pos2.get(i).getTropicHelioLong() + age, 360.0));
                    pos2.get(i).setSiderHelioLong(AstronomyMaths.modulo(pos2.get(i).getSiderHelioLong() + age, 360.0));
                    pos2.get(i).setGeoDist(pos2.get(i).getGeoDist());
                    pos2.get(i).setHelioDist(pos2.get(i).getHelioDist());
                    pos2.get(i).setRetro(pos2.get(i).getRetro());
                }
                else
                {
                    pos2.get(i).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(i).getSiderGeoLong(), 360.0));
                    pos2.get(i).setDecl(pos2.get(i).getDecl());
                    pos2.get(i).setRA(AstronomyMaths.modulo(pos2.get(i).getRA(), 360.0));
                    pos2.get(i).setAz(AstronomyMaths.modulo(pos2.get(i).getAz(), 360.0));
                    pos2.get(i).setAlt(pos2.get(i).getAlt());
                    pos2.get(i).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(i).getTropicGeoLong(), 360.0));
                    pos2.get(i).setGeoLat(pos2.get(i).getGeoLat());
                    pos2.get(i).setHelioLat(pos2.get(i).getHelioLat());
                    pos2.get(i).setTropicHelioLong(AstronomyMaths.modulo(pos2.get(i).getTropicHelioLong(), 360.0));
                    pos2.get(i).setSiderHelioLong(AstronomyMaths.modulo(pos2.get(i).getSiderHelioLong(), 360.0));
                    pos2.get(i).setGeoDist(pos2.get(i).getGeoDist());
                    pos2.get(i).setHelioDist(pos2.get(i).getHelioDist());
                    pos2.get(i).setRetro(pos2.get(i).getRetro());
                }
            }
        }
        
        //directions primaires
        else if (chartElements.getChartKind() == ChartKind.primaryDir)
        {
            //saisie de l'age (24 heures correspond � 360�, et 1� correspond � 1 an)
            age = chartElements.getChartDir1Corresp() * chartElements.getDir1Age() * getStepKindMultiplier(chartElements.getChartDir1SpaceKind()) / chartElements.getChartDir1Degree() / 360;
            
            //Get the new date
            //(la nouvelle date est egale � l'ancienne augmentee d'un nombre d'heures egal au nombre de l'age divise par 15
            ev2.addTime2CTimeH(age / 24.0);
            
            //calcul des donnees relatives � la carte du ciel of the event pour la nouvelle date
            events2 = new ArrayList();
            events2.add(ev2);
            chartElements2.setChartEvents(events2);
            
            //calcul des donnees relatives � la carte du ciel of the event pour la nouvelle date
            chartCalculation(chartElements2);
            positions2 = chartElements2.getChartCoords();
            pos2 = (AllCoord)positions2.get(0);
            
            //recalculate houses positions with the new time
            ChartEvent ev3 = ev1.cloneEvent();
            ArrayList events3 = new ArrayList();
            ChartElements chartElements3 = chartElements.cloneInitElements();
            ev3.addTime2CTimeH(age * 24.0);
            events3.add(ev3);
            chartElements3.setChartEvents(events3);
            houseCalc(chartElements3);
            ArrayList positions3 = chartElements3.getChartCoords();
            AllCoord pos3 = (AllCoord)positions3.get(0);
            for (int i = Planets.AS; i <= Planets.House12; i++)
            {
                pos2.set(pos3.get(i), i);
            }
            
            //calcul des nouvelles coordonnees des astres
            for( int i=0; i<Planets.AS; i++)
            {
                //passage en coordonnees equatoriales
                alpha = pos2.get(i).getRA();
                delta = pos2.get(i).getDecl();
                
                //modification or the Right ascension
                if ( i < Planets.AS && (i != Planets.OtherPoint ||(i == Planets.OtherPoint && chartElements.getOtherPointType() != OtherPt.star && chartElements.getOtherPointType() != OtherPt.part)) )
                {
                    aux = AstronomyMaths.modulo(alpha - age * 360.0, 360.0);
                    //retour eventuel au coordinates system initial
                    //(si l'on n'est pas dej� en equatoriales)
                    pos2.get(i).setRA(aux);
                }
                else
                {
                    aux = alpha;
                }
                
                //retour eventuel au coordinates system initial
                //(si l'on n'est pas dej� en equatoriales)
                //pos2.get(i).setRA(aux);
                //pos2.get(i).setDecl(delta);
                
                if ( Math.abs(aux) != 90.0 )
                {
                    pos2.get(i).setTropicGeoLong(AstronomyMaths.atnD((AstronomyMaths.sinD(ev2.getObliquity()) * AstronomyMaths.tanD(delta) + AstronomyMaths.cosD(ev2.getObliquity()) * AstronomyMaths.sinD(aux)) / AstronomyMaths.cosD(aux)));
                    pos2.get(i).setTropicGeoLong(AstronomyMaths.modulo(pos2.get(i).getTropicGeoLong() + 90.0 * (1 - AstronomyMaths.sgn(AstronomyMaths.cosD(aux))), 360.0));
                }
                else
                {
                    pos2.get(i).setTropicGeoLong(90.0 * AstronomyMaths.sgn(aux));
                }
                
                if ( !(i != Planets.OtherPoint || ((i == Planets.OtherPoint) && ((chartElements.getOtherPointType() == OtherPt.star) || (chartElements.getOtherPointType() == OtherPt.part)))) )
                {
                    ev2.setAyanamsa(0.0);
                }
                pos2.get(i).setSiderGeoLong(AstronomyMaths.modulo(pos2.get(i).getTropicGeoLong() - 360.0, 360.0));
                pos2.get(i).setTropicHelioLong(pos1.get(i).getTropicHelioLong());
                pos2.get(i).setSiderHelioLong(pos1.get(i).getSiderHelioLong());
                pos2.get(i).setHelioLat(pos1.get(i).getHelioLat());
                pos2.get(i).setAlt(pos2.get(i).altFromEquatorial(ev2.getPlaceLat(), ev2.getLST()));
                pos2.get(i).setAz(pos2.get(i).azFromEquatorial(ev2.getPlaceLat(), ev2.getLST()));
                pos2.get(i).setGeoDist(pos1.get(i).getGeoDist());
                pos2.get(i).setHelioDist(pos1.get(i).getHelioDist());
                pos2.get(i).setRetro(pos1.get(i).getRetro());
            }
        }
        
        //transits
        else if (chartElements.getChartKind() == ChartKind.transit)
        {
            //get the transit time and date
            String sDateTime = chartElements.getTransitsDate();
            String sDate = sDateTime;
            String sTime = MainClass.STIME_000000;
            int pos = sDateTime.indexOf(";");
            if (pos >= 0)
            {
                sTime = sDateTime.substring(pos+1);
                sDate = sDateTime.substring(0, pos);
            }
            
            FDate date = new FDate(sDate);
            FTime time = new FTime(sTime);
            double jd = AstronomyMaths.gregorianToJulian(date.getDay(), date.getMonth(), date.getYear());
            double t = time.getDecimalHour();
            
            //deduce values for the event
            ev2.deduceValues(ev1.getEvent().getPlace(), ev1.getPlaceLat(), ev1.getPlaceLong(), AstronomyMaths.modulo(ev1.getTime() + t, 24.0), sDate);
            
            //new chart data
            events2 = new ArrayList();
            events2.add(ev2);
            chartElements2.setChartEvents(events2);
            chartCalculation(chartElements2);
            positions2 = chartElements2.getChartCoords();
            pos2 = (AllCoord)positions2.get(0);
        }
        
        positions.add(pos2);
        events.add(ev2);
        chartElements.setChartCoords(positions);
    }
    
    //Calcul d'une carte harmonique
    //get the current record
    @SuppressWarnings("unchecked")
    public static AllCoord harmonicCalculation(int harmoVal, AllCoord posIni)
    {
        AllCoord posResult = posIni.cloneCoords();
        for( int i=0; i<Planets.getLast(); i++)
        {
            posResult.get(i).setSiderGeoLong(AstronomyMaths.modulo(harmoVal * posIni.get(i).getSiderGeoLong(), 360.0));
            posResult.get(i).setRA(AstronomyMaths.modulo(harmoVal * posIni.get(i).getRA(), 360.0));
            posResult.get(i).setAz(AstronomyMaths.modulo(harmoVal * posIni.get(i).getAz(), 360.0));
            posResult.get(i).setTropicGeoLong(AstronomyMaths.modulo(harmoVal * posIni.get(i).getTropicGeoLong(), 360.0));
            posResult.get(i).setTropicHelioLong(AstronomyMaths.modulo(harmoVal * posIni.get(i).getTropicHelioLong(), 360.0));
            posResult.get(i).setSiderHelioLong(AstronomyMaths.modulo(harmoVal * posIni.get(i).getSiderHelioLong(), 360.0));
        }
        return posResult;
    }
    
    //=====================================================================
    //Calculs relatifs � l'etablissement d'une carte du ciel astrologique
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    public final void chartCalculation(ChartElements chartElements)
    {
        int chartKind = chartElements.getChartKind();
        if (chartKind == ChartKind.noChart) return;
        ArrayList chartEvents = chartElements.getChartEvents();
        ChartEvent ev = (ChartEvent)chartEvents.get(0);
        AllCoord allCoord1 = new AllCoord();
        
        //heliocentric longitudes for the considered date and for five minutes after, in order to find the retrogradations
        double longitude_geo[][] = new double[Planets.Chiron + 1][2];
        //longitude difference
        double ecart_longitude;
        //One hour motion
        double h_motion;
        Planet p;
        //String nom_autre_pt = chartElements.getOtherPointName();
        //============================================================================================
        
        //CALCUL des positions planetaires au jour_seculaire plus 5 minutes
        //en vue de reperer les astres en retrogradation apparante
        //=================================================================
        ChartEvent ev2 = ev.cloneEvent();
        ev2.addTime2CTimeH(5.0 / 60.0);
        p = new Planet(ev2, chartElements.getTrueLilith());
        for (int i = Planets.Sun; i <= Planets.Vulcan; i++)
        {
            if ( chartKind == ChartKind.projective && i >= Planets.Pluto )
            {
                break;
            }
            longitude_geo[i][1] = p.getObjPosition(i).getTropicGeoLong();
        }
        
        if ( chartKind != ChartKind.projective )
        {
            //asteroides
            for (int i = Planets.Ceres; i<= Planets.Chiron; i++)
            {
                CometAsteroid asteroid = new CometAsteroid(chartElements);
                if (asteroid != null)
                {
                    String asteroidID = asteroid.getAsteroidID(i);
                    if(asteroidID != null && !asteroidID.equals(""))
                    {
                        Asteroid a = starLoginManager.getAsteroid(asteroidID, "");
                        longitude_geo[i][1] = asteroid.calculateAsteroid(a).getCoord1(chartElements.getCoordSys());
                    }
                }
            }
            
            //"autre point" (voir la feuille "options")
            //-----------------------------------------------
            //i = Planets.OtherPoint;
            switch (chartElements.getOtherPointType())
            {
                case OtherPt.comet:
                    CometAsteroid comet = new CometAsteroid(chartElements);
                    Comet c = starLoginManager.getComet(comet.getCometIDFromName(chartElements.getOtherPointName(), starLoginManager.getComets().getRecords()), "");
                    longitude_geo[Planets.OtherPoint][1] = comet.calculateComet(c).getCoord1(chartElements.getCoordSys());
                    
                    break;
                    
                case OtherPt.asteroid:
                    CometAsteroid asteroid = new CometAsteroid(chartElements);
                    Asteroid a = starLoginManager.getAsteroid(asteroid.getAsteroidIDFromName(chartElements.getOtherPointName(), starLoginManager.getAsteroids().getRecords()), "");
                    longitude_geo[Planets.OtherPoint][1] = asteroid.calculateAsteroid(a).getCoord1(chartElements.getCoordSys());
                    break;
                    
                default:
                    break;
            }
        }
        
        //calcul des positions planetaires au temps seculaire
        //===================================================
        p = new Planet(ev, chartElements.getTrueLilith());
        for (int i = Planets.Sun; i <= Planets.Vulcan; i++)
        {
            if ( chartKind == ChartKind.projective &&  i >= Planets.Pluto )
            {
                break;
            }
            allCoord1.set(p.getObjPosition(i), i);
            longitude_geo[i][0] = p.getObjPosition(i).getTropicGeoLong();
        }
        
        if ( chartKind != ChartKind.projective )
        {
            //asteroids
            for (int i = Planets.Ceres; i<= Planets.Chiron; i++)
            {
                CometAsteroid asteroid = new CometAsteroid(chartElements);
                if (asteroid != null)
                {
                    Coord asteroidCoord = asteroid.calculateAsteroid(starLoginManager.getAsteroid(asteroid.getAsteroidID(i), ""));
                    allCoord1.set(asteroidCoord ,i);
                    longitude_geo[i][0] = asteroidCoord.getCoord1(chartElements.getCoordSys());
                }
            }
        }
        
        //set the positions into chartElements
        ArrayList positions = new ArrayList();
        positions.add(allCoord1);
        chartElements.setChartCoords(positions);
        
        //calcul des pointes de maison
        houseCalc(chartElements);
        
        if ( chartKind != ChartKind.projective )
        {
            //other point
            switch(chartElements.getOtherPointType())
            {
                case OtherPt.star:
                    ArrayList stars = starLoginManager.getStars().getRecords();
                    Astronomy.starPosition(chartElements, stars);
                    AllCoord allC = (AllCoord)chartElements.getChartCoords().get(0);
                    allCoord1.set(allC.get(Planets.OtherPoint), Planets.OtherPoint);
                    break;
                    
                case OtherPt.part:
                    String otherPtName = chartElements.getOtherPointName();
                    if (!otherPtName.equals(""))
                    {
                        Part part = starLoginManager.getPartFromName(otherPtName);
                        allCoord1.set(partCalculation(part.getRef(), part.getPlus(), part.getMinus(), chartElements), Planets.OtherPoint);
                    }
                    break;
                    
                case OtherPt.comet:
                    CometAsteroid comet = new CometAsteroid(chartElements);
                    Coord cometCoord = comet.calculateComet(starLoginManager.getComet(comet.getCometIDFromName(chartElements.getOtherPointName(), starLoginManager.getComets().getRecords()), ""));
                    allCoord1.set(cometCoord, Planets.OtherPoint);
                    break;
                    
                case OtherPt.asteroid:
                    CometAsteroid asteroid = new CometAsteroid(chartElements);
                    Coord asteroidCoord = asteroid.calculateAsteroid(starLoginManager.getAsteroid(asteroid.getAsteroidIDFromName(chartElements.getOtherPointName(), starLoginManager.getAsteroids().getRecords()), ""));
                    allCoord1.set(asteroidCoord, Planets.OtherPoint);
                    break;
                    
                default:
                    break;
            }
            longitude_geo[Planets.OtherPoint][0] = allCoord1.get(Planets.OtherPoint).getTropicGeoLong();
        }
        
        //test de retrogradation
        for (int i = Planets.Mercury; i <= Planets.Chiron; i++)
        {
            if ( chartKind == ChartKind.projective && i >= Planets.Pluto )
            {
                break;
            }
            
            if ((i <= Planets.Lilith ) || (i >= Planets.Ceres ))
            {
                ecart_longitude = longitude_geo[i][1] - longitude_geo[i][0];
                
                //retrogradation condition
                if (((ecart_longitude < 0) && (ecart_longitude > -180)) || (ecart_longitude > 180))
                {
                    allCoord1.get(i).setRetro(Retro.Retro);
                }
                
                //stationary state condition
                if ( MainClass.astrobj[i].getPeriod() > 0 )
                {
                    if ( ecart_longitude > 180 )
                    {
                        ecart_longitude = ecart_longitude - 360;
                        ecart_longitude = Math.abs(ecart_longitude);
                        h_motion = 0.00015 / MainClass.astrobj[i].getPeriod();
                        if ( ecart_longitude < h_motion )
                        {
                            allCoord1.get(i).setRetro(Retro.Static);
                        }
                    }
                }
            }
            
            else if (i == Planets.OtherPoint)
            {
                //retrogradation pour comete ou asteroide
                if ((chartElements.getOtherPointType() == OtherPt.comet) || (chartElements.getOtherPointType() == OtherPt.asteroid))
                {
                    ecart_longitude = longitude_geo[Planets.OtherPoint][1] - longitude_geo[Planets.OtherPoint][0];
                    if (((ecart_longitude < 0) && (ecart_longitude > -180)) || (ecart_longitude > 180))
                    {
                        allCoord1.get(Planets.OtherPoint).setRetro(Retro.Retro);
                    }
                }
            }
        }
    }
    
    private void revolutionsProcessing()
    {
        int astre1 = chartElements.getChartReturnPlanet();
        int astre2 = Planets.None;
        planetaryRevolution(astre1, astre2, false, chartElements);
    }
    
    private void cycleProcessing()
    {
        int astre1 = chartElements.getChartCyclePlanet1();
        int astre2 = chartElements.getChartCyclePlanet2();
        planetaryRevolution(astre1, astre2, false, chartElements);
    }
    
    //=====================================================================
    //Calculation of cycles ou de revolutions planetaires
    //input : astre1         : numero du premier astre considere
    //        astre2         : numero du second astre (ou indication d'un seul astre � prendre en compte)
    //        temps_seculaire: date exprimee en siecles, depuis le 1/1/1900
    //        heure_TU       : heure en temps universel
    //        jour_julien    : Julian Day de la date
    //        tsl            : local sidereal time
    //        tsg0           : temps sideral de Greenwich � 0 h TU
    //return                 : indicateur d'interruption ou de validite
    //=====================================================================
    //get the current record
    @SuppressWarnings("unchecked")
    public void planetaryRevolution(int astre1, int astre2, boolean lookingForDate, ChartElements chartElements)
    {
        ArrayList events = chartElements.getChartEvents();
        ArrayList positions = chartElements.getChartCoords();
        if ((events.size() != chartElements.getChartCompositeNB()) && (positions.size() != events.size())) return;
        
        AllCoord pos1 = (AllCoord)positions.get(0);
        AllCoord pos2 = new AllCoord();
        ChartEvent ev1 = (ChartEvent)events.get(0);
        ChartEvent ev = ev1.cloneEvent();
        
        boolean precession = chartElements.getChartReturnPrecess();
        int sysCoord = chartElements.getCoordSys();
        String sPlace;
        //geocentric longitude de l'astre 1
        double position_coord1;
        //geocentric longitude de l'astre 2
        double position_coord2 = 0.0;
        //precedente geocentric longitude de l'astre 1
        double old_position_coord1;
        //precedente geocentric longitude de l'astre 2
        double old_position_coord2 = 0.0;
        //tableau des longitudes geocentriques pour la date consideree et une minute avant la date, afin de determiner si l'astre est retrograde ou non
        double position_coord_astre[] = new double[Planets.getLast()];
        //ecart en degres entre la longitude de revolution solaire et l'initiale
        double ecart_longitude;
        //aspect initial entre les deux astres, en cas de cycle
        double initialDelta = 0.0;
        //ecart en degres entre la longitude de revolution solaire et l'initiale pour l'astre 1
        double ecart_longitude1;
        //ecart en degres entre la longitude de revolution solaire et l'initiale pour l'astre 2
        double ecart_longitude2 = 0.0;
        //period of the planet 1 exprimee en annees dans le fichier astre.don
        double periode1;
        //period of the planet 2 exprimee en annees dans le fichier astre.don
        double periode2;
        //sauvegarde de l'ecart en longitude
        double old_ecart;
        //partie fractionnaire d'une revolution (quand l'age est decimal)
        double modul_age;
        //indicateur de non convergence lors du calcul de la boucle principale (while...)
        int indice_non_convergence;
        //indicateur de premier passage dans la boucle principale de calcul
        boolean premiere_boucle;
        //ayanamsa initial pour la calcul des revolutions tropicales precessionnees
        double ayanamsa_;
        
        double div;
        //=====================================================================
        
        //Initialize
        indice_non_convergence = 0;
        premiere_boucle = true;
        
        //Get the period
        //---------------------------
        periode1 = MainClass.astrobj[astre1].getPeriod();
        
        if ( astre2 != Planets.None )
        {
            periode2 = MainClass.astrobj[astre2].getPeriod();
            
            //periode du cycle
            periode1 = 1.0 / Math.abs(1.0 / periode1 - 1.0 / periode2);
        }
        
        //variables diverses
        position_coord1 = pos1.get(astre1).getCoord1(sysCoord);
        
        if ( precession == true )
        {
            ayanamsa_ = ev1.getAyanamsa();
        }
        else
        {
            ayanamsa_ = 0.0;
        }
        
        if ( astre2 != Planets.None )
        {
            position_coord2 = pos1.get(astre2).getCoord1(sysCoord);
            initialDelta = AstronomyMaths.modulo(position_coord1 - position_coord2, 360.0);
        }
        
        //initialisation de la valeur precedente de la longitude des astres
        old_position_coord1 = position_coord1;
        if ( astre2 != Planets.None )
        {
            old_position_coord2 = position_coord2;
        }
        
        //ecart initial en longitude
        double age = 0.0;
        if (chartElements.getChartKind() == ChartKind.revolution)
        {
            age = chartElements.getChartReturnNB();
            sPlace = chartElements.getChartReturnPlaceName();
            ev.setPlace(sPlace);
            ev.setPlaceLat(chartElements.getChartReturnLatitude());
            ev.setPlaceLong(chartElements.getChartReturnLongitude());
        }
        else if (chartElements.getChartKind() == ChartKind.cycle)
        {
            age = chartElements.getChartCycleNB();
            sPlace = chartElements.getChartCyclePlaceName();
            ev.setPlace(sPlace);
            ev.setPlaceLat(chartElements.getChartCycleLatitude());
            ev.setPlaceLong(chartElements.getChartCycleLongitude());
        }
        else if (chartElements.getChartKind() == ChartKind.projective)
        {
            age = 1.0;
        }
        
        Planet p = new Planet(ev, chartElements.getTrueLilith());
        
        ecart_longitude = 360.0 * age;
        modul_age = AstronomyMaths.modulo(ecart_longitude, 360.0);
        if (age <= 1.0) ecart_longitude += 0.01;
        //CALCUL de la longitude de l'astre pour la date de revolution
        //(cette derniere est d'abord approchee par la date de naissance
        //augmentee de "age*periode1 de l'astre", puis progressivement
        //ajustee en fonction des ecarts constates entre la position
        //theorique - egale � la position natale - et la position calculee
        //de l'astre pour la date estimee)
        //=====================================================================
        //tant que l'ecart entre la position de l'astre calculee pour la date
        //approximative de revolution et la position natale est trop grande
        while (Math.abs(ecart_longitude) > 0.00001)
        {
            old_ecart = ecart_longitude;
            if ((periode1 < 0.0) && (premiere_boucle == true))
            {
                //jour_seculaire = jour_seculaire + ecart_longitude * Math.abs(periode1) / 36000.0;
                ev.addTime2CTimeH(Math.abs(periode1) * 24.35 * ecart_longitude);
                premiere_boucle = false;
            }
            else
            {
                ev.addTime2CTimeH(periode1 * 24.35 * ecart_longitude);
            }
            
            indice_non_convergence += 1;
            
            //calcul de la position des astre 1 et 2 pour la date voisine de la revolution cherchee
            //-------------------------------------------------------------------------------------
            pos2.set(p.getObjPosition(astre1), astre1);
            if ( astre2 != Planets.None )
            {
                pos2.set(p.getObjPosition(astre2), astre2);
            }
            
            //position de l'astre 1
            position_coord_astre[astre1] = pos2.get(astre1).getCoord1(sysCoord);
            if ((sysCoord == CoordSystem.Tropical) && (precession == true))
            {
                position_coord_astre[astre1] = position_coord_astre[astre1] - ev.getAyanamsa() + ayanamsa_;
            }
            
            if ( position_coord_astre[astre1] < 0.0 )
            {
                position_coord_astre[astre1] = position_coord_astre[astre1] + 360.0;
            }
            ecart_longitude1 = position_coord1 - position_coord_astre[astre1] + modul_age * AstronomyMaths.sgn(periode1);
            
            //si la longitude de l'astre 1 passe le 0�=-360� dans un sens ou dans l'autre
            if ( Math.abs(old_position_coord1 - position_coord_astre[astre1]) > 180.0 )
            {
                position_coord_astre[astre1] = position_coord_astre[astre1] + ((double)(int)(old_position_coord1 / 180.0) - (double)(int)(position_coord_astre[astre1] / 180.0)) * 360.0;
            }
            
            //position de l'astre 2
            if ( astre2 != Planets.None )
            {
                position_coord_astre[astre2] = pos2.get(astre2).getCoord1(sysCoord);
                if ( position_coord_astre[astre2] < 0.0 )
                {
                    position_coord_astre[astre2] = position_coord_astre[astre2] + 360.0;
                }
                
                //si la longitude de l'astre 2 passe le 0�=-360� dans un sens ou dans l'autre
                if ( Math.abs(old_position_coord2 - position_coord_astre[astre2]) > 180.0 )
                {
                    position_coord_astre[astre2] = position_coord_astre[astre2] + ((double)(int)(old_position_coord2 / 180.0) - (double)(int)(position_coord_astre[astre2] / 180.0)) * 360.0;
                }
                
                //�cart entre la nouvelle position de l'astre 2 calcul�e et l'initiale
                ecart_longitude2 = position_coord2 - position_coord_astre[astre2] + modul_age;
            }
            
            if ( astre2 == Planets.None )
            {
                ecart_longitude = ecart_longitude1;
            }
            else
            {
                ecart_longitude = ecart_longitude2 - ecart_longitude1;
                if (ecart_longitude < 0.0)
                {
                    ecart_longitude += 360.0;
                }
            }
            
            //si l'�cart en longitude est sup�rieur � celui du calcul pr�c�dent
            if ((Math.abs(ecart_longitude) > 0.000001) && (Math.abs(ecart_longitude) > Math.abs(old_ecart)))
            {
                div = (2.0 + Math.pow(1.0 + ((double)(astre2 + astre1)) / 17.0, 3.0)) * ((1.0 - AstronomyMaths.sgn(periode1)) * 0.75 + 1.0);
                ecart_longitude = ecart_longitude / div;
                if ((Math.abs(ecart_longitude * div) < 0.01) && (AstronomyMaths.sgn(ecart_longitude) != AstronomyMaths.sgn(old_ecart)))
                {
                    ecart_longitude += old_ecart / div;
                }
            }
            
            //en cas d'oscillation de l'�cart autour de z�ro
            if ( Math.abs(ecart_longitude + old_ecart) < 0.001 )
            {
                ecart_longitude /= 10.0;
            }
            
            //si les calculs ne convergent pas ou ne convergent pas suffisamment vite
            if ((indice_non_convergence > 1000) && (lookingForDate == false))
            {
                if ( astre2 != Planets.None )
                {
                    JOptionPane.showMessageDialog(MainClass.mainForm, bundle.getString("CycleCalculationCantBeDone"), "StarLogin", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                else
                {
                    JOptionPane.showMessageDialog(MainClass.mainForm, bundle.getString("RevolutionCalculationCantBeDone"), "StarLogin", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
        }
        
        //calculate the new chart
        ArrayList events2 = new ArrayList();
        ChartElements chartElements2 = chartElements.cloneInitElements();
        events2.add(ev);
        chartElements2.setChartEvents(events2);
        chartCalculation(chartElements2);
        
        //Add the new chart elements
        events.add(ev);
        ArrayList positions2 = chartElements2.getChartCoords();
        pos2 = (AllCoord)positions2.get(0);
        positions.add(pos2);
        chartElements.setChartCoords(positions);
    }
    
    //=====================================================================
    //Calculation of parts derivees des astres d'une carte du Ciel
    //input : ref         : astre ou point de reference pour le calcul de la position de la part
    //        plus        : astre dont la position est ajoutee � celle de reference
    //        minus       : astre dont la position est retranchee de celle de reference
    //=====================================================================
    public static Coord partCalculation(byte ref, byte plus, byte minus, ChartElements chartElements)
    {
        double coordonnee1[] = new double[Planets.MC + 1];
        //index
        int i;
        ArrayList positions = chartElements.getChartCoords();
        AllCoord pos1 = (AllCoord)positions.get(0);
        House h = new House();
        ArrayList events = chartElements.getChartEvents();
        ChartEvent ev = (ChartEvent)events.get(0);
        //=====================================================================
        
        //longitude et geocentric latitudes d'une part
        //----------------------------------------------
        //recuperation des coordonnees des astres constituants
        //(les parts sont calculees au depart en geocentric longitude)
        for (i = 0; i <= Planets.MC; i++)
        {
            coordonnee1[i] = pos1.get(i).getTropicGeoLong();
        }
        
        //calcul de la part
        coordonnee1[Planets.OtherPoint] = coordonnee1[ref] + coordonnee1[plus] - coordonnee1[minus];
        coordonnee1[Planets.OtherPoint] = AstronomyMaths.modulo(coordonnee1[Planets.OtherPoint], 360.0);
        
        //autres coordonnees
        pos1.get(Planets.OtherPoint).setTropicGeoLong(coordonnee1[Planets.OtherPoint]);
        pos1.get(Planets.OtherPoint).setTropicHelioLong(coordonnee1[Planets.OtherPoint]);
        pos1.get(Planets.OtherPoint).setGeoLat(0);
        pos1.get(Planets.OtherPoint).setRA(pos1.get(Planets.OtherPoint).raFromEcliptic(ev.getObliquity()));
        pos1.get(Planets.OtherPoint).setDecl(pos1.get(Planets.OtherPoint).declFromEcliptic(ev.getObliquity()));
        pos1.get(Planets.OtherPoint).setAz(pos1.get(Planets.OtherPoint).azFromEquatorial(ev.getPlaceLat(), ev.getLST()));
        pos1.get(Planets.OtherPoint).setAlt(pos1.get(Planets.OtherPoint).altFromEquatorial(ev.getPlaceLat(), ev.getLST()));
        pos1.get(Planets.OtherPoint).setSiderGeoLong(pos1.get(Planets.OtherPoint).getTropicGeoLong() - ev.getAyanamsa());
        pos1.get(Planets.OtherPoint).setSiderHelioLong(pos1.get(Planets.OtherPoint).getTropicHelioLong() - ev.getAyanamsa());
        
        //return the coordinates of the part
        return pos1.get(Planets.OtherPoint);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    private void seedProcessing()
    {
        //keep the initial houses positions
        chartCalculation(chartElements);
        AllCoord posHouse = (AllCoord)chartElements.getChartCoords().get(0);
        
        //get the data
        ArrayList events = chartElements.getChartEvents();
        ChartEvent ev1 = (ChartEvent)events.get(0);
        ChartEvent ev2 = ev1.cloneEvent();
        ev2.addTime2CTimeH(-280.5 * 24.0);
        ArrayList events2 = new ArrayList();
        events2.add(ev2);
        ChartElements chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        
        //calculate the planets positions
        chartCalculation(chartElements2);
        ArrayList positions = new ArrayList();
        positions.add((AllCoord)chartElements2.getChartCoords().get(0));
        chartElements.setChartCoords(positions);
        
        //get the initial houses positions instead of the new ones
        for (int i=Planets.AS; i<=Planets.House12; i++)
        {
            AllCoord newPos = (AllCoord)chartElements.getChartCoords().get(0);
            newPos.set(posHouse.get(i), i);
        }
    }
    
    private void soulCycleProcessing()
    {
        chartElements.setHouseSys(HouseSystem.MaternusAs);
        chartElements.setCoordSys(CoordSystem.Tropical);
        chartCalculation(chartElements);
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    private void projectiveProcessing()
    {
        double ecart;
        ArrayList events = chartElements.getChartEvents();
        ArrayList positions = chartElements.getChartCoords();
        AllCoord pos1 = (AllCoord)positions.get(0);
        AllCoord pos3 = new AllCoord();
        ChartEvent ev1 = (ChartEvent)events.get(0);
        ChartEvent ev2;
        ChartElements chartElements2;
        int sysCoord = chartElements.getCoordSys();
        
        //Calculation of the chart one day after the initial one, for the moon position
        ev2 = ev1.cloneEvent();
        ev2.addTime2CTimeH(24.0);
        ArrayList events2 = new ArrayList();
        events2.add(ev2);
        chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        chartCalculation(chartElements2);
        ArrayList positions2 = chartElements2.getChartCoords();
        AllCoord pos2 = (AllCoord)positions2.get(0);
        pos3.set(pos2.get(Planets.Moon), Planets.Moon); //save the Moon position
        
        //calculation of the sun-moon cycle from birth, for the Venus position
        ecart = AstronomyMaths.modulo(pos1.get(Planets.Sun).getCoord1(sysCoord) - pos1.get(Planets.Moon).getCoord1(sysCoord), 360.0);
        if ( ecart > 180 ) ecart = ecart - 360;
        if ( ecart > 0 )
        {
            planetaryRevolution(Planets.Sun, Planets.Moon, false, chartElements);
        }
        else
        {
            planetaryRevolution(Planets.Moon, Planets.Sun, false, chartElements);
        }
        positions2 = chartElements.getChartCoords();
        if (positions2.size() < 2) return;
        pos2 = (AllCoord)positions2.get(1);
        pos3.set(pos2.get(Planets.Venus), Planets.Venus); //save Venus position
        
        //calculation of the sun-moon half cycle for the Mercury and the Sun positions (not possible with current revolution method)
        events2 = chartElements.getChartEvents();
        if (events2.size() < 2) return;
        ChartEvent ev3 = (ChartEvent)events2.get(1);
        ev2 = ev1.cloneEvent();
        double deltaT = (ev3.getCTimeH() - ev1.getCTimeH()) / 2.0 * AstronomyMaths.HOUR_PER_CENTURY;
        ev2.addTime2CTimeH(deltaT);
        events2 = new ArrayList();
        events2.add(ev2);
        chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        chartCalculation(chartElements2);
        positions2 = chartElements2.getChartCoords();
        pos2 = (AllCoord)positions2.get(0);
        pos3.set(pos2.get(Planets.Mercury), Planets.Mercury); //save Mercury position
        pos3.set(pos2.get(Planets.Sun), Planets.Sun); //save the Sun position
        
        //calculation of the solar return after the sun-moon half cycle, for Mars position
        planetaryRevolution(Planets.Sun, Planets.None, false, chartElements2);
        positions2 = chartElements2.getChartCoords();
        if (positions2.size() < 2) return;
        pos2 = (AllCoord)positions2.get(1);
        pos3.set(pos2.get(Planets.Mars), Planets.Mars); //save Mars position
        
        //calculation of the marsian return after this last date, for Jupiter
        events2 = new ArrayList();
        events2.add((ChartEvent)chartElements2.getChartEvents().get(1));
        positions2 = new ArrayList();
        positions2.add(chartElements2.getChartCoords().get(1));
        chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        chartElements2.setChartCoords(positions2);
        planetaryRevolution(Planets.Mars, Planets.None, false, chartElements2);
        positions2 = chartElements2.getChartCoords();
        if (positions2.size() < 2) return;
        pos2 = (AllCoord)positions2.get(1);
        pos3.set(pos2.get(Planets.Jupiter), Planets.Jupiter); //save Jupiter position
        
        //calculation of the jovian return after this last date, for Saturn
        events2 = new ArrayList();
        events2.add((ChartEvent)chartElements2.getChartEvents().get(1));
        positions2 = new ArrayList();
        positions2.add(chartElements2.getChartCoords().get(1));
        chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        chartElements2.setChartCoords(positions2);
        planetaryRevolution(Planets.Jupiter, Planets.None, false, chartElements2);
        positions2 = chartElements2.getChartCoords();
        if (positions2.size() < 2) return;
        pos2 = (AllCoord)positions2.get(1);
        pos3.set(pos2.get(Planets.Saturn), Planets.Saturn); //save Saturn position
        
        //calculation of the saturnian return after this last date, for Uranus and Neptun
        events2 = new ArrayList();
        events2.add((ChartEvent)chartElements2.getChartEvents().get(1));
        positions2 = new ArrayList();
        positions2.add(chartElements2.getChartCoords().get(1));
        chartElements2 = chartElements.cloneInitElements();
        chartElements2.setChartEvents(events2);
        chartElements2.setChartCoords(positions2);
        planetaryRevolution(Planets.Saturn, Planets.None, false, chartElements2);
        positions2 = chartElements2.getChartCoords();
        if (positions2.size() < 2) return;
        pos2 = (AllCoord)positions2.get(1);
        pos3.set(pos2.get(Planets.Uranus), Planets.Uranus); //save Uranus position
        pos3.set(pos2.get(Planets.Neptune), Planets.Neptune); //save Neptune position
        
        //put other planets and points from pluto (except houses) to 0:
        for (int i = Planets.Pluto; i <= Planets.Chiron; i++)
        {
            pos1.get(i).setSiderGeoLong(0);
            pos1.get(i).setDecl(0);
            pos1.get(i).setRA(0);
            pos1.get(i).setAz(0);
            pos1.get(i).setAlt(0);
            pos1.get(i).setTropicGeoLong(0);
            pos1.get(i).setGeoLat(0);
            pos1.get(i).setHelioLat(0);
            pos1.get(i).setTropicHelioLong(0);
            pos1.get(i).setSiderHelioLong(0);
            pos1.get(i).setGeoDist(0);
            pos1.get(i).setHelioDist(0);
            pos1.get(i).setRetro(0);
            pos3.get(i).setSiderGeoLong(0);
            pos3.get(i).setDecl(0);
            pos3.get(i).setRA(0);
            pos3.get(i).setAz(0);
            pos3.get(i).setAlt(0);
            pos3.get(i).setTropicGeoLong(0);
            pos3.get(i).setGeoLat(0);
            pos3.get(i).setHelioLat(0);
            pos3.get(i).setTropicHelioLong(0);
            pos3.get(i).setSiderHelioLong(0);
            pos3.get(i).setGeoDist(0);
            pos3.get(i).setHelioDist(0);
            pos3.get(i).setRetro(0);
        }
        
        //copy the houses
        for (int i = Planets.AS; i <= Planets.House12; i++)
        {
            pos3.set(pos1.get(i), i);
        }
        
        //set the projective chart as the inside or first one, and the birthday one as the second
        events2 = new ArrayList();
        events2.add(ev1);
        events2.add((ChartEvent)chartElements2.getChartEvents().get(1));
        positions2 = new ArrayList();
        positions2.add(pos3);
        positions2.add(pos1);
        chartElements.setChartEvents(events2);
        chartElements.setChartCoords(positions2);
    }
    
    private String makeCompSynHeader()
    {
        String strS = ChartKind.getChartKindName(chartElements.getChartKind());
        String strS2 = CoordSystem.getCoordSystemName(chartElements.getCoordSys()) + " - " + HouseSystem.getHouseSystemName(chartElements.getHouseSys()) + "\r\n";
        
        ArrayList chartEvents = chartElements.getChartEvents();
        for (int i = 0; i < chartEvents.size(); i++)
        {
            ChartEvent event = (ChartEvent)(chartEvents.get(i));
            String header = event.getHeader();
            if (header.equals(""))
            {
                header = strS2 + event.getShortHeader();
            }
            strS = strS + "\r\n" + header;
        }
        return strS;
    }
    
    private String makeRevolCycleHeader(boolean bCycle)
    {
        String strS = "";
        
        if (bCycle == false)
        {
            if ( chartElements.getChartReturnPrecess() )
            {
                strS = bundle.getString("Precessionned") + "\r\n";
            }
            strS = strS + "Age " + MainForm.planetName[chartElements.getChartReturnPlanet()] + " = " + chartElements.getChartReturnNB() + "\r\n";
            strS = strS + bundle.getString("Place") + " :  " + chartElements.getChartReturnPlaceName();
        }
        else
        {
            strS = strS + "Age " + MainForm.planetName[chartElements.getChartCyclePlanet1()] + " - " + MainForm.planetName[chartElements.getChartCyclePlanet2()] + " = " + chartElements.getChartCycleNB() + "\r\n";
            strS = strS + bundle.getString("Place") + " :  " + chartElements.getChartCyclePlaceName();
        }
        return strS;
    }
}