package StarLogin.Systeme.AstroCalc;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public final class FTime
{
    private String time = MainClass.STIME_000000;
    private int hour = 0;
    private int minute = 0;
    private int second = 0;
    private double decimalHour = 0.0;
    private String timeUS = "";
    
    /** Creates new FTime */
    public FTime()
    {
    }
    
    public FTime(String sData)
    {
        if (sData.equals("") || sData == null)
            sData = MainClass.STIME_000000;
        if (sData.endsWith("AM")||sData.endsWith("PM"))
        {
            timeUS = sData;
            time = format24(sData);
        }
        else
        {
            time = sData;
            timeUS = formatAMPM(time);
        }
        decimalHour = time2DecimalHour(time);
    }
    
    public FTime(int h, int m, int s)
    {
        hour = h;
        minute = m;
        second = s;
        time = formatTime(h, m, s);
        timeUS = formatAMPM(time);
        decimalHour = time2DecimalHour(time);
    }
    
    public static String curTime()
    {
        String time = MainClass.starLoginManager.getStringFieldValue("fenetre", "CURRENT_TIME", " WHERE ID=1");
        return time;
    }
    
    public FTime(double t)
    {
        decimalHour = t;
        hour = (int)t;
        double aux = (t - (double)hour)*60.0;
        minute = (int)aux;
        aux = (aux - (double)minute)*60.0;
        second = (int)aux;
        time = formatTime(hour, minute, second);
        timeUS = formatAMPM(time);
    }
    
    public int time2Hour(String tm)
    {
        decimalHour = time2DecimalHour(tm);
        return hour;
    }
    
    public int time2Minute(String tm)
    {
        decimalHour = time2DecimalHour(tm);
        return minute;
    }
    
    public int time2Second(String tm)
    {
        decimalHour = time2DecimalHour(tm);
        return second;
    }
    
    public double time2DecimalHour(String tm)
    {
        int pos1;
        int pos2;
        int difh = 0;
        time = tm;
        String s;
        hour = 0;
        minute = 0;
        second = 0;
        if (tm.endsWith("PM") || tm.endsWith("AM"))
        {
            if (tm.endsWith("PM"))
                difh = 12;
            if(tm.length()>=8)
                tm = tm.substring(0, 8);
            else
                tm = tm.substring(0, 5);
        }
        
        try
        {
            pos1 = tm.indexOf(':');
            if (pos1>0)
            {
                if (pos1<=2)
                {
                    s = tm.substring(0,pos1);
                }
                else
                {
                    s = tm.substring(0,2);
                }
                hour = new Integer(s).intValue() + difh;
                
                pos1 += 1;
                pos2 = tm.indexOf(':', pos1 + 1);
                //s = "0";
                if (pos2>pos1 || pos2<0)
                {
                    if (pos2<=pos1+2 && pos2>0)
                    {
                        s = tm.substring(pos1, pos2);
                    }
                    else
                    {
                        if (tm.length() > pos1 + 1)
                        {
                            s = tm.substring(pos1, pos1+2);
                        }
                        else
                        {
                            s = tm.substring(pos1);
                        }
                    }
                    if (s.equals("")||s.startsWith(":"))
                    {
                        s = "0";
                    }
                    minute = new Integer(s).intValue();
                    if (pos2>0)
                    {
                        s = tm.substring(pos2+1);
                        if (s.equals("")||s.startsWith(":"))
                        {
                            s = "0";
                        }
                    }
                    else
                    {
                        s = "0";
                    }
                    second = new Integer(s).intValue();
                }
            }
            else
            {
                if (tm.length()<=2)
                {
                    s = tm;
                }
                else
                {
                    s = tm.substring(0,2);
                }
                hour = new Integer(s).intValue();
            }
            if (second >= 60)
            {
                second -= 60;
                minute += 1;
            }
            if (minute >= 60)
            {
                minute -= 60;
                hour += 1;
            }
            if (hour >= 24)
            {
                hour = 24;
                minute = 0;
                second = 0;
            }
            else if (hour < 0)
            {
                hour = 0;
            }
            time = formatTime(hour, minute, second);
            timeUS = formatAMPM(time);
            decimalHour = (double)hour + (double)minute/60.0 + (double)second/3600.0;
            decimalHour = AstronomyMaths.getRnd(decimalHour, 12);
            return decimalHour;
        }
        catch(java.lang.NumberFormatException ex)
        {
            return 0.0;
        }
    }
    
    public static String formatAMPM(String stime)
    {
        int h = 0;
        if (stime.equals(""))
            stime = MainClass.STIME_000000;
        if (stime.length()>=2)
            h = new Integer(stime.substring(0, 2)).intValue();
        if (MainClass.timeType == MainClass.TIME12)
        {
            if (h < 12)
            {
                if (h==0)
                    return "12".concat(stime.substring(2)).concat("AM");
                else
                    return stime.concat("AM");
            }
            else
            {
                h -= 12;
                String sh = String.valueOf(h);
                if (h<10)
                    sh = "0".concat(sh);
                if (sh.equals("00"))
                    sh = "12";
                return sh.concat(stime.substring(2)).concat("PM");
            }
        }
        else
            return stime;
    }
    
    public static String formatAMPMAbrev(String stime)
    {
        int h = 0;
        if (stime.equals(""))
            stime = "00:00";
        if (stime.length() > 5)
            stime = stime.substring(0, 5);
        if (stime.length()>=2)
            h = new Integer(stime.substring(0, 2)).intValue();
        if (MainClass.timeType == MainClass.TIME12)
        {
            if (h < 12)
            {
                if (h==0)
                    return "12".concat(stime.substring(2)).concat("AM");
                else
                    return stime.concat("AM");
            }
            else
            {
                h -= 12;
                String sh = String.valueOf(h);
                if (h<10)
                    sh = "0".concat(sh);
                if (sh.equals("00"))
                    sh = "12";
                return sh.concat(stime.substring(2)).concat("PM");
            }
        }
        else
            return stime;
    }
    
    private String format24(String stime)
    {
        int h = 0;
        if (stime.length()>=2)
            h = new Integer(stime.substring(0, 2)).intValue();
        if (stime.endsWith("AM")||stime.endsWith("PM"))
        {
            String ampm = stime.substring(8);
            if (h < 12)
            {
                if (ampm.equals("PM"))
                    h += 12;
            }
            else
            {
                if (ampm.equals("AM"))
                    h -= 12;
            }
            String sh = String.valueOf(h);
            if (h < 10)
                sh = "0".concat(sh);
            return sh.concat(stime.substring(2, 8));
        }
        else
            return stime;
    }
    
    public static String set24(String stime)
    {
        int h = 0;
        if (stime.length()>=2)
            h = new Integer(stime.substring(0, 2)).intValue();
        if (MainClass.timeType == MainClass.TIME12)
        {
            String ampm = stime.substring(8);
            if (h < 12)
            {
                if (ampm.equals("PM"))
                    h += 12;
            }
            else
            {
                if (ampm.equals("AM"))
                    h -= 12;
            }
            String sh = String.valueOf(h);
            if (h < 10)
                sh = "0".concat(sh);
            return sh.concat(stime.substring(2, 8));
        }
        else
            return stime;
    }
    public static String set24Abrev(String stime)
    {
        int h = 0;
        if (stime.length()>=2)
            h = new Integer(stime.substring(0, 2)).intValue();
        if (MainClass.timeType == MainClass.TIME12)
        {
            String ampm = stime.substring(5);
            if (h < 12)
            {
                if (ampm.equals("PM"))
                    h += 12;
            }
            else
            {
                if (ampm.equals("AM"))
                    h -= 12;
            }
            String sh = String.valueOf(h);
            if (h < 10)
                sh = "0".concat(sh);
            return sh.concat(stime.substring(2, 5));
        }
        else
            return stime;
    }
    
    public String formatTime(int h, int m, int s)
    {
        if (s >= 60)
        {
            s -= 60;
            m += 1;
        }
        if (m >= 60)
        {
            m -= 60;
            h += 1;
        }
        if (h >= 24)
        {
            h = 24;
            m = 0;
            s = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        String sM = String.valueOf(m);
        if (m<10) sM = "0" + sM;
        String sS = String.valueOf(s);
        if (s<10) sS = "0" + sS;
        hour = h;
        minute = m;
        second = s;
        time = sH+":"+sM+":"+sS;
        return time;
    }
    
    public String formatTimeAbrev(int h, int m, int s)
    {
        if (s >= 60)
        {
            s -= 60;
            m += 1;
        }
        if (m >= 60)
        {
            m -= 60;
            h += 1;
        }
        if (h >= 24)
        {
            h = 24;
            m = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        String sM = String.valueOf(m);
        if (m<10) sM = "0" + sM;
        hour = h;
        minute = m;
        second = 0;
        time = sH+":"+sM;
        return time;
    }
    
    public static String formatTime(String sTime)
    {
        String sAMPM = "";
        boolean bAMPM = false;
        if (sTime.endsWith("AM")||sTime.endsWith("PM"))
        {
            sAMPM = sTime.substring(sTime.length()-2);
            sTime = sTime.substring(0, sTime.length()-2);
            bAMPM = true;
        }
        String sH = sTime;
        String sM = "00";
        String sS = "00";
        int pos = sTime.indexOf(":");
        if (pos>0)
        {
            sH = sTime.substring(0, pos);
            if (sH.length() == 1)
                sH = "0".concat(sH);
            sTime = sTime.substring(pos+1);
            pos = sTime.indexOf(":");
            if (pos>0)
            {
                sM = sTime.substring(0, pos);
                if (sM.length() == 1)
                    sM = "0".concat(sM);
                sS = sTime.substring(pos+1);
                if (sS.length() == 1)
                    sS = "0".concat(sS);
            }
        }
        else
        {
            if (sH.length() == 1)
                sH = "0".concat(sH);
        }
        if (bAMPM)
            return sH+":"+sM+":"+sS.concat(sAMPM);
        else
            return formatAMPM(sH+":"+sM+":"+sS);
    }
    
    public static String formatTimeAbrev(String sTime)
    {
        String sAMPM = "";
        boolean bAMPM = false;
        if (sTime.endsWith("AM")||sTime.endsWith("PM"))
        {
            sAMPM = sTime.substring(sTime.length()-2);
            sTime = sTime.substring(0, sTime.length()-2);
            bAMPM = true;
        }
        String sH = sTime;
        String sM = "00";
        int pos = sTime.indexOf(":");
        if (pos>0)
        {
            sH = sTime.substring(0, pos);
            if (sH.length() == 1)
                sH = "0".concat(sH);
            sM = sTime.substring(pos+1);
        }
        else
        {
            if (sH.length() == 1)
                sH = "0".concat(sH);
        }
        if (bAMPM)
            return sH+":"+sM+sAMPM;
        else
            return formatAMPM(sH+":"+sM);
    }
    
    public String formatTime(int h, int m)
    {
        if (m >= 60)
        {
            m -= 60;
            h += 1;
        }
        if (h >= 24)
        {
            h = 24;
            m = 0;
            second = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        String sM = String.valueOf(m);
        if (m<10) sM = "0" + sM;
        hour = h;
        minute = m;
        time = sH+":"+sM+":00";
        return time;
    }
    
    public String formatTimeAbrev(int h, int m)
    {
        if (m >= 60)
        {
            m -= 60;
            h += 1;
        }
        if (h >= 24)
        {
            h = 24;
            m = 0;
            second = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        String sM = String.valueOf(m);
        if (m<10) sM = "0" + sM;
        hour = h;
        minute = m;
        time = sH+":"+sM;
        return time;
    }
    
    public String formatTime(int h)
    {
        if (h >= 24)
        {
            h = 24;
            minute = 0;
            second = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        hour = h;
        time = sH+":00:00";
        return time;
    }
    
    public String formatTimeAbrev(int h)
    {
        if (h >= 24)
        {
            h = 24;
            minute = 0;
            second = 0;
        }
        else if (h < 0)
        {
            h = 0;
        }
        String sH = String.valueOf(h);
        if (h<10) sH = "0" + sH;
        hour = h;
        time = sH+":00";
        return time;
    }
    
    public int getHour()
    {
        return hour;
    }
    
    public double getDecimalHour()
    {
        return decimalHour;
    }
    
    public int getMinute()
    {
        return minute;
    }
    
    public int getSecond()
    {
        return second;
    }
    
    public String getTime()
    {
        if (MainClass.timeType == MainClass.TIME24)
            return time;
        else
            return timeUS;
    }
    
    public void setHour(int data)
    {
        hour = data;
    }
    
    public void setMinute(int data)
    {
        minute = data;
    }
    
    public void setSecond(int data)
    {
        second = data;
    }
    
    public void setTime(String data)
    {
        time = data;
    }
    
    public void setDecimalHour(double data)
    {
        decimalHour = data;
    }
}
