/*
 * Astrobj.java
 *
 * Created on 5 ao�t 2003, 09:45
 */

package StarLogin.Systeme.AstroCalc;

/**
 *
 * @author  Standard
 * @version
 */
public class Astrobj
{
    private double mean_long0;
    private double mean_anomal0;
    private double arg_lat0;
    private double mean_long1;
    private double mean_anomal1;
    private double arg_lat1;
    private double period;
    
    /** Creates new Astrobj */
    public Astrobj(double mean_long0, double mean_anomal0, double arg_lat0, double mean_long1, double mean_anomal1, double arg_lat1, double period)
    {
        this.mean_long0 = mean_long0;
        this.mean_anomal0 = mean_anomal0;
        this.arg_lat0 = arg_lat0;
        this.mean_long1 = mean_long1;
        this.mean_anomal1 = mean_anomal1;
        this.arg_lat1 = arg_lat1;
        this.period = period;
    }
    
    public double getMeanLong0()
    {
        return mean_long0;
    }
    
    public double getMeanAnomal0()
    {
        return mean_anomal0;
    }
    
    public double getArgLat0()
    {
        return arg_lat0;
    }
    
    public double getMeanLong1()
    {
        return mean_long1;
    }
    
    public double getMeanAnomal1()
    {
        return mean_anomal1;
    }
    
    public double getArgLat1()
    {
        return arg_lat1;
    }
    
    public double getPeriod()
    {
        return period;
    }
}
