package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class HouseInSign implements java.io.Serializable
{
    private String meaning;
    private double value;
    private byte signID;
    private byte houseID;
    
    /** Creates new HouseInSign */
    public HouseInSign()
    {
        houseID = -1;
        signID = -1;
        meaning = "";
        value = 0.0;
    }
    
    public byte getHouseID()
    {
        return houseID;
    }
    
    public void setHouseID(byte data)
    {
        houseID = data;
    }
    
    public byte getSignID()
    {
        return signID;
    }
    
    public void setSignID(byte data)
    {
        signID = data;
    }
    
    public double getValue()
    {
        return value;
    }
    
    public void setValue(double data)
    {
        value = data;
    }
    
    public String getMeaning()
    {
        return meaning;
    }
    
    public void setMeaning(String sData)
    {
        meaning = sData;
    }
}
