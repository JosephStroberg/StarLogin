package StarLogin.Systeme.Data;

import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois DESCHAMPS
 */

public class Record implements java.io.Serializable
{
    private boolean adding = false;
    private String id;
    private int nbOfRows;
    private int rowNb;
    private ArrayList values = new ArrayList();
    private ImageIcon picture;

    public ArrayList getValues()
    {
        return values;
    }

    /** Creates new Table */
    public Record()
    {
        id = "-1";
    }

    public boolean getAdding()
    {
        return adding;
    }

    public void setAdding(boolean b)
    {
        adding = b;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String sData)
    {
        id = sData;
    }

    public int getRow()
    {
        return rowNb;
    }

    public int getRowNB()
    {
        return nbOfRows;
    }

    public void setRow(int row)
    {
        rowNb = row;
    }

    public void setRowNB(int rowNB)
    {
        nbOfRows = rowNB;
    }

    public String getData(int i)
    {
        return null2String(values.get(i));
    }

    public ImageIcon getPicture()
    {
        return picture;
    }

    public void setPicture(ImageIcon data)
    {
        picture = data;
    }

    @SuppressWarnings("unchecked")
    public void setData(int i, String data)
    {
        values.set(i, data);
    }
    
    private String null2String(Object object)
    {
        if (object == null)
        {
            return "";
        }
        else
        {
            return object.toString();
        }
    }
}
