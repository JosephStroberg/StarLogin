package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import javax.swing.ImageIcon;

public class Place extends Record
{
    private String placeName;
    private String placeLatitude;
    private String placeLongitude;
    private String comments;
    private ImageIcon picture;
    
    /** Creates new Place */
    public Place()
    {
        placeName = "";
        placeLatitude = "";
        placeLongitude = "";
        comments = "";
        picture = null;
    }
    
    public String getPlaceLongitude()
    {
        return placeLongitude;
    }
    
    public void setPlaceLongitude(String sData)
    {
        placeLongitude = sData;
    }
    
    public String getPlaceLatitude()
    {
        return placeLatitude;
    }
    
    public void setPlaceLatitude(String sData)
    {
        placeLatitude = sData;
    }
    
    public String getPlaceName()
    {
        return placeName;
    }
    
    public void setPlaceName(String sData)
    {
        placeName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
