/*
 * Events.java
 *
 * Created on 28 avril 2003, 09:06
 */

package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Events extends Records {

    /** Creates new Events */
    public Events() {}
}