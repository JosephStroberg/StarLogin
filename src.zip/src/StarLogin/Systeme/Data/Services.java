package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Services extends Records {

    /** Creates new Services */
    public Services() {}
}