package StarLogin.Systeme.Data;

import javax.swing.ImageIcon;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Service extends Record
{
    private String serviceName;
    private String serviceType;
    private String averageDuration;
    private String comments;
    private ImageIcon picture;
    private String astrologicalTechniques;
    private String otherTechniques;
    private String rate;
    private String repetitiveness;
    
    /** Creates new Service */
    public Service()
    {
        serviceName = "";
        serviceType = "";
        averageDuration = "";
        astrologicalTechniques = "";
        otherTechniques = "";
        rate = "";
        repetitiveness = "";
        comments = "";
        picture = null;
    }
    
    public String getAverageDuration()
    {
        return averageDuration;
    }
    
    public void setAverageDuration(String sData)
    {
        averageDuration = sData;
    }
    
    public String getAstrologicalTechniques()
    {
        return astrologicalTechniques;
    }
    
    public void setAstrologicalTechniques(String sData)
    {
        astrologicalTechniques = sData;
    }
    
    public String getOtherTechniques()
    {
        return otherTechniques;
    }
    
    public void setOtherTechniques(String sData)
    {
        otherTechniques = sData;
    }
    
    public String getRate()
    {
        return rate;
    }
    
    public void setRate(String sData)
    {
        rate = sData;
    }
    
    public String getRepetitiveness()
    {
        return repetitiveness;
    }
    
    public void setRepetitiveness(String sData)
    {
        repetitiveness = sData;
    }
    
    public String getServiceType()
    {
        return serviceType;
    }
    
    public void setServiceType(String sData)
    {
        serviceType = sData;
    }
    
    public String getServiceName()
    {
        return serviceName;
    }
    
    public void setServiceName(String sData)
    {
        serviceName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
