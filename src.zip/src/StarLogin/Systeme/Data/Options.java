/*
 * Options.java
 *
 * Created on 30 juin 2003, 08:32
 */

package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Options extends Records {

    /** Creates new Options */
    public Options() {}
}