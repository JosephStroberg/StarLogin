/*
 * Option.java
 *
 * Created on 30 juin 2003, 08:32
 */

package StarLogin.Systeme.Data;

import StarLogin.Systeme.Enum.Planets;
import java.awt.Color;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Option extends Record
{
    private String chartReturnPlaceID;
    private String chartCyclePlaceID;
    private String defaultEvent;
    private String defaultPlace;
    private byte coordSys;
    private byte houseSys;
    private byte otherPointType;
    private String chartReturnPlanet;
    private String chartCyclePlanet1;
    private String chartCyclePlanet2;
    private String chartCompositeNB;
    private String chartHarmonicNB;
    private String chartDir1SpaceKind;
    private String chartDir2SpaceKind;
    private String chartDirSSpaceKind;
    private String otherPointName;
    private String configurationName;
    private int zodiacSize;
    private int signSize;
    private int planetSize;
    private int characterSize;
    private String typeAspect0;
    private String typeAspect1;
    private String typeAspect2;
    private String typeAspect3;
    private String typeAspect4;
    private String typeAspect5;
    private String typeAspect6;
    private String typeAspect7;
    private String typeAspect8;
    private String typeAspect9;
    private String typeAspect10;
    private String typeAspect11;
    private String typeAspect12;
    private String typeAspect13;
    private String typeAspect14;
    private String typeAspect15;
    private String typeAspect16;
    private String typeAspect17;
    private String otherAspectName;
    private String chartKinds;
    private Color sunColor;
    private Color moonColor;
    private Color mercuryColor;
    private Color venusColor;
    private Color marsColor;
    private Color jupiterColor;
    private Color saturnColor;
    private Color uranusColor;
    private Color neptuneColor;
    private Color plutoColor;
    private Color gaiaColor;
    private Color nodesColor;
    private Color cuspsColor;
    private Color asteroidsColor;
    private Color vulcanColor;
    private Color variousColor;
    private Color fireColor;
    private Color earthColor;
    private Color airColor;
    private Color waterColor;
    private Color neutralColor;
    private Color dynamicColor;
    private Color harmonicColor;
    private Color colorAspect0;
    private Color colorAspect1;
    private Color colorAspect2;
    private Color colorAspect3;
    private Color colorAspect4;
    private Color colorAspect5;
    private Color colorAspect6;
    private Color colorAspect7;
    private Color colorAspect8;
    private Color colorAspect9;
    private Color colorAspect10;
    private Color colorAspect11;
    private Color colorAspect12;
    private Color colorAspect13;
    private Color colorAspect14;
    private Color colorAspect15;
    private Color colorAspect16;
    private Color colorAspect17;
    private Color colorBackground;
    private Color colorForeground;
    private Color colorLabelsBackground;
    private Color colorLabelsForeground;
    private Color colorTextZonesBackground;
    private Color colorTextZonesForeground;
    private Color colorButtonsBackground;
    private Color colorButtonsForeground;
    private boolean defaultConfiguration;
    private boolean shownSun;
    private boolean shownMoon;
    private boolean shownMercury;
    private boolean shownVenus;
    private boolean shownMars;
    private boolean shownJupiter;
    private boolean shownSaturn;
    private boolean shownUranus;
    private boolean shownNeptune;
    private boolean shownPluto;
    private boolean shownGaia;
    private boolean shownNorthNode;
    private boolean shownLilith;
    private boolean shownEast;
    private boolean shownZenith;
    private boolean shownVertex;
    private boolean shownVulcan;
    private boolean shownOtherPoint;
    private boolean shownCeres;
    private boolean shownPallas;
    private boolean shownJuno;
    private boolean shownVesta;
    private boolean shownChiron;
    private boolean trueLilith;
    private boolean coloredAspects;
    private boolean housesCoords;
    private boolean signsNames;
    private boolean leftAsct;
    private boolean symbolAspects;
    private boolean viewStars;
    private boolean viewAsteroids;
    private boolean viewCoordinates;
    private boolean viewStraightLines;
    private boolean viewHouses;
    private boolean viewConstellations;
    private boolean viewShadedLines;
    private boolean viewAspects;
    private boolean viewBarycenter;
    private boolean singleWeight;
    private boolean horizon;
    private boolean aspectsSun;
    private boolean aspectsMoon;
    private boolean aspectsMercury;
    private boolean aspectsVenus;
    private boolean aspectsMars;
    private boolean aspectsJupiter;
    private boolean aspectsSaturn;
    private boolean aspectsUranus;
    private boolean aspectsNeptune;
    private boolean aspectsPluto;
    private boolean aspectsGaia;
    private boolean aspectsNorthNode;
    private boolean aspectsLilith;
    private boolean aspectsEast;
    private boolean aspectsZenith;
    private boolean aspectsVertex;
    private boolean aspectsVulcan;
    private boolean aspectsOtherPoint;
    private boolean aspectsCeres;
    private boolean aspectsPallas;
    private boolean aspectsJuno;
    private boolean aspectsVesta;
    private boolean aspectsChiron;
    private boolean aspectsAS;
    private boolean aspectsMC;
    private boolean shownAspect0;
    private boolean shownAspect1;
    private boolean shownAspect2;
    private boolean shownAspect3;
    private boolean shownAspect4;
    private boolean shownAspect5;
    private boolean shownAspect6;
    private boolean shownAspect7;
    private boolean shownAspect8;
    private boolean shownAspect9;
    private boolean shownAspect10;
    private boolean shownAspect11;
    private boolean shownAspect12;
    private boolean shownAspect13;
    private boolean shownAspect14;
    private boolean shownAspect15;
    private boolean shownAspect16;
    private boolean shownAspect17;
    private boolean chartSelectSingle;
    private boolean chartReturnPrecess;
    private boolean chartCompositeFromAS;
    private String limitMag;
    private String orbLightLight;
    private String orbLightTell;
    private String orbLightOtherInd;
    private String orbLightColl;
    private String orbLightVirtMax;
    private String orbLightVirtMin;
    private String orbTellTell;
    private String orbTellOtherInd;
    private String orbTellColl;
    private String orbTellVirtMax;
    private String orbTellVirtMin;
    private String orbOtherIndOtherInd;
    private String orbOtherIndColl;
    private String orbOtherIndVirtMax;
    private String orbOtherIndVirtMin;
    private String orbCollColl;
    private String orbCollVirtMax;
    private String orbCollVirtMin;
    private String orbVirtMaxVirtMax;
    private String orbVirtMaxVirtMin;
    private String orbVirtMinVirtMin;
    private String divMin;
    private String divConjuntion;
    private String divSextil;
    private String divSquare;
    private String divTrine;
    private String divOpposition;
    private String otherAspectValue;
    private String chartDir1Corresp;
    private String chartDir2Corresp;
    private String chartDirSCorresp;
    private String chartDir1Degree;
    private String chartDir2Day;
    private String chartDirSDegree;
    
    /** Creates new Option */
    public Option()
    {
        configurationName = "";
        sunColor = Color.black;
        moonColor = Color.black;
        mercuryColor = Color.black;
        venusColor = Color.black;
        marsColor = Color.black;
        jupiterColor = Color.black;
        saturnColor = Color.black;
        uranusColor = Color.black;
        neptuneColor = Color.black;
        plutoColor = Color.black;
        gaiaColor = Color.black;
        nodesColor = Color.black;
        cuspsColor = Color.black;
        asteroidsColor = Color.black;
        vulcanColor = Color.black;
        variousColor = Color.black;
        fireColor = Color.red;
        earthColor = Color.green;
        airColor = Color.yellow;
        waterColor = Color.blue;
        neutralColor = Color.green;
        dynamicColor = Color.red;
        harmonicColor = Color.blue;
        zodiacSize = 75;
        signSize = 20;
        planetSize = 12;
        characterSize = 10;
        defaultConfiguration = true;
        defaultEvent = "0";
        defaultPlace = "0";
        shownSun = true;
        shownMoon = true;
        shownMercury = true;
        shownVenus = true;
        shownMars = true;
        shownJupiter = true;
        shownSaturn = true;
        shownUranus = true;
        shownNeptune = true;
        shownPluto = true;
        shownGaia = false;
        shownNorthNode = true;
        shownLilith = true;
        shownEast = false;
        shownZenith = false;
        shownVertex = false;
        shownVulcan = false;
        shownOtherPoint = false;
        shownCeres = false;
        shownPallas = false;
        shownJuno = false;
        shownVesta = false;
        shownChiron = true;
        trueLilith = true;
        otherPointType = 0;
        otherPointName = "";
        coloredAspects = false;
        coordSys = StarLogin.Systeme.Enum.CoordSystem.Tropical;
        houseSys = StarLogin.Systeme.Enum.HouseSystem.Campanus;
        housesCoords = true;
        signsNames = false;
        leftAsct = true;
        limitMag = "3.0";
        symbolAspects = false;
        viewStars = false;
        viewAsteroids = true;
        viewCoordinates = true;
        viewStraightLines = false;
        viewHouses = true;
        viewConstellations = false;
        viewShadedLines = true;
        viewAspects = true;
        viewBarycenter = false;
        singleWeight = false;
        horizon = false;
        aspectsSun = true;
        aspectsMoon = true;
        aspectsMercury = true;
        aspectsVenus = true;
        aspectsMars = true;
        aspectsJupiter = true;
        aspectsSaturn = true;
        aspectsUranus = true;
        aspectsNeptune = true;
        aspectsPluto = true;
        aspectsGaia = false;
        aspectsNorthNode = false;
        aspectsLilith = false;
        aspectsEast = false;
        aspectsZenith = false;
        aspectsVertex = false;
        aspectsVulcan = false;
        aspectsOtherPoint = false;
        aspectsCeres = false;
        aspectsPallas = false;
        aspectsJuno = false;
        aspectsVesta = false;
        aspectsChiron = false;
        aspectsAS = false;
        aspectsMC = false;
        shownAspect0 = true;
        shownAspect1 = true;
        shownAspect2 = true;
        shownAspect3 = true;
        shownAspect4 = true;
        shownAspect5 = false;
        shownAspect6 = false;
        shownAspect7 = false;
        shownAspect8 = false;
        shownAspect9 = false;
        shownAspect10 = false;
        shownAspect11 = false;
        shownAspect12 = false;
        shownAspect13 = false;
        shownAspect14 = false;
        shownAspect15 = true;
        shownAspect16 = false;
        shownAspect17 = false;
        colorAspect0 = Color.black;
        colorAspect1 = Color.black;
        colorAspect2 = Color.black;
        colorAspect3 = Color.black;
        colorAspect4 = Color.black;
        colorAspect5 = Color.black;
        colorAspect6 = Color.black;
        colorAspect7 = Color.black;
        colorAspect8 = Color.black;
        colorAspect9 = Color.black;
        colorAspect10 = Color.black;
        colorAspect11 = Color.black;
        colorAspect12 = Color.black;
        colorAspect13 = Color.black;
        colorAspect14 = Color.black;
        colorAspect15 = Color.black;
        colorAspect16 = Color.black;
        colorAspect17 = Color.black;
        colorBackground = new Color(204, 204, 204);
        colorForeground = Color.black;
        colorLabelsBackground = new Color(102, 200, 255);
        colorLabelsForeground = Color.black;
        colorTextZonesBackground = Color.white;
        colorTextZonesForeground = Color.black;
        colorButtonsBackground = new Color(153, 204, 255);
        colorButtonsForeground = Color.black;
        typeAspect0 = "N";
        typeAspect1 = "H";
        typeAspect2 = "D";
        typeAspect3 = "H";
        typeAspect4 = "D";
        typeAspect5 = "N";
        typeAspect6 = "N";
        typeAspect7 = "N";
        typeAspect8 = "D";
        typeAspect9 = "N";
        typeAspect10 = "N";
        typeAspect11 = "N";
        typeAspect12 = "D";
        typeAspect13 = "N";
        typeAspect14 = "N";
        typeAspect15 = "N";
        typeAspect16 = "N";
        typeAspect17 = "N";
        otherAspectValue = "0.0";
        otherAspectName = "";
        orbLightLight = "10.0";
        orbLightTell = "9.0";
        orbLightOtherInd = "8.0";
        orbLightColl = "7.5";
        orbLightVirtMax = "7.0";
        orbLightVirtMin = "6.0";
        orbTellTell = "8.0";
        orbTellOtherInd = "7.5";
        orbTellColl = "7.0";
        orbTellVirtMax = "6.0";
        orbTellVirtMin = "5.0";
        orbOtherIndOtherInd = "7.0";
        orbOtherIndColl = "6.0";
        orbOtherIndVirtMax = "5.0";
        orbOtherIndVirtMin = "4.5";
        orbCollColl = "5.0";
        orbCollVirtMax = "4.5";
        orbCollVirtMin = "4.0";
        orbVirtMaxVirtMax = "4.0";
        orbVirtMaxVirtMin = "3.0";
        orbVirtMinVirtMin = "2.5";
        divMin = "3.0";
        divConjuntion = "1.0";
        divSextil = "1.25";
        divSquare = "1.2";
        divTrine = "1.15";
        divOpposition = "1.1";
        chartSelectSingle = false;
        chartKinds = "0";
        chartDir1Corresp = "1.0";
        chartDir2Corresp = "1.0";
        chartDirSCorresp = "1.0";
        chartDir1Degree = "1.0";
        chartDir2Day = "1.0";
        chartDirSDegree = "1.0";
        chartDir1SpaceKind = "0";
        chartDir2SpaceKind = "0";
        chartDirSSpaceKind = "0";
        chartReturnPrecess = false;
        chartCompositeFromAS = false;
        chartReturnPlaceID = "0";
        chartCyclePlaceID = "0";
        chartReturnPlanet = "0";
        chartCyclePlanet1 = "5";
        chartCyclePlanet2 = "6";
        chartCompositeNB = "2";
        chartHarmonicNB = "2";
    }
    
    public byte getCoordSys()
    {
        return coordSys;
    }
    public byte getHouseSys()
    {
        return houseSys;
    }
    public byte getOtherPointType()
    {
        return otherPointType;
    }
    public String getChartReturnPlanet()
    {
        return chartReturnPlanet;
    }
    public String getChartCyclePlanet1()
    {
        return chartCyclePlanet1;
    }
    public String getChartCyclePlanet2()
    {
        return chartCyclePlanet2;
    }
    public String getChartCompositeNB()
    {
        return chartCompositeNB;
    }
    public String getChartHarmonicNB()
    {
        return chartHarmonicNB;
    }
    public String getChartDir1SpaceKind()
    {
        return chartDir1SpaceKind;
    }
    public String getChartDir2SpaceKind()
    {
        return chartDir2SpaceKind;
    }
    public String getChartDirSSpaceKind()
    {
        return chartDirSSpaceKind;
    }
    public String getOtherPointName()
    {
        return otherPointName;
    }
    public String getConfigurationName()
    {
        return configurationName;
    }
    public int getZodiacSize()
    {
        return zodiacSize;
    }
    public int getSignSize()
    {
        return signSize;
    }
    public int getPlanetSize()
    {
        return planetSize;
    }
    public Color getPlanetColor(int planet)
    {
        switch(planet)
        {
            case Planets.Sun: return sunColor;
            case Planets.Moon: return moonColor;
            case Planets.Mercury: return mercuryColor;
            case Planets.Venus: return venusColor;
            case Planets.Mars: return marsColor;
            case Planets.Jupiter: return jupiterColor;
            case Planets.Saturn: return saturnColor;
            case Planets.Uranus: return uranusColor;
            case Planets.Neptune: return neptuneColor;
            case Planets.Pluto: return plutoColor;
            case Planets.Gaia: return gaiaColor;
            case Planets.NorthNode: return nodesColor;
            case Planets.Lilith: return nodesColor;
            case Planets.East: ;
            case Planets.Zenith: ;
            case Planets.Vertex: return variousColor;
            case Planets.Vulcan: return vulcanColor;
            case Planets.OtherPoint: return variousColor;
            case Planets.Ceres: ;
            case Planets.Pallas: ;
            case Planets.Juno: ;
            case Planets.Vesta: ;
            case Planets.Chiron: return asteroidsColor;
            case Planets.AS: ;
            case Planets.MC: ;
            case Planets.House1: ;
            case Planets.House2: ;
            case Planets.House3: ;
            case Planets.House4: ;
            case Planets.House5: ;
            case Planets.House6: ;
            case Planets.House7: ;
            case Planets.House8: ;
            case Planets.House9: ;
            case Planets.House10: ;
            case Planets.House11: ;
            case Planets.House12: return cuspsColor;
            case Planets.SouthNode: return nodesColor;
            default: return Color.BLACK;
        }
    }
    public int getCharacterSize()
    {
        return characterSize;
    }
    public String getTypeAspect0()
    {
        return typeAspect0;
    }
    public String getTypeAspect1()
    {
        return typeAspect1;
    }
    public String getTypeAspect2()
    {
        return typeAspect2;
    }
    public String getTypeAspect3()
    {
        return typeAspect3;
    }
    public String getTypeAspect4()
    {
        return typeAspect4;
    }
    public String getTypeAspect5()
    {
        return typeAspect5;
    }
    public String getTypeAspect6()
    {
        return typeAspect6;
    }
    public String getTypeAspect7()
    {
        return typeAspect7;
    }
    public String getTypeAspect8()
    {
        return typeAspect8;
    }
    public String getTypeAspect9()
    {
        return typeAspect9;
    }
    public String getTypeAspect10()
    {
        return typeAspect10;
    }
    public String getTypeAspect11()
    {
        return typeAspect11;
    }
    public String getTypeAspect12()
    {
        return typeAspect12;
    }
    public String getTypeAspect13()
    {
        return typeAspect13;
    }
    public String getTypeAspect14()
    {
        return typeAspect14;
    }
    public String getTypeAspect15()
    {
        return typeAspect15;
    }
    public String getTypeAspect16()
    {
        return typeAspect16;
    }
    public String getTypeAspect17()
    {
        return typeAspect17;
    }
    public String getOtherAspectName()
    {
        return otherAspectName;
    }
    public String getChartKinds()
    {
        return chartKinds;
    }
    public String getChartReturnPlaceID()
    {
        return chartReturnPlaceID;
    }
    public String getChartCyclePlaceID()
    {
        return chartCyclePlaceID;
    }
    public Color getSunColor()
    {
        return sunColor;
    }
    public Color getMoonColor()
    {
        return moonColor;
    }
    public Color getMercuryColor()
    {
        return mercuryColor;
    }
    public Color getVenusColor()
    {
        return venusColor;
    }
    public Color getMarsColor()
    {
        return marsColor;
    }
    public Color getJupiterColor()
    {
        return jupiterColor;
    }
    public Color getSaturnColor()
    {
        return saturnColor;
    }
    public Color getUranusColor()
    {
        return uranusColor;
    }
    public Color getNeptuneColor()
    {
        return neptuneColor;
    }
    public Color getPlutoColor()
    {
        return plutoColor;
    }
    public Color getGaiaColor()
    {
        return gaiaColor;
    }
    public Color getNodesColor()
    {
        return nodesColor;
    }
    public Color getCuspsColor()
    {
        return cuspsColor;
    }
    public Color getAsteroidsColor()
    {
        return asteroidsColor;
    }
    public Color getVulcanColor()
    {
        return vulcanColor;
    }
    public Color getVariousColor()
    {
        return variousColor;
    }
    public Color getFireColor()
    {
        return fireColor;
    }
    public Color getEarthColor()
    {
        return earthColor;
    }
    public Color getAirColor()
    {
        return airColor;
    }
    public Color getWaterColor()
    {
        return waterColor;
    }
    public Color getNeutralColor()
    {
        return neutralColor;
    }
    public Color getDynamicColor()
    {
        return dynamicColor;
    }
    public Color getHarmonicColor()
    {
        return harmonicColor;
    }
    public String getDefaultEvent()
    {
        return defaultEvent;
    }
    public String getDefaultPlace()
    {
        return defaultPlace;
    }
    public Color getColorAspect0()
    {
        return colorAspect0;
    }
    public Color getColorAspect1()
    {
        return colorAspect1;
    }
    public Color getColorAspect2()
    {
        return colorAspect2;
    }
    public Color getColorAspect3()
    {
        return colorAspect3;
    }
    public Color getColorAspect4()
    {
        return colorAspect4;
    }
    public Color getColorAspect5()
    {
        return colorAspect5;
    }
    public Color getColorAspect6()
    {
        return colorAspect6;
    }
    public Color getColorAspect7()
    {
        return colorAspect7;
    }
    public Color getColorAspect8()
    {
        return colorAspect8;
    }
    public Color getColorAspect9()
    {
        return colorAspect9;
    }
    public Color getColorAspect10()
    {
        return colorAspect10;
    }
    public Color getColorAspect11()
    {
        return colorAspect11;
    }
    public Color getColorAspect12()
    {
        return colorAspect12;
    }
    public Color getColorAspect13()
    {
        return colorAspect13;
    }
    public Color getColorAspect14()
    {
        return colorAspect14;
    }
    public Color getColorAspect15()
    {
        return colorAspect15;
    }
    public Color getColorAspect16()
    {
        return colorAspect16;
    }
    public Color getColorAspect17()
    {
        return colorAspect17;
    }
    public Color getColorBackground()
    {
        return colorBackground;
    }
    public Color getColorForeground()
    {
        return colorForeground;
    }
    public Color getColorLabelsBackground()
    {
        return colorLabelsBackground;
    }
    public Color getColorLabelsForeground()
    {
        return colorLabelsForeground;
    }
    public Color getColorTextZonesBackground()
    {
        return colorTextZonesBackground;
    }
    public Color getColorTextZonesForeground()
    {
        return colorTextZonesForeground;
    }
    public Color getColorButtonsBackground()
    {
        return colorButtonsBackground;
    }
    public Color getColorButtonsForeground()
    {
        return colorButtonsForeground;
    }
    public boolean getDefaultConfiguration()
    {
        return defaultConfiguration;
    }
    public boolean getShownSun()
    {
        return shownSun;
    }
    public boolean getShownMoon()
    {
        return shownMoon;
    }
    public boolean getShownMercury()
    {
        return shownMercury;
    }
    public boolean getShownVenus()
    {
        return shownVenus;
    }
    public boolean getShownMars()
    {
        return shownMars;
    }
    public boolean getShownJupiter()
    {
        return shownJupiter;
    }
    public boolean getShownSaturn()
    {
        return shownSaturn;
    }
    public boolean getShownUranus()
    {
        return shownUranus;
    }
    public boolean getShownNeptune()
    {
        return shownNeptune;
    }
    public boolean getShownPluto()
    {
        return shownPluto;
    }
    public boolean getShownGaia()
    {
        return shownGaia;
    }
    public boolean getShownNorthNode()
    {
        return shownNorthNode;
    }
    public boolean getShownLilith()
    {
        return shownLilith;
    }
    public boolean getShownEast()
    {
        return shownEast;
    }
    public boolean getShownZenith()
    {
        return shownZenith;
    }
    public boolean getShownVertex()
    {
        return shownVertex;
    }
    public boolean getShownVulcan()
    {
        return shownVulcan;
    }
    public boolean getShownOtherPoint()
    {
        return shownOtherPoint;
    }
    public boolean getShownCeres()
    {
        return shownCeres;
    }
    public boolean getShownPallas()
    {
        return shownPallas;
    }
    public boolean getShownJuno()
    {
        return shownJuno;
    }
    public boolean getShownVesta()
    {
        return shownVesta;
    }
    public boolean getShownChiron()
    {
        return shownChiron;
    }
    public boolean getTrueLilith()
    {
        return trueLilith;
    }
    public boolean getColoredAspects()
    {
        return coloredAspects;
    }
    public boolean getHousesCoords()
    {
        return housesCoords;
    }
    public boolean getSignsNames()
    {
        return signsNames;
    }
    public boolean getLeftAsct()
    {
        return leftAsct;
    }
    public boolean getSymbolAspects()
    {
        return symbolAspects;
    }
    public boolean getViewStars()
    {
        return viewStars;
    }
    public boolean getViewAsteroids()
    {
        return viewAsteroids;
    }
    public boolean getViewCoordinates()
    {
        return viewCoordinates;
    }
    public boolean getViewStraightLines()
    {
        return viewStraightLines;
    }
    public boolean getViewHouses()
    {
        return viewHouses;
    }
    public boolean getViewConstellations()
    {
        return viewConstellations;
    }
    public boolean getViewShadedLines()
    {
        return viewShadedLines;
    }
    public boolean getViewAspects()
    {
        return viewAspects;
    }
    public boolean getViewBarycenter()
    {
        return viewBarycenter;
    }
    public boolean getSingleWeight()
    {
        return singleWeight;
    }
    public boolean getHorizon()
    {
        return horizon;
    }
    public boolean getAspectsSun()
    {
        return aspectsSun;
    }
    public boolean getAspectsMoon()
    {
        return aspectsMoon;
    }
    public boolean getAspectsMercury()
    {
        return aspectsMercury;
    }
    public boolean getAspectsVenus()
    {
        return aspectsVenus;
    }
    public boolean getAspectsMars()
    {
        return aspectsMars;
    }
    public boolean getAspectsJupiter()
    {
        return aspectsJupiter;
    }
    public boolean getAspectsSaturn()
    {
        return aspectsSaturn;
    }
    public boolean getAspectsUranus()
    {
        return aspectsUranus;
    }
    public boolean getAspectsNeptune()
    {
        return aspectsNeptune;
    }
    public boolean getAspectsPluto()
    {
        return aspectsPluto;
    }
    public boolean getAspectsGaia()
    {
        return aspectsGaia;
    }
    public boolean getAspectsNorthNode()
    {
        return aspectsNorthNode;
    }
    public boolean getAspectsLilith()
    {
        return aspectsLilith;
    }
    public boolean getAspectsEast()
    {
        return aspectsEast;
    }
    public boolean getAspectsZenith()
    {
        return aspectsZenith;
    }
    public boolean getAspectsVertex()
    {
        return aspectsVertex;
    }
    public boolean getAspectsVulcan()
    {
        return aspectsVulcan;
    }
    public boolean getAspectsOtherPoint()
    {
        return aspectsOtherPoint;
    }
    public boolean getAspectsCeres()
    {
        return aspectsCeres;
    }
    public boolean getAspectsPallas()
    {
        return aspectsPallas;
    }
    public boolean getAspectsJuno()
    {
        return aspectsJuno;
    }
    public boolean getAspectsVesta()
    {
        return aspectsVesta;
    }
    public boolean getAspectsChiron()
    {
        return aspectsChiron;
    }
    public boolean getAspectsAS()
    {
        return aspectsAS;
    }
    public boolean getAspectsMC()
    {
        return aspectsMC;
    }
    public boolean getShownAspect0()
    {
        return shownAspect0;
    }
    public boolean getShownAspect1()
    {
        return shownAspect1;
    }
    public boolean getShownAspect2()
    {
        return shownAspect2;
    }
    public boolean getShownAspect3()
    {
        return shownAspect3;
    }
    public boolean getShownAspect4()
    {
        return shownAspect4;
    }
    public boolean getShownAspect5()
    {
        return shownAspect5;
    }
    public boolean getShownAspect6()
    {
        return shownAspect6;
    }
    public boolean getShownAspect7()
    {
        return shownAspect7;
    }
    public boolean getShownAspect8()
    {
        return shownAspect8;
    }
    public boolean getShownAspect9()
    {
        return shownAspect9;
    }
    public boolean getShownAspect10()
    {
        return shownAspect10;
    }
    public boolean getShownAspect11()
    {
        return shownAspect11;
    }
    public boolean getShownAspect12()
    {
        return shownAspect12;
    }
    public boolean getShownAspect13()
    {
        return shownAspect13;
    }
    public boolean getShownAspect14()
    {
        return shownAspect14;
    }
    public boolean getShownAspect15()
    {
        return shownAspect15;
    }
    public boolean getShownAspect16()
    {
        return shownAspect16;
    }
    public boolean getShownAspect17()
    {
        return shownAspect17;
    }
    public boolean getChartSelectSingle()
    {
        return chartSelectSingle;
    }
    public boolean getChartReturnPrecess()
    {
        return chartReturnPrecess;
    }
    public boolean getChartCompositeFromAS()
    {
        return chartCompositeFromAS;
    }
    public String getLimitMag()
    {
        return limitMag;
    }
    public String getOrbLightLight()
    {
        return orbLightLight;
    }
    public String getOrbLightTell()
    {
        return orbLightTell;
    }
    public String getOrbLightOtherInd()
    {
        return orbLightOtherInd;
    }
    public String getOrbLightColl()
    {
        return orbLightColl;
    }
    public String getOrbLightVirtMax()
    {
        return orbLightVirtMax;
    }
    public String getOrbLightVirtMin()
    {
        return orbLightVirtMin;
    }
    public String getOrbTellTell()
    {
        return orbTellTell;
    }
    public String getOrbTellOtherInd()
    {
        return orbTellOtherInd;
    }
    public String getOrbTellColl()
    {
        return orbTellColl;
    }
    public String getOrbTellVirtMax()
    {
        return orbTellVirtMax;
    }
    public String getOrbTellVirtMin()
    {
        return orbTellVirtMin;
    }
    public String getOrbOtherIndOtherInd()
    {
        return orbOtherIndOtherInd;
    }
    public String getOrbOtherIndColl()
    {
        return orbOtherIndColl;
    }
    public String getOrbOtherIndVirtMax()
    {
        return orbOtherIndVirtMax;
    }
    public String getOrbOtherIndVirtMin()
    {
        return orbOtherIndVirtMin;
    }
    public String getOrbCollColl()
    {
        return orbCollColl;
    }
    public String getOrbCollVirtMax()
    {
        return orbCollVirtMax;
    }
    public String getOrbCollVirtMin()
    {
        return orbCollVirtMin;
    }
    public String getOrbVirtMaxVirtMax()
    {
        return orbVirtMaxVirtMax;
    }
    public String getOrbVirtMaxVirtMin()
    {
        return orbVirtMaxVirtMin;
    }
    public String getOrbVirtMinVirtMin()
    {
        return orbVirtMinVirtMin;
    }
    public String getDivMin()
    {
        return divMin;
    }
    public String getDivConjuntion()
    {
        return divConjuntion;
    }
    public String getDivSextil()
    {
        return divSextil;
    }
    public String getDivSquare()
    {
        return divSquare;
    }
    public String getDivTrine()
    {
        return divTrine;
    }
    public String getDivOpposition()
    {
        return divOpposition;
    }
    public String getOtherAspectValue()
    {
        return otherAspectValue;
    }
    public String getChartDir1Corresp()
    {
        return chartDir1Corresp;
    }
    public String getChartDir2Corresp()
    {
        return chartDir2Corresp;
    }
    public String getChartDirSCorresp()
    {
        return chartDirSCorresp;
    }
    public String getChartDir1Degree()
    {
        return chartDir1Degree;
    }
    public String getChartDir2Day()
    {
        return chartDir2Day;
    }
    public String getChartDirSDegree()
    {
        return chartDirSDegree;
    }
    
    public void setCoordSys(byte data)
    {
        coordSys = data;
    }
    
    public void setHouseSys(byte data)
    {
        houseSys = data;
    }
    
    public void setOtherPointType(byte data)
    {
        otherPointType = data;
    }
    
    public void setChartReturnPlanet(String sData)
    {
        chartReturnPlanet = sData;
    }
    
    public void setChartCyclePlanet1(String sData)
    {
        chartCyclePlanet1 = sData;
    }
    
    public void setChartCyclePlanet2(String sData)
    {
        chartCyclePlanet2 = sData;
    }
    
    public void setChartCompositeNB(String sData)
    {
        chartCompositeNB = sData;
    }
    
    public void setChartHarmonicNB(String sData)
    {
        chartHarmonicNB = sData;
    }
    
    public void setChartDir1SpaceKind(String sData)
    {
        chartDir1SpaceKind = sData;
    }
    
    public void setChartDir2SpaceKind(String sData)
    {
        chartDir2SpaceKind = sData;
    }
    
    public void setChartDirSSpaceKind(String sData)
    {
        chartDirSSpaceKind = sData;
    }
    
    public void setOtherPointName(String sData)
    {
        otherPointName = sData;
    }
    
    public void setConfigurationName(String sData)
    {
        configurationName = sData;
    }
    
    public void setZodiacSize(int data)
    {
        zodiacSize = data;
    }
    
    public void setSignSize(int data)
    {
        signSize = data;
    }
    
    public void setPlanetSize(int data)
    {
        planetSize = data;
    }
    
    public void setCharacterSize(int data)
    {
        characterSize = data;
    }
    
    public void setTypeAspect0(String sData)
    {
        typeAspect0 = sData;
    }
    
    public void setTypeAspect1(String sData)
    {
        typeAspect1 = sData;
    }
    
    public void setTypeAspect2(String sData)
    {
        typeAspect2 = sData;
    }
    
    public void setTypeAspect3(String sData)
    {
        typeAspect3 = sData;
    }
    
    public void setTypeAspect4(String sData)
    {
        typeAspect4 = sData;
    }
    
    public void setTypeAspect5(String sData)
    {
        typeAspect5 = sData;
    }
    
    public void setTypeAspect6(String sData)
    {
        typeAspect6 = sData;
    }
    
    public void setTypeAspect7(String sData)
    {
        typeAspect7 = sData;
    }
    
    public void setTypeAspect8(String sData)
    {
        typeAspect8 = sData;
    }
    
    public void setTypeAspect9(String sData)
    {
        typeAspect9 = sData;
    }
    
    public void setTypeAspect10(String sData)
    {
        typeAspect10 = sData;
    }
    
    public void setTypeAspect11(String sData)
    {
        typeAspect11 = sData;
    }
    
    public void setTypeAspect12(String sData)
    {
        typeAspect12 = sData;
    }
    
    public void setTypeAspect13(String sData)
    {
        typeAspect13 = sData;
    }
    
    public void setTypeAspect14(String sData)
    {
        typeAspect14 = sData;
    }
    
    public void setTypeAspect15(String sData)
    {
        typeAspect15 = sData;
    }
    
    public void setTypeAspect16(String sData)
    {
        typeAspect16 = sData;
    }
    
    public void setTypeAspect17(String sData)
    {
        typeAspect17 = sData;
    }
    
    public void setOtherAspectName(String sData)
    {
        otherAspectName = sData;
    }
    
    public void setChartKinds(String sData)
    {
        chartKinds = sData;
    }
    
    public void setChartReturnPlaceID(String sData)
    {
        chartReturnPlaceID = sData;
    }
    
    public void setChartCyclePlaceID(String sData)
    {
        chartCyclePlaceID = sData;
    }
    
    public void setSunColor(Color sData)
    {
        sunColor = sData;
    }
    
    public void setMoonColor(Color sData)
    {
        moonColor = sData;
    }
    
    public void setMercuryColor(Color sData)
    {
        mercuryColor = sData;
    }
    
    public void setVenusColor(Color sData)
    {
        venusColor = sData;
    }
    
    public void setMarsColor(Color sData)
    {
        marsColor = sData;
    }
    
    public void setJupiterColor(Color sData)
    {
        jupiterColor = sData;
    }
    
    public void setSaturnColor(Color sData)
    {
        saturnColor = sData;
    }
    
    public void setUranusColor(Color sData)
    {
        uranusColor = sData;
    }
    
    public void setNeptuneColor(Color sData)
    {
        neptuneColor = sData;
    }
    
    public void setPlutoColor(Color sData)
    {
        plutoColor = sData;
    }
    
    public void setGaiaColor(Color sData)
    {
        gaiaColor = sData;
    }
    
    public void setNodesColor(Color sData)
    {
        nodesColor = sData;
    }
    
    public void setCuspsColor(Color sData)
    {
        cuspsColor = sData;
    }
    
    public void setAsteroidsColor(Color sData)
    {
        asteroidsColor = sData;
    }
    
    public void setVulcanColor(Color sData)
    {
        vulcanColor = sData;
    }
    
    public void setVariousColor(Color sData)
    {
        variousColor = sData;
    }
    
    public void setFireColor(Color sData)
    {
        fireColor = sData;
    }
    
    public void setEarthColor(Color sData)
    {
        earthColor = sData;
    }
    
    public void setAirColor(Color sData)
    {
        airColor = sData;
    }
    
    public void setWaterColor(Color sData)
    {
        waterColor = sData;
    }
    
    public void setNeutralColor(Color sData)
    {
        neutralColor = sData;
    }
    
    public void setDynamicColor(Color sData)
    {
        dynamicColor = sData;
    }
    
    public void setHarmonicColor(Color sData)
    {
        harmonicColor = sData;
    }
    
    public void setDefaultEvent(String sData)
    {
        defaultEvent = sData;
    }
    
    public void setDefaultPlace(String sData)
    {
        defaultPlace = sData;
    }
    
    public void setColorAspect0(Color sData)
    {
        colorAspect0 = sData;
    }
    
    public void setColorAspect1(Color sData)
    {
        colorAspect1 = sData;
    }
    
    public void setColorAspect2(Color sData)
    {
        colorAspect2 = sData;
    }
    
    public void setColorAspect3(Color sData)
    {
        colorAspect3 = sData;
    }
    
    public void setColorAspect4(Color sData)
    {
        colorAspect4 = sData;
    }
    
    public void setColorAspect5(Color sData)
    {
        colorAspect5 = sData;
    }
    
    public void setColorAspect6(Color sData)
    {
        colorAspect6 = sData;
    }
    
    public void setColorAspect7(Color sData)
    {
        colorAspect7 = sData;
    }
    
    public void setColorAspect8(Color sData)
    {
        colorAspect8 = sData;
    }
    
    public void setColorAspect9(Color sData)
    {
        colorAspect9 = sData;
    }
    
    public void setColorAspect10(Color sData)
    {
        colorAspect10 = sData;
    }
    
    public void setColorAspect11(Color sData)
    {
        colorAspect11 = sData;
    }
    
    public void setColorAspect12(Color sData)
    {
        colorAspect12 = sData;
    }
    
    public void setColorAspect13(Color sData)
    {
        colorAspect13 = sData;
    }
    
    public void setColorAspect14(Color sData)
    {
        colorAspect14 = sData;
    }
    
    public void setColorAspect15(Color sData)
    {
        colorAspect15 = sData;
    }
    
    public void setColorAspect16(Color sData)
    {
        colorAspect16 = sData;
    }
    
    public void setColorAspect17(Color sData)
    {
        colorAspect17 = sData;
    }
    
    public void setColorBackground(Color sData)
    {
        colorBackground = sData;
    }
    public void setColorForeground(Color sData)
    {
        colorForeground = sData;
    }
    public void setColorLabelsBackground(Color sData)
    {
        colorLabelsBackground = sData;
    }
    public void setColorLabelsForeground(Color sData)
    {
        colorLabelsForeground = sData;
    }
    public void setColorTextZonesBackground(Color sData)
    {
        colorTextZonesBackground = sData;
    }
    public void setColorTextZonesForeground(Color sData)
    {
        colorTextZonesForeground = sData;
    }
    public void setColorButtonsBackground(Color sData)
    {
        colorButtonsBackground = sData;
    }
    public void setColorButtonsForeground(Color sData)
    {
        colorButtonsForeground = sData;
    }
    
    public void setDefaultConfiguration(boolean sData)
    {
        defaultConfiguration = sData;
    }
    
    public void setShownSun(boolean sData)
    {
        shownSun = sData;
    }
    
    public void setShownMoon(boolean sData)
    {
        shownMoon = sData;
    }
    
    public void setShownMercury(boolean sData)
    {
        shownMercury = sData;
    }
    
    public void setShownVenus(boolean sData)
    {
        shownVenus = sData;
    }
    
    public void setShownMars(boolean sData)
    {
        shownMars = sData;
    }
    
    public void setShownJupiter(boolean sData)
    {
        shownJupiter = sData;
    }
    
    public void setShownSaturn(boolean sData)
    {
        shownSaturn = sData;
    }
    
    public void setShownUranus(boolean sData)
    {
        shownUranus = sData;
    }
    
    public void setShownNeptune(boolean sData)
    {
        shownNeptune = sData;
    }
    
    public void setShownPluto(boolean sData)
    {
        shownPluto = sData;
    }
    
    public void setShownGaia(boolean sData)
    {
        shownGaia = sData;
    }
    
    public void setShownNorthNode(boolean sData)
    {
        shownNorthNode = sData;
    }
    
    public void setShownLilith(boolean sData)
    {
        shownLilith = sData;
    }
    
    public void setShownEast(boolean sData)
    {
        shownEast = sData;
    }
    
    public void setShownZenith(boolean sData)
    {
        shownZenith = sData;
    }
    
    public void setShownVertex(boolean sData)
    {
        shownVertex = sData;
    }
    
    public void setShownVulcan(boolean sData)
    {
        shownVulcan = sData;
    }
    
    public void setShownOtherPoint(boolean sData)
    {
        shownOtherPoint = sData;
    }
    
    public void setShownCeres(boolean sData)
    {
        shownCeres = sData;
    }
    
    public void setShownPallas(boolean sData)
    {
        shownPallas = sData;
    }
    
    public void setShownJuno(boolean sData)
    {
        shownJuno = sData;
    }
    
    public void setShownVesta(boolean sData)
    {
        shownVesta = sData;
    }
    
    public void setShownChiron(boolean sData)
    {
        shownChiron = sData;
    }
    
    public void setTrueLilith(boolean sData)
    {
        trueLilith = sData;
    }
    
    public void setColoredAspects(boolean sData)
    {
        coloredAspects = sData;
    }
    
    public void setHousesCoords(boolean sData)
    {
        housesCoords = sData;
    }
    
    public void setSignsNames(boolean sData)
    {
        signsNames = sData;
    }
    
    public void setLeftAsct(boolean sData)
    {
        leftAsct = sData;
    }
    
    public void setSymbolAspects(boolean sData)
    {
        symbolAspects = sData;
    }
    
    public void setViewStars(boolean sData)
    {
        viewStars = sData;
    }
    
    public void setViewAsteroids(boolean sData)
    {
        viewAsteroids = sData;
    }
    
    public void setViewCoordinates(boolean sData)
    {
        viewCoordinates = sData;
    }
    
    public void setViewStraightLines(boolean sData)
    {
        viewStraightLines = sData;
    }
    
    public void setViewHouses(boolean sData)
    {
        viewHouses = sData;
    }
    
    public void setViewConstellations(boolean sData)
    {
        viewConstellations = sData;
    }
    
    public void setViewShadedLines(boolean sData)
    {
        viewShadedLines = sData;
    }
    
    public void setViewAspects(boolean sData)
    {
        viewAspects = sData;
    }
    
    public void setViewBarycenter(boolean sData)
    {
        viewBarycenter = sData;
    }
    
    public void setSingleWeight(boolean sData)
    {
        singleWeight = sData;
    }
    
    public void setHorizon(boolean sData)
    {
        horizon = sData;
    }
    
    public void setAspectsSun(boolean sData)
    {
        aspectsSun = sData;
    }
    
    public void setAspectsMoon(boolean sData)
    {
        aspectsMoon = sData;
    }
    
    public void setAspectsMercury(boolean sData)
    {
        aspectsMercury = sData;
    }
    
    public void setAspectsVenus(boolean sData)
    {
        aspectsVenus = sData;
    }
    
    public void setAspectsMars(boolean sData)
    {
        aspectsMars = sData;
    }
    
    public void setAspectsJupiter(boolean sData)
    {
        aspectsJupiter = sData;
    }
    
    public void setAspectsSaturn(boolean sData)
    {
        aspectsSaturn = sData;
    }
    
    public void setAspectsUranus(boolean sData)
    {
        aspectsUranus = sData;
    }
    
    public void setAspectsNeptune(boolean sData)
    {
        aspectsNeptune = sData;
    }
    
    public void setAspectsPluto(boolean sData)
    {
        aspectsPluto = sData;
    }
    
    public void setAspectsGaia(boolean sData)
    {
        aspectsGaia = sData;
    }
    
    public void setAspectsNorthNode(boolean sData)
    {
        aspectsNorthNode = sData;
    }
    
    public void setAspectsLilith(boolean sData)
    {
        aspectsLilith = sData;
    }
    
    public void setAspectsEast(boolean sData)
    {
        aspectsEast = sData;
    }
    
    public void setAspectsZenith(boolean sData)
    {
        aspectsZenith = sData;
    }
    
    public void setAspectsVertex(boolean sData)
    {
        aspectsVertex = sData;
    }
    
    public void setAspectsVulcan(boolean sData)
    {
        aspectsVulcan = sData;
    }
    
    public void setAspectsOtherPoint(boolean sData)
    {
        aspectsOtherPoint = sData;
    }
    
    public void setAspectsCeres(boolean sData)
    {
        aspectsCeres = sData;
    }
    
    public void setAspectsPallas(boolean sData)
    {
        aspectsPallas = sData;
    }
    
    public void setAspectsJuno(boolean sData)
    {
        aspectsJuno = sData;
    }
    
    public void setAspectsVesta(boolean sData)
    {
        aspectsVesta = sData;
    }
    
    public void setAspectsChiron(boolean sData)
    {
        aspectsChiron = sData;
    }
    
    public void setAspectsAS(boolean sData)
    {
        aspectsAS = sData;
    }
    
    public void setAspectsMC(boolean sData)
    {
        aspectsMC = sData;
    }
    
    public void setShownAspect0(boolean sData)
    {
        shownAspect0 = sData;
    }
    
    public void setShownAspect1(boolean sData)
    {
        shownAspect1 = sData;
    }
    
    public void setShownAspect2(boolean sData)
    {
        shownAspect2 = sData;
    }
    
    public void setShownAspect3(boolean sData)
    {
        shownAspect3 = sData;
    }
    
    public void setShownAspect4(boolean sData)
    {
        shownAspect4 = sData;
    }
    
    public void setShownAspect5(boolean sData)
    {
        shownAspect5 = sData;
    }
    
    public void setShownAspect6(boolean sData)
    {
        shownAspect6 = sData;
    }
    
    public void setShownAspect7(boolean sData)
    {
        shownAspect7 = sData;
    }
    
    public void setShownAspect8(boolean sData)
    {
        shownAspect8 = sData;
    }
    
    public void setShownAspect9(boolean sData)
    {
        shownAspect9 = sData;
    }
    
    public void setShownAspect10(boolean sData)
    {
        shownAspect10 = sData;
    }
    
    public void setShownAspect11(boolean sData)
    {
        shownAspect11 = sData;
    }
    
    public void setShownAspect12(boolean sData)
    {
        shownAspect12 = sData;
    }
    
    public void setShownAspect13(boolean sData)
    {
        shownAspect13 = sData;
    }
    
    public void setShownAspect14(boolean sData)
    {
        shownAspect14 = sData;
    }
    
    public void setShownAspect15(boolean sData)
    {
        shownAspect15 = sData;
    }
    
    public void setShownAspect16(boolean sData)
    {
        shownAspect16 = sData;
    }
    
    public void setShownAspect17(boolean sData)
    {
        shownAspect17 = sData;
    }
    
    public void setChartSelectSingle(boolean sData)
    {
        chartSelectSingle = sData;
    }
    
    public void setChartReturnPrecess(boolean sData)
    {
        chartReturnPrecess = sData;
    }
    
    public void setChartCompositeFromAS(boolean sData)
    {
        chartCompositeFromAS = sData;
    }
    
    public void setLimitMag(String sData)
    {
        limitMag = sData;
    }
    
    public void setOrbLightLight(String sData)
    {
        orbLightLight = sData;
    }
    
    public void setOrbLightTell(String sData)
    {
        orbLightTell = sData;
    }
    
    public void setOrbLightOtherInd(String sData)
    {
        orbLightOtherInd = sData;
    }
    
    public void setOrbLightColl(String sData)
    {
        orbLightColl = sData;
    }
    
    public void setOrbLightVirtMax(String sData)
    {
        orbLightVirtMax = sData;
    }
    
    public void setOrbLightVirtMin(String sData)
    {
        orbLightVirtMin = sData;
    }
    
    public void setOrbTellTell(String sData)
    {
        orbTellTell = sData;
    }
    
    public void setOrbTellOtherInd(String sData)
    {
        orbTellOtherInd = sData;
    }
    
    public void setOrbTellColl(String sData)
    {
        orbTellColl = sData;
    }
    
    public void setOrbTellVirtMax(String sData)
    {
        orbTellVirtMax = sData;
    }
    
    public void setOrbTellVirtMin(String sData)
    {
        orbTellVirtMin = sData;
    }
    
    public void setOrbOtherIndOtherInd(String sData)
    {
        orbOtherIndOtherInd = sData;
    }
    
    public void setOrbOtherIndColl(String sData)
    {
        orbOtherIndColl = sData;
    }
    
    public void setOrbOtherIndVirtMax(String sData)
    {
        orbOtherIndVirtMax = sData;
    }
    
    public void setOrbOtherIndVirtMin(String sData)
    {
        orbOtherIndVirtMin = sData;
    }
    
    public void setOrbCollColl(String sData)
    {
        orbCollColl = sData;
    }
    
    public void setOrbCollVirtMax(String sData)
    {
        orbCollVirtMax = sData;
    }
    
    public void setOrbCollVirtMin(String sData)
    {
        orbCollVirtMin = sData;
    }
    
    public void setOrbVirtMaxVirtMax(String sData)
    {
        orbVirtMaxVirtMax = sData;
    }
    
    public void setOrbVirtMaxVirtMin(String sData)
    {
        orbVirtMaxVirtMin = sData;
    }
    
    public void setOrbVirtMinVirtMin(String sData)
    {
        orbVirtMinVirtMin = sData;
    }
    
    public void setDivMin(String sData)
    {
        divMin = sData;
    }
    
    public void setDivConjuntion(String sData)
    {
        divConjuntion = sData;
    }
    
    public void setDivSextil(String sData)
    {
        divSextil = sData;
    }
    
    public void setDivSquare(String sData)
    {
        divSquare = sData;
    }
    
    public void setDivTrine(String sData)
    {
        divTrine = sData;
    }
    
    public void setDivOpposition(String sData)
    {
        divOpposition = sData;
    }
    
    public void setOtherAspectValue(String sData)
    {
        otherAspectValue = sData;
    }
    
    public void setChartDir1Corresp(String sData)
    {
        chartDir1Corresp = sData;
    }
    
    public void setChartDir2Corresp(String sData)
    {
        chartDir2Corresp = sData;
    }
    
    public void setChartDirSCorresp(String sData)
    {
        chartDirSCorresp = sData;
    }
    
    public void setChartDir1Degree(String sData)
    {
        chartDir1Degree = sData;
    }
    
    public void setChartDir2Day(String sData)
    {
        chartDir2Day = sData;
    }
    
    public void setChartDirSDegree(String sData)
    {
        chartDirSDegree = sData;
    }
}