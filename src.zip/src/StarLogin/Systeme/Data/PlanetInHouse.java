package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class PlanetInHouse implements java.io.Serializable
{
    private String meaning;
    private double value;
    private byte houseID;
    private byte planetID;
    
    /** Creates new PlanetInHouse */
    public PlanetInHouse()
    {
        planetID = -1;
        houseID = -1;
        meaning = "";
        value = 0.0;
    }
    
    public byte getPlanetID()
    {
        return planetID;
    }
    
    public void setPlanetID(byte data)
    {
        planetID = data;
    }
    
    public byte getHouseID()
    {
        return houseID;
    }
    
    public void setHouseID(byte data)
    {
        houseID = data;
    }
    
    public double getValue()
    {
        return value;
    }
    
    public void setValue(double data)
    {
        value = data;
    }
    
    public String getMeaning()
    {
        return meaning;
    }
    
    public void setMeaning(String sData)
    {
        meaning = sData;
    }
}
