package StarLogin.Systeme.Data;

import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Query implements java.io.Serializable {

    private ArrayList rows = new ArrayList(); 
    private ArrayList columnNames = new ArrayList();
    private ArrayList fields = new ArrayList();
    private ArrayList types = new ArrayList();
    
    /** Creates new Query */
    public Query()
    {
    }
    
    public ArrayList getHeaders()
    {
        return columnNames;
    }
    
    public ArrayList getFields()
    {
        return fields;
    }
    
    public ArrayList getQuery()
    {
        return rows;
    }
    
    public ArrayList getTypes()
    {
        return types;
    }
}
