package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ConfigurationsMeaning extends Record
{
    private String configurationMeaning;
    private String configurationName;
    private String configurationDescription;
    private byte configurationNumber;
    private double configurationValue;
    
    /** Creates new ConfigurationsMeaning */
    public ConfigurationsMeaning()
    {
        configurationMeaning = "";
        configurationName = "";
        configurationDescription = "";
        configurationNumber = 0;
        configurationValue = 0.0;
    }
    
    public String getConfigurationDescription()
    {
        return configurationDescription;
    }
    
    public void setConfigurationDescription(String sData)
    {
        configurationDescription = sData;
    }
    
    public String getConfigurationName()
    {
        return configurationName;
    }
    
    public void setConfigurationName(String sData)
    {
        configurationName = sData;
    }
    
    public String getConfigurationMeaning()
    {
        return configurationMeaning;
    }
    
    public void setConfigurationMeaning(String sData)
    {
        configurationMeaning = sData;
    }
    
    public byte getConfigurationNumber()
    {
        return configurationNumber;
    }
    
    public void setConfigurationNumber(byte data)
    {
        configurationNumber = data;
    }
    
    public double getConfigurationValue()
    {
        return configurationValue;
    }
    
    public void setConfigurationValue(double data)
    {
        configurationValue = data;
    }
}

