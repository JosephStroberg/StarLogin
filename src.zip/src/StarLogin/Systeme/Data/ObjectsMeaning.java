package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ObjectsMeaning implements java.io.Serializable
{
    private String meaning;
    private double value;
    private byte objectTypeID;
    private byte objectID;
    
    /** Creates new ObjectsMeaning */
    public ObjectsMeaning()
    {
        objectID = -1;
        objectTypeID = -1;
        meaning = "";
        value = 0.0;
    }
    
    public byte getObjectID()
    {
        return objectID;
    }
    
    public void setObjectID(byte data)
    {
        objectID = data;
    }
    
    public byte getObjectTypeID()
    {
        return objectTypeID;
    }
    
    public void setObjectTypeID(byte data)
    {
        objectTypeID = data;
    }
    
    public double getValue()
    {
        return value;
    }
    
    public void setValue(double data)
    {
        value = data;
    }
    
    public String getMeaning()
    {
        return meaning;
    }
    
    public void setMeaning(String sData)
    {
        meaning = sData;
    }
}
