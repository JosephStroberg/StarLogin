/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.Systeme.Data;

/**
 *
 * @author Francois
 */
public class Divider
{
    private String optionid;
    private String component;
    private String window;
    private String valeur;
    
    public String getID()
    {
        return optionid;
    }
    
    public String getComponentName()
    {
        return component;
    }
    
    public String getWindow()
    {
        return window;
    }
    
    public String getValeur()
    {
        return valeur;
    }
    
    public void setID(String data)
    {
        optionid = data;
    }
    
    public void setComponent(String data)
    {
        component = data;
    }
    
    public void setWindow(String data)
    {
        window = data;
    }
    
    public void setValeur(String data)
    {
        valeur = data;
    }
}
