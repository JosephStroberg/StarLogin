package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ConfigurationsMeanings extends Records {

    /** Creates new ConfigurationsMeanings */
    public ConfigurationsMeanings() {}
}

