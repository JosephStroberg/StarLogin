package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Position extends Record
{
    private String objName;
    private double helioLatitude;
    private double helioLongitude;
    private double helioLongitudeSider;
    private double helioDistance;
    private double geoLatitude;
    private double geoLongitude;
    private double geoLongitudeSider;
    private double geoDistance;
    private double rightAscension;
    private double declination;
    private double azimuth;
    private double altitude;
    private double angleWithSun;
    private double angleWithMoon;
    private double angleWithMercury;
    private double angleWithVenus;
    private double angleWithMars;
    private double angleWithJupiter;
    private double angleWithSaturn;
    private double angleWithUranus;
    private double angleWithNeptune;
    private double angleWithPluto;
    private double angleWithEarth;
    private double angleWithNorthNode;
    private double angleWithLilith;
    private double angleWithEast;
    private double angleWithZenith;
    private double angleWithVertex;
    private double angleWithVulcan;
    private double angleWithOtherPoint;
    private double angleWithCeres;
    private double angleWithPallas;
    private double angleWithJuno;
    private double angleWithVesta;
    private double angleWithChiron;
    private double angleWithAscendant;
    private double angleWithMidheaven;
    private String sign;
    private String zodConstel;
    private String constellation;
    private String house;
    private byte decan;
    private String direction;
    private String element;
    private String angle;
    private String dignity;
    private String objectID;
    private String chartID;
    private String chartNB;
    
    /** Creates new Star */
    public Position()
    {
        objName = "";
        helioLatitude = 0.0;
        helioLongitude = 0.0;
        helioLongitudeSider = 0.0;
        helioDistance = 0.0;
        geoLatitude = 0.0;
        geoLongitude = 0.0;
        geoLongitudeSider = 0.0;
        geoDistance = 0.0;
        rightAscension = 0.0;
        declination = 0.0;
        azimuth = 0.0;
        altitude = 0.0;
        angleWithSun = 0.0;
        angleWithMoon = 0.0;
        angleWithMercury = 0.0;
        angleWithVenus = 0.0;
        angleWithMars = 0.0;
        angleWithJupiter = 0.0;
        angleWithSaturn = 0.0;
        angleWithUranus = 0.0;
        angleWithNeptune = 0.0;
        angleWithPluto = 0.0;
        angleWithEarth = 0.0;
        angleWithNorthNode = 0.0;
        angleWithLilith = 0.0;
        angleWithEast = 0.0;
        angleWithZenith = 0.0;
        angleWithVertex = 0.0;
        angleWithVulcan = 0.0;
        angleWithOtherPoint = 0.0;
        angleWithCeres = 0.0;
        angleWithPallas = 0.0;
        angleWithJuno = 0.0;
        angleWithVesta = 0.0;
        angleWithChiron = 0.0;
        angleWithAscendant = 0.0;
        angleWithMidheaven = 0.0;
        sign = "";
        zodConstel = "";
        constellation = "";
        house = "";
        decan = 0;
        direction = "";
        element = "";
        angle = "";
        dignity = "";
        objectID = "-1";
        chartID = "-1";
        objectID = "-1";
    }
    
    public String getObjName()
    {
        return objName;
    }
    public double getHelioLatitude()
    {
        return helioLatitude;
    }
    public double getHelioLongitude()
    {
        return helioLongitude;
    }
    public double getHelioLongitudeSider()
    {
        return helioLongitudeSider;
    }
    public double getHelioDistance()
    {
        return helioDistance;
    }
    public double getGeoLatitude()
    {
        return geoLatitude;
    }
    public double getGeoLongitude()
    {
        return geoLongitude;
    }
    public double getGeoLongitudeSider()
    {
        return geoLongitudeSider;
    }
    public double getGeoDistance()
    {
        return geoDistance;
    }
    public double getRightAscension()
    {
        return rightAscension;
    }
    public double getDeclination()
    {
        return declination;
    }
    public double getAzimuth()
    {
        return azimuth;
    }
    public double getAltitude()
    {
        return altitude;
    }
    public double getAngleWithSun()
    {
        return angleWithSun;
    }
    public double getAngleWithMoon()
    {
        return angleWithMoon;
    }
    public double getAngleWithMercury()
    {
        return angleWithMercury;
    }
    public double getAngleWithVenus()
    {
        return angleWithVenus;
    }
    public double getAngleWithMars()
    {
        return angleWithMars;
    }
    public double getAngleWithJupiter()
    {
        return angleWithJupiter;
    }
    public double getAngleWithSaturn()
    {
        return angleWithSaturn;
    }
    public double getAngleWithUranus()
    {
        return angleWithUranus;
    }
    public double getAngleWithNeptune()
    {
        return angleWithNeptune;
    }
    public double getAngleWithPluto()
    {
        return angleWithPluto;
    }
    public double getAngleWithEarth()
    {
        return angleWithEarth;
    }
    public double getAngleWithNorthNode()
    {
        return angleWithNorthNode;
    }
    public double getAngleWithLilith()
    {
        return angleWithLilith;
    }
    public double getAngleWithEast()
    {
        return angleWithEast;
    }
    public double getAngleWithZenith()
    {
        return angleWithZenith;
    }
    public double getAngleWithVertex()
    {
        return angleWithVertex;
    }
    public double getAngleWithVulcan()
    {
        return angleWithVulcan;
    }
    public double getAngleWithOtherPoint()
    {
        return angleWithOtherPoint;
    }
    public double getAngleWithCeres()
    {
        return angleWithCeres;
    }
    public double getAngleWithPallas()
    {
        return angleWithPallas;
    }
    public double getAngleWithJuno()
    {
        return angleWithJuno;
    }
    public double getAngleWithVesta()
    {
        return angleWithVesta;
    }
    public double getAngleWithChiron()
    {
        return angleWithChiron;
    }
    public double getAngleWithAscendant()
    {
        return angleWithAscendant;
    }
    public double getAngleWithMidheaven()
    {
        return angleWithMidheaven;
    }
    public String getSign()
    {
        return sign;
    }
    public String getZodConstel()
    {
        return zodConstel;
    }
    public String getConstellation()
    {
        return constellation;
    }
    public String getHouse()
    {
        return house;
    }
    public byte getDecan()
    {
        return decan;
    }
    public String getDirection()
    {
        return direction;
    }
    public String getElement()
    {
        return element;
    }
    public String getAngle()
    {
        return angle;
    }
    public String getDignity()
    {
        return dignity;
    }
    public String getObjectID()
    {
        return objectID;
    }
    public String getChartID()
    {
        return chartID;
    }
    public String getChartNB()
    {
        return chartNB;
    }
    
    public void setObjName(String data)
    {
        objName = data;
    }
    public void setHelioLatitude(double data)
    {
        helioLatitude = data;
    }
    public void setHelioLongitude(double data)
    {
        helioLongitude = data;
    }
    public void setHelioLongitudeSider(double data)
    {
        helioLongitudeSider = data;
    }
    public void setHelioDistance(double data)
    {
        helioDistance = data;
    }
    public void setGeoLatitude(double data)
    {
        geoLatitude = data;
    }
    public void setGeoLongitude(double data)
    {
        geoLongitude = data;
    }
    public void setGeoLongitudeSider(double data)
    {
        geoLongitudeSider = data;
    }
    public void setGeoDistance(double data)
    {
        geoDistance = data;
    }
    public void setRightAscension(double data)
    {
        rightAscension = data;
    }
    public void setDeclination(double data)
    {
        declination = data;
    }
    public void setAzimuth(double data)
    {
        azimuth = data;
    }
    public void setAltitude(double data)
    {
        altitude = data;
    }
    public void setAngleWithSun(double data)
    {
        angleWithSun = data;
    }
    public void setAngleWithMoon(double data)
    {
        angleWithMoon = data;
    }
    public void setAngleWithMercury(double data)
    {
        angleWithMercury = data;
    }
    public void setAngleWithVenus(double data)
    {
        angleWithVenus = data;
    }
    public void setAngleWithMars(double data)
    {
        angleWithMars = data;
    }
    public void setAngleWithJupiter(double data)
    {
        angleWithJupiter = data;
    }
    public void setAngleWithSaturn(double data)
    {
        angleWithSaturn = data;
    }
    public void setAngleWithUranus(double data)
    {
        angleWithUranus = data;
    }
    public void setAngleWithNeptune(double data)
    {
        angleWithNeptune = data;
    }
    public void setAngleWithPluto(double data)
    {
        angleWithPluto = data;
    }
    public void setAngleWithEarth(double data)
    {
        angleWithEarth = data;
    }
    public void setAngleWithNorthNode(double data)
    {
        angleWithNorthNode = data;
    }
    public void setAngleWithLilith(double data)
    {
        angleWithLilith = data;
    }
    public void setAngleWithEast(double data)
    {
        angleWithEast = data;
    }
    public void setAngleWithZenith(double data)
    {
        angleWithZenith = data;
    }
    public void setAngleWithVertex(double data)
    {
        angleWithVertex = data;
    }
    public void setAngleWithVulcan(double data)
    {
        angleWithVulcan = data;
    }
    public void setAngleWithOtherPoint(double data)
    {
        angleWithOtherPoint = data;
    }
    public void setAngleWithCeres(double data)
    {
        angleWithCeres = data;
    }
    public void setAngleWithPallas(double data)
    {
        angleWithPallas = data;
    }
    public void setAngleWithJuno(double data)
    {
        angleWithJuno = data;
    }
    public void setAngleWithVesta(double data)
    {
        angleWithVesta = data;
    }
    public void setAngleWithChiron(double data)
    {
        angleWithChiron = data;
    }
    public void setAngleWithAscendant(double data)
    {
        angleWithAscendant = data;
    }
    public void setAngleWithMidheaven(double data)
    {
        angleWithMidheaven = data;
    }
    public void setSign(String data)
    {
        sign = data;
    }
    public void setZodConstel(String data)
    {
        zodConstel = data;
    }
    public void setConstellation(String data)
    {
        constellation = data;
    }
    public void setHouse(String data)
    {
        house = data;
    }
    public void setDecan(byte data)
    {
        decan = data;
    }
    public void setDirection(String data)
    {
        direction = data;
    }
    public void setElement(String data)
    {
        element = data;
    }
    public void setAngle(String data)
    {
        angle = data;
    }
    public void setDignity(String data)
    {
        dignity = data;
    }
    public void setObjectID(String data)
    {
        objectID = data;
    }
    public void setChartID(String data)
    {
        chartID = data;
    }
    public void setChartNB(String data)
    {
        chartNB = data;
    }
    
}
