package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Part extends Record
{
    private String part;
    private byte ref;
    private byte plus;
    private byte minus;
    private String comments;
    
    /** Creates new Part */
    public Part()
    {
        part = "";
        ref = StarLogin.Systeme.Enum.Planets.AS;
        plus = StarLogin.Systeme.Enum.Planets.AS;
        minus = StarLogin.Systeme.Enum.Planets.AS;
        comments = "";
    }
    
    public byte getPlus()
    {
        return plus;
    }
    
    public void setPlus(byte data)
    {
        plus = data;
    }
    
    public byte getRef()
    {
        return ref;
    }
    
    public void setRef(byte data)
    {
        ref = data;
    }
    
    public String getPart()
    {
        return part;
    }
    
    public void setPart(String sData)
    {
        part = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
    
    public byte getMinus()
    {
        return minus;
    }
    
    public void setMinus(byte data)
    {
        minus = data;
    }
}
