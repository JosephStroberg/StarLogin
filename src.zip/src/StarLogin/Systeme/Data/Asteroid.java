package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import javax.swing.ImageIcon;

public class Asteroid extends Record
{
    private String asteroidName;
    private int asteroidNumber;
    private double hMagnitude;
    private double meanAnomaly;
    private double eccentricity;
    private double perihelionLongitude;
    private double northNodeLongitude;
    private double inclination;
    private double semiMajorAxis;
    private double dailyMotion;
    private double epoch;
    private String comments;
    private ImageIcon picture;
    
    /** Creates new Asteroid */
    public Asteroid()
    {
        asteroidName = "";
        asteroidNumber = 0;
        hMagnitude = 0.0;
        meanAnomaly = 0.0;
        eccentricity = 0.0;
        perihelionLongitude = 0.0;
        northNodeLongitude = 0.0;
        inclination = 0.0;
        semiMajorAxis = 0.0;
        dailyMotion = 0.0;
        epoch = 0.0;
        comments = "";
        picture = null;
    }
    
    public int getAsteroidNumber()
    {
        return asteroidNumber;
    }
    
    public void setAsteroidNumber(int data)
    {
        asteroidNumber = data;
    }
    
    public double getHMagnitude()
    {
        return hMagnitude;
    }
    
    public void setHMagnitude(double data)
    {
        hMagnitude = data;
    }
    
    public double getMeanAnomaly()
    {
        return meanAnomaly;
    }
    
    public void setMeanAnomaly(double data)
    {
        meanAnomaly = data;
    }
    
    public double getEccentricity()
    {
        return eccentricity;
    }
    
    public void setEccentricity(double data)
    {
        eccentricity = data;
    }
    
    public double getPerihelionLongitude()
    {
        return perihelionLongitude;
    }
    
    public void setPerihelionLongitude(double data)
    {
        perihelionLongitude = data;
    }
    
    public double getNorthNodeLongitude()
    {
        return northNodeLongitude;
    }
    
    public void setNorthNodeLongitude(double data)
    {
        northNodeLongitude = data;
    }
    
    public double getInclination()
    {
        return inclination;
    }
    
    public void setInclination(double data)
    {
        inclination = data;
    }
    
    public double getSemiMajorAxis()
    {
        return semiMajorAxis;
    }
    
    public void setSemiMajorAxis(double data)
    {
        semiMajorAxis = data;
    }
    
    public double getDailyMotion()
    {
        return dailyMotion;
    }
    
    public void setDailyMotion(double data)
    {
        dailyMotion = data;
    }
    
    public double getEpoch()
    {
        return epoch;
    }
    
    public void setEpoch(double data)
    {
        epoch = data;
    }
    
    public String getAsteroidName()
    {
        return asteroidName;
    }
    
    public void setAsteroidName(String sData)
    {
        asteroidName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
