/*
 * Chart.java
 *
 * Created on 30 juin 2003, 08:33
 */

package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import javax.swing.ImageIcon;

public class Chart extends Record
{
    private int eventID;
    private byte chartType;
    private byte coordinatesSystem;
    private byte housesSystem;
    private byte otherPointType;
    private String otherPointName;
    private String header;
    private String title;
    private String configurations;
    private String comments;
    private ImageIcon picture;
    
    /** Creates new Chart */
    public Chart()
    {
        eventID = -1;
        chartType = 0;
        coordinatesSystem = 0;
        housesSystem = 0;
        otherPointType = 0;
        otherPointName = "";
        header = "";
        title = "";
        configurations = "";
        comments = "";
        picture = null;
    }
    
    public int getEventID()
    {
        return eventID;
    }
    
    public void setEventID(int data)
    {
        eventID = data;
    }
    
    public byte getChartType()
    {
        return chartType;
    }
    
    public void setChartType(byte sData)
    {
        chartType = sData;
    }
    
    public byte getCoordinatesSystem()
    {
        return coordinatesSystem;
    }
    
    public void setCoordinatesSystem(byte sData)
    {
        coordinatesSystem = sData;
    }
    
    public byte getHousesSystem()
    {
        return housesSystem;
    }
    
    public void setHousesSystem(byte sData)
    {
        housesSystem = sData;
    }
    
    public byte getOtherPointType()
    {
        return otherPointType;
    }
    
    public void setOtherPointType(byte sData)
    {
        otherPointType = sData;
    }
    
    public String getConfigurations()
    {
        return configurations;
    }
    
    public void setConfigurations(String sData)
    {
        configurations = sData;
    }
    
    public String getHeader()
    {
        return header;
    }
    
    public void setHeader(String sData)
    {
        header = sData;
    }
    
    public String getTitle()
    {
        return title;
    }
    
    public void setTitle(String sData)
    {
        title = sData;
    }
    
    public String getOtherPointName()
    {
        return otherPointName;
    }
    
    public void setOtherPointName(String sData)
    {
        otherPointName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }

    public ImageIcon getPicture()
    {
        return picture;
    }

    public void setPicture(ImageIcon data)
    {
        picture = data;
    }
}
