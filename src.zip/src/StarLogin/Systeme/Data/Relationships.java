package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Relationships implements java.io.Serializable
{
    private String meaning;
    private double value;
    private byte id1;
    private byte id2;
    
    /** Creates new Relationships */
    public Relationships()
    {
        id2 = -1;
        id1 = -1;
        meaning = "";
        value = 0.0;
    }

    public byte getPlanet2ID()
    {
        return id2;
    }

    public void setPlanet2ID(byte data)
    {
        id2 = data;
    }

    public byte getPlanet1ID()
    {
        return id1;
    }

    public void setPlanet1ID(byte data)
    {
        id1 = data;
    }

    public double getValue()
    {
        return value;
    }

    public void setValue(double data)
    {
        value = data;
    }

    public String getMeaning()
    {
        return meaning;
    }

    public void setMeaning(String sData)
    {
        meaning = sData;
    }
}
