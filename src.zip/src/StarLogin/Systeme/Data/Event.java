/*
 * Event.java
 *
 * Created on 27 avril 2003, 08:01
 */

package StarLogin.Systeme.Data;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.*;
import javax.swing.ImageIcon;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Event extends Record
{
    private String surname;
    private String otherNames;
    private String entityType;
    private String eventName;
    private String localDate;
    private String utDate;
    private String localTime;
    private String utTime;
    private String timeLag;
    private String place;
    private String latitude;
    private String longitude;
    private String comments;
    private String sign;
    private String ascendant;
    private ImageIcon picture;
    private String country;
    private String region;
    private double placeLong;
    private double placeLat;
    
    /** Creates new Event */
    public Event()
    {
        surname = "";
        otherNames = "";
        entityType = "";
        eventName = "";
        localDate = "";
        utDate = "";
        localTime = "";
        utTime = "";
        timeLag = "";
        place = "";
        latitude = "";
        longitude = "";
        comments = "";
        sign = "";
        ascendant = "";
        picture = null;
        placeLong = 0.0;
        placeLat = 0.0;
    }
    
    public Event cloneEvent(Event ev)
    {
        Event ev2 = new Event();
        ev2.setId(ev.getId());
        ev2.setSurname(ev.getSurname());
        ev2.setOtherNames(ev.getOtherNames());
        ev2.setEntityType(ev.getEntityType());
        ev2.setEventName(ev.getEventName());
        ev2.setLocalDate(ev.getLocalDate());
        ev2.setUtDate(ev.getUtDate());
        ev2.setLocalTime(ev.getLocalTime());
        ev2.setUtTime(ev.getUtTime());
        ev2.setTimeLag(ev.getTimeLag());
        ev2.setPlace(ev.getPlace());
        /*String lati = ev.getLatitude();
        FLatitude l = new FLatitude(lati);
        lati = l.getLatitude();
        ev2.setLatitude(lati);*/
        ev2.setLatitude(ev.getLatitude());
        /*String longi = ev.getLongitude();
        FLongitude lo = new FLongitude(longi);
        longi = lo.getLongitude();
        ev2.setLongitude(longi);*/
        ev2.setLongitude(ev.getLongitude());
        ev2.setComments(ev.getComments());
        ev2.setSign(ev.getSign());
        ev2.setAscendant(ev.getAscendant());
        ev2.setPicture(ev.getPicture());
        ev2.setAdding(ev.getAdding());
        return ev2;
    }
    
    public String getSurname()
    {
        return surname;
    }
    
    public void setSurname(String sData)
    {
        surname = sData;
    }
    
    public String getOtherNames()
    {
        return otherNames;
    }
    
    public void setOtherNames(String sData)
    {
        otherNames = sData;
    }
    
    public String getEntityType()
    {
        return entityType;
    }
    
    public void setEntityType(String sData)
    {
        entityType = sData;
    }
    
    public String getEventName()
    {
        return eventName;
    }
    
    public void setEventName(String sData)
    {
        eventName = sData;
    }
    
    public String getLocalDate()
    {
        return localDate;
    }
    
    public void setLocalDate(String sData)
    {
        localDate = MainClass.getFormatedDate(sData);
    }
    
    public String getUtDate()
    {
        return utDate;
    }
    
    public void setUtDate(String sData)
    {
        utDate = MainClass.getFormatedDate(sData);
    }
    
    public String getLocalTime()
    {
        return localTime;
    }
    
    public void setLocalTime(String sData)
    {
        FTime t = new FTime(sData);
        localTime = t.getTime();
    }
    
    public String getUtTime()
    {
        return utTime;
    }
    
    public void setUtTime(String sData)
    {
        FTime t = new FTime(sData);
        utTime = t.getTime();
    }
    
    public String getTimeLag()
    {
        return timeLag;
    }
    
    public void setTimeLag(String sData)
    {
        timeLag = sData;
    }
    
    public String getPlace()
    {
        return place;
    }
    
    public void setPlace(String sData)
    {
        place = sData;
        country = getCountryName(place);
        region = place.substring(0, java.lang.Math.max(place.length()-country.length()-2,1)-1);
    }
    
    public String getLatitude()
    {
        return latitude;
    }
    
    public double getPlaceLat()
    {
        return placeLat;
    }
    
    public double getPlaceLong()
    {
        return placeLong;
    }
    
    public void setLatitude(String sData)
    {
        FLatitude l = new FLatitude(sData);
        latitude = l.getLatitude();
        placeLat = new FLatitude(sData).getDecimalDegree();
    }
    
    public String getLongitude()
    {
        return longitude;
    }
    
    public void setLongitude(String sData)
    {
        FLongitude l = new FLongitude(sData);
        longitude = l.getLongitude();
        placeLong = new FLongitude(sData).getDecimalDegree();
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
    
    public String getSign()
    {
        return sign;
    }
    
    public void setSign(String sData)
    {
        sign = sData;
    }
    
    public String getAscendant()
    {
        return ascendant;
    }
    
    public void setAscendant(String sData)
    {
        ascendant = sData;
    }
    
    //=====================================================================
    //Calculation of the UT hour from the local one
    //input : appel : number of the utTimeCalculation call in Valider_Click
    //=====================================================================
    public void utTimeCalculation(byte appel)
    {
        //numerical value of the Local time
        FTime ft = new FTime(localTime);
        double heure = ft.getDecimalHour();
        
        //day, month and year
        FDate fd = new FDate(localDate);
        long jour = fd.getDay();
        long mois = fd.getMonth();
        long annee = fd.getYear();
        
        //estimated time-lag from the longitude of the place
        double dblTimeLag = placeLong / 15.0;
        DateTimeEvent dt = new DateTimeEvent(this);
        TZRules tzRules = new TZRules(dt);
        tzRules.setTimeLag(dblTimeLag);
        dblTimeLag = tzRules.calculateTimeLag(TZRules.LOCAL2UT, appel, dblTimeLag);
        timeLag = String.valueOf(java.lang.Math.round(dblTimeLag * 10000) / 10000.0);
        
        //UT hour in a string
        if ( (dblTimeLag + heure) < 0.0 )
        {
            //minus one day
            utDate = addDate(localDate, -1);
        }
        else
        {
            if ( (dblTimeLag + heure) > 24.0 )
            {
                //plus one day
                utDate = addDate(localDate, 1);
            }
            else
            {
                utDate = localDate;
            }
        }
        heure = AstronomyMaths.mod(dblTimeLag + heure, 24.0);
        FTime utT = new FTime(heure);
        utTime = utT.getTime();
    }
    
    //=====================================================================
    //Calculation of the local hour from the UT hour
    //input : number of localTimeCalculation calls in CalculDecalagePays
    //=====================================================================
    public void localTimeCalculation(byte appel)
    {
        FTime ft = new FTime(utTime);
        double heure = ft.getDecimalHour();
        DateTimeEvent dt = new DateTimeEvent(this);
        TZRules tzRules = new TZRules(dt);
        double dblTimeLag;
        
        //estimated time-lag from the longitude of the place
        dblTimeLag = placeLong / 15.0;
        if ( appel != TZRules.SecondTime )
        {
            tzRules.setTimeLag(dblTimeLag);
        }
        
        dblTimeLag = tzRules.calculateTimeLag(TZRules.UT2LOCAL, appel, dblTimeLag);
        timeLag = String.valueOf(((double)java.lang.Math.round(dblTimeLag * 10000)) / 10000);
        
        //local time in a string
        if ( (heure - dblTimeLag) < 0 )
        {
            //minus one day
            localDate = addDate(utDate, -1);
        }
        else
        {
            if ( (dblTimeLag + heure) > 24 )
            {
                //plus one day
                localDate = addDate(utDate, 1);
            }
            else
            {
                localDate = utDate;
            }
        }
        heure = AstronomyMaths.mod(-dblTimeLag + heure, 24.0);
        FTime localT = new FTime(heure);
        localTime = localT.getTime();
    }
    
    public String getCountry()
    {
        return country;
    }
    
    public String getRegion()
    {
        return region;
    }
    
    //=========================================================================
    //add or subtract days to or from a Gregorian date
    //input : date_entree : Gregorian date in a string "DD/MM/YYYY"
    //        plus_moins  : number of days to add or to subtract
    //return              : modified Gregorian date
    //=========================================================================
    public String addDate(String date, long delta)
    {
        long jour;
        long mois;
        long annee;
        double jj;
        FDate dt = new FDate(date);
        jour = dt.getDay();
        mois = dt.getMonth();
        annee = dt.getYear();
        jj = AstronomyMaths.gregorianToJulian(jour, mois, annee);
        return dt.formatDate(AstronomyMaths.julianToGregorian(jj + delta));
    }
    
    //=====================================================================
    //Getting the name of the country in brackets (the most internal or the Rightest brackets)
    //from the whole name of the place
    //input : place : whole name of the place (with the country name in brackets)
    //return           : name of the country
    //=====================================================================
    private String getCountryName(String place)
    {
        if ((place ==  null) || place.equals("")) return "";
        
        int position1;
        int position2;
        int position3;
        
        position1 = place.indexOf('(');
        
        if (position1 >= 0)
        {
            position2 = place.indexOf('(', position1+1);
            position3 = place.indexOf(')');
            
            if (position3 < 0)
            {
                place = place.substring(position1+1);
            }
            else
            {
                if (position3 > position2)
                {
                    place = place.substring(0, position3);
                    if (position2 < 0)
                    {
                        place = place.substring(position1+1);
                    }
                    else
                    {
                        place = place.substring(position2+1);
                    }
                }
                else
                {
                    place = place.substring(position2+1);
                    position3 = place.indexOf(')');
                    if (position3 >= 0)
                    {
                        place = place.substring(0, position3);
                    }
                }
            }
        }
        return place;
    }
}