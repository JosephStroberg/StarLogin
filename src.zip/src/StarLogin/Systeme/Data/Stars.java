package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Stars extends Records {

    /** Creates new Stars */
    public Stars() {}
}