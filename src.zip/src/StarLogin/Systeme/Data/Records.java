package StarLogin.Systeme.Data;

import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 */
public class Records implements java.io.Serializable
{

    private ArrayList rows = new ArrayList();
    private ArrayList fields = new ArrayList();
    private ArrayList columnNames = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList sizes = new ArrayList();
    private String from = "";
    private String where = "";
    private ArrayList fieldsVal = new ArrayList();


    public ArrayList fieldsValues()
    {
        return fieldsVal;
    }


    /** Creates new Clients */
    public Records()
    {
    }

    public String getFrom()
    {
        return from;
    }

    public void setFrom(String data)
    {
        from = data;
    }

    public String getWhere()
    {
        return where;
    }

    public void setWhere(String data)
    {
        where = data;
    }

    public ArrayList getTypes()
    {
        return types;
    }

    public ArrayList getSizes()
    {
        return sizes;
    }

    public ArrayList getHeaders()
    {
        return columnNames;
    }

    public ArrayList getFields()
    {
        return fields;
    }

    public ArrayList getRecords()
    {
        return rows;
    }

    public String getIDFromRow(int row)
    {
        if (row <= 0)
        {
            return "-1";
        }

        ArrayList v;
        String strID = "-1";
        if (row - 1 < rows.size())
        {
            v = (ArrayList) rows.get(row - 1);
            strID = String.valueOf(v.get(0));
        }
        if (strID.equals(""))
            strID = "-1";

        return strID;
    }

    public int getRowFromID(String id)
    {
        if (id == null|| id.equals("-1"))
        {
            return -1;
        }
        int r = -1;
        ArrayList v;
        String strID;

        for (int i = 0; i < rows.size(); i++)
        {
            v = (ArrayList) rows.get(i);
            strID = String.valueOf(v.get(0));
            if (strID.equals(id))
            {
                return i+1;
            }
        }
        return r;
    }
}