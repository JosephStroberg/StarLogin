package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Parts extends Records {

    /** Creates new Asteroids */
    public Parts() {}
}