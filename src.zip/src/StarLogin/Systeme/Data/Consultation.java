package StarLogin.Systeme.Data;

import javax.swing.ImageIcon;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Consultation extends Record
{
    private String clientName;
    private String services;
    private String fee;
    private String comments;
    private ImageIcon picture;
    private String consultationDate;
    private String consultationTime;
    private String location;
    private boolean done;
    private String due;
    private boolean payed;
    private int clientID;
    
    /** Creates new Consultation */
    public Consultation()
    {
        clientName = "";
        services = "";
        fee = "";
        comments = "";
        picture = null;
    }
    
    public int getClientID()
    {
        return clientID;
    }
    
    public void setClientID(int data)
    {
        clientID = data;
    }
    
    public boolean getDone()
    {
        return done;
    }
    
    public void setDone(boolean b)
    {
        done = b;
    }
    
    public boolean getPayed()
    {
        return payed;
    }
    
    public void setPayed(boolean b)
    {
        payed = b;
    }
    
    public String getFee()
    {
        return fee;
    }
    
    public void setFee(String sData)
    {
        fee = sData;
    }
    
    public String getConsultationDate()
    {
        return consultationDate;
    }
    
    public void setConsultationDate(String sData)
    {
        consultationDate = sData;
    }
    
    public String getConsultationTime()
    {
        return consultationTime;
    }
    
    public void setConsultationTime(String sData)
    {
        consultationTime = sData;
    }
    
    public String getLocation()
    {
        return location;
    }
    
    public void setLocation(String sData)
    {
        location = sData;
    }
    
    public String getDue()
    {
        return due;
    }
    
    public void setDue(String sData)
    {
        due = sData;
    }
    
    public String getServices()
    {
        return services;
    }
    
    public void setServices(String sData)
    {
        services = sData;
    }
    
    public String getClientName()
    {
        return clientName;
    }
    
    public void setClientName(String sData)
    {
        clientName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
