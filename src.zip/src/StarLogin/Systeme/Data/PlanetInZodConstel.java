package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class PlanetInZodConstel implements java.io.Serializable
{
    private String meaning;
    private double value;
    private byte zodConstelID;
    private byte planetID;
    
    /** Creates new PlanetInZodConstel */
    public PlanetInZodConstel()
    {
        planetID = -1;
        zodConstelID = -1;
        meaning = "";
        value = 0.0;
    }
    
    public byte getPlanetID()
    {
        return planetID;
    }
    
    public void setPlanetID(byte data)
    {
        planetID = data;
    }
    
    public byte getZodConstelID()
    {
        return zodConstelID;
    }
    
    public void setZodConstelID(byte data)
    {
        zodConstelID = data;
    }
    
    public double getValue()
    {
        return value;
    }
    
    public void setValue(double data)
    {
        value = data;
    }
    
    public String getMeaning()
    {
        return meaning;
    }
    
    public void setMeaning(String sData)
    {
        meaning = sData;
    }
}
