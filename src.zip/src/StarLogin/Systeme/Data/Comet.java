package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import javax.swing.ImageIcon;

public class Comet extends Record
{
    private String cometName;
    private int cometNumber;
    private String perihelionDate;
    private double perihelionUA;
    private double eccentricity;
    private double perihelionLongitude;
    private double northNodeLongitude;
    private double inclination;
    private double semiMajorAxis;
    private double period;
    private double epoch;
    private String comments;
    private ImageIcon picture;
    
    /** Creates new Comet */
    public Comet()
    {
        cometName = "";
        cometNumber = 0;
        perihelionDate = "2000-1-1.0";
        perihelionUA = 0.0;
        eccentricity = 0.0;
        perihelionLongitude = 0.0;
        northNodeLongitude = 0.0;
        inclination = 0.0;
        semiMajorAxis = 0.0;
        period = 0.0;
        epoch = 0.0;
        comments = "";
        picture = null;
    }
    
    public int getCometNumber()
    {
        return cometNumber;
    }
    
    public void setCometNumber(int data)
    {
        cometNumber = data;
    }
    
    public String getPerihelionDate()
    {
        return perihelionDate;
    }
    
    public void setPerihelionDate(String sData)
    {
        perihelionDate = sData;
    }
    
    public double getPerihelionUA()
    {
        return perihelionUA;
    }
    
    public void setPerihelionUA(double data)
    {
        perihelionUA = data;
    }
    
    public double getEccentricity()
    {
        return eccentricity;
    }
    
    public void setEccentricity(double data)
    {
        eccentricity = data;
    }
    
    public double getPerihelionLongitude()
    {
        return perihelionLongitude;
    }
    
    public void setPerihelionLongitude(double data)
    {
        perihelionLongitude = data;
    }
    
    public double getNorthNodeLongitude()
    {
        return northNodeLongitude;
    }
    
    public void setNorthNodeLongitude(double data)
    {
        northNodeLongitude = data;
    }
    
    public double getInclination()
    {
        return inclination;
    }
    
    public void setInclination(double data)
    {
        inclination = data;
    }
    
    public double getSemiMajorAxis()
    {
        return semiMajorAxis;
    }
    
    public void setSemiMajorAxis(double data)
    {
        semiMajorAxis = data;
    }
    
    public double getPeriod()
    {
        return period;
    }
    
    public void setPeriod(double data)
    {
        period = data;
    }
    
    public double getEpoch()
    {
        return epoch;
    }
    
    public void setEpoch(double data)
    {
        epoch = data;
    }
    
    public String getCometName()
    {
        return cometName;
    }
    
    public void setCometName(String sData)
    {
        cometName = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
