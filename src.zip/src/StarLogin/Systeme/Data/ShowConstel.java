package StarLogin.Systeme.Data;

import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ShowConstel implements java.io.Serializable {

    private ArrayList rows = new ArrayList(); 
    
    /** Creates new ShowConstel */
    public ShowConstel()
    {
    }
    
    public ArrayList getShowConstel()
    {
        return rows;
    }
}
