package StarLogin.Systeme.Data;

import javax.swing.ImageIcon;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Star extends Record
{
    private int hr;
    private String starName;
    private String identity;
    private double ra;
    private double d;
    private double properMotionRA;
    private double properMotionD;
    private double magnitude;
    private double radialVelocity;
    private double distance;
    private double distError;
    private String light;
    private String comments;
    private ImageIcon picture;
    
    /** Creates new Star */
    public Star()
    {
        starName = "";
        comments = "";
        picture = null;
        identity = "";
        ra = 0.0;
        d = 0.0;
        properMotionRA = 0.0;
        properMotionD = 0.0;
        magnitude = 0.0;
        radialVelocity = 0.0;
        distance = 0.0;
        distError = 0.0;
        light = "";
    }
    
    public double getRA()
    {
        return ra;
    }
    
    public void setRA(double data)
    {
        ra = data;
    }
    
    public double getD()
    {
        return d;
    }
    
    public void setD(double data)
    {
        d = data;
    }
    
    public double getProperMotionRA()
    {
        return properMotionRA;
    }
    
    public void setProperMotionRA(double data)
    {
        properMotionRA = data;
    }
    
    public double getProperMotionD()
    {
        return properMotionD;
    }
    
    public void setProperMotionD(double data)
    {
        properMotionD = data;
    }
    
    public double getMagnitude()
    {
        return magnitude;
    }
    
    public void setMagnitude(double data)
    {
        magnitude = data;
    }
    
    public double getRadialVelocity()
    {
        return radialVelocity;
    }
    
    public void setRadialVelocity(double data)
    {
        radialVelocity = data;
    }
    
    public double getDistance()
    {
        return distance;
    }
    
    public void setDistance(double data)
    {
        distance = data;
    }
    
    public double getDistError()
    {
        return distError;
    }
    
    public void setDistError(double data)
    {
        distError = data;
    }
    
    public String getLight()
    {
        return light;
    }
    
    public int getHR()
    {
        return hr;
    }
    
    public void setHR(int data)
    {
        hr = data;
    }
    
    public void setLight(String sData)
    {
        light = sData;
    }
    
    public String getStarName()
    {
        return starName;
    }
    
    public void setStarName(String sData)
    {
        starName = sData;
    }
    
    public String getIdentity()
    {
        return identity;
    }
    
    public void setIdentity(String sData)
    {
        identity = sData;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String sData)
    {
        comments = sData;
    }
}
