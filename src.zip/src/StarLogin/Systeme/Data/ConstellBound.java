package StarLogin.Systeme.Data;

import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ConstellBound implements java.io.Serializable {

    private ArrayList rows = new ArrayList(); 
    
    /** Creates new ConstellBound */
    public ConstellBound()
    {
    }
    
    public ArrayList getConstellBound()
    {
        return rows;
    }
}
