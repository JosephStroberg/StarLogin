/*
 * Groups.java
 *
 * Created on 28 avril 2003, 09:06
 */

package StarLogin.Systeme.Data;

import java.util.ArrayList;
import javax.swing.tree.*;

/**
 *
 * @authors  Fran�ois & Christophe DESCHAMPS
 * @version 1.0.0
 */
public class Groups implements java.io.Serializable
{
    //private ArrayList groupsList0;   //ordered by level in the tree, then by name
    private ArrayList groupsList;  //ordered by group name
    private DefaultMutableTreeNode top = new DefaultMutableTreeNode("");
    private DefaultMutableTreeNode topIDs = new DefaultMutableTreeNode(""); //clone of the tree but with IDs, to store the group IDs
    
    /** Creates new Groups */
    public Groups()
    {
    }
    
    public void setGroupsList(ArrayList list)
    {
        groupsList = list;
    }
    
    public ArrayList getGroups()
    {
        return groupsList;
    }
    
    public DefaultMutableTreeNode getTopNode()
    {
        return top;
    }
    
    public DefaultMutableTreeNode getTopIDsNode()
    {
        return topIDs;
    }
    
    public void checkGroupChildren(DefaultMutableTreeNode node, DefaultMutableTreeNode nodeID, String strParentID, String strGroup, String strID)
    {
        for (int j=0;j<node.getChildCount();j++)
        {
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getChildAt(j);
            DefaultMutableTreeNode parentID = (DefaultMutableTreeNode)nodeID.getChildAt(j);
            if (strParentID.equals((String)parentID.getUserObject()))
            {
                DefaultMutableTreeNode child = new DefaultMutableTreeNode(strGroup);
                parent.add(child);
                DefaultMutableTreeNode child2 = new DefaultMutableTreeNode(strID);
                parentID.add(child2);
                break;
            }
            checkGroupChildren(parent, parentID, strParentID, strGroup, strID);
        }
    }
    
    public String getGroupID(String strGroup)
    {
        String strID = "0";
        if (!strGroup.equals(""))
        {
            for (int i=0; i<groupsList.size(); i++)
            {
                ArrayList v = (ArrayList)groupsList.get(i);
                String strGroup2 = String.valueOf(v.get(1));
                if (strGroup.equals(strGroup2))
                {
                    strID = String.valueOf(v.get(0));
                    break;
                }
            }
        }
        return strID;
    }

    @SuppressWarnings("unchecked")
    public ArrayList getGroupChildren(String strGroupID)
    {
        ArrayList groupChildren = new ArrayList();
        for (int i=0; i<groupsList.size(); i++)
        {
            ArrayList v = (ArrayList)groupsList.get(i);
            String strParentID = String.valueOf(v.get(2));
            if (strParentID.equals(strGroupID))
            {
                groupChildren.add(String.valueOf(v.get(0)));
            }
        }
        return groupChildren;
    }
    
    public String getLevel(String strGroupID)
    {
        String strParent=strGroupID;
        int iLevel = 0;
        while (!strParent.equals("0"))
        {
            strParent = getParentID(strParent);
            iLevel += 1;
        }
        return String.valueOf(iLevel);
    }
    
    public String getParentID(String strGroupID)
    {
        String strParentID="0";
        for (int i=0; i<groupsList.size(); i++)
        {
            ArrayList v = (ArrayList)groupsList.get(i);
            String strID = String.valueOf(v.get(0));
            if (strGroupID.equals(strID))
            {
                strParentID = String.valueOf(v.get(2));
                break;
            }
        }
        
        return strParentID;
    }
    
    public int getGroupRow(String strGroupID)
    {
        int index=-1;
        for (int i=0; i<groupsList.size() ; i++)
        {
            ArrayList v = (ArrayList)groupsList.get(i);
            String strID = String.valueOf(v.get(0));
            if (strID.equals(strGroupID))
            {
                index = i;
                break;
            }
        }
        return index;
    }
    
    public String getGroupIDFromRow(int row)
    {
        ArrayList v = (ArrayList)groupsList.get(row);
        String strID = String.valueOf(v.get(0));
        return strID;
    }
    
    
    public boolean isExistingGroupName(String strGroup)
    {
        if (getGroupID(strGroup).equals("0"))
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public String getGroupName(String strID)
    {
        String strGroupName = "";
        if (!strID.equals(""))
        {
            for (int i=0; i<groupsList.size(); i++)
            {
                ArrayList v = (ArrayList)groupsList.get(i);
                String strGroupID = String.valueOf(v.get(0));
                if (strID.equals(strGroupID))
                {
                    strGroupName = String.valueOf(v.get(1));
                    break;
                }
            }
        }
        return strGroupName;
    }
    
    public void removeChildren(String strGroupID)
    {
        ArrayList groupChildren = getGroupChildren(strGroupID);
        for (int i=0; i<groupChildren.size(); i++)
        {
            String strID = (String)groupChildren.get(i);
            removeChildren(strID);
        }
    }

}
