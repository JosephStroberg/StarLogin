package StarLogin.Systeme.Data;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Constellations extends Records {

    /** Creates new Constellations */
    public Constellations() {}
}