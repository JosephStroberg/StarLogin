package StarLogin.Systeme;

import StarLogin.Systeme.Enum.AspectType;
import StarLogin.Systeme.Enum.Planets;
import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartElements
{
    private int chartKind;
    private String chartHeader;
    private String chartReturnPlaceName;
    private String chartCyclePlaceName;
    private String planetaryConfigurations;
    private double chartReturnLatitude;
    private double chartReturnLongitude;
    private double chartCycleLatitude;
    private double chartCycleLongitude;
    private double chartReturnNB;
    private double chartCycleNB;
    private double dirSAge;
    private double dir1Age;
    private double dir2Age;
    private double chartDirSCorresp;
    private double chartDir1Corresp;
    private double chartDir2Corresp;
    private double chartDirSDegree;
    private double chartDir1Degree;
    private double chartDir2Day;
    private int chartDirSSpaceKind;
    private int chartDir1SpaceKind;
    private int chartDir2SpaceKind;
    private String transitsDate;
    private ArrayList chartEvents;
    private int coordSys;
    private int houseSys;
    private byte otherPointType;
    private int chartReturnPlanet;
    private int chartCyclePlanet1;
    private int chartCyclePlanet2;
    private int chartCompositeNB;
    private boolean chartCompositeFromAS;
    private int chartHarmonicNB;
    private String otherPointName;
    private int zodiacSize;
    private int signSize;
    private int planetSize;
    private int characterSize;
    private int typeAspect0;
    private int typeAspect1;
    private int typeAspect2;
    private int typeAspect3;
    private int typeAspect4;
    private int typeAspect5;
    private int typeAspect6;
    private int typeAspect7;
    private int typeAspect8;
    private int typeAspect9;
    private int typeAspect10;
    private int typeAspect11;
    private int typeAspect12;
    private int typeAspect13;
    private int typeAspect14;
    private int typeAspect15;
    private int typeAspect16;
    private int typeAspect17;
    private String otherAspectName;
    private Color sunColor;
    private Color moonColor;
    private Color mercuryColor;
    private Color venusColor;
    private Color marsColor;
    private Color jupiterColor;
    private Color saturnColor;
    private Color uranusColor;
    private Color neptuneColor;
    private Color plutoColor;
    private Color gaiaColor;
    private Color nodesColor;
    private Color cuspsColor;
    private Color asteroidsColor;
    private Color vulcanColor;
    private Color variousColor;
    private Color fireColor;
    private Color earthColor;
    private Color airColor;
    private Color waterColor;
    private Color neutralColor;
    private Color dynamicColor;
    private Color harmonicColor;
    private Color colorAspect0;
    private Color colorAspect1;
    private Color colorAspect2;
    private Color colorAspect3;
    private Color colorAspect4;
    private Color colorAspect5;
    private Color colorAspect6;
    private Color colorAspect7;
    private Color colorAspect8;
    private Color colorAspect9;
    private Color colorAspect10;
    private Color colorAspect11;
    private Color colorAspect12;
    private Color colorAspect13;
    private Color colorAspect14;
    private Color colorAspect15;
    private Color colorAspect16;
    private Color colorAspect17;
    private boolean shownSun;
    private boolean shownMoon;
    private boolean shownMercury;
    private boolean shownVenus;
    private boolean shownMars;
    private boolean shownJupiter;
    private boolean shownSaturn;
    private boolean shownUranus;
    private boolean shownNeptune;
    private boolean shownPluto;
    private boolean shownGaia;
    private boolean shownNorthNode;
    private boolean shownLilith;
    private boolean shownEast;
    private boolean shownZenith;
    private boolean shownVertex;
    private boolean shownVulcan;
    private boolean shownOtherPoint;
    private boolean shownCeres;
    private boolean shownPallas;
    private boolean shownJuno;
    private boolean shownVesta;
    private boolean shownChiron;
    private boolean trueLilith;
    private boolean coloredAspects;
    private boolean housesCoords;
    private boolean signsNames;
    private boolean leftAsct;
    private boolean symbolAspects;
    private boolean viewStars;
    private boolean viewAsteroids;
    private boolean viewCoordinates;
    private boolean viewStraightLines;
    private boolean viewHouses;
    private boolean viewConstellations;
    private boolean viewShadedLines;
    private boolean viewAspects;
    private boolean viewBarycenter;
    private boolean singleWeight;
    private boolean horizon;
    private boolean aspectsSun;
    private boolean aspectsMoon;
    private boolean aspectsMercury;
    private boolean aspectsVenus;
    private boolean aspectsMars;
    private boolean aspectsJupiter;
    private boolean aspectsSaturn;
    private boolean aspectsUranus;
    private boolean aspectsNeptune;
    private boolean aspectsPluto;
    private boolean aspectsGaia;
    private boolean aspectsNorthNode;
    private boolean aspectsLilith;
    private boolean aspectsEast;
    private boolean aspectsZenith;
    private boolean aspectsVertex;
    private boolean aspectsVulcan;
    private boolean aspectsOtherPoint;
    private boolean aspectsCeres;
    private boolean aspectsPallas;
    private boolean aspectsJuno;
    private boolean aspectsVesta;
    private boolean aspectsChiron;
    private boolean aspectsAS;
    private boolean aspectsMC;
    private boolean shownAspect0;
    private boolean shownAspect1;
    private boolean shownAspect2;
    private boolean shownAspect3;
    private boolean shownAspect4;
    private boolean shownAspect5;
    private boolean shownAspect6;
    private boolean shownAspect7;
    private boolean shownAspect8;
    private boolean shownAspect9;
    private boolean shownAspect10;
    private boolean shownAspect11;
    private boolean shownAspect12;
    private boolean shownAspect13;
    private boolean shownAspect14;
    private boolean shownAspect15;
    private boolean shownAspect16;
    private boolean shownAspect17;
    private boolean chartSelectSingle;
    private boolean chartReturnPrecess;
    private double limitMag;
    private double orbLightLight;
    private double orbLightTell;
    private double orbLightOtherInd;
    private double orbLightColl;
    private double orbLightVirtMax;
    private double orbLightVirtMin;
    private double orbTellTell;
    private double orbTellOtherInd;
    private double orbTellColl;
    private double orbTellVirtMax;
    private double orbTellVirtMin;
    private double orbOtherIndOtherInd;
    private double orbOtherIndColl;
    private double orbOtherIndVirtMax;
    private double orbOtherIndVirtMin;
    private double orbCollColl;
    private double orbCollVirtMax;
    private double orbCollVirtMin;
    private double orbVirtMaxVirtMax;
    private double orbVirtMaxVirtMin;
    private double orbVirtMinVirtMin;
    private double divMin;
    private double divConjunction;
    private double divSextile;
    private double divSquare;
    private double divTrine;
    private double divOpposition;
    private double otherAspectValue;
    private ArrayList allCoords;
    private String chartID;
    
    /** Creates new ChartElements */
    public ChartElements()
    {
        chartID = "-1";
        chartKind = 0;
        chartHeader = "";
        chartReturnPlaceName = "";
        chartCyclePlaceName = "";
        planetaryConfigurations = "";
        chartReturnLatitude = 0.0;
        chartReturnLongitude = 0.0;
        chartCycleLatitude = 0.0;
        chartCycleLongitude = 0.0;
        chartReturnNB = 0.0;
        chartCycleNB = 0.0;
        dirSAge = 0.0;
        dir1Age = 0.0;
        dir2Age = 0.0;
        chartDirSCorresp = 0.0;
        chartDir1Corresp = 0.0;
        chartDir2Corresp = 0.0;
        chartDirSDegree = 0.0;
        chartDir1Degree = 0.0;
        chartDir2Day = 0.0;
        chartDirSSpaceKind = 0;
        chartDir1SpaceKind = 0;
        chartDir2SpaceKind = 0;
        transitsDate = "";
        chartEvents = new ArrayList();
        coordSys = 0;
        houseSys = 0;
        otherPointType = 0;
        chartReturnPlanet = 0;
        chartCyclePlanet1 = 0;
        chartCyclePlanet2 = 0;
        chartCompositeNB = 0;
        chartCompositeFromAS = false;
        chartHarmonicNB = 0;
        otherPointName = "";
        zodiacSize = 0;
        signSize = 0;
        planetSize = 0;
        characterSize = 0;
        typeAspect0 = 0;
        typeAspect1 = 0;
        typeAspect2 = 0;
        typeAspect3 = 0;
        typeAspect4 = 0;
        typeAspect5 = 0;
        typeAspect6 = 0;
        typeAspect7 = 0;
        typeAspect8 = 0;
        typeAspect9 = 0;
        typeAspect10 = 0;
        typeAspect11 = 0;
        typeAspect12 = 0;
        typeAspect13 = 0;
        typeAspect14 = 0;
        typeAspect15 = 0;
        typeAspect16 = 0;
        typeAspect17 = 0;
        otherAspectName = "";
        sunColor= Color.BLACK;
        moonColor= Color.BLACK;
        mercuryColor= Color.BLACK;
        venusColor= Color.BLACK;
        marsColor= Color.BLACK;
        jupiterColor= Color.BLACK;
        saturnColor= Color.BLACK;
        uranusColor= Color.BLACK;
        neptuneColor= Color.BLACK;
        plutoColor= Color.BLACK;
        gaiaColor= Color.BLACK;
        nodesColor= Color.BLACK;
        cuspsColor= Color.BLACK;
        asteroidsColor= Color.BLACK;
        vulcanColor= Color.BLACK;
        variousColor= Color.BLACK;
        fireColor= Color.BLACK;
        earthColor= Color.BLACK;
        airColor= Color.BLACK;
        waterColor= Color.BLACK;
        neutralColor= Color.BLACK;
        dynamicColor= Color.BLACK;
        harmonicColor= Color.BLACK;
        colorAspect0= Color.BLACK;
        colorAspect1= Color.BLACK;
        colorAspect2= Color.BLACK;
        colorAspect3= Color.BLACK;
        colorAspect4= Color.BLACK;
        colorAspect5= Color.BLACK;
        colorAspect6= Color.BLACK;
        colorAspect7= Color.BLACK;
        colorAspect8= Color.BLACK;
        colorAspect9= Color.BLACK;
        colorAspect10= Color.BLACK;
        colorAspect11= Color.BLACK;
        colorAspect12= Color.BLACK;
        colorAspect13= Color.BLACK;
        colorAspect14= Color.BLACK;
        colorAspect15= Color.BLACK;
        colorAspect16= Color.BLACK;
        colorAspect17= Color.BLACK;
        shownSun = false;
        shownMoon = false;
        shownMercury = false;
        shownVenus = false;
        shownMars = false;
        shownJupiter = false;
        shownSaturn = false;
        shownUranus = false;
        shownNeptune = false;
        shownPluto = false;
        shownGaia = false;
        shownNorthNode = false;
        shownLilith = false;
        shownEast = false;
        shownZenith = false;
        shownVertex = false;
        shownVulcan = false;
        shownOtherPoint = false;
        shownCeres = false;
        shownPallas = false;
        shownJuno = false;
        shownVesta = false;
        shownChiron = false;
        trueLilith = false;
        coloredAspects = false;
        housesCoords = false;
        signsNames = false;
        leftAsct = false;
        symbolAspects = false;
        viewStars = false;
        viewAsteroids = false;
        viewCoordinates = false;
        viewStraightLines = false;
        viewHouses = false;
        viewConstellations = false;
        viewShadedLines = false;
        viewAspects = false;
        viewBarycenter = false;
        singleWeight = false;
        horizon = false;
        aspectsSun = false;
        aspectsMoon = false;
        aspectsMercury = false;
        aspectsVenus = false;
        aspectsMars = false;
        aspectsJupiter = false;
        aspectsSaturn = false;
        aspectsUranus = false;
        aspectsNeptune = false;
        aspectsPluto = false;
        aspectsGaia = false;
        aspectsNorthNode = false;
        aspectsLilith = false;
        aspectsEast = false;
        aspectsZenith = false;
        aspectsVertex = false;
        aspectsVulcan = false;
        aspectsOtherPoint = false;
        aspectsCeres = false;
        aspectsPallas = false;
        aspectsJuno = false;
        aspectsVesta = false;
        aspectsChiron = false;
        aspectsAS = false;
        aspectsMC = false;
        shownAspect0 = false;
        shownAspect1 = false;
        shownAspect2 = false;
        shownAspect3 = false;
        shownAspect4 = false;
        shownAspect5 = false;
        shownAspect6 = false;
        shownAspect7 = false;
        shownAspect8 = false;
        shownAspect9 = false;
        shownAspect10 = false;
        shownAspect11 = false;
        shownAspect12 = false;
        shownAspect13 = false;
        shownAspect14 = false;
        shownAspect15 = false;
        shownAspect16 = false;
        shownAspect17 = false;
        chartSelectSingle = false;
        chartReturnPrecess = false;
        limitMag = 0.0;
        orbLightLight = 0.0;
        orbLightTell = 0.0;
        orbLightOtherInd = 0.0;
        orbLightColl = 0.0;
        orbLightVirtMax = 0.0;
        orbLightVirtMin = 0.0;
        orbTellTell = 0.0;
        orbTellOtherInd = 0.0;
        orbTellColl = 0.0;
        orbTellVirtMax = 0.0;
        orbTellVirtMin = 0.0;
        orbOtherIndOtherInd = 0.0;
        orbOtherIndColl = 0.0;
        orbOtherIndVirtMax = 0.0;
        orbOtherIndVirtMin = 0.0;
        orbCollColl = 0.0;
        orbCollVirtMax = 0.0;
        orbCollVirtMin = 0.0;
        orbVirtMaxVirtMax = 0.0;
        orbVirtMaxVirtMin = 0.0;
        orbVirtMinVirtMin = 0.0;
        divMin = 0.0;
        divConjunction = 0.0;
        divSextile = 0.0;
        divSquare = 0.0;
        divTrine = 0.0;
        divOpposition = 0.0;
        otherAspectValue = 0.0;
        allCoords = new ArrayList();
    }
    
    public ChartElements cloneInitElements()
    {
        ChartElements chartElements2 = new ChartElements();
        chartElements2.setChartID(chartID);
        chartElements2.setChartKind(chartKind);
        chartElements2.setChartReturnPlaceName(chartReturnPlaceName);
        chartElements2.setChartHeader(chartHeader);
        chartElements2.setChartCyclePlaceName(chartCyclePlaceName);
        chartElements2.setPlanetaryConfigurations(planetaryConfigurations);
        chartElements2.setChartReturnLatitude(chartReturnLatitude);
        chartElements2.setChartReturnLongitude(chartReturnLongitude);
        chartElements2.setChartCycleLatitude(chartCycleLatitude);
        chartElements2.setChartCycleLongitude(chartCycleLongitude);
        chartElements2.setChartReturnNB(chartReturnNB);
        chartElements2.setChartCycleNB(chartCycleNB);
        chartElements2.setDirSAge(dirSAge);
        chartElements2.setDir1Age(dir1Age);
        chartElements2.setDir2Age(dir2Age);
        chartElements2.setChartDirSCorresp(chartDirSCorresp);
        chartElements2.setChartDir1Corresp(chartDir1Corresp);
        chartElements2.setChartDir2Corresp(chartDir2Corresp);
        chartElements2.setChartDirSDegree(chartDirSDegree);
        chartElements2.setChartDir1Degree(chartDir1Degree);
        chartElements2.setChartDir2Day(chartDir2Day);
        chartElements2.setChartDirSSpaceKind(chartDirSSpaceKind);
        chartElements2.setChartDir1SpaceKind(chartDir1SpaceKind);
        chartElements2.setChartDir2SpaceKind(chartDir2SpaceKind);
        chartElements2.setTransitsDate(transitsDate);
        chartElements2.setChartEvents(chartEvents);
        chartElements2.setCoordSys(coordSys);
        chartElements2.setHouseSys(houseSys);
        chartElements2.setOtherPointType(otherPointType);
        chartElements2.setChartReturnPlanet(chartReturnPlanet);
        chartElements2.setChartCyclePlanet1(chartCyclePlanet1);
        chartElements2.setChartCyclePlanet2(chartCyclePlanet2);
        chartElements2.setChartCompositeNB(chartCompositeNB);
        chartElements2.setChartCompositeFromAS(chartCompositeFromAS);
        chartElements2.setChartHarmonicNB(chartHarmonicNB);
        chartElements2.setOtherPointName(otherPointName);
        chartElements2.setZodiacSize(zodiacSize);
        chartElements2.setSignSize(signSize);
        chartElements2.setPlanetSize(planetSize);
        chartElements2.setCharacterSize(characterSize);
        chartElements2.setTypeAspect0(typeAspect0);
        chartElements2.setTypeAspect1(typeAspect1);
        chartElements2.setTypeAspect2(typeAspect2);
        chartElements2.setTypeAspect3(typeAspect3);
        chartElements2.setTypeAspect4(typeAspect4);
        chartElements2.setTypeAspect5(typeAspect5);
        chartElements2.setTypeAspect6(typeAspect6);
        chartElements2.setTypeAspect7(typeAspect7);
        chartElements2.setTypeAspect8(typeAspect8);
        chartElements2.setTypeAspect9(typeAspect9);
        chartElements2.setTypeAspect10(typeAspect10);
        chartElements2.setTypeAspect11(typeAspect11);
        chartElements2.setTypeAspect12(typeAspect12);
        chartElements2.setTypeAspect13(typeAspect13);
        chartElements2.setTypeAspect14(typeAspect14);
        chartElements2.setTypeAspect15(typeAspect15);
        chartElements2.setTypeAspect16(typeAspect16);
        chartElements2.setTypeAspect17(typeAspect17);
        chartElements2.setOtherAspectName(otherAspectName);
        chartElements2.setSunColor(sunColor);
        chartElements2.setMoonColor(moonColor);
        chartElements2.setMercuryColor(mercuryColor);
        chartElements2.setVenusColor(venusColor);
        chartElements2.setMarsColor(marsColor);
        chartElements2.setJupiterColor(jupiterColor);
        chartElements2.setSaturnColor(saturnColor);
        chartElements2.setUranusColor(uranusColor);
        chartElements2.setNeptuneColor(neptuneColor);
        chartElements2.setPlutoColor(plutoColor);
        chartElements2.setGaiaColor(gaiaColor);
        chartElements2.setNodesColor(nodesColor);
        chartElements2.setCuspsColor(cuspsColor);
        chartElements2.setAsteroidsColor(asteroidsColor);
        chartElements2.setVulcanColor(vulcanColor);
        chartElements2.setVariousColor(variousColor);
        chartElements2.setFireColor(fireColor);
        chartElements2.setEarthColor(earthColor);
        chartElements2.setAirColor(airColor);
        chartElements2.setWaterColor(waterColor);
        chartElements2.setNeutralColor(neutralColor);
        chartElements2.setDynamicColor(dynamicColor);
        chartElements2.setHarmonicColor(harmonicColor);
        chartElements2.setColorAspect0(colorAspect0);
        chartElements2.setColorAspect1(colorAspect1);
        chartElements2.setColorAspect2(colorAspect2);
        chartElements2.setColorAspect3(colorAspect3);
        chartElements2.setColorAspect4(colorAspect4);
        chartElements2.setColorAspect5(colorAspect5);
        chartElements2.setColorAspect6(colorAspect6);
        chartElements2.setColorAspect7(colorAspect7);
        chartElements2.setColorAspect8(colorAspect8);
        chartElements2.setColorAspect9(colorAspect9);
        chartElements2.setColorAspect10(colorAspect10);
        chartElements2.setColorAspect11(colorAspect11);
        chartElements2.setColorAspect12(colorAspect12);
        chartElements2.setColorAspect13(colorAspect13);
        chartElements2.setColorAspect14(colorAspect14);
        chartElements2.setColorAspect15(colorAspect15);
        chartElements2.setColorAspect16(colorAspect16);
        chartElements2.setColorAspect17(colorAspect17);
        chartElements2.setShownSun(shownSun);
        chartElements2.setShownMoon(shownMoon);
        chartElements2.setShownMercury(shownMercury);
        chartElements2.setShownVenus(shownVenus);
        chartElements2.setShownMars(shownMars);
        chartElements2.setShownJupiter(shownJupiter);
        chartElements2.setShownSaturn(shownSaturn);
        chartElements2.setShownUranus(shownUranus);
        chartElements2.setShownNeptune(shownNeptune);
        chartElements2.setShownPluto(shownPluto);
        chartElements2.setShownGaia(shownGaia);
        chartElements2.setShownNorthNode(shownNorthNode);
        chartElements2.setShownLilith(shownLilith);
        chartElements2.setShownEast(shownEast);
        chartElements2.setShownZenith(shownZenith);
        chartElements2.setShownVertex(shownVertex);
        chartElements2.setShownVulcan(shownVulcan);
        chartElements2.setShownOtherPoint(shownOtherPoint);
        chartElements2.setShownCeres(shownCeres);
        chartElements2.setShownPallas(shownPallas);
        chartElements2.setShownJuno(shownJuno);
        chartElements2.setShownVesta(shownVesta);
        chartElements2.setShownChiron(shownChiron);
        chartElements2.setTrueLilith(trueLilith);
        chartElements2.setColoredAspects(coloredAspects);
        chartElements2.setHousesCoords(housesCoords);
        chartElements2.setSignsNames(signsNames);
        chartElements2.setLeftAsct(leftAsct);
        chartElements2.setSymbolAspects(symbolAspects);
        chartElements2.setViewStars(viewStars);
        chartElements2.setViewAsteroids(viewAsteroids);
        chartElements2.setViewCoordinates(viewCoordinates);
        chartElements2.setViewStraightLines(viewStraightLines);
        chartElements2.setViewHouses(viewHouses);
        chartElements2.setViewConstellations(viewConstellations);
        chartElements2.setViewShadedLines(viewShadedLines);
        chartElements2.setViewAspects(viewAspects);
        chartElements2.setViewBarycenter(viewBarycenter);
        chartElements2.setSingleWeight(singleWeight);
        chartElements2.setHorizon(horizon);
        chartElements2.setAspectsSun(aspectsSun);
        chartElements2.setAspectsMoon(aspectsMoon);
        chartElements2.setAspectsMercury(aspectsMercury);
        chartElements2.setAspectsVenus(aspectsVenus);
        chartElements2.setAspectsMars(aspectsMars);
        chartElements2.setAspectsJupiter(aspectsJupiter);
        chartElements2.setAspectsSaturn(aspectsSaturn);
        chartElements2.setAspectsUranus(aspectsUranus);
        chartElements2.setAspectsNeptune(aspectsNeptune);
        chartElements2.setAspectsPluto(aspectsPluto);
        chartElements2.setAspectsGaia(aspectsGaia);
        chartElements2.setAspectsNorthNode(aspectsNorthNode);
        chartElements2.setAspectsLilith(aspectsLilith);
        chartElements2.setAspectsEast(aspectsEast);
        chartElements2.setAspectsZenith(aspectsZenith);
        chartElements2.setAspectsVertex(aspectsVertex);
        chartElements2.setAspectsVulcan(aspectsVulcan);
        chartElements2.setAspectsOtherPoint(aspectsOtherPoint);
        chartElements2.setAspectsCeres(aspectsCeres);
        chartElements2.setAspectsPallas(aspectsPallas);
        chartElements2.setAspectsJuno(aspectsJuno);
        chartElements2.setAspectsVesta(aspectsVesta);
        chartElements2.setAspectsChiron(aspectsChiron);
        chartElements2.setAspectsAS(aspectsAS);
        chartElements2.setAspectsMC(aspectsMC);
        chartElements2.setShownAspect0(shownAspect0);
        chartElements2.setShownAspect1(shownAspect1);
        chartElements2.setShownAspect2(shownAspect2);
        chartElements2.setShownAspect3(shownAspect3);
        chartElements2.setShownAspect4(shownAspect4);
        chartElements2.setShownAspect5(shownAspect5);
        chartElements2.setShownAspect6(shownAspect6);
        chartElements2.setShownAspect7(shownAspect7);
        chartElements2.setShownAspect8(shownAspect8);
        chartElements2.setShownAspect9(shownAspect9);
        chartElements2.setShownAspect10(shownAspect10);
        chartElements2.setShownAspect11(shownAspect11);
        chartElements2.setShownAspect12(shownAspect12);
        chartElements2.setShownAspect13(shownAspect13);
        chartElements2.setShownAspect14(shownAspect14);
        chartElements2.setShownAspect15(shownAspect15);
        chartElements2.setShownAspect16(shownAspect16);
        chartElements2.setShownAspect17(shownAspect17);
        chartElements2.setChartSelectSingle(chartSelectSingle);
        chartElements2.setChartReturnPrecess(chartReturnPrecess);
        chartElements2.setLimitMag(limitMag);
        chartElements2.setOrbLightLight(orbLightLight);
        chartElements2.setOrbLightTell(orbLightTell);
        chartElements2.setOrbLightOtherInd(orbLightOtherInd);
        chartElements2.setOrbLightColl(orbLightColl);
        chartElements2.setOrbLightVirtMax(orbLightVirtMax);
        chartElements2.setOrbLightVirtMin(orbLightVirtMin);
        chartElements2.setOrbTellTell(orbTellTell);
        chartElements2.setOrbTellOtherInd(orbTellOtherInd);
        chartElements2.setOrbTellColl(orbTellColl);
        chartElements2.setOrbTellVirtMax(orbTellVirtMax);
        chartElements2.setOrbTellVirtMin(orbTellVirtMin);
        chartElements2.setOrbOtherIndOtherInd(orbOtherIndOtherInd);
        chartElements2.setOrbOtherIndColl(orbOtherIndColl);
        chartElements2.setOrbOtherIndVirtMax(orbOtherIndVirtMax);
        chartElements2.setOrbOtherIndVirtMin(orbOtherIndVirtMin);
        chartElements2.setOrbCollColl(orbCollColl);
        chartElements2.setOrbCollVirtMax(orbCollVirtMax);
        chartElements2.setOrbCollVirtMin(orbCollVirtMin);
        chartElements2.setOrbVirtMaxVirtMax(orbVirtMaxVirtMax);
        chartElements2.setOrbVirtMaxVirtMin(orbVirtMaxVirtMin);
        chartElements2.setOrbVirtMinVirtMin(orbVirtMinVirtMin);
        chartElements2.setDivMin(divMin);
        chartElements2.setDivConjunction(divConjunction);
        chartElements2.setDivSextile(divSextile);
        chartElements2.setDivSquare(divSquare);
        chartElements2.setDivTrine(divTrine);
        chartElements2.setDivOpposition(divOpposition);
        chartElements2.setOtherAspectValue(otherAspectValue);
        chartElements2.setChartCoords(allCoords);
        return chartElements2;
    }
    
    public String getChartID()
    {
        return chartID;
    }
    public void setChartID(String sData)
    {
        chartID = sData;
    }
    
    public int getChartKind()
    {
        return chartKind;
    }
    public void setChartKind(int data)
    {
        chartKind = data;
    }
    
    public double getChartReturnNB()
    {
        return chartReturnNB;
    }
    public void setChartReturnNB(double data)
    {
        chartReturnNB = data;
    }
    
    public double getChartCycleNB()
    {
        return chartCycleNB;
    }
    public void setChartCycleNB(double data)
    {
        chartCycleNB = data;
    }
    
    public double getChartReturnLatitude()
    {
        return chartReturnLatitude;
    }
    public void setChartReturnLatitude(double data)
    {
        chartReturnLatitude = data;
    }
    
    public int getChartDirSSpaceKind()
    {
        return chartDirSSpaceKind;
    }
    public void setChartDirSSpaceKind(int data)
    {
        chartDirSSpaceKind = data;
    }
    
    public int getChartDir1SpaceKind()
    {
        return chartDir1SpaceKind;
    }
    public void setChartDir1SpaceKind(int data)
    {
        chartDir1SpaceKind = data;
    }
    
    public int getChartDir2SpaceKind()
    {
        return chartDir2SpaceKind;
    }
    public void setChartDir2SpaceKind(int data)
    {
        chartDir2SpaceKind = data;
    }
    
    public double getChartReturnLongitude()
    {
        return chartReturnLongitude;
    }
    public void setChartReturnLongitude(double data)
    {
        chartReturnLongitude = data;
    }
    
    public double getChartCycleLatitude()
    {
        return chartCycleLatitude;
    }
    public void setChartCycleLatitude(double data)
    {
        chartCycleLatitude = data;
    }
    
    public double getChartCycleLongitude()
    {
        return chartCycleLongitude;
    }
    public void setChartCycleLongitude(double data)
    {
        chartCycleLongitude = data;
    }
    
    public double getDirSAge()
    {
        return dirSAge;
    }
    public void setDirSAge(double data)
    {
        dirSAge = data;
    }
    
    public double getDir1Age()
    {
        return dir1Age;
    }
    public void setDir1Age(double data)
    {
        dir1Age = data;
    }
    
    public double getDir2Age()
    {
        return dir2Age;
    }
    public void setDir2Age(double data)
    {
        dir2Age = data;
    }
    
    public double getChartDirSCorresp()
    {
        return chartDirSCorresp;
    }
    public void setChartDirSCorresp(double data)
    {
        chartDirSCorresp = data;
    }
    
    public double getChartDir1Corresp()
    {
        return chartDir1Corresp;
    }
    public void setChartDir1Corresp(double data)
    {
        chartDir1Corresp = data;
    }
    
    public double getChartDir2Corresp()
    {
        return chartDir2Corresp;
    }
    public void setChartDir2Corresp(double data)
    {
        chartDir2Corresp = data;
    }
    
    public double getChartDirSDegree()
    {
        return chartDirSDegree;
    }
    public void setChartDirSDegree(double data)
    {
        chartDirSDegree = data;
    }
    
    public double getChartDir1Degree()
    {
        return chartDir1Degree;
    }
    public void setChartDir1Degree(double data)
    {
        chartDir1Degree = data;
    }
    
    public double getChartDir2Day()
    {
        return chartDir2Day;
    }
    public void setChartDir2Day(double data)
    {
        chartDir2Day = data;
    }
    
    public String getTransitsDate()
    {
        return transitsDate;
    }
    public void setTransitsDate(String sData)
    {
        transitsDate = sData;
    }
    
    public ArrayList getChartEvents()
    {
        return chartEvents;
    }
    public void setChartEvents(ArrayList data)
    {
        chartEvents = data;
    }
    
    public ArrayList getChartCoords()
    {
        return allCoords;
    }
    public void setChartCoords(ArrayList data)
    {
        allCoords = data;
    }
    
    public int getCoordSys()
    {
        return coordSys;
    }
    public int getHouseSys()
    {
        return houseSys;
    }
    public byte getOtherPointType()
    {
        return otherPointType;
    }
    public int getChartReturnPlanet()
    {
        return chartReturnPlanet;
    }
    public int getChartCyclePlanet1()
    {
        return chartCyclePlanet1;
    }
    public int getChartCyclePlanet2()
    {
        return chartCyclePlanet2;
    }
    public int getChartCompositeNB()
    {
        return chartCompositeNB;
    }
    public boolean getChartCompositeFromAS()
    {
        return chartCompositeFromAS;
    }
    public int getChartHarmonicNB()
    {
        return chartHarmonicNB;
    }
    public String getOtherPointName()
    {
        return otherPointName;
    }
    public int getZodiacSize()
    {
        return zodiacSize;
    }
    public int getSignSize()
    {
        return signSize;
    }
    public int getPlanetSize()
    {
        return planetSize;
    }
    public int getCharacterSize()
    {
        return characterSize;
    }
    public int getTypeAspect0()
    {
        return typeAspect0;
    }
    public int getTypeAspect1()
    {
        return typeAspect1;
    }
    public int getTypeAspect2()
    {
        return typeAspect2;
    }
    public int getTypeAspect3()
    {
        return typeAspect3;
    }
    public int getTypeAspect4()
    {
        return typeAspect4;
    }
    public int getTypeAspect5()
    {
        return typeAspect5;
    }
    public int getTypeAspect6()
    {
        return typeAspect6;
    }
    public int getTypeAspect7()
    {
        return typeAspect7;
    }
    public int getTypeAspect8()
    {
        return typeAspect8;
    }
    public int getTypeAspect9()
    {
        return typeAspect9;
    }
    public int getTypeAspect10()
    {
        return typeAspect10;
    }
    public int getTypeAspect11()
    {
        return typeAspect11;
    }
    public int getTypeAspect12()
    {
        return typeAspect12;
    }
    public int getTypeAspect13()
    {
        return typeAspect13;
    }
    public int getTypeAspect14()
    {
        return typeAspect14;
    }
    public int getTypeAspect15()
    {
        return typeAspect15;
    }
    public int getTypeAspect16()
    {
        return typeAspect16;
    }
    public int getTypeAspect17()
    {
        return typeAspect17;
    }
    public String getOtherAspectName()
    {
        return otherAspectName;
    }
    public String getChartReturnPlaceName()
    {
        return chartReturnPlaceName;
    }
    public String getChartCyclePlaceName()
    {
        return chartCyclePlaceName;
    }
    public String getPlanetaryConfigurations()
    {
        return planetaryConfigurations;
    }
    public String getChartHeader()
    {
        return chartHeader;
    }
    public Color getPlanetColor(int planet)
    {
        switch(planet)
        {
            case Planets.Sun: return sunColor;
            case Planets.Moon: return moonColor;
            case Planets.Mercury: return mercuryColor;
            case Planets.Venus: return venusColor;
            case Planets.Mars: return marsColor;
            case Planets.Jupiter: return jupiterColor;
            case Planets.Saturn: return saturnColor;
            case Planets.Uranus: return uranusColor;
            case Planets.Neptune: return neptuneColor;
            case Planets.Pluto: return plutoColor;
            case Planets.Gaia: return gaiaColor;
            case Planets.NorthNode: return nodesColor;
            case Planets.Lilith: return nodesColor;
            case Planets.East: ;
            case Planets.Zenith: ;
            case Planets.Vertex: return variousColor;
            case Planets.Vulcan: return vulcanColor;
            case Planets.OtherPoint: return variousColor;
            case Planets.Ceres: ;
            case Planets.Pallas: ;
            case Planets.Juno: ;
            case Planets.Vesta: ;
            case Planets.Chiron: return asteroidsColor;
            case Planets.AS: ;
            case Planets.MC: ;
            case Planets.House1: ;
            case Planets.House2: ;
            case Planets.House3: ;
            case Planets.House4: ;
            case Planets.House5: ;
            case Planets.House6: ;
            case Planets.House7: ;
            case Planets.House8: ;
            case Planets.House9: ;
            case Planets.House10: ;
            case Planets.House11: ;
            case Planets.House12: return cuspsColor;
            case Planets.SouthNode: return nodesColor;
            default: return Color.BLACK;
        }
    }
    public boolean getShownObject(int planet)
    {
        switch(planet)
        {
            case Planets.Sun: return shownSun;
            case Planets.Moon: return shownMoon;
            case Planets.Mercury: return shownMercury;
            case Planets.Venus: return shownVenus;
            case Planets.Mars: return shownMars;
            case Planets.Jupiter: return shownJupiter;
            case Planets.Saturn: return shownSaturn;
            case Planets.Uranus: return shownUranus;
            case Planets.Neptune: return shownNeptune;
            case Planets.Pluto: return shownPluto;
            case Planets.Gaia: return shownGaia;
            case Planets.NorthNode: return shownNorthNode;
            case Planets.Lilith: return shownLilith;
            case Planets.East: return shownEast;
            case Planets.Zenith: return shownZenith;
            case Planets.Vertex: return shownVertex;
            case Planets.Vulcan: return shownVulcan;
            case Planets.OtherPoint: return shownOtherPoint;
            case Planets.Ceres: return shownCeres;
            case Planets.Pallas: return shownPallas;
            case Planets.Juno: return shownJuno;
            case Planets.Vesta: return shownVesta;
            case Planets.Chiron: return shownChiron;
            case Planets.AS: return viewHouses;
            case Planets.MC: return viewHouses;
            case Planets.House1: return viewHouses;
            case Planets.House2: return viewHouses;
            case Planets.House3: return viewHouses;
            case Planets.House4: return viewHouses;
            case Planets.House5: return viewHouses;
            case Planets.House6: return viewHouses;
            case Planets.House7: return viewHouses;
            case Planets.House8: return viewHouses;
            case Planets.House9: return viewHouses;
            case Planets.House10: return viewHouses;
            case Planets.House11: return viewHouses;
            case Planets.House12: return viewHouses;
            case Planets.SouthNode: return shownNorthNode;
            default: return false;
        }
    }
    public Color getSunColor()
    {
        return sunColor;
    }
    public Color getMoonColor()
    {
        return moonColor;
    }
    public Color getMercuryColor()
    {
        return mercuryColor;
    }
    public Color getVenusColor()
    {
        return venusColor;
    }
    public Color getMarsColor()
    {
        return marsColor;
    }
    public Color getJupiterColor()
    {
        return jupiterColor;
    }
    public Color getSaturnColor()
    {
        return saturnColor;
    }
    public Color getUranusColor()
    {
        return uranusColor;
    }
    public Color getNeptuneColor()
    {
        return neptuneColor;
    }
    public Color getPlutoColor()
    {
        return plutoColor;
    }
    public Color getGaiaColor()
    {
        return gaiaColor;
    }
    public Color getNodesColor()
    {
        return nodesColor;
    }
    public Color getCuspsColor()
    {
        return cuspsColor;
    }
    public Color getAsteroidsColor()
    {
        return asteroidsColor;
    }
    public Color getVulcanColor()
    {
        return vulcanColor;
    }
    public Color getVariousColor()
    {
        return variousColor;
    }
    public Color getFireColor()
    {
        return fireColor;
    }
    public Color getEarthColor()
    {
        return earthColor;
    }
    public Color getAirColor()
    {
        return airColor;
    }
    public Color getWaterColor()
    {
        return waterColor;
    }
    public Color getNeutralColor()
    {
        return neutralColor;
    }
    public Color getDynamicColor()
    {
        return dynamicColor;
    }
    public Color getHarmonicColor()
    {
        return harmonicColor;
    }
    public Color getColorAspect(int aspect)
    {
        switch(aspect)
        {
            case 0: return colorAspect0;
            case 1: return colorAspect1;
            case 2: return colorAspect2;
            case 3: return colorAspect3;
            case 4: return colorAspect4;
            case 5: return colorAspect5;
            case 6: return colorAspect6;
            case 7: return colorAspect7;
            case 8: return colorAspect8;
            case 9: return colorAspect9;
            case 10: return colorAspect10;
            case 11: return colorAspect11;
            case 12: return colorAspect12;
            case 13: return colorAspect13;
            case 14: return colorAspect14;
            case 15: return colorAspect15;
            case 16: return colorAspect16;
            case 17: return colorAspect17;
            default : return Color.BLACK;
        }
    }
    public int getTypeAspect(int aspect)
    {
        switch(aspect)
        {
            case 0: return typeAspect0;
            case 1: return typeAspect1;
            case 2: return typeAspect2;
            case 3: return typeAspect3;
            case 4: return typeAspect4;
            case 5: return typeAspect5;
            case 6: return typeAspect6;
            case 7: return typeAspect7;
            case 8: return typeAspect8;
            case 9: return typeAspect9;
            case 10: return typeAspect10;
            case 11: return typeAspect11;
            case 12: return typeAspect12;
            case 13: return typeAspect13;
            case 14: return typeAspect14;
            case 15: return typeAspect15;
            case 16: return typeAspect16;
            case 17: return typeAspect17;
            default : return -1;
        }
    }
    public Color getColorAspect0()
    {
        return colorAspect0;
    }
    public Color getColorAspect1()
    {
        return colorAspect1;
    }
    public Color getColorAspect2()
    {
        return colorAspect2;
    }
    public Color getColorAspect3()
    {
        return colorAspect3;
    }
    public Color getColorAspect4()
    {
        return colorAspect4;
    }
    public Color getColorAspect5()
    {
        return colorAspect5;
    }
    public Color getColorAspect6()
    {
        return colorAspect6;
    }
    public Color getColorAspect7()
    {
        return colorAspect7;
    }
    public Color getColorAspect8()
    {
        return colorAspect8;
    }
    public Color getColorAspect9()
    {
        return colorAspect9;
    }
    public Color getColorAspect10()
    {
        return colorAspect10;
    }
    public Color getColorAspect11()
    {
        return colorAspect11;
    }
    public Color getColorAspect12()
    {
        return colorAspect12;
    }
    public Color getColorAspect13()
    {
        return colorAspect13;
    }
    public Color getColorAspect14()
    {
        return colorAspect14;
    }
    public Color getColorAspect15()
    {
        return colorAspect15;
    }
    public Color getColorAspect16()
    {
        return colorAspect16;
    }
    public Color getColorAspect17()
    {
        return colorAspect17;
    }
    public boolean getShownSun()
    {
        return shownSun;
    }
    public boolean getShownMoon()
    {
        return shownMoon;
    }
    public boolean getShownMercury()
    {
        return shownMercury;
    }
    public boolean getShownVenus()
    {
        return shownVenus;
    }
    public boolean getShownMars()
    {
        return shownMars;
    }
    public boolean getShownJupiter()
    {
        return shownJupiter;
    }
    public boolean getShownSaturn()
    {
        return shownSaturn;
    }
    public boolean getShownUranus()
    {
        return shownUranus;
    }
    public boolean getShownNeptune()
    {
        return shownNeptune;
    }
    public boolean getShownPluto()
    {
        return shownPluto;
    }
    public boolean getShownGaia()
    {
        return shownGaia;
    }
    public boolean getShownNorthNode()
    {
        return shownNorthNode;
    }
    public boolean getShownLilith()
    {
        return shownLilith;
    }
    public boolean getShownEast()
    {
        return shownEast;
    }
    public boolean getShownZenith()
    {
        return shownZenith;
    }
    public boolean getShownVertex()
    {
        return shownVertex;
    }
    public boolean getShownVulcan()
    {
        return shownVulcan;
    }
    public boolean getShownOtherPoint()
    {
        return shownOtherPoint;
    }
    public boolean getShownCeres()
    {
        return shownCeres;
    }
    public boolean getShownPallas()
    {
        return shownPallas;
    }
    public boolean getShownJuno()
    {
        return shownJuno;
    }
    public boolean getShownVesta()
    {
        return shownVesta;
    }
    public boolean getShownChiron()
    {
        return shownChiron;
    }
    public boolean getTrueLilith()
    {
        return trueLilith;
    }
    public boolean getColoredAspects()
    {
        return coloredAspects;
    }
    public boolean getHousesCoords()
    {
        return housesCoords;
    }
    public boolean getSignsNames()
    {
        return signsNames;
    }
    public boolean getLeftAsct()
    {
        return leftAsct;
    }
    public boolean getSymbolAspects()
    {
        return symbolAspects;
    }
    public boolean getViewStars()
    {
        return viewStars;
    }
    public boolean getViewAsteroids()
    {
        return viewAsteroids;
    }
    public boolean getViewCoordinates()
    {
        return viewCoordinates;
    }
    public boolean getViewStraightLines()
    {
        return viewStraightLines;
    }
    public boolean getViewHouses()
    {
        return viewHouses;
    }
    public boolean getViewConstellations()
    {
        return viewConstellations;
    }
    public boolean getViewShadedLines()
    {
        return viewShadedLines;
    }
    public boolean getViewAspects()
    {
        return viewAspects;
    }
    public boolean getViewBarycenter()
    {
        return viewBarycenter;
    }
    public boolean getSingleWeight()
    {
        return singleWeight;
    }
    public boolean getHorizon()
    {
        return horizon;
    }
    public boolean getAspectsObject(int obj)
    {
        switch (obj)
        {
            case Planets.Sun: return aspectsSun;
            case Planets.Moon: return aspectsMoon;
            case Planets.Mercury: return aspectsMercury;
            case Planets.Venus: return aspectsVenus;
            case Planets.Mars: return aspectsMars;
            case Planets.Jupiter: return aspectsJupiter;
            case Planets.Saturn: return aspectsSaturn;
            case Planets.Uranus: return aspectsUranus;
            case Planets.Neptune: return aspectsNeptune;
            case Planets.Pluto: return aspectsPluto;
            case Planets.Gaia: return aspectsGaia;
            case Planets.NorthNode: return aspectsNorthNode;
            case Planets.Lilith: return aspectsLilith;
            case Planets.East: return aspectsEast;
            case Planets.Vertex: return aspectsVertex;
            case Planets.Vulcan: return aspectsVulcan;
            case Planets.Zenith: return aspectsZenith;
            case Planets.Ceres: return aspectsCeres;
            case Planets.Pallas: return aspectsPallas;
            case Planets.Juno: return aspectsJuno;
            case Planets.Vesta: return aspectsVesta;
            case Planets.Chiron: return aspectsChiron;
            case Planets.OtherPoint: return aspectsOtherPoint;
            case Planets.AS: return aspectsAS;
            case Planets.MC: return aspectsMC;
            default: return false;
        }
    }
    public boolean getAspectsSun()
    {
        return aspectsSun;
    }
    public boolean getAspectsMoon()
    {
        return aspectsMoon;
    }
    public boolean getAspectsMercury()
    {
        return aspectsMercury;
    }
    public boolean getAspectsVenus()
    {
        return aspectsVenus;
    }
    public boolean getAspectsMars()
    {
        return aspectsMars;
    }
    public boolean getAspectsJupiter()
    {
        return aspectsJupiter;
    }
    public boolean getAspectsSaturn()
    {
        return aspectsSaturn;
    }
    public boolean getAspectsUranus()
    {
        return aspectsUranus;
    }
    public boolean getAspectsNeptune()
    {
        return aspectsNeptune;
    }
    public boolean getAspectsPluto()
    {
        return aspectsPluto;
    }
    public boolean getAspectsGaia()
    {
        return aspectsGaia;
    }
    public boolean getAspectsNorthNode()
    {
        return aspectsNorthNode;
    }
    public boolean getAspectsLilith()
    {
        return aspectsLilith;
    }
    public boolean getAspectsEast()
    {
        return aspectsEast;
    }
    public boolean getAspectsZenith()
    {
        return aspectsZenith;
    }
    public boolean getAspectsVertex()
    {
        return aspectsVertex;
    }
    public boolean getAspectsVulcan()
    {
        return aspectsVulcan;
    }
    public boolean getAspectsOtherPoint()
    {
        return aspectsOtherPoint;
    }
    public boolean getAspectsCeres()
    {
        return aspectsCeres;
    }
    public boolean getAspectsPallas()
    {
        return aspectsPallas;
    }
    public boolean getAspectsJuno()
    {
        return aspectsJuno;
    }
    public boolean getAspectsVesta()
    {
        return aspectsVesta;
    }
    public boolean getAspectsChiron()
    {
        return aspectsChiron;
    }
    public boolean getAspectsAS()
    {
        return aspectsAS;
    }
    public boolean getAspectsMC()
    {
        return aspectsMC;
    }
    public boolean getShownAspect(int aspect)
    {
        if (aspect == 0) return shownAspect0;
        else if (aspect == 1) return shownAspect1;
        else if (aspect == 2) return shownAspect2;
        else if (aspect == 3) return shownAspect3;
        else if (aspect == 4) return shownAspect4;
        else if (aspect == 5) return shownAspect5;
        else if (aspect == 6) return shownAspect6;
        else if (aspect == 7) return shownAspect7;
        else if (aspect == 8) return shownAspect8;
        else if (aspect == 9) return shownAspect9;
        else if (aspect == 10) return shownAspect10;
        else if (aspect == 11) return shownAspect11;
        else if (aspect == 12) return shownAspect12;
        else if (aspect == 13) return shownAspect13;
        else if (aspect == 14) return shownAspect14;
        else if (aspect == 15) return shownAspect15;
        else if (aspect == 16) return shownAspect16;
        else if (aspect == 17) return shownAspect17;
        return false;
    }
    public boolean getShownAspect0()
    {
        return shownAspect0;
    }
    public boolean getShownAspect1()
    {
        return shownAspect1;
    }
    public boolean getShownAspect2()
    {
        return shownAspect2;
    }
    public boolean getShownAspect3()
    {
        return shownAspect3;
    }
    public boolean getShownAspect4()
    {
        return shownAspect4;
    }
    public boolean getShownAspect5()
    {
        return shownAspect5;
    }
    public boolean getShownAspect6()
    {
        return shownAspect6;
    }
    public boolean getShownAspect7()
    {
        return shownAspect7;
    }
    public boolean getShownAspect8()
    {
        return shownAspect8;
    }
    public boolean getShownAspect9()
    {
        return shownAspect9;
    }
    public boolean getShownAspect10()
    {
        return shownAspect10;
    }
    public boolean getShownAspect11()
    {
        return shownAspect11;
    }
    public boolean getShownAspect12()
    {
        return shownAspect12;
    }
    public boolean getShownAspect13()
    {
        return shownAspect13;
    }
    public boolean getShownAspect14()
    {
        return shownAspect14;
    }
    public boolean getShownAspect15()
    {
        return shownAspect15;
    }
    public boolean getShownAspect16()
    {
        return shownAspect16;
    }
    public boolean getShownAspect17()
    {
        return shownAspect17;
    }
    public boolean getChartSelectSingle()
    {
        return chartSelectSingle;
    }
    public boolean getChartReturnPrecess()
    {
        return chartReturnPrecess;
    }
    public double getLimitMag()
    {
        return limitMag;
    }
    public double getOrbLightLight()
    {
        return orbLightLight;
    }
    public double getOrbLightTell()
    {
        return orbLightTell;
    }
    public double getOrbLightOtherInd()
    {
        return orbLightOtherInd;
    }
    public double getOrbLightColl()
    {
        return orbLightColl;
    }
    public double getOrbLightVirtMax()
    {
        return orbLightVirtMax;
    }
    public double getOrbLightVirtMin()
    {
        return orbLightVirtMin;
    }
    public double getOrbTellTell()
    {
        return orbTellTell;
    }
    public double getOrbTellOtherInd()
    {
        return orbTellOtherInd;
    }
    public double getOrbTellColl()
    {
        return orbTellColl;
    }
    public double getOrbTellVirtMax()
    {
        return orbTellVirtMin;
    }
    public double getOrbTellVirtMin()
    {
        return orbTellVirtMin;
    }
    public double getOrbOtherIndOtherInd()
    {
        return orbOtherIndOtherInd;
    }
    public double getOrbOtherIndColl()
    {
        return orbOtherIndColl;
    }
    public double getOrbOtherIndVirtMax()
    {
        return orbOtherIndVirtMax;
    }
    public double getOrbOtherIndVirtMin()
    {
        return orbOtherIndVirtMin;
    }
    public double getOrbCollColl()
    {
        return orbCollColl;
    }
    public double getOrbCollVirtMax()
    {
        return orbCollVirtMax;
    }
    public double getOrbCollVirtMin()
    {
        return orbCollVirtMin;
    }
    public double getOrbVirtMaxVirtMax()
    {
        return orbVirtMaxVirtMax;
    }
    public double getOrbVirtMaxVirtMin()
    {
        return orbVirtMaxVirtMin;
    }
    public double getOrbVirtMinVirtMin()
    {
        return orbVirtMinVirtMin;
    }
    public double getDivisor(int aspect)
    {
        if (aspect == AspectType.Conjunction) return divConjunction;
        else if (aspect == AspectType.Sextile) return divSextile;
        else if (aspect == AspectType.Square) return divSquare;
        else if (aspect == AspectType.Trine) return divTrine;
        else if (aspect == AspectType.Opposition) return divOpposition;
        else return divMin;
    }
    public double getDivMin()
    {
        return divMin;
    }
    public double getDivConjunction()
    {
        return divConjunction;
    }
    public double getDivSextile()
    {
        return divSextile;
    }
    public double getDivSquare()
    {
        return divSquare;
    }
    public double getDivTrine()
    {
        return divTrine;
    }
    public double getDivOpposition()
    {
        return divOpposition;
    }
    public double getOtherAspectValue()
    {
        return otherAspectValue;
    }
    
    public void setCoordSys(int data)
    {
        coordSys = data;
    }
    
    public void setHouseSys(int data)
    {
        houseSys = data;
    }
    
    public void setOtherPointType(byte data)
    {
        otherPointType = data;
    }
    
    public void setChartReturnPlanet(int data)
    {
        chartReturnPlanet = data;
    }
    
    public void setChartCyclePlanet1(int data)
    {
        chartCyclePlanet1 = data;
    }
    
    public void setChartCyclePlanet2(int data)
    {
        chartCyclePlanet2 = data;
    }
    
    public void setChartCompositeNB(int data)
    {
        chartCompositeNB = data;
    }
    
    public void setChartCompositeFromAS(boolean data)
    {
        chartCompositeFromAS = data;
    }
    
    public void setChartHarmonicNB(int data)
    {
        chartHarmonicNB = data;
    }
    
    public void setOtherPointName(String data)
    {
        otherPointName = data;
    }
    
    public void setZodiacSize(int data)
    {
        zodiacSize = data;
    }
    
    public void setSignSize(int data)
    {
        signSize = data;
    }
    
    public void setPlanetSize(int data)
    {
        planetSize = data;
    }
    
    public void setCharacterSize(int data)
    {
        characterSize = data;
    }
    
    public void setTypeAspect0(int data)
    {
        typeAspect0 = data;
    }
    
    public void setTypeAspect1(int data)
    {
        typeAspect1 = data;
    }
    
    public void setTypeAspect2(int data)
    {
        typeAspect2 = data;
    }
    
    public void setTypeAspect3(int data)
    {
        typeAspect3 = data;
    }
    
    public void setTypeAspect4(int data)
    {
        typeAspect4 = data;
    }
    
    public void setTypeAspect5(int data)
    {
        typeAspect5 = data;
    }
    
    public void setTypeAspect6(int data)
    {
        typeAspect6 = data;
    }
    
    public void setTypeAspect7(int data)
    {
        typeAspect7 = data;
    }
    
    public void setTypeAspect8(int data)
    {
        typeAspect8 = data;
    }
    
    public void setTypeAspect9(int data)
    {
        typeAspect9 = data;
    }
    
    public void setTypeAspect10(int data)
    {
        typeAspect10 = data;
    }
    
    public void setTypeAspect11(int data)
    {
        typeAspect11 = data;
    }
    
    public void setTypeAspect12(int data)
    {
        typeAspect12 = data;
    }
    
    public void setTypeAspect13(int data)
    {
        typeAspect13 = data;
    }
    
    public void setTypeAspect14(int data)
    {
        typeAspect14 = data;
    }
    
    public void setTypeAspect15(int data)
    {
        typeAspect15 = data;
    }
    
    public void setTypeAspect16(int data)
    {
        typeAspect16 = data;
    }
    
    public void setTypeAspect17(int data)
    {
        typeAspect17 = data;
    }
    
    public void setOtherAspectName(String data)
    {
        otherAspectName = data;
    }
    
    public void setChartReturnPlaceName(String data)
    {
        chartReturnPlaceName = data;
    }
    
    public void setChartHeader(String data)
    {
        chartHeader = data;
    }
    
    public void setChartCyclePlaceName(String data)
    {
        chartCyclePlaceName = data;
    }
    
    public void setPlanetaryConfigurations(String data)
    {
        planetaryConfigurations = data;
    }
    
    public void setSunColor(Color data)
    {
        sunColor = data;
    }
    
    public void setMoonColor(Color data)
    {
        moonColor = data;
    }
    
    public void setMercuryColor(Color data)
    {
        mercuryColor = data;
    }
    
    public void setVenusColor(Color data)
    {
        venusColor = data;
    }
    
    public void setMarsColor(Color data)
    {
        marsColor = data;
    }
    
    public void setJupiterColor(Color data)
    {
        jupiterColor = data;
    }
    
    public void setSaturnColor(Color data)
    {
        saturnColor = data;
    }
    
    public void setUranusColor(Color data)
    {
        uranusColor = data;
    }
    
    public void setNeptuneColor(Color data)
    {
        neptuneColor = data;
    }
    
    public void setPlutoColor(Color data)
    {
        plutoColor = data;
    }
    
    public void setGaiaColor(Color data)
    {
        gaiaColor = data;
    }
    
    public void setNodesColor(Color data)
    {
        nodesColor = data;
    }
    
    public void setCuspsColor(Color data)
    {
        cuspsColor = data;
    }
    
    public void setAsteroidsColor(Color data)
    {
        asteroidsColor = data;
    }
    
    public void setVulcanColor(Color data)
    {
        vulcanColor = data;
    }
    
    public void setVariousColor(Color data)
    {
        variousColor = data;
    }
    
    public void setFireColor(Color data)
    {
        fireColor = data;
    }
    
    public void setEarthColor(Color data)
    {
        earthColor = data;
    }
    
    public void setAirColor(Color data)
    {
        airColor = data;
    }
    
    public void setWaterColor(Color data)
    {
        waterColor = data;
    }
    
    public void setNeutralColor(Color data)
    {
        neutralColor = data;
    }
    
    public void setDynamicColor(Color data)
    {
        dynamicColor = data;
    }
    
    public void setHarmonicColor(Color data)
    {
        harmonicColor = data;
    }
    
    public void setColorAspect0(Color data)
    {
        colorAspect0 = data;
    }
    
    public void setColorAspect1(Color data)
    {
        colorAspect1 = data;
    }
    
    public void setColorAspect2(Color data)
    {
        colorAspect2 = data;
    }
    
    public void setColorAspect3(Color data)
    {
        colorAspect3 = data;
    }
    
    public void setColorAspect4(Color data)
    {
        colorAspect4 = data;
    }
    
    public void setColorAspect5(Color data)
    {
        colorAspect5 = data;
    }
    
    public void setColorAspect6(Color data)
    {
        colorAspect6 = data;
    }
    
    public void setColorAspect7(Color data)
    {
        colorAspect7 = data;
    }
    
    public void setColorAspect8(Color data)
    {
        colorAspect8 = data;
    }
    
    public void setColorAspect9(Color data)
    {
        colorAspect9 = data;
    }
    
    public void setColorAspect10(Color data)
    {
        colorAspect10 = data;
    }
    
    public void setColorAspect11(Color data)
    {
        colorAspect11 = data;
    }
    
    public void setColorAspect12(Color data)
    {
        colorAspect12 = data;
    }
    
    public void setColorAspect13(Color data)
    {
        colorAspect13 = data;
    }
    
    public void setColorAspect14(Color data)
    {
        colorAspect14 = data;
    }
    
    public void setColorAspect15(Color data)
    {
        colorAspect15 = data;
    }
    
    public void setColorAspect16(Color data)
    {
        colorAspect16 = data;
    }
    
    public void setColorAspect17(Color data)
    {
        colorAspect17 = data;
    }
    
    public void setShownSun(boolean data)
    {
        shownSun = data;
    }
    
    public void setShownMoon(boolean data)
    {
        shownMoon = data;
    }
    
    public void setShownMercury(boolean data)
    {
        shownMercury = data;
    }
    
    public void setShownVenus(boolean data)
    {
        shownVenus = data;
    }
    
    public void setShownMars(boolean data)
    {
        shownMars = data;
    }
    
    public void setShownJupiter(boolean data)
    {
        shownJupiter = data;
    }
    
    public void setShownSaturn(boolean data)
    {
        shownSaturn = data;
    }
    
    public void setShownUranus(boolean data)
    {
        shownUranus = data;
    }
    
    public void setShownNeptune(boolean data)
    {
        shownNeptune = data;
    }
    
    public void setShownPluto(boolean data)
    {
        shownPluto = data;
    }
    
    public void setShownGaia(boolean data)
    {
        shownGaia = data;
    }
    
    public void setShownNorthNode(boolean data)
    {
        shownNorthNode = data;
    }
    
    public void setShownLilith(boolean data)
    {
        shownLilith = data;
    }
    
    public void setShownEast(boolean data)
    {
        shownEast = data;
    }
    
    public void setShownZenith(boolean data)
    {
        shownZenith = data;
    }
    
    public void setShownVertex(boolean data)
    {
        shownVertex = data;
    }
    
    public void setShownVulcan(boolean data)
    {
        shownVulcan = data;
    }
    
    public void setShownOtherPoint(boolean data)
    {
        shownOtherPoint = data;
    }
    
    public void setShownCeres(boolean data)
    {
        shownCeres = data;
    }
    
    public void setShownPallas(boolean data)
    {
        shownPallas = data;
    }
    
    public void setShownJuno(boolean data)
    {
        shownJuno = data;
    }
    
    public void setShownVesta(boolean data)
    {
        shownVesta = data;
    }
    
    public void setShownChiron(boolean data)
    {
        shownChiron = data;
    }
    
    public void setTrueLilith(boolean data)
    {
        trueLilith = data;
    }
    
    public void setColoredAspects(boolean data)
    {
        coloredAspects = data;
    }
    
    public void setHousesCoords(boolean data)
    {
        housesCoords = data;
    }
    
    public void setSignsNames(boolean data)
    {
        signsNames = data;
    }
    
    public void setLeftAsct(boolean data)
    {
        leftAsct = data;
    }
    
    public void setSymbolAspects(boolean data)
    {
        symbolAspects = data;
    }
    
    public void setViewStars(boolean data)
    {
        viewStars = data;
    }
    
    public void setViewAsteroids(boolean data)
    {
        viewAsteroids = data;
    }
    
    public void setViewCoordinates(boolean data)
    {
        viewCoordinates = data;
    }
    
    public void setViewStraightLines(boolean data)
    {
        viewStraightLines = data;
    }
    
    public void setViewHouses(boolean data)
    {
        viewHouses = data;
    }
    
    public void setViewConstellations(boolean data)
    {
        viewConstellations = data;
    }
    
    public void setViewShadedLines(boolean data)
    {
        viewShadedLines = data;
    }
    
    public void setViewAspects(boolean data)
    {
        viewAspects = data;
    }
    
    public void setViewBarycenter(boolean data)
    {
        viewBarycenter = data;
    }
    
    public void setSingleWeight(boolean data)
    {
        singleWeight = data;
    }
    
    public void setHorizon(boolean data)
    {
        horizon = data;
    }
    
    public void setAspectsSun(boolean data)
    {
        aspectsSun = data;
    }
    
    public void setAspectsMoon(boolean data)
    {
        aspectsMoon = data;
    }
    
    public void setAspectsMercury(boolean data)
    {
        aspectsMercury = data;
    }
    
    public void setAspectsVenus(boolean data)
    {
        aspectsVenus = data;
    }
    
    public void setAspectsMars(boolean data)
    {
        aspectsMars = data;
    }
    
    public void setAspectsJupiter(boolean data)
    {
        aspectsJupiter = data;
    }
    
    public void setAspectsSaturn(boolean data)
    {
        aspectsSaturn = data;
    }
    
    public void setAspectsUranus(boolean data)
    {
        aspectsUranus = data;
    }
    
    public void setAspectsNeptune(boolean data)
    {
        aspectsNeptune = data;
    }
    
    public void setAspectsPluto(boolean data)
    {
        aspectsPluto = data;
    }
    
    public void setAspectsGaia(boolean data)
    {
        aspectsGaia = data;
    }
    
    public void setAspectsNorthNode(boolean data)
    {
        aspectsNorthNode = data;
    }
    
    public void setAspectsLilith(boolean data)
    {
        aspectsLilith = data;
    }
    
    public void setAspectsEast(boolean data)
    {
        aspectsEast = data;
    }
    
    public void setAspectsZenith(boolean data)
    {
        aspectsZenith = data;
    }
    
    public void setAspectsVertex(boolean data)
    {
        aspectsVertex = data;
    }
    
    public void setAspectsVulcan(boolean data)
    {
        aspectsVulcan = data;
    }
    
    public void setAspectsOtherPoint(boolean data)
    {
        aspectsOtherPoint = data;
    }
    
    public void setAspectsCeres(boolean data)
    {
        aspectsCeres = data;
    }
    
    public void setAspectsPallas(boolean data)
    {
        aspectsPallas = data;
    }
    
    public void setAspectsJuno(boolean data)
    {
        aspectsJuno = data;
    }
    
    public void setAspectsVesta(boolean data)
    {
        aspectsVesta = data;
    }
    
    public void setAspectsChiron(boolean data)
    {
        aspectsChiron = data;
    }
    
    public void setAspectsAS(boolean data)
    {
        aspectsAS = data;
    }
    
    public void setAspectsMC(boolean data)
    {
        aspectsMC = data;
    }
    
    public void setShownAspect0(boolean data)
    {
        shownAspect0 = data;
    }
    
    public void setShownAspect1(boolean data)
    {
        shownAspect1 = data;
    }
    
    public void setShownAspect2(boolean data)
    {
        shownAspect2 = data;
    }
    
    public void setShownAspect3(boolean data)
    {
        shownAspect3 = data;
    }
    
    public void setShownAspect4(boolean data)
    {
        shownAspect4 = data;
    }
    
    public void setShownAspect5(boolean data)
    {
        shownAspect5 = data;
    }
    
    public void setShownAspect6(boolean data)
    {
        shownAspect6 = data;
    }
    
    public void setShownAspect7(boolean data)
    {
        shownAspect7 = data;
    }
    
    public void setShownAspect8(boolean data)
    {
        shownAspect8 = data;
    }
    
    public void setShownAspect9(boolean data)
    {
        shownAspect9 = data;
    }
    
    public void setShownAspect10(boolean data)
    {
        shownAspect10 = data;
    }
    
    public void setShownAspect11(boolean data)
    {
        shownAspect11 = data;
    }
    
    public void setShownAspect12(boolean data)
    {
        shownAspect12 = data;
    }
    
    public void setShownAspect13(boolean data)
    {
        shownAspect13 = data;
    }
    
    public void setShownAspect14(boolean data)
    {
        shownAspect14 = data;
    }
    
    public void setShownAspect15(boolean data)
    {
        shownAspect15 = data;
    }
    
    public void setShownAspect16(boolean data)
    {
        shownAspect16 = data;
    }
    
    public void setShownAspect17(boolean data)
    {
        shownAspect17 = data;
    }
    
    public void setChartSelectSingle(boolean data)
    {
        chartSelectSingle = data;
    }
    
    public void setChartReturnPrecess(boolean data)
    {
        chartReturnPrecess = data;
    }
    
    public void setLimitMag(double data)
    {
        limitMag = data;
    }
    
    public void setOrbLightLight(double data)
    {
        orbLightLight = data;
    }
    
    public void setOrbLightTell(double data)
    {
        orbLightTell = data;
    }
    
    public void setOrbLightOtherInd(double data)
    {
        orbLightOtherInd = data;
    }
    
    public void setOrbLightColl(double data)
    {
        orbLightColl = data;
    }
    
    public void setOrbLightVirtMax(double data)
    {
        orbLightVirtMax = data;
    }
    
    public void setOrbLightVirtMin(double data)
    {
        orbLightVirtMin = data;
    }
    
    public void setOrbTellTell(double data)
    {
        orbTellTell = data;
    }
    
    public void setOrbTellOtherInd(double data)
    {
        orbTellOtherInd = data;
    }
    
    public void setOrbTellColl(double data)
    {
        orbTellColl = data;
    }
    
    public void setOrbTellVirtMax(double data)
    {
        orbTellVirtMax = data;
    }
    
    public void setOrbTellVirtMin(double data)
    {
        orbTellVirtMin = data;
    }
    
    public void setOrbOtherIndOtherInd(double data)
    {
        orbOtherIndOtherInd = data;
    }
    
    public void setOrbOtherIndColl(double data)
    {
        orbOtherIndColl = data;
    }
    
    public void setOrbOtherIndVirtMax(double data)
    {
        orbOtherIndVirtMax = data;
    }
    
    public void setOrbOtherIndVirtMin(double data)
    {
        orbOtherIndVirtMin = data;
    }
    
    public void setOrbCollColl(double data)
    {
        orbCollColl = data;
    }
    
    public void setOrbCollVirtMax(double data)
    {
        orbCollVirtMax = data;
    }
    
    public void setOrbCollVirtMin(double data)
    {
        orbCollVirtMin = data;
    }
    
    public void setOrbVirtMaxVirtMax(double data)
    {
        orbVirtMaxVirtMax = data;
    }
    
    public void setOrbVirtMaxVirtMin(double data)
    {
        orbVirtMaxVirtMin = data;
    }
    
    public void setOrbVirtMinVirtMin(double data)
    {
        orbVirtMinVirtMin = data;
    }
    
    public void setDivMin(double data)
    {
        divMin = data;
    }
    
    public void setDivConjunction(double data)
    {
        divConjunction = data;
    }
    
    public void setDivSextile(double data)
    {
        divSextile = data;
    }
    
    public void setDivSquare(double data)
    {
        divSquare = data;
    }
    
    public void setDivTrine(double data)
    {
        divTrine = data;
    }
    
    public void setDivOpposition(double data)
    {
        divOpposition = data;
    }
    
    public void setOtherAspectValue(double data)
    {
        otherAspectValue = data;
    }
}
