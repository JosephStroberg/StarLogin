package StarLogin.Systeme;

import java.util.ArrayList;

/**
 *
 * @author Francois DESCHAMPS
 */
public class QueryDescription
{
    private int number;
    private final static String STR_WHERE = " WHERE ";
    private final static String STR_ORDER_BY = " ORDER BY ";
    private final static String STR_GROUP_BY = " GROUP BY ";
    private final static String STR_HAVING = " HAVING ";
    public final static String STR_FROM = " FROM ";
    private String name;
    private String sqlFrom;
    private String sqlWhere;
    private ArrayList fields = new ArrayList();
    private ArrayList columnNames = new ArrayList();
    private ArrayList types = new ArrayList();
    
    /** Creates a new instance of QueryDescription */
    public QueryDescription(int number, String name, String sqlFrom, String sqlWhere, ArrayList fields, ArrayList headers, ArrayList types)
    {
        this.number = number;
        this.name = name;
        this.sqlFrom = sqlFrom;
        this.sqlWhere = sqlWhere;
        this.fields = fields;
        this.columnNames = headers;
        this.types = types;
    }
    
    public ArrayList getFieldNames()
    {
        return fields;
    }
    
    public ArrayList getHeaders()
    {
        return columnNames;
    }

    public String getWhere()
    {
        return sqlWhere;
    }
    
    public String getFrom()
    {
        return sqlFrom;
    }
    
    public int getNumber()
    {
        return number;
    }

    public String getName()
    {
        return name;
    }

    public ArrayList getTypes()
    {
        return types;
    }
    //-----------------------------------------------------------------------------------------------------------------
    //Extract the HAVING part from an SQL string
    //Input: strSQL: the SQL string
    //Return:        the HAVING part of the string
    //-----------------------------------------------------------------------------------------------------------------
    public static String getHavingPart(String strSQL)
    {
        String strString = strSQL;
        int pos;

        pos = strString.indexOf(STR_HAVING);
        if ( pos >= 0 )
        {
            strString = strString.substring(pos);
            pos = strString.indexOf(STR_ORDER_BY);
            if ( pos >= 0 ) strString = strString.substring(0, pos);
            return strString;
        }
        else
        {
            return "";
        }
    }

    //-----------------------------------------------------------------------------------------------------------------
    //Extract the GROUP BY part from an SQL string
    //Input: strSQL: the SQL string
    //Return:        the GROUP BY part of the string
    //-----------------------------------------------------------------------------------------------------------------
    public static String getGroupingPart(String strSQL)
    {
        String strString = strSQL;
        int pos;

        pos = strString.indexOf(STR_GROUP_BY);
        if ( pos >= 0 )
        {
            strString = strString.substring(pos);
            pos = strString.indexOf(STR_HAVING);
            if ( pos < 0 ) pos = strString.indexOf(STR_ORDER_BY);
            if ( pos >= 0 ) strString = strString.substring(0, pos);
            return strString;
        }
        else
        {
            return "";
        }
    }

    //-----------------------------------------------------------------------------------------------------------------
    //Extract the ORDER BY part from an SQL string
    //Input: strSQL: the SQL string
    //Return:        the ORDER BY part of the string
    //-----------------------------------------------------------------------------------------------------------------
    public static String getOrderPart(String strSQL)
    {
        String strString = strSQL;
        int pos;

        pos = strString.indexOf(STR_ORDER_BY);
        if ( pos >= 0 )
        {
            return strString.substring(pos);
        }
        else
        {
            return "";
        }
    }

    //-----------------------------------------------------------------------------------------------------------------
    //Extract the WHERE part from an SQL string
    //Input: strSQL: the SQL string
    //Return:        the WHERE part of the string
    //-----------------------------------------------------------------------------------------------------------------
    public static String getWherePart(String strSQL)
    {
        String strString = strSQL;
        int pos;

        pos = strString.indexOf(STR_WHERE);
        if ( pos >= 0 )
        {
            strString = strString.substring(pos);
            pos = strString.indexOf(STR_GROUP_BY);
            if ( pos < 0 ) pos = strString.indexOf(STR_HAVING);
            if ( pos < 0 ) pos = strString.indexOf(STR_ORDER_BY);
            if ( pos >= 0 ) strString = strString.substring(0, pos);
            return strString;
        }
        else
        {
            return "";
        }
    }

    //-----------------------------------------------------------------------------------------------------------------
    //Extract the FROM part from an SQL string
    //Input: strSQL: the SQL string
    //Return:        the FROM part of the string
    //-----------------------------------------------------------------------------------------------------------------
    public static String getFromPart(String strSQL)
    {
        String strString = strSQL;
        int pos;

        pos = strString.indexOf(STR_FROM);
        if ( pos >= 0 )
        {
            strString = strString.substring(pos);
            pos = strString.indexOf(STR_WHERE);
            if ( pos < 0 ) pos = strString.indexOf(STR_GROUP_BY);
            if ( pos < 0 ) pos = strString.indexOf(STR_HAVING);
            if ( pos < 0 ) pos = strString.indexOf(STR_ORDER_BY);
            if ( pos >= 0 ) strString = strString.substring(0, pos);
            return strString;
        }
        else
        {
            return "";
        }
    }
}
