/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.Systeme;

import StarLogin.IHM.MainClass;
import java.io.*;
import java.sql.Blob;
import java.sql.SQLException;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.swing.ImageIcon;

/**
 *
 * @author francoisdeschamps
 */
public class BlobIconConv
{
    public static ImageIcon blob2Icon(Blob blob)
    {
        ImageIcon icon = null;

        if (blob == null)
        {
            return null;
        }

        InputStream in = null;

        try
        {
            in = blob.getBinaryStream();
        }
        catch (SQLException se)
        {
            MainClass.setMessage(se.getMessage());
        }

        if (in != null)
        {
            int size = -1;
            byte b[] = null;
            try
            {
                size = (int)blob.length();
                b = blob.getBytes(1l, size);
            }

            catch (java.sql.SQLException se)
            {
                MainClass.setMessage(se.getMessage());
            }

            /*try
            {
                size = in.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }*/

            OutputStream out = null;

            try
            {
                //String path = System.getProperty("user.home", ".");
                //out = new FileOutputStream(path + "/img.jpg");
                out = new FileOutputStream("img.jpg");
            }
            catch (java.io.FileNotFoundException fe)
            {
                MainClass.setMessage(fe.getMessage());
            }

            if (size > 0)
            {
                //byte b[] = new byte[size];

                try
                {
                    in.read(b);

                    if (out != null)
                    {
                        out.write(b);
                        icon = new ImageIcon(b);
                    }
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }
            }
        }

        return icon;
    }

    public static byte[] WriteBlob(Blob blob)
    {
        byte b[] = null;

        if (blob == null)
        {
            return null;
        }

        // String strOut = null;
        InputStream in = null;
        OutputStream out = null;

        try
        {
            in = blob.getBinaryStream();
        }
        catch (SQLException se)
        {
            MainClass.setMessage(se.getMessage());
        }

        if (in != null)
        {
            int size = -1;

            try
            {
                size = in.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }

            try
            {
                //String path = System.getProperty("user.home", ".");
                //out = new FileOutputStream(path + "/img.jpg");
                out = new FileOutputStream("img.jpg");
            }
            catch (java.io.FileNotFoundException fe)
            {
                MainClass.setMessage(fe.getMessage());
            }

            if (size > 0)
            {
                b = new byte[size];

                try
                {
                    in.read(b);

                    if (out != null)
                    {
                        out.write(b);

                        String strOut = new String(b, "ISO-8859-1");
                    }
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }
            }
        }

        return b;    // strOut;
    }

    public static Blob icon2Blob(ImageIcon icon)
    {
        if (icon == null)
        {
            return null;
        }

        FileInputStream fs = null;
        SerialBlob blob = null;

        try
        {
            fs = new FileInputStream(icon.toString());
        }
        catch (FileNotFoundException fe)
        {
            MainClass.setMessage(fe.getMessage());
        }

        if (fs != null)
        {
            int size = -1;

            try
            {
                size = fs.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }

            if (size > 0)
            {
                byte bytes[] = new byte[size];
                BufferedInputStream bis = new BufferedInputStream(fs);

                try
                {
                    bis.read(bytes);
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }

                try
                {
                    blob = new SerialBlob(bytes);
                }
                catch (SerialException se)
                {
                    MainClass.setMessage(se.getMessage());
                }
                catch (SQLException se)
                {
                    MainClass.setMessage(se.getMessage());
                }
            }
        }

        return (Blob) blob;
    }
}
