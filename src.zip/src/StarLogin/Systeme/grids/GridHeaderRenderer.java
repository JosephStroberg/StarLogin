/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.Systeme.grids;

import StarLogin.IHM.components.Options;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Francois
 */
public class GridHeaderRenderer implements TableCellRenderer
{
    //public MyRenderer(Font font, Color bkColor, Color fgColor, int align, int rownum, int colnum)
    public GridHeaderRenderer()
    {
    }

    @Override
    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row, int column)
    {
        JLabel jl;
        if (value == null)
            jl = new JLabel("");
        else
            jl = new JLabel(value.toString());
        Font font = table.getFont();
        font = new Font(font.getName(), font.getStyle(), font.getSize()+1);

        //Object cellVal = table.getValueAt(row, column);
        jl.setHorizontalAlignment(JLabel.CENTER);
        jl.setFont(new Font(font.getName(), Font.PLAIN, font.getSize()));
        jl.setBorder(new BevelBorder(BevelBorder.RAISED));
        jl.setOpaque(true);
        jl.setBackground(Options.getColor("TableHeader.background"));
        jl.setForeground(Options.getColor("TableHeader.foreground"));
        //jl.setBorder(javax.swing.BorderFactory.createLineBorder(Options.getColor("Table.GridColor")));
        return (jl);
    }
}
