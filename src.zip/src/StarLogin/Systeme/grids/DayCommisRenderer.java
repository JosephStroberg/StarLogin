/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.Systeme.grids;

import StarLogin.IHM.MainClass;
import StarLogin.IHM.components.Options;
import StarLogin.Systeme.AstroCalc.FTime;
import StarLogin.Systeme.Data.Record;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Francois
 */
public class DayCommisRenderer implements TableCellRenderer
{
    private int jour;
    
    //public MyRenderer(Font font, Color bkColor, Color fgColor, int align, int rownum, int colnum)
    public DayCommisRenderer(int jour)
    {
        this.jour = jour;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row, int column)
    {
        JLabel jl;
        if (value == null)
            jl = new JLabel("");
        else
            jl = new JLabel(value.toString());
        
        int rownb = table.getModel().getRowCount();
        
        Record jourouvrable = MainClass.starLoginManager.getRecord("SELECT ID,DEBUT,FIN FROM joursouvrables WHERE ID=" + (jour+1), "joursouvrables", "");
        String hopen = null2String(jourouvrable.getData(1));
        String hclose = null2String(jourouvrable.getData(2));
        
        FTime fto = new FTime(hopen);
        FTime ftc = new FTime(hclose);
        int ho = fto.getHour();
        int mno = fto.getMinute();
        int hc = ftc.getHour();
        int mnc = ftc.getMinute();
        int ideb;
        int ifin;
        
        if (rownb == 24)
        {
            ideb = ho;
            ifin = hc;
            if (mnc >= 0)
                ifin += 1;
        }
        else if (rownb == 48)
        {
            ideb = 2 * ho;
            ifin = 2 * hc;
            if (mno >= 30)
                ideb += 1;
            if (mnc >= 0)
            {
                if (mnc < 30)
                    ifin += 1;
                else
                    ifin += 2;
            }
        }
        else if (rownb == 96)
        {
            ideb = 4 * ho;
            ifin = 4 * hc;
            if (mno >= 15)
                ideb += 1;
            if (mno >= 30)
                ideb += 1;
            if (mno >= 45)
                ideb += 1;
            if (mnc >= 0)
            {
                if (mnc < 15)
                    ifin += 1;
                else if (mnc < 30)
                    ifin += 2;
                else if (mnc < 45)
                    ifin += 3;
                else
                    ifin += 4;
            }
        }
        else//144
        {
            ideb = 6 * ho;
            ifin = 6 * hc;
            if (mno >= 10)
                ideb += 1;
            if (mno >= 20)
                ideb += 1;
            if (mno >= 30)
                ideb += 1;
            if (mno >= 40)
                ideb += 1;
            if (mno >= 50)
                ideb += 1;
            if (mnc >= 0)
            {
                if (mnc < 10)
                    ifin += 1;
                else if (mnc < 20)
                    ifin += 2;
                else if (mnc < 30)
                    ifin += 3;
                else if (mnc < 40)
                    ifin += 4;
                else if (mnc < 50)
                    ifin += 5;
                else
                    ifin += 6;
            }
        }
        
        Font font = table.getFont();
        font = new Font(font.getName(), font.getStyle(), font.getSize() + 1);

        jl.setFont(font);
        if (isSelected)
            jl.setBackground(Options.getColor("Table.selectionBackground"));
        else
        {
            if (row >= ideb && row < ifin)
            {
                Color color = table.getBackground();
                int r = color.getRed();
                int b = color.getBlue();
                int g = color.getGreen();
                int sup1;
                int sup2;
                int sup3;
                int sup = 90;
                int div = 3;
                
                while (sup>0 && (b!=255 || r!=255 || g!=255))
                {
                    int i = 3;
                    if (r>255-sup/div && r<255)
                    {
                        sup1 = r - 235;
                        r = 255;
                        i-=1;
                    }
                    else if (r<=255-sup/div)
                    {
                        r += sup/div;
                        sup1 = 0;
                    }
                    else
                        sup1 = sup/div;
                    
                    if (b>235 && b<255)
                    {
                        sup2 = b - 235;
                        b = 255;
                        i-=1;
                    }
                    else if (b<=255-sup/div)
                    {
                        b += sup/div;
                        sup2 = 0;
                    }
                    else
                        sup2 = sup/div;
                    
                    if (g>255-sup/div && g<255)
                    {
                        sup3 = g - 235;
                        g = 255;
                        i-=1;
                    }
                    else if (g<=255-sup/div)
                    {
                        g += sup/div;
                        sup3 = 0;
                    }
                    else
                        sup3 = sup/div;
                    if (i == 0)
                        i = 1;
                    div = i;
                    sup = sup1 + sup2 + sup3;
                }
                
                color = new Color(r,g,b);
                jl.setBackground(color);
            }
            else
                jl.setBackground(table.getBackground());
        }
        jl.setOpaque(true);
        return (jl);
    }

    private String null2String(Object object)
    {
        String result;
        if (object == null)
        {
            result = MainClass.STIME_000000;
        }
        else
        {
            result = object.toString();
            if (result.equals(""))
                result = MainClass.STIME_000000;
        }
        return result;
    }
}
