package StarLogin.Systeme.grids;

import StarLogin.IHM.*;
import StarLogin.IHM.components.KeyType.KTLatitude;
import StarLogin.IHM.components.KeyType.KTLongitude;
import StarLogin.IHM.components.Options;
import StarLogin.Persistence.DataBaseRecords;
import StarLogin.Systeme.AstroCalc.FLatitude;
import StarLogin.Systeme.AstroCalc.FLongitude;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Francois DESCHAMPS
 */
public class TableSorter extends TableMap
{
    private int[] indexes;
    private final ArrayList sortingColumns = new ArrayList();
    private boolean ascending = true;
    private int compares;
    private int cellRow = 0;
    private int cellColumn = 0;
    private final JPopupMenu popMenu = new JPopupMenu();     //popup menu
    private TableData tableData;
    private JTable tblTable;
    //private String selectedColumn;
    private String selectedField;
    private String savedSelectedField;
    //private boolean bolZoomingText = false;
    private boolean bolSorting = true;
    private boolean bolRemoving = false;
    private int fieldSize = 255;
    public JTextField textField;  //used to edit a cell
    private JTextField txtLatitude;  //used to edit a cell
    private JTextField txtLongitude;  //used to edit a cell
    private boolean bolCodeSelection = false;
    private boolean selectable = false;
    private boolean deletable = false;
    private Window parentForm;
    private int saveRow = 0;
    private int saveCol = 0;
    //private int totalWidth = 0;
    private boolean keepVisible = false;
    private boolean canAdd = false;
    private boolean bMovingCol = false;
    private boolean bFromKey = false;
    private boolean bMousePressed = false;
    private boolean bSetting = true;
    private final int FIELDTEXT = 0;
    private final int FIELDLATITUDE = 1;
    private final int FIELDLONGITUDE = 2;
    private int fieldKind = FIELDTEXT;
    private int kc; //key code
    private int cp; //caret position
    private String latitude = "";
    private String longitude = "";

    public TableSorter()
    {
        indexes = new int[0]; // For consistency.
    }

    public TableSorter(boolean sorting)
    {
        this();
        bolSorting = sorting;
    }

    public TableSorter(TableModel model)
    {
        this();
        setModel(model);
    }

    public void setCanAdd(boolean data)
    {
        canAdd = data;
    }

    public TableSorter(Window parent)
    {
        this();
        parentForm = parent;
        createTextFields();
    }

    private void createTextFields()
    {
        textField = new JTextField();
        textField.setVisible(false);
        textField.setBorder(null);//javax.swing.BorderFactory.createLineBorder(new Color(Integer.valueOf(MainClass.getOptions().getData(1))),1));//.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        textField.setBackground(Options.getColor("TextField.background"));
        textField.setForeground(Options.getColor("TextField.foreground"));
        textField.setFont(new Font("Arial", Font.PLAIN, 12));

        txtLatitude = new JTextField();
        txtLatitude.setVisible(false);
        txtLatitude.setBorder(null);//javax.swing.BorderFactory.createLineBorder(new Color(Integer.valueOf(MainClass.getOptions().getData(1))),1));//.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txtLatitude.setBackground(Options.getColor("TextField.background"));
        txtLatitude.setForeground(Options.getColor("TextField.foreground"));
        txtLatitude.setFont(new Font("Arial", Font.PLAIN, 12));
        txtLatitude.setToolTipText(MainClass.bundle.getString("LatitudeSudNeg"));
        txtLatitude.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                FLatitude l = new FLatitude(txtLatitude.getText());
                String sText = l.getLatitude();
                txtLatitude.setText(sText);
                if (!bFromKey)
                {
                    setData(txtLatitude);
                }
            }
        });

        txtLatitude.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                bFromKey = false;
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                    cp = txtLatitude.getCaretPosition();
                }
                if (kc == KeyEvent.VK_ESCAPE)
                {
                    txtLatitude.setText(latitude);
                }
                else
                {
                    KTLatitude lng;
                    if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                    {
                        lng = new KTLatitude(evt, txtLatitude, kc);
                    }
                    else if ((evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_ENTER) || (evt.getKeyCode() == KeyEvent.VK_LEFT))
                    {
                        savedSelectedField = tableData.getField(saveCol);// tableData.getColumnName(saveCol);
                        int row = saveRow;
                        int col = saveCol;

                        bFromKey = true;

                        if ((evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_ENTER))
                        {
                            if (col < tableData.getColumnCount() - 1)
                            {
                                int col2 = getNextFree(col);
                                if (col2 >= 0)
                                {
                                    keepVisible = isEditableCell(col2);
                                    col = col2;
                                }
                            }
                        }
                        else if (evt.getKeyCode() == KeyEvent.VK_LEFT)
                        {
                            if (col > 1)
                            {
                                int col2 = getPrevFree(col);
                                if (col2 >= 0)
                                {
                                    keepVisible = isEditableCell(col2);
                                    col = col2;
                                }
                            }
                        }
                        else
                        {
                            keepVisible = false;
                            textField.setVisible(false);
                        }
                        setData(txtLatitude);
                        evt.consume();

                        String sValue = String.valueOf(tblTable.getValueAt(row, col));
                        if (sValue.equals("null"))
                        {
                            sValue = "";
                        }
                        setValue(col, sValue);
                        String header = tblTable.getColumnModel().getColumn(col).getHeaderValue().toString();
                        if (!header.startsWith("_"))
                        {
                            EditCell(row, col);
                        }
                        cellRow = row;
                        cellColumn = col;
                        saveRow = row;
                        saveCol = col;
                        savedSelectedField = tableData.getField(col);
                        selectedField = savedSelectedField;
                    }
                    else if (kc == KeyEvent.VK_ESCAPE)
                    {
                        keepVisible = false;
                        txtLatitude.setVisible(false);
                    }
                    else if ((kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_UP))
                    {
                        bFromKey = false;
                    }
                }
            }

            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                KTLatitude lat = new KTLatitude(evt, txtLatitude, kc);
                if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
                    txtLatitude.setCaretPosition(cp-1);
            }
        });

        txtLongitude = new JTextField();
        txtLongitude.setVisible(false);
        txtLongitude.setBorder(null);//javax.swing.BorderFactory.createLineBorder(new Color(Integer.valueOf(MainClass.getOptions().getData(1))),1));//.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txtLongitude.setBackground(Options.getColor("TextField.background"));
        txtLongitude.setForeground(Options.getColor("TextField.foreground"));
        txtLongitude.setFont(new Font("Arial", Font.PLAIN, 12));
        txtLongitude.setToolTipText(MainClass.bundle.getString("LongitudeEstNeg"));

        String defaultVal = "";
        FLatitude flat = new FLatitude(defaultVal);
        defaultVal = flat.getLatitude();
        txtLatitude.setText(flat.getLatitude());
        FLongitude flong = new FLongitude(defaultVal);
        txtLongitude.setText(flong.getLongitude());
        txtLongitude.addFocusListener(new java.awt.event.FocusAdapter()
        {
            @Override
            public void focusLost(java.awt.event.FocusEvent evt)
            {
                FLongitude l = new FLongitude(txtLongitude.getText());
                String sText = l.getLongitude();
                txtLongitude.setText(sText);
                if (!bFromKey)
                {
                    setData(txtLongitude);
                }
            }
        });
        txtLongitude.addKeyListener(new java.awt.event.KeyAdapter()
        {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                bFromKey = false;
                if (evt.getKeyCode() != KeyEvent.VK_ALT)
                {
                    kc = evt.getKeyCode();
                    cp = txtLongitude.getCaretPosition();
                }
                if (kc == KeyEvent.VK_ESCAPE)
                {
                    txtLongitude.setText(longitude);
                }
                else
                {
                    KTLongitude lng;
                    if (kc == KeyEvent.VK_DOWN || kc == KeyEvent.VK_UP || kc == KeyEvent.VK_DELETE || kc == KeyEvent.VK_BACK_SPACE)
                    {
                        lng = new KTLongitude(evt, txtLongitude, kc);
                    }
                    else if ((evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_ENTER) || (evt.getKeyCode() == KeyEvent.VK_LEFT))
                    {
                        savedSelectedField = tableData.getField(saveCol);// tableData.getColumnName(saveCol);
                        int row = saveRow;
                        int col = saveCol;

                        bFromKey = true;

                        if ((evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_ENTER))
                        {
                            if (col < tableData.getColumnCount() - 1)
                            {
                                int col2 = getNextFree(col);
                                if (col2 >= 0)
                                {
                                    keepVisible = isEditableCell(col2);
                                    col = col2;
                                }
                            }
                        }
                        else if (evt.getKeyCode() == KeyEvent.VK_LEFT)
                        {
                            if (col > 1)
                            {
                                int col2 = getPrevFree(col);
                                if (col2 >= 0)
                                {
                                    keepVisible = isEditableCell(col2);
                                    col = col2;
                                }
                            }
                        }
                        else
                        {
                            keepVisible = false;
                            txtLongitude.setVisible(false);
                        }
                        setData(txtLongitude);
                        evt.consume();

                        String sValue = String.valueOf(tblTable.getValueAt(row, col));
                        if (sValue.equals("null"))
                        {
                            sValue = "";
                        }
                        setValue(col, sValue);
                        String header = tblTable.getColumnModel().getColumn(col).getHeaderValue().toString();
                        if (!header.startsWith("_"))
                        {
                            EditCell(row, col);
                        }
                        cellRow = row;
                        cellColumn = col;
                        saveRow = row;
                        saveCol = col;
                        savedSelectedField = tableData.getField(col);
                        selectedField = savedSelectedField;
                    }
                    else if (kc == KeyEvent.VK_ESCAPE)
                    {
                        keepVisible = false;
                        txtLongitude.setVisible(false);
                    }
                    else if ((kc != KeyEvent.VK_DOWN) && (kc != KeyEvent.VK_UP))
                    {
                        bFromKey = false;
                    }
                }
            }

            @Override
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                KTLongitude lng = new KTLongitude(evt, txtLongitude, kc);
                if (kc == KeyEvent.VK_BACK_SPACE && cp>0)
                    txtLongitude.setCaretPosition(cp-1);
            }
        });
    }

    private void setValue(int col, String sValue)
    {
        textField.setVisible(false);
        txtLatitude.setVisible(false);
        txtLongitude.setVisible(false);
        if (tableData.getField(col).contains("LONGITUDE"))
        {
            FLongitude flong = new FLongitude(sValue);
            sValue = flong.getLongitude();
            longitude = sValue;
            txtLongitude.setText(sValue);
            txtLongitude.setVisible(keepVisible);
            fieldKind = FIELDLONGITUDE;
        }
        else if (tableData.getField(col).contains("LATITUDE"))
        {
            FLatitude flat = new FLatitude(sValue);
            sValue = flat.getLatitude();
            latitude = sValue;
            txtLatitude.setText(sValue);
            txtLatitude.setVisible(keepVisible);
            fieldKind = FIELDLATITUDE;
        }
        else
        {
            textField.setText(sValue);
            textField.setVisible(keepVisible);
            fieldKind = FIELDTEXT;
        }
    }

    public TableSorter(boolean sorting, Window parent)
    {
        this(parent);
        bolSorting = sorting;
    }

    public TableSorter(TableModel model, Window parent)
    {
        this(parent);
        setModel(model);
    }

    @Override
    public final void setModel(TableModel model)
    {
        super.setModel(model);
        tableData = (TableData) model;
    }

    public void setPanelName(String panelName)
    {
        //this.panelName = panelName;
        TableCellRenderer rend = new GridRenderer();
        for (int i = 0; i < tblTable.getColumnCount(); i++)
        {
            tblTable.getColumnModel().getColumn(i).setCellRenderer(rend);
        }
    }

    public int compareRowsByColumn(int row1, int row2, int column)
    {
        Class type = model.getColumnClass(column);
        TableModel data = model;

        // Check for nulls
        Object o1 = data.getValueAt(row1, column);
        Object o2 = data.getValueAt(row2, column);

        // If both values are null return 0
        if (o1 == null && o2 == null)
        {
            return 0;
        }
        else if (o1 == null)
        { // Define null less than everything.
            return -1;
        }
        else if (o2 == null)
        {
            return 1;
        }

        /*
         * We copy all returned values from the getValue call in case an optimised model is reusing
         * one object to return many values. The Number subclasses in the JDK are immutable and so
         * will not be used in this way but other subclasses of Number might want to do this to save
         * space and avoid unnecessary heap allocation.
         */
        if (type.getSuperclass() == java.lang.Number.class)
        {
            Number n1 = (Number) data.getValueAt(row1, column);
            double d1 = n1.doubleValue();
            Number n2 = (Number) data.getValueAt(row2, column);
            double d2 = n2.doubleValue();

            if (d1 < d2)
            {
                return -1;
            }
            else if (d1 > d2)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (type == Date.class)
        {
            Date d1 = (Date) data.getValueAt(row1, column);
            long n1 = d1.getTime();
            Date d2 = (Date) data.getValueAt(row2, column);
            long n2 = d2.getTime();

            if (n1 < n2)
            {
                return -1;
            }
            else if (n1 > n2)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (type == String.class)
        {
            String s1 = (String) data.getValueAt(row1, column);
            String s2 = (String) data.getValueAt(row2, column);
            int result = s1.compareTo(s2);

            if (result < 0)
            {
                return -1;
            }
            else if (result > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (type == Boolean.class)
        {
            Boolean bool1 = (Boolean) data.getValueAt(row1, column);
            boolean b1 = bool1.booleanValue();
            Boolean bool2 = (Boolean) data.getValueAt(row2, column);
            boolean b2 = bool2.booleanValue();

            if (b1 == b2)
            {
                return 0;
            }
            else if (b1) // Define false < true
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }
        else
        {
            Object v1 = data.getValueAt(row1, column);
            String s1 = v1.toString();
            Object v2 = data.getValueAt(row2, column);
            String s2 = v2.toString();
            int result = s1.compareTo(s2);

            if (result < 0)
            {
                return -1;
            }
            else if (result > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }

    public int compare(int row1, int row2)
    {
        compares++;
        for (int level = 0; level < sortingColumns.size(); level++)
        {
            Integer column = (Integer) sortingColumns.get(level);
            int result = compareRowsByColumn(row1, row2, column.intValue());
            if (result != 0)
            {
                return ascending ? result : -result;
            }
        }
        return 0;
    }

    public void reallocateIndexes()
    {
        int rowCount = model.getRowCount();

        // Set up a new array of indexes with the right number of elements
        // for the new data model.
        indexes = new int[rowCount];

        // Initialise with the identity mapping.
        for (int row = 0; row < rowCount; row++)
        {
            indexes[row] = row;
        }
    }

    @Override
    public void tableChanged(TableModelEvent e)
    {
        reallocateIndexes();
        super.tableChanged(e);
    }

    public void checkModel()
    {
        if (indexes.length != model.getRowCount())
        {
            MainClass.setMessage("Sorter not informed of a change in model.");
        }
    }

    public void sort(Object sender)
    {
        checkModel();

        compares = 0;
        if (tableData.getUpdatable() == false)
        {
            shuttlesort((int[]) indexes.clone(), indexes, 0, indexes.length);
        }
        else
        {
            shuttlesort((int[]) indexes.clone(), indexes, 0, indexes.length - 1);
        }
    }

    public void n2sort()
    {
        for (int i = 0; i < getRowCount(); i++)
        {
            for (int j = i + 1; j < getRowCount(); j++)
            {
                if (compare(indexes[i], indexes[j]) == -1)
                {
                    swap(i, j);
                }
            }
        }
    }

    public void shuttlesort(int[] from, int[] to, int low, int high)
    {
        if (high - low < 2)
        {
            return;
        }
        int middle = (low + high) / 2;
        shuttlesort(to, from, low, middle);
        shuttlesort(to, from, middle, high);

        int p = low;
        int q = middle;

        /*
         * This is an optional short-cut; at each recursive call, check to see if the elements in
         * this subset are already ordered. If so, no further comparisons are needed; the sub-array
         * can just be copied. The array must be copied rather than assigned otherwise sister calls
         * in the recursion might get out of sinc. When the number of elements is three they are
         * partitioned so that the first set, [low, mid), has one element and and the second, [mid,
         * high), has two. We skip the optimisation when the number of elements is three or less as
         * the first compare in the normal merge will produce the same sequence of steps. This
         * optimisation seems to be worthwhile for partially ordered lists but some analysis is
         * needed to find out how the performance drops to Nlog(N) as the initial order diminishes -
         * it may drop very quickly.
         */
        if (high - low >= 4 && compare(from[middle - 1], from[middle]) <= 0)
        {
            System.arraycopy(from, low, to, low, high - low);
            return;
        }

        // A normal merge.
        for (int i = low; i < high; i++)
        {
            if (q >= high || (p < middle && compare(from[p], from[q]) <= 0))
            {
                to[i] = from[p++];
            }
            else
            {
                to[i] = from[q++];
            }
        }
    }

    public void swap(int i, int j)
    {
        int tmp = indexes[i];
        indexes[i] = indexes[j];
        indexes[j] = tmp;
    }

    @Override
    public Object getValueAt(int aRow, int aColumn)
    {
        checkModel();
        return model.getValueAt(indexes[aRow], aColumn);
    }

    @Override
    public void setValueAt(Object aValue, int aRow, int aColumn)
    {
        checkModel();
        model.setValueAt(aValue, indexes[aRow], aColumn);
    }

    public void sortByColumn(int column)
    {
        sortByColumn(column);
    }

    @SuppressWarnings("unchecked")
    public void sortByColumn(int column, boolean ascending)
    {
        this.ascending = ascending;
        sortingColumns.clear();
        sortingColumns.add(new Integer(column));
        sort(this);
        super.tableChanged(new TableModelEvent(this));
    }

    public JTable getTable()
    {
        return tblTable;
    }

    public void setTable(JTable table)
    {
        tblTable = table;
        tblTable.add(textField);
        tblTable.setComponentZOrder(textField, 0);
        tblTable.add(txtLatitude);
        tblTable.setComponentZOrder(txtLatitude, 0);
        tblTable.add(txtLongitude);
        tblTable.setComponentZOrder(txtLongitude, 0);
    }

    public void addListenersAndPopup()
    {
        addMouseListenerToHeaderInTable();
        addMouseListenerToCellsInTable();
        if ((tableData.getUpdatable() == true) || (tableData.getDelete() == true))
        {
            addContextMenu();
            if (tableData.getUpdatable() == true)
            {
                addCellEditorListener();
            }
        }
        else
        {
            //addMouseMotionListener();
        }

        if (selectable == true)
        {
            DefaultListSelectionModel listModel = (DefaultListSelectionModel) tblTable.getSelectionModel();
            ListSelectionListener listSelectionListener = new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (bolCodeSelection == false)
                    {
                        if (parentForm instanceof ListeClientForm)
                        {
                            /*if (bDone)
                            {
                                bDone = false;
                                return;
                            }*/
                            int rows[] = tblTable.getSelectedRows();
                            if (rows.length == 1)
                            {
                                cellRow = tblTable.getSelectedRow();
                                if (cellRow < tblTable.getRowCount())
                                {
                                    //bDone = true;
                                    ((ListeClientForm) parentForm).bolClickFromGrid = true;
                                    ((ListeClientForm) parentForm).showClient(cellRow + 1);
                                }
                            }
                        }
                        else if (parentForm instanceof ListeRdvForm)
                        {
                            /*if (bDone)
                            {
                                bDone = false;
                                return;
                            }*/
                            int rows[] = tblTable.getSelectedRows();
                            if (rows.length == 1)
                            {
                                cellRow = tblTable.getSelectedRow();
                                if (cellRow < tblTable.getRowCount())
                                {
                                    //bDone = true;
                                    ((ListeRdvForm) parentForm).bolClickFromGrid = true;
                                    ((ListeRdvForm) parentForm).showRdv(cellRow + 1);
                                }
                            }
                        }
                        else if (parentForm instanceof ListeEventForm)
                        {
                            /*if (bDone)
                            {
                                bDone = false;
                                return;
                            }*/
                            int rows[] = tblTable.getSelectedRows();
                            if (rows.length == 1)
                            {
                                cellRow = tblTable.getSelectedRow();
                                if (cellRow < tblTable.getRowCount())
                                {
                                    //bDone = true;
                                    ((ListeEventForm) parentForm).bolClickFromGrid = true;
                                    ((ListeEventForm) parentForm).showEvent(cellRow + 1);//showSelected();//Record(cellRow + 1);
                                }
                            }
                        }
                        /*
                         * else if (parentForm instanceof DialogTaxes) { if (bDone) { bDone = false;
                         * return; } int rows[] = tblTable.getSelectedRows(); if (rows.length == 1)
                         * { cellRow = tblTable.getSelectedRow(); if (cellRow <
                         * tblTable.getRowCount()) { bDone = true; ((DialogTaxes)
                         * parentForm).bolClickFromGrid = true; ((DialogTaxes)
                         * parentForm).showRecord(cellRow + 1); } } }
                         */
                        else if (parentForm instanceof DialogPlaces)
                        {
                            /*if (bDone)
                            {
                                bDone = false;
                                return;
                            }*/
                            int rows[] = tblTable.getSelectedRows();
                            if (rows.length == 1)
                            {
                                cellRow = tblTable.getSelectedRow();
                                if (cellRow < tblTable.getRowCount())
                                {
                                    //bDone = true;
                                    ((DialogPlaces) parentForm).bolClickFromGrid = true;
                                    ((DialogPlaces) parentForm).showRecord(cellRow + 1);
                                }
                            }
                        }
                    }
                }
            };
            listModel.addListSelectionListener(listSelectionListener);
        }
    }

    public void setSelectable(boolean data)
    {
        selectable = data;
    }

    public void setDeletable(boolean data)
    {
        deletable = data;
    }

    public void SetTableColumnWidth()
    {
        String fenetre = "";
        String composant = "defaut";
        /*
         * if (parentForm instanceof DialogTaxes) { fenetre = "DialogTaxes"; } else
         */
        if (parentForm instanceof DialogPlaces)
        {
            fenetre = "DialogPlaces";
        }
        /*
         * else if (parentForm instanceof GestionStatusFactureForm) { fenetre =
         * "GestionStatusFactureForm"; }
         */
        else if (parentForm instanceof ListeClientForm)
        {
            fenetre = "ListeClientForm";
        }
        else if (parentForm instanceof ListeRdvForm || parentForm instanceof DialogWarnRdvs)
        {
            fenetre = "ListeRdvForm";
        }
        else if (parentForm instanceof ListeEventForm)
        {
            fenetre = "ListeEventForm";
        }
        /*
         * else if (parentForm instanceof MoyensPaiementForm) { fenetre = "MoyensPaiementForm"; }
         */

        for (int i = 0; i < tblTable.getColumnCount(); i++)
        {
            String colName = tableData.getColumnName(i);
            String colField = tableData.getField(i);
            if (colField.equals(DataBaseRecords.HDFORMAT))
            {
                colField = "HEURE_DEBUT";
            }
            else if (colField.equals(DataBaseRecords.HFFORMAT))
            {
                colField = "HEURE_FIN";
            }
            else if (colField.equals(DataBaseRecords.T2SURT1X))
            {
                colField = "T2SURT1";
            }
            if (colName.startsWith("_"))
            {
                tblTable.getColumn(colName).setMinWidth(0);
                tblTable.getColumn(colName).setPreferredWidth(0);
                tblTable.getColumn(colName).setWidth(0);
                tblTable.getColumn(colName).setMaxWidth(0);
            }
            else
            {
                String colWidth = MainClass.starLoginManager.getStringFieldValue("option_", "VALEUR", " WHERE WINDOW_='" + fenetre + "' AND COMPONENT='" + composant + "' AND PROPERTY='" + colField.replace("'", "''") + "'");
                if (colWidth == null || colWidth.equals("") || colWidth.equals("-1"))
                {
                    colWidth = "100";
                }
                int w = Integer.valueOf(colWidth).intValue();
                tblTable.getColumn(colName).setMinWidth(10);
                tblTable.getColumn(colName).setPreferredWidth(w);
                tblTable.getColumn(colName).setWidth(w);
                tblTable.getColumn(colName).setMaxWidth(w * 5);
                /*
                 * int s = tableData.getSize(i); int s2 = colName.length(); if (s2 > s) s = s2; int
                 * w = tblTable.getFont().getSize(); int max = Math.max(50, (int)((s * w) / 1.85));
                 * if (max > 150) { max = 150; }
                 *
                 * if (parentForm instanceof DialogTaxes) { if
                 * (colName.equals(MainClass.bundle.getString("schemataxeNOM1"))||colName.equals(MainClass.bundle.getString("schemataxeNOM2")))
                 * max /=2; else
                 * if(colName.equals(MainClass.bundle.getString("schemataxeTAUX1"))||colName.equals(MainClass.bundle.getString("schemataxeTAUX2")))
                 * max *=1.8; else
                 * if(colName.equals(MainClass.bundle.getString("schemataxeT2SURT1"))) max *=2; }
                 * else if (parentForm instanceof ProduitsACommander) { if
                 * (colName.equals(MainClass.bundle.getString("clientCOMMANDER"))) { max *= 3; } }
                 *
                 * if (max > 10) tblTable.getColumn(tblTable.getColumnName(i)).setMinWidth(10); else
                 * tblTable.getColumn(tblTable.getColumnName(i)).setMinWidth(max); max =
                 * (int)(max*multi);
                 * tblTable.getColumn(tblTable.getColumnName(i)).setPreferredWidth(max);
                 * tblTable.getColumn(tblTable.getColumnName(i)).setWidth(max);
                 * tblTable.getColumn(tblTable.getColumnName(i)).setMaxWidth(400); totalWidth +=
                 * max;
                 */

            }
        }
        bSetting = false;
    }

    /*public int getWidth()
    {
        return totalWidth;
    }*/

    private void addMouseListenerToHeaderInTable()
    {
        if (bolSorting == true)
        {
            final TableSorter sorter = this;
            tblTable.setColumnSelectionAllowed(false);
            MouseAdapter listMouseListener = new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                }

                @Override
                public void mousePressed(MouseEvent e)
                {
                    bMousePressed = true;
                }

                @Override
                public void mouseReleased(MouseEvent e)
                {
                    if (bMousePressed == false)
                        return;
                    bMousePressed = false;
                    TableColumnModel columnModel = tblTable.getColumnModel();
                    int viewColumn = columnModel.getColumnIndexAtX(e.getX());
                    int column = tblTable.convertColumnIndexToModel(viewColumn);
                    if (e.getClickCount() == 1 && column != -1)
                    {
                        //MainClass.setMessage("Sorting ...");
                        int shiftPressed = e.getModifiers() & InputEvent.SHIFT_MASK;
                        int ctrlPressed = e.getModifiers() & InputEvent.CTRL_MASK;
                        boolean ascending = (shiftPressed == 0) && (ctrlPressed == 0);
                        sorter.sortByColumn(column, ascending);
                        if (parentForm instanceof ListeClientForm)
                        {
                            if (bMovingCol == false)
                            {
                                String descending = "";
                                if (ascending == false)
                                {
                                    descending = " DESC";
                                }
                                String name = tableData.getField(column);
                                ((ListeClientForm) parentForm).setOrder(" ORDER BY ".concat(name).concat(descending));
                            }
                        }
                        else if (parentForm instanceof ListeRdvForm)
                        {
                            if (bMovingCol == false)
                            {
                                String descending = "";
                                if (ascending == false)
                                {
                                    descending = " DESC";
                                }
                                //TableColumn tblcol = columnModel.getColumn(column);
                                String name = tableData.getField(column);
                                ((ListeRdvForm) parentForm).setOrder(" ORDER BY ".concat(name).concat(descending));
                            }
                        }
                        else if (parentForm instanceof DialogWarnRdvs)
                        {
                            if (bMovingCol == false)
                            {
                                String descending = "";
                                if (ascending == false)
                                {
                                    descending = " DESC";
                                }
                                //TableColumn tblcol = columnModel.getColumn(column);
                                String name = tableData.getField(column);
                                ((DialogWarnRdvs) parentForm).setOrder(" ORDER BY ".concat(name).concat(descending));
                            }
                        }
                        else if (parentForm instanceof ListeEventForm)
                        {
                            if (bMovingCol == false)
                            {
                                String descending = "";
                                if (ascending == false)
                                {
                                    descending = " DESC";
                                }
                                //TableColumn tblcol = columnModel.getColumn(column);
                                String name = tableData.getField(column);
                                ((ListeEventForm) parentForm).setOrder(" ORDER BY ".concat(name).concat(descending));
                            }
                        }
                    }
                }
            };
            JTableHeader th = tblTable.getTableHeader();
            th.addMouseListener(listMouseListener);
        }
    }

    private void addContextMenu()
    {
        if (deletable == false)
        {
            return;
        }
        // add a popup menu

        // item of the menu: to delete the selected rows
        JMenuItem jMenuItem1 = new JMenuItem();
        jMenuItem1.setText(MainClass.bundle.getString("RemoveSelectedRows"));
        jMenuItem1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                int rows[] = tblTable.getSelectedRows();
                if (rows.length > 0)
                {
                    for (int i = rows.length - 1; i >= 0; i--)
                    {
                        if ((rows[i] < tableData.getRowCount() - 1 && canAdd == true) || (rows[i] < tableData.getRowCount() && canAdd == false))
                        {
                            bolRemoving = true;

                            //if (parentForm instanceof DialogTaxes)
                            //    ((DialogTaxes) parentForm).removeFromGrid(rows[i] + 1);
                            //else if (parentForm instanceof MoyensPaiementForm)
                            //    ((MoyensPaiementForm) parentForm).removeFromGrid(rows[i] + 1);
                            if (parentForm instanceof ListeRdvForm)
                            {
                                ((ListeRdvForm) parentForm).removeFromGrid(rows[i] + 1);
                            }
                            else if (parentForm instanceof ListeClientForm)
                            {
                                ((ListeClientForm) parentForm).removeFromGrid(rows[i] + 1);
                            }
                            else if (parentForm instanceof ListeEventForm)
                            {
                                ((ListeEventForm) parentForm).removeFromGrid(rows[i] + 1);
                            }
                            else if (parentForm instanceof DialogPlaces)
                            {
                                ((DialogPlaces) parentForm).removeFromGrid(rows[i] + 1);
                            }
                        }
                    }
                }
                //if (parentForm instanceof DialogTaxes)
                //    ((DialogTaxes) parentForm).setRow();
                //else if (parentForm instanceof MoyensPaiementForm)
                //    ((MoyensPaiementForm) parentForm).setRow();
                if (parentForm instanceof ListeRdvForm)
                {
                    ((ListeRdvForm) parentForm).setRow();
                }
                else if (parentForm instanceof ListeClientForm)
                {
                    ((ListeClientForm) parentForm).setRow();
                }
                else if (parentForm instanceof ListeEventForm)
                {
                    ((ListeEventForm) parentForm).setRow();
                }
                else if (parentForm instanceof DialogPlaces)
                {
                    ((DialogPlaces) parentForm).setRow();
                }
            }
        });

        popMenu.add(jMenuItem1);
    }

    public int getSelectedRow()
    {
        return cellRow;
    }

    public void setSelectedRow(int row)
    {
        bolCodeSelection = true;
        cellRow = row - 1;
        tblTable.clearSelection();
        if ((cellRow < tblTable.getModel().getRowCount()) && (cellRow >= 0))
        {
            tblTable.setRowSelectionInterval(cellRow, cellRow);
        }
        bolCodeSelection = false;
    }

    private void addMouseListenerToCellsInTable()
    {
        //if (tableData.getUpdatable())
        {
            TableColumnModel colModel = tblTable.getColumnModel();
            colModel.addColumnModelListener(new TableColumnModelListener()
            {
                @Override
                public void columnMoved(TableColumnModelEvent e)
                {
                    if (e.getFromIndex() == 0 || e.getToIndex() == 0)
                    {
                        bMovingCol = false;
                        return;
                    }
                    if (e.getFromIndex() != e.getToIndex())
                    {
                        textField.setVisible(false);
                        txtLatitude.setVisible(false);
                        txtLongitude.setVisible(false);
                        if (parentForm instanceof ListeClientForm)
                        {
                            ((ListeClientForm) parentForm).saveColOrder();
                        }
                        else if (parentForm instanceof ListeRdvForm)
                        {
                            ((ListeRdvForm) parentForm).saveColOrder();
                        }
                        else if (parentForm instanceof ListeEventForm)
                        {
                            ((ListeEventForm) parentForm).saveColOrder();
                        }
                        bMovingCol = true;
                    }
                    else if (bMousePressed == false)
                    {
                        bMovingCol = false;
                    }
                }

                @Override
                public void columnAdded(TableColumnModelEvent e)
                {
                }

                @Override
                public void columnRemoved(TableColumnModelEvent e)
                {
                }

                @Override
                public void columnMarginChanged(ChangeEvent e)
                {
                    TableColumnModel columnModel = tblTable.getColumnModel();//(TableColumnModel)e.getSource();
                    
                    if (bSetting)
                    {
                        return;
                    }
                    if (textField.isVisible() || txtLatitude.isVisible() ||txtLongitude.isVisible())
                    {
                        int w = columnModel.getColumn(cellColumn).getWidth() - 1;
                        if (w < 0)
                        {
                            return;
                        }
                        Rectangle rect = tblTable.getCellRect(cellRow, cellColumn, true);
                        Point pt = new Point(0, 0);
                        pt.setLocation(rect.getX(), rect.getY());
                        if (textField.isVisible())
                        {
                            textField.setLocation(pt);
                            textField.setPreferredSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            textField.setSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            textField.setMinimumSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                        }
                        else if (txtLatitude.isVisible())
                        {
                            txtLatitude.setLocation(pt);
                            txtLatitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            txtLatitude.setSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            txtLatitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                        }
                        else if (txtLongitude.isVisible())
                        {
                            txtLongitude.setLocation(pt);
                            txtLongitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            txtLongitude.setSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                            txtLongitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(cellRow)));
                        }
                    }
                    
                    for (int i = 1; i < columnModel.getColumnCount(); i++)
                    {
                        int w = columnModel.getColumn(i).getWidth();
                        String colName = columnModel.getColumn(i).getHeaderValue().toString();
                        if (w > 0 && !colName.startsWith("_"))
                        {
                            String fenetre = "";
                            String composant = "defaut";
                            String colField = tableData.getField(i);

                            if (colField.equals(DataBaseRecords.HDFORMAT))
                            {
                                colField = "HEURE_DEBUT";
                            }
                            else if (colField.equals(DataBaseRecords.HFFORMAT))
                            {
                                colField = "HEURE_FIN";
                            }
                            else if (colField.equals(DataBaseRecords.T2SURT1X))
                            {
                                colField = "T2SURT1";
                            }
                            if (!colField.equals("ID"))
                            {                            
                                if (parentForm instanceof ListeClientForm)
                                {
                                    fenetre = "ListeClientForm";
                                }
                                else if (parentForm instanceof ListeRdvForm || parentForm instanceof DialogWarnRdvs)
                                {
                                    fenetre = "ListeRdvForm";
                                }
                                else if (parentForm instanceof ListeEventForm)
                                {
                                    fenetre = "ListeEventForm";
                                }
                                MainClass.starLoginManager.updateDataBase("UPDATE option_ SET VALEUR='" + w + "' WHERE WINDOW_='" + fenetre + "' AND COMPONENT='" + composant + "' AND PROPERTY='" + colField + "'");
                            }
                        }
                        else
                        {
                            if (colName.startsWith("_"))
                            {
                                columnModel.getColumn(i).setWidth(0);
                            }
                        }
                    }
                }

                @Override
                public void columnSelectionChanged(ListSelectionEvent e)
                {
                    if (bMovingCol && bMousePressed == false)
                    {

                        if (parentForm instanceof ListeClientForm)
                        {
                            ((ListeClientForm) parentForm).refreshRecord();
                        }
                        else if (parentForm instanceof ListeRdvForm)
                        {
                            ((ListeRdvForm) parentForm).refreshRecord();
                        }
                        else if (parentForm instanceof ListeEventForm)
                        {
                            ((ListeEventForm) parentForm).refreshRecord();
                        }

                    }
                }
            });
        }

        MouseAdapter listMouseListener = new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent e)
            {
                if (e.getButton() == 3)
                {
                    popMenu.show(tblTable, e.getX(), e.getY());
                    textField.setVisible(false);
                    txtLatitude.setVisible(false);
                    txtLongitude.setVisible(false);
                }
                else if (tableData.getUpdatable() == true)
                {
                    if (e.getButton() == 1)
                    {
                        TableColumnModel columnModel = tblTable.getColumnModel();
                        int viewColumn = columnModel.getColumnIndexAtX(e.getX());
                        int column = tblTable.convertColumnIndexToModel(viewColumn);
                        String columnName = tableData.getField(column);
                        Point pt = new Point(0, 0);
                        pt.setLocation(e.getX(), e.getY());
                        int row = tblTable.rowAtPoint(pt);
                        cellRow = row;
                        cellColumn = viewColumn;
                        saveRow = cellRow;
                        saveCol = cellColumn;

                        //on interdit de mondifier les colonnes magasin et Code_barre
                        /*
                         * if (columnName.equals("MAGID") || (columnName.equals("CODE_BARRE") &&
                         * !(parentForm instanceof CaisseForm && panelName.equals("detail")))) {
                         * //setToolTipText(MainClass.getMag().getableData(1)); }
                         */
                        if (!columnName.startsWith("_"))
                        {
                            selectedField = columnName;
                            savedSelectedField = selectedField;
                            //selectedColumn = tableData.getColumnName(column);
                            //saveSize = tableData.getRowCount();
                            if (selectedField.equals("ID") && parentForm instanceof ListeClientForm)
                            {
                                return;
                            }
                            if (selectedField.equals("ID") && parentForm instanceof ListeEventForm)
                            {
                                return;
                            }
                            if (selectedField.equals("ID") && parentForm instanceof ListeRdvForm)
                            {
                                return;
                            }
                            if (selectedField.equals("ID") && parentForm instanceof DialogPlaces)
                            {
                                return;
                            }

                            Object value = tblTable.getValueAt(row, viewColumn);
                            String defaultVal;
                            if (value == null)
                            {
                                defaultVal = "";
                            }
                            else
                            {
                                defaultVal = String.valueOf(value);
                            }

                            /*
                             * if (parentForm instanceof DialogTaxes) { defaultVal =
                             * String.valueOf(value); if (defaultVal.equals("null")) defaultVal =
                             * "";
                             *
                             * if (selectedField.contains("T2SURT1")) { if (defaultVal.equals("X"))
                             * defaultVal = ""; else defaultVal = "X";
                             * tblTable.setValueAt(defaultVal, cellRow, cellColumn); ((DialogTaxes)
                             * parentForm).showRecord(row + 1); if (row!=0 && row >= saveSize - 1 &&
                             * bAdding == false && tableData.getAdd()) //record added {
                             * ((DialogTaxes) parentForm).addRecord(); bAdding = true; }
                             * ((DialogTaxes) parentForm).save(row + 1, cellColumn, defaultVal);
                             * ((DialogTaxes) parentForm).showRecord(row + 1); return; } } else
                             */
                            if (parentForm instanceof DialogPlaces)
                            {
                                defaultVal = String.valueOf(value);
                                if (defaultVal.equals("null"))
                                {
                                    defaultVal = "";
                                }

                                if (selectedField.equals("PLACELATITUDE") || selectedField.equals("PLACELONGITUDE") || savedSelectedField.equals(MainClass.bundle.getString("placesPLACELATITUDE")) || savedSelectedField.equals(MainClass.bundle.getString("placesPLACELONGITUDE")))
                                {
                                    if (selectedField.equals("PLACELATITUDE") || savedSelectedField.equals(MainClass.bundle.getString("placesPLACELATITUDE")))
                                    {
                                        FLatitude flat = new FLatitude(defaultVal);
                                        defaultVal = flat.getLatitude();
                                        latitude = defaultVal;
                                        fieldKind = FIELDLATITUDE;
                                    }
                                    else
                                    {
                                        FLongitude flong = new FLongitude(defaultVal);
                                        defaultVal = flong.getLongitude();
                                        longitude = defaultVal;
                                        fieldKind = FIELDLONGITUDE;
                                    }
                                }
                                else
                                {
                                    fieldKind = FIELDTEXT;
                                }
                                tblTable.setValueAt(defaultVal, cellRow, cellColumn);
                                ((DialogPlaces) parentForm).save(row + 1, cellColumn, defaultVal);
                            }
                            tblTable.paintImmediately(tblTable.getCellRect(cellRow - 1, cellColumn, true));

                            //autres champs
                            //Show a text area box to edit the cell
                            //-------------------------------------
                            //set the size and location of the component
                            if (columnName.equals("Comments") || columnName.equals("Note"))
                            {
                                fieldSize = 10000;
                            }
                            else
                            {
                                fieldSize = 255;
                            }
                            Rectangle rect = tblTable.getCellRect(row, viewColumn, true);
                            pt.setLocation(rect.getX(), rect.getY());
                            int w = columnModel.getColumn(viewColumn).getWidth() - 1;
                            textField.setVisible(false);
                            txtLatitude.setVisible(false);
                            txtLongitude.setVisible(false);

                            switch (fieldKind)
                            {
                                case FIELDTEXT:
                                    textField.setLocation(pt);
                                    textField.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    textField.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    textField.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));

                                    //Show the component
                                    textField.setVisible(true);

                                    //Select the text if any
                                    textField.setText(defaultVal);
                                    textField.requestFocus();
                                    textField.selectAll();
                                    break;

                                case FIELDLATITUDE:
                                    txtLatitude.setLocation(pt);
                                    txtLatitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    txtLatitude.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    txtLatitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));

                                    //Show the component
                                    txtLatitude.setVisible(true);

                                    //Select the text if any
                                    txtLatitude.setText(defaultVal);
                                    txtLatitude.requestFocus();
                                    //txtLatitude.selectAll();
                                    break;

                                case FIELDLONGITUDE:
                                    txtLongitude.setLocation(pt);
                                    txtLongitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    txtLongitude.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                                    txtLongitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));

                                    //Show the component
                                    txtLongitude.setVisible(true);

                                    //Select the text if any
                                    txtLongitude.setText(defaultVal);
                                    txtLongitude.requestFocus();
                                    //txtLongitude.selectAll();
                                    break;
                            }
                            //}
                        }
                    }
                }
                else if (e.getClickCount() == 2)
                {
                    Point pt = new Point(0, 0);
                    pt.setLocation(e.getX(), e.getY());
                    int row = tblTable.rowAtPoint(pt);
                    Object ovalue = tblTable.getValueAt(row, 0);
                    String value = "-1";
                    if (ovalue != null)
                    {
                        value = String.valueOf(ovalue);
                    }

                    if (parentForm instanceof ListeClientForm)
                    {
                        String groupeid = ((ListeClientForm) parentForm).getGroupID();
                        String clientid = ((ListeClientForm) parentForm).getClientID();
                        DialogClient dlgCl = new DialogClient(((ListeClientForm) parentForm).getForm(), true, clientid, groupeid);
                        //((ListeClientForm)parentForm).refreshRecord();
                    }
                    else if (parentForm instanceof ListeEventForm)
                    {
                        String eventid = ((ListeEventForm) parentForm).getEventID();
                        ((ListeEventForm) parentForm).showEvent(cellRow + 1);
                        DialogEvent dlgEvt = new DialogEvent(((ListeEventForm) parentForm).getForm(), true, eventid);
                        //((ListeEventForm)parentForm).refreshRecord();
                    }
                    else if (parentForm instanceof ListeRdvForm)
                    {
                        String sduree = MainClass.starLoginManager.getStringFieldValue("rdv", "DUREE", " WHERE ID=" + value);
                        if (sduree.equals(""))
                        {
                            sduree = "0";
                        }
                        int duree = Integer.valueOf(sduree).intValue();
                        boolean bMois;
                        if (duree > 1440)
                        {
                            bMois = true;
                        }
                        else
                        {
                            bMois = false;
                        }
                        DialogRdv dlgRdv = new DialogRdv(((ListeRdvForm) parentForm).getForm(), true, "-1", "", value, bMois);
                        //((ListeRdvForm)parentForm).refreshRecord();
                    }
                }
            }
        };
        tblTable.addMouseListener(listMouseListener);
    }
    /*
     * private void addMouseMotionListener() { MouseMotionAdapter motionListener = new
     * java.awt.event.MouseMotionAdapter() { @Override public void mouseMoved(MouseEvent e) {
     *
     * TableColumnModel columnModel = tblTable.getColumnModel(); int viewColumn =
     * columnModel.getColumnIndexAtX(e.getX()); int column =
     * tblTable.convertColumnIndexToModel(viewColumn); String columnName =
     * tableData.getField(column); if (!columnName.startsWith("_")) { selectedField = columnName;
     * //selectedColumn = tableData.getColumnName(column); saveSize = tableData.getRowCount();
     *
     * Point pt = new Point(0, 0); pt.setLocation(e.getX(), e.getY()); int row =
     * tblTable.rowAtPoint(pt); cellRow = row; cellColumn = viewColumn; //saveRow = cellRow;
     * //saveCol = cellColumn; Object value = tblTable.getValueAt(row, viewColumn); if (value ==
     * null) { value = ""; } String defaultVal = String.valueOf(value);
     *
     * if (defaultVal.equals("") || defaultVal.equals("-1")) { tblTable.setToolTipText(""); } else {
     * tblTable.setToolTipText(defaultVal); } } } };
     * tblTable.addMouseMotionListener(motionListener); }
     */

    public void EditCell(int row, int column)
    {
        if (isEditableCell(column) == false)
        {
            textField.setVisible(false);
            txtLatitude.setVisible(false);
            txtLongitude.setVisible(false);
            return;
        }
        int col = tblTable.convertColumnIndexToModel(column);
        String columnName = tableData.getField(col);
        //selectedColumn = tableData.getColumnName(col);
        cellRow = row;
        cellColumn = column;

        if (columnName.startsWith("_"))
        {
            //textField.setEditable(false);
            textField.setVisible(false);
            txtLatitude.setVisible(false);
            txtLongitude.setVisible(false);
            return;
        }

        if (columnName.equals("Comments"))
        {
            fieldSize = 32768;
        }
        else
        {
            fieldSize = 255;
        }
        Point pt = new Point(0, 0);
        Object value = tblTable.getValueAt(row, column);

        //Show a text area box to edit the cell
        //-------------------------------------
        //set the size and location of the component
        Rectangle rect = tblTable.getCellRect(row, column, true);
        pt.setLocation(rect.getX(), rect.getY());
        TableColumnModel columnModel = tblTable.getColumnModel();
        int w = columnModel.getColumn(column).getWidth() - 1;

        //Select the text if any
        String texte = String.valueOf(value);
        if (texte.equals("null"))
        {
            texte = "";
        }

        switch (fieldKind)
        {
            case FIELDTEXT:
                textField.setLocation(pt);
                textField.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                textField.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                textField.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));
                textField.setVisible(true);
                textField.setText(texte);
                textField.requestFocus();
                textField.selectAll();
                break;

            case FIELDLATITUDE:
                txtLatitude.setLocation(pt);
                txtLatitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLatitude.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLatitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLatitude.setVisible(true);
                FLatitude flat = new FLatitude(texte);
                texte = flat.getLatitude();
                txtLatitude.setText(texte);
                txtLatitude.requestFocus();
                break;

            case FIELDLONGITUDE:
                txtLongitude.setLocation(pt);
                txtLongitude.setPreferredSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLongitude.setSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLongitude.setMinimumSize(new Dimension(w, tblTable.getRowHeight(row)));
                txtLongitude.setVisible(true);
                FLongitude flong = new FLongitude(texte);
                texte = flong.getLongitude();
                txtLongitude.setText(texte);
                txtLongitude.requestFocus();
                break;
        }
        saveRow = row;
        saveCol = col;
    }

    /*
     * public void setVisibleCell(int row, int col) { String texte =
     * String.valueOf(tblTable.getValueAt(row, col)); switch (fieldKind) { case FIELDTEXT:
     * textField.setText(texte); textField.setVisible(true); textField.grabFocus(); break;
     *
     * case FIELDLATITUDE: txtLatitude.setText(texte); txtLatitude.setVisible(true);
     * txtLatitude.grabFocus(); break;
     *
     * case FIELDLONGITUDE: txtLongitude.setText(texte); txtLongitude.setVisible(true);
     * txtLongitude.grabFocus(); break;
     *
     * }
     * }
     */
    private void addCellEditorListener()
    {
        textField.addKeyListener(new KeyAdapter()
        {
            @Override
            public void keyPressed(KeyEvent evt)
            {
                bFromKey = false;
                String text = textField.getText();
                if ((evt.getKeyCode() == KeyEvent.VK_DOWN) || (evt.getKeyCode() == KeyEvent.VK_UP) || (evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_ENTER) || (evt.getKeyCode() == KeyEvent.VK_LEFT))
                {
                    savedSelectedField = tableData.getField(saveCol);// tableData.getColumnName(saveCol);
                    int row = saveRow;
                    int col = saveCol;

                    bFromKey = true;

                    if ((evt.getKeyCode() == KeyEvent.VK_TAB) || (evt.getKeyCode() == KeyEvent.VK_RIGHT) || (evt.getKeyCode() == KeyEvent.VK_ENTER))
                    {
                        if (col < tableData.getColumnCount() - 1)
                        {
                            int col2 = getNextFree(col);
                            if (col2 >= 0)
                            {
                                keepVisible = isEditableCell(col2);
                                col = col2;
                            }
                        }
                    }
                    else if (evt.getKeyCode() == KeyEvent.VK_LEFT)
                    {
                        if (col > 1)
                        {
                            int col2 = getPrevFree(col);
                            if (col2 >= 0)
                            {
                                keepVisible = isEditableCell(col2);
                                col = col2;
                            }
                        }
                    }
                    else
                    {
                        keepVisible = false;
                        textField.setVisible(false);
                    }
                    setData(textField);
                    evt.consume();

                    String sValue = String.valueOf(tblTable.getValueAt(row, col));
                    if (sValue.equals("null"))
                    {
                        sValue = "";
                    }
                    setValue(col, sValue);
                    String header = tblTable.getColumnModel().getColumn(col).getHeaderValue().toString();
                    if (!header.startsWith("_"))
                    {
                        EditCell(row, col);
                    }
                    cellRow = row;
                    cellColumn = col;
                    saveRow = row;
                    saveCol = col;
                    savedSelectedField = tableData.getField(col);
                    selectedField = savedSelectedField;
                }
                else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE)
                {
                    keepVisible = false;
                    textField.setVisible(false);
                }
                else
                {
                    bFromKey = false;
                }
            }
        });

        textField.addFocusListener(new FocusAdapter()
        {
            @Override
            public void focusLost(FocusEvent evt)
            {
                if (!bFromKey)
                {
                    setData(textField);
                }
            }
        });
    }

    private void setData(JTextField textField)
    {
        //if (bolZoomingText == false && bolRemoving == false)
        if (bolRemoving == false)
        {
            /*
             * int sup = 0; if (tableData.getAdd()) sup = 1;
             */
            if (saveRow < tableData.getRowCount() - 1 || !textField.getText().equals(""))
            {
                String text = textField.getText();
                if (text.equals("null"))
                {
                    text = "";
                }
                if (text.length() > fieldSize)
                {
                    text = text.substring(0, fieldSize);
                }
                textField.setText(text);
                tableData.setValueAt(text, saveRow, saveCol);

                /*
                 * if (parentForm instanceof DialogTaxes) { if (savedSelectedField.equals("TAUX1")
                 * || savedSelectedField.equals("TAUX2") ||
                 * savedSelectedField.equals(MainClass.bundle.getString("schemataxeTAUX1")) ||
                 * savedSelectedField.equals(MainClass.bundle.getString("schemataxeTAUX2"))) { try {
                 * double taux = Double.valueOf(text).doubleValue(); taux =
                 * AstronomyMaths.getRnd(taux, 3); text =
                 * MainClass.formatDouble(String.valueOf(taux)); } catch (NumberFormatException ex)
                 * { //MainClass.writelog(ex.getMessage()); text = "0.00"; } finally {
                 * textField.setText(text); tblTable.setValueAt(text, saveRow, saveCol);
                 * ((DialogTaxes) parentForm).showRecord(saveRow + 1); if (saveRow!=0 && saveRow >=
                 * saveSize - 1 && bAdding == false && tableData.getAdd()) //record added {
                 * ((DialogTaxes) parentForm).addRecord(); bAdding = true; } ((DialogTaxes)
                 * parentForm).save(saveRow + 1, saveCol, text); } } else { ((DialogTaxes)
                 * parentForm).showRecord(saveRow + 1); if (saveRow != 0 && saveRow >= saveSize - 1
                 * && bAdding == false && tableData.getAdd()) //record added { ((DialogTaxes)
                 * parentForm).addRecord(); bAdding = true; } ((DialogTaxes)
                 * parentForm).save(saveRow + 1, saveCol, text); } }
                 */

                /*
                 * else if (parentForm instanceof GestionStatusFactureForm) {
                 * ((GestionStatusFactureForm) parentForm).showRecord(saveRow + 1); if (saveRow != 0
                 * && saveRow >= saveSize - 1 && bAdding == false && tableData.getAdd()) //record
                 * added { ((GestionStatusFactureForm) parentForm).addRecord(); bAdding = true; }
                 * ((GestionStatusFactureForm) parentForm).save(saveRow + 1, saveCol, text); }
                 */

                /*
                 * else if (parentForm instanceof MoyensPaiementForm) { ((MoyensPaiementForm)
                 * parentForm).showRecord(saveRow + 1); if (saveRow != 0 && saveRow >= saveSize - 1
                 * && bAdding == false && tableData.getAdd()) //record added { ((MoyensPaiementForm)
                 * parentForm).addRecord(); bAdding = true; } ((MoyensPaiementForm)
                 * parentForm).save(saveRow + 1, saveCol, text); }
                 */

                if (parentForm instanceof DialogPlaces)
                {
                    ((DialogPlaces) parentForm).bolClickFromGrid = true;
                    ((DialogPlaces) parentForm).showRecord(saveRow + 1);
                    ((DialogPlaces) parentForm).save(saveRow + 1, saveCol, text);
                }
            }
        }

        bolRemoving = false;
        textField.setVisible(keepVisible);
        //bAdding = false;
        //bFromKey = false;
    }

    private int getNextFree(int col)
    {
        for (int i = col + 1; i < tblTable.getColumnCount(); i++)
        {
            int w = tblTable.getColumn(tblTable.getColumnName(i)).getMaxWidth();
            if (w > 0)
            {
                return i;
            }
        }
        return -1;
    }

    private int getPrevFree(int col)
    {
        for (int i = col - 1; i >= 0; i--)
        {
            int w = tblTable.getColumn(tblTable.getColumnName(i)).getMaxWidth();
            if (w > 0)
            {
                return i;
            }
        }
        return -1;
    }

    private boolean isEditableCell(int col)//, int row)
    {
        String columnName = tableData.getField(col);
        if (columnName.startsWith("_"))
        {
            return false;
        }
        else if (columnName.equals("ID"))
        {
            return false;
        }
        //else if (parentForm instanceof DialogTaxes && columnName.equals(DataBaseRecords.T2SURT1X))
        //    return false;
        return tableData.getUpdatable();
    }
}
