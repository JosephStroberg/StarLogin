package StarLogin.Systeme.grids;

import StarLogin.IHM.components.Options;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author Francois DESCHAMPS
 */
public final class DataGrid implements java.awt.LayoutManager
{
    private Dimension origin = new Dimension(0, 0);
    private JScrollPane tableAggregate;
    private TableData tableData;
    private TableSorter sorter;
    private JTable table;
    private JTableHeader tableHeader;
    private JTable tableRows;
    private DataGrid current = this;
    private int rowsPerPage;
    private JPanel panel;

    public DataGrid(ArrayList rows, ArrayList columns, ArrayList fields, ArrayList sizes, JPanel panel, boolean canAdd, boolean sorting, boolean updatable, boolean canDelete, Window parent, boolean selectable)
    {
        this(rows, columns, fields, sizes, panel, canAdd, sorting, updatable, canDelete, parent, selectable, 40);
    }

    public DataGrid(ArrayList rows, ArrayList columns, ArrayList fields, ArrayList sizes, JPanel panel, boolean canAdd, boolean sorting, boolean updatable, boolean canDelete, Window parent, boolean selectable, int headerWidth)
    {
        //panelContainer = panel;
        int leg = headerWidth; //largeur de la colonne des chiffres (gauche)
        
        // Create the table.
        sorter = new TableSorter(sorting, parent);
        this.panel = panel;
        sorter.setSelectable(selectable);
        sorter.setDeletable(canDelete);
        table = new JTable(sorter);
        table.setFont(new Font("Arial", Font.PLAIN, 11));
        
        //tableHeader = table.getTableHeader();
        //tableHeader.setReorderingAllowed(true);//pour permettre le changement d'ordre des colonnes
        
        tableAggregate = new JScrollPane(table);

        // Use a scrollbar, in case there are many columns and set the columns initial width
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setEnabled(true);
        table.setAutoscrolls(true);

        tableAggregate.setAutoscrolls(true);
        tableAggregate.setWheelScrollingEnabled(true);

        //add the data
        tableData = new TableData(updatable, canDelete, canAdd);
        sorter.setModel(tableData);
        tableData.setTable(rows, columns, fields, sizes);

        // Install listeners.
        sorter.setCanAdd(canAdd);
        sorter.setTable(table);
        sorter.setPanelName(panel.getName());
        table.setName(panel.getName());
        table.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        sorter.addListenersAndPopup();
        sorter.SetTableColumnWidth();

        //Set the row headers
        tableRows = new JTable(rows.size(), 1);
        for (int i = 0; i < rows.size(); i++)
        {
            tableRows.setValueAt(" " + new Integer(i + 1).toString(), i, 0);
        }
        if (canAdd && updatable)
        {
            tableRows.setValueAt(" *", rows.size() - 1, 0);
        }
        tableRows.setColumnSelectionAllowed(false);
        tableRows.setCellSelectionEnabled(true);
        tableRows.setRowSelectionAllowed(false);
        tableRows.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tableRows.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableRows.setFont(new Font("Arial", Font.PLAIN, 11));
        String rowsHeaderName = tableRows.getColumnName(0);
        tableRows.getColumn(rowsHeaderName).setMinWidth(leg);
        tableRows.getColumn(rowsHeaderName).setPreferredWidth(leg);

        //tableHeader = new JTableHeader();
        
        tableHeader = table.getTableHeader();
        tableHeader.setReorderingAllowed(true);//pour permettre le changement d'ordre des colonnes
        
        tableHeader.setAutoscrolls(true);
        tableHeader.setOpaque(true);
        tableHeader.setDefaultRenderer(new GridHeaderRenderer());
        tableHeader.setResizingAllowed(true);//false;
        tableRows.setTableHeader(tableHeader);
        tableRows.setBackground(tableHeader.getBackground());
        tableRows.setForeground(tableHeader.getForeground());
        tableRows.setOpaque(true);
        
        tableAggregate.setRowHeaderView(tableRows);
        tableAggregate.getRowHeader().setPreferredSize(new Dimension(leg, panel.getHeight()));
        
        tableRows.setIntercellSpacing(new Dimension(2, 2));
        
        // Add the component to the panel.
        panel.removeAll();
        panel.setLayout(current);
        panel.add(tableAggregate);
        
        setTableColors();
    }
    
    /*public void setVisibleCell(int row, int col)
    {
        sorter.setVisibleCell(row, col);
    }*/
    
    public JTextField getTextField()
    {
        return sorter.textField;
    }
    
    public boolean isUpdatable()
    {
        return tableData.getUpdatable();
    }
    
    public void setUpdatable(boolean updatable)
    {
        tableData.setUpdatable(updatable);
    }
    
    public JScrollPane getScrollPane()
    {
        return tableAggregate;
    }
    
    public JTable getTable()
    {
        return sorter.getTable();
    }
    
    /*public void hideVSB()
    {
        tableAggregate.getVerticalScrollBar().setVisible(false);
    }*/

    public void setTableColors()
    {
        Color bk = Options.getColor("Table.background");
        table.setBackground(bk);
        panel.setBackground(bk);
        tableHeader.setBackground(Options.getColor("TableHeader.background"));
        tableHeader.setForeground(Options.getColor("TableHeader.foreground"));
        //tableRows.setForeground(Options.getColor("Table", "Header"));
        //tableRows.setBackground(Options.getColor("Table", "Header"));
        table.setGridColor(Options.getColor("Table.gridColor"));
        table.setSelectionForeground(Options.getColor("Table.selectionForeground"));
        table.setSelectionBackground(Options.getColor("Table.selectionBackground"));
        sorter.setPanelName(panel.getName());
    }

    public int getSelectedRow()
    {
        return sorter.getSelectedRow();
    }
    
    public int getPagesNb()
    {
        JViewport viewport = tableAggregate.getRowHeader();
        Dimension dim = viewport.getPreferredSize();
        Rectangle oldRect = viewport.getViewRect();
        rowsPerPage = (int)Math.floor((double)oldRect.getHeight() / (double)table.getRowHeight());
        return (int)Math.ceil((double)table.getRowCount()/(double)rowsPerPage);
    }
    
    public int getRowsPerPage()
    {
        return rowsPerPage;
    }

    public void setSelectedRow(int row)
    {
        sorter.setSelectedRow(row);

        JViewport viewport = tableAggregate.getRowHeader();
        Dimension dim = viewport.getPreferredSize();
        Rectangle oldRect = viewport.getViewRect();
        
        int oldTop = (int)oldRect.getY();
        int rowTop = (int)table.getRowHeight()*(row-1);
        int height = (int)dim.getHeight();
        int width = (int)dim.getWidth();
        int top = rowTop - oldTop;
        
        Rectangle rect = new Rectangle(0, top, width, height);
        viewport.scrollRectToVisible(rect);
        viewport = tableAggregate.getViewport();
        //dim = viewport.getPreferredSize();
        rect = new Rectangle(0, top, width, height);
        viewport.scrollRectToVisible(rect);
    }
    
    public void EditCell(int row, int column)
    {
        sorter.EditCell(row, column);
    }

    public TableColumnModel getTableColumnModel()
    {
        return table.getColumnModel();
    }

    @Override
    public Dimension preferredLayoutSize(Container c)
    {
        return origin;
    }

    @Override
    public Dimension minimumLayoutSize(Container c)
    {
        return origin;
    }

    @Override
    public void addLayoutComponent(String s, Component c)
    {
    }

    @Override
    public void removeLayoutComponent(Component c)
    {
    }

    @Override
    public void layoutContainer(Container c)
    {
        Rectangle b = c.getBounds();
        int topHeight = 0;
        int inset = 0;
        tableAggregate.setBounds(new Rectangle(inset,
                                               inset + topHeight,
                                               b.width - 2 * inset,
                                               b.height - 2 * inset - topHeight));
    }
}