package StarLogin.Systeme.grids;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Francois DESCHAMPS
 */
public class TableData extends AbstractTableModel
{

    private ArrayList rows = new ArrayList();
    private ArrayList columnNames = new ArrayList();
    private ArrayList fields = new ArrayList();
    private ArrayList sizes = new ArrayList();
    private boolean dirty = false;
    private int lastRow;
    private boolean bolUpdatable = true;
    private boolean bolDelete = true;
    private boolean bolAdd = false;

    public TableData()
    {
    }

    public TableData(boolean updatable)
    {
        bolUpdatable = updatable;
    }

    public TableData(boolean updatable, boolean canDelete)
    {
        bolUpdatable = updatable;
        bolDelete = canDelete;
    }

    public TableData(boolean updatable, boolean canDelete, boolean canAdd)
    {
        bolUpdatable = updatable;
        bolDelete = canDelete;
        bolAdd = canAdd;
    }

    public boolean getDirty()
    {
        return dirty;
    }
    
    public boolean getAdd()
    {
        return bolAdd;
    }

    public void setDirty(boolean data)
    {
        dirty = data;
    }

    public boolean getUpdatable()
    {
        return bolUpdatable;
    }
    
    public void setUpdatable(boolean updatable)
    {
        bolUpdatable = updatable;
    }

    public boolean getDelete()
    {
        return bolDelete;
    }

    public void setTable(ArrayList row, ArrayList column, ArrayList flds, ArrayList sizs)
    {
        rows = row;
        columnNames = column;
        fields = flds;
        sizes = sizs;
        lastRow = rows.size() - 1;
        addRow();   //may add an empty row at the end
        fireTableChanged(null); // Tell the listeners a new table has arrived.
    }

    @SuppressWarnings("unchecked")
    private void addRow()
    {
        if (bolAdd && bolUpdatable)
        {
            ArrayList newRow = new ArrayList();
            lastRow += 1;
            for (int i = 1; i <= getColumnCount(); i++)
            {
                newRow.add("");
            }
            rows.add(newRow);
        }
    }

    public void removeRow(int row)
    {
        if ((bolUpdatable == true) || (bolDelete == true))
        {
            rows.remove(row);
            lastRow -= 1;
            fireTableChanged(null);
            dirty = true;
        }
    }

    public ArrayList getRows()
    {
        return rows;
    }

    public ArrayList getColumnNames()
    {
        return columnNames;
    }

    public ArrayList getFields()
    {
        return fields;
    }

    public ArrayList getSizes()
    {
        return sizes;
    }

    public String getField(int column)
    {
        return (String) fields.get(column);
    }

    public int getSize(int column)
    {
        return Integer.valueOf(sizes.get(column).toString());
    }

    /*@Override
    protected void finalize() throws Throwable
    {
        super.finalize();
    }*/

    @Override
    public String getColumnName(int column)
    {
        return (String) columnNames.get(column);
    }

    @Override
    public int getColumnCount()
    {
        return columnNames.size();
    }

    @Override
    public int getRowCount()
    {
        return rows.size();
    }

    @Override
    public Object getValueAt(int aRow, int aColumn)
    {
        ArrayList row = (ArrayList) rows.get(aRow);
        return row.get(aColumn);
    }

    @Override
    @SuppressWarnings("unchecked")
    public void setValueAt(Object value, int row, int column)
    {
        if (bolUpdatable == true)
        {
            ArrayList dataRow = (ArrayList) rows.get(row);
            dataRow.set(column, value);
            dirty = true;
            if (row == lastRow && bolAdd)
            {
                addRow();
                fireTableChanged(null);
            }
        }
    }
}
