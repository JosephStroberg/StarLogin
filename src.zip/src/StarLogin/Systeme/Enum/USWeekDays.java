package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import java.util.Locale;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class USWeekDays extends Object
{
    public static final int SUNDAY = 0;
    public static final int MONDAY = 1;
    public static final int TUESDAY = 2;
    public static final int WEDNESDAY = 3;
    public static final int THURSDAY = 4;
    public static final int FRIDAY = 5;
    public static final int SATURDAY = 6;
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    
    public static String getName(int weekDay)
    {
        switch(weekDay)
        {
            case SUNDAY: return bundle.getString("SunDay");
            case MONDAY: return bundle.getString("Monday");
            case TUESDAY: return bundle.getString("Tuesday");
            case WEDNESDAY: return bundle.getString("Wednesday");
            case THURSDAY: return bundle.getString("Thursday");
            case FRIDAY: return bundle.getString("Friday");
            case SATURDAY: return bundle.getString("Saturday");
            default: return "???";
        }
    }
    public static String getInitiale(int weekDay)
    {
        boolean writeLeft2Right = true;

        if (Locale.getDefault().getLanguage().equals("ar") || Locale.getDefault().getLanguage().equals("he"))
        {
            writeLeft2Right = false;
        }

        if (writeLeft2Right)
        {
            switch(weekDay)
            {
                case SUNDAY: return bundle.getString("Sunday").substring(0, 1);
                case MONDAY: return bundle.getString("Monday").substring(0, 1);
                case TUESDAY: return bundle.getString("Tuesday").substring(0, 1);
                case WEDNESDAY: return bundle.getString("Wednesday").substring(0, 1);
                case THURSDAY: return bundle.getString("Thursday").substring(0, 1);
                case FRIDAY: return bundle.getString("Friday").substring(0, 1);
                case SATURDAY: return bundle.getString("Saturday").substring(0, 1);
                default: return "???";
            }
        }
        else
        {
            String name = "";
            switch(weekDay)
            {
                case SUNDAY: name = bundle.getString("Sunday");
                case MONDAY: name = bundle.getString("Monday");
                case TUESDAY: name = bundle.getString("Tuesday");
                case WEDNESDAY: name = bundle.getString("Wednesday");
                case THURSDAY: name = bundle.getString("Thursday");
                case FRIDAY: name = bundle.getString("Friday");
                case SATURDAY: name = bundle.getString("Saturday");
                default: name = "???";
            }
            int size = name.length();
            return name.substring(size-1, size);
        }
    }
}

