package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.ChartElements;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Planets extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int None = -1;
    public static final int Sun = 0;
    public static final int Moon = 1;
    public static final int Mercury  = 2;
    public static final int Venus  = 3;
    public static final int Mars  = 4;
    public static final int Jupiter  = 5;
    public static final int Saturn  = 6;
    public static final int Uranus  = 7;
    public static final int Neptune  = 8;
    public static final int Pluto = 9;
    public static final int Gaia = 10;
    public static final int NorthNode = 11;
    public static final int Lilith = 12;
    public static final int East = 13;
    public static final int Zenith = 14;
    public static final int Vertex = 15;
    public static final int Vulcan = 16;
    public static final int OtherPoint = 17;
    public static final int Ceres = 18;
    public static final int Pallas = 19;
    public static final int Juno = 20;
    public static final int Vesta = 21;
    public static final int Chiron = 22;
    public static final int AS = 23;
    public static final int MC = 24;
    public static final int House1 = 25;
    public static final int House2 = 26;
    public static final int House3 = 27;
    public static final int House4 = 28;
    public static final int House5 = 29;
    public static final int House6 = 30;
    public static final int House7 = 31;
    public static final int House8 = 32;
    public static final int House9 = 33;
    public static final int House10 = 34;
    public static final int House11 = 35;
    public static final int House12 = 36;
    public static final int SouthNode = 37;
    public static final int Barycenter = 38;
    
    public static int getLast()
    {
        return Barycenter;
    }
    
    public static int getPlanetNumber(String planet)
    {
        for (int i=0; i <= getLast(); i++)
        {
            if (planet.equals(getPlanetName(i)))
            {
                return i;
            }
        }
        return -1;
    }
    
    public static int getPlanetNumber(String planet, ChartElements chartElements)
    {
        for (int i=0; i <= getLast(); i++)
        {
            if (planet.equals(getPlanetName(i, chartElements)))
            {
                return i;
            }
        }
        return -1;
    }
    
    public static String getPlanetName(int planet)
    {
        switch(planet)
        {
            case Sun: return bundle.getString("Sun");
            case Moon: return bundle.getString("Moon");
            case Mercury: return bundle.getString("Mercury");
            case Venus: return bundle.getString("Venus");
            case Mars: return bundle.getString("Mars");
            case Jupiter: return bundle.getString("Jupiter");
            case Saturn: return bundle.getString("Saturn");
            case Uranus: return bundle.getString("Uranus");
            case Neptune: return bundle.getString("Neptune");
            case Pluto: return bundle.getString("Pluto");
            case Gaia: return bundle.getString("Gaia");
            case NorthNode: return bundle.getString("NorthNode");
            case Lilith: return bundle.getString("Lilith");
            case East: return bundle.getString("East");
            case Zenith: return bundle.getString("Zenith");
            case Vertex: return bundle.getString("Vertex");
            case Vulcan: return bundle.getString("Vulcan");
            case OtherPoint: return bundle.getString("OtherPoint");
            case Ceres: return bundle.getString("Ceres");
            case Pallas: return bundle.getString("Pallas");
            case Juno: return bundle.getString("Juno");
            case Vesta: return bundle.getString("Vesta");
            case Chiron: return bundle.getString("Chiron");
            case AS: return bundle.getString("Ascendant");
            case MC: return bundle.getString("Midheaven");
            case House1: return bundle.getString("House1");
            case House2: return bundle.getString("House2");
            case House3: return bundle.getString("House3");
            case House4: return bundle.getString("House4");
            case House5: return bundle.getString("House5");
            case House6: return bundle.getString("House6");
            case House7: return bundle.getString("House7");
            case House8: return bundle.getString("House8");
            case House9: return bundle.getString("House9");
            case House10: return bundle.getString("House10");
            case House11: return bundle.getString("House11");
            case House12: return bundle.getString("House12");
            case SouthNode: return bundle.getString("SouthNode");
            case Barycenter: return bundle.getString("Barycenter");
            default: return "???";
        }
    }
    
    public static String getPlanetName(int planet, ChartElements chartElements)
    {
        switch(planet)
        {
            case OtherPoint: return chartElements.getOtherPointName();
            case Sun: return bundle.getString("Sun");
            case Moon: return bundle.getString("Moon");
            case Mercury: return bundle.getString("Mercury");
            case Venus: return bundle.getString("Venus");
            case Mars: return bundle.getString("Mars");
            case Jupiter: return bundle.getString("Jupiter");
            case Saturn: return bundle.getString("Saturn");
            case Uranus: return bundle.getString("Uranus");
            case Neptune: return bundle.getString("Neptune");
            case Pluto: return bundle.getString("Pluto");
            case Gaia: return bundle.getString("Gaia");
            case NorthNode: return bundle.getString("NorthNode");
            case Lilith: return bundle.getString("Lilith");
            case East: return bundle.getString("East");
            case Zenith: return bundle.getString("Zenith");
            case Vertex: return bundle.getString("Vertex");
            case Vulcan: return bundle.getString("Vulcan");
            case Ceres: return bundle.getString("Ceres");
            case Pallas: return bundle.getString("Pallas");
            case Juno: return bundle.getString("Juno");
            case Vesta: return bundle.getString("Vesta");
            case Chiron: return bundle.getString("Chiron");
            case AS: return bundle.getString("Ascendant");
            case MC: return bundle.getString("Midheaven");
            case House1: return bundle.getString("House1");
            case House2: return bundle.getString("House2");
            case House3: return bundle.getString("House3");
            case House4: return bundle.getString("House4");
            case House5: return bundle.getString("House5");
            case House6: return bundle.getString("House6");
            case House7: return bundle.getString("House7");
            case House8: return bundle.getString("House8");
            case House9: return bundle.getString("House9");
            case House10: return bundle.getString("House10");
            case House11: return bundle.getString("House11");
            case House12: return bundle.getString("House12");
            case SouthNode: return bundle.getString("SouthNode");
            case Barycenter: return bundle.getString("Barycenter");
            default: return "???";
        }
    }
    
    public static String getPlanetSymbol(int planet)
    {
        switch(planet)
        {
            case Sun: return "A";
            case Moon: return "B";
            case Mercury: return "C";
            case Venus: return "D";
            case Mars: return "E";
            case Jupiter: return "F";
            case Saturn: return "G";
            case Uranus: return "H";
            case Neptune: return "I";
            case Pluto: return "J";
            case Gaia: return "K";
            case NorthNode: return "L";
            case Lilith: return "M";
            case East: return "N";
            case Zenith: return "O";
            case Vertex: return "P";
            case Vulcan: return "Q";
            case OtherPoint: return "R";
            case Ceres: return "S";
            case Pallas: return "T";
            case Juno: return "U";
            case Vesta: return "V";
            case Chiron: return "W";
            case AS: return "X";
            case MC: return "Y";
            case House1: return "1";
            case House2: return "2";
            case House3: return "3";
            case House4: return "4";
            case House5: return "5";
            case House6: return "6";
            case House7: return "7";
            case House8: return "8";
            case House9: return "9";
            case House10: return "10";
            case House11: return "11";
            case House12: return "12";
            case SouthNode: return "Z";
            default: return "";
        }
    }
}

