package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Months extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Month1 = 0;
    public static final int Month2 = 1;
    public static final int Month3  = 2;
    public static final int Month4  = 3;
    public static final int Month5  = 4;
    public static final int Month6  = 5;
    public static final int Month7  = 6;
    public static final int Month8  = 7;
    public static final int Month9  = 8;
    public static final int Month10  = 9;
    public static final int Month11  = 10;
    public static final int Month12  = 11;
    
    public static String getMonthName(int month)
    {
        switch(month)
        {
            case Month1: return bundle.getString("Month1");
            case Month2: return bundle.getString("Month2");
            case Month3: return bundle.getString("Month3");
            case Month4: return bundle.getString("Month4");
            case Month5: return bundle.getString("Month5");
            case Month6: return bundle.getString("Month6");
            case Month7: return bundle.getString("Month7");
            case Month8: return bundle.getString("Month8");
            case Month9: return bundle.getString("Month9");
            case Month10: return bundle.getString("Month10");
            case Month11: return bundle.getString("Month11");
            case Month12: return bundle.getString("Month12");
            default: return "???";
        }
    }
}

