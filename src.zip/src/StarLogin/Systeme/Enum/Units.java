package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 */
public class Units extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Milimeter = 0;
    public static final int Line = 1;
    public static final int Inch = 2;
    public static final int FInch = 3;
    public static final int Chainon = 4;
    public static final int Foot = 5;
    public static final int FFoot = 6;
    public static final int Yard = 7;
    public static final int Meter = 8;
    public static final int Toise = 9;
    public static final int Rod = 10;
    public static final int FRod = 11;
    public static final int Chaine = 12;
    public static final int Arpent = 13;
    public static final int Furlong = 14;
    public static final int Kilometer = 15;
    public static final int Mile = 16;
    public static final int NauticMile = 17;
    public static final int Lieue = 18;
    public static final int FLieue = 19;
    public static final int AU = 20;
    public static final int LightYear = 21;
    public static final int Parsec = 22;

    public static int getLast()
    {
        return Parsec;
    }

    public static String getName(int unit)
    {
        switch(unit)
        {
            case Milimeter: return bundle.getString("Millimeter");
            case Meter: return bundle.getString("Meter");
            case Kilometer: return bundle.getString("Kilometer");
            case Line: return bundle.getString("Line");
            case Inch: return bundle.getString("Inch");
            case FInch: return bundle.getString("FInch");
            case Chainon: return bundle.getString("Chainon");
            case Foot: return bundle.getString("Foot");
            case FFoot: return bundle.getString("FFoot");
            case Yard: return bundle.getString("Yard");
            case Toise: return bundle.getString("Toise");
            case Rod: return bundle.getString("Rod");
            case FRod: return bundle.getString("FRod");
            case Chaine: return bundle.getString("Chaine");
            case Furlong: return bundle.getString("Furlong");
            case Arpent: return bundle.getString("Arpent");
            case Mile: return bundle.getString("Mile");
            case NauticMile: return bundle.getString("NauticMile");
            case Lieue: return bundle.getString("Lieue");
            case FLieue: return bundle.getString("FLieue");
            case AU: return bundle.getString("AU");
            case LightYear: return bundle.getString("LightYear");
            case Parsec: return bundle.getString("Parsec");
            default : return "???";
        }
    }

    public static double getValue(int unit)
    {
        switch(unit)
        {
            case Milimeter : return 0.001;
            case Line : return 0.003174875;
            case Inch : return 0.025399;
            case FInch : return 0.027069;
            case Chainon : return 0.20116;
            case Foot : return 0.30479;
            case FFoot : return 0.32483;
            case Yard : return 0.91438;
            case Meter : return 1.0;
            case Toise : return 1.949;
            case Rod : return 5.0291;
            case FRod : return 5.847;
            case Chaine : return 20.1164;
            case Arpent : return 58.47;
            case Furlong : return 201.164;
            case Kilometer : return 1000.0;
            case Mile : return 1609.3;
            case NauticMile : return 1853.13;
            case Lieue : return 4827.9;
            case FLieue : return 4911.5;
            case AU : return 149597900000.0;
            case LightYear : return 9.48621E+15;
            case Parsec : return 3.085678E+16;
            default : return 1.0;
        }
    }
}