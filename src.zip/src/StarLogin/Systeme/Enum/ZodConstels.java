package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ZodConstels extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int ZodConstel1 = 0;
    public static final int ZodConstel2 = 1;
    public static final int ZodConstel3  = 2;
    public static final int ZodConstel4  = 3;
    public static final int ZodConstel5  = 4;
    public static final int ZodConstel6  = 5;
    public static final int ZodConstel7  = 6;
    public static final int ZodConstel8  = 7;
    public static final int ZodConstel9  = 8;
    public static final int ZodConstel10  = 9;
    public static final int ZodConstel11  = 10;
    public static final int ZodConstel12  = 11;
    public static final int ZodConstel13  = 12;
    public static final int Aries = 0;
    public static final int Taurus = 1;
    public static final int Gemini  = 2;
    public static final int Cancer  = 3;
    public static final int Leo  = 4;
    public static final int Virgo  = 5;
    public static final int Libra  = 6;
    public static final int Scorpio  = 7;
    public static final int Ophiuccus  = 8;
    public static final int Sagittarius  = 9;
    public static final int Capricorn  = 10;
    public static final int Aquarius  = 11;
    public static final int Pisces  = 12;
    
    public static int getLast()
    {
        return ZodConstel13;
    }
    
    public static String getZodConstelName(int zodConstel)
    {
        switch(zodConstel)
        {
            case ZodConstel1: return bundle.getString("Sign1");
            case ZodConstel2: return bundle.getString("Sign2");
            case ZodConstel3: return bundle.getString("Sign3");
            case ZodConstel4: return bundle.getString("Sign4");
            case ZodConstel5: return bundle.getString("Sign5");
            case ZodConstel6: return bundle.getString("Sign6");
            case ZodConstel7: return bundle.getString("Sign7");
            case ZodConstel8: return bundle.getString("Sign8");
            case ZodConstel9: return bundle.getString("Sign13");
            case ZodConstel10: return bundle.getString("Sign9");
            case ZodConstel11: return bundle.getString("Sign10");
            case ZodConstel12: return bundle.getString("Sign11");
            case ZodConstel13: return bundle.getString("Sign12");
            default: return "???";
        }
    }
    
    public static String getAbConstelName(int zodConstel)
    {
        switch(zodConstel)
        {
            case ZodConstel1: return "ARI";
            case ZodConstel2: return "TAU";
            case ZodConstel3: return "GEM";
            case ZodConstel4: return "CAN";
            case ZodConstel5: return "LEO";
            case ZodConstel6: return "VIR";
            case ZodConstel7: return "LIB";
            case ZodConstel8: return "SCO";
            case ZodConstel9: return "OPH";
            case ZodConstel10: return "SAG";
            case ZodConstel11: return "CAP";
            case ZodConstel12: return "AQU";
            case ZodConstel13: return "PIS";
            default: return "???";
        }
    }
    
    public static double getConstelBoundary(int constel, double temps_seculaire)
    {
        double init_val;
        
        switch(constel)
        {
            case ZodConstel2 : init_val = 51.5; break;
            case ZodConstel3 : init_val = 88.5; break;
            case ZodConstel4 : init_val = 116.5; break;
            case ZodConstel5 : init_val = 136.5; break;
            case ZodConstel6 : init_val = 172.5; break;
            case ZodConstel7 : init_val = 216.5; break;
            case ZodConstel8 : init_val = 239.0; break;
            case ZodConstel9 : init_val = 246.5; break;
            case ZodConstel10 : init_val = 264.5; break;
            case ZodConstel11 : init_val = 298.5; break;
            case ZodConstel12 : init_val = 326.0; break;
            case ZodConstel13 : init_val = 349.5; break;
            case ZodConstel1 : init_val = 27.5; break;
            default : init_val = 0; temps_seculaire = 0; break;
        }
        return init_val + 5029.0966 / 3600.0 * temps_seculaire;
    }
}
