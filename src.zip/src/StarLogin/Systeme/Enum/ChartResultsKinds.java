package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartResultsKinds
{        
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int aspects = 0;
    public static final int aspectsValue = 1;
    public static final int parallels = 2;
    public static final int orbsOfParallels = 3;
    public static final int relativeAspects = 4;
    public static final int midpoints = 5;
    public static final int treeOfMidpoints = 6;
    public static final int trueMidpoints = 7;
    public static final int treeOfTrueMidpoints = 8;
    public static final int arabianParts = 9;
    public static final int treeOfArabianParts = 10;
    public static final int definedArabianParts = 11;
    public static final int treeOfDefinedArabianParts = 12;
    public static final int distancesAndCoordinates = 13;
    public static final int planetsPropetiesOfChart = 14;
    private boolean selected[] = new boolean[planetsPropetiesOfChart + 1];
    
    public static int getLast()
    {
        return planetsPropetiesOfChart;
    }
    
    public ChartResultsKinds()
    {
        for (int i=0; i<=planetsPropetiesOfChart; i++)
        {
            selected[i] = false;
        }
    }
    
    public void setSelection(int kind, boolean value)
    {
        selected[kind] = value;
    }
    
    public boolean[] getSelections()
    {
        return selected;
    }
    
    public boolean getSelection(int kind)
    {
        return selected[kind];
    }
    
    public static String getName(int kind)
    {
        switch(kind)
        {
            case aspects: return bundle.getString("Aspects");
            case aspectsValue: return bundle.getString("AspectsValue");
            case parallels: return bundle.getString("ParallelsAndAntiParallels");
            case orbsOfParallels: return bundle.getString("OrbsOfParallelsAndAntiparallels");
            case relativeAspects: return bundle.getString("RelativeAspects");
            case treeOfMidpoints: return bundle.getString("TreeOfMidpoints");
            case midpoints: return bundle.getString("Midpoints");
            case treeOfTrueMidpoints: return bundle.getString("TreeOfTrueMidpoints");
            case trueMidpoints: return bundle.getString("TrueMidpoints");
            case arabianParts: return bundle.getString("ArabianParts");
            case treeOfArabianParts: return bundle.getString("TreeOfArabianParts");
            case definedArabianParts: return bundle.getString("DefinedArabianParts");
            case treeOfDefinedArabianParts: return bundle.getString("TreeOfDefinedArabianParts");
            case distancesAndCoordinates: return bundle.getString("DistancesAndCoordinates");
            case planetsPropetiesOfChart: return bundle.getString("PlanetsPropetiesOfChart");
            default : return "";
        }
    }
}
