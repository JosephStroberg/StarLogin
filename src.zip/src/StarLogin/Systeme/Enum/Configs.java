package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Configs extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int SmallTriangle = 0;
    public static final int GrandTrine = 1;
    public static final int TCross  = 2;
    public static final int Yod  = 3;
    public static final int BirdWings  = 4;
    public static final int Boat  = 5;
    public static final int Boomerang  = 6;
    public static final int Kite  = 7;
    public static final int GrandSquare  = 8;
    public static final int Anvil = 9;
    public static final int Mountain = 10;
    public static final int Keepnet = 11;
    public static final int Rectangle = 12;
    public static final int CeremonialDress = 13;
    public static final int Submarine = 14;
    public static final int Trampoline = 15;
    public static final int ChineseHat = 16;
    public static final int Crystal = 17;
    public static final int Envelope = 18;
    public static final int House = 19;
    public static final int SmallCrystal = 20;
    public static final int Fish = 21;
    public static final int Sailboat = 22;
    public static final int Crushing = 23;
    public static final int Star = 24;
    public static final int Stellium = 25;
    public static final int FanHandle = 26;
    
    public static int getLast()
    {
        return FanHandle;
    }
    
    public static String getConfigName(int config)
    {
        switch(config)
        {
            case SmallTriangle: return bundle.getString("SmallTriangle");
            case GrandTrine: return bundle.getString("GrandTrine");
            case TCross: return bundle.getString("TCross");
            case Yod: return bundle.getString("Yod");
            case BirdWings: return bundle.getString("BirdWings");
            case Boat: return bundle.getString("Boat");
            case Boomerang: return bundle.getString("Boomerang");
            case Kite: return bundle.getString("Kite");
            case GrandSquare: return bundle.getString("GrandSquare");
            case Anvil: return bundle.getString("Anvil");
            case Mountain: return bundle.getString("Mountain");
            case Keepnet: return bundle.getString("Keepnet");
            case Rectangle: return bundle.getString("Rectangle");
            case CeremonialDress: return bundle.getString("CeremonialDress");
            case Submarine: return bundle.getString("Submarine");
            case Trampoline: return bundle.getString("Trampoline");
            case ChineseHat: return bundle.getString("ChineseHat");
            case Crystal: return bundle.getString("Crystal");
            case Envelope: return bundle.getString("Envelope");
            case House: return bundle.getString("House");
            case SmallCrystal: return bundle.getString("SmallCrystal");
            case Fish: return bundle.getString("Fish");
            case Sailboat: return bundle.getString("Sailboat");
            case Crushing: return bundle.getString("Crushing");
            case Star: return bundle.getString("StarConfig");
            case Stellium: return bundle.getString("Stellium");
            case FanHandle: return bundle.getString("FanHandle");
            default: return "???";
        }
    }
    
    public static String getPlanetaryConfigs(String val_aspect[][])
    {
        int i;
        int j;
        int k;
        int l;
        int m;
        int n;
        String strResult = "";
        int a1;
        int a2;
        int a3;
        int a4;
        int a5;
        int a6;
        int a7;
        int a8;
        int a9;
        int a10;
        int a11;
        int a12;
        int a13;
        int a14;
        int a15;
        boolean bConfigs[] = new boolean[getLast()];
        //Dim progress As New frmProgress();
        double v;
        
        //progress.Show();
        //progress.Refresh();
        
        for (i = 0 ; i <= Planets.MC; i++)
        {
            for (j = 0 ; j <= Planets.MC; j++)
            {
                a1 = AspectType.getAspectNBFromSymbol(val_aspect[i][j]);
                for (k = 0 ; k <= Planets.MC; k++)
                {
                    a2 = AspectType.getAspectNBFromSymbol(val_aspect[i][k]);
                    a3 = AspectType.getAspectNBFromSymbol(val_aspect[j][k]);
                    if ( a1 == AspectType.Sextile && a2 == AspectType.Sextile && a3 == AspectType.Trine )
                    {
                        bConfigs[0] = true;
                    }
                    else if ( a1 == AspectType.Trine && a2 == AspectType.Trine && a3 == AspectType.Trine )
                    {
                        bConfigs[1] = true;
                    }
                    else if ( a1 == AspectType.Square && a2 == AspectType.Square && a3 == AspectType.Opposition )
                    {
                        bConfigs[2] = true;
                    }
                    else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile )
                    {
                        bConfigs[3] = true;
                    }
                    
                    for (l = 0 ; l <= Planets.MC; l++)
                    {
                        a4 = AspectType.getAspectNBFromSymbol(val_aspect[i][l]);
                        a5 = AspectType.getAspectNBFromSymbol(val_aspect[j][l]);
                        a6 = AspectType.getAspectNBFromSymbol(val_aspect[k][l]);
                        if ( a1 == AspectType.Sextile && a2 == AspectType.Square && (a3 == AspectType.Inconjunct || a4 == AspectType.SemiSextile) && a5 == AspectType.Square && a6 == AspectType.Sextile )
                        {
                            bConfigs[4] = true;
                        }
                        else if ( a1 == AspectType.Opposition && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Sextile )
                        {
                            bConfigs[5] = true;
                        }
                        else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Opposition && a4 == AspectType.Inconjunct && a5 == AspectType.Sextile )
                        {
                            bConfigs[6] = true;
                        }
                        else if ( a1 == AspectType.Sextile && a2 == AspectType.Opposition && a3 == AspectType.Trine && a4 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Trine )
                        {
                            bConfigs[7] = true;
                        }
                        else if ( a1 == AspectType.Square && a2 == AspectType.Opposition && a3 == AspectType.Square && a4 == AspectType.Square && a5 == AspectType.Opposition && a6 == AspectType.Square )
                        {
                            bConfigs[8] = true;
                        }
                        else if ( a1 == AspectType.Trine && a2 == AspectType.Square && a3 == AspectType.SemiSextile && a5 == AspectType.Square && a6 == AspectType.Sextile )
                        {
                            bConfigs[9] = true;
                        }
                        else if ( a2 == AspectType.Trine && a3 == AspectType.Square && a4 == AspectType.Square && a5 == AspectType.Trine && a6 == AspectType.Inconjunct )
                        {
                            bConfigs[10] = true;
                        }
                        else if ( a1 == AspectType.SemiSextile && a2 == AspectType.Opposition && a3 == AspectType.Inconjunct && a4 == AspectType.Inconjunct && a5 == AspectType.Opposition && a6 == AspectType.SemiSextile )
                        {
                            bConfigs[11] = true;
                        }
                        else if ( a1 == AspectType.Trine && a2 == AspectType.Opposition && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Opposition && a6 == AspectType.Trine )
                        {
                            bConfigs[12] = true;
                        }
                        else if ( a2 == AspectType.Inconjunct && a3 == AspectType.Trine && a4 == AspectType.Trine && a5 == AspectType.Inconjunct && a6 == AspectType.Square )
                        {
                            bConfigs[13] = true;
                        }
                        else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile && a4 == AspectType.Sextile && a5 == AspectType.Inconjunct && a6 == AspectType.Square )
                        {
                            bConfigs[14] = true;
                        }
                        else if ( a1 == AspectType.Inconjunct && a2 == AspectType.Trine && a5 == AspectType.Trine && a6 == AspectType.Square )
                        {
                            bConfigs[15] = true;
                        }
                        else if ( a1 == AspectType.Conjunction && a3 == AspectType.Conjunction && a6 == AspectType.Conjunction && i != j && i != k && i != l && j != k && j != l && k != l )
                        {
                            bConfigs[25] = true;
                        }
                        
                        for (m = 0 ; m <= Planets.MC; m++)
                        {
                            a7 = AspectType.getAspectNBFromSymbol(val_aspect[i][m]);
                            a8 = AspectType.getAspectNBFromSymbol(val_aspect[j][m]);
                            a9 = AspectType.getAspectNBFromSymbol(val_aspect[k][m]);
                            a10 = AspectType.getAspectNBFromSymbol(val_aspect[l][m]);
                            if ( a1 == AspectType.Opposition && a3 == AspectType.SemiSextile && a4 == AspectType.Square && a5 == AspectType.Square && a6 == AspectType.Sextile && (a8 == AspectType.Inconjunct || a2 == AspectType.Inconjunct) && a9 == AspectType.Trine && a10 == AspectType.Sextile )
                            {
                                bConfigs[16] = true;
                            }
                            else if ( a1 == AspectType.Opposition && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Square && a5 == AspectType.Square && a6 == AspectType.SemiSextile && a7 == AspectType.Sextile && a8 == AspectType.Trine && a9 == AspectType.Sextile && a10 == AspectType.SemiSextile )
                            {
                                bConfigs[17] = true;
                            }
                            else if ( a1 == AspectType.Sextile && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Trine && a5 == AspectType.Opposition && a6 == AspectType.Trine && a7 == AspectType.Sextile && a8 == AspectType.Trine && a9 == AspectType.Opposition && a10 == AspectType.Sextile )
                            {
                                bConfigs[18] = true;
                            }
                            else if ( a1 == AspectType.Sextile && a3 == AspectType.Square && (a2 == AspectType.Inconjunct || a4 == AspectType.Inconjunct) && (a5 == AspectType.Inconjunct || a9 == AspectType.Inconjunct) && a6 == AspectType.Sextile && a7 == AspectType.Sextile && a8 == AspectType.Trine && a10 == AspectType.Square )
                            {
                                bConfigs[19] = true;
                            }
                            else if ( a1 == AspectType.Trine && a2 == AspectType.Square && a4 == AspectType.Sextile && a5 == AspectType.Sextile && a6 == AspectType.SemiSextile && a8 == AspectType.Square && a9 == AspectType.Sextile && a10 == AspectType.SemiSextile )
                            {
                                bConfigs[20] = true;
                            }
                            else if ( a1 == AspectType.Trine && (a2 == AspectType.Inconjunct || a4 == AspectType.Inconjunct) && a5 == AspectType.Square && a6 == AspectType.Sextile && a7 == AspectType.Trine && a8 == AspectType.Trine && a9 == AspectType.Square && (a3 == AspectType.SemiSextile || a10 == AspectType.SemiSextile))
                            {
                                bConfigs[21] = true;
                            }
                            else if ( a1 == AspectType.Square && a2 == AspectType.Inconjunct && a3 == AspectType.Sextile && a5 == AspectType.Trine && a6 == AspectType.Sextile && a7 == AspectType.Square && a8 == AspectType.Opposition && a9 == AspectType.Trine && a10 == AspectType.Sextile )
                            {
                                bConfigs[22] = true;
                            }
                            else if ( a1 == AspectType.Conjunction && a3 == AspectType.Conjunction && a6 == AspectType.Conjunction && (a7 == AspectType.Opposition || a8 == AspectType.Opposition || a9 == AspectType.Opposition || a10 == AspectType.Opposition) && i != j && i != k && i != l && j != k && j != l && k != l )
                            {
                                bConfigs[26] = true;
                            }
                            
                            for (n = 0 ; n <= Planets.MC; n++)
                            {
                                a11 = AspectType.getAspectNBFromSymbol(val_aspect[i][n]);
                                a12 = AspectType.getAspectNBFromSymbol(val_aspect[j][n]);
                                a13 = AspectType.getAspectNBFromSymbol(val_aspect[k][n]);
                                a14 = AspectType.getAspectNBFromSymbol(val_aspect[l][n]);
                                a15 = AspectType.getAspectNBFromSymbol(val_aspect[m][n]);
                                if ( a1 == AspectType.Sextile && a2 == AspectType.Inconjunct && a3 == AspectType.Square && a4 == AspectType.Opposition && a5 == AspectType.Trine && a6 == AspectType.SemiSextile && a7 == AspectType.Square && a8 == AspectType.Inconjunct && a9 == AspectType.Trine && a10 == AspectType.Square && a11 == AspectType.SemiSextile && a12 == AspectType.Square && a13 == AspectType.Opposition && a14 == AspectType.Inconjunct && a15 == AspectType.Sextile )
                                {
                                    bConfigs[23] = true;
                                }
                                else if ( a1 == AspectType.Sextile && a2 == AspectType.Trine && a3 == AspectType.Sextile && a4 == AspectType.Opposition && a5 == AspectType.Trine && a6 == AspectType.Sextile && a7 == AspectType.Trine && a8 == AspectType.Opposition && a9 == AspectType.Trine && a10 == AspectType.Sextile && a11 == AspectType.Sextile && a12 == AspectType.Trine && a13 == AspectType.Opposition && a14 == AspectType.Trine && a15 == AspectType.Sextile )
                                {
                                    bConfigs[24] = true;
                                }
                            }
                        }
                    }
                }
                v = (int)(AstronomyMaths.sgn(25.0 * (double)(i + j + 1)) / 6.25);
                //progress.ProgressBar1.Value = v;
                //progress.lblPercent.Text = CStr(v) + " " + "%";
                //progress.lblPercent.Refresh();
            }
        }
        
        for (i = 0; i < getLast(); i++)
        {
            if ( bConfigs[i])
            {
                strResult = strResult + ", " + getConfigName(i);
            }
        }
        if ( strResult.length() > 1 )
        {
            strResult = strResult.substring(0, strResult.length() - 2);
        }
        return strResult;
    }
}
