package StarLogin.Systeme.Enum;
/**
 *
 * @author Francois DESCHAMPS
 * @version 1.0.0
 **/

public class AlignOptions extends Object {        
    public static final byte _default = 0;        
    public static final byte left = 1;       
    public static final byte center = 2;       
    public static final byte right = 3; 
}