package StarLogin.Systeme.Enum;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Retro extends Object {        
    public static final byte Null = 0;        
    public static final byte Retro = 1;       
    public static final byte Static  = 2;  
    
    public static String getRetroString(int retro)
    {
        switch (retro)
        {
            case (int)Retro : return "R";
            case (int)Static : return "S";
            default : return "";
        }
    }
}
