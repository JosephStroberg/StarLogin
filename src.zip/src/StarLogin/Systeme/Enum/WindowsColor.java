package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class WindowsColor extends Object
{
    public static final byte Background = 0;
    public static final byte Foreground = 1;
    public static final byte LabelsBackground = 2;
    public static final byte LabelsForeground = 3;
    public static final byte TextZonesBackground = 4;
    public static final byte TextZonesForeground = 5;
    public static final byte ButtonsBackground = 6;
    public static final byte ButtonsForeground = 7;
}
