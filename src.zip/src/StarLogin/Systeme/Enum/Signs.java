package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import java.util.Locale;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Signs extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Sign1 = 0;
    public static final int Sign2 = 1;
    public static final int Sign3  = 2;
    public static final int Sign4  = 3;
    public static final int Sign5  = 4;
    public static final int Sign6  = 5;
    public static final int Sign7  = 6;
    public static final int Sign8  = 7;
    public static final int Sign9  = 8;
    public static final int Sign10  = 9;
    public static final int Sign11  = 10;
    public static final int Sign12  = 11;
    public static final int Aries = 0;
    public static final int Taurus = 1;
    public static final int Gemini  = 2;
    public static final int Cancer  = 3;
    public static final int Leo  = 4;
    public static final int Virgo  = 5;
    public static final int Libra  = 6;
    public static final int Scorpio  = 7;
    public static final int Sagittarius  = 8;
    public static final int Capricorn  = 9;
    public static final int Aquarius  = 10;
    public static final int Pisces  = 11;
    
    public static String getSignName(int sign)
    {
        switch(sign)
        {
            case Sign1: return bundle.getString("Sign1");
            case Sign2: return bundle.getString("Sign2");
            case Sign3: return bundle.getString("Sign3");
            case Sign4: return bundle.getString("Sign4");
            case Sign5: return bundle.getString("Sign5");
            case Sign6: return bundle.getString("Sign6");
            case Sign7: return bundle.getString("Sign7");
            case Sign8: return bundle.getString("Sign8");
            case Sign9: return bundle.getString("Sign9");
            case Sign10: return bundle.getString("Sign10");
            case Sign11: return bundle.getString("Sign11");
            case Sign12: return bundle.getString("Sign12");
            default: return "???";
        }
    }
    public static String getSignName2(int sign)
    {
        java.util.ResourceBundle bundle2;
        if (MainClass.locale == Locale.FRENCH)
        {
            bundle2 = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources_en");
        }
        else
        {
            bundle2 = java.util.ResourceBundle.getBundle("StarLogin/internationalization/Resources_fr");
        }
        switch(sign)
        {
            case Sign1: return bundle2.getString("Sign1");
            case Sign2: return bundle2.getString("Sign2");
            case Sign3: return bundle2.getString("Sign3");
            case Sign4: return bundle2.getString("Sign4");
            case Sign5: return bundle2.getString("Sign5");
            case Sign6: return bundle2.getString("Sign6");
            case Sign7: return bundle2.getString("Sign7");
            case Sign8: return bundle2.getString("Sign8");
            case Sign9: return bundle2.getString("Sign9");
            case Sign10: return bundle2.getString("Sign10");
            case Sign11: return bundle2.getString("Sign11");
            case Sign12: return bundle2.getString("Sign12");
            default: return "???";
        }
    }
    public static String getSignSymbol(int sign)
    {
        switch(sign)
        {
            case Sign1: return "s";
            case Sign2: return "t";
            case Sign3: return "u";
            case Sign4: return "v";
            case Sign5: return "w";
            case Sign6: return "x";
            case Sign7: return "y";
            case Sign8: return "z";
            case Sign9: return "{";
            case Sign10: return "|";
            case Sign11: return "}";
            case Sign12: return "~";
            default: return "";
        }
    }
    
    public static String getElement(int sign)
    {
        switch(sign)
        {
            case Sign1:
            case Sign5:
            case Sign9:
                return bundle.getString("Fire");
            case Sign2:
            case Sign6:
            case Sign10:
                return bundle.getString("Earth");
            case Sign3:
            case Sign7:
            case Sign11:
                return bundle.getString("Air");
            case Sign4:
            case Sign8:
            case Sign12:
                return bundle.getString("Water");
            default: return "";
        }
    }
    
    public static String getAngle(int sign)
    {
        switch(sign)
        {
            case Sign1:
            case Sign4:
            case Sign7:
            case Sign10:
                return "Card";
            case Sign2:
            case Sign5:
            case Sign8:
            case Sign11:
                return "Fix";
            case Sign3:
            case Sign6:
            case Sign9:
            case Sign12:
                return "Mut";
            default: return "";
        }
    }
}
