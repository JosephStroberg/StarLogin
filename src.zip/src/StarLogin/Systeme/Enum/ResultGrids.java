package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ResultGrids extends Object
{        
    public static final byte Normal = 0;        
    public static final byte Comparison = 1;       
    public static final byte Aspects  = 2;        
    public static final byte AspectsComparison  = 3;  
    public static final byte MidPoints  = 4; 
    public static final byte MidPointsComparison  = 5;  
    public static final byte Jupiter  = 6;  
    public static final byte RelativeAspects  = 7;  
    public static final byte Parts  = 8; 
}
