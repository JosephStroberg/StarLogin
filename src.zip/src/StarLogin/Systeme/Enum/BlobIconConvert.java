/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import java.io.*;
import java.sql.Blob;
import java.sql.SQLException;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.swing.ImageIcon;

/**
 *
 * @author francoisdeschamps
 */
public class BlobIconConvert
{
    public static ImageIcon blob2Icon(Blob blob)
    {
        ImageIcon icon = null;

        if (blob == null)
        {
            return null;
        }

        InputStream in = null;

        try
        {
            in = blob.getBinaryStream();
        }
        catch (SQLException se)
        {
            MainClass.setMessage(se.getMessage());
        }

        if (in != null)
        {
            int size = -1;

            try
            {
                size = in.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }

            OutputStream out = null;

            try
            {
                out = new FileOutputStream("img.jpg");
            }
            catch (java.io.FileNotFoundException fe)
            {
                MainClass.setMessage(fe.getMessage());
            }

            if (size > 0)
            {
                byte b[] = new byte[size];

                try
                {
                    in.read(b);

                    if (out != null)
                    {
                        out.write(b);
                        icon = new ImageIcon(b);
                    }
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }
            }
        }

        return icon;
    }

    public static byte[] WriteBlob(Blob blob)
    {
        byte b[] = null;

        if (blob == null)
        {
            return null;
        }

        // String strOut = null;
        InputStream in = null;
        OutputStream out = null;

        try
        {
            in = blob.getBinaryStream();
        }
        catch (SQLException se)
        {
            MainClass.setMessage(se.getMessage());
        }

        if (in != null)
        {
            int size = -1;

            try
            {
                size = in.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }

            try
            {
                out = new FileOutputStream("img.jpg");
            }
            catch (java.io.FileNotFoundException fe)
            {
                MainClass.setMessage(fe.getMessage());
            }

            if (size > 0)
            {
                b = new byte[size];

                try
                {
                    in.read(b);

                    if (out != null)
                    {
                        out.write(b);

                        // strOut = new String(b, "ISO-8859-1");
                    }
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }
            }
        }

        return b;    // strOut;
    }

    public static Blob icon2Blob(ImageIcon icon)
    {
        if (icon == null)
        {
            return null;
        }

        FileInputStream fs = null;
        SerialBlob blob = null;

        try
        {
            fs = new FileInputStream(icon.toString());
        }
        catch (FileNotFoundException fe)
        {
            MainClass.setMessage(fe.getMessage());
        }

        if (fs != null)
        {
            int size = -1;

            try
            {
                size = fs.available();
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }

            if (size > 0)
            {
                byte bytes[] = new byte[size];
                BufferedInputStream bis = new BufferedInputStream(fs);

                try
                {
                    bis.read(bytes);
                }
                catch (IOException ie)
                {
                    MainClass.setMessage(ie.getMessage());
                }

                try
                {
                    blob = new SerialBlob(bytes);
                }
                catch (SerialException se)
                {
                    MainClass.setMessage(se.getMessage());
                }
                catch (SQLException se)
                {
                    MainClass.setMessage(se.getMessage());
                }
            }
        }

        return (Blob) blob;
    }
}
