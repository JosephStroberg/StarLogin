package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class CoordSystem extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Tropical = 0;
    public static final int Sidereal = 1;
    public static final int Equatorial  = 2;
    public static final int Ecliptic  = 3;
    public static final int Local  = 4;
    public static final int HelioNormal  = 5;
    public static final int HelioSidereal  = 6;
    public static final int Cartesian  = 7;
    public static final int Spherical  = 8;
    public static final int Domitudes = 9;
    
    
    public static String getCoordSystemName(int coordSystem)
    {
        switch(coordSystem)
        {
            case Tropical: return bundle.getString("Tropical");
            case Sidereal: return bundle.getString("Sidereal");
            case Equatorial: return bundle.getString("Equatorial");
            case Ecliptic: return bundle.getString("Ecliptic");
            case Local: return bundle.getString("Local");
            case HelioNormal: return bundle.getString("HeliocentricNormal");
            case HelioSidereal: return bundle.getString("HeliocentricSidereal");
            case Cartesian: return bundle.getString("Cartesian");
            case Spherical: return bundle.getString("Spherical");
            case Domitudes: return bundle.getString("Domitudes");
            default: return bundle.getString("Tropical");
        }
    }
}
