package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class CalendarsKinds extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int EGYPTIEN = 0;
    public static final int ARMENIEN = 1;
    public static final int IEZDEJERD = 2;
    public static final int PERSE = 3;
    public static final int ALEXANDRE = 4;
    public static final int ETHIOPIEN = 5;
    public static final int COPTE = 6;
    public static final int MACEDONIEN = 7;
    public static final int SYRIEN = 8;
    public static final int JULIEN1 = 9;
    public static final int JULIEN2 = 10;
    public static final int JULIEN_ROMAIN = 11;
    public static final int GREGORIEN = 12;
    public static final int ISLAMIQUE1 = 13;
    public static final int ISLAMIQUE2 = 14;
    public static final int ISLAMIQUE3 = 15;
    public static final int ISLAMIQUE4 = 16;
    public static final int REPUBLICAIN = 17;
    public static final int ISRAELITE = 18;
    public static final int MAYA_LONG = 19;
    public static final int MAYA_TH = 20;
    
    public static int getLast()
    {
        return MAYA_TH;
    }
    
    public static String getName(int i)
    {
        switch(i)
        {
            case EGYPTIEN: return bundle.getString("Egyptian");
            case ARMENIEN: return bundle.getString("Armenian");
            case IEZDEJERD: return bundle.getString("Iezdejerd");
            case PERSE: return bundle.getString("Persian");
            case ALEXANDRE: return bundle.getString("Alexander");
            case ETHIOPIEN: return bundle.getString("Ethiopian");
            case COPTE: return bundle.getString("Copt");
            case MACEDONIEN: return bundle.getString("Macedonian");
            case SYRIEN: return bundle.getString("Syrian");
            case JULIEN1: return bundle.getString("Julian1");
            case JULIEN2: return bundle.getString("Julian2");
            case JULIEN_ROMAIN: return bundle.getString("JulianRoman");
            case GREGORIEN: return bundle.getString("Gregorian");
            case ISLAMIQUE1: return bundle.getString("Islamic1");
            case ISLAMIQUE2: return bundle.getString("Islamic2");
            case ISLAMIQUE3: return bundle.getString("Islamic3");
            case ISLAMIQUE4: return bundle.getString("Islamic4");
            case REPUBLICAIN: return bundle.getString("Republican");
            case ISRAELITE: return bundle.getString("Jewish");
            case MAYA_LONG: return bundle.getString("Mayan");
            case MAYA_TH: return bundle.getString("MayanTzolkinHaab");
            default : return "???";
        }
    }
}
