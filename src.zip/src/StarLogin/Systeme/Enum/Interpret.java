package StarLogin.Systeme.Enum;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Interpret extends Object {        
    public static final byte Signs = 0;        
    public static final byte Planets = 1;       
    public static final byte Houses  = 2;        
    public static final byte Aspects  = 3;  
    public static final byte Configurations  = 4; 
    public static final byte PlanetsInSign  = 5;  
    public static final byte PlanetsInHouse  = 6;  
    public static final byte HousesInSign  = 7;  
    public static final byte Relationships  = 8;   
    public static final byte ZodiacalConstellations  = 9; 
    public static final byte PlanetsInZodConstel  = 10; 
}