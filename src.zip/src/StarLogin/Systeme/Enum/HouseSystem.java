package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class HouseSystem extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Ancient = 0;
    public static final int TwoHours = 1;
    public static final int SemiAngular = 2; //Bissectrices in French
    public static final int Campanus = 3;
    public static final int EquatorialRegular = 4;    //Diisogone in French
    public static final int ColinEvans = 5;   //Graduelle in French
    public static final int Bazchenoff = 6;   //Harmonique in French
    public static final int MaternusAs = 7;
    public static final int MaternusMC = 8;
    public static final int Nodal = 9;
    public static final int Porphyre = 10;
    public static final int Regiomontanus = 11;
    public static final int Solar = 12;
    public static final int Wiesel = 13;
    public static final int Zenithal = 14;
    public static final int Zodiacal = 15;
    public static final int Abenragel = 16;
    public static final int Albategnius = 17;
    public static final int Alcabitius = 18;
    public static final int Koch = 19;
    public static final int Placidus = 20;
    
    public static String getHouseSystemName(int houseSystem)
    {
        switch(houseSystem)
        {
            case Ancient: return bundle.getString("Ancient");
            case TwoHours: return bundle.getString("TwoHours");
            case SemiAngular: return bundle.getString("SemiAngular");
            case Campanus: return "Campanus";
            case EquatorialRegular: return bundle.getString("EquatorialRegular");
            case ColinEvans: return bundle.getString("ColinEvans");
            case Bazchenoff: return bundle.getString("Bazchenoff");
            case MaternusAs: return "Maternus/AS";
            case MaternusMC: return "Maternus/MC";
            case Nodal: return bundle.getString("Nodal");
            case Porphyre: return "Porphyre";
            case Regiomontanus: return "Regiomontanus";
            case Solar: return bundle.getString("Solar");
            case Wiesel: return "Wiesel";
            case Zenithal: return bundle.getString("Zenithal");
            case Zodiacal: return bundle.getString("Zodiacal");
            case Abenragel: return "Abenragel";
            case Albategnius: return "Albategnius";
            case Alcabitius: return "Alcabitius";
            case Koch: return "Koch";
            case Placidus: return "Placidus";
            default: return "Campanus";
        }
    }
}