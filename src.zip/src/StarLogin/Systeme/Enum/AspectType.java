package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;
import StarLogin.Systeme.ChartElements;
import java.awt.Color;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class AspectType extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Conjunction = 0;
    public static final int Sextile = 1;
    public static final int Square = 2;
    public static final int Trine = 3;
    public static final int Opposition = 4;
    public static final int Vigintile = 5;
    public static final int SemiSextile = 6;
    public static final int SemiQuintile = 7;
    public static final int Nonagon = 8;
    public static final int SemiSquare = 9;
    public static final int Septile = 10;
    public static final int Quintile = 11;
    public static final int TriDectile = 12;
    public static final int SesquiSquare = 13;
    public static final int BiQuintile = 14;
    public static final int Inconjunct = 15;
    public static final int QuadriNonagon = 16;
    public static final int OtherAspect = 17;
    public static final int firstMajorAspect = Conjunction;
    public static final int lastMajorAspect = Opposition;
    public static final int firstMinorAspect = Vigintile;
    public static final int lastMinorAspect = OtherAspect;
    public static final int lastAspect = lastMinorAspect;
    public static final int harmonic = 0;
    public static final int dynamic = 1;
    public static final int neutral = 2;
    
    public static int getLast()
    {
        return OtherAspect;
    }
    
    public static double getAspectValue(int aspect)
    {
        switch (aspect)
        {
            case Conjunction : return 0.0;
            case Sextile : return 60.0;
            case Square : return 90.0;
            case Trine : return 120.0;
            case Opposition : return 180.0;
            case Vigintile : return 18.0;
            case SemiSextile : return 30.0;
            case SemiQuintile : return 36.0;
            case Nonagon : return 40.0;
            case SemiSquare : return 45.0;
            case Septile : return 51.42857;
            case Quintile : return 72.0;
            case TriDectile : return 108.0;
            case SesquiSquare : return 135.0;
            case BiQuintile : return 144.0;
            case Inconjunct : return 150.0;
            case QuadriNonagon : return 160.0;
            case OtherAspect : return 0.0;
            default: return 0.0;
        }
    }
    
    public static double getAspectValue(int aspect, ChartElements chartElements)
    {
        switch (aspect)
        {
            case OtherAspect : return new Double(chartElements.getOtherAspectValue()).doubleValue();
            case Conjunction : return 0.0;
            case Sextile : return 60.0;
            case Square : return 90.0;
            case Trine : return 120.0;
            case Opposition : return 180.0;
            case Vigintile : return 18.0;
            case SemiSextile : return 30.0;
            case SemiQuintile : return 36.0;
            case Nonagon : return 40.0;
            case SemiSquare : return 45.0;
            case Septile : return 51.42857;
            case Quintile : return 72.0;
            case TriDectile : return 108.0;
            case SesquiSquare : return 135.0;
            case BiQuintile : return 144.0;
            case Inconjunct : return 150.0;
            case QuadriNonagon : return 160.0;
            default: return 0.0;
        }
    }
    
    public static String getAspectName(int aspect, ChartElements chartElements)
    {
        switch(aspect)
        {
            case OtherAspect: return chartElements.getOtherAspectName();
            case Conjunction: return bundle.getString("Conjunction");
            case Sextile: return bundle.getString("Sextile");
            case Square: return bundle.getString("Square");
            case Trine: return bundle.getString("Trine");
            case Opposition: return bundle.getString("Opposition");
            case Vigintile: return bundle.getString("Vigintile");
            case SemiSextile: return bundle.getString("SemiSextile");
            case SemiQuintile: return bundle.getString("SemiQuintile");
            case Nonagon: return bundle.getString("Nonagon");
            case SemiSquare: return bundle.getString("SemiSquare");
            case Septile: return bundle.getString("Septile");
            case Quintile: return bundle.getString("Quintile");
            case TriDectile: return bundle.getString("TriDectile");
            case SesquiSquare: return bundle.getString("SesquiSquare");
            case BiQuintile: return bundle.getString("BiQuintile");
            case Inconjunct: return bundle.getString("Inconjunct");
            case QuadriNonagon: return bundle.getString("QuadriNonagon");
            default: return "???";
        }
    }
    
    public static String getAspectName(int aspect)
    {
        switch(aspect)
        {
            case Conjunction: return bundle.getString("Conjunction");
            case Sextile: return bundle.getString("Sextile");
            case Square: return bundle.getString("Square");
            case Trine: return bundle.getString("Trine");
            case Opposition: return bundle.getString("Opposition");
            case Vigintile: return bundle.getString("Vigintile");
            case SemiSextile: return bundle.getString("SemiSextile");
            case SemiQuintile: return bundle.getString("SemiQuintile");
            case Nonagon: return bundle.getString("Nonagon");
            case SemiSquare: return bundle.getString("SemiSquare");
            case Septile: return bundle.getString("Septile");
            case Quintile: return bundle.getString("Quintile");
            case TriDectile: return bundle.getString("TriDectile");
            case SesquiSquare: return bundle.getString("SesquiSquare");
            case BiQuintile: return bundle.getString("BiQuintile");
            case Inconjunct: return bundle.getString("Inconjunct");
            case QuadriNonagon: return bundle.getString("QuadriNonagon");
            case OtherAspect: return bundle.getString("OtherAspect");
            default: return "???";
        }
    }
    
    public static int getAspectNBFromSymbol(String symbol)
    {
        if (symbol.equals("a")) return Conjunction;
        else if (symbol.equals("b")) return Sextile;
        else if (symbol.equals("c")) return Square;
        else if (symbol.equals("d")) return Trine;
        else if (symbol.equals("e")) return Opposition;
        else if (symbol.equals("f")) return SemiSextile;
        else if (symbol.equals("g")) return SemiQuintile;
        else if (symbol.equals("h")) return Nonagon;
        else if (symbol.equals("i")) return SemiSquare;
        else if (symbol.equals("j")) return Septile;
        else if (symbol.equals("k")) return Quintile;
        else if (symbol.equals("l")) return TriDectile;
        else if (symbol.equals("m")) return SesquiSquare;
        else if (symbol.equals("n")) return BiQuintile;
        else if (symbol.equals("o")) return Inconjunct;
        else if (symbol.equals("p")) return QuadriNonagon;
        else if (symbol.equals("q")) return Vigintile;
        else if (symbol.equals("r")) return OtherAspect;
        return -1;
    }
    
    public static int translateAspectType(String aspectType)
    {
        if (aspectType.equals("N")) return neutral;
        else if (aspectType.equals("H")) return harmonic;
        else if (aspectType.equals("D")) return dynamic;
        return neutral;
    }
    
    public static String getAspectSymbol(int aspect)
    {
        switch(aspect)
        {
            case Conjunction: return "a";
            case Sextile: return "b";
            case Square: return "c";
            case Trine: return "d";
            case Opposition: return "e";
            case Vigintile: return "q";
            case SemiSextile: return "f";
            case SemiQuintile: return "g";
            case Nonagon: return "h";
            case SemiSquare: return "i";
            case Septile: return "j";
            case Quintile: return "k";
            case TriDectile: return "l";
            case SesquiSquare: return "m";
            case BiQuintile: return "n";
            case Inconjunct: return "o";
            case QuadriNonagon: return "p";
            case OtherAspect: return "r";
            default: return "";
        }
    }
    
    //=========================================================================
    //Calculation of l'orbe d'un aspect potentiel entre deux astres
    //input : point1 : numero du premier astre considere
    //        point2 : numero de l'autre astre
    //        aspect : valeur de l'aspect potentiel
    //return         : valeur de l'orbe
    //=========================================================================
    public static double orbCalculation(int point1, int point2, int aspect, ChartElements chartElements)
    {
        int divNum;
        boolean entrance = false;
        
        if ( aspect <= lastMajorAspect )
        {
            divNum = aspect;
        }
        else
        {
            divNum = firstMinorAspect;
        }
        
        if ( aspect == lastMinorAspect )
        {
            //le dernier aspect se saisit dans le cadre correspondant
            if ( !chartElements.getOtherAspectName().equals("") )
            {
                entrance = true;
            }
            else
            {
                entrance = false;
            }
        }
        else if ( aspect < lastMinorAspect  )
        {
            if ( chartElements.getShownAspect(aspect))
            {
                entrance = true;
            }
            else
            {
                entrance = false;
            }
        }
        
        //si l'aspect figure parmi ceux choisis en option
        if ( entrance == true )
        {
            if ( point1 == Planets.Sun || point1 == Planets.Moon )
            {
                if ( point2 == Planets.Sun || point2 == Planets.Moon )
                {
                    return chartElements.getOrbLightLight() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Mercury || point2 == Planets.Venus || point2 == Planets.Gaia || point2 == Planets.Mars )
                {
                    return chartElements.getOrbLightTell() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Jupiter || point2 == Planets.Saturn )
                {
                    return chartElements.getOrbLightOtherInd() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Uranus || point2 == Planets.Neptune || point2 == Planets.Pluto || point2 == Planets.Vulcan || (point2 >= Planets.Ceres &&  point2 <= Planets.Chiron))
                {
                    return chartElements.getOrbLightColl() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.NorthNode || point2 == Planets.Lilith || point2 == Planets.AS || point2 == Planets.MC )
                {
                    return chartElements.getOrbLightVirtMax() / chartElements.getDivisor(divNum);
                }
                else
                {
                    return chartElements.getOrbLightVirtMin() / chartElements.getDivisor(divNum);
                }
            }
            
            else if ( point1 == Planets.Mercury || point1 == Planets.Venus || point1 == Planets.Gaia || point1 == Planets.Mars )
            {
                if ( point2 == Planets.Mercury || point2 == Planets.Venus || point2 == Planets.Gaia || point2 == Planets.Mars )
                {
                    return chartElements.getOrbTellTell() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Jupiter || point2 == Planets.Saturn )
                {
                    return chartElements.getOrbTellOtherInd() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Uranus || point2 == Planets.Neptune || point2 == Planets.Pluto || point2 == Planets.Vulcan || (point2 >= Planets.Ceres &&  point2 <= Planets.Chiron))
                {
                    return chartElements.getOrbTellColl() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.NorthNode || point2 == Planets.Lilith || point2 == Planets.AS || point2 == Planets.MC )
                {
                    return chartElements.getOrbTellVirtMax() / chartElements.getDivisor(divNum);
                }
                else
                {
                    return chartElements.getOrbTellVirtMin() / chartElements.getDivisor(divNum);
                }
            }
            
            else if ( point1 == Planets.Jupiter || point1 == Planets.Saturn )
            {
                if ( point2 == Planets.Jupiter || point2 == Planets.Saturn )
                {
                    return chartElements.getOrbOtherIndOtherInd() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.Uranus || point2 == Planets.Neptune || point2 == Planets.Pluto || point2 == Planets.Vulcan || (point2 >= Planets.Ceres &&  point2 <= Planets.Chiron))
                {
                    return chartElements.getOrbOtherIndColl() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.NorthNode || point2 == Planets.Lilith || point2 == Planets.AS || point2 == Planets.MC )
                {
                    return chartElements.getOrbOtherIndVirtMax() / chartElements.getDivisor(divNum);
                }
                else
                {
                    return chartElements.getOrbOtherIndVirtMin() / chartElements.getDivisor(divNum);
                }
            }
            
            else if ( point1 == Planets.Uranus || point1 == Planets.Neptune || point1 == Planets.Pluto || point1 == Planets.Vulcan || (point1 >= Planets.Ceres &&  point1 <= Planets.Chiron))
            {
                if ( point2 == Planets.Uranus || point2 == Planets.Neptune || point2 == Planets.Pluto || point2 == Planets.Vulcan || (point2 >= Planets.Ceres &&  point2 <= Planets.Chiron))
                {
                    return chartElements.getOrbCollColl() / chartElements.getDivisor(divNum);
                }
                else if ( point2 == Planets.NorthNode || point2 == Planets.Lilith || point2 == Planets.AS || point2 == Planets.MC )
                {
                    return chartElements.getOrbCollVirtMax() / chartElements.getDivisor(divNum);
                }
                else
                {
                    return chartElements.getOrbCollVirtMin() / chartElements.getDivisor(divNum);
                }
            }
            
            else if ( point1 == Planets.NorthNode || point1 == Planets.Lilith || point1 == Planets.AS || point1 == Planets.MC )
            {
                if ( point2 == Planets.NorthNode || point2 == Planets.Lilith || point2 == Planets.AS || point2 == Planets.MC )
                {
                    return chartElements.getOrbVirtMaxVirtMax() / chartElements.getDivisor(divNum);
                }
                else
                {
                    return chartElements.getOrbVirtMaxVirtMin() / chartElements.getDivisor(divNum);
                }
            }
            
            else
            {
                return chartElements.getOrbVirtMinVirtMin() / chartElements.getDivisor(divNum);
            }
        }
        else
        {
            return -1;
        }
    }
    
    //=========================================================================
    //Get the color of an aspect, according to its type
    //input : aspect : number of the aspect
    //return         : numerical value of the color of the aspect
    //=========================================================================
    public static Color aspectKindColor(String aspect, ChartElements chartElements)
    {
        int i;
        if (aspect == null || aspect.equals("")) return Color.BLACK;
        
        if (chartElements.getColoredAspects())
        {
            for (i = 0; i <= lastAspect; i++)
            {
                if (aspect.equals(getAspectSymbol(i)))
                {
                    return chartElements.getColorAspect(i);
                }
            }
        }
        else
        {
            for (i = 0; i <= lastAspect; i++)
            {
                if (aspect.equals(getAspectSymbol(i)))
                {
                    if (chartElements.getTypeAspect(i) == translateAspectType("N"))
                    {
                        return chartElements.getNeutralColor();
                    }
                    else if (chartElements.getTypeAspect(i) == translateAspectType("H"))
                    {
                        return chartElements.getHarmonicColor();
                    }
                    else if (chartElements.getTypeAspect(i) == translateAspectType("D"))
                    {
                        return chartElements.getDynamicColor();
                    }
                }
            }
        }
        return Color.BLACK;
    }
}
