package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class LocalDateFormat extends Object {        
    public static final byte French = 1;        
    public static final byte English = 2;  
}
