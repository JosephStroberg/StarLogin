package StarLogin.Systeme.Enum;

//~--- JDK imports ------------------------------------------------------------
import StarLogin.IHM.MainClass;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author Francois DESCHAMPS
 * @version 2.0.0
 */
public class OS
{
    public static final int apple = 1;
    public static final int windows = 0;
    public static final int linux = 2;

    public static int getOS()
    {
        String systemName = System.getProperty("os.name");

        systemName = systemName.substring(0, 5);

        if (systemName.equals("Windo"))
        {
            return windows;
        }
        if (systemName.equals("Linux"))
        {
            return linux;
        }
        else
        {
            return apple;
        }
    }

    /*public static void runOOffice(String[] args)
    {
        String argString = "";
        for (int i=0; i<args.length; i++)
        {
            argString = argString.concat(" "+args[i]);
        }
        if (getOS() == windows)
        {
            try
            {
                Runtime rt = Runtime.getRuntime();
                rt.exec("java -jar c:\\OfficeUNOClientApp\\OfficeUNOClientApp.jar" + argString);
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }
        }
        else
        {
            try
            {
                Runtime rt = Runtime.getRuntime();
                rt.exec("java -jar /Users/francoisdeschamps/Devt/Java/OfficeUNOClientApp/dist/OfficeUNOClientApp.jar" + argString);
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }
        }
    }*/
    
    @SuppressWarnings("unchecked")
    public static String processDosName(String filename)
    {
        StringTokenizer stkrow = new StringTokenizer(filename, "\\");
        String newname = "";
        ArrayList liste = new ArrayList();
        while (stkrow.hasMoreElements())
        {
            Object row = stkrow.nextToken();
            String srow = MainClass.null2String(row);
            srow = srow.trim();
            liste.add(srow);
        }
        Object[] oliste = liste.toArray();
        boolean[] btilde = new boolean[oliste.length];
        for (int i = 0; i < oliste.length ; i++)
        {
            btilde[i] = false;
            String srow = MainClass.null2String(oliste[i]);
            if (srow.length() > 8)
                btilde[i] = true;
            oliste[i] = srow;
        }
        Object[] otmp = new Object[oliste.length];
        
        for (int i = oliste.length - 1; i >= 0 ; i--)
        {
            if (btilde[i])
            {
                System.arraycopy(oliste, 0, otmp, 0, oliste.length);
                int j = 1;
                boolean result = false;
                while(result == false && j < 10)
                {
                    String srow = MainClass.null2String(otmp[i]);
                    srow = srow.substring(0, 6).concat("~") + j;
                    otmp[i] = srow;
                    newname = buildFileName(otmp);
                    j++;
                    File fichier = new File(newname);
                    result = fichier.exists();
                }
                if (result)
                {
                    oliste[i] = otmp[i];
                }
            }
        }
        return newname;
    }
    
    private static String buildFileName(Object[] oliste)
    {
        String nomfichier = "";
        for (int i = 0; i < oliste.length ; i++)
        {
            if (i == 0)
                nomfichier = MainClass.null2String(oliste[i]);
            else
                nomfichier = nomfichier.concat("\\").concat(MainClass.null2String(oliste[i]));
        }
        return nomfichier;
    }
    
    public static String getFileCreationDateOrTime(String filename, boolean bDate, boolean bTime)
    {	
        if (OS.getOS() == OS.windows)
        {
            try
            {
                filename = processDosName(filename);
                Process proc = Runtime.getRuntime().exec("cmd /c dir " + filename + " /t:c");
                /*try
                {
                    proc.waitFor();
                }
                catch (InterruptedException ex)
                {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }*/
                InputStreamReader in = new InputStreamReader(proc.getInputStream());
                BufferedReader br = new BufferedReader(in);

                String data = "";

                for (int i = 0; i < 6; i++)
                {
                    data = br.readLine();
                }

                //System.out.println("Extracted value : " + data);

                //split by space
                StringTokenizer st = new StringTokenizer(data);
                String date = st.nextToken();//Get date
                String time = st.nextToken();//Get time

                //System.out.println("Creation Date  : " + date);
                //System.out.println("Creation Time  : " + time);
                String result = "";
                if (bDate && !bTime)
                    result = date;
                else if (bTime && !bDate)
                    result = time;
                else if (bDate && bTime)
                    result = date + " " + time;
                in.close();
                br.close();
                return result;

            }
            catch (IOException e)
            {
                MainClass.setMessage(e.getMessage());
                return null;
            }
        }
        else
        {
            String cmd = "stat -t\"%F_%H-%M-%S\" " + filename;
            Runtime run = Runtime.getRuntime();
            Process pr;
            try
            {
                pr = run.exec(cmd);
                try
                {
                    pr.waitFor();
                }
                catch (InterruptedException ex)
                {
                    MainClass.setMessage(ex.getMessage());
                }
                InputStreamReader in = new InputStreamReader(pr.getInputStream());
                BufferedReader buf = new BufferedReader(in);
                String line;
                if ((line = buf.readLine()) != null)
                {
                    //System.out.println(line);
                    StringTokenizer st = new StringTokenizer(line);
                    //"16777218 32671158 drwxrwxrwx 10 francoisdeschamps staff 0 340 ""2013-08-12" ""2013-08-07" ""2013-08-08" ""2013-06-04" 4096 0 0 /Users/francoisdeschamps/Devt/Java/Isydata/data"
                    String col1 = st.nextToken();
                    String col2 = st.nextToken();
                    String accessRights = st.nextToken();
                    String x = st.nextToken();
                    String creator = st.nextToken();
                    String group = st.nextToken();
                    String s = st.nextToken();
                    String size = st.nextToken();
                    String dateAccess = st.nextToken();
                    String dateModif = st.nextToken();
                    String dateChange = st.nextToken();
                    String dateCreation = st.nextToken();
                    line = dateChange;
                }
                else
                    line = "";
                in.close();
                buf.close();
                return line;
            }
            catch (IOException ex)
            {
                MainClass.setMessage(ex.getMessage());
                return null;
            }
        }
    }
    
    public static String getCurrentUser()
    {	
        return System.getProperty("user.name");
    }

    public static void runExplorer(String pathName)
    {
        if (getOS() == windows)
        {
            try
            {
                while (pathName.lastIndexOf("/") > 0)
                {
                    pathName = pathName.replace("/", "\\");
                }

                Runtime rt = Runtime.getRuntime();

                rt.exec("explorer.exe " + pathName);
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }
        }
        else
        {
            try
            {
                Runtime rt = Runtime.getRuntime();

                rt.exec("open /Applications/Safari.app " + pathName);
            }
            catch (IOException ie)
            {
                MainClass.setMessage(ie.getMessage());
            }
        }
    }

    public static String getSeparator()
    {
        if (getOS() == windows)
        {
            return "\\";
        }
        else
        {
            return "/";
        }
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
