package StarLogin.Systeme.Enum;
/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Direction extends Object {        
    public static final byte North = 1;        
    public static final byte South = 2;       
    public static final byte East  = 3;        
    public static final byte West  = 4;    
}
