package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Cusp extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int House1 = 0;
    public static final int House2 = 1;
    public static final int House3  = 2;
    public static final int House4  = 3;
    public static final int House5  = 4;
    public static final int House6  = 5;
    public static final int House7  = 6;
    public static final int House8  = 7;
    public static final int House9  = 8;
    public static final int House10  = 9;
    public static final int House11  = 10;
    public static final int House12  = 11;
    public static final int Ascendant  = 12;
    public static final int Midheaven  = 13;
    
    public static String getCuspName(int cusp)
    {
        switch(cusp)
        {
            case House1: return bundle.getString("House1");
            case House2: return bundle.getString("House2");
            case House3: return bundle.getString("House3");
            case House4: return bundle.getString("House4");
            case House5: return bundle.getString("House5");
            case House6: return bundle.getString("House6");
            case House7: return bundle.getString("House7");
            case House8: return bundle.getString("House8");
            case House9: return bundle.getString("House9");
            case House10: return bundle.getString("House10");
            case House11: return bundle.getString("House11");
            case House12: return bundle.getString("House12");
            case Ascendant: return bundle.getString("Ascendant");
            case Midheaven: return bundle.getString("Midheaven");
            default: return bundle.getString("Ascendant");
        }
    }
}