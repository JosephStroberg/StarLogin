package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Coordinate extends Object
{        
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int Azimuth = 0;        
    public static final int Altitude = 1;       
    public static final int RightAscension  = 2;        
    public static final int Declination  = 3;  
    public static final int Latitude  = 4; 
    public static final int Longitude  = 5;  
    public static final int GeoDistance = 6;
    public static final int HelioDistance = 7;
    public static final int TropicGeoLong = 8;
    public static final int TropicHelioLong = 9;
    public static final int SiderGeoLong = 10;
    public static final int SiderHelioLong = 11;
    public static final int GeoLat = 12;
    public static final int HelioLat = 13;
    public static final int Domitude = 14;
    
    public static String getCoordinateName(int coord)
    {
        switch(coord)
        {
            case Azimuth: return bundle.getString("Azimuth");
            case Altitude: return bundle.getString("Altitude");
            case RightAscension: return bundle.getString("RightAscension");
            case Declination: return bundle.getString("Declination");
            case Latitude: return bundle.getString("Latitude");
            case Longitude: return bundle.getString("Longitude");
            case GeoDistance: return bundle.getString("GeoDistance");
            case HelioDistance: return bundle.getString("HelioDistance");
            case TropicGeoLong: return bundle.getString("TropicGeoLong");
            case TropicHelioLong: return bundle.getString("TropicHelioLong");
            case SiderGeoLong: return bundle.getString("SiderGeoLong");
            case SiderHelioLong: return bundle.getString("SiderHelioLong");
            case GeoLat: return bundle.getString("GeoLat");
            case HelioLat: return bundle.getString("HelioLat");
            case Domitude: return bundle.getString("Domitude");
            default: return bundle.getString("???");
        }
    } 
}