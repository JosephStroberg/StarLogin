package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 2.0.0
 */
public class ComboRenderers {
    public static final int TextArea = 1;
    public static final int TextPane = 2;

    // public static final int Panel = 3;
    // public static final int HTML = 4;
}


//~ Formatted by Jindent --- http://www.jindent.com
