package StarLogin.Systeme.Enum;

import StarLogin.IHM.MainClass;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartKind extends Object
{        
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    public static final int noChart = 99;        
    public static final int normal = 0;
    public static final int local = 1;
    public static final int seed = 2;
    public static final int symbolicDir = 3;
    public static final int primaryDir = 4;
    public static final int secondaryDir = 5;
    public static final int transit = 6;
    public static final int revolution = 7;
    public static final int cycle = 8;
    public static final int synastry = 9;
    public static final int composite = 10;
    public static final int free = 11;
    public static final int projective = 12;
    public static final int harmonic = 13;
    public static final int various = 100;
    public static final int all = -99;
    
    public static String getChartKindName(int chartKind)
    {
        switch(chartKind)
        {
            case normal: return bundle.getString("NormalChart");
            case local: return bundle.getString("LocalChart");
            case seed: return bundle.getString("SeedHoroscope");
            case symbolicDir: return bundle.getString("SymbolicDir");
            case primaryDir: return bundle.getString("PrimaryDir");
            case secondaryDir: return bundle.getString("SecondaryDir");
            case transit: return bundle.getString("Transits");
            case revolution: return bundle.getString("Revolution");
            case cycle: return bundle.getString("Cycle");
            case synastry: return bundle.getString("Synastry");
            case composite: return bundle.getString("Composite");
            case free: return bundle.getString("FreeChart");
            case projective: return bundle.getString("ProjectiveChart");
            case harmonic: return bundle.getString("HarmonicChart");
            default : return "";
        }
    }
}