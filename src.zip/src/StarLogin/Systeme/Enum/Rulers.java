package StarLogin.Systeme.Enum;

import StarLogin.IHM.DialogDoc;
import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;
import StarLogin.Systeme.AstroCalc.AllCoord;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.ChartElements;
import StarLogin.Systeme.iofiles.HTMLStrings;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JDialog;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class Rulers
{
    private static final java.util.ResourceBundle bundle = MainClass.bundle;
    //private static int windowNB = 0;
    public static final int Sign1 = 0;
    public static final int Sign2 = 1;
    public static final int Sign3 = 2;
    public static final int Sign4 = 3;
    public static final int Sign5 = 4;
    public static final int Sign6 = 5;
    public static final int Sign7 = 6;
    public static final int Sign8 = 7;
    public static final int Sign9 = 8;
    public static final int Sign10 = 9;
    public static final int Sign11 = 10;
    public static final int Sign12 = 11;
    public static final int Orthodox = 0;
    public static final int Modern = 1;
    public static final int Esoteric = 2;
    public static final int Hierarchical = 3;
    public static final int Both = 2;
    public static final int All = 4;
    public static final int InSign = 0;
    public static final int InHouse = 1;
    public static final String domicile = bundle.getString("Home");
    public static final String exil = bundle.getString("Exile");
    public static final String exaltation = bundle.getString("Exaltation");
    public static final String chute = bundle.getString("Detriment");
    private String sHeader;
    private AllCoord allCoord;
    private int rulerKind;
    private int rulerRef;
    private int sys_coord;
    private String sHtml;
    private HTMLStrings htmlStrings;
    private ChartElements chartElements;
    
    public static String getRulerKind(int rulerKind)
    {
        switch(rulerKind)
        {
            case Modern: return bundle.getString("Modern");
            case Orthodox: return bundle.getString("Traditional");
            case Esoteric: return bundle.getString("Esoteric");
            case Hierarchical: return bundle.getString("Hierarchical");
            case All: return bundle.getString("All");
            default: return "???";
        }
    }
    
    public static String getRulerRef(int rulerRef)
    {
        switch(rulerRef)
        {
            case InSign: return bundle.getString("InSign");
            case InHouse: return bundle.getString("InHouse");
            case Both: return bundle.getString("Both");
            default: return "???";
        }
    }
    
    public Rulers(ChartElements chartElements, String aspectKinds[][], int rulerKind, int rulerRef, AllCoord allCoord)
    {
        this.sHeader = chartElements.getChartHeader();
        this.rulerKind = rulerKind;
        this.rulerRef = rulerRef;
        this.allCoord = allCoord;
        this.sys_coord = chartElements.getCoordSys();
        htmlStrings = new HTMLStrings(chartElements, aspectKinds);
        this.chartElements = chartElements;
        process();
    }
    
    private int getRuler(int rulerships, int sign)
    {
        switch(rulerships)
        {
            case Orthodox:
                switch(sign)
                {
                    case Sign1: return 4;
                    case Sign2: return 3;
                    case Sign3: return 2;
                    case Sign4: return 1;
                    case Sign5: return 0;
                    case Sign6: return 2;
                    case Sign7: return 3;
                    case Sign8: return 4;
                    case Sign9: return 5;
                    case Sign10: return 6;
                    case Sign11: return 6;
                    case Sign12: return 5;
                    default: return -1;
                }
            case Modern:
                switch(sign)
                {
                    case Sign1: return 4;
                    case Sign2: return 3;
                    case Sign3: return 2;
                    case Sign4: return 1;
                    case Sign5: return 0;
                    case Sign6: return 2;
                    case Sign7: return 3;
                    case Sign8: return 9;
                    case Sign9: return 5;
                    case Sign10: return 6;
                    case Sign11: return 7;
                    case Sign12: return 8;
                    default: return -1;
                }
            case Esoteric:
                switch(sign)
                {
                    case Sign1: return 2;
                    case Sign2: return 16;
                    case Sign3: return 3;
                    case Sign4: return 8;
                    case Sign5: return 0;
                    case Sign6: return 1;
                    case Sign7: return 7;
                    case Sign8: return 4;
                    case Sign9: return 10;
                    case Sign10: return 6;
                    case Sign11: return 5;
                    case Sign12: return 9;
                    default: return -1;
                }
            case Hierarchical:
                switch(sign)
                {
                    case Sign1: return 7;
                    case Sign2: return 16;
                    case Sign3: return 10;
                    case Sign4: return 8;
                    case Sign5: return 0;
                    case Sign6: return 5;
                    case Sign7: return 6;
                    case Sign8: return 2;
                    case Sign9: return 4;
                    case Sign10: return 3;
                    case Sign11: return 1;
                    case Sign12: return 9;
                    default: return -1;
                }
            default: return -1;
        }
    }
    
    public static String dignityCalculation(int astre, int sign)
    {
        switch(astre)
        {
            case Planets.Sun:
                if ( sign == Signs.Leo )
                    return domicile;
                else if ( sign == Signs.Aquarius )
                    return exil;
                else if ( sign == Signs.Aries )
                    return exaltation;
                else if ( sign == Signs.Libra )
                    return chute;
                else
                    return "";
                
            case Planets.Moon:
                if ( sign == Signs.Cancer )
                    return domicile;
                else if ( sign == Signs.Capricorn )
                    return exil;
                else if ( sign == Signs.Taurus )
                    return exaltation;
                else if ( sign == Signs.Scorpio )
                    return chute;
                else
                    return "";
                
            case Planets.Mercury:
                if ( sign == Signs.Gemini || sign == Signs.Virgo )
                    return domicile;
                else if ( sign == Signs.Sagittarius || sign == Signs.Pisces )
                    return exil;
                else if ( sign == Signs.Virgo )
                    return exaltation;
                else if ( sign == Signs.Pisces )
                    return chute;
                else
                    return "";
                
            case Planets.Venus:
                if ( sign == Signs.Libra || sign == Signs.Taurus )
                    return domicile;
                else if ( sign == Signs.Aries || sign == Signs.Scorpio )
                    return exil;
                else if ( sign == Signs.Pisces )
                    return exaltation;
                else if ( sign == Signs.Virgo )
                    return chute;
                else
                    return "";
                
            case Planets.Mars:
                if ( sign == Signs.Aries || sign == Signs.Scorpio )
                    return domicile;
                else if ( sign == Signs.Libra || sign == Signs.Taurus )
                    return exil;
                else if ( sign == Signs.Capricorn )
                    return exaltation;
                else if ( sign == Signs.Cancer )
                    return chute;
                else
                    return "";
                
            case Planets.Jupiter:
                if ( sign == Signs.Sagittarius || sign == Signs.Pisces )
                    return domicile;
                else if ( sign == Signs.Gemini || sign == Signs.Virgo )
                    return exil;
                else if ( sign == Signs.Cancer )
                    return exaltation;
                else if ( sign == Signs.Capricorn )
                    return chute;
                else
                    return "";
            
            case Planets.Saturn:
                if ( sign == Signs.Capricorn || sign == Signs.Aquarius )
                    return domicile;
                else if ( sign == Signs.Cancer || sign == Signs.Leo )
                    return exil;
                else if ( sign == Signs.Libra )
                    return exaltation;
                else if ( sign == Signs.Aries )
                    return chute;
                else
                    return "";
                
            case Planets.Uranus:
                if ( sign == Signs.Aquarius )
                    return domicile;
                else if ( sign == Signs.Leo )
                    return exil;
                else
                    return "";
                
            case Planets.Neptune:
                if ( sign == Signs.Pisces )
                    return domicile;
                else if ( sign == Signs.Virgo )
                    return exil;
                else
                    return "";
            
            case Planets.Pluto:
                if ( sign == Signs.Scorpio )
                    return domicile;
                else if ( sign == Signs.Taurus )
                    return exil;
                else
                    return "";
                
            default: return "";
        }
    }
    
    private void process()
    {
        //Header of the document
        String sDocument = "<p style='background-color: #FFE1C3;' align='center' width='75%'><b><font color='#C300FF' face='arial' size='5'>";
        sDocument = sDocument.concat(bundle.getString("Rulers"));
        sDocument = sDocument.concat("</font></b>");


        sDocument = sDocument.concat("<p style=' align='center'><b><font color='#0000ff' face='arial' size='2'>");
        sDocument = sDocument.concat(sHeader);
        sDocument = sDocument.concat("</font></b>");

        sDocument = sDocument.concat("<p style=' align='center'><b><i><font color='#0000ff' face='arial' size='2'>");
        sDocument = sDocument.concat(bundle.getString("OnlyInnerChartData"));
        sDocument = sDocument.concat("</font></i></b>");

      
        if ( rulerKind == All )
        {
            sDocument = sDocument.concat("<p style='background-color: #FFE1C3;' align='center' width='60%'><b><font color='#C300FF' face='arial' size='4'>");
            sDocument = sDocument.concat(getRulerKind(All));
            sDocument = sDocument.concat("</font></b>");
        }
        
        String sDocumentDetail = "";
        if ( rulerRef == Both )
        {
            for (int i = 0; i < Both; i++)
            {
                sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #FFE1C3;' align='center' width='50%'><b><font color='#C300FF' face='arial' size='4'>");
                sDocumentDetail = sDocumentDetail.concat(getRulerRef(i));
                sDocumentDetail = sDocumentDetail.concat("</font></b>");
                if ( rulerKind == All )
                {
                    for (int j = 0; j < All; j++)
                    {
                        sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #C3C3FF;' align='center' width='40%'><b><font color='#000080' face='arial' size='4'>");
                        sDocumentDetail = sDocumentDetail.concat(getRulerKind(j));
                        sDocumentDetail = sDocumentDetail.concat("</font></b>");
                        sDocumentDetail = sDocumentDetail.concat(setText(j, i));
                    }
                }
                else
                {
                    if ( i == 0 )
                    {
                        sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #C3C3FF;' align='center' width='40%'><b><font color='#000080' face='arial' size='4'>");
                        sDocumentDetail = sDocumentDetail.concat(getRulerKind(rulerKind));
                        sDocumentDetail = sDocumentDetail.concat("</font></b>");
                    }
                    sDocumentDetail = sDocumentDetail.concat(setText(rulerKind, i));
                }
            }
        }
        else
        {
            sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #FFE1C3;' align='center' width='50%'><b><font color='#C300FF' face='arial' size='4'>");
            sDocumentDetail = sDocumentDetail.concat(getRulerRef(rulerRef));
            sDocumentDetail = sDocumentDetail.concat("</font></b>");
            if ( rulerKind == All )
            {
                for (int j = 0; j < All; j++)
                {
                    sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #C3C3FF;' align='center' width='40%'><b><font color='#000080' face='arial' size='4'>");
                    sDocumentDetail = sDocumentDetail.concat(getRulerKind(j));
                    sDocumentDetail = sDocumentDetail.concat("</font></b>");
                    sDocumentDetail = sDocumentDetail.concat(setText(j, rulerRef));
                }
            }
            else
            {
                    sDocumentDetail = sDocumentDetail.concat("<p style='background-color: #C3C3FF;' align='center' width='40%'><b><font color='#000080' face='arial' size='4'>");
                    sDocumentDetail = sDocumentDetail.concat(getRulerKind(rulerKind));
                    sDocumentDetail = sDocumentDetail.concat("</font></b>");
                    sDocumentDetail = sDocumentDetail.concat(setText(rulerKind, rulerRef));
            }
        }
        
        //DialogDoc DialogDoc = new DialogDoc();
        //windowNB += 1;
        String title = bundle.getString("Rulers");
        //HTMLDocument doc = (HTMLDocument) DialogDoc.getDocument();
        HTMLDocument doc = new HTMLDocument();
            
        sHtml = sDocument.concat(sDocumentDetail);
        Element firstElement = doc.getElement(doc.getDefaultRootElement(), StyleConstants.NameAttribute, HTML.Tag.BODY);
        try
        {
            HTMLEditorKit.Parser parser = new javax.swing.text.html.parser.ParserDelegator();
            doc.setParser(parser);
            sHtml = htmlStrings.processCR(sHtml);
            doc.setInnerHTML(firstElement, sHtml);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        catch (java.io.IOException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        //DialogDoc.resetUndo();
        //DialogDoc.getTextPane().setSelectionStart(0);
        //DialogDoc.getTextPane().setSelectionEnd(0);
        //DialogDoc.setVisible(true);
        //DialogDoc.setExtendedState(DialogDoc.MAXIMIZED_BOTH);
        DialogDoc docForm = new DialogDoc(new JDialog(), true, doc, title);
    }
    
    
    private String setText(int rulerKind, int rulerRef)
    {
        int i;
        int j;
        int iRulers[] = new int[Planets.Pluto+1];
        ArrayList signs;// = new ArrayList();
        double delta;
        double lenH;

        //text
        //----
        String strText = "<table width='100%' border='1' cellspacing='0' cellpadding='0'><tr>";

        //Line for the planets
        strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", bundle.getString("Planet")));
        for ( i = 0 ; i <= Planets.Pluto; i++)
        {
            strText = strText.concat(htmlStrings.getHTMLPlanet(i));
        }
        strText = strText.concat("</tr><tr>");

        //Line for the signs or the houses
        if ( rulerRef == 0 )
        {
            //for the signs
            strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", bundle.getString("Sign")));
            for ( i = 0 ; i <= Planets.Pluto; i++)
            {
                iRulers[i] = (int)(allCoord.get(i).getCoord1(sys_coord) / 30.0);
                strText = strText.concat(htmlStrings.getHTMLSign(iRulers[i]));
            }
        }
            
        else
        {
            //for the houses
            strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", bundle.getString("House")));
            for ( i = 0 ; i <= Planets.Pluto; i++)
            {
                strText = strText.concat(htmlStrings.getHTMLCaseDebut());
                for ( j = 0 ; j <= Cusp.House12; j++)
                {
                    //si l 'astre i se situe entre la pointe de la maison j normale et de la maison j+1 normale
                    delta = AstronomyMaths.modulo(allCoord.get(i).getCoord1(sys_coord) - allCoord.get(j + Planets.House1).getCoord1(sys_coord), 360.0);
                    lenH = AstronomyMaths.modulo(allCoord.get(AstronomyMaths.modulo(j + 1, 12) + Planets.House1).getCoord1(sys_coord) - allCoord.get(j + Planets.House1).getCoord1(sys_coord), 360.0);

                    if ( delta < lenH )
                    {
                        strText = strText.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", MainForm.houseName[j]));
                        break;
                    }
                }
                strText = strText.concat(htmlStrings.getHTMLCaseFin());
                iRulers[i] = j;
            }
        }
        strText = strText.concat("</tr><tr>");

        //Line for the rulers
        strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", bundle.getString("Ruler")));
        for (i = 0 ; i <= Planets.Pluto; i++)
        {
            j = getRuler(rulerKind, iRulers[i]);
            if ( j >= 0 )
            {
                strText = strText.concat(htmlStrings.getHTMLPlanet(j));
            }
            else
            {
                strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", "&nbsp;"));
            }
        }
        strText = strText.concat("</tr><tr>");

        //Line for the Home
        strText = strText.concat(htmlStrings.getHTMLOther(Color.BLACK, "arial", bundle.getString("Home")));
        for (i = 0 ; i <= Planets.Pluto; i++)
        {
            strText = strText.concat(htmlStrings.getHTMLCaseDebut());
            signs = getHome(rulerKind, i);
            if ( signs == null )
            {
                strText = strText.concat("&nbsp;");
            }
            else
            {
                for ( j = 0 ; j < signs.size(); j++)
                {
                    String sResult;
                    if ( rulerRef == 0 )
                    {
                        Integer sign = (Integer)signs.get(j);
                        strText = strText.concat(htmlStrings.getHTMLSign2(sign.intValue()));
                    }
                    else
                    {
                        Integer house = (Integer)signs.get(j);
                        //if (signs.size() > 1)
                        //{
                            sResult = bundle.getString("H") + " " + Integer.toString(house.intValue() + 1);
                        //}
                        //else
                        //{
                        //    sResult = MainForm.houseName[house.intValue()];
                        //}
                        strText = strText.concat(htmlStrings.getHTMLFont(Color.BLACK, "arial", sResult));
                    }
                    if ( j+1 < signs.size() )
                    {
                        strText = strText.concat(", ");
                    }
                }
            }
            strText = strText.concat(htmlStrings.getHTMLCaseFin());
        }
        strText = strText.concat("</tr></table>");
        return strText;
    }
    
    //get the current record
    @SuppressWarnings("unchecked")
    private ArrayList getHome(int rulerships, int planet)
    {
        ArrayList signs = new ArrayList();
        
        for (int i=0; i<12; i++)
        {
            if (getRuler(rulerships, i) == planet)
            {
                signs.add(new Integer(i));
            }
        }
        return signs;
    }
}
