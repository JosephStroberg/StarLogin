package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
public class ChartColor extends Object
{
    public static final byte Sun = 0;
    public static final byte Moon = 1;
    public static final byte Mercury = 2;
    public static final byte Venus = 3;
    public static final byte Mars = 4;
    public static final byte Jupiter = 5;
    public static final byte Saturn = 6;
    public static final byte Uranus = 7;
    public static final byte Neptune = 8;
    public static final byte Pluto = 9;
    public static final byte Gaia = 10;
    public static final byte Nodes = 11;
    public static final byte Houses = 12;
    public static final byte Asteroids = 13;
    public static final byte Vulcan = 14;
    public static final byte Text = 15;
    public static final byte Fire = 16;
    public static final byte Earth = 17;
    public static final byte Air = 18;
    public static final byte Water = 19;
    public static final byte Neutral = 20;
    public static final byte Dynamic = 21;
    public static final byte Harmonic = 22;
}