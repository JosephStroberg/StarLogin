package StarLogin.Systeme.Enum;
/**
 *
 * @author Francois DESCHAMPS
 * @version 1.0.0
 **/

public class WidthOption extends Object {        
    public static final byte pixels = 0;        
    public static final byte percent = 1; 
}