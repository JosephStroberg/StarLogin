package StarLogin.Systeme.Enum;

/**
 *
 * @author Francois DESCHAMPS
 * @version 8.0.0
 */
import StarLogin.IHM.DialogDoc;
import StarLogin.IHM.MainClass;
import StarLogin.IHM.MainForm;
import StarLogin.Systeme.AstroCalc.AstronomyMaths;
import StarLogin.Systeme.AstroCalc.ChartEvent;
import StarLogin.Systeme.AstroCalc.FDate;
import StarLogin.Systeme.AstroCalc.Planet;
import java.awt.Color;
import javax.swing.JDialog;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.html.HTMLDocument;

public class Dasa extends Object
{
    private static java.util.ResourceBundle bundle = MainClass.bundle;
    //private static int windowNB = 0;
    private static final int SouthNode = 0;
    private static final int Venus = 1;
    private static final int Sun  = 2;
    private static final int Moon  = 3;
    private static final int Mars  = 4;
    private static final int NorthNode  = 5;
    private static final int Jupiter  = 6;
    private static final int Saturn  = 7;
    private static final int Mercury  = 8;
    
    private static double bukhtiTime;
    private static double remainingTime;
    
    private static double getTimeDasa(int dasa)
    {
        switch(dasa)
        {
            case SouthNode: return 7.0;
            case Venus: return 20.0;
            case Sun: return 6.0;
            case Moon: return 10.0;
            case Mars: return 7.0;
            case NorthNode: return 18.0;
            case Jupiter: return 16.0;
            case Saturn: return 19.0;
            case Mercury: return 17.0;
            default: return 0.0;
        }
    }
    
    private static String getBukhtiName(int bukhti)
    {
        switch(bukhti)
        {
            case SouthNode: return MainForm.planetName[Planets.SouthNode];
            case Venus: return MainForm.planetName[Planets.Venus];
            case Sun: return MainForm.planetName[Planets.Sun];
            case Moon: return MainForm.planetName[Planets.Moon];
            case Mars: return MainForm.planetName[Planets.Mars];
            case NorthNode: return MainForm.planetName[Planets.NorthNode];
            case Jupiter: return MainForm.planetName[Planets.Jupiter];
            case Saturn: return MainForm.planetName[Planets.Saturn];
            case Mercury: return MainForm.planetName[Planets.Mercury];
            default: return "";
        }
    }
    
    private static String getBukhtiSymbol(int bukhti)
    {
        switch(bukhti)
        {
            case SouthNode: return "Z";
            case Venus: return "D";
            case Sun: return "A";
            case Moon: return "B";
            case Mars: return "E";
            case NorthNode: return "L";
            case Jupiter: return "F";
            case Saturn: return "G";
            case Mercury: return "C";
            default: return "";
        }
    }
    
    private static int getFirstBukhti(double timeDasa, int dasa)
    {
        double t = timeDasa;
        int bukhti = 0;
        double t0;
        
        while (t > 0.0)
        {
            t0 = getTimeDasa(AstronomyMaths.modulo(dasa + bukhti, 9));
            t -= t0;
            bukhti += 1;
        }
        remainingTime = -t * getTimeDasa(dasa) / 120.0 * 365.25;
        if ( t < 0.0 )
        {
            bukhti -= 1;
        } 
        else
        {
            bukhti = 0;
        }
        return AstronomyMaths.modulo(dasa + bukhti, 9);
    }
    
    private static int getNextBukhti(int dasa, int bukhti)
    {
        int nextBukhti = AstronomyMaths.modulo(bukhti + 1, 9);
        bukhtiTime = getTimeDasa(AstronomyMaths.modulo(nextBukhti, 9)) * getTimeDasa(dasa) / 120.0 * 365.25;
        return nextBukhti;
    }
    
    private static int getNextDasa(int dasa)
    {
        return AstronomyMaths.modulo(dasa + 1, 9);
    }
    
    public static void hinduCycles(ChartEvent ev)
    {
        Planet pl = new Planet(ev, false);
        String sDocument;
        int i;
        double nakshatra;
        double moonCoord;
        int orderNumNakshatra;
        int dasa;
        String nakshatras[] = new String[27];
        double timeDasa;
        int natalBukhti;
        int bukhti;
        int iHeaderLength;
        double t;
        double MaxTime = 120.0 * 365.25;
        String strDate;
        
        nakshatras[0] = "Aswini";
        nakshatras[1] = "Bharani";
        nakshatras[2] = "Krittika";
        nakshatras[3] = "Rohini";
        nakshatras[4] = "Mrigasira";
        nakshatras[5] = "Aridra";
        nakshatras[6] = "Punarvasu";
        nakshatras[7] = "Pushyami";
        nakshatras[8] = "Aslesha";
        nakshatras[9] = "Makha";
        nakshatras[10] = "Pubba";
        nakshatras[11] = "Uttara";
        nakshatras[12] = "Hasta";
        nakshatras[13] = "Chitta";
        nakshatras[14] = "Swati";
        nakshatras[15] = "Visakha";
        nakshatras[16] = "Anuradha";
        nakshatras[17] = "Jyesta";
        nakshatras[18] = "Moola";
        nakshatras[19] = "Poorvashadha";
        nakshatras[20] = "Uttarashadha";
        nakshatras[21] = "Sravana";
        nakshatras[22] = "Dhanishta";
        nakshatras[23] = "Satabhisha";
        nakshatras[24] = "Poorvabhadra";
        nakshatras[25] = "Uttarabhadra";
        nakshatras[26] = "Revati";
        
        pl.getObjPosition(Planets.Moon);
        moonCoord = pl.getCoordinates().getSiderGeoLong();
        nakshatra = moonCoord * 27.0 / 360.0;
        orderNumNakshatra = (int)(int)nakshatra;
        switch ((int)orderNumNakshatra)
        {
            case 0 :
            case 9 :
            case 18 : dasa = SouthNode; break;
            case 1 :
            case 10 :
            case 19 : dasa = Venus; break;
            case 2 :
            case 11 :
            case 20 : dasa = Sun; break;
            case 3 :
            case 12 :
            case 21 : dasa = Moon; break;
            case 4 :
            case 13 :
            case 22 : dasa = Mars; break;
            case 5 :
            case 14 :
            case 23 : dasa = NorthNode; break;
            case 6 :
            case 15 :
            case 24 : dasa = Jupiter; break;
            case 7 :
            case 16 :
            case 25 : dasa = Saturn; break;
            default : dasa = Mercury;
        }
        timeDasa = (nakshatra - orderNumNakshatra) * 120.0;
        natalBukhti = getFirstBukhti(timeDasa, dasa);
        
        sDocument = ev.getEvent().getSurname() + " " + ev.getEvent().getOtherNames() + "\r\n" + ev.getEvent().getEventName() + " " + ev.getEvent().getLocalDate() + "\r\n\r\n" + bundle.getString("HinduCycles");
        sDocument = sDocument + "\r\n" + "nakshatra " + nakshatras[orderNumNakshatra] + " - bukhti " + getBukhtiName(natalBukhti) + "\r\n" + "\r\n";
        iHeaderLength = sDocument.length();
        
        bukhti = natalBukhti;
        t = remainingTime;
        String sDocumentDetail = "";
        while (t < MaxTime)
        {
            strDate = new FDate(AstronomyMaths.julianToGregorian(ev.getJD() + t + (double)(int)(t / 4.0 / 365.25))).getDate();
            sDocumentDetail = sDocumentDetail + getBukhtiSymbol(dasa) + getBukhtiSymbol(bukhti) + "\t]\t" + strDate + "\r\n";
            bukhti = getNextBukhti(dasa, bukhti);
            if ( bukhti == dasa )
            {
                dasa = getNextDasa(dasa);
                bukhti = getNextBukhti(dasa, bukhti);
            }
            t += remainingTime;
        }
        
        String title = bundle.getString("HinduCycles");
        //DefaultStyledDocument doc = DialogDoc.getDocument();
        HTMLDocument doc = new HTMLDocument();//(HTMLDocument) docForm.getDocument();

        StyleContext styles = new StyleContext();
        Style s = styles.addStyle(null, null);
        Style sicon = styles.addStyle(null, null);
        
        try
        {
            //Header
            StyleConstants.setLineSpacing(s, 0.0f);
            StyleConstants.setFontFamily(s, "arial");
            StyleConstants.setAlignment(s, StyleConstants.ALIGN_CENTER);
            doc.insertString(doc.getLength(), " \n", s);
            StyleConstants.setFontSize(s, 16);
            StyleConstants.setBold(s, true);
            StyleConstants.setForeground(s, new Color(195, 0, 255));
            StyleConstants.setBackground(s, new Color(255, 225, 195));
            doc.insertString(doc.getLength(), bundle.getString("HinduCycles"), s); 
            StyleConstants.setAlignment(s, StyleConstants.ALIGN_LEFT);
            StyleConstants.setFontSize(s, 12);
            
            StyleConstants.setBackground(s, Color.WHITE);
            StyleConstants.setForeground(s, Color.BLACK);
            doc.insertString(doc.getLength(), " \n\n", s);
            doc.insertString(doc.getLength(), sDocument, s);
            
            //detail (dasa)
            StyleConstants.setFontFamily(s, "starlogin");
            StyleConstants.setFontSize(s, 12);
            doc.insertString(doc.getLength(), sDocumentDetail, s);
        }
        catch (BadLocationException ex)
        {
            MainClass.setMessage(ex.getMessage());
        }
        //DialogDoc.resetUndo();
        //DialogDoc.getTextPane().setSelectionStart(0);
        //DialogDoc.getTextPane().setSelectionEnd(0);
        //DialogDoc.setVisible(true);
        //DialogDoc.setExtendedState(DialogDoc.MAXIMIZED_BOTH);
        DialogDoc docForm = new DialogDoc(new JDialog(), true, doc, title);
    }
}