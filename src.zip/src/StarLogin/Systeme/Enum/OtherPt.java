package StarLogin.Systeme.Enum;

public class OtherPt extends Object {        
    public static final byte none = 0;   
    public static final byte asteroid = 1;
    public static final byte part = 2;
    public static final byte star = 3;
    public static final byte comet = 4;
}
